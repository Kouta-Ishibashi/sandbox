Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373813277291073536",
  "text" : "\u305D\u3057\u3066\u3053\u3093\u306A\u6642\u671F\u306B\u6696\u304B\u3044\u305D\u3070\u8336\u3068\u304B\u98F2\u3093\u3067\u308B",
  "id" : 373813277291073536,
  "created_at" : "2013-08-31 14:23:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373813210073137154",
  "text" : "\u53E3\u306E\u4E2D\u3001\u4E0A\u984E\uFF1F\u3084\u3051\u3069\u3057\u305F\u3082\u3088\u3046",
  "id" : 373813210073137154,
  "created_at" : "2013-08-31 14:23:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373810891378020353",
  "text" : "\u81EA\u660E\u306A\u3053\u3068\u30C9\u30E4\u9854\u3067\u8A00\u3046\u306E,\u672C\u4EBA\u304C\u30CD\u30BF\u3067\u3042\u308B\u3053\u3068\u3092\u8A8D\u8B58\u3057\u3066\u3044\u306A\u3044\u3068\u7247\u8179\u5927\u6FC0\u75DB",
  "id" : 373810891378020353,
  "created_at" : "2013-08-31 14:13:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373809510680236032",
  "text" : "\u6700\u8FD1\u98DF\u30D1\u30F3\u3092\u886810\u5206\u88CF10\u5206\u713C\u304F\u306E\u304C\u30C8\u30EC\u30F3\u30C9",
  "id" : 373809510680236032,
  "created_at" : "2013-08-31 14:08:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373807977502756864",
  "text" : "\u30A8\u30C3\u30B0\u98DF\u30D1\u30F3\u98DF\u3079\u305F\u3089\u3086\u3063\u304F\u308A\u304A\u98A8\u5442\u306F\u3044\u308D\u3046",
  "id" : 373807977502756864,
  "created_at" : "2013-08-31 14:02:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373806437152985088",
  "text" : "\u590F\u306E\u6642\u671F\u306B\u8CAF\u3081\u3053\u3080\u3068\u5927\u5909\u3060\u3068\u3044\u3046\u3053\u3068\u304C\u4ECA\u56DE\u306E\u3053\u3068\u3067\u3088\u304F\u308F\u304B\u3063\u305F\u3088",
  "id" : 373806437152985088,
  "created_at" : "2013-08-31 13:56:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373806332593201153",
  "text" : "\u4E45\u3005\u306B\u6D17\u3044\u7269\u3068\u30B7\u30F3\u30AF\u306E\u307E\u308F\u308A\u6383\u9664\u3057\u305F\u3089\u75B2\u308C\u305F",
  "id" : 373806332593201153,
  "created_at" : "2013-08-31 13:55:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373788716164063232",
  "text" : "\u305F\u3044\u3066\u3044\u306E\u4F1A\u8A71\u7CFB\u306E\u30B3\u30D4\u30DA\u300C\u305D\u3046\u3067\u3059\u304B.\u300D\u631F\u3081\u308B\u306E\u3067\u306F.",
  "id" : 373788716164063232,
  "created_at" : "2013-08-31 12:45:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373788502820790273",
  "text" : "\u5973\u795E\u300C\u3042\u306A\u305F\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u91D1\u306E\u65A7\u3067\u3059\u304B\uFF1F\u9280\u306E\u65A7\u3067\u3059\u304B\uFF1F\u300D\n\u6728\u3053\u308A\u300C\u9244\u306E\u65A7\u3067\u3059.\u300D\n\u5973\u795E\u300C\u305D\u3046\u3067\u3059\u304B.\u300D",
  "id" : 373788502820790273,
  "created_at" : "2013-08-31 12:44:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "indices" : [ 0, 10 ],
      "id_str" : "139971386",
      "id" : 139971386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373787822408208384",
  "geo" : { },
  "id_str" : "373788062368546816",
  "in_reply_to_user_id" : 139971386,
  "text" : "@pochipink \u305D\u308C\u3067\u3082\u4F55\u4F53\u30C7\u30B9\u30D4\u30B5\u30ED\u4F5C\u3089\u305B\u308B\u3093\u3060\u3063\u3066\u611F\u3058\u3057\u307E\u3057\u305F\u3051\u308C\u3069\u306D\uFF3B\u30C7\u30E5\u30E9\u30F3\u3068\u3057\u3093\u308A\u3085\u3046\u3067\u3057\u305F\u3063\u3051\u304B\uFF3D",
  "id" : 373788062368546816,
  "in_reply_to_status_id" : 373787822408208384,
  "created_at" : "2013-08-31 12:43:13 +0000",
  "in_reply_to_screen_name" : "pochipink",
  "in_reply_to_user_id_str" : "139971386",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373787219477032960",
  "text" : "\u304A\u6BCD\u3055\u3093\u5148\u751F\u306F\u5148\u751F\u3060\u304B\u3089\u5225\u3060\u3051\u3069\u306A\u3093\u304B\u304A\u304B\u3061\u30FC\u3060\u3051\u304A\u304B\u3061\u30FC\u3060\u306A\uFF3B\u3042\u3068\u306F\u307F\u3093\u306A\u3061\u3083\u3093\u3065\u3051\u306A\u306E\u306B\uFF3D",
  "id" : 373787219477032960,
  "created_at" : "2013-08-31 12:39:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373786592554393600",
  "text" : "\u5149\u304C\u3042\u308B\u3068\u3053\u308D\u306B\u95C7\u304C\u3042\u308B\u3093\u3060\u306A\u3041...",
  "id" : 373786592554393600,
  "created_at" : "2013-08-31 12:37:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "glacier",
      "screen_name" : "glacier_phys",
      "indices" : [ 0, 13 ],
      "id_str" : "543379554",
      "id" : 543379554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373786278791098369",
  "geo" : { },
  "id_str" : "373786470852485120",
  "in_reply_to_user_id" : 841274743,
  "text" : "@glacier_phys \u306F\u3044.\u3059\u3044\u307E\u305B\u3093\u3067\u3057\u305F.",
  "id" : 373786470852485120,
  "in_reply_to_status_id" : 373786278791098369,
  "created_at" : "2013-08-31 12:36:53 +0000",
  "in_reply_to_screen_name" : "glacier_string",
  "in_reply_to_user_id_str" : "841274743",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "indices" : [ 0, 10 ],
      "id_str" : "139971386",
      "id" : 139971386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373785645388271616",
  "geo" : { },
  "id_str" : "373786206938472448",
  "in_reply_to_user_id" : 139971386,
  "text" : "@pochipink \u30B0\u30E9\u30F3\u30B9\u30E9\u30A4\u30E0\u3068\u304B\u61D0\u304B\u3057\u3044\u3067\u3059\u306D\u30FC.\u9B54\u738B\u7CFB\u306E\u4F5C\u308A\u306B\u304F\u3055\u3082\u61D0\u304B\u3057\u3044\u9650\u308A\u3067\u3059.",
  "id" : 373786206938472448,
  "in_reply_to_status_id" : 373785645388271616,
  "created_at" : "2013-08-31 12:35:51 +0000",
  "in_reply_to_screen_name" : "pochipink",
  "in_reply_to_user_id_str" : "139971386",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373785878339915776",
  "text" : "\u3042\u3001\u304A\u6BCD\u3055\u3093\u5148\u751F\u6D3E\u3092\u5FD8\u308C\u3066\u3044\u307E\u3057\u305F",
  "id" : 373785878339915776,
  "created_at" : "2013-08-31 12:34:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373785807892402176",
  "text" : "\u3086\u3086\u5F0F\u304B\u3089\u5149\u304C\u767A\u305B\u3089\u308C\u308B\u6D3E\u306E\u306A\u304B\u306B\u3082\u3086\u3044\u3061\u3083\u3093\u6D3E\u3068\u3086\u305A\u3061\u3083\u3093\u6D3E\u3068\u3086\u304B\u308A\u3061\u3083\u3093\u6D3E\u3068\uFF08\u3042\u3044\u3061\u3083\u3093\u6D3E\u3068\u304A\u304B\u3061\u30FC\u6D3E\u3068\u3075\u307F\u3061\u3083\u3093\u6D3E\uFF09\u3067\u307E\u305F\u4E89\u3044\u305D\u3046\u306A",
  "id" : 373785807892402176,
  "created_at" : "2013-08-31 12:34:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373785350499352576",
  "text" : "\u307E\u3042\u5E78\u3044\uFF08\uFF1F\uFF09\u304A\u91D1\u306B\u4F59\u88D5\u306A\u3044\u304B\u3089\u3059\u3050\u306B\u306F\u5909\u3048\u306A\u3044\u3093\u3060\u3051\u308C\u3069\uFF1C3DS",
  "id" : 373785350499352576,
  "created_at" : "2013-08-31 12:32:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "indices" : [ 0, 10 ],
      "id_str" : "139971386",
      "id" : 139971386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373785046408105985",
  "geo" : { },
  "id_str" : "373785252251967489",
  "in_reply_to_user_id" : 139971386,
  "text" : "@pochipink \u307B\u3046\uFF013DS\u8CFC\u8CB7\u610F\u6B32\u304C\u5C11\u3057\u305A\u3064\u4E0A\u304C\u3063\u3066\u3044\u304D\u307E\u3059\u306D\uFF01\uFF3B\u30DD\u30B1\u30E2\u30F3\u3060\u3051\u306A\u3089\u898B\u9001\u308B\u4E88\u5B9A\u3067\u3057\u305F\u304C\u3080\u3080\u3080\uFF3D",
  "id" : 373785252251967489,
  "in_reply_to_status_id" : 373785046408105985,
  "created_at" : "2013-08-31 12:32:03 +0000",
  "in_reply_to_screen_name" : "pochipink",
  "in_reply_to_user_id_str" : "139971386",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "indices" : [ 3, 13 ],
      "id_str" : "139971386",
      "id" : 139971386
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 15, 25 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373785072756748289",
  "text" : "RT @pochipink: @end313124 3DS\u3067\u30EA\u30E1\u30A4\u30AF\u3055\u308C\u308B\u3089\u3057\u3044\u3067\u3059\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "373784682057326592",
    "geo" : { },
    "id_str" : "373785046408105985",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 3DS\u3067\u30EA\u30E1\u30A4\u30AF\u3055\u308C\u308B\u3089\u3057\u3044\u3067\u3059\uFF01",
    "id" : 373785046408105985,
    "in_reply_to_status_id" : 373784682057326592,
    "created_at" : "2013-08-31 12:31:14 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "protected" : true,
      "id_str" : "139971386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576397464820789248\/Ns-Cf1nH_normal.jpeg",
      "id" : 139971386,
      "verified" : false
    }
  },
  "id" : 373785072756748289,
  "created_at" : "2013-08-31 12:31:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373785048253620224",
  "text" : "\u8AB0\u304Bmikutter\u30E6\u30FC\u30B6\u30FC\u306B\u4F1A\u3063\u305F\u3089\u8272\u3005\u805E\u3044\u3066\u307F\u3088\u3046\u3063\u3068",
  "id" : 373785048253620224,
  "created_at" : "2013-08-31 12:31:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373784682057326592",
  "text" : "\u30A4\u30EB\u30EB\u30AB\u30EA\u30E1\u30A4\u30AF\u3059\u308B\u306E\uFF1F",
  "id" : 373784682057326592,
  "created_at" : "2013-08-31 12:29:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "indices" : [ 3, 13 ],
      "id_str" : "139971386",
      "id" : 139971386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373784625757163520",
  "text" : "RT @pochipink: \u30C9\u30E9\u30B4\u30F3\u30AF\u30A8\u30B9\u30C8\u30E2\u30F3\u30B9\u30BF\u30FC\u30BA2\u30EA\u30E1\u30A4\u30AF\u306E\u7D9A\u5831\u51FA\u3066\u305F\u3068\u306F\u77E5\u3089\u3093\u304B\u3063\u305F...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373784463446003712",
    "text" : "\u30C9\u30E9\u30B4\u30F3\u30AF\u30A8\u30B9\u30C8\u30E2\u30F3\u30B9\u30BF\u30FC\u30BA2\u30EA\u30E1\u30A4\u30AF\u306E\u7D9A\u5831\u51FA\u3066\u305F\u3068\u306F\u77E5\u3089\u3093\u304B\u3063\u305F...",
    "id" : 373784463446003712,
    "created_at" : "2013-08-31 12:28:55 +0000",
    "user" : {
      "name" : "\u611B\u3068\u4FE1\u983C\u306E\u30DD\u30C1\u30D4\u30F3\u30AF@\u30CD\u30B3",
      "screen_name" : "pochipink",
      "protected" : true,
      "id_str" : "139971386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576397464820789248\/Ns-Cf1nH_normal.jpeg",
      "id" : 139971386,
      "verified" : false
    }
  },
  "id" : 373784625757163520,
  "created_at" : "2013-08-31 12:29:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373784253437181952",
  "text" : "\u3073\u3063\u307F\u3087\u3046\u306A\u6642\u9593\u306B\u3054\u98EF\u98DF\u3079\u305F\u305B\u3044\u3067\u3073\u3063\u307F\u3087\u3046\u306A\u6642\u9593\u306B\u304A\u8179\u6E1B\u3063\u305F\u306A",
  "id" : 373784253437181952,
  "created_at" : "2013-08-31 12:28:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373783441638047744",
  "text" : "\u3066\u3059\u3066\u3059",
  "id" : 373783441638047744,
  "created_at" : "2013-08-31 12:24:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373783209827258368",
  "text" : "\u30B7\u30F3\u30BF\u30B9\u4ECA\u5EA6\u306F\u6176\u5FDC\u3067\u3059\u304B\u3002\u53BB\u5E74\u306FKU\u306B\u304D\u3066\u305F\u3093\u3060\u3063\u3051\uFF1F",
  "id" : 373783209827258368,
  "created_at" : "2013-08-31 12:23:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 3, 12 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/JgpRc7UCNn",
      "expanded_url" : "http:\/\/seiyuusokuhou.blog106.fc2.com\/?mode=m&no=6946",
      "display_url" : "seiyuusokuhou.blog106.fc2.com\/?mode=m&no=6946"
    } ]
  },
  "geo" : { },
  "id_str" : "373783099907112960",
  "text" : "RT @isaribiz: \u65B0\u8C37\u826F\u5B50\u3055\u3093\u304C\u6176\u61C9\u5927\u5B66\u77E2\u4E0A\u30AD\u30E3\u30F3\u30D1\u30B9\u306E\u5B66\u5712\u796D\u3067\u30C8\u30FC\u30AF\u30B7\u30E7\u30FC\u958B\u50AC\u6C7A\u5B9A\uFF01 - \u58F0\u512A\u2606\u901F\u5831 http:\/\/t.co\/JgpRc7UCNn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/2chmatomesaitorida\/id388549602?mt=8&uo=4\" rel=\"nofollow\"\u003E2ch\u307E\u3068\u3081\u30B5\u30A4\u30C8\u30EA\u30FC\u30C0\u30FC on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/JgpRc7UCNn",
        "expanded_url" : "http:\/\/seiyuusokuhou.blog106.fc2.com\/?mode=m&no=6946",
        "display_url" : "seiyuusokuhou.blog106.fc2.com\/?mode=m&no=6946"
      } ]
    },
    "geo" : { },
    "id_str" : "373783061231439872",
    "text" : "\u65B0\u8C37\u826F\u5B50\u3055\u3093\u304C\u6176\u61C9\u5927\u5B66\u77E2\u4E0A\u30AD\u30E3\u30F3\u30D1\u30B9\u306E\u5B66\u5712\u796D\u3067\u30C8\u30FC\u30AF\u30B7\u30E7\u30FC\u958B\u50AC\u6C7A\u5B9A\uFF01 - \u58F0\u512A\u2606\u901F\u5831 http:\/\/t.co\/JgpRc7UCNn",
    "id" : 373783061231439872,
    "created_at" : "2013-08-31 12:23:21 +0000",
    "user" : {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "protected" : true,
      "id_str" : "150662260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586179377114685441\/2LPKH2Xn_normal.jpg",
      "id" : 150662260,
      "verified" : false
    }
  },
  "id" : 373783099907112960,
  "created_at" : "2013-08-31 12:23:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373782644741263360",
  "text" : "\u62BD\u51FA\u30BF\u30D6\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 373782644741263360,
  "created_at" : "2013-08-31 12:21:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373781815133093888",
  "text" : "\u3068\u304B\u8A00\u308F\u308C\u305F\u304C\u307B\u307C\u30C7\u30D5\u30A9\u30EB\u30C8\u3060\u3057\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u3093\u3060\u308D.",
  "id" : 373781815133093888,
  "created_at" : "2013-08-31 12:18:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373781730236178433",
  "text" : "home_timeline' \u304C\u898F\u5236\u3055\u308C\u307E\u3057\u305F\u3002 21:17:06\u306B\u89E3\u9664\u3055\u308C\u307E\u3059\u3002\nstatuses\/home_timeline \u306F15\u5206\u306B 15 \u56DE\u307E\u3067\u306E\u30A2\u30AF\u30BB\u30B9\u304C\u8A31\u53EF\u3055\u308C\u3066\u3044\u307E\u3059\u3002\u983B\u767A\u3059\u308B\u3088\u3046\u306A\u3089\u540C\u6642\u306B\u4F7F\u7528\u3059\u308BTwitter\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u3092\u6E1B\u3089\u3059\u304B\u3001\u8A2D\u5B9A\u3092\u898B\u76F4\u3057\u307E\u3057\u3087\u3046.",
  "id" : 373781730236178433,
  "created_at" : "2013-08-31 12:18:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373781339914248192",
  "text" : "\u3042\u308C\u3053\u308C\u3084\u3063\u3066\u308B\u3068\u5FC3\u304C\u4F11\u307E\u3089\u306A\u3044\u3057\u306A\u3093\u306B\u3082\u3057\u306A\u3044\u3068\u5FC3\u304C\u8150\u3063\u3066\u3044\u304F\u304B\u3089\u5FC3\u3068\u304B\u3044\u3046\u30B7\u30B9\u30C6\u30E0\u306F\u5EC3\u6B62\u3059\u3079\u304D\u306A\u306E\u3067\u306F",
  "id" : 373781339914248192,
  "created_at" : "2013-08-31 12:16:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373781189447778305",
  "text" : "\u4E45\u3005\u306B\u4F55\u3082\u306A\u3044\u7121\u70BA\u306A\u4E00\u65E5\u3092\u904E\u3054\u3057\u3066\u3057\u307E\u3063\u305F.",
  "id" : 373781189447778305,
  "created_at" : "2013-08-31 12:15:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373780492446728193",
  "text" : "\u30A2\u30A4\u30B3\u30F3\u306F\u306A\u308A\u305F\u3044\u59FF\u3060\u3068\u3059\u308B\u3068\u79C1\u306F\u4F55\u306B\u306A\u308A\u305F\u3044\u3093\u3060\uFF1F",
  "id" : 373780492446728193,
  "created_at" : "2013-08-31 12:13:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373779388287840257",
  "text" : "\u3066\u304A\u304F\u308C\u306A\u3044\u3088\u3046\u306B\u3057\u306A\u3051\u308C\u3070\uFF1F",
  "id" : 373779388287840257,
  "created_at" : "2013-08-31 12:08:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373779363944083456",
  "text" : "\u8272\u3005\u8A2D\u5B9A\u3057\u3066\u307F\u305F\u304C\u5B9F\u969B\u81EA\u7531\u5EA6\u9AD8\u305D\u3046\u3060\u306A\u307F\u304F\u3063\u305F\u30FC",
  "id" : 373779363944083456,
  "created_at" : "2013-08-31 12:08:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mikutter.hachune.net\/\" rel=\"nofollow\"\u003Emikutter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373778168663928832",
  "text" : "\u3053\u3053\u306Bmikutter\u304C\u3042\u308B\u3058\u3083\u308D\uFF1F\u3000tsts",
  "id" : 373778168663928832,
  "created_at" : "2013-08-31 12:03:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373777288065589248",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 373777288065589248,
  "created_at" : "2013-08-31 12:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373768201118556160",
  "text" : "\u53E3\u52D5\u304B\u3057\u305F\u3044\u304A\u5316\u3051\u304C\u3053\u3053\u306B",
  "id" : 373768201118556160,
  "created_at" : "2013-08-31 11:24:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373734925729419265",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 373734925729419265,
  "created_at" : "2013-08-31 09:12:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373734913507217408",
  "text" : "\u305D\u3046\u8003\u3048\u308B\u3068\u65B0\u5E79\u7DDA\u3059\u3052\u30FC\u65E9\u3044\u306A\uFF01\uFF01\uFF01\u3042\u308C\u3067\u5C4B\u6839\u304C\u306A\u304B\u3063\u305F\u3089\u826F\u304B\u3063\u305F\u306E\u306B",
  "id" : 373734913507217408,
  "created_at" : "2013-08-31 09:12:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373734703490011136",
  "text" : "\u6D41\u77F3\u306B\u30B8\u30A7\u30C3\u30C8\u30B3\u30FC\u30B9\u30BF\u30FC6\u6642\u9593\u4EE5\u4E0A\u4E57\u308B\u306E\u306F\u7121\u7406\u3067\u3059\u2026",
  "id" : 373734703490011136,
  "created_at" : "2013-08-31 09:11:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373734626545508352",
  "text" : "\u8ABF\u3079\u305F\u3089\u30B8\u30A7\u30C3\u30C8\u30B3\u30FC\u30B9\u30BF\u30FC\u6700\u9AD8\u6642\u901F\u3067\u3082\u305B\u3044\u305C\u304480km\/h\u3089\u3057\u3044\u3057\u5B9F\u5BB6\u307E\u30676\u6642\u9593\u4EE5\u4E0A\u304B\u304B\u308B",
  "id" : 373734626545508352,
  "created_at" : "2013-08-31 09:10:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373734272307191809",
  "text" : "\u30B8\u30A7\u30C3\u30C8\u30B3\u30FC\u30B9\u30BF\u30FC\u3067\u5B9F\u5BB6\u307E\u3067\u5E30\u308A\u305F\u3044",
  "id" : 373734272307191809,
  "created_at" : "2013-08-31 09:09:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373734176475725824",
  "text" : "\u75BE\u8D70\u611F\u6B32\u3057\u3044\u3001\u30B8\u30A7\u30C3\u30C8\u30B3\u30FC\u30B9\u30BF\u30FC\u3068\u304B\u4E57\u308A\u305F\u3044[\u306A\u304A\u304A\u91D1\u306F\u306A\u3044\u6A21\u69D8]",
  "id" : 373734176475725824,
  "created_at" : "2013-08-31 09:09:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373733767950524416",
  "text" : "\u304F\u308D\u306D\u3055\u3093\u306F\u753B\u4F2F\u3060\u3063\u305F\u304B\u3089\u306A\u3041\u2026[A\u306A\u3089\u3070A]",
  "id" : 373733767950524416,
  "created_at" : "2013-08-31 09:07:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u306D",
      "screen_name" : "spine19642",
      "indices" : [ 0, 11 ],
      "id_str" : "264623696",
      "id" : 264623696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373733256455127040",
  "in_reply_to_user_id" : 264623696,
  "text" : "@spine19642 \u5FF5\u306E\u305F\u3081\u30AB\u30D0\u30F3\u7B49\u898B\u3066\u898B\u307E\u3057\u305F\u304C\u898B\u5F53\u305F\u308A\u307E\u305B\u3093[\u50D5\u304C\u5E30\u3063\u305F\u3042\u3068\u306B\u5B58\u5728\u78BA\u8A8D\u304C\u53D6\u308C\u3066\u308C\u3070\u4F59\u8A08\u3067\u3059\u304C\u3001\u4E00\u5FDC]",
  "id" : 373733256455127040,
  "created_at" : "2013-08-31 09:05:26 +0000",
  "in_reply_to_screen_name" : "spine19642",
  "in_reply_to_user_id_str" : "264623696",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373731252857090049",
  "geo" : { },
  "id_str" : "373732399584006144",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3067\u304D\u307E\u3057\u305F\u3001\u3054\u5FC3\u914D\u306A\u304F",
  "id" : 373732399584006144,
  "in_reply_to_status_id" : 373731252857090049,
  "created_at" : "2013-08-31 09:02:02 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373722338887352320",
  "text" : "\u6614\u3005\u3042\u308B\u3068\u3053\u308D\u306B\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u3068\u3044\u3046\u30A6\u30A7\u30D6\u30B5\u30FC\u30D3\u30B9\u304C\u3042(\u6587\u5B57\u306F\u3053\u3053\u3067\u9014\u5207\u308C\u3066\u3044\u308B)",
  "id" : 373722338887352320,
  "created_at" : "2013-08-31 08:22:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373722005171740672",
  "text" : "\u8D85\u9AD8\u6821\u7D1A\u306E\u5E30\u5B85\u6B32",
  "id" : 373722005171740672,
  "created_at" : "2013-08-31 08:20:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373721602828943360",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 373721602828943360,
  "created_at" : "2013-08-31 08:19:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373721569647800320",
  "text" : "\u7406\u60F3\u3068\u3059\u308B\u6709\u8C61\u7121\u8C61\u50CF",
  "id" : 373721569647800320,
  "created_at" : "2013-08-31 08:19:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373721373794783232",
  "text" : "\u6709\u8C61\u7121\u8C61\u50CF\u3092\u5EFA\u3066\u305F\u3044",
  "id" : 373721373794783232,
  "created_at" : "2013-08-31 08:18:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373720201608429568",
  "text" : "\uFF1F",
  "id" : 373720201608429568,
  "created_at" : "2013-08-31 08:13:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373720192242556928",
  "text" : "\u610F\u5473\u4E0D\u660E\u306A\u8A00\u8449\u306F\u201D\u306E\u201D\u3068\u3044\u3046\u52A9\u8A5E\u306B\u3064\u3044\u3066\u610F\u5473\u4E0D\u660E\u3055\u304C\u9589\u3058\u3066\u3044\u308B",
  "id" : 373720192242556928,
  "created_at" : "2013-08-31 08:13:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373719998088216576",
  "text" : "\u201C\u304B\u3078\u308F\u306C\u3081\u201D\u3082\u201D\u3059\u3086\u3042\u306C\u201D\u3082\u610F\u5473\u4E0D\u660E\u3060\u304B\u3089\u201D\u304B\u3078\u308F\u306C\u3081\u306E\u3059\u3086\u3042\u306C\u201D\u306F\u610F\u5473\u4E0D\u660E",
  "id" : 373719998088216576,
  "created_at" : "2013-08-31 08:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373719724573462528",
  "text" : "\u307E\u3041\u591C\u306B\u3082\u4F3C\u305F\u3088\u306A\u30DD\u30B9\u30C8\u3057\u3066\u307F\u308B\u304B\u306A\u30FC",
  "id" : 373719724573462528,
  "created_at" : "2013-08-31 08:11:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373719666952122368",
  "text" : "\u30ED\u30B4\u307F\u305F\u3044\u306A\u306E\u3067\u826F\u3044\u3068\u601D\u308F\u308C\u308B&lt;\u30A4\u30E9\u30B9\u30C8",
  "id" : 373719666952122368,
  "created_at" : "2013-08-31 08:11:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373719473665998848",
  "text" : "\u89AA\u306B\u5411\u304B\u3063\u3066\u306A\u3093\u3060\u2026\u305D\u306E\u2026\u307B\u3089\u3001\u30A2\u30EC\u3060\u3088\u30A2\u30EC",
  "id" : 373719473665998848,
  "created_at" : "2013-08-31 08:10:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373719102168104960",
  "text" : "1cm\u3063\u3066\u4F55\u30D4\u30AF\u30BB\u30EB\u306A\u3093\u3060\u308D(\u3058\u3087\u3046\u3088\u308F",
  "id" : 373719102168104960,
  "created_at" : "2013-08-31 08:09:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373718999504125953",
  "text" : "[\u3086\u308B\u307C\/\u62E1\u6563\u5E0C\u671B]\u304B\u3078\u308F\u306C\u3081\u306E\u201D\u3059\u3086\u3042\u306C\u201D\u306E\u30D1\u30F3\u30D5\u306B\u8F09\u305B\u308B\u30A4\u30E9\u30B9\u30C8\u66F8\u3044\u3066\u304F\u308C\u308B\u4EBA.4cm\u00D74cm.",
  "id" : 373718999504125953,
  "created_at" : "2013-08-31 08:08:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373717609385959424",
  "text" : "\u77E2\u3082\u76FE\u3082\u305F\u307E\u3089\u306C\u3058\u3083",
  "id" : 373717609385959424,
  "created_at" : "2013-08-31 08:03:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373521823154974721",
  "text" : "4\u6642\u306B\u76EE\u304C\u899A\u3081\u308B\u3001\u5BDD\u9055\u3048\u304C\u3088\u308A\u3072\u3069\u304F\u306A\u3063\u3066\u308B\u30023\u30DE\u30B9\u623B\u308B\u3002[\u7121\u8AD6\u4E8C\u5EA6\u5BDD]",
  "id" : 373521823154974721,
  "created_at" : "2013-08-30 19:05:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373413449822253056",
  "text" : "\u306F\u3050\u308B\u307E\u3055\u3093\u306Ebio\u306B\u5408\u308F\u305B\u3066(?)bio\u5909\u3048\u305F.\u304A\u3084\u3059\u307F.",
  "id" : 373413449822253056,
  "created_at" : "2013-08-30 11:54:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373411507909840896",
  "text" : "\u7720\u3059\u304E\u3066\u7720\u3059\u304E\u3066\u5BDD\u308B",
  "id" : 373411507909840896,
  "created_at" : "2013-08-30 11:46:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373382168212287489",
  "text" : "\u305D\u3046\u3060\u3063\u305F\u306E\u304B\u2026",
  "id" : 373382168212287489,
  "created_at" : "2013-08-30 09:50:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "indices" : [ 3, 10 ],
      "id_str" : "89620915",
      "id" : 89620915
    }, {
      "name" : "palmon",
      "screen_name" : "palmon2011",
      "indices" : [ 30, 41 ],
      "id_str" : "238617473",
      "id" : 238617473
    }, {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "indices" : [ 43, 50 ],
      "id_str" : "89620915",
      "id" : 89620915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373382135165374464",
  "text" : "RT @qusumi: \u3042\u308C\u304C\uFF12\uFF12\u6B73\u306E\u30C7\u30D3\u30E5\u30FC\u4F5C\u3067\u3059\u3002RT @palmon2011: @qusumi \u4E16\u306B\u3082\u5947\u5999\u306A\u7269\u8A9E\u306E\u3001\u591C\u6C7D\u8ECA\u306E\u7537\u306E\u539F\u4F5C\u3063\u3066\u4E45\u4F4F\u3055\u3093\u3060\u3063\u305F\u306E\u3067\u3059\u304B( \uFF9F\u0434\uFF9F )\u5B58\u3058\u4E0A\u3052\u307E\u305B\u3093\u3067\u3057\u305F\n\u5F53\u6642\u30C6\u30EC\u30D3\u3084\u539F\u4F5C\u672C\u3067\u898B\u3066\u3001\u5909\u306A\u8A71\u3060\u3051\u3069\u9762\u767D\u3044\u306A\u3042\u3001\u3068\u601D\u3063\u305F\u3082\u306E\u3067\u3059\n\u3068\u3066\u3082\u4E0D\u601D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "palmon",
        "screen_name" : "palmon2011",
        "indices" : [ 18, 29 ],
        "id_str" : "238617473",
        "id" : 238617473
      }, {
        "name" : "\u4E45\u4F4F\u660C\u4E4B",
        "screen_name" : "qusumi",
        "indices" : [ 31, 38 ],
        "id_str" : "89620915",
        "id" : 89620915
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373366429170802688",
    "text" : "\u3042\u308C\u304C\uFF12\uFF12\u6B73\u306E\u30C7\u30D3\u30E5\u30FC\u4F5C\u3067\u3059\u3002RT @palmon2011: @qusumi \u4E16\u306B\u3082\u5947\u5999\u306A\u7269\u8A9E\u306E\u3001\u591C\u6C7D\u8ECA\u306E\u7537\u306E\u539F\u4F5C\u3063\u3066\u4E45\u4F4F\u3055\u3093\u3060\u3063\u305F\u306E\u3067\u3059\u304B( \uFF9F\u0434\uFF9F )\u5B58\u3058\u4E0A\u3052\u307E\u305B\u3093\u3067\u3057\u305F\n\u5F53\u6642\u30C6\u30EC\u30D3\u3084\u539F\u4F5C\u672C\u3067\u898B\u3066\u3001\u5909\u306A\u8A71\u3060\u3051\u3069\u9762\u767D\u3044\u306A\u3042\u3001\u3068\u601D\u3063\u305F\u3082\u306E\u3067\u3059\n\u3068\u3066\u3082\u4E0D\u601D\u8B70\u306A\u6C17\u5206\u3067\u3059",
    "id" : 373366429170802688,
    "created_at" : "2013-08-30 08:47:48 +0000",
    "user" : {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "protected" : false,
      "id_str" : "89620915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1625008477\/Q_Wqusumi_____normal.jpg",
      "id" : 89620915,
      "verified" : false
    }
  },
  "id" : 373382135165374464,
  "created_at" : "2013-08-30 09:50:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373140995237363712",
  "text" : "\u3081\u3081\u3081\u3081\u3081\u3081\u3081\u3081\u3046\u3081\u3046",
  "id" : 373140995237363712,
  "created_at" : "2013-08-29 17:52:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373125748736794624",
  "text" : "\u3086\u3086\u5F0F\u304C\u7D42\u308F\u3063\u305F\u3068\u304B\u3044\u3046\u30C7\u30DE",
  "id" : 373125748736794624,
  "created_at" : "2013-08-29 16:51:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373123445115994112",
  "text" : "\u30CA\u30D3\u30B9\u30B3\u306E\u30AA\u30EA\u30B8\u30CA\u30EB\u30D7\u30EC\u30DF\u30A2\u30E0\u30AF\u30E9\u30C3\u30AB\u30FC\u7F8E\u5473\u3057\u3044",
  "id" : 373123445115994112,
  "created_at" : "2013-08-29 16:42:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373082697976922114",
  "text" : "\u3069\u3046\u3082\u201D\u60AA\u3044\u30CD\u30BA\u30DF\u306E\u30A4\u30C7\u30A2\u201D\u3092\u66F8\u3051\u308B\u65B9\u306E\u30A8\u30F3\u30C9\u3067\u3059.",
  "id" : 373082697976922114,
  "created_at" : "2013-08-29 14:00:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373052514477694976",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 373052514477694976,
  "created_at" : "2013-08-29 12:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373038585110208512",
  "text" : "\u201D\u3059\u3086\u3042\u306C\u201D \u4F55\u56DE\u304B\u53E3\u306B\u51FA\u3059\u3068\u3057\u3063\u304F\u308A\u3057\u3066\u304D\u305F\u6C17\u304C",
  "id" : 373038585110208512,
  "created_at" : "2013-08-29 11:05:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373037724405481472",
  "text" : "\u3059\u306C\u3042\u306C\u3081",
  "id" : 373037724405481472,
  "created_at" : "2013-08-29 11:01:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373037611016671232",
  "text" : "\u3059\u3086\u3042\u306C",
  "id" : 373037611016671232,
  "created_at" : "2013-08-29 11:01:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373037412126978048",
  "geo" : { },
  "id_str" : "373037521266954240",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u3044\u307F\u306A\u3093\u3066\u306A\u3044\u3001\u3067\u3059",
  "id" : 373037521266954240,
  "in_reply_to_status_id" : 373037412126978048,
  "created_at" : "2013-08-29 11:00:50 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373036846931931136",
  "text" : "\u201C\u304B\u3078\u308F\u306C\u3081\u201D\u306E\u201D\u3059\u3086\u3042\u306C\u201D\u3001\u8A00\u3044\u3065\u3089\u3044",
  "id" : 373036846931931136,
  "created_at" : "2013-08-29 10:58:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 15, 25 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/373036592245391360\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/P1Fp6eUEwL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS1KzdBCMAEL2CX.jpg",
      "id_str" : "373036591964368897",
      "id" : 373036591964368897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS1KzdBCMAEL2CX.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/P1Fp6eUEwL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373036720704331776",
  "text" : "\u300C\u3059\u3086\u3042\u306C\u300D\u3067\u3057\u305F\uFF01\uFF01\uFF01RT @end313124: \u304B\u3078\u308F\u306C\u3081\u306E\u4F01\u753B\u540D\u300C\u3059\u3086\u308F\u306C\u300D\u306B\u6C7A\u5B9A\u3057\u307E\u3057\u305F\uFF01\uFF01\uFF01 http:\/\/t.co\/P1Fp6eUEwL",
  "id" : 373036720704331776,
  "created_at" : "2013-08-29 10:57:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/373036592245391360\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/P1Fp6eUEwL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS1KzdBCMAEL2CX.jpg",
      "id_str" : "373036591964368897",
      "id" : 373036591964368897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS1KzdBCMAEL2CX.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/P1Fp6eUEwL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373036592245391360",
  "text" : "\u304B\u3078\u308F\u306C\u3081\u306E\u4F01\u753B\u540D\u300C\u3059\u3086\u308F\u306C\u300D\u306B\u6C7A\u5B9A\u3057\u307E\u3057\u305F\uFF01\uFF01\uFF01 http:\/\/t.co\/P1Fp6eUEwL",
  "id" : 373036592245391360,
  "created_at" : "2013-08-29 10:57:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372819756069715968",
  "geo" : { },
  "id_str" : "372820765756100608",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u8D77\u304D\u305F\u6642\u9593\u306B\u5FDC\u3058\u3066\u8003\u3048\u307E\u3059\u3068\u308A\u3042\u3048\u305A\u30EB\u30CD\u3067\u3059\u304B\u306D\u2026[]",
  "id" : 372820765756100608,
  "in_reply_to_status_id" : 372819756069715968,
  "created_at" : "2013-08-28 20:39:31 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372818467055226880",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 372818467055226880,
  "created_at" : "2013-08-28 20:30:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372817035136630784",
  "geo" : { },
  "id_str" : "372817767235616768",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u4F55\u6642\u306B\u884C\u3051\u3070\u3044\u3044\u3067\u3059\u304B([\u50D5\u3082\u4ECA\u304B\u3089\u5BDD\u307E\u3059]",
  "id" : 372817767235616768,
  "in_reply_to_status_id" : 372817035136630784,
  "created_at" : "2013-08-28 20:27:36 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372746026328657920",
  "text" : "pixiv\u3068facebook\u8272\u3005\u7DE8\u96C6\u3057\u305F",
  "id" : 372746026328657920,
  "created_at" : "2013-08-28 15:42:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pixiv",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/XkC39bhhaJ",
      "expanded_url" : "http:\/\/www.pixiv.net\/member.php?id=8178755",
      "display_url" : "pixiv.net\/member.php?id=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372737100589694976",
  "text" : "\u300Cend313124\u300D\u306E\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB[pixiv] #pixiv http:\/\/t.co\/XkC39bhhaJ",
  "id" : 372737100589694976,
  "created_at" : "2013-08-28 15:07:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372733210138267648",
  "text" : "pixiv\u767B\u9332\u3057\u307E\u3057\u305F[\u306A\u304A\u5C0F\u5B66\u751F\u4E26\u307F\u306E\u753B\u529B]",
  "id" : 372733210138267648,
  "created_at" : "2013-08-28 14:51:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372520346928578561",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 372520346928578561,
  "created_at" : "2013-08-28 00:45:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372520126353907712",
  "text" : "\u3055\u3066\u3055\u30FC\u3066\uFF1F",
  "id" : 372520126353907712,
  "created_at" : "2013-08-28 00:44:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "q",
      "screen_name" : "qvolks",
      "indices" : [ 0, 7 ],
      "id_str" : "1537700496",
      "id" : 1537700496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372517087656148992",
  "text" : "@qvolks (\u4ECA\u65E5\u306F\u591A\u5FD9\u3067\u3057\u2026)",
  "id" : 372517087656148992,
  "created_at" : "2013-08-28 00:32:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372509744960794624",
  "text" : "\u671D\u306E\u7CFA\u306E\u68EE\u5FC3\u5730\u3088\u3044",
  "id" : 372509744960794624,
  "created_at" : "2013-08-28 00:03:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372500642633646082",
  "text" : "\u76EE\u899A\u307E\u3057\u304C\u306A\u308B\u524D\u306B\u8D77\u304D\u308B\u5049\u696D\u3092\u9054\u6210\u3057\u307E\u3057\u305F\u3002",
  "id" : 372500642633646082,
  "created_at" : "2013-08-27 23:27:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372327761907417088",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 372327761907417088,
  "created_at" : "2013-08-27 12:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372260954194456577",
  "geo" : { },
  "id_str" : "372261109786345472",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u3044\u3048\u4F55\u3082",
  "id" : 372261109786345472,
  "in_reply_to_status_id" : 372260954194456577,
  "created_at" : "2013-08-27 07:35:39 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372260812007567360",
  "text" : "\u6C34\uFF13\uFF15\uFF2C\u70AD\u7D20\uFF12\uFF10\uFF4B\uFF47\u30A2\u30F3\u30E2\u30CB\u30A2\uFF14\uFF2C\u77F3\u7070\uFF11.\uFF15\uFF4B\uFF47\u30EA\u30F3\uFF18\uFF10\uFF10\uFF47\u5869\u5206\uFF12\uFF15\uFF10\uFF47\u785D\u77F3\uFF11\uFF10\uFF10\uFF47\u786B\u9EC4\uFF18\uFF10\uFF47\u30D5\u30C3\u7D20\uFF17.\uFF15\uFF47\u9244\uFF15\uFF47\u30B1\u30A4\u7D20\uFF13\uFF47\u305D\u306E\u4ED6\u5C11\u91CF\u306E\uFF11\uFF15\u306E\u5143\u7D20",
  "id" : 372260812007567360,
  "created_at" : "2013-08-27 07:34:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372237298433142784",
  "geo" : { },
  "id_str" : "372239550434652160",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u4E86\u89E3\u3067\u3059\u3001\u307E\u305F\u5225\u306E\u6A5F\u4F1A\u306B\u304A\u8A98\u3044\u3057\u307E\u3059\u3002",
  "id" : 372239550434652160,
  "in_reply_to_status_id" : 372237298433142784,
  "created_at" : "2013-08-27 06:09:59 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/HFifBvEvMD",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=shi_sshi",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372237190945714176",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/HFifBvEvMD",
  "id" : 372237190945714176,
  "created_at" : "2013-08-27 06:00:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    }, {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 10, 20 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370506687293046785",
  "geo" : { },
  "id_str" : "372235912488312832",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma @piano2683 \u660E\u65E5\u306E\u591C\u3068\u304B\u6687\u3058\u3083\u3042\u308A\u307E\u305B\u3093\u304B\uFF1F[\u65E5\u672C\u9152]",
  "id" : 372235912488312832,
  "in_reply_to_status_id" : 370506687293046785,
  "created_at" : "2013-08-27 05:55:32 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372069107375427584",
  "text" : "\u4E45\u3005\u306B\u826F\u304F\u904A\u3093\u3060\u3002\u5C11\u3057\u306F\u6C17\u304C\u7D1B\u308C\u305F\u304B\u306A\u3002",
  "id" : 372069107375427584,
  "created_at" : "2013-08-26 18:52:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371904510202892288",
  "geo" : { },
  "id_str" : "371905075347595264",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u305D\u3046\u3060\u306D\u3001\u304A\u3086\u306F\u3093\u306F\u591A\u5206\u98DF\u3079\u3066\u96C6\u307E\u308B\u611F\u3058\u300219:30\u3068\u304B\u3058\u3083\u65E9\u3044\u304B\u306A[\u5FD9\u3057\u3044\u3088\u3046\u306A\u3089\u4ED6\u3082\u3042\u305F\u3063\u3066\u307F\u307E\u3059\u3051\u308C\u3069]",
  "id" : 371905075347595264,
  "in_reply_to_status_id" : 371904510202892288,
  "created_at" : "2013-08-26 08:00:54 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371904282666102784",
  "geo" : { },
  "id_str" : "371904343479316480",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u6642\u9593\u3069\u3093\u306A\u3082\u3093\u304B\u306A",
  "id" : 371904343479316480,
  "in_reply_to_status_id" : 371904282666102784,
  "created_at" : "2013-08-26 07:57:59 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371904134271610880",
  "geo" : { },
  "id_str" : "371904166072827904",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u3044\u3048\u3059",
  "id" : 371904166072827904,
  "in_reply_to_status_id" : 371904134271610880,
  "created_at" : "2013-08-26 07:57:17 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371903689255956481",
  "geo" : { },
  "id_str" : "371903947927080960",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u3044\u3084\u307E\u3041\u30E1\u30F3\u30C4\u304C\u8DB3\u308A\u306A\u304F\u3066\u3067\u3059\u306D(",
  "id" : 371903947927080960,
  "in_reply_to_status_id" : 371903689255956481,
  "created_at" : "2013-08-26 07:56:25 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371894689101660160",
  "geo" : { },
  "id_str" : "371903585841188864",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u6687\u3060\u3063\u305F\u308A\u3057\u307E\u305B\u3093\u304B",
  "id" : 371903585841188864,
  "in_reply_to_status_id" : 371894689101660160,
  "created_at" : "2013-08-26 07:54:59 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371898947213611008",
  "text" : "4\u4EBA\u76EE\u304C\u63C3\u308F\u306A\u3044\u2026",
  "id" : 371898947213611008,
  "created_at" : "2013-08-26 07:36:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371799431818919938",
  "text" : "\u3042\u3063\u3042\u3063",
  "id" : 371799431818919938,
  "created_at" : "2013-08-26 01:01:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371798819928678401",
  "text" : "@kotorin_phoenix \u7D42\u308F\u3063\u305F\u306E\u306F\u4E00\u6B21\u306E\u767A\u8868\u3060\u3051\u3067\u3059[\u9762\u63A5\u306F\u4ECA\u65E5\u660E\u65E5\u660E\u5F8C\u65E5]",
  "id" : 371798819928678401,
  "created_at" : "2013-08-26 00:58:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371797689811210241",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u3001\u4E8C\u5EA6\u5BDD",
  "id" : 371797689811210241,
  "created_at" : "2013-08-26 00:54:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371793950522089474",
  "geo" : { },
  "id_str" : "371794319524384768",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 fmfm\u59CB\u3081\u308B\u306A\u308918:30\u3068\u304B19:00\u304B\u3089\u3067\u3059\u304B\u306D",
  "id" : 371794319524384768,
  "in_reply_to_status_id" : 371793950522089474,
  "created_at" : "2013-08-26 00:40:48 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371793472853794817",
  "geo" : { },
  "id_str" : "371793824390971392",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3061\u306A\u307F\u306B\u4F55\u6642\u3054\u308D\u304A\u5E30\u308A\u3067\uFF1F",
  "id" : 371793824390971392,
  "in_reply_to_status_id" : 371793472853794817,
  "created_at" : "2013-08-26 00:38:49 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371793472853794817",
  "geo" : { },
  "id_str" : "371793555099901952",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u4EBA\u3042\u3064\u307E\u308B\u304B\u306A(\u3044\u3084\u96C6\u3081\u307E\u3059\u3051\u308C\u3069)",
  "id" : 371793555099901952,
  "in_reply_to_status_id" : 371793472853794817,
  "created_at" : "2013-08-26 00:37:45 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371793310689423361",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u6687\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F",
  "id" : 371793310689423361,
  "created_at" : "2013-08-26 00:36:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371792885122740224",
  "text" : "\u7559\u5E74\u305D\u306E\u3082\u306E\u306B\u306F\u62B5\u6297\u306A\u3044\u304C\u89AA\u306B\u306F\u7533\u3057\u8A33\u306A\u3044\u3088\u306A\u20269",
  "id" : 371792885122740224,
  "created_at" : "2013-08-26 00:35:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371792777966657537",
  "text" : "\u3053\u308C\u7559\u5E74\u30EB\u30FC\u30C8\u5B9F\u969B\u3042\u308B\u6D41\u308C\u3060",
  "id" : 371792777966657537,
  "created_at" : "2013-08-26 00:34:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371792597800329217",
  "text" : "\"\u304A\u304A\u3044\u305F\"\u3067\u306F\u306A\u304F\"\u3060\u3044\u3076\"",
  "id" : 371792597800329217,
  "created_at" : "2013-08-26 00:33:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371792523217231874",
  "text" : "\u899A\u609F\u306F\u5927\u5206\u3057\u3066\u3044\u305F\u3051\u3069\u305D\u308C\u3067\u3082\u9662\u6B7B\u306F\u3064\u3089\u3044\u306A\uFF1F",
  "id" : 371792523217231874,
  "created_at" : "2013-08-26 00:33:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371781905844150272",
  "geo" : { },
  "id_str" : "371782037981499392",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u5C65\u4FEE\u3057\u3066\u306A\u304D\u3083\u306A\u3093\u3082\u306A\u3044\u3088[\u79C1\u3082\u3067\u3059]",
  "id" : 371782037981499392,
  "in_reply_to_status_id" : 371781905844150272,
  "created_at" : "2013-08-25 23:51:59 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371781885921226752",
  "text" : "\u305F\u3001\u5358\u4F4D\u3068\u304B\u3069\u3046\u3084\u3063\u3066\u3082\u53D6\u308C\u308B\u3088(",
  "id" : 371781885921226752,
  "created_at" : "2013-08-25 23:51:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371779750039019520",
  "text" : "\u3042\u306E\u65E5\u307F\u305F\u30D5\u30EB\u5358\u5831\u544A\u306E\u30C1\u30E9\u88CF\u611F\u3092\u50D5\u305F\u3061\u306F\u307E\u3060\u77E5\u3089\u306A\u3044",
  "id" : 371779750039019520,
  "created_at" : "2013-08-25 23:42:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371778821046812672",
  "text" : "S\u81EA\u306B\u3064\u3089\u307F\u3068\u6B7B\u306B\u305F\u307F\u3092\u8CAF\u3081\u3066\u7F6E\u3044\u305F\u306E\u3067\u3054\u6D3B\u7528\u4E0B\u3055\u3044",
  "id" : 371778821046812672,
  "created_at" : "2013-08-25 23:39:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371778707645419520",
  "text" : "\u3069\u3046\u3060\uFF01\uFF33\u81EA\u306B\"\u3064\u3089\u307F\"\u304C\u6E9C\u307E\u3063\u3066\u6765\u305F\u3060\u308D\u3046\uFF01[\u9662\u8A66\u5F8C\u306E\u7B54\u3048\u5408\u308F\u305B]",
  "id" : 371778707645419520,
  "created_at" : "2013-08-25 23:38:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "owarin",
      "screen_name" : "ls9mk",
      "indices" : [ 0, 6 ],
      "id_str" : "567896882",
      "id" : 567896882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371772391484973056",
  "geo" : { },
  "id_str" : "371778387246731264",
  "in_reply_to_user_id" : 567896882,
  "text" : "@ls9mk (\u3082\u306E\u306B\u3088\u3063\u3066\u306F\u30EC\u30DD\u30FC\u30C8\u3060\u3051\u9069\u5F53\u306B\u51FA\u305B\u3070\u5358\u4F4D\u964D\u3063\u3066\u6765\u308B\u3088)",
  "id" : 371778387246731264,
  "in_reply_to_status_id" : 371772391484973056,
  "created_at" : "2013-08-25 23:37:29 +0000",
  "in_reply_to_screen_name" : "ls9mk",
  "in_reply_to_user_id_str" : "567896882",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "owarin",
      "screen_name" : "ls9mk",
      "indices" : [ 0, 6 ],
      "id_str" : "567896882",
      "id" : 567896882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371772134260871169",
  "geo" : { },
  "id_str" : "371772235477815296",
  "in_reply_to_user_id" : 567896882,
  "text" : "@ls9mk \u305D\u308C\u306A\u2026[\u901A\u5E74\u79D1\u76EE\u306E\u5384\u4ECB\u611F]",
  "id" : 371772235477815296,
  "in_reply_to_status_id" : 371772134260871169,
  "created_at" : "2013-08-25 23:13:02 +0000",
  "in_reply_to_screen_name" : "ls9mk",
  "in_reply_to_user_id_str" : "567896882",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "owarin",
      "screen_name" : "ls9mk",
      "indices" : [ 0, 6 ],
      "id_str" : "567896882",
      "id" : 567896882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371771807767883776",
  "geo" : { },
  "id_str" : "371771989221859328",
  "in_reply_to_user_id" : 567896882,
  "text" : "@ls9mk \u307E\u3041\u6BCE\u5E74\u305D\u3093\u306A\u3093(\u3057\u308D\u3081",
  "id" : 371771989221859328,
  "in_reply_to_status_id" : 371771807767883776,
  "created_at" : "2013-08-25 23:12:04 +0000",
  "in_reply_to_screen_name" : "ls9mk",
  "in_reply_to_user_id_str" : "567896882",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "owarin",
      "screen_name" : "ls9mk",
      "indices" : [ 0, 6 ],
      "id_str" : "567896882",
      "id" : 567896882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371771219856482304",
  "geo" : { },
  "id_str" : "371771308171730945",
  "in_reply_to_user_id" : 567896882,
  "text" : "@ls9mk 9\/26\u3068\u304B\u305D\u3093\u306A\u3093",
  "id" : 371771308171730945,
  "in_reply_to_status_id" : 371771219856482304,
  "created_at" : "2013-08-25 23:09:21 +0000",
  "in_reply_to_screen_name" : "ls9mk",
  "in_reply_to_user_id_str" : "567896882",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371656264842874880",
  "geo" : { },
  "id_str" : "371662804551352320",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u30B3\u30F3\u30BF\u30AF\u30C8\u3068\u3063\u3066\u898B\u307E\u3059\u3042\u308A\u304C\u3068\u3046",
  "id" : 371662804551352320,
  "in_reply_to_status_id" : 371656264842874880,
  "created_at" : "2013-08-25 15:58:12 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371655371347079168",
  "geo" : { },
  "id_str" : "371655838080831488",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u307E\u3041\u5927\u62B5\u50D5\u304C\u3044\u308B\u3068\u306F\u601D\u3046\u3051\u3069\u306D\u30FC",
  "id" : 371655838080831488,
  "in_reply_to_status_id" : 371655371347079168,
  "created_at" : "2013-08-25 15:30:31 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371655498191220737",
  "geo" : { },
  "id_str" : "371655751304896512",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u3044\u3084\u3001\u3084\u308A\u306A\u3044\u3053\u3068\u3042\u308B\u306A\u3089\u3042\u308B\u7A0B\u5EA6\u3044\u3066\u3082\u3089\u3046\u3053\u3068\u306B\u306A\u308B\u3060\u308D\u3046\u3057\u3001\u591A\u3044\u306B\u8D8A\u3057\u305F\u3053\u3068\u306F\u306A\u3044(\u3076\u3063\u3061\u3083\u3051\u7533\u8ACB\u3060\u3051\u306A\u30892\u4EBA\u3068\u304B\u3067\u3082\u3067\u304D\u308B)",
  "id" : 371655751304896512,
  "in_reply_to_status_id" : 371655498191220737,
  "created_at" : "2013-08-25 15:30:10 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371651343900884992",
  "geo" : { },
  "id_str" : "371654859524542465",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u4EBA\u6570\u305D\u306E\u3082\u306E\u306F\u96C6\u307E\u3063\u3066\u307E\u3059\u304C\u904B\u55B6(\u5E97\u756A\uFF1F)\u3067\u304D\u308B\u4EBA\u306F\u3082\u3046\u5C11\u3057\u3044\u3066\u3082\u3044\u3044\u304B\u306A\u30FC\u3068\u3044\u3046\u611F\u3058\u3067\u3059",
  "id" : 371654859524542465,
  "in_reply_to_status_id" : 371651343900884992,
  "created_at" : "2013-08-25 15:26:38 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371650576825581568",
  "geo" : { },
  "id_str" : "371651069668909057",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u3044\u3089\u306A\u3044\u3088\u3093\u3002\u5FF5\u306E\u305F\u3081\u3060\u3051\u3069\u4ED6\u306E\u4F01\u753B\u306B\u540D\u524D\u3060\u3057\u305F\u308A\u3057\u3066\u308B\uFF1F\u88AB\u308B\u3068\u30DE\u30BA\u30A4\u3089\u3057\u3044\u3093\u3060\u3051\u3069\u3002",
  "id" : 371651069668909057,
  "in_reply_to_status_id" : 371650576825581568,
  "created_at" : "2013-08-25 15:11:34 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371644323432890368",
  "geo" : { },
  "id_str" : "371649777940713474",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 \u3044\u3044\u3088\u30FC\u3001\u540D\u524D\u3068\u5B66\u7C4D\u756A\u53F7\u3060\u3051DM\u4E0B\u3055\u3044\u30FC",
  "id" : 371649777940713474,
  "in_reply_to_status_id" : 371644323432890368,
  "created_at" : "2013-08-25 15:06:26 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371602953167044609",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 371602953167044609,
  "created_at" : "2013-08-25 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371541347187974144",
  "text" : "\u51B7\u8535\u5EAB\u58CA\u308C\u3066\u308B\u3057\u30D6\u30ED\u30FC\u30AF\u30F3\u51B7\u8535\u5EAB\u6B4C\u304A\u3046\u304B\u3068\u601D\u3063\u305F\u304C\u4F1D\u308F\u308A\u306B\u304F\u3044\u3057\u3084\u3081\u3088\u3046",
  "id" : 371541347187974144,
  "created_at" : "2013-08-25 07:55:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371536082388516864",
  "text" : "\"hogehoge\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\"hogehoge\u3092\u53E9\u304D\u305F\u3044\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\"hogehoge\u3092\u53E9\u304D\u305F\u3044\u3092\u53E9\u304D\u305F\u3044\u4EBA\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\"hogehoge\u3092\u53E9\u304D\u305F\u3044\u3092\u53E9\u304D\u305F\u3044\u4EBA\u3092\u53E9\u304D\u305F\u3044\u4EBA\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\u2026\nhogehoge\u306B\u597D\u304D\u306A\u3082\u306E\u3092\u5165\u308C\u3066\u541B\u3060\u3051\u306E(ry",
  "id" : 371536082388516864,
  "created_at" : "2013-08-25 07:34:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371535884572557312",
  "text" : "\"24\u6642\u9593\u30C6\u30EC\u30D3\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\"24\u6642\u9593\u30C6\u30EC\u30D3\u3092\u53E9\u304D\u305F\u3044\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\"24\u6642\u9593\u30C6\u30EC\u30D3\u3092\u53E9\u304D\u305F\u3044\u4EBA\u53E9\u304D\u305F\u3044\u4EBA\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\"24\u6642\u9593\u30C6\u30EC\u30D3\u3092\u53E9\u304D\u305F\u3044\u3092\u53E9\u304D\u305F\u3044\u4EBA\u3092\u53E9\u304D\u305F\u3044\u4EBA\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\u2026",
  "id" : 371535884572557312,
  "created_at" : "2013-08-25 07:33:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371513134487310336",
  "text" : "\u30A9\u30A9\u30A1\u30A9\u30A9\u30A1\u30F3",
  "id" : 371513134487310336,
  "created_at" : "2013-08-25 06:03:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasuhitoakita",
      "screen_name" : "yasuhitoakita",
      "indices" : [ 0, 14 ],
      "id_str" : "205210585",
      "id" : 205210585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371511144910827520",
  "geo" : { },
  "id_str" : "371511471441596416",
  "in_reply_to_user_id" : 205210585,
  "text" : "@yasuhitoakita \u3053\u306Ehogehoge\u306F\u98DF\u3079\u3089\u308C\u306A\u3044\u3088\u3002\u301C\u660E\u65E5\u307E\u305F\u3053\u3053\u306B\u6765\u3066\u4E0B\u3055\u3044\u3082\u3063\u3068\u3046\u307E\u3044hogehoge\u3092\u98DF\u3079\u3055\u305B\u3066\u3084\u308A\u307E\u3059\u3088\u3001\u306E\u30A4\u30E1\u30FC\u30B8\u3067\u3059\u306D",
  "id" : 371511471441596416,
  "in_reply_to_status_id" : 371511144910827520,
  "created_at" : "2013-08-25 05:56:51 +0000",
  "in_reply_to_screen_name" : "yasuhitoakita",
  "in_reply_to_user_id_str" : "205210585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371510752651116544",
  "text" : "\u5317\u5927\u8DEF\u306A\u3093\u305F\u3089\u3055\u3093\u304B",
  "id" : 371510752651116544,
  "created_at" : "2013-08-25 05:54:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasuhitoakita",
      "screen_name" : "yasuhitoakita",
      "indices" : [ 3, 17 ],
      "id_str" : "205210585",
      "id" : 205210585
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 19, 29 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/z4g7rFQSeM",
      "expanded_url" : "http:\/\/www.aozora.gr.jp\/cards\/001403\/files\/54947_48516.html",
      "display_url" : "aozora.gr.jp\/cards\/001403\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371510683805827072",
  "text" : "RT @yasuhitoakita: @end313124 \u4EAC\u90FD\u306E\u4F1D\u7D71\u7684\u306A\u590F\u306E\u98DF\u3044\u7269\u3089\u3057\u3044\u3063\u3059\u3088\nhttp:\/\/t.co\/z4g7rFQSeM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/z4g7rFQSeM",
        "expanded_url" : "http:\/\/www.aozora.gr.jp\/cards\/001403\/files\/54947_48516.html",
        "display_url" : "aozora.gr.jp\/cards\/001403\/f\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "371509234715738112",
    "geo" : { },
    "id_str" : "371510169940660225",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u4EAC\u90FD\u306E\u4F1D\u7D71\u7684\u306A\u590F\u306E\u98DF\u3044\u7269\u3089\u3057\u3044\u3063\u3059\u3088\nhttp:\/\/t.co\/z4g7rFQSeM",
    "id" : 371510169940660225,
    "in_reply_to_status_id" : 371509234715738112,
    "created_at" : "2013-08-25 05:51:41 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "yasuhitoakita",
      "screen_name" : "yasuhitoakita",
      "protected" : false,
      "id_str" : "205210585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548519086599049216\/-RHktmFq_normal.jpeg",
      "id" : 205210585,
      "verified" : false
    }
  },
  "id" : 371510683805827072,
  "created_at" : "2013-08-25 05:53:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasuhitoakita",
      "screen_name" : "yasuhitoakita",
      "indices" : [ 0, 14 ],
      "id_str" : "205210585",
      "id" : 205210585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371510169940660225",
  "geo" : { },
  "id_str" : "371510464426950656",
  "in_reply_to_user_id" : 205210585,
  "text" : "@yasuhitoakita \u3078\u3047\u2026",
  "id" : 371510464426950656,
  "in_reply_to_status_id" : 371510169940660225,
  "created_at" : "2013-08-25 05:52:51 +0000",
  "in_reply_to_screen_name" : "yasuhitoakita",
  "in_reply_to_user_id_str" : "205210585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasuhitoakita",
      "screen_name" : "yasuhitoakita",
      "indices" : [ 0, 14 ],
      "id_str" : "205210585",
      "id" : 205210585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371503509151023104",
  "geo" : { },
  "id_str" : "371509234715738112",
  "in_reply_to_user_id" : 205210585,
  "text" : "@yasuhitoakita \u540D\u524D\u304C\u3042\u308B\u306E\u306F\u77E5\u308A\u307E\u305B\u3093\u3067\u3057\u305F\uFF01",
  "id" : 371509234715738112,
  "in_reply_to_status_id" : 371503509151023104,
  "created_at" : "2013-08-25 05:47:58 +0000",
  "in_reply_to_screen_name" : "yasuhitoakita",
  "in_reply_to_user_id_str" : "205210585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371502997320126464",
  "geo" : { },
  "id_str" : "371509156391292929",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 \u304B\u3089\u304F\u306A\u3044\u3067\u3059\u306D\u30FC\u3001\u723D\u3084\u304B\u306A\u611F\u3058\u3067\u3059",
  "id" : 371509156391292929,
  "in_reply_to_status_id" : 371502997320126464,
  "created_at" : "2013-08-25 05:47:39 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371502853954613248",
  "text" : "\u64E6\u308A\u7ACB\u3066\u305F\u308F\u3055\u3073\u306B\u9C39\u7BC0\u6DF7\u305C\u3066\u91A4\u6CB9\u639B\u3051\u3066\u3054\u98EF\u3068\u98DF\u3079\u308B\u3068\u7F8E\u5473\u3057\u3044",
  "id" : 371502853954613248,
  "created_at" : "2013-08-25 05:22:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371502182014529536",
  "geo" : { },
  "id_str" : "371502681660993536",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 \u308F\u3055\u3073\u5B9F\u969B\u7F8E\u5473\u3057\u3044",
  "id" : 371502681660993536,
  "in_reply_to_status_id" : 371502182014529536,
  "created_at" : "2013-08-25 05:21:56 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371502018721882113",
  "text" : "\u89AA\u306E\u7530\u820Ewww",
  "id" : 371502018721882113,
  "created_at" : "2013-08-25 05:19:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u300C\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u300D TV\u30C9\u30E9\u30DE\u516C\u5F0F",
      "screen_name" : "tx_kodokugurume",
      "indices" : [ 3, 19 ],
      "id_str" : "462789515",
      "id" : 462789515
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tx_kodokugurume\/status\/371499910098456576\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/9P24OrBOF1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSfVMzBCEAE2rR-.jpg",
      "id_str" : "371499910111039489",
      "id" : 371499910111039489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSfVMzBCEAE2rR-.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1632
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9P24OrBOF1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371501917043580929",
  "text" : "RT @tx_kodokugurume: \u4ECA\u65E5\u3001\u5915\u65B9\uFF14\u6642\u300C\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\uFF33\uFF45\uFF41\uFF53\uFF4F\uFF4E\uFF13\u5091\u4F5C\u9078\u300D\u3067\u3059\uFF01 \u300C\u5317\u533A\u8D64\u7FBD\u306E\u307B\u308D\u307B\u308D\u9CE5\u3068\u3046\u306A\u4E3C\u300D\u300C\u9759\u5CA1\u770C\u8CC0\u8302\u90E1\u6CB3\u6D25\u753A\u306E\u751F\u30EF\u30B5\u30D3\u4ED8\u308F\u3055\u3073\u4E3C\u300D \u307E\u305F\u756A\u7D44\u4E2D\u306B\u304A\u77E5\u3089\u305B\u3082\u3042\u308A\u307E\u3059\u306E\u3067\u3001\u3057\u3063\u304B\u308A\u898B\u3066\u304F\u3060\u3055\u3044\u306D\uFF5E\u3000\u3053\u3093\u306A\u3068\u3053\u308D\u3067\u30ED\u30B1\u3057\u307E\u3057\u305F\u3002\u7652\u3055\u308C\u308B\u3002 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tx_kodokugurume\/status\/371499910098456576\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/9P24OrBOF1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSfVMzBCEAE2rR-.jpg",
        "id_str" : "371499910111039489",
        "id" : 371499910111039489,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSfVMzBCEAE2rR-.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9P24OrBOF1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371499910098456576",
    "text" : "\u4ECA\u65E5\u3001\u5915\u65B9\uFF14\u6642\u300C\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\uFF33\uFF45\uFF41\uFF53\uFF4F\uFF4E\uFF13\u5091\u4F5C\u9078\u300D\u3067\u3059\uFF01 \u300C\u5317\u533A\u8D64\u7FBD\u306E\u307B\u308D\u307B\u308D\u9CE5\u3068\u3046\u306A\u4E3C\u300D\u300C\u9759\u5CA1\u770C\u8CC0\u8302\u90E1\u6CB3\u6D25\u753A\u306E\u751F\u30EF\u30B5\u30D3\u4ED8\u308F\u3055\u3073\u4E3C\u300D \u307E\u305F\u756A\u7D44\u4E2D\u306B\u304A\u77E5\u3089\u305B\u3082\u3042\u308A\u307E\u3059\u306E\u3067\u3001\u3057\u3063\u304B\u308A\u898B\u3066\u304F\u3060\u3055\u3044\u306D\uFF5E\u3000\u3053\u3093\u306A\u3068\u3053\u308D\u3067\u30ED\u30B1\u3057\u307E\u3057\u305F\u3002\u7652\u3055\u308C\u308B\u3002 http:\/\/t.co\/9P24OrBOF1",
    "id" : 371499910098456576,
    "created_at" : "2013-08-25 05:10:56 +0000",
    "user" : {
      "name" : "\u300C\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u300D TV\u30C9\u30E9\u30DE\u516C\u5F0F",
      "screen_name" : "tx_kodokugurume",
      "protected" : false,
      "id_str" : "462789515",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1758677981\/_________normal.png",
      "id" : 462789515,
      "verified" : false
    }
  },
  "id" : 371501917043580929,
  "created_at" : "2013-08-25 05:18:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371467697650819074",
  "text" : "\u3042\u304D\u3081\u3044\u3066\u308B",
  "id" : 371467697650819074,
  "created_at" : "2013-08-25 03:02:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371466584360906752",
  "text" : "\u3058\u3083\u30FC\u3044",
  "id" : 371466584360906752,
  "created_at" : "2013-08-25 02:58:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371465705159266304",
  "text" : "\u8FD1\u5834\u306B\u306F",
  "id" : 371465705159266304,
  "created_at" : "2013-08-25 02:55:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371465677686599680",
  "text" : "\u3060\u3044\u305F\u3044\u4EAC\u90FD\u306B\u30D0\u30FC\u30D9\u30AD\u30E5\u30FC\u51FA\u6765\u308B\u3068\u3053\u3068\u304B\u3042\u3093\u306E\u304B(\u3044\u3084\u3001\u306A\u3044)",
  "id" : 371465677686599680,
  "created_at" : "2013-08-25 02:54:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305D\u3059\u3046\u307D\u3088",
      "screen_name" : "_primenumber",
      "indices" : [ 0, 13 ],
      "id_str" : "86075525",
      "id" : 86075525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371464217573879809",
  "geo" : { },
  "id_str" : "371464391268372481",
  "in_reply_to_user_id" : 86075525,
  "text" : "@_primenumber \u3048\u3093\u3069\u6C0F\u304C\u4F01\u753B\u3059\u308B\u306E\u306F\u305B\u3044\u305C\u3044\u30B9\u30DE\u30D6\u30E9\u3068\u304B\u9EBB\u96C0\u3068\u304B\u3067\u3059\u3088",
  "id" : 371464391268372481,
  "in_reply_to_status_id" : 371464217573879809,
  "created_at" : "2013-08-25 02:49:47 +0000",
  "in_reply_to_screen_name" : "_primenumber",
  "in_reply_to_user_id_str" : "86075525",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF8F\uFF72\uFF79\uFF99",
      "screen_name" : "beyond_mb",
      "indices" : [ 0, 10 ],
      "id_str" : "1649884393",
      "id" : 1649884393
    }, {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 11, 23 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371463994734698497",
  "geo" : { },
  "id_str" : "371464237966561280",
  "in_reply_to_user_id" : 1649884393,
  "text" : "@beyond_mb @modestrella 3\u65E5\u306B\u306F\u884C\u304F\u307E\u3059",
  "id" : 371464237966561280,
  "in_reply_to_status_id" : 371463994734698497,
  "created_at" : "2013-08-25 02:49:10 +0000",
  "in_reply_to_screen_name" : "beyond_mb",
  "in_reply_to_user_id_str" : "1649884393",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371463972542623744",
  "text" : "\u304B\u305A\u30FC\u6C0F\u30D0\u30FC\u30D9\u30AD\u30E5\u30FC\u3044\u3044\u306A\u30FC\u305F\u306E\u3057\u305D\u3046\u3060\u306A\u30FC",
  "id" : 371463972542623744,
  "created_at" : "2013-08-25 02:48:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371413383158849536",
  "text" : "\u30EC\u30D6\u30ED\u30C9\u30FC\u30EB\u306E\u30D1\u30F3\u304C\u7F8E\u5473\u3057\u304F\u3066",
  "id" : 371413383158849536,
  "created_at" : "2013-08-24 23:27:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371394721198792704",
  "text" : "@kotorin_phoenix \u304A\u306F\u3074\u3088\uFF01\u3067\u3059\uFF01",
  "id" : 371394721198792704,
  "created_at" : "2013-08-24 22:12:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371393462697861122",
  "text" : "\u7720\u3044 of the world",
  "id" : 371393462697861122,
  "created_at" : "2013-08-24 22:07:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371251395405414400",
  "text" : "\u6B7B\u3093\u3060\u3089\u6570\u5B66\u8005\u306B\u306A\u308B",
  "id" : 371251395405414400,
  "created_at" : "2013-08-24 12:43:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 17, 28 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371251067058544641",
  "geo" : { },
  "id_str" : "371251302644215808",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank @haguruma20 \u591C\u306A\u3089[\u88AB\u3063\u305F]",
  "id" : 371251302644215808,
  "in_reply_to_status_id" : 371251067058544641,
  "created_at" : "2013-08-24 12:43:02 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371250618838417408",
  "text" : "@kotorin_phoenix \u5FA1\u671F\u5F85\u306B\u6DFB\u3048\u305A\u3059\u307F\u307E\u305B\u3093(?)",
  "id" : 371250618838417408,
  "created_at" : "2013-08-24 12:40:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 12, 28 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371249247850487809",
  "geo" : { },
  "id_str" : "371250438462402560",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 @Jelly_in_a_tank 27\u3042\u305F\u308A\u306B\u30CF\u30E0\u3084\u3089\u30BD\u30FC\u30BB\u30FC\u30B8\u3084\u3089\u5C4A\u304F\u306E\u3067\u51B7\u8535\u5EAB\u8CB8\u3057\u3066\u4E0B\u3055\u3044(\u61C7\u9858)",
  "id" : 371250438462402560,
  "in_reply_to_status_id" : 371249247850487809,
  "created_at" : "2013-08-24 12:39:36 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371250139525951488",
  "text" : "\u7537\u306E\u5A18\u6587\u5316\u3001\u7406\u89E3\u306F\u51FA\u6765\u308B\u3051\u3069\u5171\u611F\u306F\u51FA\u6765\u306A\u3044",
  "id" : 371250139525951488,
  "created_at" : "2013-08-24 12:38:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371249953139482624",
  "text" : "@kotorin_phoenix \u3044\u3084\u7121\u7406\u3067\u3059(\u771F\u9854",
  "id" : 371249953139482624,
  "created_at" : "2013-08-24 12:37:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371247638563143680",
  "text" : "@kotorin_phoenix \u3067\u3059\u306A\u30FC\u3002\u5207\u306B\u305D\u3046\u601D\u3044\u307E\u3059\u3002",
  "id" : 371247638563143680,
  "created_at" : "2013-08-24 12:28:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371247464180748289",
  "text" : "\u307E\u3041\u50D5\u3082\u5E38\u306B\u30B1\u30ED\u3063\u3068\u3057\u3066\u307E\u3059\u3051\u3069\u306D(\u30AB\u30A8\u30EB\u3067\u306F\u306A\u3044)",
  "id" : 371247464180748289,
  "created_at" : "2013-08-24 12:27:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371247003306426369",
  "text" : "\u81EA\u696D\u81EA\u5F97\u3001\u8EAB\u304B\u3089\u51FA\u305F\u9306\u3063\u3066\u308F\u304B\u3063\u3066\u308B\u304B\u3089\u306A\u304A\u3064\u3089\u307F",
  "id" : 371247003306426369,
  "created_at" : "2013-08-24 12:25:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371246889636601856",
  "text" : "@kotorin_phoenix \u3064\u3089\u307F\u306F\u81EA\u5206\u304B\u3089\u3001\u6E9C\u3081\u8FBC\u307F\u307E\u305B\u3093\u3088\u3046[\u30D6\u30FC\u30E1\u30E9\u30F3]",
  "id" : 371246889636601856,
  "created_at" : "2013-08-24 12:25:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6D45\u672C\u30C0\u30B5\u5E73",
      "screen_name" : "fuckn15",
      "indices" : [ 0, 8 ],
      "id_str" : "353598147",
      "id" : 353598147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371246268426620928",
  "geo" : { },
  "id_str" : "371246518553948160",
  "in_reply_to_user_id" : 353598147,
  "text" : "@fuckn15 \u306A\u3093\u304B\u3082\u3046\u6700\u8FD1\u306A\u3093\u3067\u3082\u3042\u308A\u3060\u3082\u3093\u306A[\u3042\u308C\u306F\u3044\u3063\u305F\u3089\u51FA\u308C\u306A\u305D\u3046]",
  "id" : 371246518553948160,
  "in_reply_to_status_id" : 371246268426620928,
  "created_at" : "2013-08-24 12:24:02 +0000",
  "in_reply_to_screen_name" : "fuckn15",
  "in_reply_to_user_id_str" : "353598147",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371245682394279936",
  "text" : "\u30B3\u30A4\u30F3\u30E9\u30F3\u30C9\u30EA\u30FC\u3067\u3082\u3044\u3044",
  "id" : 371245682394279936,
  "created_at" : "2013-08-24 12:20:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371245651327057921",
  "text" : "\u30C9\u30E9\u30A4\u30E4\u30FC\u639B\u3051\u3066\u3066\u6C17\u6301\u3061\u826F\u3044\u306A\u3041\u3068\u601D\u3063\u305F\u3093\u3060\u3051\u3069\u3001\u30AC\u30BD\u30EA\u30F3\u30B9\u30BF\u30F3\u30C9\u306E\u30D0\u30AB\u5E97\u54E1\u304C\u6D17\u8ECA\u306E\u30A2\u30EC\u306B\u5165\u3063\u3061\u3083\u3046\u4E0D\u7965\u4E8B\u306F\u307E\u3060\u8D77\u304D\u3066\u306A\u3044\u306E\uFF1F",
  "id" : 371245651327057921,
  "created_at" : "2013-08-24 12:20:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371243738237898755",
  "text" : "\u300C\u30AB\u30F3\u30D1\u30FC\u30A4\uFF01\u300D\u3068\u304B\u3063\u3066\u5727\u529B\u304B\u3051\u3089\u308C\u305F\u3089\u305D\u306E\u307E\u307E\u98F2\u307F\u7269\u3092\u76F8\u624B\u306B\u304B\u3051\u304B\u306D\u306A\u3044\u306E\u3067\u50D5\u306B\u304A\u9152\u3092\u5F37\u8981\u3059\u308B\u306E\u306F\u3084\u3081\u307E\u3057\u3087\u3046[\u7121\u8AD6\u50D5\u3082\u5F37\u8981\u3057\u306A\u3044]",
  "id" : 371243738237898755,
  "created_at" : "2013-08-24 12:12:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371240606179131394",
  "text" : "\u98DF\u3079\u7269\u3041",
  "id" : 371240606179131394,
  "created_at" : "2013-08-24 12:00:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371240599166271488",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 371240599166271488,
  "created_at" : "2013-08-24 12:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371240515359895552",
  "text" : "\u30EF\u30A4\u30F3\u306F\u7518\u3044\u306E\u306E\u65B9\u304C\u597D\u304D\u3001\u5473\u899A\u304C\u5B50\u3069\u3082\u3081\u3044\u3066\u308B\u304B\u3089",
  "id" : 371240515359895552,
  "created_at" : "2013-08-24 12:00:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371240160630824960",
  "text" : "\u25CB\u25CB\u306B\u541B\u3060\u3051\u306E\u98DF\u3079\u7269\u3092\u5165\u308C\u3066\u541B\u3060\u3051\u306E\u53C2\u8003\u306B\u306A\u308B\u6587\u3092\u4F5C\u308D\u3046\uFF01",
  "id" : 371240160630824960,
  "created_at" : "2013-08-24 11:58:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371240132638015488",
  "text" : "\u7F8E\u5473\u3044\u25CB\u25CB\u306F\u7F8E\u5473\u3044\u3057\u4E0D\u5473\u3044\u25CB\u25CB\u306F\u4E0D\u5473\u3044",
  "id" : 371240132638015488,
  "created_at" : "2013-08-24 11:58:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371239775665004545",
  "text" : "\u3061\u304C\u3046\u3001\u4E00\u6BB5\u843D\u3057\u3066\u3044\u308B\u3068\u3053\u308D\u3060\u3002",
  "id" : 371239775665004545,
  "created_at" : "2013-08-24 11:57:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371239722837741568",
  "text" : "\u5352\u8AD6\u304C\u4E00\u6BB5\u843D\u3057\u304B\u304B\u3051\u3066\u3044\u306A\u3044\u9803\u3060",
  "id" : 371239722837741568,
  "created_at" : "2013-08-24 11:57:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371239627497025536",
  "text" : "@Kyo_Hiiragi \u5E74\u660E\u3051\u304B\uFF01\u305D\u306E\u3042\u305F\u308A\u306A\u3093\u304B\u98F2\u307F\u307E\u3057\u3087\u3046\u3002",
  "id" : 371239627497025536,
  "created_at" : "2013-08-24 11:56:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371239279587901440",
  "text" : "@Kyo_Hiiragi \u3044\u3064\u30CF\u30BF\u30C1\u306B\u306A\u308B\u306E\uFF1F",
  "id" : 371239279587901440,
  "created_at" : "2013-08-24 11:55:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371239016735055872",
  "text" : "\u65E5\u672C\u9152\u30C0\u30E1\u306A\u3082\u306E\u306F\u672C\u5F53\u306B\u30C0\u30E1\u3060\u304B\u3089\u30C0\u30E1",
  "id" : 371239016735055872,
  "created_at" : "2013-08-24 11:54:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371238914935107584",
  "text" : "@Kyo_Hiiragi \u3046\u307E\u3044\u65E5\u672C\u9152\u306F\u7F8E\u5473\u3044\u3057\u307E\u305A\u3044\u65E5\u672C\u9152\u306F\u5B9F\u969B\u307E\u305A\u3044",
  "id" : 371238914935107584,
  "created_at" : "2013-08-24 11:53:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371238676577009666",
  "text" : "\u306A\u304A\u837B\u7AAA\u306E\"\u6700\u4E0A\u968E\"\u306A\u308B\u5C45\u9152\u5C4B\u3055\u3093\u3067\u9802\u3044\u305F\u6A21\u69D8[\u30C9\u30A4\u30C4\u5C4B\u53F0\u98A8\u30BD\u30FC\u30BB\u30FC\u30B8][\u305D\u3053\u304B\u3089\u5F92\u6B695\u5206\u3067\u3086\u3086\u5F0F\u4E00\u8A71\u306E\u304A\u56E3\u5B50\u5C4B\u3055\u3093\u306E\u30E2\u30C7\u30EB\u304C\u3042\u3063\u305F\u306A\u3069]",
  "id" : 371238676577009666,
  "created_at" : "2013-08-24 11:52:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371238384083034112",
  "text" : "\u306A\u305C\u304B\"kinds of\u3050\u308B\u3050\u308B\u30BD\u30FC\u30BB\u30FC\u30B8\"\u306B\u8A00\u53CA\u3059\u308B\u4EBA\u591A\u3057",
  "id" : 371238384083034112,
  "created_at" : "2013-08-24 11:51:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5408\u540C\u635C\u67FB\u672C\u90E8",
      "screen_name" : "Gityo_san",
      "indices" : [ 3, 13 ],
      "id_str" : "600605098",
      "id" : 600605098
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Gityo_san\/status\/371237702785458176\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/6bDYWm1YYK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSbmuUoCYAAJc8K.jpg",
      "id_str" : "371237702789652480",
      "id" : 371237702789652480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSbmuUoCYAAJc8K.jpg",
      "sizes" : [ {
        "h" : 534,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/6bDYWm1YYK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371238262511120385",
  "text" : "RT @Gityo_san: \u30C9\u30A4\u30C4\u5C4B\u53F0\u98A8\u30BD\u30FC\u30BB\u30FC\u30B8 http:\/\/t.co\/6bDYWm1YYK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Gityo_san\/status\/371237702785458176\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/6bDYWm1YYK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSbmuUoCYAAJc8K.jpg",
        "id_str" : "371237702789652480",
        "id" : 371237702789652480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSbmuUoCYAAJc8K.jpg",
        "sizes" : [ {
          "h" : 534,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/6bDYWm1YYK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371237702785458176",
    "text" : "\u30C9\u30A4\u30C4\u5C4B\u53F0\u98A8\u30BD\u30FC\u30BB\u30FC\u30B8 http:\/\/t.co\/6bDYWm1YYK",
    "id" : 371237702785458176,
    "created_at" : "2013-08-24 11:49:00 +0000",
    "user" : {
      "name" : "\u5408\u540C\u635C\u67FB\u672C\u90E8",
      "screen_name" : "Gityo_san",
      "protected" : false,
      "id_str" : "600605098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463376146696921088\/myCOcBio_normal.png",
      "id" : 600605098,
      "verified" : false
    }
  },
  "id" : 371238262511120385,
  "created_at" : "2013-08-24 11:51:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371238013092638720",
  "text" : "\u3050\u308B\u3050\u308B\u30BD\u30FC\u30BB\u30FC\u30B8\u7F8E\u5473\u3057\u304B\u3063\u305F\u3001\u305A\u3044\u3076\u3093\u524D\u3060\u306A\u98DF\u3079\u305F\u306E",
  "id" : 371238013092638720,
  "created_at" : "2013-08-24 11:50:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u306A\u306E\u307E\u308B\/\u30EA\u30F3\u30AC\u6CCA\u5730\u3067\u3077\u304B\u3077\u304B",
      "screen_name" : "sinanomaru",
      "indices" : [ 3, 14 ],
      "id_str" : "71668658",
      "id" : 71668658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/KiDPm1fkSj",
      "expanded_url" : "http:\/\/www.garbagenews.net\/archives\/1138987.html",
      "display_url" : "garbagenews.net\/archives\/11389\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371237918167150592",
  "text" : "RT @sinanomaru: \u3053\u308C\u3067\u3044\u3093\u3058\u3083\u306D\uFF1Fhttp:\/\/t.co\/KiDPm1fkSj\uFF1E\u516C\u5F0F\uFF32\uFF34",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/KiDPm1fkSj",
        "expanded_url" : "http:\/\/www.garbagenews.net\/archives\/1138987.html",
        "display_url" : "garbagenews.net\/archives\/11389\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "371237633994657792",
    "text" : "\u3053\u308C\u3067\u3044\u3093\u3058\u3083\u306D\uFF1Fhttp:\/\/t.co\/KiDPm1fkSj\uFF1E\u516C\u5F0F\uFF32\uFF34",
    "id" : 371237633994657792,
    "created_at" : "2013-08-24 11:48:43 +0000",
    "user" : {
      "name" : "\u3057\u306A\u306E\u307E\u308B\/\u30EA\u30F3\u30AC\u6CCA\u5730\u3067\u3077\u304B\u3077\u304B",
      "screen_name" : "sinanomaru",
      "protected" : false,
      "id_str" : "71668658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238328178\/53eca894-e187-46fd-83d9-f73c4bd8836b_normal.png",
      "id" : 71668658,
      "verified" : false
    }
  },
  "id" : 371237918167150592,
  "created_at" : "2013-08-24 11:49:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u306A\u306E\u307E\u308B\/\u30EA\u30F3\u30AC\u6CCA\u5730\u3067\u3077\u304B\u3077\u304B",
      "screen_name" : "sinanomaru",
      "indices" : [ 0, 11 ],
      "id_str" : "71668658",
      "id" : 71668658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371237633994657792",
  "geo" : { },
  "id_str" : "371237897044643840",
  "in_reply_to_user_id" : 71668658,
  "text" : "@sinanomaru \u3053\u308C\u306F\u30D5\u30E9\u30A4\u30D1\u30F3\u3067\u8339\u3067\u713C\u304D\u306B\u3059\u308B\u3068\u7F8E\u5473\u3057\u3044\u3067\u3059",
  "id" : 371237897044643840,
  "in_reply_to_status_id" : 371237633994657792,
  "created_at" : "2013-08-24 11:49:46 +0000",
  "in_reply_to_screen_name" : "sinanomaru",
  "in_reply_to_user_id_str" : "71668658",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371237590407446528",
  "text" : "\u601D\u3063\u305F\u3088\u308ART\u3055\u308C\u3066\u3066\u4E0D\u601D\u8B70",
  "id" : 371237590407446528,
  "created_at" : "2013-08-24 11:48:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yasuhitoakita",
      "screen_name" : "yasuhitoakita",
      "indices" : [ 0, 14 ],
      "id_str" : "205210585",
      "id" : 205210585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371237347762782209",
  "geo" : { },
  "id_str" : "371237513051926528",
  "in_reply_to_user_id" : 205210585,
  "text" : "@yasuhitoakita \u58F0\u306B\u51FA\u3059\u3068\u30BF\u30A4\u611F\u3082\u3042\u3063\u3066\u591A\u56FD\u7C4D\u306A\u611F\u3058\u3057\u307E\u3059\u3088\u306D(?)",
  "id" : 371237513051926528,
  "in_reply_to_status_id" : 371237347762782209,
  "created_at" : "2013-08-24 11:48:15 +0000",
  "in_reply_to_screen_name" : "yasuhitoakita",
  "in_reply_to_user_id_str" : "205210585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371237232159383552",
  "text" : "\u77B3\u5B54\u306F\u958B\u304F\u3093\u3060\u3063\u3051",
  "id" : 371237232159383552,
  "created_at" : "2013-08-24 11:47:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371237163884486657",
  "text" : "\u76EE\u3082\u5F53\u3066\u3089\u308C\u306A\u3044\u3001\u76EE\u3082\u958B\u3051\u3089\u308C\u306A\u3044[\u6B7B]",
  "id" : 371237163884486657,
  "created_at" : "2013-08-24 11:46:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371236854613282817",
  "text" : "\u306A\u304A\u30C9\u30A4\u30C4\u5C4B\u53F0\u3092\u7D4C\u9A13\u3057\u305F\u3053\u3068\u306A\u3044\u306E\u3067\u30C9\u30A4\u30C4\u5C4B\u53F0\u611F\u3082\u3088\u304F\u308F\u304B\u3089\u306A\u304B\u3063\u305F\u6A21\u69D8",
  "id" : 371236854613282817,
  "created_at" : "2013-08-24 11:45:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371236775567437824",
  "text" : "\u30C9\u30A4\u30C4\u5C4B\u53F0\u98A8\u30BD\u30FC\u30BB\u30FC\u30B8\u3001\u53F0\u98A8\u611F\u304C\u307E\u308B\u3067\u306A\u304B\u3063\u305F\u3093\u3060\u3051\u3069\u30C9\u30A4\u30C4\u5C4B\u53F0\u3063\u307D\u3044\u3063\u3066\u3053\u3068\u3060\u3063\u305F\u3089\u3057\u3044",
  "id" : 371236775567437824,
  "created_at" : "2013-08-24 11:45:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371236462059995136",
  "text" : "\u697D\u3057\u3044\u304A\u98A8\u5442",
  "id" : 371236462059995136,
  "created_at" : "2013-08-24 11:44:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371233183661961217",
  "text" : "\u9EBB\u96C0\u3084\u308A\u305F\u3044\u304A\u5316\u3051\u306B\u884C\u304D\u906D\u3063\u305F\u306E\u306F,\u50D5\u3060\u3063\u305F\u306E\u304B...!(CV\u795E\u8C37\u6D69\u53F2)",
  "id" : 371233183661961217,
  "created_at" : "2013-08-24 11:31:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371232774583111680",
  "geo" : { },
  "id_str" : "371232958184570880",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3046\u304A\u304A\u304A\u304A\u304A",
  "id" : 371232958184570880,
  "in_reply_to_status_id" : 371232774583111680,
  "created_at" : "2013-08-24 11:30:09 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371232620312399874",
  "geo" : { },
  "id_str" : "371232663517949952",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3046\u3080\u30FC",
  "id" : 371232663517949952,
  "in_reply_to_status_id" : 371232620312399874,
  "created_at" : "2013-08-24 11:28:58 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371232276014571520",
  "geo" : { },
  "id_str" : "371232516226551808",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 (\u4E00\u6B21\u3067\u5207\u3089\u308C\u308B\u53EF\u80FD\u6027\u3055\u3048\u8996\u91CE)[\u7DDA\u5F62\u4EE3\u6570\u3057\u304B\u51FA\u6765\u306A\u3044\u4EBA\u751F\u3060\u3063\u305F]",
  "id" : 371232516226551808,
  "in_reply_to_status_id" : 371232276014571520,
  "created_at" : "2013-08-24 11:28:23 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371232087161847808",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u3001\u660E\u65E5\u306F\u6D88\u5316\u8A66\u5408\u3060\u3057\u71C3\u3048\u5C3D\u304D\u305F\u611F\u3058",
  "id" : 371232087161847808,
  "created_at" : "2013-08-24 11:26:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371231835008692224",
  "text" : "\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u8AAD\u3093\u3060\u3089\u53F3\u8155\u75B2\u308C\u305F\u3002\u8CA7\u5F31\u8CA7\u5F31\u3002",
  "id" : 371231835008692224,
  "created_at" : "2013-08-24 11:25:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371231266089078784",
  "text" : "\u3059\u3052\u30FC\u3075\u3093\u308F\u308A\u3057\u305F\u59CB\u307E\u308A\u65B9\u3057\u305F\u65B0\u9023\u8F09\u304C\u6025\u6FC0\u30B5\u30C4\u30D0\u30C4\u3057\u3066\u697D\u3057\u307F",
  "id" : 371231266089078784,
  "created_at" : "2013-08-24 11:23:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371230988480700416",
  "text" : "\u8A00\u306E\u8449\u306E\u5EAD\u3001\u826F\u3044\u96F0\u56F2\u6C17\u3060\u3001\u6765\u6708\u7D42\u308F\u308B\u3051\u3069\u3053\u308C\u306F\u6620\u50CF\u3067\u3082\u307F\u3066\u307F\u305F\u3044\u306A",
  "id" : 371230988480700416,
  "created_at" : "2013-08-24 11:22:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371062432984088576",
  "text" : "\u6709\u8C61\u7121\u8C61\u306E\u4EE3\u8868\u3068\u3057\u3066\u3082\u3060\u306A\u2026",
  "id" : 371062432984088576,
  "created_at" : "2013-08-24 00:12:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371056127573622784",
  "text" : "\u591C\u306B\u3084\u308B\u3079\u304D\u3060\u3063\u305F\u611F",
  "id" : 371056127573622784,
  "created_at" : "2013-08-23 23:47:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371055791798632448",
  "text" : "\u6052\u4F8B\u306E",
  "id" : 371055791798632448,
  "created_at" : "2013-08-23 23:46:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371055752183439360",
  "text" : "\u3044\u3088\u3044\u3088\u660E\u65E5\u304C\u9662\u8A66\u672C\u756A\u3067\u3059\u3088\uFF01 \n\n\u3080\u3063\u3061\u3083\u30C9\u30AD\u30C9\u30AD\u3057\u3066\u304D\u305F\u2026\u3002 \n\n\u53D7\u9A13\u751F\u306E\u7686\u3055\u3093\u3001\u4ECA\u65E5\u304F\u3089\u3044\u306F\u52C9\u5F37\u306F\u4F11\u3093\u3067\u660E\u65E5\u306B\u5099\u3048\u307E\u3059\u3088\u306D\uFF1F",
  "id" : 371055752183439360,
  "created_at" : "2013-08-23 23:45:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371031311277764608",
  "text" : "\u30D7\u30C3\u30C1\u30F3\u30D7\u30EA\u30F3\u3092\u30D7\u30C3\u30C1\u30F3\u3057\u306A\u3044\u3067\u98DF\u3079\u308B\u5974\u2026",
  "id" : 371031311277764608,
  "created_at" : "2013-08-23 22:08:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370885042592944128",
  "geo" : { },
  "id_str" : "370885219001192448",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u305D\u3046\u306A\u3093\u3067\u3059\u304B\u3001\u3067\u306F\u3084\u3081\u3066\u304A\u304D\u307E\u3057\u3087\u3046\u3002[\u30DC\u30C9\u30B2\u306E\u6642\u306B\u3044\u308D\u3044\u308D\u805E\u304D\u307E\u3059\u306D]",
  "id" : 370885219001192448,
  "in_reply_to_status_id" : 370885042592944128,
  "created_at" : "2013-08-23 12:28:21 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370884278990561280",
  "text" : "\u30B3\u30DB\u30E2\u30ED\u30B8\u30FC\u5927\u81E3\uFF1F",
  "id" : 370884278990561280,
  "created_at" : "2013-08-23 12:24:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370884234191175681",
  "text" : "RT @koizumi_fifty: \u30B3\u30DB\u30E2\u30ED\u30B8\u30FC\u4EBA\u9593\u304B\u3063\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370884157104062464",
    "text" : "\u30B3\u30DB\u30E2\u30ED\u30B8\u30FC\u4EBA\u9593\u304B\u3063\uFF01",
    "id" : 370884157104062464,
    "created_at" : "2013-08-23 12:24:08 +0000",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 370884234191175681,
  "created_at" : "2013-08-23 12:24:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370882830932267008",
  "text" : "\u925B\u7B46\u30AC\u30EA\u30AC\u30EA",
  "id" : 370882830932267008,
  "created_at" : "2013-08-23 12:18:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370881287143174144",
  "geo" : { },
  "id_str" : "370882507178135553",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma [\u88AB\u3063\u3066\u3082\u554F\u984C\u306A\u3044\u6C17\u3082\u3057\u307E\u3059\u304C]\u7121\u7406\u306B\u3068\u306F\u8A00\u3044\u307E\u3059\u307E\u3044",
  "id" : 370882507178135553,
  "in_reply_to_status_id" : 370881287143174144,
  "created_at" : "2013-08-23 12:17:35 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370880639878168576",
  "geo" : { },
  "id_str" : "370880924264587264",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u307E\u305F\u9023\u7D61\u3057\u307E\u3059\u3057",
  "id" : 370880924264587264,
  "in_reply_to_status_id" : 370880639878168576,
  "created_at" : "2013-08-23 12:11:17 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370880616046157824",
  "text" : "\u304F\u3089\u5BFF\u53F8\u30AA\u30D5\u884C\u3063\u3066\u307F\u305F\u304B\u3063\u305F",
  "id" : 370880616046157824,
  "created_at" : "2013-08-23 12:10:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370879924749352960",
  "text" : "\u306E\u306A\u3061\u3083\u3093\u3075\u3041\u307C\u3063\u3066\u306A\u3044\u3066\u540D\u524D\u8CB8\u305D\u3046()",
  "id" : 370879924749352960,
  "created_at" : "2013-08-23 12:07:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370878487818547201",
  "text" : "\u3055\u30FC\u3066\u66F8\u985E\u3069\u3053\u3084\u3063\u305F\u304B\u306A()",
  "id" : 370878487818547201,
  "created_at" : "2013-08-23 12:01:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370878024159207424",
  "geo" : { },
  "id_str" : "370878202081595394",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u77E5\u3063\u3066\u307E\u3059\u304C\u5B66\u751F\u8A3C\u306E\u30B3\u30D4\u30FC\u3068\u304B\u3044\u308B\u304B\u3082\u306A\u306E\u3067\u8FFD\u3063\u3066\u9023\u7D61\u3057\u307E\u3059",
  "id" : 370878202081595394,
  "in_reply_to_status_id" : 370878024159207424,
  "created_at" : "2013-08-23 12:00:28 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370877684257017856",
  "geo" : { },
  "id_str" : "370877881808744449",
  "in_reply_to_user_id" : 547547290,
  "text" : "@oPAKILIFEo \u305C\u3072\u304A\u9858\u3044\u3057\u307E\u3059",
  "id" : 370877881808744449,
  "in_reply_to_status_id" : 370877684257017856,
  "created_at" : "2013-08-23 11:59:12 +0000",
  "in_reply_to_screen_name" : "kussy_tessy",
  "in_reply_to_user_id_str" : "547547290",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370877494112428032",
  "geo" : { },
  "id_str" : "370877654393565186",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u305C\u3072\u304A\u9858\u3044\u3057\u307E\u3059",
  "id" : 370877654393565186,
  "in_reply_to_status_id" : 370877494112428032,
  "created_at" : "2013-08-23 11:58:18 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370877248380760064",
  "text" : "\u304B\u3078\u308F\u306C\u3081\u3084\u308B\u306B\u5F53\u305F\u3063\u3066\u540D\u524D\u304B\u3057\u3066\u304F\u308C\u308B\u4EBA\u30EA\u30D7\u30E9\u30A4\u304F\u3060\u3055\u3044\u3001\u5B9F\u969B\u540D\u524D\u8CB8\u3059\u3060\u3051\u3067\u4ED5\u4E8B\u3068\u304B\u306A\u3044\u3067\u3059\u3002",
  "id" : 370877248380760064,
  "created_at" : "2013-08-23 11:56:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370874040409272320",
  "geo" : { },
  "id_str" : "370874264670306304",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u4E86\u89E3\u3067\u3057",
  "id" : 370874264670306304,
  "in_reply_to_status_id" : 370874040409272320,
  "created_at" : "2013-08-23 11:44:49 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370868429776879616",
  "geo" : { },
  "id_str" : "370873781146767360",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3042\u30FC\u96C6\u3081\u3066\u306A\u3044\u3067\u3059(\u3057\u308D\u3081\n\u9069\u5F53\u306B\u52DF\u308C\u3070\u3042\u3064\u307E\u308B\u304B\u3068[6\u4EBA\u3082\u3044\u308B\u3093\u3067\u3059\u304B]",
  "id" : 370873781146767360,
  "in_reply_to_status_id" : 370868429776879616,
  "created_at" : "2013-08-23 11:42:54 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370822679319703552",
  "geo" : { },
  "id_str" : "370822877848686592",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma (\u7B39\u53D6\u308A)\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F(\u7B39\u53D6\u308A)\u4EE5\u5F8C\u6C17\u3092\u3064\u3051\u307E\u3059(\u7B39\u53D6\u308A\u884C\u304D\u307E\u3057\u3087\u3046)",
  "id" : 370822877848686592,
  "in_reply_to_status_id" : 370822679319703552,
  "created_at" : "2013-08-23 08:20:38 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370822435169243136",
  "geo" : { },
  "id_str" : "370822524952530944",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma (\u7B39\u53D6\u308A)",
  "id" : 370822524952530944,
  "in_reply_to_status_id" : 370822435169243136,
  "created_at" : "2013-08-23 08:19:14 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370808063730540544",
  "text" : "\u306C\u308B\u3044\u6C34\u3092\u555C\u308B",
  "id" : 370808063730540544,
  "created_at" : "2013-08-23 07:21:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2B50\u3044\u305F\u308A\u3042\u2B50",
      "screen_name" : "_Italia3",
      "indices" : [ 0, 9 ],
      "id_str" : "510117176",
      "id" : 510117176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370577699967758336",
  "geo" : { },
  "id_str" : "370722436108402688",
  "in_reply_to_user_id" : 510117176,
  "text" : "@_Italia3 \u304A\u3084\u3042\u308A\u3067\u3057\u305F\u30FC\u30FC",
  "id" : 370722436108402688,
  "in_reply_to_status_id" : 370577699967758336,
  "created_at" : "2013-08-23 01:41:31 +0000",
  "in_reply_to_screen_name" : "_Italia3",
  "in_reply_to_user_id_str" : "510117176",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370577612516495361",
  "text" : "\u3067\u3082\u4ECA\u65E5\u306F\u5BDD\u308B\uFF01\u304A\u4F11\u307F\uFF01",
  "id" : 370577612516495361,
  "created_at" : "2013-08-22 16:06:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370577531071508480",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u3001\u5348\u524D\u304B\u3089\u96C6\u307E\u3063\u3066\u4E00\u65E5\u7BED\u3063\u3066\u591C22\u6642\u304F\u3089\u3044\u306B\u89E3\u6563\u3059\u308B\u9EBB\u96C0\u3057\u305F\u3044",
  "id" : 370577531071508480,
  "created_at" : "2013-08-22 16:05:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370577115990605824",
  "geo" : { },
  "id_str" : "370577249088450560",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u6253\u3068\u3046\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 370577249088450560,
  "in_reply_to_status_id" : 370577115990605824,
  "created_at" : "2013-08-22 16:04:35 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370577074982895616",
  "geo" : { },
  "id_str" : "370577199788613633",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u6D41\u77F3\u306B\u7121\u7406\u3067\u3059\u3046",
  "id" : 370577199788613633,
  "in_reply_to_status_id" : 370577074982895616,
  "created_at" : "2013-08-22 16:04:24 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370577105718738944",
  "text" : "\u6B7B\u4EBA\u306B\u53E3\u7121\u3057",
  "id" : 370577105718738944,
  "created_at" : "2013-08-22 16:04:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370577063201079296",
  "text" : "\u6B7B\u306B\u8A00\u306F\u6B7B\u3093\u3067\u8A00\u3048",
  "id" : 370577063201079296,
  "created_at" : "2013-08-22 16:03:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370576992191524864",
  "text" : "\u9EBB\u96C0\u3068\u304B\u30C9\u30DF\u30CB\u30AA\u30F3\u3068\u304B\u30C9\u30DF\u30CB\u30AA\u30F3\u3068\u304B\u9EBB\u96C0\u3068\u304B\u9EBB\u96C0\u3068\u304B\u3057\u305F\u3044\u306A\u3041\u2026",
  "id" : 370576992191524864,
  "created_at" : "2013-08-22 16:03:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370576720534835201",
  "text" : "\u3053\u306E\u9580\u3092\u304F\u3050\u308B\u3082\u306E\u306F\u4E00\u5207\u306E\u671B\u307F\u3092\u2026",
  "id" : 370576720534835201,
  "created_at" : "2013-08-22 16:02:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/vcBdaNeNyQ",
      "expanded_url" : "https:\/\/twitter.com\/end313124\/status\/370137764169134081",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370532822441680896",
  "text" : "https:\/\/t.co\/vcBdaNeNyQ \u3053\u308C\u545F\u3044\u305F\u7FCC\u65E5\u540C\u3058\u5E97\u884C\u3063\u305F\u3089\u3042\u305A\u304D\u30D0\u30FC\u7F6E\u3044\u3066\u305F\u3057\u76E3\u8996\u3055\u308C\u3066\u308B\u53EF\u80FD\u6027\u3042\u308B",
  "id" : 370532822441680896,
  "created_at" : "2013-08-22 13:08:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370515802677473280",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 370515802677473280,
  "created_at" : "2013-08-22 12:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370512941751074816",
  "text" : "\u6B7B\u306C\u3068\u304D\u306F\u6B7B\u306C\u3001\u306A\u305C\u306A\u3089\u3070\u6B7B\u306C\u3068\u304D\u306F\u6B7B\u306C\u3068\u304D\u3060\u304B\u3089\u3067\u3042\u308B\u3002",
  "id" : 370512941751074816,
  "created_at" : "2013-08-22 11:49:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370512045185056768",
  "text" : "\u4F53\u80B2\u4F1A\u7CFB\u306F\u306A\u3093\u304B\u6CD5\u5F8B\u3068\u304B\u4EBA\u6A29\u3068\u304B\u53CA\u3070\u306A\u3044\u611F\u3058\u3057\u3066\u308B\u3001\u504F\u898B",
  "id" : 370512045185056768,
  "created_at" : "2013-08-22 11:45:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370511907972595713",
  "text" : "RT @kagakuma: \u9AD8\u91CE\u9023\u3092\u898B\u3066\u3082\u3084\u3082\u3084\u3057\u3066\u305F\u3051\u3069\u3001\u3044\u307E\u306F\u3063\u304D\u308A\u5206\u304B\u3063\u305F\u308F\u3002\u9AD8\u6821\u91CE\u7403\u3068\u3044\u3046\u4E16\u754C\u306F\u6CD5\u6CBB\u56FD\u5BB6\u306E\u8981\u4EF6\u3092\u6E80\u305F\u3057\u3066\u3044\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370511681098498048",
    "text" : "\u9AD8\u91CE\u9023\u3092\u898B\u3066\u3082\u3084\u3082\u3084\u3057\u3066\u305F\u3051\u3069\u3001\u3044\u307E\u306F\u3063\u304D\u308A\u5206\u304B\u3063\u305F\u308F\u3002\u9AD8\u6821\u91CE\u7403\u3068\u3044\u3046\u4E16\u754C\u306F\u6CD5\u6CBB\u56FD\u5BB6\u306E\u8981\u4EF6\u3092\u6E80\u305F\u3057\u3066\u3044\u306A\u3044\u3002",
    "id" : 370511681098498048,
    "created_at" : "2013-08-22 11:44:03 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 370511907972595713,
  "created_at" : "2013-08-22 11:44:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370510814316224513",
  "text" : "\u8A9E\u5C3E\u306B\u30B7\u30F3\u30B8\u30C6\u3063\u3066\u7740\u3051\u308B\u306E\u80E1\u6563\u81ED\u304F\u3066\u826F\u3044\u306A",
  "id" : 370510814316224513,
  "created_at" : "2013-08-22 11:40:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370510573680607233",
  "text" : "\u304B\u304C\u304F\u307E\u3055\u3093\u306F\"\u3061\u3087\u3063\u304B\u3044\u51FA\u3057\u305F\u304F\u3055\u305B\u308B\u624D\u80FD\u306E\u4EBA\"",
  "id" : 370510573680607233,
  "created_at" : "2013-08-22 11:39:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370509134266769408",
  "geo" : { },
  "id_str" : "370510260735184896",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u304B\u304C\u304F\u307E\u3055\u3093\u306F\u512A\u3057\u3044\u3067\u3059\u304B\u3089\u306D\u2026[\u3075\u3056\u3051\u306F\u3057\u307E\u3059\u304C\u8210\u3081\u305F\u308A\u306F\u3057\u3066\u307E\u305B\u3093\u30B7\u30F3\u30B8\u30C6\uFF01]",
  "id" : 370510260735184896,
  "in_reply_to_status_id" : 370509134266769408,
  "created_at" : "2013-08-22 11:38:24 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    }, {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 10, 20 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370506687293046785",
  "geo" : { },
  "id_str" : "370507409921306624",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma @piano2683 \u3054\u305F\u307E\u305C\u306B\u3057\u307E\u3057\u3087\u3046",
  "id" : 370507409921306624,
  "in_reply_to_status_id" : 370506687293046785,
  "created_at" : "2013-08-22 11:27:04 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B89\u897F",
      "screen_name" : "chinchikurim_ba",
      "indices" : [ 0, 16 ],
      "id_str" : "277901173",
      "id" : 277901173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370507063916367872",
  "geo" : { },
  "id_str" : "370507306779176960",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurim_ba \u4F3C\u305F\u672A\u6765\u3092\u8FBF\u308B\u5371\u967A\u304C\u3042\u308B\u306E\u3067\u30A2\u30A4\u30A8\u30A8\u30A8\u3063\u3066\u306A\u308A\u307E\u3057\u305F\u3002\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F\u3002[\u5B9F\u969B\u7D1B\u3089\u308F\u3057\u3044\u3067\u3059\u3088\u3046]",
  "id" : 370507306779176960,
  "in_reply_to_status_id" : 370507063916367872,
  "created_at" : "2013-08-22 11:26:40 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370506956093419520",
  "text" : "\u50D5\u305F\u3044\u3057\u3066\u98F2\u3081\u306A\u3044\u3051\u3069\u697D\u3057\u307F\u306B\u3057\u3066\u307E\u3059",
  "id" : 370506956093419520,
  "created_at" : "2013-08-22 11:25:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B89\u897F",
      "screen_name" : "chinchikurim_ba",
      "indices" : [ 0, 16 ],
      "id_str" : "277901173",
      "id" : 277901173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370506559161241600",
  "geo" : { },
  "id_str" : "370506767244869633",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurim_ba \u672C\u5F53\u3067\u3059\uFF1F\u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01",
  "id" : 370506767244869633,
  "in_reply_to_status_id" : 370506559161241600,
  "created_at" : "2013-08-22 11:24:31 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 11, 14 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370505528260059137",
  "geo" : { },
  "id_str" : "370506326742274048",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 #\u306F\u3044 \u6B7B\u306C\u307E\u3067\u5F85\u3063\u3066\u6B32\u3057\u3044",
  "id" : 370506326742274048,
  "in_reply_to_status_id" : 370505528260059137,
  "created_at" : "2013-08-22 11:22:46 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370504567315652608",
  "text" : "\u304B\u3093\u3053\u308C\u3082\u3084\u3089\u306A\u3044",
  "id" : 370504567315652608,
  "created_at" : "2013-08-22 11:15:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370469699298942976",
  "geo" : { },
  "id_str" : "370471724925456385",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u304C\u305F\u304C\u305F",
  "id" : 370471724925456385,
  "in_reply_to_status_id" : 370469699298942976,
  "created_at" : "2013-08-22 09:05:16 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370466694860242945",
  "text" : "\u3082\u3046\u3053\u3093\u306A\u3058\u304B\u3093",
  "id" : 370466694860242945,
  "created_at" : "2013-08-22 08:45:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370385086828408833",
  "geo" : { },
  "id_str" : "370385166889283584",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3046\u3069\u3093\u305D\u3070\u3060\u304B\u305D\u3070\u3046\u3069\u3093\u3060\u304B\u2026",
  "id" : 370385166889283584,
  "in_reply_to_status_id" : 370385086828408833,
  "created_at" : "2013-08-22 03:21:19 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370383065303887872",
  "geo" : { },
  "id_str" : "370384771873914880",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u30AF\u30C9\u304C\u305D\u3093\u306A\u3093\u98DF\u3079\u3066\u305F\u3088\u3046\u306A",
  "id" : 370384771873914880,
  "in_reply_to_status_id" : 370383065303887872,
  "created_at" : "2013-08-22 03:19:45 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370382953190141952",
  "text" : "\u3046\u3069\u3093\u3068\u305D\u3046\u3081\u3093\u3092\u51FA\u6C41\u3067\u5272\u3063\u305F\u611F\u3058",
  "id" : 370382953190141952,
  "created_at" : "2013-08-22 03:12:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370382561416978432",
  "geo" : { },
  "id_str" : "370382877856256001",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3046\u3069\u3093\u3068\u305D\u3046\u3081\u3093\u3092\u8DB3\u3057\u3066\u4E8C\u3067\u5272\u3063\u305F\u611F\u3058\uFF1F",
  "id" : 370382877856256001,
  "in_reply_to_status_id" : 370382561416978432,
  "created_at" : "2013-08-22 03:12:14 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370382583269298177",
  "text" : "\u51B7\u9EA6\u306E\u5E02\u6C11\u6A29\u304C\u6B86\u3069\u306A\u3044",
  "id" : 370382583269298177,
  "created_at" : "2013-08-22 03:11:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370382119840657408",
  "geo" : { },
  "id_str" : "370382453937958912",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3072\u3084\u3080\u304E\u3043",
  "id" : 370382453937958912,
  "in_reply_to_status_id" : 370382119840657408,
  "created_at" : "2013-08-22 03:10:33 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370381664305688576",
  "text" : "\u304A\u3046\u3069\u3093\u304C\u76EE\u306E\u524D\u306B\u3042\u3063\u305F\u3089\u30C0\u30A4\u30D6\u3059\u308B\u306E\u304B",
  "id" : 370381664305688576,
  "created_at" : "2013-08-22 03:07:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370140007450693632",
  "text" : "\u9662\u6B7B",
  "id" : 370140007450693632,
  "created_at" : "2013-08-21 11:07:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370139957697839105",
  "text" : "\u6D41\u77F3\u306B\u7121\u7406",
  "id" : 370139957697839105,
  "created_at" : "2013-08-21 11:06:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370139775946092544",
  "geo" : { },
  "id_str" : "370139901796159488",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u9662\u8A66\uFF01\uFF01\uFF01\uFF01\u524D\u3005\u65E5\uFF01\uFF01\uFF01",
  "id" : 370139901796159488,
  "in_reply_to_status_id" : 370139775946092544,
  "created_at" : "2013-08-21 11:06:44 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370139036830023681",
  "text" : "\u85AC\u98F2\u3093\u3067\u5BDD\u308B\u304B",
  "id" : 370139036830023681,
  "created_at" : "2013-08-21 11:03:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370138973647024128",
  "text" : "\u30BA\u30C4\u30A6=\u30CB\u30F3\u30B8\u30E3=\u30AF\u30E9\u30F3",
  "id" : 370138973647024128,
  "created_at" : "2013-08-21 11:03:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370138166323191809",
  "text" : "\u3068\u306F\u3044\u3048\u98DF\u3079\u306A\u3044\u3067\u6587\u53E5\u3082\u3042\u308C\u3060\u306A\u3001\u305D\u306E\u3046\u3061\u98DF\u3079\u3088\u3046",
  "id" : 370138166323191809,
  "created_at" : "2013-08-21 10:59:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370137764169134081",
  "text" : "\u30B3\u30F3\u30D3\u30CB\u306B\u3086\u305A\u3042\u305A\u304D\u30D0\u30FC\u306A\u308B\u306E\u304C\u3042\u3063\u305F\u3001\u306A\u3093\u3060\u3088\u3086\u305A\u3063\u3066\uFF01\u666E\u901A\u306E\u7F6E\u3051\u3088\uFF01\uFF01",
  "id" : 370137764169134081,
  "created_at" : "2013-08-21 10:58:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30E0\u30C8",
      "screen_name" : "turkey2410",
      "indices" : [ 0, 11 ],
      "id_str" : "763557104",
      "id" : 763557104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370135752312516608",
  "geo" : { },
  "id_str" : "370137558908297217",
  "in_reply_to_user_id" : 763557104,
  "text" : "@turkey2410 \u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01",
  "id" : 370137558908297217,
  "in_reply_to_status_id" : 370135752312516608,
  "created_at" : "2013-08-21 10:57:25 +0000",
  "in_reply_to_screen_name" : "turkey2410",
  "in_reply_to_user_id_str" : "763557104",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370115962436984833",
  "text" : "\u5915\u7ACB\u3060",
  "id" : 370115962436984833,
  "created_at" : "2013-08-21 09:31:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/cS3pFJ3MVd",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=mami_katze",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370112721485705216",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/cS3pFJ3MVd",
  "id" : 370112721485705216,
  "created_at" : "2013-08-21 09:18:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370054078094508032",
  "geo" : { },
  "id_str" : "370054725581819904",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u5148\u884C\u304D\u304C\u5FC3\u914D\u3067\u3059",
  "id" : 370054725581819904,
  "in_reply_to_status_id" : 370054078094508032,
  "created_at" : "2013-08-21 05:28:16 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370054044313583616",
  "text" : "\u91CE\u7403\u3068\u304B\u30B5\u30C3\u30AB\u30FC\u3068\u304B\u7A4D\u6975\u7684\u306B\u7279\u6B8A\u30EB\u30FC\u30EB\u3067\u3084\u3063\u3066\u307F\u308C\u3070\u3044\u3044\u306E\u306B",
  "id" : 370054044313583616,
  "created_at" : "2013-08-21 05:25:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370053556188897282",
  "geo" : { },
  "id_str" : "370053902676131841",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u30EB\u30FC\u30C4\u306E\u65B9\u304C\u9762\u767D\u305D\u3046\u3067\u3059\u306Dwww",
  "id" : 370053902676131841,
  "in_reply_to_status_id" : 370053556188897282,
  "created_at" : "2013-08-21 05:25:00 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370053751010103296",
  "text" : "\u4E2D2\u306E\u59B9\u304C\u4E09\u89D2\u5F62\u306E\u9762\u7A4D\u306E\u516C\u5F0F\u300C\u305F\u3066\u304B\u3051\u308B\u3088\u3053\u5272\u308B2\u300D\u3068\u899A\u3048\u3066\u3044\u305F\u306E\u306F\u826F\u304B\u3063\u305F\u304C\u76F4\u89D2\u4E09\u89D2\u5F62\u3067\u306A\u304F\u3066\u3082\u7E26\u65B9\u5411\u306E\u8FBA\u306E\u9577\u3055\u3068\u6A2A\u65B9\u5411\u306E\u8FBA\u306E\u9577\u3055\u639B\u3051\u7B97\u3057\u3066\u3066\u3084\u3070\u3044\u3068\u601D\u3063\u305F",
  "id" : 370053751010103296,
  "created_at" : "2013-08-21 05:24:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370051598090653696",
  "geo" : { },
  "id_str" : "370052822382821376",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u9762\u767D\u305D\u3046\u3067\u3059\u306D\uFF01\n\u306B\u3057\u3066\u3082\u305D\u3053\u307E\u3067\u6975\u7AEF\u3058\u3083\u306A\u304F\u3066\u3082\u7279\u6B8A\u30EB\u30FC\u30EB\u3067\u8A66\u5408\u307F\u305F\u3044\u306E\u3063\u3066\u306A\u3044\u3093\u3067\u3059\uFF1F",
  "id" : 370052822382821376,
  "in_reply_to_status_id" : 370051598090653696,
  "created_at" : "2013-08-21 05:20:42 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370050060337160192",
  "geo" : { },
  "id_str" : "370050528270503937",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u534A\u65E5\u3067\u7D42\u308F\u308B\u6C17\u304C\u3057\u306A\u3044\u3093\u3067\u3059\u3051\u3069",
  "id" : 370050528270503937,
  "in_reply_to_status_id" : 370050060337160192,
  "created_at" : "2013-08-21 05:11:35 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370047539895996416",
  "text" : "\u30B0\u30FC\u5168\u632F\u308A\u3092\u5BE9\u5224\u306B\u9811\u306A\u306B\u4E3B\u5F35\u3059\u308B\u56F3\u3001\u3053\u306E\u4E0A\u306A\u304F\u30A8\u30F3\u30BF\u30FC\u30C6\u30A4\u30E1\u30F3\u30C8",
  "id" : 370047539895996416,
  "created_at" : "2013-08-21 04:59:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370044930720161792",
  "geo" : { },
  "id_str" : "370045228427669505",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u753B\u9762\u304B\u30895m\u304F\u3089\u3044\u96E2\u308C\u3066\u898B\u308B\u3068\u898B\u5206\u3051\u3064\u304B\u306A\u3044\u3088\uFF1F",
  "id" : 370045228427669505,
  "in_reply_to_status_id" : 370044930720161792,
  "created_at" : "2013-08-21 04:50:32 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370045090644758528",
  "text" : "\u305D\u306E\u70B9\u3058\u3083\u304B\u3058\u3083\u304B\u3058\u3083\u3093\u3051\u3093\u306F\u516C\u5E73",
  "id" : 370045090644758528,
  "created_at" : "2013-08-21 04:49:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370045033635774464",
  "text" : "\u3058\u3083\u3093\u3051\u3093\u3060\u3068\u30BC\u30EA\u30FC\u3055\u3093\u307F\u305F\u3044\u306B\u30B0\u30FC\u306B\u5168\u632F\u308A\u3057\u3066\u308B\u4EBA\u304C\u3044\u3066\u4E0D\u516C\u5E73",
  "id" : 370045033635774464,
  "created_at" : "2013-08-21 04:49:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370044086935240706",
  "geo" : { },
  "id_str" : "370044590021033984",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u306B\u3066\u308B",
  "id" : 370044590021033984,
  "in_reply_to_status_id" : 370044086935240706,
  "created_at" : "2013-08-21 04:48:00 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u707C\u773C\u306E\u3042\u304B\u2606\u306D\u3053",
      "screen_name" : "math_neko",
      "indices" : [ 0, 10 ],
      "id_str" : "232545906",
      "id" : 232545906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370042703527948289",
  "geo" : { },
  "id_str" : "370043098174197760",
  "in_reply_to_user_id" : 232545906,
  "text" : "@math_neko \u3044\u3084\u307E\u3041\u5927\u5B66\u306B\u304A\u3051\u308B\u30B0\u30EB\u30FC\u30D7\u5F62\u6210\u306E\u8A71\u3092\u3057\u3066\u308B\u4EBA\u304C\u3044\u305F\u306E\u3067\u3064\u3044(",
  "id" : 370043098174197760,
  "in_reply_to_status_id" : 370042703527948289,
  "created_at" : "2013-08-21 04:42:04 +0000",
  "in_reply_to_screen_name" : "math_neko",
  "in_reply_to_user_id_str" : "232545906",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370042454629576704",
  "geo" : { },
  "id_str" : "370042663765954560",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u6642\u9593\u7121\u5236\u9650\u3068\u66F8\u304F\u3079\u304D\u3060\u3063\u305F",
  "id" : 370042663765954560,
  "in_reply_to_status_id" : 370042454629576704,
  "created_at" : "2013-08-21 04:40:20 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370042556597301248",
  "text" : "\u5143\u304C\u5358\u4F4D\u5143\u3060\u3051\u3067\u3082\u30B0\u30EB\u30FC\u30D7\u2026",
  "id" : 370042556597301248,
  "created_at" : "2013-08-21 04:39:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370042269232922624",
  "text" : "\u30B5\u30C3\u30AB\u30FC\u3068\u304B50\u70B9\u5148\u53D6\u304C\u52DD\u5229\u6761\u4EF6\u306E\u30B5\u30C9\u30F3\u30C7\u30B9\u3068\u304B\u3042\u3063\u305F\u3089\u898B\u308B\u304B\u3082",
  "id" : 370042269232922624,
  "created_at" : "2013-08-21 04:38:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370041558336155648",
  "text" : "\u307E\u3041\u30B9\u30DD\u30FC\u30C4\u898B\u306A\u3044\u30DE\u30F3\u3060\u3057\u30B9\u30DD\u30FC\u30C4\u304C\u3061\u3067\u3084\u3089\u306A\u3044\u30DE\u30F3\u3060\u304B\u3089\u306A\u3041",
  "id" : 370041558336155648,
  "created_at" : "2013-08-21 04:35:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3061\u3088\u304E",
      "screen_name" : "larvitar1031",
      "indices" : [ 0, 13 ],
      "id_str" : "785969384",
      "id" : 785969384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370041144672919553",
  "geo" : { },
  "id_str" : "370041434302210050",
  "in_reply_to_user_id" : 785969384,
  "text" : "@larvitar1031 \u305D\u306E\u3088\u3046\u3067\u3059\u306A\u30FC[\u52DD\u3064\u305F\u3081\u306E\u52B9\u7387\u7684\u624B\u6BB5\u304C\u305D\u3046\u3044\u3046\u30B2\u30FC\u30E0\u4EE5\u5916\u306E\u7406\u7531\u3067\u5C01\u3058\u3089\u308C\u308B\u4E16\u306E\u4E2D\u3060\u3063\u305F]",
  "id" : 370041434302210050,
  "in_reply_to_status_id" : 370041144672919553,
  "created_at" : "2013-08-21 04:35:27 +0000",
  "in_reply_to_screen_name" : "larvitar1031",
  "in_reply_to_user_id_str" : "785969384",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370040318743179264",
  "text" : "\u30AA\u30D5\u30B5\u30A4\u30C9\u306E\u7981\u6B62\u7406\u7531\u304C\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u3048\u3093\u3069\u3055\u3093\u306B\u30B5\u30A4\u30F3\u76D7\u307F\u306E\u7981\u6B62\u7406\u7531\u304C\u308F\u304B\u308B\u306F\u305A\u304C\u7121\u304B\u3063\u305F",
  "id" : 370040318743179264,
  "created_at" : "2013-08-21 04:31:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369859919014404096",
  "geo" : { },
  "id_str" : "370018118271107072",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 \u306A\u3093\u3068\u3044\u3046\u304B\u3001\"\u5F7C\u5973\u732B\u304B\u308F\u3044\u3044\"\u3001\u305D\u308C\u3060\u3051\u3067\u3057\u305F\u306D\uFF1F\u6620\u753B\u5316\u3084\u3089\u306A\u306B\u3084\u3089\u306F\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u3067\u3059",
  "id" : 370018118271107072,
  "in_reply_to_status_id" : 369859919014404096,
  "created_at" : "2013-08-21 03:02:48 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370017368296013824",
  "text" : "\u5BDD\u7656\u6848\u4EF6",
  "id" : 370017368296013824,
  "created_at" : "2013-08-21 02:59:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369819603888644097",
  "text" : "\u3069\u3046\u3082\u3001\u53E3\u52D5\u304B\u3057\u305F\u3044\u4EBA\u9593\u3067\u3059\u3002",
  "id" : 369819603888644097,
  "created_at" : "2013-08-20 13:53:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369819567259803648",
  "text" : "\u8AB0\u304B\u3068\u558B\u308A\u305F\u307F\u304C\u9AD8\u307E\u308B\u6570\u65E5\u3060\u306A\u3041\u2026\u53E3\u52D5\u304B\u3057\u305F\u3044\u4EBA\u9593\u3068\u3057\u3066\u306F",
  "id" : 369819567259803648,
  "created_at" : "2013-08-20 13:53:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369817728330125312",
  "text" : "co-worker\u306E-\u306F\u5F15\u304D\u7B97\u3068\u89E3\u91C8\u3059\u308B\u304B\u3063\u3066\u8A71\u306A\u30EF\u30B1\u3088",
  "id" : 369817728330125312,
  "created_at" : "2013-08-20 13:46:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u308B\u30FD('\u03C9'*)\u2606@\u5951\u4E39\u65CF",
      "screen_name" : "KAZ343434",
      "indices" : [ 0, 10 ],
      "id_str" : "48631158",
      "id" : 48631158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369816774910304258",
  "geo" : { },
  "id_str" : "369817164024266752",
  "in_reply_to_user_id" : 48631158,
  "text" : "@KAZ343434 iff\u3068\u306F\u66F8\u3044\u3066\u306A\u3044\u306A\uFF1F",
  "id" : 369817164024266752,
  "in_reply_to_status_id" : 369816774910304258,
  "created_at" : "2013-08-20 13:44:17 +0000",
  "in_reply_to_screen_name" : "KAZ343434",
  "in_reply_to_user_id_str" : "48631158",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369816622925488128",
  "text" : "\u30D5\u30AF\u30C4\u30A6=\u30A4\u30BF\u30DF=\u30DA\u30A4\u30F3",
  "id" : 369816622925488128,
  "created_at" : "2013-08-20 13:42:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369815223554699264",
  "text" : "\u3084\u3044\u3070\u306E\u30D6\u30FC\u30E1\u30E9\u30F3",
  "id" : 369815223554699264,
  "created_at" : "2013-08-20 13:36:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369815182945427456",
  "text" : "\u5730\u306B\u8DB3\u304C\u7740\u3044\u3066\u306A\u3044\u306E\u306B\u6D6E\u3044\u305F\u8A71\u304C\u306A\u3044\u307F\u306A\u3055\u3093\uFF1F",
  "id" : 369815182945427456,
  "created_at" : "2013-08-20 13:36:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369791012102627330",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 369791012102627330,
  "created_at" : "2013-08-20 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369774211696295936",
  "text" : "\u7A7A\u8179\u3068\u3044\u3046\u6848\u4EF6",
  "id" : 369774211696295936,
  "created_at" : "2013-08-20 10:53:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369692407022878720",
  "text" : "\u3080\u3044\u5F0F",
  "id" : 369692407022878720,
  "created_at" : "2013-08-20 05:28:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369641709891633152",
  "text" : "\u5BDD\u308B\u5EA6\u306B\u6642\u9593\u304C\u9032\u3080\u30D0\u30B0",
  "id" : 369641709891633152,
  "created_at" : "2013-08-20 02:07:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369469761354080256",
  "geo" : { },
  "id_str" : "369478492108251136",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u30A2\u30C3\u30CF\u30A4",
  "id" : 369478492108251136,
  "in_reply_to_status_id" : 369469761354080256,
  "created_at" : "2013-08-19 15:18:31 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369469585356902400",
  "text" : "\u3069\u3046\u305B\u610F\u5473\u306E\u3042\u308B\u3053\u3068\u6B86\u3069\u8A00\u308F\u306A\u3044",
  "id" : 369469585356902400,
  "created_at" : "2013-08-19 14:43:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369469507489636353",
  "text" : "\u963F\u90E8\u304F\u3093\u304B\u3089\u9854\u672C\u7533\u8ACB\u6765\u3066OK\u3057\u305F\u3051\u3069\u3001\u963F\u90E8\u304F\u3093\u306B\u9650\u3089\u305A\u9B31\u9676\u3057\u304B\u3063\u305F\u3089\u30EA\u30E0\u3063\u3066(?)\u4E0B\u3055\u3044\u306D",
  "id" : 369469507489636353,
  "created_at" : "2013-08-19 14:42:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369464630919172097",
  "text" : "\u6700\u8FD1\u9854\u672C\u3067\u30B5\u30C4\u30D0\u30C4\u3057\u3066\u306A\u304B\u3063\u305F\u304B\u3089\u6BBA\u4F10\u3057\u3066\u304A\u3044\u305F",
  "id" : 369464630919172097,
  "created_at" : "2013-08-19 14:23:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369453230964473856",
  "text" : "TL\u3067\u3044\u3064\u3082\u306F\u898B\u904E\u3054\u305B\u308B\u3057\u3087\u3046\u3082\u306A\u3044\u3053\u3068\u306B\u30A4\u30E9\u3063\u3068\u3057\u305F\u3089\u6A5F\u5ACC\u304C\u60AA\u3044\u3063\u3066\u81EA\u899A\u3067\u304D\u3066\u4FBF\u5229\u3060\u306A\u30FC",
  "id" : 369453230964473856,
  "created_at" : "2013-08-19 13:38:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369430907427377152",
  "text" : "( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 369430907427377152,
  "created_at" : "2013-08-19 12:09:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369430721883934721",
  "text" : "\"\u308B\u30AB\u30C3\u30D7\u30EB\u306E\"\u306B\u66F8\u304D\u63DB\u3048\u305F",
  "id" : 369430721883934721,
  "created_at" : "2013-08-19 12:08:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369430454035705857",
  "text" : "\u30AB\u30C3\u30D7\u30EB\u306ELINE\u3067\u30DF\u30E5\u30FC\u30C8\u304B\u3051\u305F.31\u65E5\u671F\u9650\u3067.",
  "id" : 369430454035705857,
  "created_at" : "2013-08-19 12:07:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369429851150643200",
  "text" : "Twitter\u306E\u30CD\u30BF\u306E\u6D88\u8CBB\u306E\u65E9\u3055\u3063\u3066\u2026",
  "id" : 369429851150643200,
  "created_at" : "2013-08-19 12:05:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369356421600514048",
  "text" : "\u75DB\u3044\u3082\u306E\u306D",
  "id" : 369356421600514048,
  "created_at" : "2013-08-19 07:13:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369356396946411522",
  "text" : "hogehoge\u306A\u3093\u3066\u53E3\u304C\u88C2\u3051\u305F\u3089\u8A00\u3048\u306A\u3044[\u30C6\u30F3\u30D7\u30EC]",
  "id" : 369356396946411522,
  "created_at" : "2013-08-19 07:13:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JinS",
      "screen_name" : "Jin0172",
      "indices" : [ 0, 8 ],
      "id_str" : "95801744",
      "id" : 95801744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369356144667422720",
  "geo" : { },
  "id_str" : "369356229442691072",
  "in_reply_to_user_id" : 95801744,
  "text" : "@Jin0172 \u30A2\u30C3\u30CF\u30A4",
  "id" : 369356229442691072,
  "in_reply_to_status_id" : 369356144667422720,
  "created_at" : "2013-08-19 07:12:42 +0000",
  "in_reply_to_screen_name" : "Jin0172",
  "in_reply_to_user_id_str" : "95801744",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JinS",
      "screen_name" : "Jin0172",
      "indices" : [ 0, 8 ],
      "id_str" : "95801744",
      "id" : 95801744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369355791397969920",
  "geo" : { },
  "id_str" : "369355951771361280",
  "in_reply_to_user_id" : 95801744,
  "text" : "@Jin0172 [\u8A95\u751F\u65E52\u6708\u306A\u306E\u3067\u5E74\u8D8A\u3057\u5F85\u3063\u305F\u65B9\u304C\u65E9\u3044]",
  "id" : 369355951771361280,
  "in_reply_to_status_id" : 369355791397969920,
  "created_at" : "2013-08-19 07:11:35 +0000",
  "in_reply_to_screen_name" : "Jin0172",
  "in_reply_to_user_id_str" : "95801744",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369355657578704897",
  "text" : "\u6075\u65B9\u5DFB\u304D\u3068\u304B\u3082\u98DF\u3079\u305F\u3057",
  "id" : 369355657578704897,
  "created_at" : "2013-08-19 07:10:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JinS",
      "screen_name" : "Jin0172",
      "indices" : [ 0, 8 ],
      "id_str" : "95801744",
      "id" : 95801744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369355375901822976",
  "geo" : { },
  "id_str" : "369355574862811136",
  "in_reply_to_user_id" : 95801744,
  "text" : "@Jin0172 \u3044\u3084\u3001\u5E74\u8D8A\u3057\u306E\u6642\u306B\u98DF\u3079\u306A\u3044\u3068\u305F\u3060\u306E\u305D\u3070\u3058\u3083\u3093\uFF1F",
  "id" : 369355574862811136,
  "in_reply_to_status_id" : 369355375901822976,
  "created_at" : "2013-08-19 07:10:06 +0000",
  "in_reply_to_screen_name" : "Jin0172",
  "in_reply_to_user_id_str" : "95801744",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369354793036177408",
  "text" : "\u3060\u3063\u3066\u534A\u5E74\u4EE5\u4E0A\u98DF\u3079\u3066\u306A\u3044\u3067\u3059\u3088\uFF1F\u5E74\u8D8A\u3057\u305D\u3070\uFF01",
  "id" : 369354793036177408,
  "created_at" : "2013-08-19 07:06:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369354643500851200",
  "text" : "\u5E74\u8D8A\u3057\u305D\u3070\u98DF\u3079\u305F\u3044\u3093\u3060\u3051\u3069\uFF1F\u4ECA\uFF1F",
  "id" : 369354643500851200,
  "created_at" : "2013-08-19 07:06:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369352557216268288",
  "text" : "\u5317\u6D77\u9053\u4E00\u5468\u30C9\u30E9\u30A4\u30D6\u3068\u304B\u3057\u305F\u3044\u3001\u4E00\u9031\u9593\u304F\u3089\u3044\u304B\u3051\u3066\uFF1F",
  "id" : 369352557216268288,
  "created_at" : "2013-08-19 06:58:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369352418443546624",
  "text" : "\u6B21\u306E\u7AE0\u3067\u5C0E\u5165\u3059\u308B\u6982\u5FF5\u4E71\u6253\u3059\u308B\u306E\u3084\u3081\u3061\u304F\u308A\u30FC",
  "id" : 369352418443546624,
  "created_at" : "2013-08-19 06:57:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369330382388211712",
  "geo" : { },
  "id_str" : "369330567679987712",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u6848\u5916\u3044\u3051\u308B\u306E\u306B\u306D\u30FC[\u79FB\u52D5\u304C\u82E6\u3067\u306A\u3051\u308C\u3070]",
  "id" : 369330567679987712,
  "in_reply_to_status_id" : 369330382388211712,
  "created_at" : "2013-08-19 05:30:43 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369317693725216771",
  "geo" : { },
  "id_str" : "369329325947895808",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 TL\u3067\u898B\u305F\u6642\u306B\u771F\u9854\u3060\u3063\u305F\u3053\u3068\u3092\u304A\u77E5\u3089\u305B\u3057\u3066\u304A\u304D\u307E\u3059",
  "id" : 369329325947895808,
  "in_reply_to_status_id" : 369317693725216771,
  "created_at" : "2013-08-19 05:25:47 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369268671174029312",
  "text" : "\u51C4\u3044\u98DB\u3076\u5922\u898B\u305F",
  "id" : 369268671174029312,
  "created_at" : "2013-08-19 01:24:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3083\u3093\u3075",
      "screen_name" : "nyamph_pf",
      "indices" : [ 0, 10 ],
      "id_str" : "107723928",
      "id" : 107723928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369075141348556800",
  "geo" : { },
  "id_str" : "369075184700903425",
  "in_reply_to_user_id" : 107723928,
  "text" : "@nyamph_pf \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 369075184700903425,
  "in_reply_to_status_id" : 369075141348556800,
  "created_at" : "2013-08-18 12:35:55 +0000",
  "in_reply_to_screen_name" : "nyamph_pf",
  "in_reply_to_user_id_str" : "107723928",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369066231627661313",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 369066231627661313,
  "created_at" : "2013-08-18 12:00:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369064153790414849",
  "geo" : { },
  "id_str" : "369064357985939456",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u307E\u3060\u53D6\u308A\u6B8B\u3055\u308C\u3066\u3044\u304F\u6A21\u69D8\u306A\u306E\u3067\u793E\u4F1A\u306E\u5148\u8F29\u3068\u3057\u3066\u9811\u5F35\u3063\u3066\u4E0B\u3055\u3044(?)",
  "id" : 369064357985939456,
  "in_reply_to_status_id" : 369064153790414849,
  "created_at" : "2013-08-18 11:52:54 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369063443375980544",
  "geo" : { },
  "id_str" : "369063543473070080",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u5185\u5B9A\u3057\u305F\u306E\uFF1F\u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01",
  "id" : 369063543473070080,
  "in_reply_to_status_id" : 369063443375980544,
  "created_at" : "2013-08-18 11:49:40 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369061025762385920",
  "text" : "\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC\u5165\u9580\u306B60\u5206\u67A0\u3092\u5272\u308A\u632F\u3089\u308C\u3066\u3044\u308B\u4E8B\u306B\u6C17\u3065\u3044\u305F\u6642\u306E\u9854 of the year 2013\u306A\u3089\u512A\u52DD\u3067\u304D\u308B",
  "id" : 369061025762385920,
  "created_at" : "2013-08-18 11:39:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369052941774114816",
  "geo" : { },
  "id_str" : "369060653182361600",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u30B5\u30F3\u30C8\u30EA\u30FC\u3068\u30D1\u30B9\u30B3\u306B\u76F8\u8AC7\u3067\u3059\u304B\u306D",
  "id" : 369060653182361600,
  "in_reply_to_status_id" : 369052941774114816,
  "created_at" : "2013-08-18 11:38:11 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369052660839620608",
  "text" : "\u305D\u3093\u306A\u3082\u306E\u306F\u306A\u3044\u3088",
  "id" : 369052660839620608,
  "created_at" : "2013-08-18 11:06:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369052599804112896",
  "text" : "\u98DF\u30D1\u30F3\u3068\u70CF\u9F8D\u8336\u3092\u7121\u9650\u306B\u751F\u6210\u3059\u308B\u6A5F\u95A2\u304C\u3042\u308C\u3070\u98DF\u8CBB\u3044\u3089\u306A\u3044\u306E\u3067\u306F",
  "id" : 369052599804112896,
  "created_at" : "2013-08-18 11:06:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369040405301428224",
  "text" : "\u9EC4\u7DD1\u3001\u6C34\u8272\u3001\u7D2B\u3068\u30AB\u30E9\u30D5\u30EB\u306A\u30CE\u30FC\u30C8\u3060\u3063\u305F\u304C\u3053\u3053\u304B\u3089\u306F\u767D\u3044\u306E\u3067",
  "id" : 369040405301428224,
  "created_at" : "2013-08-18 10:17:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369039029179670528",
  "text" : "\u8272\u4ED8\u304D\u306EB5\u7528\u7D19\u58F2\u3063\u3066\u306A\u304F\u3066\u4ED5\u65B9\u306A\u304F\u666E\u901A\u306E\u767D\u3044\u306E\u8CB7\u3063\u3066\u304D\u305F",
  "id" : 369039029179670528,
  "created_at" : "2013-08-18 10:12:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369016310392311808",
  "text" : "sksk\u30FC",
  "id" : 369016310392311808,
  "created_at" : "2013-08-18 08:41:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369012759775547393",
  "text" : "\u30C8\u30FC\u30B9\u30C8\u8A0814\u5206\u3082\u713C\u304F\u754C\u9688",
  "id" : 369012759775547393,
  "created_at" : "2013-08-18 08:27:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369012645644357632",
  "text" : "\u8868\u516B\u5206\u3001\u88CF\u516D\u5206\u3001\u5929\u76EE\u767E\u676F\u68D2\u516B\u767E\u672C\u266A",
  "id" : 369012645644357632,
  "created_at" : "2013-08-18 08:27:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369011621978316800",
  "text" : "\u6FC3\u3044\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u306F\u6FC3\u304F\u3066\u51B7\u305F\u3044\u3053\u3068\u3060\u306A\u3041",
  "id" : 369011621978316800,
  "created_at" : "2013-08-18 08:23:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369011216636592128",
  "text" : "\u6FC3\u3044\uFF01",
  "id" : 369011216636592128,
  "created_at" : "2013-08-18 08:21:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368948462206738432",
  "text" : "\u8AB0\u304B\u4E5D\u5DDE\u3092\u4E5D\u5468\u3059\u308B\u30EC\u30DD\u66F8\u3044\u3066",
  "id" : 368948462206738432,
  "created_at" : "2013-08-18 04:12:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368948308862984193",
  "text" : "\u554F\u984C\u306F\u4E5D\u5DDE\u306B\u4E0A\u9678\u3057\u305F\u3053\u3068\u306A\u3044\u3063\u3066\u30B3\u30C8[\u4E0A\u7A7A\u3082\u306A\u3044\u304B\u3082\u3060\u3051\u3069]",
  "id" : 368948308862984193,
  "created_at" : "2013-08-18 04:11:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368947882004463616",
  "text" : "\u5B9F\u969B\u4E5D\u5DDE\u3092\u4E5D\u5468\u3082\u3059\u308B\u306E\u3001\u8CA1\u529B\u3082\u4F53\u529B\u3082\u8981\u308B",
  "id" : 368947882004463616,
  "created_at" : "2013-08-18 04:10:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368947608795889664",
  "text" : "\u4E5D\u5DDE\u3092\u6025\u8972\u3057\u305F\u304B\u3063\u305F",
  "id" : 368947608795889664,
  "created_at" : "2013-08-18 04:08:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "410natsuki529",
      "screen_name" : "tatyusa419",
      "indices" : [ 0, 11 ],
      "id_str" : "2531832002",
      "id" : 2531832002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368947548301426688",
  "text" : "@tatyusa419 \u5B9F\u969B\u98FD\u304D\u308B\u306A\u3001\u4E5D\u5DDE\u884C\u3063\u305F\u4E8B\u306A\u3044\u3051\u3069",
  "id" : 368947548301426688,
  "created_at" : "2013-08-18 04:08:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368947274199486464",
  "text" : "\u6C7A\u307E\u308A\u304D\u3063\u305F\u4F1A\u8A71\u30E1\u30BD\u30C3\u30C9",
  "id" : 368947274199486464,
  "created_at" : "2013-08-18 04:07:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368947196483223552",
  "text" : "\u300C\u3067\u3001\u4E5D\u5DDE\u3092\u4F55\u5468\u3059\u308B\u3064\u3082\u308A\u306A\u306E\uFF1F\u300D\u306B\u5BFE\u3057\u3066\n\u300C\u4E5D\u5468\u300D\u3068\u8FD4\u3057\u3066\u304F\u308C\u308B\u601D\u8003\u505C\u6B62\u30D5\u30EC\u30F3\u30C9",
  "id" : 368947196483223552,
  "created_at" : "2013-08-18 04:07:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368703880562896896",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 368703880562896896,
  "created_at" : "2013-08-17 12:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368692360911155200",
  "text" : "\u53E3\u3092\u52D5\u304B\u3057\u305F\u3044\u3060\u3051\u306E\u751F\u304D\u7269\u3060\u3063\u305F(\u5B8C)",
  "id" : 368692360911155200,
  "created_at" : "2013-08-17 11:14:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368691746328162304",
  "text" : "\u9069\u5F53\u3067\u826F\u3044.\u3066\u304D\u3068\u30FC\u3066\u304D\u3068\u30FC.",
  "id" : 368691746328162304,
  "created_at" : "2013-08-17 11:12:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368691398687481857",
  "geo" : { },
  "id_str" : "368691577897484288",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5168\u90E8\u306F\u6D41\u77F3\u306B\u306A\u3044.\u9069\u5F53\u3067\u826F\u3044\u3088.",
  "id" : 368691577897484288,
  "in_reply_to_status_id" : 368691398687481857,
  "created_at" : "2013-08-17 11:11:36 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368690764441608193",
  "geo" : { },
  "id_str" : "368691049440354304",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3057\u3042\u308F\u305B\u3082\u306E\u3081\u30FC",
  "id" : 368691049440354304,
  "in_reply_to_status_id" : 368690764441608193,
  "created_at" : "2013-08-17 11:09:30 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368690303495966720",
  "text" : "\u6E0B\u307F\u3068\u6FC3\u307F\u3092\u4E21\u7ACB\u3059\u308B\u306E\u306F\u96E3\u3057\u3044\u306A\u2026",
  "id" : 368690303495966720,
  "created_at" : "2013-08-17 11:06:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368684195507216384",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u76EE\u899A\u307E\u3057\u3046\u308B\u3055\u3044\u3057\u5BB6\u306E\u524D\u3067\u5F35\u3063\u3066\u308C\u3070\u53EF\u80FD[\u8D77\u304D\u305F\u77AC\u9593\u30A4\u30F3\u30BF\u30FC\u30DB\u30F3]",
  "id" : 368684195507216384,
  "created_at" : "2013-08-17 10:42:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368679827085086721",
  "geo" : { },
  "id_str" : "368683956373180416",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u306A\u306B\u305D\u308C\u3053\u308F\u3044",
  "id" : 368683956373180416,
  "in_reply_to_status_id" : 368679827085086721,
  "created_at" : "2013-08-17 10:41:19 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368675177694904320",
  "text" : "\u4E00\u6642\u9593\u3076\u308A\u306B\u643A\u5E2F\u89E6\u3063\u305F\u77AC\u9593\u30E1\u30FC\u30EB\u6765\u305F\u3057\u306F\u3050\u308B\u307E\u3055\u3093\u30A8\u30B9\u30D1\u30FC\u304B",
  "id" : 368675177694904320,
  "created_at" : "2013-08-17 10:06:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368644488014491648",
  "text" : "\u7CBE\u795E\u885B\u751F\u306B\u3082\u826F\u3044\u6C17\u304C\u3059\u308B",
  "id" : 368644488014491648,
  "created_at" : "2013-08-17 08:04:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368644414194720768",
  "text" : "\u663C\u304B\u3089\u92AD\u6E6F\u306E\u5E78\u305B\u307F",
  "id" : 368644414194720768,
  "created_at" : "2013-08-17 08:04:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368628220045701120",
  "geo" : { },
  "id_str" : "368628509284904960",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u9152\u76D7\u304B\u5869\u8F9B\u3081\u3044\u305F\u3082\u306E\u3042\u3063\u305F\u3089\u8CB7\u3063\u3066\u304D\u3061\u304F\u308A\u30FC[\u304A\u91D1\u306F\u6255\u3044\u307E\u3059\u3057]",
  "id" : 368628509284904960,
  "in_reply_to_status_id" : 368628220045701120,
  "created_at" : "2013-08-17 07:01:00 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368625260511256578",
  "text" : "\u3053\u306E\u524D\u934B\u98DF\u3079\u305F\u3057\u304A\u3067\u3093\u98DF\u3079\u305F\u3044",
  "id" : 368625260511256578,
  "created_at" : "2013-08-17 06:48:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368623768526004226",
  "text" : "\u59CB\u3081\u3066\/\u521D\u3081\u3066",
  "id" : 368623768526004226,
  "created_at" : "2013-08-17 06:42:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368623553291112448",
  "text" : "\u6211\u3005Twitter\u521D\u3081\u3066\u304B\u3089\u30A2\u30A4\u30B3\u30F3\u307B\u307C\u56FA\u5B9A\u52E2\u3068\u3057\u3066\u3082\u3060\u306A\u2026",
  "id" : 368623553291112448,
  "created_at" : "2013-08-17 06:41:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7vOYRNIpGD",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368613682999070720",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/7vOYRNIpGD",
  "id" : 368613682999070720,
  "created_at" : "2013-08-17 06:02:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368558374415130624",
  "text" : "\u30D1\u30B7\u30D5\u30A3\u30C3\u30AF\u30EA\u30E0\u3063\u3066\u898B\u308B\u305F\u3073\u306B\u30B9\u30AB\u30A4\u30EA\u30E0\u306E\u65B0\u4F5C\u306E\u5302\u3044\u3092\u611F\u3058\u308B\u306E\u3084\u3081\u305F\u3044",
  "id" : 368558374415130624,
  "created_at" : "2013-08-17 02:22:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368550393099202561",
  "text" : "\u300C\u30B4\u30EA\u30E9\u3092\u4E0A\u3052\u305F\u304F\u3066\u3042\u3052\u308B\u3093\u3058\u3083\u306A\u3044\u4E0A\u304C\u3063\u3066\u3057\u307E\u3046\u8005\u304C\u30B4\u30EA\u30E9\u300D",
  "id" : 368550393099202561,
  "created_at" : "2013-08-17 01:50:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    }, {
      "name" : "\u3046\u3093\u3053\u3051\u3068\u307F",
      "screen_name" : "_Mosstomi",
      "indices" : [ 16, 26 ],
      "id_str" : "1436955463",
      "id" : 1436955463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368549810447458304",
  "geo" : { },
  "id_str" : "368549956849659904",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji @_Mosstomi \u307F\u3093\u306A\u3001\u751F\u304D\u3066\u3044\u308B",
  "id" : 368549956849659904,
  "in_reply_to_status_id" : 368549810447458304,
  "created_at" : "2013-08-17 01:48:51 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    }, {
      "name" : "\u3046\u3093\u3053\u3051\u3068\u307F",
      "screen_name" : "_Mosstomi",
      "indices" : [ 16, 26 ],
      "id_str" : "1436955463",
      "id" : 1436955463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368549297756712960",
  "geo" : { },
  "id_str" : "368549655476322305",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji @_Mosstomi \u30C1\u30F3\u30D1\u30F3\u30B8\u30FC\u3068\u30B4\u30EA\u30E9\u3068\u304B\u3001\u7A2E\u65CF\u306E\u5DEE\u306B\u3060\u3051\u76EE\u3092\u7791\u308C\u3070\u4F3C\u305F\u3088\u3046\u306A\u3082\u3093\u3060\u308D\uFF01\uFF01\uFF01\uFF01",
  "id" : 368549655476322305,
  "in_reply_to_status_id" : 368549297756712960,
  "created_at" : "2013-08-17 01:47:39 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368549384251654144",
  "text" : "\u7532\u5B50\u5712\u306E\u7802\u304B\u3051\u5A46\u5A46 \u3068\u306F",
  "id" : 368549384251654144,
  "created_at" : "2013-08-17 01:46:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368549276026023936",
  "text" : "RT @shigmax: \u51B7\u9759\u306B\u8003\u3048\u305F\u3089\u7532\u5B50\u5712\u306E\u7802\u6301\u3061\u5E30\u3063\u3066\u3082\u98DF\u3046\u308F\u3051\u3067\u3082\u98FE\u308B\u308F\u3051\u3067\u3082\u306A\u3044\u3057\u6848\u5916\u90AA\u9B54\u3060\u306A\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368549245327929345",
    "text" : "\u51B7\u9759\u306B\u8003\u3048\u305F\u3089\u7532\u5B50\u5712\u306E\u7802\u6301\u3061\u5E30\u3063\u3066\u3082\u98DF\u3046\u308F\u3051\u3067\u3082\u98FE\u308B\u308F\u3051\u3067\u3082\u306A\u3044\u3057\u6848\u5916\u90AA\u9B54\u3060\u306A\uFF1F",
    "id" : 368549245327929345,
    "created_at" : "2013-08-17 01:46:02 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 368549276026023936,
  "created_at" : "2013-08-17 01:46:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u3059\u3061",
      "screen_name" : "k49taku_misty",
      "indices" : [ 0, 14 ],
      "id_str" : "505403850",
      "id" : 505403850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368548363781693441",
  "geo" : { },
  "id_str" : "368548443754467328",
  "in_reply_to_user_id" : 505403850,
  "text" : "@k49taku_misty \u3084\u3081\u3088\u3046",
  "id" : 368548443754467328,
  "in_reply_to_status_id" : 368548363781693441,
  "created_at" : "2013-08-17 01:42:50 +0000",
  "in_reply_to_screen_name" : "k49taku_misty",
  "in_reply_to_user_id_str" : "505403850",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u3059\u3061",
      "screen_name" : "k49taku_misty",
      "indices" : [ 0, 14 ],
      "id_str" : "505403850",
      "id" : 505403850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368548127306813440",
  "geo" : { },
  "id_str" : "368548242998304769",
  "in_reply_to_user_id" : 505403850,
  "text" : "@k49taku_misty \u30A2\u30C3\u30CF\u30A4\u30DF\u30CA\u30AB\u30C3\u30BF\u30B3\u30C8\u30CB\u30B7\u30C6\u30AF\u30C0\u30B5\u30A4",
  "id" : 368548242998304769,
  "in_reply_to_status_id" : 368548127306813440,
  "created_at" : "2013-08-17 01:42:03 +0000",
  "in_reply_to_screen_name" : "k49taku_misty",
  "in_reply_to_user_id_str" : "505403850",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368548093144223744",
  "text" : "\u9014\u4E2D\u3067\u30DF\u30B9\u3063\u305F\u306E\u306F\u306A\u3044\u3057\u3087",
  "id" : 368548093144223744,
  "created_at" : "2013-08-17 01:41:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368548011812458498",
  "text" : "\u300C\u666E\u901A\u306E\u4EBA\u9593\u306F\u5145\u96FB\u5668\u3092\u5FD8\u308C\u51FA\u5148\u306BiPhone\u306E\u5145\u96FB\u5668\u3057\u304B\u306A\u3044\u3068\u77E5\u308C\u3070\n\u6A5F\u7A2E\u5909\u66F4\u3057\u3088\u3046\u3068\u3070\u304B\u308A\u8003\u3048\u308B,\u3060\u304C\u3000\u82D4\u5BCC\u306F\u9055\u3063\u305F\uFF01\u9006\u306B\uFF01\u82D4\u5BCC\u306F\u306A\u3093\u3068\uFF01\u5145\u96FB\u5668\u3092\u8CB7\u3063\u305F\uFF01\u300D",
  "id" : 368548011812458498,
  "created_at" : "2013-08-17 01:41:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3046\u3093\u3053\u3051\u3068\u307F",
      "screen_name" : "_Mosstomi",
      "indices" : [ 0, 10 ],
      "id_str" : "1436955463",
      "id" : 1436955463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368547095621283841",
  "geo" : { },
  "id_str" : "368547197677101056",
  "in_reply_to_user_id" : 1436955463,
  "text" : "@_Mosstomi \u5145\u96FB\u5668\u3092\u8CB7\u3046\u3068\u304B\u5727\u5012\u7684\u9583\u304D",
  "id" : 368547197677101056,
  "in_reply_to_status_id" : 368547095621283841,
  "created_at" : "2013-08-17 01:37:53 +0000",
  "in_reply_to_screen_name" : "_Mosstomi",
  "in_reply_to_user_id_str" : "1436955463",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368546827127103490",
  "text" : "\u30C4\u30C3\u30B3\u30DF\u304C\u4E0D\u5728\u3068\u3044\u3046\u3053\u3068\u306F,\u3064\u307E\u308A,\u30C4\u30C3\u30B3\u30DF\u3092\u3059\u308B\u4EBA\u304C\u3044\u306A\u3044,\u3068\u3044\u3046\u3053\u3068\u3067\u3042\u308B.",
  "id" : 368546827127103490,
  "created_at" : "2013-08-17 01:36:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3046\u3093\u3053\u3051\u3068\u307F",
      "screen_name" : "_Mosstomi",
      "indices" : [ 0, 10 ],
      "id_str" : "1436955463",
      "id" : 1436955463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368546411672911872",
  "geo" : { },
  "id_str" : "368546615138611200",
  "in_reply_to_user_id" : 1436955463,
  "text" : "@_Mosstomi \u5B9F\u969B\u3053\u308C\u3092\u898B\u843D\u3068\u3057\u3066\u3044\u305F\u305B\u3044\u3067\u591A\u304F\u306E\u4EBA\u304C\u547D\u3092\u843D\u3068\u3057\u3066\u3044\u308B.\u5099\u3048\u3088\u3046.",
  "id" : 368546615138611200,
  "in_reply_to_status_id" : 368546411672911872,
  "created_at" : "2013-08-17 01:35:34 +0000",
  "in_reply_to_screen_name" : "_Mosstomi",
  "in_reply_to_user_id_str" : "1436955463",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3046\u3093\u3053\u3051\u3068\u307F",
      "screen_name" : "_Mosstomi",
      "indices" : [ 0, 10 ],
      "id_str" : "1436955463",
      "id" : 1436955463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368545982406852608",
  "geo" : { },
  "id_str" : "368546123092209664",
  "in_reply_to_user_id" : 1436955463,
  "text" : "@_Mosstomi \u305D\u308C\u3058\u3083\u5145\u96FB\u5668\u306E\u554F\u984C\u304C\u89E3\u6C7A\u3057\u306D\u3047wwwww",
  "id" : 368546123092209664,
  "in_reply_to_status_id" : 368545982406852608,
  "created_at" : "2013-08-17 01:33:37 +0000",
  "in_reply_to_screen_name" : "_Mosstomi",
  "in_reply_to_user_id_str" : "1436955463",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3046\u3093\u3053\u3051\u3068\u307F",
      "screen_name" : "_Mosstomi",
      "indices" : [ 0, 10 ],
      "id_str" : "1436955463",
      "id" : 1436955463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368544601365155840",
  "geo" : { },
  "id_str" : "368545078173630464",
  "in_reply_to_user_id" : 1436955463,
  "text" : "@_Mosstomi iPhone\u306B\u6A5F\u7A2E\u5909\u3057\u3066\u884C\u3051\u3070\u826F\u3044\u306E\u3067\u306F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 368545078173630464,
  "in_reply_to_status_id" : 368544601365155840,
  "created_at" : "2013-08-17 01:29:28 +0000",
  "in_reply_to_screen_name" : "_Mosstomi",
  "in_reply_to_user_id_str" : "1436955463",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368544291330609153",
  "text" : "\u4E88\u5B9A\u3055\u308C\u3066\u3044\u308B\u672C\u65E5\u306E\u5916\u51FA\u306F\u4EE5\u4E0A\u306B\u306A\u308A\u307E\u3059.",
  "id" : 368544291330609153,
  "created_at" : "2013-08-17 01:26:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368401194613370880",
  "text" : "\u304A\u3084\u3059\u307F.",
  "id" : 368401194613370880,
  "created_at" : "2013-08-16 15:57:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368401160232632320",
  "text" : "\u8C46\u8150\u30E1\u30F3\u30BF\u30EB\u306E\u4E0B\u306E\u6BB5\u968E\u3068\u3057\u3066\u304D\u306A\u7C89\u30E1\u30F3\u30BF\u30EB\u3068\u3044\u3046\u306E\u306F\u3069\u3046\u3060\u308D\u3046.\u5439\u3051\u3070\u98DB\u3076.",
  "id" : 368401160232632320,
  "created_at" : "2013-08-16 15:57:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368396087767232512",
  "text" : "\u6B7B\u306F\u60B2\u3057\u307F\u3092",
  "id" : 368396087767232512,
  "created_at" : "2013-08-16 15:37:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368394760215482370",
  "text" : "\u76F8\u624B\u304C\u3044\u306A\u3044\u304B\u3089\u5FC3\u914D\u306A\u3044\u306D\uFF01",
  "id" : 368394760215482370,
  "created_at" : "2013-08-16 15:32:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368394697086996480",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u3001\u81EA\u5B85\u3067\u98DF\u5F8C\u3068\u304B\u306B\u30B3\u30FC\u30D2\u30FC\u3068\u304B\u98F2\u307F\u306A\u304C\u3089\u300C\u7D50\u5A5A\u3059\u308B\u304B\u30FC\u300D\u304F\u3089\u3044\u306E\u30CE\u30EA\u3067\u30D7\u30ED\u30DD\u30FC\u30BA\u3057\u305F\u3044\u3093\u3060\u3051\u3069\u523A\u3055\u308C\u308B\u306A\uFF1F",
  "id" : 368394697086996480,
  "created_at" : "2013-08-16 15:31:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3068\u308A",
      "screen_name" : "Yutoric_Star",
      "indices" : [ 3, 16 ],
      "id_str" : "2978563700",
      "id" : 2978563700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/zcIu4cPWSg",
      "expanded_url" : "http:\/\/kanasoku.info\/articles\/22115.html",
      "display_url" : "kanasoku.info\/articles\/22115\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368394482082791424",
  "text" : "RT @Yutoric_Star: \u3010\u95B2\u89A7\u6CE8\u610F\u3011\u30D5\u30A1\u30DF\u30EC\u30B9\u3067\u30D7\u30ED\u30DD\u30FC\u30BA\u3057\u305F\u3089\u5927\u5909\u306A\u3053\u3068\u306B\u306A\u3063\u305F - \u30AB\u30CA\u901F http:\/\/t.co\/zcIu4cPWSg\n\u6C17\u6301\u3061\u306F\u308F\u304B\u3089\u3093\u3067\u3082\u306A\u3044\u304C\u30E4\u30D0\u3059\u304E\u3084\u308D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/zcIu4cPWSg",
        "expanded_url" : "http:\/\/kanasoku.info\/articles\/22115.html",
        "display_url" : "kanasoku.info\/articles\/22115\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "368392460973535232",
    "text" : "\u3010\u95B2\u89A7\u6CE8\u610F\u3011\u30D5\u30A1\u30DF\u30EC\u30B9\u3067\u30D7\u30ED\u30DD\u30FC\u30BA\u3057\u305F\u3089\u5927\u5909\u306A\u3053\u3068\u306B\u306A\u3063\u305F - \u30AB\u30CA\u901F http:\/\/t.co\/zcIu4cPWSg\n\u6C17\u6301\u3061\u306F\u308F\u304B\u3089\u3093\u3067\u3082\u306A\u3044\u304C\u30E4\u30D0\u3059\u304E\u3084\u308D",
    "id" : 368392460973535232,
    "created_at" : "2013-08-16 15:23:01 +0000",
    "user" : {
      "name" : "\u6D25\u826F\u3044\u3093\u3058\u3083\u301C",
      "screen_name" : "Z_Tsu_City",
      "protected" : false,
      "id_str" : "177194292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556984463444295681\/UT5S308X_normal.jpeg",
      "id" : 177194292,
      "verified" : false
    }
  },
  "id" : 368394482082791424,
  "created_at" : "2013-08-16 15:31:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368384739503128576",
  "text" : "\u3086\u304B\u308A\u3061\u3083\u3093\u6D3E\u304C\u591A\u3044\u306E\u304B\u306A\u2026 [\u3086\u3086\u5F0F]",
  "id" : 368384739503128576,
  "created_at" : "2013-08-16 14:52:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30F4\u30A7\u30EA\u30BA\u30FB\u30F4\u30A7\u30EB\u306E\u7FFC\u30C3\u30B7\u30D0\u30FC",
      "screen_name" : "asshibar",
      "indices" : [ 3, 12 ],
      "id_str" : "383109833",
      "id" : 383109833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368370421063639040",
  "text" : "RT @asshibar: \u300C\u304A\u8F9E\u5100\u3092\u3057\u308D\u30DD\u30C3\u30BF\u30FC!\u4F1D\u7D71\u3042\u308B\u683C\u5F0F\u306B\u306F\u5F93\u308F\u306D\u3070\u306A\u3089\u306C\u3002\u300D\u300C\u30C9\u30FC\u30E2\u3002\u30F4\u30A9\u30EB\u30C7\u30E2\u30FC\u30C8=\u30B5\u30F3\u3002\u30DD\u30C3\u30BF\u30FC\u3067\u3059\u3002\u300D\u300C\u30C9\u30FC\u30E2\u3002\u30DD\u30C3\u30BF\u30FC=\u30B5\u30F3\u3002\u30F4\u30A9\u30EB\u30C7\u30E2\u30FC\u30C8\u3067\u3059\u3002\u300D\u30A2\u30A4\u30B5\u30C4\u304B\u3089\u308F\u305A\u304B1\u79D2!\u300C\u300C\u30A4\u30E4\u30FC\u30C3!\u300D\u300D\u30CF\u30EA\u30C4\u30B1=\u30B8\u30C4\u3068\u30D6\u30BD\u30FC\u30FB\u30AB\u30A4\u30B8\u30E7=\u30B8\u30C4\u304C\u70B8\u88C2!\u304A\u4E92\u3044\u306E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199998962265104384",
    "text" : "\u300C\u304A\u8F9E\u5100\u3092\u3057\u308D\u30DD\u30C3\u30BF\u30FC!\u4F1D\u7D71\u3042\u308B\u683C\u5F0F\u306B\u306F\u5F93\u308F\u306D\u3070\u306A\u3089\u306C\u3002\u300D\u300C\u30C9\u30FC\u30E2\u3002\u30F4\u30A9\u30EB\u30C7\u30E2\u30FC\u30C8=\u30B5\u30F3\u3002\u30DD\u30C3\u30BF\u30FC\u3067\u3059\u3002\u300D\u300C\u30C9\u30FC\u30E2\u3002\u30DD\u30C3\u30BF\u30FC=\u30B5\u30F3\u3002\u30F4\u30A9\u30EB\u30C7\u30E2\u30FC\u30C8\u3067\u3059\u3002\u300D\u30A2\u30A4\u30B5\u30C4\u304B\u3089\u308F\u305A\u304B1\u79D2!\u300C\u300C\u30A4\u30E4\u30FC\u30C3!\u300D\u300D\u30CF\u30EA\u30C4\u30B1=\u30B8\u30C4\u3068\u30D6\u30BD\u30FC\u30FB\u30AB\u30A4\u30B8\u30E7=\u30B8\u30C4\u304C\u70B8\u88C2!\u304A\u4E92\u3044\u306E\u30B8\u30C4\u304C\u30AF\u30B5\u30EA\u3081\u3044\u3066\u3064\u306A\u304C\u308B!",
    "id" : 199998962265104384,
    "created_at" : "2012-05-08 23:07:23 +0000",
    "user" : {
      "name" : "\u30F4\u30A7\u30EA\u30BA\u30FB\u30F4\u30A7\u30EB\u306E\u7FFC\u30C3\u30B7\u30D0\u30FC",
      "screen_name" : "asshibar",
      "protected" : false,
      "id_str" : "383109833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598502265154998272\/EElf76ZR_normal.jpg",
      "id" : 383109833,
      "verified" : false
    }
  },
  "id" : 368370421063639040,
  "created_at" : "2013-08-16 13:55:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3083\u3093\u3075",
      "screen_name" : "nyamph_pf",
      "indices" : [ 2, 12 ],
      "id_str" : "107723928",
      "id" : 107723928
    }, {
      "name" : "\u5C0F\u6307",
      "screen_name" : "suwakoishi",
      "indices" : [ 13, 24 ],
      "id_str" : "107395166",
      "id" : 107395166
    }, {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 25, 33 ],
      "id_str" : "145536184",
      "id" : 145536184
    }, {
      "name" : "\u307F\u3084\u30BF\u30B3\u30B9(\u261D \u055E\u0A0A \u055E)\u261D",
      "screen_name" : "miya_tacos",
      "indices" : [ 34, 45 ],
      "id_str" : "747261714",
      "id" : 747261714
    }, {
      "name" : "Ivan",
      "screen_name" : "3dzin",
      "indices" : [ 46, 52 ],
      "id_str" : "3231433158",
      "id" : 3231433158
    }, {
      "name" : "\u7559\u3005\u6D6A\u4EBA\u306E\u3053\u306E\u3053",
      "screen_name" : "Far_east_turtle",
      "indices" : [ 53, 69 ],
      "id_str" : "277816120",
      "id" : 277816120
    }, {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 70, 79 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    }, {
      "name" : "\u725B\u5CF6",
      "screen_name" : "usijima_uoichi",
      "indices" : [ 80, 95 ],
      "id_str" : "162395025",
      "id" : 162395025
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 96, 105 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368347038208892928",
  "text" : ". @nyamph_pf @suwakoishi @chr1233 @miya_tacos @3dzin @Far_east_turtle @kaikyune @usijima_uoichi @nisehorn \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 368347038208892928,
  "created_at" : "2013-08-16 12:22:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "3dzin",
      "indices" : [ 0, 6 ],
      "id_str" : "3231433158",
      "id" : 3231433158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368338064306745344",
  "text" : "@3dzin \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01\uFF01",
  "id" : 368338064306745344,
  "created_at" : "2013-08-16 11:46:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368337042884673536",
  "text" : "\u3061\u3083\u3052\u3068\u304B\u805E\u3053\u3048\u305F[\u8FB2\u5B66\u90E8\u30B0\u30E9\u30A6\u30F3\u30C9]",
  "id" : 368337042884673536,
  "created_at" : "2013-08-16 11:42:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368329092153626625",
  "text" : "\u3042\u3048\u3066\u7B49\u500D\u3067\u304A\u9001\u308A\u3057\u3066\u3044\u307E\u3059",
  "id" : 368329092153626625,
  "created_at" : "2013-08-16 11:11:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/368329031457853440\/photo\/1",
      "indices" : [ 2, 24 ],
      "url" : "http:\/\/t.co\/f7P6BmLXzA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRyRTXjCUAAZyje.jpg",
      "id_str" : "368329031462047744",
      "id" : 368329031462047744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRyRTXjCUAAZyje.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/f7P6BmLXzA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368329031457853440",
  "text" : "\u5927 http:\/\/t.co\/f7P6BmLXzA",
  "id" : 368329031457853440,
  "created_at" : "2013-08-16 11:10:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368328067476758529",
  "text" : "Gozan in frame",
  "id" : 368328067476758529,
  "created_at" : "2013-08-16 11:07:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368327989366255616",
  "text" : "\u4EAC\u90FD\u306E\u5C71\u304C\u3001\u71C3\u3048\u3066\u3044\u308B",
  "id" : 368327989366255616,
  "created_at" : "2013-08-16 11:06:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan",
      "screen_name" : "3dzin",
      "indices" : [ 0, 6 ],
      "id_str" : "3231433158",
      "id" : 3231433158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368327747719806976",
  "text" : "@3dzin \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 368327747719806976,
  "created_at" : "2013-08-16 11:05:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368327569487065090",
  "geo" : { },
  "id_str" : "368327667176587264",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 368327667176587264,
  "in_reply_to_status_id" : 368327569487065090,
  "created_at" : "2013-08-16 11:05:33 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368327470501474304",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 368327470501474304,
  "created_at" : "2013-08-16 11:04:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368327419502927872",
  "text" : "\u307C\u3063\u3061\u9001\u308A\u706B\u3041",
  "id" : 368327419502927872,
  "created_at" : "2013-08-16 11:04:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368326759302717440",
  "text" : "4\u5E74\u3081\u306B\u3057\u3066\u4E94\u5C71\u773A\u3081\u3066\u308B",
  "id" : 368326759302717440,
  "created_at" : "2013-08-16 11:01:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368230489737265152",
  "text" : "\u5DE6\u8155\u304C\u91CD\u304F\u3066\u75DB\u3044\u3093\u3060\u3051\u3069\u3053\u308C\u3084\u3070\u304F\u306A\u3044\u304B",
  "id" : 368230489737265152,
  "created_at" : "2013-08-16 04:39:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368204652564578304",
  "geo" : { },
  "id_str" : "368204913127325696",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u3067\u306F18:30\u306B\u3057\u307E\u3057\u3087\u3046\u3002\u5FA1\u852D\u306E\u751F\u9BAE\u9928\u3042\u305F\u308A\u3067\u3002",
  "id" : 368204913127325696,
  "in_reply_to_status_id" : 368204652564578304,
  "created_at" : "2013-08-16 02:57:46 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368203969383776256",
  "geo" : { },
  "id_str" : "368204490278588417",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u6642\u9593\u3069\u3046\u3057\u307E\u3057\u3087\uFF1F19\u6642\u304F\u3089\u3044\uFF1F",
  "id" : 368204490278588417,
  "in_reply_to_status_id" : 368203969383776256,
  "created_at" : "2013-08-16 02:56:06 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367953331177525250",
  "geo" : { },
  "id_str" : "368203900186152961",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u304A\u597D\u307F\u713C\u304D\u3067\u3082\u98DF\u3079\u306B\u884C\u304D\u307E\u3059\u304B\u30FC",
  "id" : 368203900186152961,
  "in_reply_to_status_id" : 367953331177525250,
  "created_at" : "2013-08-16 02:53:45 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367978932835872769",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 367978932835872769,
  "created_at" : "2013-08-15 11:59:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367948814109253632",
  "geo" : { },
  "id_str" : "367949233560621057",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u3042\u3093\u307E\u308A\u304A\u9AD8\u3044\u3082\u306E\u306F\u3064\u3089\u3044\u306E\u3067\u9069\u5EA6\u306A\u3068\u3053\u308D\u3067\u2026",
  "id" : 367949233560621057,
  "in_reply_to_status_id" : 367948814109253632,
  "created_at" : "2013-08-15 10:01:48 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367948773604851713",
  "text" : "\u304F\u3089\u307E\u3050\u3061\u304B\u3089\u3042\u308B\u304F",
  "id" : 367948773604851713,
  "created_at" : "2013-08-15 09:59:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367946556936183808",
  "text" : "\u8377\u7269\u3082\u3055\u3057\u3066\u91CD\u304F\u306A\u3044\u3057\u30BF\u30AF\u30B7\u30FC\u306F\u304A\u9810\u3051\u304B\u306A\u30FC\u30FC",
  "id" : 367946556936183808,
  "created_at" : "2013-08-15 09:51:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367944568534073344",
  "geo" : { },
  "id_str" : "367944969228525569",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u660E\u65E5\u306A\u3089\u591C\u306B\u3001\u3042\u3055\u3063\u3066\u306A\u3089\u3044\u3064\u3067\u3082\u5927\u4E08\u592B\u3067\u3059\u3088\u30FC\u3002[\u4F55\u3092\u3001\u306B\u3064\u3044\u3066\u306F\u7279\u306B\u98DF\u3079\u305F\u3044\u3082\u306E\u304C\u6D6E\u304B\u3073\u307E\u305B\u3093\u304C\u98DF\u3079\u305F\u3044\u3082\u306E\u3042\u3063\u305F\u3089\u3069\u3046\u305E]",
  "id" : 367944969228525569,
  "in_reply_to_status_id" : 367944568534073344,
  "created_at" : "2013-08-15 09:44:51 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367944223816814592",
  "geo" : { },
  "id_str" : "367944402888437761",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u7A81\u7136\u3067\u3059\u306D\u30FC\u3001\u3044\u3044\u3067\u3059\u3088\u30FC",
  "id" : 367944402888437761,
  "in_reply_to_status_id" : 367944223816814592,
  "created_at" : "2013-08-15 09:42:36 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367941809785147392",
  "geo" : { },
  "id_str" : "367943958124457984",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u4ECA\u307E\u3055\u306B\u4EAC\u90FD\u99C5\u3067\u3059\u304C\uFF1F\uFF1F",
  "id" : 367943958124457984,
  "in_reply_to_status_id" : 367941809785147392,
  "created_at" : "2013-08-15 09:40:50 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367941310000275456",
  "text" : "\u4EBA\u306E\u3075\u308A\u307F\u3066\u6211\u304C\u3075\u308A\u306A\u3093\u3061\u3083\u3089\u306F\u660E\u8A00\u3060\u3001\u306A\u3041",
  "id" : 367941310000275456,
  "created_at" : "2013-08-15 09:30:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367940478487891968",
  "text" : "\u9060\u304F\u304B\u3089\u5E30\u3063\u3066\u304D\u305F\u3051\u3069\u9060\u304F\u306B\u51FA\u639B\u3051\u305F\u3044\u306A\u3041\u3068\u601D\u3046\u3042\u305F\u308A\u305F\u3076\u3093\u4F55\u51E6\u306B\u3044\u3066\u3082\u305D\u3046\u601D\u3046",
  "id" : 367940478487891968,
  "created_at" : "2013-08-15 09:27:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367911910533906433",
  "text" : "\u79C1\u306E\u4E0D\u5728\u304C\u304B\u304F\u306E\u3054\u3068\u304D\u5F71\u97FF\u3092\u751F\u3082\u3046\u3068\u306F",
  "id" : 367911910533906433,
  "created_at" : "2013-08-15 07:33:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367911197086990337",
  "text" : "\u5927\u62B5\u306E\u79C1\u306E\u6020\u6162\u3067\u3042\u308B",
  "id" : 367911197086990337,
  "created_at" : "2013-08-15 07:30:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nf_spitz",
      "screen_name" : "nf_spitz",
      "indices" : [ 0, 9 ],
      "id_str" : "134141604",
      "id" : 134141604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367910583594536961",
  "geo" : { },
  "id_str" : "367911103709188096",
  "in_reply_to_user_id" : 134141604,
  "text" : "@nf_spitz \u629C\u3051\u3066\u308B\u3063\u3066\u306E\u304C\u30CE\u30FC\u30C8\u3042\u308B\u3051\u3069\u30C7\u30FC\u30BF\u306B\u306A\u3063\u3066\u306A\u3044\u3063\u3066\u306E\u3060\u304B\u3089\u79C1\u306E\u6020\u6162\u3067\u3059\u3059\u307F\u307E\u305B\u3093",
  "id" : 367911103709188096,
  "in_reply_to_status_id" : 367910583594536961,
  "created_at" : "2013-08-15 07:30:17 +0000",
  "in_reply_to_screen_name" : "nf_spitz",
  "in_reply_to_user_id_str" : "134141604",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367910920384544768",
  "text" : "\u904E\u5EA6\u306A\u30B9\u30AD\u30F3\u30B7\u30C3\u30D7\u3068\u3044\u3046\u8A00\u8449\u306E\"\u305D\u308C\u3044\u3058\u3081\u3067\u306F\uFF1F\"\u611F\u306F\u51C4\u307E\u3058\u3044",
  "id" : 367910920384544768,
  "created_at" : "2013-08-15 07:29:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367910822334304257",
  "text" : "\u3044\u3058\u3081\u306E\u4E8B\u5B9F\u306F\u78BA\u8A8D\u3055\u308C\u306A\u304B\u3063\u305F\u304C\u3001\u4E00\u90E8\u3067\u904E\u5EA6\u306A\u30B9\u30AD\u30F3\u30B7\u30C3\u30D7\u304C\u898B\u3089\u308C\u305F.",
  "id" : 367910822334304257,
  "created_at" : "2013-08-15 07:29:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 16, 25 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367910594734616576",
  "text" : "RT @akeopyaa: \u4FFA\uFF08@akeopyaa\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u8266\u5A18",
        "screen_name" : "akeopyaa",
        "indices" : [ 2, 11 ],
        "id_str" : "112398542",
        "id" : 112398542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367910375313793025",
    "text" : "\u4FFA\uFF08@akeopyaa\uFF09",
    "id" : 367910375313793025,
    "created_at" : "2013-08-15 07:27:23 +0000",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 367910594734616576,
  "created_at" : "2013-08-15 07:28:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nf_spitz",
      "screen_name" : "nf_spitz",
      "indices" : [ 0, 9 ],
      "id_str" : "134141604",
      "id" : 134141604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367909598503510016",
  "geo" : { },
  "id_str" : "367909964536242176",
  "in_reply_to_user_id" : 134141604,
  "text" : "@nf_spitz \u5E30\u5B85\u3057\u305F\u3089\u78BA\u8A8D\u3057\u307E\u3059[\u4E00\u5E74\u5206\u629C\u3051\u3066\u305F\u8A18\u61B6\u304C\u3042\u308A\u307E\u3059]",
  "id" : 367909964536242176,
  "in_reply_to_status_id" : 367909598503510016,
  "created_at" : "2013-08-15 07:25:45 +0000",
  "in_reply_to_screen_name" : "nf_spitz",
  "in_reply_to_user_id_str" : "134141604",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367909786802585600",
  "text" : "\u3053\u306E\u62EC\u5F27\u306E\u4E2D\u306B\u30A2\u30AB\u30A6\u30F3\u30C8\u540D\u304B\u3044\u3066\u305D\u306E\u4EBA\u306E\u8A71\u3059\u308B\u306E\u3001\u805E\u3053\u3048\u3066\u308B\u3068\u5206\u304B\u3063\u3066\u308B\u4F4D\u7F6E\u3067\u9670\u53E3\u8A00\u3046\u3081\u3044\u305F\u9670\u6E7F\u3055\u304C\u3042\u308B",
  "id" : 367909786802585600,
  "created_at" : "2013-08-15 07:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "CompactHausdorff\u5C71\u7530",
      "screen_name" : "NoriMathTp",
      "indices" : [ 51, 62 ],
      "id_str" : "231358679",
      "id" : 231358679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367908435808899072",
  "geo" : { },
  "id_str" : "367909069505318912",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u4F8B\u3048\u305D\u3046\u3044\u3046\u3084\u3064\u304C\u3044\u305F\u3068\u3057\u3066\u3082\u5BDB\u5BB9\u306A\u6C17\u6301\u3061\u3067\u8A31\u3057\u3066\u3084\u308D\u3046\u305C\uFF01\uFF01\uFF01( @NoriMathTp )",
  "id" : 367909069505318912,
  "in_reply_to_status_id" : 367908435808899072,
  "created_at" : "2013-08-15 07:22:12 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367908741955330048",
  "text" : "\u9593\u3082\u306A\u304F\u9759\u5CA1\u7A0B\u5EA6\u306E\u6A5F\u52D5\u529B",
  "id" : 367908741955330048,
  "created_at" : "2013-08-15 07:20:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367903507149361153",
  "text" : "\u65B0\u5E79\u7DDA\u5B9F\u969B\u30CF\u30E4\u30A4",
  "id" : 367903507149361153,
  "created_at" : "2013-08-15 07:00:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367900013029912576",
  "text" : "\u30BF\u30D0\u30B3\u304F\u3055\u3044\u304C\u6587\u53E5\u8A00\u3048\u306C\u2026",
  "id" : 367900013029912576,
  "created_at" : "2013-08-15 06:46:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367894462942289921",
  "text" : "\u6307\u5B9A\u5E2D\u3001\u55AB\u7159\u5E2D\u3057\u304B\u7A7A\u3044\u3066\u306A\u304F\u3066\u3064\u3089\u307F",
  "id" : 367894462942289921,
  "created_at" : "2013-08-15 06:24:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367886427448561664",
  "text" : "\u4F55\u3082\u304B\u3082\u3042\u30FC",
  "id" : 367886427448561664,
  "created_at" : "2013-08-15 05:52:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367875322399584257",
  "text" : "\u6717\u5831:\u5EA7\u308C\u305F",
  "id" : 367875322399584257,
  "created_at" : "2013-08-15 05:08:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367874994958655489",
  "text" : "\u30AB\u30BF\u30BB\u30B7\u30E9\u30BF",
  "id" : 367874994958655489,
  "created_at" : "2013-08-15 05:06:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367874557383696385",
  "text" : "\u8ECA\u306F\u6700\u5F37\u306E\u79FB\u52D5\u30C4\u30FC\u30EB\u3067\u3042\u308B\u3068\u518D\u8A8D\u8B58\u3057\u305F.",
  "id" : 367874557383696385,
  "created_at" : "2013-08-15 05:05:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367872592645873664",
  "text" : "\u6D77\u304C\u898B\u3048\u3066\u5B9F\u969B\u826F\u3044\u666F\u8272",
  "id" : 367872592645873664,
  "created_at" : "2013-08-15 04:57:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367872222683086849",
  "text" : "\u771F\u590F\u306E\u65B9\u7A0B\u5F0F\u306E\u30ED\u30B1\u5730\u3053\u306E\u8FBA\u3060\u3063\u305F\u307D\u3044",
  "id" : 367872222683086849,
  "created_at" : "2013-08-15 04:55:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367871890393550849",
  "text" : "3\u4E21\u3057\u304B\u306A\u3044\u304B\u3089\u4ED5\u65B9\u306A\u3044\u306A",
  "id" : 367871890393550849,
  "created_at" : "2013-08-15 04:54:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367871793534476289",
  "text" : "\u305D\u306E\u4E0A\u306BDQN\u3081\u3044\u305F\u4EBA\u3005\u304C\u5730\u3079\u305F\u306B\u5EA7\u3063\u3066\u5927\u5BCC\u8C6A\u3081\u3044\u305F\u3053\u3068\u3057\u3066\u3066\u30DE\u30C3\u30DD\u30FC",
  "id" : 367871793534476289,
  "created_at" : "2013-08-15 04:54:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367871544074059776",
  "text" : "\u60B2\u5831:\u6DF7\u3093\u3067\u308B",
  "id" : 367871544074059776,
  "created_at" : "2013-08-15 04:53:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367871084311244800",
  "text" : "\u3053\u3093\u3067\u306A\u3044\u3068\u3044\u3044\u306A",
  "id" : 367871084311244800,
  "created_at" : "2013-08-15 04:51:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/VDXULT1dz5",
      "expanded_url" : "http:\/\/4sq.com\/16MmFBQ",
      "display_url" : "4sq.com\/16MmFBQ"
    } ]
  },
  "geo" : { },
  "id_str" : "367869948607348736",
  "text" : "\u67D0\u5927\u5148\u751F\u306F\u95A2\u4FC2\u306A\u3044. (@ \u6CB3\u6D25\u99C5 (Kawazu Sta.)) http:\/\/t.co\/VDXULT1dz5",
  "id" : 367869948607348736,
  "created_at" : "2013-08-15 04:46:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367867869154914304",
  "text" : "\u305D\u3046\u304B\u30018\u670815\u65E5\u304B.",
  "id" : 367867869154914304,
  "created_at" : "2013-08-15 04:38:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/367820504620470273\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/x9vh6Z9O9W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRrCzNeCEAEu_Ly.jpg",
      "id_str" : "367820504628858881",
      "id" : 367820504628858881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRrCzNeCEAEu_Ly.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/x9vh6Z9O9W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367820504620470273",
  "text" : "\u5F53\u3066\u3066\u3084\u308D\u3046\u304B\uFF1F\u8AB0\u304B\u306B\u30B9\u30A4\u30FC\u30C8\u30ED\u30FC\u30EB\u3092\u76D7\u307E\u308C\u305F\u304B\u306A\uFF1F http:\/\/t.co\/x9vh6Z9O9W",
  "id" : 367820504620470273,
  "created_at" : "2013-08-15 01:30:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/LTUn8xsr0y",
      "expanded_url" : "http:\/\/4sq.com\/19rV26y",
      "display_url" : "4sq.com\/19rV26y"
    } ]
  },
  "geo" : { },
  "id_str" : "367514809539256320",
  "text" : "\u7F8E\u5473\u3057\u304B\u3063\u305F (@ \u6771\u5E9C\u3084 \u30D9\u30FC\u30AB\u30EA\u30FC&amp;\u30AB\u30D5\u30A7) http:\/\/t.co\/LTUn8xsr0y",
  "id" : 367514809539256320,
  "created_at" : "2013-08-14 05:15:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6E56\u795E\u97F3\u30B7\u30F3\u30BA\u30A9\u30FC",
      "screen_name" : "kogamine",
      "indices" : [ 3, 12 ],
      "id_str" : "70957921",
      "id" : 70957921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367278070924722177",
  "text" : "RT @kogamine: \u4FFA\u300C\u524D\u6B6F\u304C\u6B20\u3051\u3066\u3057\u307E\u3063\u3066\u2026\u2026\u300D\n\n\u6B6F\u533B\u8005\u300C\u3069\u3053\u304B\u306B\u3076\u3064\u3051\u305F\u3093\u3067\u3059\u304B\uFF1F\u300D\n\n\u4FFA\u300C\u3042\u305A\u304D\u30D0\u30FC\u3092\u98DF\u3079\u3066\u3066\u2026\u2026\u300D\n\n\u6B6F\u533B\u8005\u300C\u305D\u308C\u306F\u4ED5\u65B9\u306A\u3044\u3067\u3059\u306D\u3002\u590F\u5834\u306F\u591A\u3044\u3093\u3067\u3059\u3088\u3001\u3042\u305A\u304D\u30D0\u30FC\u306B\u8CA0\u3051\u308B\u4EBA\u300D\n\n \uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E \u3042\u305A\u304D\u30D0\u30FC\u306B\u8CA0\u3051\u308B\u4EBA \uFF1C\n\uFFE3Y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367176471237754880",
    "text" : "\u4FFA\u300C\u524D\u6B6F\u304C\u6B20\u3051\u3066\u3057\u307E\u3063\u3066\u2026\u2026\u300D\n\n\u6B6F\u533B\u8005\u300C\u3069\u3053\u304B\u306B\u3076\u3064\u3051\u305F\u3093\u3067\u3059\u304B\uFF1F\u300D\n\n\u4FFA\u300C\u3042\u305A\u304D\u30D0\u30FC\u3092\u98DF\u3079\u3066\u3066\u2026\u2026\u300D\n\n\u6B6F\u533B\u8005\u300C\u305D\u308C\u306F\u4ED5\u65B9\u306A\u3044\u3067\u3059\u306D\u3002\u590F\u5834\u306F\u591A\u3044\u3093\u3067\u3059\u3088\u3001\u3042\u305A\u304D\u30D0\u30FC\u306B\u8CA0\u3051\u308B\u4EBA\u300D\n\n \uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E \u3042\u305A\u304D\u30D0\u30FC\u306B\u8CA0\u3051\u308B\u4EBA \uFF1C\n\uFFE3Y^Y^Y^Y^Y^Y^Y^Y^",
    "id" : 367176471237754880,
    "created_at" : "2013-08-13 06:51:07 +0000",
    "user" : {
      "name" : "\u6E56\u795E\u97F3\u30B7\u30F3\u30BA\u30A9\u30FC",
      "screen_name" : "kogamine",
      "protected" : false,
      "id_str" : "70957921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606394292618170368\/y5I5WsJ3_normal.png",
      "id" : 70957921,
      "verified" : false
    }
  },
  "id" : 367278070924722177,
  "created_at" : "2013-08-13 13:34:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367254195130212352",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 367254195130212352,
  "created_at" : "2013-08-13 11:59:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367251792158932992",
  "text" : "\"\u81EA\u5206\u306E\u904B\u8EE2\u306A\u3089\u9154\u308F\u306A\u3044\"\u306F\u5618.\u30BD\u30FC\u30B9\u306F\u79C1.",
  "id" : 367251792158932992,
  "created_at" : "2013-08-13 11:50:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367218422737674241",
  "text" : "\u60AA\u3044\u30D5\u30A1\u30DF\u30DE\u3092\u78BA\u8A8D",
  "id" : 367218422737674241,
  "created_at" : "2013-08-13 09:37:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/msNv0HTuRY",
      "expanded_url" : "http:\/\/4sq.com\/13wWFYG",
      "display_url" : "4sq.com\/13wWFYG"
    } ]
  },
  "geo" : { },
  "id_str" : "367218245658771456",
  "text" : "I'm at \u8DB3\u67C4SA \u4E0B\u308A EXPASA\u8DB3\u67C4 (\u99FF\u6771\u90E1, \u9759\u5CA1\u770C) w\/ 4 others http:\/\/t.co\/msNv0HTuRY",
  "id" : 367218245658771456,
  "created_at" : "2013-08-13 09:37:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/gubipdVnH2",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=gyuudon025",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367107904827965441",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/gubipdVnH2",
  "id" : 367107904827965441,
  "created_at" : "2013-08-13 02:18:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366851850768621569",
  "text" : "\u96E8\u3088\u308A\u96F7\u306E\u65B9\u304C\u964D\u3063\u3066\u308B\u611F\u3058",
  "id" : 366851850768621569,
  "created_at" : "2013-08-12 09:21:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366851730895421440",
  "text" : "\u306A\u304A\u3063\u305F",
  "id" : 366851730895421440,
  "created_at" : "2013-08-12 09:20:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366851706572644352",
  "text" : "\u96F7\u3067\u505C\u96FB\u2026",
  "id" : 366851706572644352,
  "created_at" : "2013-08-12 09:20:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/366752099062644741\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/ixxFgdMClV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRb3F0mCAAA-Jh8.jpg",
      "id_str" : "366752099066839040",
      "id" : 366752099066839040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRb3F0mCAAA-Jh8.jpg",
      "sizes" : [ {
        "h" : 452,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ixxFgdMClV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366752099062644741",
  "text" : "\u3084\u308B\u6C17\u30D3\u30FC\u30E0\u3063\uFF01\uFF01\uFF01 http:\/\/t.co\/ixxFgdMClV",
  "id" : 366752099062644741,
  "created_at" : "2013-08-12 02:44:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366751806434451456",
  "text" : "\u30DC\u30EB\u30C8\u304C\u3084\u308B\u6C17\u30D3\u30FC\u30E0\u51FA\u3057\u3066\u305F",
  "id" : 366751806434451456,
  "created_at" : "2013-08-12 02:43:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366556164273618945",
  "text" : "\u306A\u30FC\u3093\u3064\u3063\u3066\u3064\u3063\u3061\u3083\u3063\u305F\u3001\u3082\u826F\u3044\u3067\u3059\u304C\u3001\u3044\u308F\u3086\u3089\u306D\u3047\u304B\u3041\u30FC\uFF01\u3082\u7D50\u69CB\u597D\u304D",
  "id" : 366556164273618945,
  "created_at" : "2013-08-11 13:46:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 12, 27 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366554752248586242",
  "geo" : { },
  "id_str" : "366554883861655552",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 @mircea_morning \u306A\u3093\u3064\u3063\u3066\u3064\u3063\u3061\u3083\u3063\u305F\uFF1F\uFF01",
  "id" : 366554883861655552,
  "in_reply_to_status_id" : 366554752248586242,
  "created_at" : "2013-08-11 13:41:09 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366553365938839552",
  "geo" : { },
  "id_str" : "366553719573200898",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u306A\u3093\u3067\u3060\u3088\u3063\u3001\u9802\u304D\u307E\u3057\u305F\uFF01\uFF01(\u96D1)",
  "id" : 366553719573200898,
  "in_reply_to_status_id" : 366553365938839552,
  "created_at" : "2013-08-11 13:36:31 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366552691725451265",
  "text" : "\u552F\u3061\u3083\u3093\u307F\u305F\u3044\u306A\u7A81\u3063\u8FBC\u307F\u5F79\u304C\u6B32\u3057\u3044\u4EBA\u751F\u3060\u3063\u305F(\u5B8C)",
  "id" : 366552691725451265,
  "created_at" : "2013-08-11 13:32:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366529455457452036",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 366529455457452036,
  "created_at" : "2013-08-11 12:00:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366528263276855296",
  "text" : "\u95A2\u6771\u306E\u53CB\u4EBA\u306F\u30DC\u30B1\u306B\u3064\u3044\u3066\u3053\u306A\u3044\u306A\u30FC\u3001\u3068\u601D\u3063\u305F\u304C\u3001\u51B7\u9759\u306B\u8003\u3048\u305F\u3089\u95A2\u897F\u306E\u53CB\u4EBA\u3082\u5927\u3057\u3066\u3064\u3044\u3066\u6765\u3066\u306A\u304B\u3063\u305F\u3057\u539F\u56E0\u306F\u79C1",
  "id" : 366528263276855296,
  "created_at" : "2013-08-11 11:55:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/QIja9fRPWb",
      "expanded_url" : "http:\/\/sx9.jp\/weather\/tokyo.html",
      "display_url" : "sx9.jp\/weather\/tokyo.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366448484892672001",
  "text" : "\u3046\u3078\u3047\u2026http:\/\/t.co\/QIja9fRPWb",
  "id" : 366448484892672001,
  "created_at" : "2013-08-11 06:38:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366448176007360512",
  "text" : "\u6DBC\u3057\u304F\u306F\u306A\u3063\u305F\u304C\u96E8\u306B\u6253\u305F\u308C\u308B\u3053\u3068\u3068\u6B62\u3093\u3060\u3042\u3068\u306E\u6E7F\u5EA6\u3092\u8003\u3048\u308B\u3068( \u00B4_\u309D\uFF40)",
  "id" : 366448176007360512,
  "created_at" : "2013-08-11 06:37:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366447701560270848",
  "text" : "\u3072\u3069\u3044\u96E8",
  "id" : 366447701560270848,
  "created_at" : "2013-08-11 06:35:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366443986266755073",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u2026",
  "id" : 366443986266755073,
  "created_at" : "2013-08-11 06:20:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 0, 10 ],
      "id_str" : "158645894",
      "id" : 158645894
    }, {
      "name" : "\u3061\u3083\u3093\u3081\u304A",
      "screen_name" : "came1223pg",
      "indices" : [ 11, 22 ],
      "id_str" : "218818356",
      "id" : 218818356
    }, {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 23, 33 ],
      "id_str" : "157989076",
      "id" : 157989076
    }, {
      "name" : "\u3060\u30FC\u3059\u306A",
      "screen_name" : "DarknessCatX",
      "indices" : [ 34, 47 ],
      "id_str" : "258868251",
      "id" : 258868251
    }, {
      "name" : "\u305F\u307E\u307D\u3093",
      "screen_name" : "KhronosTamapon",
      "indices" : [ 48, 63 ],
      "id_str" : "398375051",
      "id" : 398375051
    }, {
      "name" : "\u304B\u3068\u308A\u3087\u30FC",
      "screen_name" : "katryo",
      "indices" : [ 64, 71 ],
      "id_str" : "20364161",
      "id" : 20364161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366402384416620544",
  "geo" : { },
  "id_str" : "366437332846522368",
  "in_reply_to_user_id" : 158645894,
  "text" : "@eclair_15 @came1223pg @typekanon @DarknessCatX @KhronosTamapon @katryo \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 366437332846522368,
  "in_reply_to_status_id" : 366402384416620544,
  "created_at" : "2013-08-11 05:54:02 +0000",
  "in_reply_to_screen_name" : "eclair_15",
  "in_reply_to_user_id_str" : "158645894",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/qncfW6JFhM",
      "expanded_url" : "http:\/\/4sq.com\/11VDEBC",
      "display_url" : "4sq.com\/11VDEBC"
    } ]
  },
  "geo" : { },
  "id_str" : "366430075085783041",
  "text" : "I'm at cafe de L'ambre (\u4E2D\u592E\u533A, \u6771\u4EAC\u90FD) http:\/\/t.co\/qncfW6JFhM",
  "id" : 366430075085783041,
  "created_at" : "2013-08-11 05:25:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366402371225522177",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 366402371225522177,
  "created_at" : "2013-08-11 03:35:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366402347892613121",
  "text" : "\u6B7B\u3092\u76EE\u524D\u306B\u3057\u3066\u2026",
  "id" : 366402347892613121,
  "created_at" : "2013-08-11 03:35:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366389169410408448",
  "text" : "\u3086\u3086\u5F0F\u539F\u753B\u96C6\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 366389169410408448,
  "created_at" : "2013-08-11 02:42:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366375231910199296",
  "text" : "\u3053\u306E\u975E\u5E38\u306B\u6691\u3044\u4E2D\u2026",
  "id" : 366375231910199296,
  "created_at" : "2013-08-11 01:47:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366375159730405376",
  "text" : "\u30B3\u30DF\u30B1\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 366375159730405376,
  "created_at" : "2013-08-11 01:46:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366370782235992064",
  "text" : "\u4E0B\u5317\u901A\u904E",
  "id" : 366370782235992064,
  "created_at" : "2013-08-11 01:29:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366367504173502464",
  "text" : "\u3042\u3064\u3044\u3042\u3064\u3044\u3042\u3064\u3044\u3042\u3064\u3044",
  "id" : 366367504173502464,
  "created_at" : "2013-08-11 01:16:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6EC5\u3073\u306E\u6642\u306F\u8FD1\u3044",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366359487117930496",
  "text" : "#\u6EC5\u3073\u306E\u6642\u306F\u8FD1\u3044",
  "id" : 366359487117930496,
  "created_at" : "2013-08-11 00:44:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 12, 28 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366181489391575040",
  "geo" : { },
  "id_str" : "366182074698313728",
  "in_reply_to_user_id" : 155546700,
  "text" : "@haguruma20 @Jelly_in_a_tank (\u884C\u3051\u306A\u3044\u3051\u3069\u3042\u3068\u304B\u3089\u4F55\u304B\u805E\u304F\u304B\u3082)",
  "id" : 366182074698313728,
  "in_reply_to_status_id" : 366181489391575040,
  "created_at" : "2013-08-10 12:59:44 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366175088539734016",
  "geo" : { },
  "id_str" : "366175468304613377",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u3059\u3054\uFF01\u8272\u3093\u306A\u4EBA\u3068\u304A\u8A71\u3059\u308B\u306E\u697D\u3057\u307F\u3067\u3059\u306D\u30FC\uFF01",
  "id" : 366175468304613377,
  "in_reply_to_status_id" : 366175088539734016,
  "created_at" : "2013-08-10 12:33:29 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366174465031282689",
  "geo" : { },
  "id_str" : "366174675396599808",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u5E02\u6C11\u6A29\u3092\u5F97\u3064\u3064\u3042\u308A\u307E\u3059\u306D[\uFF1F]",
  "id" : 366174675396599808,
  "in_reply_to_status_id" : 366174465031282689,
  "created_at" : "2013-08-10 12:30:20 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366174286232305665",
  "text" : "\u65B0\u3057\u3044\u30CD\u30BF\u306B\u3064\u3069\u3044\u304C\u4F7F\u308F\u308C\u3066\u308B\u30C3\uFF01",
  "id" : 366174286232305665,
  "created_at" : "2013-08-10 12:28:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366174186609184768",
  "text" : "RT @JOJO_math: \u300C\u3059\u3046\u304C\u304F\u5F92\u306E\u3064\u3069\u3044\u300D\u304B\u2026\u306A\u304B\u306A\u304B\u306E\u30D1\u30EF\u30FC\u3068\u53C2\u52A0\u4EBA\u6570\u3060\u3000\u3053\u306EDIO\u306E\u5B66\u751F\u6642\u4EE3\u306F\u81EA\u4E3B\u30BB\u30DF\u30CA\u30FC\u3057\u304B\u3084\u3063\u3066\u3044\u306A\u304B\u3063\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366174103465500672",
    "text" : "\u300C\u3059\u3046\u304C\u304F\u5F92\u306E\u3064\u3069\u3044\u300D\u304B\u2026\u306A\u304B\u306A\u304B\u306E\u30D1\u30EF\u30FC\u3068\u53C2\u52A0\u4EBA\u6570\u3060\u3000\u3053\u306EDIO\u306E\u5B66\u751F\u6642\u4EE3\u306F\u81EA\u4E3B\u30BB\u30DF\u30CA\u30FC\u3057\u304B\u3084\u3063\u3066\u3044\u306A\u304B\u3063\u305F",
    "id" : 366174103465500672,
    "created_at" : "2013-08-10 12:28:04 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 366174186609184768,
  "created_at" : "2013-08-10 12:28:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366167140534980608",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 366167140534980608,
  "created_at" : "2013-08-10 12:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366163965438476288",
  "text" : "Kinbo\u3063\u3066\u3084\u3070\u3044\u306A",
  "id" : 366163965438476288,
  "created_at" : "2013-08-10 11:47:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366163631425064960",
  "geo" : { },
  "id_str" : "366163852880134144",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows Kinbo\u2026",
  "id" : 366163852880134144,
  "in_reply_to_status_id" : 366163631425064960,
  "created_at" : "2013-08-10 11:47:20 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366163528614281217",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u30AA\u30FC\u30D7\u30F3\u30AD\u30E3\u30F3\u30D1\u30B9\u306E\u8CC7\u6599\u306B\u77E5\u308A\u5408\u3044\u304C\u6570\u4EBA\u8F09\u3063\u3066\u3066\u7B11\u3063\u305F",
  "id" : 366163528614281217,
  "created_at" : "2013-08-10 11:46:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366162791310176256",
  "geo" : { },
  "id_str" : "366162883542921217",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows [\u5B9F\u969B\u305D\u3046\u3060\u3063\u305F\u308A\u3057\u307E\u3059]",
  "id" : 366162883542921217,
  "in_reply_to_status_id" : 366162791310176256,
  "created_at" : "2013-08-10 11:43:29 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6EC5\u3073\u306E\u6642\u306F\u8FD1\u3044",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366162460383776769",
  "geo" : { },
  "id_str" : "366162569163063296",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows #\u6EC5\u3073\u306E\u6642\u306F\u8FD1\u3044",
  "id" : 366162569163063296,
  "in_reply_to_status_id" : 366162460383776769,
  "created_at" : "2013-08-10 11:42:14 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6EC5\u3073\u306E\u6642\u306F\u8FD1\u3044",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366162374778044417",
  "text" : "#\u6EC5\u3073\u306E\u6642\u306F\u8FD1\u3044",
  "id" : 366162374778044417,
  "created_at" : "2013-08-10 11:41:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366118008046886912",
  "text" : "\u91CE\u7403\u8208\u5473\u306A\u3044\u306E\u306B\u4ECA\u65E5\u898B\u3066\u308B",
  "id" : 366118008046886912,
  "created_at" : "2013-08-10 08:45:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366117905412263936",
  "text" : "\u91CE\u7403\u8208\u5473\u306A\u3044\u304B\u3089\u590F\u3089\u3057\u3044BGM\u3068\u3057\u3066\u512A\u79C0",
  "id" : 366117905412263936,
  "created_at" : "2013-08-10 08:44:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366115815457685505",
  "text" : "\u6700\u9AD8\u6C17\u6E2937\u5EA6\u3068\u304B\u306E\u65E5\u306B\u934B\u3084\u308B\u5BB6\u65CF\u3060\u3063\u305F",
  "id" : 366115815457685505,
  "created_at" : "2013-08-10 08:36:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366115580211761154",
  "text" : "\u305D\u3057\u3066\u672C\u5F53\u306B\u6C34\u708A\u304D\u306B\u306A\u308B\u6A21\u69D8",
  "id" : 366115580211761154,
  "created_at" : "2013-08-10 08:35:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366115515703373824",
  "text" : "\u6BCD\u300C\u4F55\u98DF\u3079\u305F\u3044\uFF1F\u300D\n\u3048\u3093\u3069\u300C\u3046\u306A\u304E\u300D\n\u6BCD\u300C\u3046\u306A\u304E\u5ACC\u3044\u306A\u3093\u3060\u3088\u306D\u300D\n\u3048\u3093\u3069\u300C\u3058\u3083\u3042\u30AB\u30EC\u30FC\u300D\n\u5F1F\u300C\u30AB\u30EC\u30FC\u2026(\u3042\u307E\u308A\u597D\u304D\u3067\u306A\u3044)\u300D\n\u3048\u3093\u3069\u300C\u3058\u3083\u3042\u934B\u300D\n\n\uFF3F\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u934B\u3000\uFF1C\n\uFFE3Y^Y\uFFE3",
  "id" : 366115515703373824,
  "created_at" : "2013-08-10 08:35:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366057493228560385",
  "text" : "\u3042\u30FC\u3064\u30FC\u3044\u30FC\u30FC\u30FC",
  "id" : 366057493228560385,
  "created_at" : "2013-08-10 04:44:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365763552344158208",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\uFF1F\uFF01\u30CB\u30F3\u30B8\u30E3\uFF1F\uFF01\u306A\u3093\u3067\u306B\u3093\u3058\u3083\uFF1F\uFF01",
  "id" : 365763552344158208,
  "created_at" : "2013-08-09 09:16:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365763467791179776",
  "text" : "\u5FCD\u305F\u307E\u306B\u30BA\u30F3\u30D3\u30FC\u30CB\u30F3\u30B8\u30E3\u304C\u51FA\u3066\u3066\u7B11\u3044\u3092\u582A\u3048\u3066\u3044\u308B",
  "id" : 365763467791179776,
  "created_at" : "2013-08-09 09:16:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365751042220101632",
  "text" : "\u5B9F\u5BB6\u3067TV\u3092\u6B7B\u3093\u3060\u76EE\u3067\u773A\u3081\u3066\u3044\u308B",
  "id" : 365751042220101632,
  "created_at" : "2013-08-09 08:26:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365726528161583105",
  "text" : "\u6771\u4EAC\u99C5\u4EBA\u591A\u3059\u304E\u3001\u30E4\u30F3\u30CA\u30EB\u30CD",
  "id" : 365726528161583105,
  "created_at" : "2013-08-09 06:49:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365700334414340097",
  "text" : "redatuition",
  "id" : 365700334414340097,
  "created_at" : "2013-08-09 05:05:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365699373448970241",
  "text" : "\u306A\u3054\u3084\u30FC",
  "id" : 365699373448970241,
  "created_at" : "2013-08-09 05:01:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365698709360611330",
  "text" : "\u306A\u3093\u304B\u3082\u3046\u3069\u3046\u305B\u306A\u3089\u672C\u5F53\u306B\u610F\u5473\u4E0D\u660E\u306A\u306E\u306B\u3059\u308C\u3070\u3044\u3044\u306E\u306B\u306D\u3002\u7D71\u4E00\u30C6\u30FC\u30DE\u3002",
  "id" : 365698709360611330,
  "created_at" : "2013-08-09 04:59:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365698523682971648",
  "text" : "\u300C\u8DA3\u65E8\u306A\u3093\u3066\u306A\u3044\u300D",
  "id" : 365698523682971648,
  "created_at" : "2013-08-09 04:58:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365698309635051521",
  "text" : "\u63A8\u7406\u5C0F\u8AAC\u306E\u30C8\u30EA\u30C3\u30AF\u306B\u4F7F\u3048\u305D\u3046\u3001\u30A2\u30EA\u30D0\u30A4\u5DE5\u4F5C",
  "id" : 365698309635051521,
  "created_at" : "2013-08-09 04:57:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365698177967456256",
  "text" : "\u5225\u306B\u826F\u3044\u306E\u3060\u304CWi-Fi\u306E\u30A2\u30EC\u306B\u300Chogehoge(\u540D\u5B57)hugahuga(\u540D\u524D)\u306EiPhone\u300D\u3063\u3066\u51FA\u308B\u3068\u300C\u3053\u306E\u8FD1\u304F\u306Bhogehogehugahuga\u3055\u3093\u304C\u3044\u308B\u3063\uFF01\u300D\u3063\u3066\u306A\u308B",
  "id" : 365698177967456256,
  "created_at" : "2013-08-09 04:56:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/L8yEUimlCH",
      "expanded_url" : "http:\/\/goo.gl\/kGMz2D",
      "display_url" : "goo.gl\/kGMz2D"
    } ]
  },
  "geo" : { },
  "id_str" : "365697297817935872",
  "text" : "\u3053\u3053\u3067\u99AC\u5177\u306B\u3064\u3044\u3066\u304A\u3055\u3089\u3044\u3057\u3066\u307F\u307E\u3057\u3087\u3046 http:\/\/t.co\/L8yEUimlCH",
  "id" : 365697297817935872,
  "created_at" : "2013-08-09 04:53:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3063\u3069\u30FC",
      "screen_name" : "ido_d",
      "indices" : [ 0, 6 ],
      "id_str" : "335231130",
      "id" : 335231130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365695480165974016",
  "geo" : { },
  "id_str" : "365695695216312320",
  "in_reply_to_user_id" : 335231130,
  "text" : "@ido_d \u30DC\u30B8\u30E7\u30EC\u30FC\u30B3\u30D4\u30DA\u306F\u3088\uFF01",
  "id" : 365695695216312320,
  "in_reply_to_status_id" : 365695480165974016,
  "created_at" : "2013-08-09 04:47:02 +0000",
  "in_reply_to_screen_name" : "ido_d",
  "in_reply_to_user_id_str" : "335231130",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365695434963955712",
  "text" : "\u99AC\u5177\u3068\u3044\u3046\u8A00\u8449[\u30D0\u30B0\u3067\u306A\u304F\u3066]\u65E5\u5E38\u3067\u4E00\u5207\u805E\u304B\u306A\u3044",
  "id" : 365695434963955712,
  "created_at" : "2013-08-09 04:46:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365695002095001601",
  "text" : "\u3080\u304E\u3054\u307F\u3080\u304E\u3054\u307F\u307F\u3080\u304E\u3054\u307F",
  "id" : 365695002095001601,
  "created_at" : "2013-08-09 04:44:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "410natsuki529",
      "screen_name" : "tatyusa419",
      "indices" : [ 0, 11 ],
      "id_str" : "2531832002",
      "id" : 2531832002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365694938345775105",
  "text" : "@tatyusa419 \u304D\u304F\u304F\u308A\u304D\u304F\u304F\u308A\u307F\u304D\u304F\u304F\u308A",
  "id" : 365694938345775105,
  "created_at" : "2013-08-09 04:44:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365694535726137345",
  "text" : "\u5177\u3001\u5177\u3001\u978D\u304F\u3089\u3001\u3068\u5927\u5909\u8AAD\u307F\u306B\u304F\u3044",
  "id" : 365694535726137345,
  "created_at" : "2013-08-09 04:42:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365694482718539776",
  "text" : "\u99AC\u5177\u3001\u5177\u4F53\u7684\u306B\u306F\u978D\u304F\u3089\u3044\u3057\u304B\u77E5\u3089\u306A\u3044",
  "id" : 365694482718539776,
  "created_at" : "2013-08-09 04:42:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365694402473107456",
  "text" : "\u4ECA\u65E5\u306F8\/9\u3067\u99AC\u5177\u306E\u65E5\u3067\u3059\u306D\uFF01",
  "id" : 365694402473107456,
  "created_at" : "2013-08-09 04:41:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365692765566283776",
  "text" : "\u307E\u3041\u8D64\u798F\u306E\u30A2\u30AF\u30BB\u30B7\u30D3\u30EA\u30C6\u30A3\u306F\u7570\u5E38",
  "id" : 365692765566283776,
  "created_at" : "2013-08-09 04:35:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conjugate_box",
      "screen_name" : "conjugate_box",
      "indices" : [ 0, 14 ],
      "id_str" : "214532657",
      "id" : 214532657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365691989716516865",
  "geo" : { },
  "id_str" : "365692651028226048",
  "in_reply_to_user_id" : 214532657,
  "text" : "@conjugate_box \u4F0A\u52E2\u89B3\u5149\u3067\u3082\u306A\u3093\u3067\u3082\u306A\u3044\u305F\u3060\u306E\u5E30\u7701\u306A\u3093\u3067\u3059\u3051\u3069\u306D\u30FC",
  "id" : 365692651028226048,
  "in_reply_to_status_id" : 365691989716516865,
  "created_at" : "2013-08-09 04:34:56 +0000",
  "in_reply_to_screen_name" : "conjugate_box",
  "in_reply_to_user_id_str" : "214532657",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conjugate_box",
      "screen_name" : "conjugate_box",
      "indices" : [ 0, 14 ],
      "id_str" : "214532657",
      "id" : 214532657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365689983291502592",
  "geo" : { },
  "id_str" : "365691260205416448",
  "in_reply_to_user_id" : 214532657,
  "text" : "@conjugate_box \u6B8B\u308A\u306F\u304A\u571F\u7523\u3067\u3059\u306D\u30FC",
  "id" : 365691260205416448,
  "in_reply_to_status_id" : 365689983291502592,
  "created_at" : "2013-08-09 04:29:25 +0000",
  "in_reply_to_screen_name" : "conjugate_box",
  "in_reply_to_user_id_str" : "214532657",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365690954084139008",
  "text" : "\u3042\u30FC\u3001\u30D6\u30EB\u30C9\u30C3\u30B0\u30BD\u30FC\u30B9\u6301\u3063\u3066\u304D\u3066\u30AB\u30C4\u30B5\u30F3\u30C9\u8CB7\u3046\u306E\u3082\u30CD\u30BF\u7684\u306B\u3042\u308A\u3060\u3063\u305F\u306A\u30FC",
  "id" : 365690954084139008,
  "created_at" : "2013-08-09 04:28:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365690621190610944",
  "text" : "\u304A\u3068\u306A\u3057\u304F\u3059\u308B\u30FC",
  "id" : 365690621190610944,
  "created_at" : "2013-08-09 04:26:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365690424570036225",
  "text" : "\u60B2\u5831:\u30B3\u30F3\u30BB\u30F3\u30C8\u304C\u306A\u3044",
  "id" : 365690424570036225,
  "created_at" : "2013-08-09 04:26:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365689604956889088",
  "text" : "\u304A\u663C\u3054\u306F\u3093\u306B\u8D64\u798F\u3092\u8CB7\u3063\u305F\u304C\u3053\u308C\u91CD\u305F\u3044\u306A",
  "id" : 365689604956889088,
  "created_at" : "2013-08-09 04:22:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365689349502812162",
  "text" : "\u3042\u30FC\u3042\u3064\u3044\u3001\u3061\u3083\u3093\u3061\u3083\u3089\u3042\u3064\u3044\u308F",
  "id" : 365689349502812162,
  "created_at" : "2013-08-09 04:21:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365682904690462722",
  "text" : "\u30A2\u30EC\u30D5\u2026",
  "id" : 365682904690462722,
  "created_at" : "2013-08-09 03:56:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365679644336340992",
  "text" : "\u3082\u3061\u308D\u3093\u4E92\u3044\u306B",
  "id" : 365679644336340992,
  "created_at" : "2013-08-09 03:43:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365679596542230529",
  "text" : "\u89AA\u3067\u3082\u914D\u5076\u8005\u3067\u3082\u4E0D\u53EF\u4FB5\u306A\u9818\u57DF\u3063\u3066\u3042\u308B\u3088\u306D\u3047",
  "id" : 365679596542230529,
  "created_at" : "2013-08-09 03:43:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pok",
      "screen_name" : "nobuhusababa",
      "indices" : [ 3, 16 ],
      "id_str" : "77971818",
      "id" : 77971818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365679468666290178",
  "text" : "RT @nobuhusababa: \u5B50\u4F9B\u306E\u30B2\u30FC\u30E0\u6A5F\u3092\u30D6\u30C3\u58CA\u3059\u89AA\u3068\u592B\u306E\u9244\u9053\u6A21\u578B\u3092\u6368\u3066\u308B\u59BB\u3001\u3084\u3063\u3071\u308A\u4F3C\u3066\u308B\u3068\u3044\u3046\u304B\u3001\u300C\u672C\u4EBA\u306E\u8208\u5473\u306E\u5BFE\u8C61\u3092\u7834\u58CA\u3059\u308C\u3070\u3001\u81EA\u5206\u306B\u3068\u3063\u3066\u597D\u307E\u3057\u3044\u65B9\u5411\u306B\u5909\u5316\u3055\u305B\u3089\u308C\u308B\u300D\u3068\u3044\u3046\u4F55\u306E\u6839\u62E0\u3082\u306A\u3044\u601D\u3044\u8FBC\u307F\u3092\u305D\u306E\u307E\u307E\u5B9F\u884C\u3059\u308B\u8FBA\u308A\u304C\u6700\u9AD8\u306B\u30D5\u30A1\u30C3\u30AF\u3067\u3059\u306D\u3002\u8981\u306F\u81EA\u5206\u597D\u307F\u306B\u6D17\u8133\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365637197073874944",
    "text" : "\u5B50\u4F9B\u306E\u30B2\u30FC\u30E0\u6A5F\u3092\u30D6\u30C3\u58CA\u3059\u89AA\u3068\u592B\u306E\u9244\u9053\u6A21\u578B\u3092\u6368\u3066\u308B\u59BB\u3001\u3084\u3063\u3071\u308A\u4F3C\u3066\u308B\u3068\u3044\u3046\u304B\u3001\u300C\u672C\u4EBA\u306E\u8208\u5473\u306E\u5BFE\u8C61\u3092\u7834\u58CA\u3059\u308C\u3070\u3001\u81EA\u5206\u306B\u3068\u3063\u3066\u597D\u307E\u3057\u3044\u65B9\u5411\u306B\u5909\u5316\u3055\u305B\u3089\u308C\u308B\u300D\u3068\u3044\u3046\u4F55\u306E\u6839\u62E0\u3082\u306A\u3044\u601D\u3044\u8FBC\u307F\u3092\u305D\u306E\u307E\u307E\u5B9F\u884C\u3059\u308B\u8FBA\u308A\u304C\u6700\u9AD8\u306B\u30D5\u30A1\u30C3\u30AF\u3067\u3059\u306D\u3002\u8981\u306F\u81EA\u5206\u597D\u307F\u306B\u6D17\u8133\u3057\u305F\u3044\u3063\u3066\u4E8B\u3058\u3083\u306D\u3047\u304B\u3002\u6C17\u6301\u3061\u60AA\u3044\u3002",
    "id" : 365637197073874944,
    "created_at" : "2013-08-09 00:54:35 +0000",
    "user" : {
      "name" : "Pok",
      "screen_name" : "nobuhusababa",
      "protected" : false,
      "id_str" : "77971818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450834272803241984\/vlcIO6UH_normal.jpeg",
      "id" : 77971818,
      "verified" : false
    }
  },
  "id" : 365679468666290178,
  "created_at" : "2013-08-09 03:42:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365679036254519296",
  "text" : "\uFF1F",
  "id" : 365679036254519296,
  "created_at" : "2013-08-09 03:40:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365679017266913281",
  "text" : "\u5EA7\u308C\u3066\u5B09\u3057\u3044\u306F\u306A\u3044\u3061\u3082\u3093\u3081",
  "id" : 365679017266913281,
  "created_at" : "2013-08-09 03:40:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365678346299912192",
  "text" : "\u65B0\u5E79\u7DDA\u6DF7\u3093\u3067\u305F\u3089\u30E4\u30C0\u306A\u30FC",
  "id" : 365678346299912192,
  "created_at" : "2013-08-09 03:38:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365677126646640640",
  "text" : "\u30D0\u30B9\u6DF7\u3093\u3067\u308B\u3045",
  "id" : 365677126646640640,
  "created_at" : "2013-08-09 03:33:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365647811712258050",
  "text" : "\u9CE5\u8CB4\u65CF\u2026",
  "id" : 365647811712258050,
  "created_at" : "2013-08-09 01:36:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365640861826027522",
  "text" : "\u3068\u306F\u3044\u3048\u306A\u30FC\u3093\u3082\u6E96\u5099\u3057\u3066\u306A\u3044\u3093\u3060\u3088\u306A\u2026",
  "id" : 365640861826027522,
  "created_at" : "2013-08-09 01:09:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DE\u30C8\u30AD",
      "screen_name" : "pleconermatoki",
      "indices" : [ 0, 15 ],
      "id_str" : "449895783",
      "id" : 449895783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365640011342823426",
  "geo" : { },
  "id_str" : "365640135993339904",
  "in_reply_to_user_id" : 449895783,
  "text" : "@pleconermatoki \u50D5\u3001\u4ECA\u65E5\u304B\u3089\u5E30\u7701\u3059\u308B\u306E\u3067\u3064\u304F\u9803\u306B\u306F\u3044\u306A\u3044\u3067\u3059\u3051\u308C\u3069\u306D\uFF01\uFF01",
  "id" : 365640135993339904,
  "in_reply_to_status_id" : 365640011342823426,
  "created_at" : "2013-08-09 01:06:16 +0000",
  "in_reply_to_screen_name" : "pleconermatoki",
  "in_reply_to_user_id_str" : "449895783",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365639688888922113",
  "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u51FA\u3066\u304F\u308B\u5922\u3092\u307F\u305F\u3088\u3046\u306A\u6C17\u304C\u3057\u305F",
  "id" : 365639688888922113,
  "created_at" : "2013-08-09 01:04:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365628414352293888",
  "text" : "\u3042\u3070\u3070\u3070\u3070\u3001\u8D77\u304D\u305F\u3088",
  "id" : 365628414352293888,
  "created_at" : "2013-08-09 00:19:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365448570956025858",
  "text" : "\u304A\u3075\u308D\u306F\u3044\u3063\u3066\u5BDD\u3088\u2026",
  "id" : 365448570956025858,
  "created_at" : "2013-08-08 12:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365442361939075072",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 365442361939075072,
  "created_at" : "2013-08-08 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365417633648095233",
  "text" : "\uFF1F",
  "id" : 365417633648095233,
  "created_at" : "2013-08-08 10:22:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365417586751586304",
  "text" : "\u3066\u304B\u3001LINE\u4EE5\u5916\u3084\u3063\u3066\u308B\u3068\u306F\u9650\u3089\u306A\u3044\uFF1F\u7B11",
  "id" : 365417586751586304,
  "created_at" : "2013-08-08 10:21:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 0, 9 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365415267360186368",
  "geo" : { },
  "id_str" : "365415613407047680",
  "in_reply_to_user_id" : 532309831,
  "text" : "@usiusi02 \u4ECA\u5EA6\u884C\u3063\u3066\u898B\u308B [4sq\u898B\u308B\u524D\u306B\u30EA\u30D7\u30E9\u30A4\u3057\u3061\u3083\u3063\u3066\u3054\u3081\u3093\u306A\u30FC]",
  "id" : 365415613407047680,
  "in_reply_to_status_id" : 365415267360186368,
  "created_at" : "2013-08-08 10:14:05 +0000",
  "in_reply_to_screen_name" : "usiusi02",
  "in_reply_to_user_id_str" : "532309831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 10, 19 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365414757798391808",
  "text" : "@potezaki @usiusi02 \u3069\u3053\u305D\u308C\u3046\u307E\u305D\u3046",
  "id" : 365414757798391808,
  "created_at" : "2013-08-08 10:10:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365414179487752193",
  "text" : "\"\u30C8\u30E9\u30F3\u30AF\u306B\u4EBA\u9593\"\u3068\u805E\u3044\u305F\u3089\u3069\u3046\u8003\u3048\u3066\u3082\u4E2D\u306E\u4EBA\u751F\u304D\u3066\u306A\u3044",
  "id" : 365414179487752193,
  "created_at" : "2013-08-08 10:08:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365413613122502656",
  "text" : "\u751F\u304D\u3066\u3044\u306A\u3044\u72B6\u614B\u3067\u58F2\u308A\u8CB7\u3044\u3055\u308C\u308B\u53EF\u80FD\u6027\u3092\u3060\u306A\u2026",
  "id" : 365413613122502656,
  "created_at" : "2013-08-08 10:06:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365407147510607873",
  "text" : "\"\u8AA4\u5831\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\"\u8AA4\u5831\u3092\u53E9\u304D\u305F\u3044\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\"\u8AA4\u5831\u3092\u53E9\u304D\u305F\u3044\u3092\u53E9\u304D\u305F\u3044\u4EBA\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\"\u8AA4\u5831\u3092\u53E9\u304D\u305F\u3044\u3092\u53E9\u304D\u305F\u3044\u4EBA\u3092\u53E9\u304D\u305F\u3044\u4EBA\u3092\u53E9\u304D\u305F\u3044\u4EBA\"\u3068\u2026",
  "id" : 365407147510607873,
  "created_at" : "2013-08-08 09:40:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365383409796775938",
  "text" : "\u8AA4\u5831\u3067\u826F\u304B\u3063\u305F\u3058\u3083\u3093",
  "id" : 365383409796775938,
  "created_at" : "2013-08-08 08:06:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365368728654843904",
  "text" : "\u72D0\u306E\u5AC1\u5165\u308A\u5929\u6C17\u96E8",
  "id" : 365368728654843904,
  "created_at" : "2013-08-08 07:07:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365368496726614016",
  "text" : "\u5915\u7ACB\uFF1F",
  "id" : 365368496726614016,
  "created_at" : "2013-08-08 07:06:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365368197790183426",
  "text" : "Kan\u4EA1\u304F\u306A\u3063\u305F\u306E\u304B\u2026",
  "id" : 365368197790183426,
  "created_at" : "2013-08-08 07:05:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hiroyuki Miyoshi",
      "screen_name" : "metaphusika",
      "indices" : [ 3, 15 ],
      "id_str" : "27468098",
      "id" : 27468098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365368103313473536",
  "text" : "RT @metaphusika: Daniel M. Kan\u5148\u751F\u304C8\u67084\u65E5\u306B\u901D\u53BB\u3055\u308C\u307E\u3057\u305F\u3002\u570F\u8AD6\u306E\u6700\u91CD\u8981\u6982\u5FF5\u306E\u4E00\u3064\u3067\u3042\u308B\u968F\u4F34\u306E\u767A\u898B\u8005\u3067\u3059\u3002\u3054\u51A5\u798F\u3092\u304A\u7948\u308A\u3057\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365365813819092994",
    "text" : "Daniel M. Kan\u5148\u751F\u304C8\u67084\u65E5\u306B\u901D\u53BB\u3055\u308C\u307E\u3057\u305F\u3002\u570F\u8AD6\u306E\u6700\u91CD\u8981\u6982\u5FF5\u306E\u4E00\u3064\u3067\u3042\u308B\u968F\u4F34\u306E\u767A\u898B\u8005\u3067\u3059\u3002\u3054\u51A5\u798F\u3092\u304A\u7948\u308A\u3057\u307E\u3059\u3002",
    "id" : 365365813819092994,
    "created_at" : "2013-08-08 06:56:12 +0000",
    "user" : {
      "name" : "Hiroyuki Miyoshi",
      "screen_name" : "metaphusika",
      "protected" : false,
      "id_str" : "27468098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114000033\/muga_normal.jpg",
      "id" : 27468098,
      "verified" : false
    }
  },
  "id" : 365368103313473536,
  "created_at" : "2013-08-08 07:05:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/thtPPb0fUD",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/745?prefill=jazzcoltrain",
      "display_url" : "gohantabeyo.com\/nani\/745?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365341670247636992",
  "text" : "\u30C7\u30FC\u30C8\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/thtPPb0fUD",
  "id" : 365341670247636992,
  "created_at" : "2013-08-08 05:20:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365322015802003458",
  "text" : "\u5618\u3067\u3059",
  "id" : 365322015802003458,
  "created_at" : "2013-08-08 04:02:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365321984210513920",
  "text" : "\u3069\u3046\u3082\u3001\u30A8\u30F3\u30C9\u30AA\u30D6\u30DB\u30EF\u30A4\u30C8\u30CF\u30A6\u30B9\u3067\u3059",
  "id" : 365321984210513920,
  "created_at" : "2013-08-08 04:02:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "indices" : [ 3, 11 ],
      "id_str" : "16331213",
      "id" : 16331213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365321919966347264",
  "text" : "RT @kazoo04: \u30A8\u30F3\u30C9\u30FB\u30AA\u30D6\u30FB\u30DB\u30EF\u30A4\u30C8\u30CF\u30A6\u30B9\u3001\u307E\u3042\u307E\u3042\u306E\u51FA\u6765\u3089\u3057\u3044\u306E\u3067\u898B\u306B\u884C\u304D\u305F\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365321161728475136",
    "text" : "\u30A8\u30F3\u30C9\u30FB\u30AA\u30D6\u30FB\u30DB\u30EF\u30A4\u30C8\u30CF\u30A6\u30B9\u3001\u307E\u3042\u307E\u3042\u306E\u51FA\u6765\u3089\u3057\u3044\u306E\u3067\u898B\u306B\u884C\u304D\u305F\u3044",
    "id" : 365321161728475136,
    "created_at" : "2013-08-08 03:58:46 +0000",
    "user" : {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "protected" : false,
      "id_str" : "16331213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583129549694640129\/aPkbezAe_normal.png",
      "id" : 16331213,
      "verified" : false
    }
  },
  "id" : 365321919966347264,
  "created_at" : "2013-08-08 04:01:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7559\u3005\u6D6A\u4EBA\u306E\u3053\u306E\u3053",
      "screen_name" : "Far_east_turtle",
      "indices" : [ 0, 16 ],
      "id_str" : "277816120",
      "id" : 277816120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365315629001084928",
  "geo" : { },
  "id_str" : "365315675683688448",
  "in_reply_to_user_id" : 277816120,
  "text" : "@Far_east_turtle \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 365315675683688448,
  "in_reply_to_status_id" : 365315629001084928,
  "created_at" : "2013-08-08 03:36:58 +0000",
  "in_reply_to_screen_name" : "Far_east_turtle",
  "in_reply_to_user_id_str" : "277816120",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "glacier",
      "screen_name" : "glacier_phys",
      "indices" : [ 0, 13 ],
      "id_str" : "543379554",
      "id" : 543379554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365296848040235008",
  "geo" : { },
  "id_str" : "365297026453340161",
  "in_reply_to_user_id" : 841274743,
  "text" : "@glacier_phys \u307E\u3041\u53CB\u4EBA\u30B0\u30EB\u30FC\u30D7\u3067\u305D\u3093\u306A\u8A71\u304C\u51FA\u3066\u3044\u305F\u306E\u3092\u601D\u3044\u51FA\u3057\u305F\u306E\u3067\u30FC",
  "id" : 365297026453340161,
  "in_reply_to_status_id" : 365296848040235008,
  "created_at" : "2013-08-08 02:22:52 +0000",
  "in_reply_to_screen_name" : "glacier_string",
  "in_reply_to_user_id_str" : "841274743",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "glacier",
      "screen_name" : "glacier_phys",
      "indices" : [ 0, 13 ],
      "id_str" : "543379554",
      "id" : 543379554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365296385156857858",
  "geo" : { },
  "id_str" : "365296489280450560",
  "in_reply_to_user_id" : 841274743,
  "text" : "@glacier_phys \u767A\u6848\u8005\u306F\u50D5\u3067\u306F\u306A\u3044\u3067\u3059\u3051\u3069\u306D\u30FC",
  "id" : 365296489280450560,
  "in_reply_to_status_id" : 365296385156857858,
  "created_at" : "2013-08-08 02:20:44 +0000",
  "in_reply_to_screen_name" : "glacier_string",
  "in_reply_to_user_id_str" : "841274743",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365296145276223488",
  "text" : "\u5B9F\u969B\u3042\u307E\u308A\u306B\u60AA\u8CEA\u3060\u304B\u3089\u5B9F\u884C\u304C\u65AD\u5FF5\u3055\u308C\u305F",
  "id" : 365296145276223488,
  "created_at" : "2013-08-08 02:19:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "glacier",
      "screen_name" : "glacier_phys",
      "indices" : [ 0, 13 ],
      "id_str" : "543379554",
      "id" : 543379554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365295782645084161",
  "geo" : { },
  "id_str" : "365296000908279809",
  "in_reply_to_user_id" : 841274743,
  "text" : "@glacier_phys \u540C\u611F\u3067\u3059",
  "id" : 365296000908279809,
  "in_reply_to_status_id" : 365295782645084161,
  "created_at" : "2013-08-08 02:18:48 +0000",
  "in_reply_to_screen_name" : "glacier_string",
  "in_reply_to_user_id_str" : "841274743",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365295333087002624",
  "text" : "\u5B9F\u884C\u306F\u3057\u3066\u306A\u3044",
  "id" : 365295333087002624,
  "created_at" : "2013-08-08 02:16:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365295310353858561",
  "text" : "\u5927\u5B66\u30C7\u30D3\u30E5\u30FC\u3057\u305F\u3068\u601D\u3057\u304D\u53CB\u4EBA\u3092\u3001\u4F8B\u3048\u3070\u6587\u5316\u796D\u3068\u304B\u306E\u6642\u306B\u8A2A\u306D\u3066\u3001\u3044\u304B\u306B\u3082\u30AD\u30E2\u30AA\u30BF\u307F\u305F\u3044\u306A\u30AB\u30C3\u30B3\u3067\u300Chogehoge\u6C0F\u301C\uFF01\uFF01\uFF01\u983C\u307E\u308C\u3066\u3044\u305F\u540C\u4EBA\u8A8C\u3092\u6301\u3063\u3066\u304D\u305F\u3067\u3054\u3056\u308B\u3088\u301C\uFF01\uFF01\uFF01\u300D\u3063\u3066\u3084\u308B\u30C6\u30ED\u304C\u8A08\u753B\u3055\u308C\u305F",
  "id" : 365295310353858561,
  "created_at" : "2013-08-08 02:16:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365282196409430016",
  "text" : "\u5B9F\u969B\u98F2\u307F\u7269\u9673\u5217\u68DA\u306E\u88CF\u5074\u306F\u8D85\u7D76\u6DBC\u3057\u3044",
  "id" : 365282196409430016,
  "created_at" : "2013-08-08 01:23:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365276849108037632",
  "text" : "\u65E5\u672C\u4E2D\u3067\u30D0\u30A4\u30AA\u30B9\u30E2\u30C8\u30EA\u3092\u5FD7\u3057\u305F\u4EBA\u3005\u304C\u30D0\u30A4\u30C8\u5148\u306E\u51B7\u8535\u5EAB\u306B\u5165\u3089\u3093\u3068\u3057\u3066\u3044\u308B\u3068\u601D\u3046\u3068\u30B5\u30C4\u30D0\u30C4",
  "id" : 365276849108037632,
  "created_at" : "2013-08-08 01:02:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365266876554690562",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u9060\u3044\u304B\u3089\u306A\u3001\u5317\u6D77\u9053",
  "id" : 365266876554690562,
  "created_at" : "2013-08-08 00:23:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365266819382120449",
  "text" : "\u30D4\u30AB\u30F3\u30C6\u30A3\u306E\u30B9\u30FC\u30D7\u30AB\u30EC\u30FC\u98DF\u3079\u305F\u3044\u3051\u3069\u5317\u6D77\u9053\u306A\u3093\u3060\u3088\u306A\u3041\u3001\u56F0\u308B",
  "id" : 365266819382120449,
  "created_at" : "2013-08-08 00:22:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365266520672174082",
  "text" : "\u4F55\u3088\u308A\u307E\u3060\u4E5D\u6642\u534A\u3060\u3088\uFF01\uFF01",
  "id" : 365266520672174082,
  "created_at" : "2013-08-08 00:21:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365266484353708032",
  "text" : "\u30AB\u30EC\u30FC\u98DF\u3079\u305F\u3044\u3051\u3069\u5B66\u98DF\u307E\u305F\u6DF7\u307F\u305D\u3046\u3060\u3057\u306A\u2026\u3069\u3046\u3057\u305F\u3082\u306E\u304B\u2026",
  "id" : 365266484353708032,
  "created_at" : "2013-08-08 00:21:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365263483425656833",
  "text" : "\u30BF\u30B3\u30B9\uFF01\u98DF\u3079\u305F\u3044\uFF01",
  "id" : 365263483425656833,
  "created_at" : "2013-08-08 00:09:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365254461314179074",
  "text" : "\u30CF\u30E0\u305F\u307E\u3054\u30B5\u30F3\u30C9\uFF01\u98DF\u3079\u305F\u3044\uFF01",
  "id" : 365254461314179074,
  "created_at" : "2013-08-07 23:33:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365249331789434880",
  "text" : "\u304B\u308C\u30FC\uFF01\u98DF\u3079\u305F\u3044\uFF01",
  "id" : 365249331789434880,
  "created_at" : "2013-08-07 23:13:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365237553525305344",
  "text" : "\u59CB\u7687\u5E1D\u6C0F\u30DE\u30B7\u30FC\u30F3",
  "id" : 365237553525305344,
  "created_at" : "2013-08-07 22:26:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365211849509191683",
  "text" : "\u671D\u306F\u5473\u899A\u304C\u654F\u611F\u3060\u304B\u3089\u4F59\u8A08\u6FC3\u304F\u611F\u3058\u308B\uFF1F",
  "id" : 365211849509191683,
  "created_at" : "2013-08-07 20:44:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365211398537613314",
  "text" : "\u30B9\u30C8\u30ED\u30F3\u30B0\u30B3\u30FC\u30D2\u30FC",
  "id" : 365211398537613314,
  "created_at" : "2013-08-07 20:42:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365211313527455744",
  "text" : "\u5BDD\u307C\u3051\u773C\u3067\u30B3\u30FC\u30D2\u30FC\u6DF9\u308C\u305F\u3089\u8D85\u7D76\u6FC3\u3044",
  "id" : 365211313527455744,
  "created_at" : "2013-08-07 20:42:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365209381664591874",
  "text" : "\u7720\u304F\u7720\u304F\u7720\u3044\u304C\u8D77\u304D\u305F",
  "id" : 365209381664591874,
  "created_at" : "2013-08-07 20:34:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365095214496485376",
  "text" : "\u304A\u304A\u304A\u3084\u3059\u307F\u30FC",
  "id" : 365095214496485376,
  "created_at" : "2013-08-07 13:00:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365091980415483905",
  "geo" : { },
  "id_str" : "365094404073074688",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u96C6\u5408\u8AD6\u3067\u81EA\u7136\u6570\u3092\u5B9A\u7FA9\u3059\u308B\u6642\u306B\u306F0\u304B\u3089\u3084\u308B\u3053\u3068\u304C\u591A\u3044\u306E\u3067\u2026\u3042\u3068\u306F\u30B3\u30F3\u30D4\u30E5\u30FC\u30BF\u30B5\u30A4\u30A8\u30F3\u30B9\u306A\u3093\u304B\u3067\u30820\u304C\u4FBF\u5229\u306A\u306E\u3067\u3042\u3063\u3066\u6B32\u3057\u3044\u3068\u8A00\u3046\u611F\u3058\u3067\u3059[\u3082\u3061\u308D\u30931\u304B\u3089\u3067\u3082\u5B9A\u7FA9\u306F\u51FA\u6765\u307E\u3059\u304C]",
  "id" : 365094404073074688,
  "in_reply_to_status_id" : 365091980415483905,
  "created_at" : "2013-08-07 12:57:43 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365091291656241152",
  "geo" : { },
  "id_str" : "365091453493456899",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u306F\u3044\u306F\u30FC\u3044\u3002",
  "id" : 365091453493456899,
  "in_reply_to_status_id" : 365091291656241152,
  "created_at" : "2013-08-07 12:46:00 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365090608773206016",
  "geo" : { },
  "id_str" : "365090814772248579",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u4E2D2\uFF1F[\u3042\u3068\u3067\u3044\u3044\u304B\u3089\u6D88\u3057\u3068\u3044\u3066\u306A\u30FC]",
  "id" : 365090814772248579,
  "in_reply_to_status_id" : 365090608773206016,
  "created_at" : "2013-08-07 12:43:27 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365090093129662467",
  "geo" : { },
  "id_str" : "365090360776593411",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u540D\u524D\u51FA\u3059\u306A\u3088\u2026[\u4ECA\u9AD81\u304B\u306A]",
  "id" : 365090360776593411,
  "in_reply_to_status_id" : 365090093129662467,
  "created_at" : "2013-08-07 12:41:39 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365089976548990976",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u9069\u5F53\u306B\u304A\u9152\u306E\u3093\u3067\u5BDD\u3066\u30015\u6642\u3059\u304E\u306B\u8D77\u304D\u307E\u3059\u308B",
  "id" : 365089976548990976,
  "created_at" : "2013-08-07 12:40:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365089289056419841",
  "geo" : { },
  "id_str" : "365089794855927811",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u305D\u3046\u3044\u3046\u3053\u3068\u30FC",
  "id" : 365089794855927811,
  "in_reply_to_status_id" : 365089289056419841,
  "created_at" : "2013-08-07 12:39:24 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365089512713490432",
  "geo" : { },
  "id_str" : "365089722764242944",
  "in_reply_to_user_id" : 155546700,
  "text" : "@modestrella \u30A2\u30D0\u3001\u30B5\u30A4\u30C8\u5185\u30670\u306F\u81EA\u7136\u6570 \u3068\u691C\u7D22\u3057\u3066\u307F\u3066\u304F\u3060\u3055\u3044",
  "id" : 365089722764242944,
  "in_reply_to_status_id" : 365089512713490432,
  "created_at" : "2013-08-07 12:39:07 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/g4QBFjqnFK",
      "expanded_url" : "http:\/\/s2s.undefin.net\/wiki\/?0",
      "display_url" : "s2s.undefin.net\/wiki\/?0"
    } ]
  },
  "in_reply_to_status_id_str" : "365089123754713088",
  "geo" : { },
  "id_str" : "365089512713490432",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u306F\u3044\u3001\u8A73\u3057\u304F\u306F\u3053\u3061\u3089\u3092 http:\/\/t.co\/g4QBFjqnFK\u306F\u81EA\u7136\u6570",
  "id" : 365089512713490432,
  "in_reply_to_status_id" : 365089123754713088,
  "created_at" : "2013-08-07 12:38:17 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365089264507170817",
  "text" : "\u307E\u3069\u304B\u300C\u307B\u3080\u3089\u3061\u3083\u3093\u2026\u79C1\u2026\u671D\u65B9\u4EBA\u9593\u306B\u306A\u308B\uFF01\u300D\n\u307B\u3080\u3089\u300C\u305D\u3093\u306A\uFF01\u79C1\u306F\u2026\uFF01\u4F55\u306E\u70BA\u306B\u2026\uFF01(\u62B1\u3048\u3066\u3044\u308B\u5927\u91CF\u306E\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u3092\u53D6\u308A\u843D\u3068\u3059)\u300D",
  "id" : 365089264507170817,
  "created_at" : "2013-08-07 12:37:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365088648112259073",
  "text" : "\u751F\u304D\u3088\uFF01\u305D\u306A\u305F\u306F\u30DD\u30A8\u30C3\u30C8\uFF01",
  "id" : 365088648112259073,
  "created_at" : "2013-08-07 12:34:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365088481409638400",
  "text" : "\u306A\u305C\u304B\u9AD8\u6821\u306E\u540C\u7D1A\u751F\u304B\u3089\u53CD\u5FDC\u304C\u591A\u304F\u3066\u9762\u767D\u3044",
  "id" : 365088481409638400,
  "created_at" : "2013-08-07 12:34:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 3, 12 ],
      "id_str" : "174262858",
      "id" : 174262858
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 14, 24 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365088390619734017",
  "text" : "RT @mesaya31: @end313124 \u30E1\u30EA\u30B1\u30F3\u7C89\u305D\u306E\u4EE3\u511F\u306B\u4FFA\u306F\u6B7B\u306C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "365088231437516800",
    "geo" : { },
    "id_str" : "365088349041598466",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u30E1\u30EA\u30B1\u30F3\u7C89\u305D\u306E\u4EE3\u511F\u306B\u4FFA\u306F\u6B7B\u306C",
    "id" : 365088349041598466,
    "in_reply_to_status_id" : 365088231437516800,
    "created_at" : "2013-08-07 12:33:40 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "protected" : false,
      "id_str" : "174262858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1854605073\/image_normal.jpg",
      "id" : 174262858,
      "verified" : false
    }
  },
  "id" : 365088390619734017,
  "created_at" : "2013-08-07 12:33:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365088231437516800",
  "text" : "\u30A4\u30F3\u30AC\u30AA\u30DB\u30FC \u305D\u306E\u4EE3\u511F\u306B \u4FFA\u306F\u6B7B\u306C",
  "id" : 365088231437516800,
  "created_at" : "2013-08-07 12:33:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365087952583393282",
  "geo" : { },
  "id_str" : "365088003862953985",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 365088003862953985,
  "in_reply_to_status_id" : 365087952583393282,
  "created_at" : "2013-08-07 12:32:17 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365087907242971136",
  "text" : "\u702C\u3092\u306F\u3084\u307F \u305D\u306E\u4EE3\u511F\u306B \u4FFA\u306F\u6B7B\u306C (\u6C34\u96E3\u4E8B\u6545)",
  "id" : 365087907242971136,
  "created_at" : "2013-08-07 12:31:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365087653969932288",
  "text" : "\u67FF\u306B\u4E2D\u3063\u3066\u6B7B\u306C",
  "id" : 365087653969932288,
  "created_at" : "2013-08-07 12:30:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 3, 18 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365087613327118338",
  "text" : "RT @kanoto_hitsuji: \u67FF\u98DF\u3048\u3070 \u305D\u306E\u4EE3\u511F\u306B \u4FFA\u306F\u6B7B\u306C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365087513569792001",
    "text" : "\u67FF\u98DF\u3048\u3070 \u305D\u306E\u4EE3\u511F\u306B \u4FFA\u306F\u6B7B\u306C",
    "id" : 365087513569792001,
    "created_at" : "2013-08-07 12:30:20 +0000",
    "user" : {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "protected" : false,
      "id_str" : "112678195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000133370705\/7e4c0c7ed3e9f2e926e0bd5bb2b7bca8_normal.jpeg",
      "id" : 112678195,
      "verified" : false
    }
  },
  "id" : 365087613327118338,
  "created_at" : "2013-08-07 12:30:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365087513569792001",
  "geo" : { },
  "id_str" : "365087599804682241",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u6BD2\u98DF\u3046\u866B\u306F\u76BF\u3082\u5927\u597D\u304D",
  "id" : 365087599804682241,
  "in_reply_to_status_id" : 365087513569792001,
  "created_at" : "2013-08-07 12:30:41 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365087400155820032",
  "text" : "\u30DD\u30A8\u30C3\u30C8\uFF01",
  "id" : 365087400155820032,
  "created_at" : "2013-08-07 12:29:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5CA1\u672C\u6681\u5E83\u3004\u7CBE\u795E\u3068\u6642\u306E\u9AEA",
      "screen_name" : "henkma",
      "indices" : [ 3, 10 ],
      "id_str" : "45520875",
      "id" : 45520875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365087369449312257",
  "text" : "RT @henkma: \u9CF4\u304B\u306C\u306A\u3089 \u9CF4\u304B\u305B\u3066\u307F\u305B\u3088\u3046 \u30DB\u30C8\u30C8\u30AE\u30B9 \u305D\u306E\u4EE3\u511F\u306B\u4FFA\u306F\u6B7B\u306C \uFF08\u3053\u3046\uFF1F\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365087308346703872",
    "text" : "\u9CF4\u304B\u306C\u306A\u3089 \u9CF4\u304B\u305B\u3066\u307F\u305B\u3088\u3046 \u30DB\u30C8\u30C8\u30AE\u30B9 \u305D\u306E\u4EE3\u511F\u306B\u4FFA\u306F\u6B7B\u306C \uFF08\u3053\u3046\uFF1F\uFF09",
    "id" : 365087308346703872,
    "created_at" : "2013-08-07 12:29:31 +0000",
    "user" : {
      "name" : "\u5CA1\u672C\u6681\u5E83\u3004\u7CBE\u795E\u3068\u6642\u306E\u9AEA",
      "screen_name" : "henkma",
      "protected" : false,
      "id_str" : "45520875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3213753488\/c693aa532154076f8bc8fd61f31e3cfb_normal.png",
      "id" : 45520875,
      "verified" : false
    }
  },
  "id" : 365087369449312257,
  "created_at" : "2013-08-07 12:29:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365087066024968193",
  "text" : "\u305D\u306E\u4EE3\u511F\u306B\u4FFA\u306F\u6B7B\u306C \u4E0B\u306E\u53E5\u306B\u4F7F\u3048\u305D\u3046",
  "id" : 365087066024968193,
  "created_at" : "2013-08-07 12:28:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365073639143518213",
  "text" : "\u3081\u304C\u3044\u305F\u3044",
  "id" : 365073639143518213,
  "created_at" : "2013-08-07 11:35:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365073596483252224",
  "text" : "\u5DE6\u76EE\u304B\u3089\u3084\u308B\u6C17\u304C\u6D41\u308C\u843D\u3061\u3066\u3044\u308B",
  "id" : 365073596483252224,
  "created_at" : "2013-08-07 11:35:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365039773712261120",
  "text" : "10\u5206\u306E\u77ED\u3055\u306B\u60B6\u7D76\u3057\u3066\u308B",
  "id" : 365039773712261120,
  "created_at" : "2013-08-07 09:20:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364993073224228864",
  "geo" : { },
  "id_str" : "365014737035075584",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u5E74\u660E\u3051\u3066\u304B\u3089\u306A\u3089\u826F\u3044\u304C\u305D\u308C\u4EE5\u524D\u306F\u5352\u8AD6\u3067\u6B7B\u3093\u3067\u308B",
  "id" : 365014737035075584,
  "in_reply_to_status_id" : 364993073224228864,
  "created_at" : "2013-08-07 07:41:09 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364953569545297921",
  "text" : "\u3044\u2026\u4EE5\u4E0A\u3067\u3059\uFF01",
  "id" : 364953569545297921,
  "created_at" : "2013-08-07 03:38:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364953513182240768",
  "text" : "\u30C6\u30F3\u30C9\u30F3\u4EE5\u5916\u306F\u305A\u308B\u3044\u3068\u306F\u9650\u3089\u306A\u3044",
  "id" : 364953513182240768,
  "created_at" : "2013-08-07 03:37:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364953443024125953",
  "text" : "\u30C6\u30F3\u30C9\u30F3\u306F\u305A\u308B\u3044",
  "id" : 364953443024125953,
  "created_at" : "2013-08-07 03:37:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364953382991036416",
  "text" : "\u30C6\u30F3\u30C9\u30F3\u305A\u308B\u3044",
  "id" : 364953382991036416,
  "created_at" : "2013-08-07 03:37:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364952373384314882",
  "text" : "\u98A8\u7ACB\u3061\u306C\u306F\u7B39\u53D6\u308A\u306B\u3044\u3063\u305F\u3089\u5C71\u5965\u3067\u304A\u5316\u3051\u306B\u906D\u3063\u3066\u540D\u524D\u3092\u596A\u308F\u308C\u3066\u6D77\u8CCA\u306B\u306A\u3063\u305F\u6319\u53E5\u306B\u6700\u5F8C\u306F\u6EB6\u9271\u7089\u306E\u4E2D\u306B\u89AA\u6307\u7ACB\u3066\u306A\u304C\u3089\u6C88\u3093\u3067\u884C\u304F\u6620\u753B\u3067\u3057\u3087\u3001\u3048\u3093\u3069\u77E5\u3063\u3066\u308B",
  "id" : 364952373384314882,
  "created_at" : "2013-08-07 03:33:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364949970677284865",
  "text" : "\u53CB\u4EBA\u306B\u3088\u308B\u304A\u904D\u8DEF\u5B9F\u6CC1\u304C\u30A2\u30C4\u3044",
  "id" : 364949970677284865,
  "created_at" : "2013-08-07 03:23:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364949088032129026",
  "text" : "\u30AA\u30FC\u30D7\u30F3\u30AD\u30E3\u30F3\u30D1\u30B9\u8003\u3048\u305F\u3084\u3064\u30B1\u30B8\u30E1",
  "id" : 364949088032129026,
  "created_at" : "2013-08-07 03:20:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364948935590158336",
  "text" : "\u3042\u30FC\u3001\u6C57\u304C\u30FC",
  "id" : 364948935590158336,
  "created_at" : "2013-08-07 03:19:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364945915204747266",
  "text" : "\u98DF\u5802\u6DF7\u3093\u3067\u308B\u2026",
  "id" : 364945915204747266,
  "created_at" : "2013-08-07 03:07:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364942451481391105",
  "text" : "\u81EA\u5206\u306E\u6642\u306F\u6765\u3082\u3057\u306A\u304B\u3063\u305F\u306E\u306B\u306A\u2026",
  "id" : 364942451481391105,
  "created_at" : "2013-08-07 02:53:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364942222325579777",
  "text" : "\u6211\u304C\u7269\u9854\u3067\u30AA\u30FC\u30D7\u30F3\u30AD\u30E3\u30F3\u30D1\u30B9\u306E\u8CC7\u6599\u3092\u3082\u3089\u30464\u56DE\u751F\u306E\u59FF\u304C\u305D\u3053\u306B\u306F\u3042\u3063\u305F\u3002\u3066\u3044\u3046\u304B\u50D5\u3060\u3063\u305F\u3002",
  "id" : 364942222325579777,
  "created_at" : "2013-08-07 02:53:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364938878118932481",
  "text" : "\u8CC7\u6599\u3082\u3089\u3048\u3063\u304B\u306A\u2026",
  "id" : 364938878118932481,
  "created_at" : "2013-08-07 02:39:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364938833617367042",
  "text" : "\u30AA\u30FC\u30D7\u30F3\u30AD\u30E3\u30F3\u30D1\u30B9\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 364938833617367042,
  "created_at" : "2013-08-07 02:39:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E94\u8272",
      "screen_name" : "Rskud",
      "indices" : [ 3, 9 ],
      "id_str" : "392028823",
      "id" : 392028823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364930657715101696",
  "text" : "RT @Rskud: \u305D\u3057\u3066\u5F7C\u3089\u306FTwitter\u306E\u30AB\u30C1\u30B0\u30DF\u30FB\u30B5\u30E9\u30EA\u30DE\u30F3\u306B\u30CF\u30F3\u30C6\u30A3\u30F3\u30B0\u3055\u308C\u308B\u306E\u3060\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364930591382192129",
    "text" : "\u305D\u3057\u3066\u5F7C\u3089\u306FTwitter\u306E\u30AB\u30C1\u30B0\u30DF\u30FB\u30B5\u30E9\u30EA\u30DE\u30F3\u306B\u30CF\u30F3\u30C6\u30A3\u30F3\u30B0\u3055\u308C\u308B\u306E\u3060\uFF01",
    "id" : 364930591382192129,
    "created_at" : "2013-08-07 02:06:47 +0000",
    "user" : {
      "name" : "\u4E94\u8272",
      "screen_name" : "Rskud",
      "protected" : false,
      "id_str" : "392028823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582188419775787008\/HgoK92O__normal.jpg",
      "id" : 392028823,
      "verified" : false
    }
  },
  "id" : 364930657715101696,
  "created_at" : "2013-08-07 02:07:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364930215434125313",
  "text" : "\u51B7\u8535\u5EAB\u306B\u5165\u308B\u3068\u304B\u30D0\u30A4\u30AA\u30B9\u30E2\u30C8\u30EA\u304B\u3088\uFF01\u3068\u3044\u3046\u308F\u304B\u308A\u306B\u304F\u3044\u30C4\u30C3\u30B3\u30DF\u3092\u601D\u3044\u3064\u3044\u305F\u3002",
  "id" : 364930215434125313,
  "created_at" : "2013-08-07 02:05:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364929830464139265",
  "text" : "\u30DE\u30C3\u30DD\u30FC\u3081\u3044\u305F\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u91CD\u70B9",
  "id" : 364929830464139265,
  "created_at" : "2013-08-07 02:03:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364929752814993410",
  "text" : "\u656C\u79F0\u3067\u547C\u3070\u306A\u3044\u3068\u30E0\u30E9\u30CF\u30C1\u304B",
  "id" : 364929752814993410,
  "created_at" : "2013-08-07 02:03:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3089\u3053",
      "screen_name" : "laco0416",
      "indices" : [ 3, 12 ],
      "id_str" : "498602690",
      "id" : 498602690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364929666085163008",
  "text" : "RT @laco0416: \u3055\u3063\u304D\u8ABF\u3079\u305F\u3089\u56FD\u4F1A\u306E\u4E2D\u3067\u306F\u8B70\u54E1\u540C\u58EB\u306F\u656C\u79F0\u3067\u547C\u3073\u5408\u3044\u307E\u3057\u3087\u3046\u3063\u3066\u6CD5\u5F8B\u3067\u5B9A\u3081\u3089\u308C\u3066\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/smileessence.miz-hi.net\/index.html\" rel=\"nofollow\"\u003ESmileEssence Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364929539425579008",
    "text" : "\u3055\u3063\u304D\u8ABF\u3079\u305F\u3089\u56FD\u4F1A\u306E\u4E2D\u3067\u306F\u8B70\u54E1\u540C\u58EB\u306F\u656C\u79F0\u3067\u547C\u3073\u5408\u3044\u307E\u3057\u3087\u3046\u3063\u3066\u6CD5\u5F8B\u3067\u5B9A\u3081\u3089\u308C\u3066\u305F",
    "id" : 364929539425579008,
    "created_at" : "2013-08-07 02:02:36 +0000",
    "user" : {
      "name" : "\u3089\u3053",
      "screen_name" : "laco0416",
      "protected" : false,
      "id_str" : "498602690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567892503362154496\/h87qkh1e_normal.png",
      "id" : 498602690,
      "verified" : false
    }
  },
  "id" : 364929666085163008,
  "created_at" : "2013-08-07 02:03:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364868129677000704",
  "geo" : { },
  "id_str" : "364921732215218178",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u307E\u30FC\u3044\u3064\u3082\u3060\u304C\u304F\u308B\u6642\u304C\u308F\u304B\u308A\u6B21\u7B2C\u9023\u7D61\u3057\u3061\u304F\u308A\u30FC",
  "id" : 364921732215218178,
  "in_reply_to_status_id" : 364868129677000704,
  "created_at" : "2013-08-07 01:31:35 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364776267402330114",
  "text" : "\u5BDD\u308B\u2026\u304A\u4F11\u307F\uFF01",
  "id" : 364776267402330114,
  "created_at" : "2013-08-06 15:53:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364775628286865408",
  "geo" : { },
  "id_str" : "364775768124956672",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u8AAD\u3082\u3046\uFF01[\u30CB\u30F3\u30B8\u30E3\u30B9\u30EC\u30A4\u30E4\u30FC\u6717\u8AAD\u30C4\u30A4\u30AD\u30E3\u30B9]",
  "id" : 364775768124956672,
  "in_reply_to_status_id" : 364775628286865408,
  "created_at" : "2013-08-06 15:51:34 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364775309838532608",
  "geo" : { },
  "id_str" : "364775403971284992",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30E0\u30E9\u30CF\u30C1\u306F\u30AB\u30BF\u30AB\u30CA\uFF01\u5927\u4E8B\uFF01",
  "id" : 364775403971284992,
  "in_reply_to_status_id" : 364775309838532608,
  "created_at" : "2013-08-06 15:50:08 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364775286484631554",
  "text" : "\u30E2\u30B9\u30D0\u30FC\u30AC\u30FC\u304C\u30DC\u30FC\u30C0\u30FC\u3060\u3063\u305F\u3093\u3060\u304C\u306A\u3041\u2026",
  "id" : 364775286484631554,
  "created_at" : "2013-08-06 15:49:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364775223117103104",
  "text" : "\u307E\u305F\u4E00\u3064\"\u3061\u3083\u3093\u3068\u3057\u305F\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\"\u3092\u51FA\u3059\u5E97\u304C\u306A\u304F\u306A\u3063\u3066\u3057\u307E\u3046",
  "id" : 364775223117103104,
  "created_at" : "2013-08-06 15:49:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "indices" : [ 3, 12 ],
      "id_str" : "105498380",
      "id" : 105498380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364775129886113792",
  "text" : "RT @_Nururin: \u3048\u3001\u767E\u4E07\u904D\u30E2\u30B9\u9589\u5E97\u3059\u3093\u306E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sourceforge.jp\/projects\/opentween\/\" rel=\"nofollow\"\u003EOpenTween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364775028279091200",
    "text" : "\u3048\u3001\u767E\u4E07\u904D\u30E2\u30B9\u9589\u5E97\u3059\u3093\u306E",
    "id" : 364775028279091200,
    "created_at" : "2013-08-06 15:48:38 +0000",
    "user" : {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "protected" : false,
      "id_str" : "105498380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591661205489520640\/gzUrW2-9_normal.jpg",
      "id" : 105498380,
      "verified" : false
    }
  },
  "id" : 364775129886113792,
  "created_at" : "2013-08-06 15:49:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364775092753924097",
  "text" : "\u30E0\u30B8\u30E7\u30A6\uFF01",
  "id" : 364775092753924097,
  "created_at" : "2013-08-06 15:48:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364774443748294656",
  "geo" : { },
  "id_str" : "364774480226168833",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30E6\u30A6\u30B8\u30E7\u30A6\uFF01",
  "id" : 364774480226168833,
  "in_reply_to_status_id" : 364774443748294656,
  "created_at" : "2013-08-06 15:46:27 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "s.t.fake@\u4FEE\u884C\u306E\u5FC5\u8981\u6027",
      "screen_name" : "st_fake",
      "indices" : [ 3, 11 ],
      "id_str" : "158636586",
      "id" : 158636586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/q2BydfVdtl",
      "expanded_url" : "http:\/\/kokucheese.com\/event\/index\/106711\/",
      "display_url" : "kokucheese.com\/event\/index\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364774088079704064",
  "text" : "RT @st_fake: \u95A2\u897F\u3059\u3046\u304C\u304F\u5F92\u306E\u96C6\u3044\u3001\u516C\u5F0F\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30EA\u30F3\u30AF\u304C\u3061\u3087\u3063\u3068\u5D29\u308C\u3066\u308B\u306E\u3067\u3053\u3063\u3061\u304B\u3089\u98DB\u3076\u3068\u3044\u3044\u304B\u3082\u3088\u3093\u3002\uFF1Ehttp:\/\/t.co\/q2BydfVdtl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/migratory-of-dimension.blog.jp\/\" rel=\"nofollow\"\u003E\u3075\u3047\u3044\u304F\u3055\u3093\u306E\u304A\u3046\u3061\u30FB\u6539\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/q2BydfVdtl",
        "expanded_url" : "http:\/\/kokucheese.com\/event\/index\/106711\/",
        "display_url" : "kokucheese.com\/event\/index\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364774042168852481",
    "text" : "\u95A2\u897F\u3059\u3046\u304C\u304F\u5F92\u306E\u96C6\u3044\u3001\u516C\u5F0F\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u30EA\u30F3\u30AF\u304C\u3061\u3087\u3063\u3068\u5D29\u308C\u3066\u308B\u306E\u3067\u3053\u3063\u3061\u304B\u3089\u98DB\u3076\u3068\u3044\u3044\u304B\u3082\u3088\u3093\u3002\uFF1Ehttp:\/\/t.co\/q2BydfVdtl",
    "id" : 364774042168852481,
    "created_at" : "2013-08-06 15:44:43 +0000",
    "user" : {
      "name" : "s.t.fake@\u4FEE\u884C\u306E\u5FC5\u8981\u6027",
      "screen_name" : "st_fake",
      "protected" : false,
      "id_str" : "158636586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536334489450848256\/Z0pk6hnk_normal.jpeg",
      "id" : 158636586,
      "verified" : false
    }
  },
  "id" : 364774088079704064,
  "created_at" : "2013-08-06 15:44:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364773956500197378",
  "text" : "\u4F55\u304B\u3082\u3046\u6B7B\u306C\u306A\u3089\u6B7B\u306C\u3067\u6B7B\u3093\u3067\u304B\u3089\u8003\u3048\u308C\u3070\u3044\u3044\u3068\u601D\u3063\u3066\u308B",
  "id" : 364773956500197378,
  "created_at" : "2013-08-06 15:44:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364773802917363712",
  "geo" : { },
  "id_str" : "364773861897682944",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30AC\u30F3\u30D0\u30EA\u30DE\u30B9",
  "id" : 364773861897682944,
  "in_reply_to_status_id" : 364773802917363712,
  "created_at" : "2013-08-06 15:44:00 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364773765235736577",
  "text" : "\u4ED6\u306A\u3089\u4F59\u88D5\u3068\u304B\u8A00\u3048\u306A\u3044\u304B\u3089\u4E0A\u304B\u3089\u6291\u3048\u3089\u308C\u3066\u6B7B\u306C",
  "id" : 364773765235736577,
  "created_at" : "2013-08-06 15:43:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364773459424854016",
  "geo" : { },
  "id_str" : "364773567033901056",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u305D\u308C\u306A\u2026",
  "id" : 364773567033901056,
  "in_reply_to_status_id" : 364773459424854016,
  "created_at" : "2013-08-06 15:42:50 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364772784011882496",
  "text" : "\u6700\u901F\u3067\u6B7B\u306C",
  "id" : 364772784011882496,
  "created_at" : "2013-08-06 15:39:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364772587521323010",
  "geo" : { },
  "id_str" : "364772715724419072",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u53C2\u52A0\u6B7B\u9A13\u2026",
  "id" : 364772715724419072,
  "in_reply_to_status_id" : 364772587521323010,
  "created_at" : "2013-08-06 15:39:27 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364772169332428800",
  "geo" : { },
  "id_str" : "364772308260368385",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u6B21\u306F\u53C2\u52A0\u8005\u96C6\u3063\u3066\u6226\u304A\u3046",
  "id" : 364772308260368385,
  "in_reply_to_status_id" : 364772169332428800,
  "created_at" : "2013-08-06 15:37:50 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364771684777070592",
  "text" : "\u30BC\u30EA\u30FC\u3055\u3093\u306E\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u304C\u307E\u3068\u3082\u3059\u304E\u3066\u6065\u305A\u304B\u3057\u3044",
  "id" : 364771684777070592,
  "created_at" : "2013-08-06 15:35:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 15, 31 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364771399610540034",
  "geo" : { },
  "id_str" : "364771516069593089",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty @Jelly_in_a_tank \u3053\u308C\u304C\u5149\u306E\u65E9\u3055\u3067\u3059\u304B\u2026",
  "id" : 364771516069593089,
  "in_reply_to_status_id" : 364771399610540034,
  "created_at" : "2013-08-06 15:34:41 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364770017771921408",
  "geo" : { },
  "id_str" : "364770133899616257",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u6C17\u306B\u306A\u308B\u3088\u306D\u3001\u305D\u308C\u3002",
  "id" : 364770133899616257,
  "in_reply_to_status_id" : 364770017771921408,
  "created_at" : "2013-08-06 15:29:11 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364767167884967936",
  "geo" : { },
  "id_str" : "364768395524190210",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p \u8FFD\u3063\u3066\u9023\u7D61\u3057\u307E\u3059\u30FC",
  "id" : 364768395524190210,
  "in_reply_to_status_id" : 364767167884967936,
  "created_at" : "2013-08-06 15:22:17 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364768172898918400",
  "text" : "\u3053\u306E\u30DA\u30FC\u30B9\u3060\u30683\uFF0C4\u65E5\u306F\u6301\u305F\u306A\u3044\u304B\u306A\u3002\u4ECA\u65E5\u306E\u671D\u8D77\u304D\u3066\u304B\u3089\u306E\u4EBA\u3082\u3044\u308B\u304B\u3089\u308F\u304B\u3089\u3093\u307D\u3093\u3060\u304C\u3002",
  "id" : 364768172898918400,
  "created_at" : "2013-08-06 15:21:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364767685743095808",
  "text" : "\u305B\u304B\u30CA\u30F3\u30C8\u30AB\u307D\u30CA\u30F3\u30C8\u30AB\u3048\u3080\u3055\u3093\u3001\u76F8\u5909\u308F\u3089\u305A\u306E\u30B3\u30F3\u30C6\u30F3\u30C4\u529B\u3067\u3042\u308B",
  "id" : 364767685743095808,
  "created_at" : "2013-08-06 15:19:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u95A2\u897F\u3059\u3046\u304C\u304F\u5F92\u306E\u3064\u3069\u3044",
      "screen_name" : "kansaimath",
      "indices" : [ 3, 14 ],
      "id_str" : "819871357",
      "id" : 819871357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364767215540633601",
  "text" : "RT @kansaimath: \u30C8\u30C3\u30D7\u306Fend\u3055\u3093\u3067\u3057\u305F\uFF01\uFF01\u795D( ^^)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364765163464830977",
    "text" : "\u30C8\u30C3\u30D7\u306Fend\u3055\u3093\u3067\u3057\u305F\uFF01\uFF01\u795D( ^^)",
    "id" : 364765163464830977,
    "created_at" : "2013-08-06 15:09:26 +0000",
    "user" : {
      "name" : "\u95A2\u897F\u3059\u3046\u304C\u304F\u5F92\u306E\u3064\u3069\u3044",
      "screen_name" : "kansaimath",
      "protected" : false,
      "id_str" : "819871357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558444210320191490\/SC7oiFvZ_normal.jpeg",
      "id" : 819871357,
      "verified" : false
    }
  },
  "id" : 364767215540633601,
  "created_at" : "2013-08-06 15:17:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364766722072391682",
  "geo" : { },
  "id_str" : "364766861977587714",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p 12,13\u3042\u305F\u308A\u306B\u3044\u308B\u3068\u601D\u3046\u306E\u3067\u304A\u6642\u9593\u3042\u3063\u305F\u3089\u3054\u98EF\u3067\u3082",
  "id" : 364766861977587714,
  "in_reply_to_status_id" : 364766722072391682,
  "created_at" : "2013-08-06 15:16:11 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364766481042522113",
  "geo" : { },
  "id_str" : "364766629743177729",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30A2\u30C3\u30CF\u30A4",
  "id" : 364766629743177729,
  "in_reply_to_status_id" : 364766481042522113,
  "created_at" : "2013-08-06 15:15:16 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364766532741500929",
  "text" : "\u3053\u3053\u307E\u3067\u61C7\u89AA\u4F1A\u30AA\u30FC\u30EB\u30B0\u30EA\u30FC\u30F3wwwww",
  "id" : 364766532741500929,
  "created_at" : "2013-08-06 15:14:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364766030570061826",
  "geo" : { },
  "id_str" : "364766268164808705",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u9AA8\u5207\u308A\u5305\u4E01\u3067\u8089\u3082\u65AC\u308B\u3068\u3044\u3046\u3084\u3064\u3060\u306A",
  "id" : 364766268164808705,
  "in_reply_to_status_id" : 364766030570061826,
  "created_at" : "2013-08-06 15:13:50 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364765892053176321",
  "geo" : { },
  "id_str" : "364766097242730497",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p \u3044\u3064\u307E\u3067\u5B9F\u5BB6\u306B\u3044\u308B\u3093\u3067\u3059\uFF1F(\u63A8\u79FB\u7684\u3064\u3069\u3044\u306E\u753B\u7B56)",
  "id" : 364766097242730497,
  "in_reply_to_status_id" : 364765892053176321,
  "created_at" : "2013-08-06 15:13:09 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 12, 28 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364765893357608960",
  "text" : "@umichoco11 @Jelly_in_a_tank \u3042\u308B\u3079\u304D\u59FF\u3060",
  "id" : 364765893357608960,
  "created_at" : "2013-08-06 15:12:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364765719923142656",
  "text" : "\u3069\u3046\u3082\u3001\u5FC3\u306A\u3044\u4EBA\u3067\u3059",
  "id" : 364765719923142656,
  "created_at" : "2013-08-06 15:11:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364765676021366784",
  "text" : "\u5FC3\u306F\u914D\u308A\u3059\u304E\u3066\u624B\u5143\u306B\u306A\u304B\u3063\u305F",
  "id" : 364765676021366784,
  "created_at" : "2013-08-06 15:11:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364765414493913089",
  "geo" : { },
  "id_str" : "364765602230976513",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u65E9\u3055\u304C\u5927\u4E8B\u306A\u3093\u3058\u3083\u306A\u3044\u3093\u3067\u3059\u304B\u30FC\uFF1F\uFF1F\uFF1F",
  "id" : 364765602230976513,
  "in_reply_to_status_id" : 364765414493913089,
  "created_at" : "2013-08-06 15:11:11 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364765437545816065",
  "text" : "\u4ECA\u5EA6\u306Ftwipla\u3067\u3082\u4F5C\u3063\u3066\u3061\u3083\u3093\u3068\u307F\u3093\u306A\u3068\u6226\u304A\u3046(\uFF1F)",
  "id" : 364765437545816065,
  "created_at" : "2013-08-06 15:10:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364765146851192832",
  "text" : "\u3082\u3063\u3068\u3053\u3046\u30B5\u30C4\u30D0\u30C4\u3081\u3044\u305F\u6226\u3044\u3092\u671F\u5F85\u3057\u3066\u3044\u305F\u304C\u79D2\u5358\u4F4D\u3067\u4E89\u3063\u3066\u308B\u306E\u30BC\u30EA\u30FC\u3055\u3093\u3060\u3051\u3058\u3083\u3093wwwww\u30A6\u30B1\u308Bwwwww",
  "id" : 364765146851192832,
  "created_at" : "2013-08-06 15:09:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364764827891146753",
  "text" : "\u3064\u3069\u3044\u3001\u6700\u901F\u767B\u9332\u306E\u90E8",
  "id" : 364764827891146753,
  "created_at" : "2013-08-06 15:08:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u95A2\u897F\u3059\u3046\u304C\u304F\u5F92\u306E\u3064\u3069\u3044",
      "screen_name" : "kansaimath",
      "indices" : [ 3, 14 ],
      "id_str" : "819871357",
      "id" : 819871357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/2azU505nUj",
      "expanded_url" : "http:\/\/kokucheese.com\/event\/index\/106711\/",
      "display_url" : "kokucheese.com\/event\/index\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364764740356026369",
  "text" : "RT @kansaimath: \u2605\u4E00\u822C\u53C2\u52A0\u8005\u306E\u52DF\u96C6\u3092\u958B\u59CB\u3057\u307E\u3059(^o^)\uFF0F\u3000\u7686\u69D8\u306E\u5FA1\u53C2\u52A0\u3001\u304A\u5F85\u3061\u3057\u3066\u304A\u308A\u307E\u3059\u2605http:\/\/t.co\/2azU505nUj(2013\u5E748\u67087\u65E5)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/2azU505nUj",
        "expanded_url" : "http:\/\/kokucheese.com\/event\/index\/106711\/",
        "display_url" : "kokucheese.com\/event\/index\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364764429243523073",
    "text" : "\u2605\u4E00\u822C\u53C2\u52A0\u8005\u306E\u52DF\u96C6\u3092\u958B\u59CB\u3057\u307E\u3059(^o^)\uFF0F\u3000\u7686\u69D8\u306E\u5FA1\u53C2\u52A0\u3001\u304A\u5F85\u3061\u3057\u3066\u304A\u308A\u307E\u3059\u2605http:\/\/t.co\/2azU505nUj(2013\u5E748\u67087\u65E5)",
    "id" : 364764429243523073,
    "created_at" : "2013-08-06 15:06:31 +0000",
    "user" : {
      "name" : "\u95A2\u897F\u3059\u3046\u304C\u304F\u5F92\u306E\u3064\u3069\u3044",
      "screen_name" : "kansaimath",
      "protected" : false,
      "id_str" : "819871357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558444210320191490\/SC7oiFvZ_normal.jpeg",
      "id" : 819871357,
      "verified" : false
    }
  },
  "id" : 364764740356026369,
  "created_at" : "2013-08-06 15:07:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364764697813196800",
  "text" : "\u4F55\u3053\u306E\u4E0D\u601D\u8B70\u30B9\u30DD\u30FC\u30C4",
  "id" : 364764697813196800,
  "created_at" : "2013-08-06 15:07:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364764657011003394",
  "text" : "\u5927\u52DD\u5229",
  "id" : 364764657011003394,
  "created_at" : "2013-08-06 15:07:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364764335056232449",
  "geo" : { },
  "id_str" : "364764485648527362",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank F5\u9023\u6253\u3068\u304B\u3057\u3066\u306A\u3044\u3057\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u30B3\u30D4\u30FC\u3057\u3066\u304A\u3044\u305F\u308A\u3068\u304B\u3057\u3066\u306A\u3044\u3088\uFF1F",
  "id" : 364764485648527362,
  "in_reply_to_status_id" : 364764335056232449,
  "created_at" : "2013-08-06 15:06:45 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364764297106165761",
  "text" : "\u53C2\u52A0\u6C7A\u3081\u305F\u304Cno2\u304B\u3001\u30BC\u30EA\u30FC\u3055\u3093\uFF1F",
  "id" : 364764297106165761,
  "created_at" : "2013-08-06 15:06:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364763461059751936",
  "text" : "\u307E\u3060\u6E96\u5099\u4E2D",
  "id" : 364763461059751936,
  "created_at" : "2013-08-06 15:02:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364762319764467712",
  "text" : "\u5F85\u6A5F\u30FC",
  "id" : 364762319764467712,
  "created_at" : "2013-08-06 14:58:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364762155272257536",
  "text" : "\u3044\u308F\u3086\u3089\u306D\u30FC\u304B\u30FC",
  "id" : 364762155272257536,
  "created_at" : "2013-08-06 14:57:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364760813162070016",
  "text" : "\u3064\u3069\u3044\u306E\u3042\u308C\u5F85\u6A5F",
  "id" : 364760813162070016,
  "created_at" : "2013-08-06 14:52:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 3, 18 ],
      "id_str" : "199550192",
      "id" : 199550192
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 20, 30 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364750614372171776",
  "text" : "RT @mircea_morning: @end313124 \u3064\u307E\u308A\u3001\u30B8\u30E5\u30FC\u30B8\u30C4\u306F\u30B8\u30E5\u30FC\u30B2\u30FC\u30DF\u30D5\u30A3\u30B1\u30FC\u30B7\u30E7\u30F3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "364750038963978240",
    "geo" : { },
    "id_str" : "364750416552013825",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u3064\u307E\u308A\u3001\u30B8\u30E5\u30FC\u30B8\u30C4\u306F\u30B8\u30E5\u30FC\u30B2\u30FC\u30DF\u30D5\u30A3\u30B1\u30FC\u30B7\u30E7\u30F3",
    "id" : 364750416552013825,
    "in_reply_to_status_id" : 364750038963978240,
    "created_at" : "2013-08-06 14:10:50 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "protected" : false,
      "id_str" : "199550192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494419651342774272\/VcykhvGX_normal.jpeg",
      "id" : 199550192,
      "verified" : false
    }
  },
  "id" : 364750614372171776,
  "created_at" : "2013-08-06 14:11:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364750038963978240",
  "text" : "\u30B2\u30FC\u30DF\u30D5\u30A3\u30B1\u30FC\u30B7\u30E7\u30F3=\u30B8\u30C4",
  "id" : 364750038963978240,
  "created_at" : "2013-08-06 14:09:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364748928048054275",
  "text" : "\u51B7\u8535\u5EAB\u304C\u6A5F\u80FD\u3057\u306A\u304F\u306A\u3063\u3066\u304B\u3089QOL\u3060\u3060\u4E0B\u304C\u308A\u2026",
  "id" : 364748928048054275,
  "created_at" : "2013-08-06 14:04:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364747618829602817",
  "text" : "\u8AB0\u304B\u300C\u30A2\u30D6\u30B9\u30C8\u30E9\u30AF\u30C8\u30CA\u30F3\u30BB\u30F3\u30B9\u300D\u306E\u30DC\u30AB\u30ED\u5C0F\u8AAC\u306E\u76AE\u3092\u88AB\u3063\u305F\u30B1\u30F3\u30ED\u30F3\u306E\u6559\u79D1\u66F8\u66F8\u3044\u3066\u304F\u308C\u306A\u3044\u304B\u306A\u30FC",
  "id" : 364747618829602817,
  "created_at" : "2013-08-06 13:59:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364747231112335360",
  "geo" : { },
  "id_str" : "364747354185797633",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u305D\u3093\u306A\u6DF1\u591C\u5F98\u5F8A\u30AA\u30D5\u307F\u305F\u3044\u306A\u3053\u3068\u306F\u305D\u3046\u305D\u3046\u8D77\u304D\u306A\u3044\u305C\u30FC",
  "id" : 364747354185797633,
  "in_reply_to_status_id" : 364747231112335360,
  "created_at" : "2013-08-06 13:58:40 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364744878351073280",
  "text" : "\u30B3\u30F3\u30D3\u30CB\u8FD1\u3044\u304B\u3089\u306A\u2026",
  "id" : 364744878351073280,
  "created_at" : "2013-08-06 13:48:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364744440092434433",
  "geo" : { },
  "id_str" : "364744815088373761",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u4F1A\u308F\u306A\u304B\u3063\u305F",
  "id" : 364744815088373761,
  "in_reply_to_status_id" : 364744440092434433,
  "created_at" : "2013-08-06 13:48:35 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364744014882275330",
  "geo" : { },
  "id_str" : "364744146059149314",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u30BF\u30A4\u30DF\u30F3\u30B0\u304C\u795E\u304C\u304B\u3063\u3066\u305F",
  "id" : 364744146059149314,
  "in_reply_to_status_id" : 364744014882275330,
  "created_at" : "2013-08-06 13:45:55 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364743921189912576",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u3053\u3093\u3073\u306B\u3078",
  "id" : 364743921189912576,
  "created_at" : "2013-08-06 13:45:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364743567048056833",
  "geo" : { },
  "id_str" : "364743828718108672",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u5168\u304F\u540C\u3058\u3053\u3068\u601D\u3063\u305F",
  "id" : 364743828718108672,
  "in_reply_to_status_id" : 364743567048056833,
  "created_at" : "2013-08-06 13:44:40 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364742462075441155",
  "geo" : { },
  "id_str" : "364742537291898881",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u8ECA\u306E\u30B7\u30E7\u30C3\u30D7\u3068\u3044\u3046\u610F\u5473\u3067\uFF1F",
  "id" : 364742537291898881,
  "in_reply_to_status_id" : 364742462075441155,
  "created_at" : "2013-08-06 13:39:32 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364742459953123329",
  "text" : "\u5B9F\u969B\u98DF\u80B2\u306F\u5927\u4E8B\u3060\u3088\u306A\u2026\u89AA\u306E\u6599\u7406\u306E\u8155\u306B\u3069\u3046\u3057\u305F\u3063\u3066\u4F9D\u5B58\u3057\u3061\u3083\u3046\u304C\u2026",
  "id" : 364742459953123329,
  "created_at" : "2013-08-06 13:39:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364742144302395394",
  "text" : "\u3068\u306F\u3044\u3048\u89AA\u542B\u3081\u3066\u6570\u4EBA\u5927\u6839\u304A\u308D\u3057\u3054\u98EF\u306E\u652F\u6301\u8005\u3092\u77E5\u3063\u3066\u308B\u304B\u3089\u30A2\u30EA\u306A\u3093\u3060\u308D\u3046\u306A\u30FC",
  "id" : 364742144302395394,
  "created_at" : "2013-08-06 13:37:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "410natsuki529",
      "screen_name" : "tatyusa419",
      "indices" : [ 0, 11 ],
      "id_str" : "2531832002",
      "id" : 2531832002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364741960029835266",
  "text" : "@tatyusa419 \u5927\u6839\u304A\u308D\u3057\u597D\u304D\u306A\u4EBA\u306F\u597D\u304D\u3089\u3057\u3044\u304C\u2026\u50D5\u306F\u3061\u3087\u3063\u3068\u7121\u7406\u3002",
  "id" : 364741960029835266,
  "created_at" : "2013-08-06 13:37:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rev_gun",
      "screen_name" : "howasepu",
      "indices" : [ 0, 9 ],
      "id_str" : "2530338835",
      "id" : 2530338835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364741237749714944",
  "geo" : { },
  "id_str" : "364741777074302976",
  "in_reply_to_user_id" : 330432607,
  "text" : "@howasepu (\u5B9F\u306E\u5F1F\u306A\u306E\u3067\u3042\u308C\u3067\u3059\u304C)\u3067\u3059\u306D\u3002[\u50D5\u306F\u4E0B\u5BBF\u3059\u308B\u3088\u3046\u306B\u306A\u3063\u3066\u3042\u308A\u304C\u305F\u307F\u3092\u77E5\u308A\u307E\u3057\u305F\u306D]",
  "id" : 364741777074302976,
  "in_reply_to_status_id" : 364741237749714944,
  "created_at" : "2013-08-06 13:36:30 +0000",
  "in_reply_to_screen_name" : "gravestone11",
  "in_reply_to_user_id_str" : "330432607",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364741416276066304",
  "text" : "\u3046\u3061\u306E\u89AA\u3001\u6599\u7406\u5ACC\u3044\u3068\u8A00\u3046\u5272\u306B\u4F5C\u308B\u3082\u306E\u306F\u7F8E\u5473\u3057\u3044\u306A\u3002\u4E00\u4EBA\u3060\u3068\u5927\u6839\u304A\u308D\u3057\u3067\u3054\u98EF\u3068\u304B\u98DF\u3079\u308B\u4EBA\u3060\u3051\u3069\u3002",
  "id" : 364741416276066304,
  "created_at" : "2013-08-06 13:35:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rev_gun",
      "screen_name" : "howasepu",
      "indices" : [ 0, 9 ],
      "id_str" : "2530338835",
      "id" : 2530338835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364740797884669952",
  "geo" : { },
  "id_str" : "364741171471327232",
  "in_reply_to_user_id" : 330432607,
  "text" : "@howasepu \u50D5\u306E\u5F1F\u306F\u3061\u3087\u3063\u3068\u5DE5\u592B\u3057\u305F\u6599\u7406\u304C\u51FA\u308B\u3068\u7BB8\u3092\u3064\u3051\u306A\u3044\u4FDD\u5B88\u7684\u306A\u5B50\u306A\u306E\u3067\u2026",
  "id" : 364741171471327232,
  "in_reply_to_status_id" : 364740797884669952,
  "created_at" : "2013-08-06 13:34:06 +0000",
  "in_reply_to_screen_name" : "gravestone11",
  "in_reply_to_user_id_str" : "330432607",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364740862284017664",
  "text" : "\u5F1F\u304C\u8089\u713C\u3044\u305F\u3084\u3064\u306B\u713C\u8089\u306E\u30BF\u30EC\u304B\u3051\u308B\u3001\u3060\u3051\u3067\u6E80\u8DB3\u3067\u304D\u308B\u4EBA\u7A2E\u3089\u3057\u304F\u3066\u89AA\u304C\u5F35\u308A\u5408\u3044\u306A\u3044\u3068\u8A00\u3063\u3066\u305F\u306A\u3041",
  "id" : 364740862284017664,
  "created_at" : "2013-08-06 13:32:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364740583509602305",
  "text" : "[\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u3066\u306A\u3044\u4EBA\u306B\u30EA\u30D7\u30E9\u30A4\u98DB\u3070\u3059\u306E\u4E45\u3005\u306B\u3084\u3063\u3066\u3057\u307E\u3063\u305F]",
  "id" : 364740583509602305,
  "created_at" : "2013-08-06 13:31:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rev_gun",
      "screen_name" : "howasepu",
      "indices" : [ 0, 9 ],
      "id_str" : "2530338835",
      "id" : 2530338835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364740294727565314",
  "geo" : { },
  "id_str" : "364740475267190784",
  "in_reply_to_user_id" : 330432607,
  "text" : "@howasepu \u3042\u308B\u7A0B\u5EA6\u6587\u53E5\u8A00\u308F\u308C\u305F\u65B9\u304C\u5F35\u308A\u5408\u3044\u306F\u3042\u308B\u3001\u3089\u3057\u3044\u3067\u3059\u3051\u308C\u3069[\u3046\u3061\u306E\u6BCD\u89AA\u66F0\u304F]",
  "id" : 364740475267190784,
  "in_reply_to_status_id" : 364740294727565314,
  "created_at" : "2013-08-06 13:31:20 +0000",
  "in_reply_to_screen_name" : "gravestone11",
  "in_reply_to_user_id_str" : "330432607",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364737487618318337",
  "geo" : { },
  "id_str" : "364737559382863873",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u30B8\u30FC",
  "id" : 364737559382863873,
  "in_reply_to_status_id" : 364737487618318337,
  "created_at" : "2013-08-06 13:19:45 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364717538371846145",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 364717538371846145,
  "created_at" : "2013-08-06 12:00:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364713410669182976",
  "geo" : { },
  "id_str" : "364713565325758464",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u305D\u308A\u3083\u306D[\u3060\u304B\u3089\u3053\u305D\u6311\u6226\u3059\u308B\u610F\u5473\u304C\uFF1F]",
  "id" : 364713565325758464,
  "in_reply_to_status_id" : 364713410669182976,
  "created_at" : "2013-08-06 11:44:24 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364705945978290177",
  "text" : "\u4E00\u77AC\u307E\u30607\u6708\u304B\u3068\u601D\u308F\u3055\u308C\u305F\u308F",
  "id" : 364705945978290177,
  "created_at" : "2013-08-06 11:14:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364705882698817536",
  "text" : "\u3073\u3063\u304F\u308A\u3059\u308B\u307B\u3069\u304A\u308F\u3063\u3066\u308B",
  "id" : 364705882698817536,
  "created_at" : "2013-08-06 11:13:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u90E8\u8CFC\u8CB7\u90E8",
      "screen_name" : "HokubuShop",
      "indices" : [ 3, 14 ],
      "id_str" : "371765010",
      "id" : 371765010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364705860708085760",
  "text" : "RT @HokubuShop: \u6BCE\u5E74\u6052\u4F8B\u306E\u300C\u5317\u90E8\u7D0D\u6DBC\u796D\u300D\u304C\u4ECA\u5E74\u306F8\/2\uFF08\u91D1\uFF09\u306B\u958B\u50AC\u3055\u308C\u307E\u3059\u300217\u6642\u534A\uFF5E20\u6642\u307E\u3067\u3067\u3059\u3002\u96E8\u5929\u306F\u4E2D\u6B62\u3067\u3059\uFF5E\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364705673247866880",
    "text" : "\u6BCE\u5E74\u6052\u4F8B\u306E\u300C\u5317\u90E8\u7D0D\u6DBC\u796D\u300D\u304C\u4ECA\u5E74\u306F8\/2\uFF08\u91D1\uFF09\u306B\u958B\u50AC\u3055\u308C\u307E\u3059\u300217\u6642\u534A\uFF5E20\u6642\u307E\u3067\u3067\u3059\u3002\u96E8\u5929\u306F\u4E2D\u6B62\u3067\u3059\uFF5E\u3002",
    "id" : 364705673247866880,
    "created_at" : "2013-08-06 11:13:03 +0000",
    "user" : {
      "name" : "\u5317\u90E8\u8CFC\u8CB7\u90E8",
      "screen_name" : "HokubuShop",
      "protected" : false,
      "id_str" : "371765010",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_1_normal.png",
      "id" : 371765010,
      "verified" : false
    }
  },
  "id" : 364705860708085760,
  "created_at" : "2013-08-06 11:13:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364705682987040768",
  "text" : "\u30A2\u30D6\u30B9\u30C8\u30E9\u30AF\u30C8\u30CA\u30F3\u30BB\u30F3\u30B9\u3068\u3044\u3064\u30DC\u30AB\u30ED\u66F2\u304C\u3042\u308B\u3068\u304B\u306A\u3044\u3068\u304B",
  "id" : 364705682987040768,
  "created_at" : "2013-08-06 11:13:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364704612638400513",
  "geo" : { },
  "id_str" : "364704810676654080",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3080\u3057\u308D\u5B9A\u54E1\u6700\u5F8C\u306E\u4E00\u4EBA\u3092\u72D9\u3046\u65B9\u304C\u30B9\u30DD\u30FC\u30C6\u30A3\u306A\u306E\u3067\u306F",
  "id" : 364704810676654080,
  "in_reply_to_status_id" : 364704612638400513,
  "created_at" : "2013-08-06 11:09:37 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364704638026514433",
  "text" : "\u91CE\u3005\u539F\u3086\u305A\u3053\u306F\u4E45\u3005\u306B\u53EF\u611B\u3044\u3068\u601D\u3063\u305F[\u6700\u521D\u306F\u305D\u3046\u3067\u3082\u306A\u304B\u3063\u305F\u304C]",
  "id" : 364704638026514433,
  "created_at" : "2013-08-06 11:08:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364704323025895425",
  "geo" : { },
  "id_str" : "364704445193392129",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u306A\u306B\u305D\u308C\u3069\u3093\u306A\u30B9\u30DD\u30FC\u30C4",
  "id" : 364704445193392129,
  "in_reply_to_status_id" : 364704323025895425,
  "created_at" : "2013-08-06 11:08:10 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364704372711632896",
  "text" : "\u53EF\u611B\u3044\u306F\u6B63\u7FA9\u3060\u3068\u306F\u307E\u3041\u601D\u3046\u3051\u3069\u3001\u4E16\u306E\u4E2D\u306E\u3082\u306E\u5927\u62B5\u306F\u53EF\u611B\u304F\u306A\u3044\u3057\u3001\u611B\u7740\u304C\u3042\u308C\u3070\u8272\u3093\u306A\u3082\u306E\u304C\u53EF\u611B\u304F\u601D\u3048\u308B\u3057\u3082\u3046\u3088\u304F\u308F\u304B\u3093\u306A\u3044",
  "id" : 364704372711632896,
  "created_at" : "2013-08-06 11:07:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364703930992693249",
  "geo" : { },
  "id_str" : "364704073640968192",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u307E\u3041\u305D\u3046\u304B\u3082\u3060\u304C\u2026[\u304B\u304F\u8A00\u3046\u79C1\u3082\u958B\u59CB\u5F8C1\uFF0C2\u6642\u9593\u3067\u767B\u9332\u3057\u305F\u8A18\u61B6\u304C]",
  "id" : 364704073640968192,
  "in_reply_to_status_id" : 364703930992693249,
  "created_at" : "2013-08-06 11:06:41 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u306E\u4FE1\u5F92\u307E\u3093\u304C\u3093\uFF01",
      "screen_name" : "25manganum",
      "indices" : [ 0, 11 ],
      "id_str" : "400280435",
      "id" : 400280435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364703817368993792",
  "geo" : { },
  "id_str" : "364703904870572032",
  "in_reply_to_user_id" : 400280435,
  "text" : "@25manganum [\u305D\u308C\u8A00\u304A\u3046\u3068\u601D\u3063\u3066\u3084\u3081\u305F\u306E\u3067\u3059\u304C]",
  "id" : 364703904870572032,
  "in_reply_to_status_id" : 364703817368993792,
  "created_at" : "2013-08-06 11:06:01 +0000",
  "in_reply_to_screen_name" : "25manganum",
  "in_reply_to_user_id_str" : "400280435",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364703817348034560",
  "text" : "\u3069\u3046\u305B\u904B\u55B6\u52E2\u304C\u30A2\u30CA\u30A6\u30F3\u30B9\u3059\u308B\u3057\u306A\u30FC",
  "id" : 364703817348034560,
  "created_at" : "2013-08-06 11:05:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364703520869449728",
  "geo" : { },
  "id_str" : "364703738679672832",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u4E00\u65E5\u3068\u304B\u4E8C\u65E5\u3067\u57CB\u307E\u308B\u306E\u306F\u4E88\u60F3\u51FA\u6765\u308B\u304C10\u5206\u3084\u305D\u3053\u3089\u3067\u57CB\u307E\u308B\u3068\u3082\u8003\u3048\u306B\u304F\u3044\u304B\u3089\u5927\u4E08\u592B\u3060\u308D\u30FC\u3002",
  "id" : 364703738679672832,
  "in_reply_to_status_id" : 364703520869449728,
  "created_at" : "2013-08-06 11:05:21 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364703575407988736",
  "text" : "\u671F\u5F85\u3092\u88CF\u5207\u3089\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u3001\u3068\u8A00\u3046\u6587\u8A00\u3001\u5927\u62B5\u306E\u6587\u8108\u3067\u304A\u9580\u9055\u3044\u306A\u611F\u3058\u3059\u308B\u3002",
  "id" : 364703575407988736,
  "created_at" : "2013-08-06 11:04:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u306E\u4FE1\u5F92\u307E\u3093\u304C\u3093\uFF01",
      "screen_name" : "25manganum",
      "indices" : [ 0, 11 ],
      "id_str" : "400280435",
      "id" : 400280435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364703301440249856",
  "geo" : { },
  "id_str" : "364703417798623233",
  "in_reply_to_user_id" : 400280435,
  "text" : "@25manganum \u305D\u308C\u306F\u3042\u308B\u304B\u3082\u3067\u3059\u306D\uFF1F",
  "id" : 364703417798623233,
  "in_reply_to_status_id" : 364703301440249856,
  "created_at" : "2013-08-06 11:04:05 +0000",
  "in_reply_to_screen_name" : "25manganum",
  "in_reply_to_user_id_str" : "400280435",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364703159660183552",
  "geo" : { },
  "id_str" : "364703243827294210",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u5FD8\u308C\u3066\u305F\u3002\u5F85\u6A5F\u3002",
  "id" : 364703243827294210,
  "in_reply_to_status_id" : 364703159660183552,
  "created_at" : "2013-08-06 11:03:23 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u306E\u4FE1\u5F92\u307E\u3093\u304C\u3093\uFF01",
      "screen_name" : "25manganum",
      "indices" : [ 0, 11 ],
      "id_str" : "400280435",
      "id" : 400280435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364702773784231936",
  "geo" : { },
  "id_str" : "364703105977286657",
  "in_reply_to_user_id" : 400280435,
  "text" : "@25manganum \u4E2D\u8EAB\u306E\u30A4\u30E1\u30FC\u30B8\u3068\u5916\u5473\u306E\u30A4\u30E1\u30FC\u30B8\u306F\u5225\u7269\u3067\u306F\u2026[\u3069\u3063\u3061\u304B\u3068\u3044\u3046\u3068\u671F\u5F85\u3092\u88CF\u5207\u3089\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u306E\u6587\u8A00\u306B\u30A4\u30E9\u3063\u3068\u3057\u3066\u307E\u3059\u304C]",
  "id" : 364703105977286657,
  "in_reply_to_status_id" : 364702773784231936,
  "created_at" : "2013-08-06 11:02:50 +0000",
  "in_reply_to_screen_name" : "25manganum",
  "in_reply_to_user_id_str" : "400280435",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364702541608529921",
  "text" : "\u3044\u30FC\uFF1F\u5973\u6027\u30C4\u30A4\u30C3\u30BF\u30E9\u30FC\u306B\u305D\u3053\u307E\u3067\u30A4\u30E1\u30FC\u30B8\u6301\u3063\u3066\u308B\u3082\u3093\u306A\u306E\u304B\uFF1F\u3053\u306E\u30B5\u30C4\u30D0\u30C4\u7A7A\u9593\u3067\uFF1F",
  "id" : 364702541608529921,
  "created_at" : "2013-08-06 11:00:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364696465450348545",
  "text" : "\u306A\u304C\u306A\u304E\u306A\u305F",
  "id" : 364696465450348545,
  "created_at" : "2013-08-06 10:36:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364696418612551680",
  "text" : "\u3042\u306E\u306A\u3052\u3057\u306E\u306A\u304C\u306A\u304E\u306A\u305F\u306F\u305F\u304C\u306A\u304E\u306A\u305F\u305E",
  "id" : 364696418612551680,
  "created_at" : "2013-08-06 10:36:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364696278204035072",
  "text" : "\u304A\u3061\u3083\u305F\u3061\u3087 \u3061\u3083\u305F\u3061\u3087 \u3061\u3083\u3063\u3068 \u305F\u3061\u3087 \u3061\u3083\u305F\u3061\u3087\u3001\u3042\u304A\u305F\u3051 \u3061\u3083\u305B\u3093\u3067\u3000\u304A\u3061\u3083 \u3061\u3083\u3068 \u305F\u3061\u3087\u3002\u3000",
  "id" : 364696278204035072,
  "created_at" : "2013-08-06 10:35:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364691863262863361",
  "text" : "\u30EA\u30AB\u30DE\u30F3\u306E\u81EA\u793E\u30D6\u30E9\u30F3\u30C9\u306E\u304A\u8336\u306F\u30DE\u30B8\u3067\u60B6\u7D76\u3082\u306E\u3060\u3063\u305F",
  "id" : 364691863262863361,
  "created_at" : "2013-08-06 10:18:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364691575160307712",
  "geo" : { },
  "id_str" : "364691753497927682",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u30E8\u30FC\u30B0\u30EC\u30C3\u30C8\u597D\u304D\u306A\u3089\u826F\u3044\u3068\u601D\u3044\u307E\u3059\u3051\u3069\u306D\u2026[\u50D5\u306F\u304A\u8336\u3082\u30C0\u30E1\u3067\u3059\u3051\u308C\u3069\u2026]",
  "id" : 364691753497927682,
  "in_reply_to_status_id" : 364691575160307712,
  "created_at" : "2013-08-06 10:17:44 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364691225233719296",
  "text" : "\u4F55\u3088\u308A\u81EA\u793E\u30D6\u30E9\u30F3\u30C9\u306E\u70CF\u9F8D\u8336\u7F6E\u3044\u3066\u3066\u30B5\u30F3\u30C8\u30EA\u30FC\u306E\u70CF\u9F8D\u8336\u7F6E\u3044\u3066\u306A\u3044\u5E97\u304C\u76EE\u7ACB\u3064\u306E\u304C\u8179\u7ACB\u305F\u3057\u3044",
  "id" : 364691225233719296,
  "created_at" : "2013-08-06 10:15:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364691116970352640",
  "text" : "\u57FA\u672C\u81EA\u793E\u30D6\u30E9\u30F3\u30C9\u88FD\u54C1\u306F\u8B66\u6212\u3057\u3066\u308B\u3002\u30BB\u30D6\u30F3\u30A4\u30EC\u30D6\u30F3\u306E\u304A\u60E3\u83DC\u306F\u7D50\u69CB\u7F8E\u5473\u3057\u3044\u3002",
  "id" : 364691116970352640,
  "created_at" : "2013-08-06 10:15:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364689988266377216",
  "geo" : { },
  "id_str" : "364690988423331840",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u30ED\u30FC\u30BD\u30F3\u30D6\u30E9\u30F3\u30C9\u306E\u98F2\u3080\u30E8\u30FC\u30B0\u30EB\u30C8\u304C\u98F2\u3080\u30E8\u30FC\u30B0\u30EC\u30C3\u30C8\u3060\u3063\u305F\u306E\u3067\u304A\u597D\u304D\u306A\u3089\u3069\u3046\u305E\uFF1F",
  "id" : 364690988423331840,
  "in_reply_to_status_id" : 364689988266377216,
  "created_at" : "2013-08-06 10:14:41 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364690136669237249",
  "text" : "\u4F53\u52D5\u304B\u3057\u305F\u3044\u2026\u306E\u304B\u3082\uFF1F",
  "id" : 364690136669237249,
  "created_at" : "2013-08-06 10:11:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364689226576564226",
  "text" : "\u666E\u6BB5\u306F\u300C\u3042\u30FC\u300D\u3063\u3066\u30B9\u30EB\u30FC\u51FA\u6765\u308B\u30A2\u30EC\u306A\u30C6\u30A4\u30B9\u30C8\u304C\u9F3B\u306B\u4ED8\u304F\u3063\u3066\u3053\u3068\u306F\u305F\u3076\u3093\u30A4\u30E9\u30A4\u30E9\u3057\u3066\u308B\u3093\u3060\u306A\u30FC\uFF1F",
  "id" : 364689226576564226,
  "created_at" : "2013-08-06 10:07:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364689103448576000",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u3001\u30A2\u30EC\u306Abot\u3068\u304B\u898B\u308B\u3068RT\u3057\u3066\u308B\u30C4\u30A4\u30FC\u30C8\u3082\u898B\u4E8B\u306B\u30A2\u30EC\u3067\u3001\u4F5C\u3063\u3066\u308B\u3084\u3064\u3068\u4E00\u7DD2\u306B\u6DF1\u6D77\u306B\u6C88\u3081\u305F\u304F\u306A\u308B",
  "id" : 364689103448576000,
  "created_at" : "2013-08-06 10:07:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364668896650858496",
  "text" : "\u3042\u305F\u307E\u304C\u304A\u304B\u3057\u304F\u306A\u3063\u3066\u3057\u306C",
  "id" : 364668896650858496,
  "created_at" : "2013-08-06 08:46:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364614392257581058",
  "text" : "\u3042\u30FC\u3001\u4ECA\u65E5\u307E\u3060\u4F55\u3082\u98DF\u3079\u3066\u306A\u3044\u306A",
  "id" : 364614392257581058,
  "created_at" : "2013-08-06 05:10:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    }, {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 16, 32 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364337444142845953",
  "geo" : { },
  "id_str" : "364340932214136832",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning @takasan_san_san \u3093\u30FC\u3001\u6C34\u66DC\u306F\u7ACB\u3066\u8FBC\u307F\u305D\u3046\u3060\u3057\u3084\u3081\u3068\u304F\u308F\u30FC\u3002\u611F\u60F3\u805E\u304B\u305B\u3066\u30FC",
  "id" : 364340932214136832,
  "in_reply_to_status_id" : 364337444142845953,
  "created_at" : "2013-08-05 11:03:42 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "indices" : [ 3, 11 ],
      "id_str" : "16331213",
      "id" : 16331213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364321038764478466",
  "text" : "RT @kazoo04: \u30A8\u30B4\u30B5\u3059\u308B\u305F\u3081\u306B\u5927\u5B66\u3067\u60C5\u5831\u5DE5\u5B66\u3092\u52C9\u5F37\u3057\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364320860418486272",
    "text" : "\u30A8\u30B4\u30B5\u3059\u308B\u305F\u3081\u306B\u5927\u5B66\u3067\u60C5\u5831\u5DE5\u5B66\u3092\u52C9\u5F37\u3057\u305F",
    "id" : 364320860418486272,
    "created_at" : "2013-08-05 09:43:56 +0000",
    "user" : {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "protected" : false,
      "id_str" : "16331213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583129549694640129\/aPkbezAe_normal.png",
      "id" : 16331213,
      "verified" : false
    }
  },
  "id" : 364321038764478466,
  "created_at" : "2013-08-05 09:44:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364281034327592961",
  "text" : "\u6D78\u6C34\u306E\u771F\u9AC4",
  "id" : 364281034327592961,
  "created_at" : "2013-08-05 07:05:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364280777388724226",
  "text" : "\u6D2A\u6C34\u3047\u2026",
  "id" : 364280777388724226,
  "created_at" : "2013-08-05 07:04:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364280340581318657",
  "text" : "@\u3042\u3081 \u3082\u3046\u6B62\u3082\u3046\uFF01",
  "id" : 364280340581318657,
  "created_at" : "2013-08-05 07:02:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364277991146127360",
  "text" : "\u7121\u3044\u3082\u306E",
  "id" : 364277991146127360,
  "created_at" : "2013-08-05 06:53:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364277949689638913",
  "text" : "RT @kagakuma: \u6697\u5531\u3067\u304D\u308B\u6F22\u8A69\u306F\u5C11\u306A\u3044\u304C\u3002\u3068\u304F\u306B\u767D\u5C45\u6613\u306F\u77E5\u3089\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364277805774675969",
    "text" : "\u6697\u5531\u3067\u304D\u308B\u6F22\u8A69\u306F\u5C11\u306A\u3044\u304C\u3002\u3068\u304F\u306B\u767D\u5C45\u6613\u306F\u77E5\u3089\u306A\u3044\u3002",
    "id" : 364277805774675969,
    "created_at" : "2013-08-05 06:52:51 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 364277949689638913,
  "created_at" : "2013-08-05 06:53:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364277928558735360",
  "text" : "\u6697\u5531\u3067\u304D\u308B\u6F22\u8A69\u306F\u306A\u3044\u304C\u3002\u3068\u304F\u306B\u767D\u5C45\u6613\u306F\u77E5\u3089\u306A\u3044\u3002",
  "id" : 364277928558735360,
  "created_at" : "2013-08-05 06:53:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364277814754676736",
  "text" : "\u30A2\u30E1\u30A7\u30A7\u30A7\u30A7\u30A7\u30A7\u30A7",
  "id" : 364277814754676736,
  "created_at" : "2013-08-05 06:52:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304A\u3093",
      "screen_name" : "__ion__",
      "indices" : [ 3, 11 ],
      "id_str" : "569690517",
      "id" : 569690517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364259119537995776",
  "text" : "RT @__ion__: \u3042\u305A\u304D\u30D0\u30FC\n\u786C\u3044\n\u786C\u3044\n\u786C\u3044\n\u65E8\u3044\n\u65E8\u3044\n\u65E8\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364251126129893376",
    "text" : "\u3042\u305A\u304D\u30D0\u30FC\n\u786C\u3044\n\u786C\u3044\n\u786C\u3044\n\u65E8\u3044\n\u65E8\u3044\n\u65E8\u3044",
    "id" : 364251126129893376,
    "created_at" : "2013-08-05 05:06:50 +0000",
    "user" : {
      "name" : "\u3044\u304A\u3093",
      "screen_name" : "__ion__",
      "protected" : false,
      "id_str" : "569690517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603931155113447424\/lu8Pylbi_normal.png",
      "id" : 569690517,
      "verified" : false
    }
  },
  "id" : 364259119537995776,
  "created_at" : "2013-08-05 05:38:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364229967950786560",
  "text" : "\u7B11\u3048\u306A\u3044",
  "id" : 364229967950786560,
  "created_at" : "2013-08-05 03:42:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364229904084111360",
  "text" : "RT @shigmax: \u3041\u3042\u3042\u3042\u3042\u66F8\u985E\u4E0D\u5099\u3067\u9662\u6B7B\u304C\u61D0\u304B\u3057\u3044\u30CA\u30A1\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364229588357885952",
    "text" : "\u3041\u3042\u3042\u3042\u3042\u66F8\u985E\u4E0D\u5099\u3067\u9662\u6B7B\u304C\u61D0\u304B\u3057\u3044\u30CA\u30A1\uFF01",
    "id" : 364229588357885952,
    "created_at" : "2013-08-05 03:41:15 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 364229904084111360,
  "created_at" : "2013-08-05 03:42:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364228667896901633",
  "text" : "\u307B\u304F\u3068\u9589\u5E97\u304B\u3001\u60B2\u3057\u3044",
  "id" : 364228667896901633,
  "created_at" : "2013-08-05 03:37:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364221520958070784",
  "text" : "\u30B8\u30A7\u30EA\u30FC\u30DE\u30F3\u6C0F\u306B\u5384\u4ECB\u7D61\u307F\u3057\u3066\u305F\u30A2\u30EC\u3001\u4F8B\u3048\u5F7C\u306E\u8A00\u3046\u30B8\u30A7\u30EA\u30FC\u30DE\u30F3\u6C0F\u306E\u884C\u3044\u304C\u672C\u5F53\u3067\u3082\u300C\u3067\uFF1F\u300D\u3068\u8A00\u3046\u611F\u3058\u3059\u308B",
  "id" : 364221520958070784,
  "created_at" : "2013-08-05 03:09:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363992791015112707",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 363992791015112707,
  "created_at" : "2013-08-04 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363974132553097218",
  "text" : "\u304F\u3063\u3061\u3093\u3071\u6C0F\u5510\u7A81\u306B\u305A\u308B\u3044",
  "id" : 363974132553097218,
  "created_at" : "2013-08-04 10:46:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363973750821105665",
  "text" : "\u50D5\u306F\u98DF\u30D1\u30F3\u3092\u9F67\u308A\u307E\u3059",
  "id" : 363973750821105665,
  "created_at" : "2013-08-04 10:44:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363973684332990464",
  "text" : "\u30D6\u30EB\u30B8\u30E7\u30A2\u30B8\u30FC\u306A\u3089\u51FA\u524D\u3068\u304B\u304A\u5F01\u5F53\u5C4A\u3051\u3055\u305B\u308B\u624B\u3082",
  "id" : 363973684332990464,
  "created_at" : "2013-08-04 10:44:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363973477969035264",
  "geo" : { },
  "id_str" : "363973593153024000",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u9811\u5F35\u308C\u30FC",
  "id" : 363973593153024000,
  "in_reply_to_status_id" : 363973477969035264,
  "created_at" : "2013-08-04 10:44:01 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/yPXgQte7v4",
      "expanded_url" : "http:\/\/sx9.jp\/weather\/kyoto.html",
      "display_url" : "sx9.jp\/weather\/kyoto.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "363973087630327808",
  "geo" : { },
  "id_str" : "363973294921220096",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u96E8\u306E\u4E2D\u3044\u304F\u3057\u304B\u306A\u3055\u305D\u3046\u3067\u3059\u306D\uFF1F http:\/\/t.co\/yPXgQte7v4",
  "id" : 363973294921220096,
  "in_reply_to_status_id" : 363973087630327808,
  "created_at" : "2013-08-04 10:42:50 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363973060115701761",
  "text" : "\u306A\u3044\u3093\u305F\u3093\u306E\u30B0\u30E9\u30D5\u306B\u3060\u3044\u3076\u52A9\u3051\u3089\u308C\u3066\u3044\u308B",
  "id" : 363973060115701761,
  "created_at" : "2013-08-04 10:41:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363972757052071936",
  "geo" : { },
  "id_str" : "363972932239757313",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u964D\u308A\u305D\u3046\u3060\u3063\u305F\u3088\u30FC(\u4E00\u8DB3\u65E9\u304F\u92AD\u6E6F\u306B\u884C\u304D\u7D42\u3048\u305F\u9854)",
  "id" : 363972932239757313,
  "in_reply_to_status_id" : 363972757052071936,
  "created_at" : "2013-08-04 10:41:23 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363972426452844544",
  "geo" : { },
  "id_str" : "363972649262645248",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u96E8\u304F\u3089\u3044\u8AAD\u3093\u3067\u884C\u52D5\u3057\u308D\u3088\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF01(\u3080\u3061\u3083\u3076\u308A)",
  "id" : 363972649262645248,
  "in_reply_to_status_id" : 363972426452844544,
  "created_at" : "2013-08-04 10:40:16 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363972030795755522",
  "geo" : { },
  "id_str" : "363972120075710465",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3042\u3081",
  "id" : 363972120075710465,
  "in_reply_to_status_id" : 363972030795755522,
  "created_at" : "2013-08-04 10:38:10 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363971799970627585",
  "text" : "\u3042\u3081",
  "id" : 363971799970627585,
  "created_at" : "2013-08-04 10:36:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0416\u30A3\u2172%?\u0449",
      "screen_name" : "Maleic1618",
      "indices" : [ 0, 11 ],
      "id_str" : "520458209",
      "id" : 520458209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363968797201285120",
  "geo" : { },
  "id_str" : "363968936385060865",
  "in_reply_to_user_id" : 520458209,
  "text" : "@Maleic1618 \u307E\u3068\u3081\u3066\u51B7\u51CD\u30E1\u30BD\u30C3\u30C9\u3092\u805E\u3044\u305F\u3053\u3068\u3042\u308B\u304B\u3089\u8ABF\u3079\u3066\u307F\u308C\u3070\uFF1F",
  "id" : 363968936385060865,
  "in_reply_to_status_id" : 363968797201285120,
  "created_at" : "2013-08-04 10:25:31 +0000",
  "in_reply_to_screen_name" : "Maleic1618",
  "in_reply_to_user_id_str" : "520458209",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363968318568275968",
  "text" : "\u3044\u3064\u3082\u306E\u30C8\u30FC\u30C8\u30ED\u30B8\u30FC\u30CD\u30BF\u306B\u898B\u305B\u304B\u3051\u3066\u7D50\u69CB\u5927\u4E8B\u3060\u3068\u601D\u3046",
  "id" : 363968318568275968,
  "created_at" : "2013-08-04 10:23:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363967672620294144",
  "text" : "\u6700\u8FD1\u3088\u304F\u8A00\u3063\u3066\u308B\u304C\"\u76F8\u624B\u306B\u3059\u3079\u304D\u3067\u306A\u3044\u4EBA\u7A2E\u306F\u5B9F\u969B\u76F8\u624B\u306B\u3059\u3079\u304D\u3067\u306A\u3044\"",
  "id" : 363967672620294144,
  "created_at" : "2013-08-04 10:20:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jellyman5009",
      "screen_name" : "jellyman5009",
      "indices" : [ 0, 13 ],
      "id_str" : "2595829088",
      "id" : 2595829088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363967329547206656",
  "geo" : { },
  "id_str" : "363967568354091009",
  "in_reply_to_user_id" : 118355311,
  "text" : "@jellyman5009 \u76F8\u624B\u306B\u3059\u3079\u304D\u3067\u306A\u3044\u4EBA\u7A2E\u306F\u5B9F\u969B\u76F8\u624B\u306B\u3059\u3079\u304D\u3067\u306A\u3044",
  "id" : 363967568354091009,
  "in_reply_to_status_id" : 363967329547206656,
  "created_at" : "2013-08-04 10:20:05 +0000",
  "in_reply_to_screen_name" : "_ca76",
  "in_reply_to_user_id_str" : "118355311",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363967079382130688",
  "text" : "@umichoco11 \u3046\u307E\u304F\u3044\u3048\u306A\u3044\u3067\u3059\u3051\u308C\u3069\u304C\u3093\u3070\u308A\u307E\u3057\u3087\u3046",
  "id" : 363967079382130688,
  "created_at" : "2013-08-04 10:18:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363960150358364160",
  "geo" : { },
  "id_str" : "363960267526254593",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u3044\u3084\u30FC\u5FD9\u3057\u3044\u304B\u3089\u904A\u3093\u3067\u308B\u6687\u306A\u3044\u3068\u601D\u3046(\u5207\u5B9F)",
  "id" : 363960267526254593,
  "in_reply_to_status_id" : 363960150358364160,
  "created_at" : "2013-08-04 09:51:04 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363959402727878657",
  "geo" : { },
  "id_str" : "363959745687732224",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u30A6\u30B1\u308B\u30FC\u30FC\u305D\u306E\u6642\u6771\u4EAC\u306B\u3044\u308B\u308F\u30FC\u30FC\u30A6\u30B1\u308B\u30FC\u30FC\u30FC[\u5C06\u6765\u7684\u306A\u610F\u5473\u3067\u805E\u3044\u305F\u306E\u3060\u304C\u30FC]",
  "id" : 363959745687732224,
  "in_reply_to_status_id" : 363959402727878657,
  "created_at" : "2013-08-04 09:49:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363959057637318657",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u3053\u3063\u3061\u306B\u5E30\u3063\u3066\u6765\u305F\u308A\u3059\u308B\u30BB\u30F3\u306F\u306A\u3044\u306E\u304B\uFF1F",
  "id" : 363959057637318657,
  "created_at" : "2013-08-04 09:46:16 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363958741948829696",
  "text" : "\u305D\u3057\u3066\u5589\u304C\u4E7E\u3044\u305F\u6240\u306B\u70CF\u9F8D\u8336\u3067\u3059\u3088\u3002\u9699\u306E\u306A\u3044\u30B3\u30F3\u30DC\uFF01",
  "id" : 363958741948829696,
  "created_at" : "2013-08-04 09:45:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363958440088969216",
  "geo" : { },
  "id_str" : "363958591218130945",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u304A\u304A\u3046\uFF01\u304A\u3084\u3059\u307F\uFF01",
  "id" : 363958591218130945,
  "in_reply_to_status_id" : 363958440088969216,
  "created_at" : "2013-08-04 09:44:24 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3075\u3047\u3044\u3093\u304C\u305F\u308A\u306A\u3044\u3002",
      "screen_name" : "KishidaKus",
      "indices" : [ 0, 11 ],
      "id_str" : "1521726091",
      "id" : 1521726091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363956987320475648",
  "geo" : { },
  "id_str" : "363958360543985665",
  "in_reply_to_user_id" : 1521726091,
  "text" : "@KishidaKus \u81EA\u5206\u3067\u4F5C\u308D\u3046\uFF01",
  "id" : 363958360543985665,
  "in_reply_to_status_id" : 363956987320475648,
  "created_at" : "2013-08-04 09:43:29 +0000",
  "in_reply_to_screen_name" : "KishidaKus",
  "in_reply_to_user_id_str" : "1521726091",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363958297398751232",
  "text" : "\u30DE\u30AD\u30CD\u30C3\u30BF\u306F\u666E\u901A\u306B\u30A8\u30B9\u30D7\u30EC\u30C3\u30BD\u3081\u3044\u3066\u6FC3\u3044\u30B3\u30FC\u30D2\u30FC\u98F2\u3081\u308B\u3057\u30A2\u30D5\u30A9\u30AC\u30FC\u30C9\u4F5C\u308C\u308B\u3057\u30AA\u30B9\u30B9\u30E1",
  "id" : 363958297398751232,
  "created_at" : "2013-08-04 09:43:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363958109280022529",
  "text" : "@Neko_Nahu \u30B9\u30FC\u30D1\u30FC\u30AB\u30C3\u30D7\u3068\u76F4\u706B\u5F0F\u30A8\u30B9\u30D7\u30EC\u30C3\u30BD\u3067\u7C21\u5358\u306B\u3067\u304D\u307E\u3059\u30FC",
  "id" : 363958109280022529,
  "created_at" : "2013-08-04 09:42:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363957836113387520",
  "text" : "\u82E6\u7518\u7F8E\u5473",
  "id" : 363957836113387520,
  "created_at" : "2013-08-04 09:41:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363957297933860864",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u30D5\u30ED\u30FC\u30C8\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F\u611F\u3058\u3059\u308B",
  "id" : 363957297933860864,
  "created_at" : "2013-08-04 09:39:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363956886485209090",
  "text" : "\u898B\u305F\u76EE\u30A4\u30DE\u30A4\u30C1wwwww",
  "id" : 363956886485209090,
  "created_at" : "2013-08-04 09:37:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/363956828939382785\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/HzFXJUqCIX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ0Izr8CcAAvI-2.jpg",
      "id_str" : "363956828947771392",
      "id" : 363956828947771392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ0Izr8CcAAvI-2.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/HzFXJUqCIX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363956828939382785",
  "text" : "\u3053\u308C\u3092\u3001\u3053\u3046\u3058\u3083\uFF01 http:\/\/t.co\/HzFXJUqCIX",
  "id" : 363956828939382785,
  "created_at" : "2013-08-04 09:37:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/363956654804463616\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/26eYSsEH78",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ0IpjOCcAAcGV7.jpg",
      "id_str" : "363956654808657920",
      "id" : 363956654808657920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ0IpjOCcAAcGV7.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/26eYSsEH78"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363956654804463616",
  "text" : "\u3053\u3053\u306B\u30D0\u30CB\u30E9\u30A2\u30A4\u30B9\u304C\u3042\u308B\u3058\u3083\u308D\uFF1F http:\/\/t.co\/26eYSsEH78",
  "id" : 363956654804463616,
  "created_at" : "2013-08-04 09:36:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363954840377896961",
  "text" : "\u30D0\u30CB\u30E9\u30A2\u30A4\u30B9\u8CB7\u3063\u305F\u3057\u30A2\u30D5\u30A9\u30AC\u30FC\u30C9\u306B\u3057\u3066\u98DF\u3079\u308B\uFF01",
  "id" : 363954840377896961,
  "created_at" : "2013-08-04 09:29:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 3, 18 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mircea_morning\/status\/363952643711844352\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/1hMfY4loD5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ0FAEwCQAAo7ar.jpg",
      "id_str" : "363952643720232960",
      "id" : 363952643720232960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ0FAEwCQAAo7ar.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1hMfY4loD5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363953606690471936",
  "text" : "RT @mircea_morning: \u5E30\u5B85\u3063\u3063\u3063\u3002\u4ECA\u65E5\u306F\u4E45\u3057\u3076\u308A\u306E\u30AA\u30D5\u3067\u3001\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u3082\u306A\u3044\u3068\u3053\u308D\u3067\u3060\u3089\u3060\u3089\u6642\u9593\u3092\u904E\u3054\u3057\u305F\u3002\u304A\u3044\u3057\u3044\u3082\u306E\u3082\u98DF\u3079\u305F\u3002\u5E30\u3063\u305F\u3089\u3001\u98DF\u30D1\u30F3\u30C0\u30C3\u30B7\u30E5\u304B\u3089\u3084\u307E\u3060\u3061\u3083\u3093\u90F5\u4FBF\u304C\u5C4A\u3044\u3066\u305F http:\/\/t.co\/1hMfY4loD5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mircea_morning\/status\/363952643711844352\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/1hMfY4loD5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ0FAEwCQAAo7ar.jpg",
        "id_str" : "363952643720232960",
        "id" : 363952643720232960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ0FAEwCQAAo7ar.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1hMfY4loD5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363952643711844352",
    "text" : "\u5E30\u5B85\u3063\u3063\u3063\u3002\u4ECA\u65E5\u306F\u4E45\u3057\u3076\u308A\u306E\u30AA\u30D5\u3067\u3001\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u3082\u306A\u3044\u3068\u3053\u308D\u3067\u3060\u3089\u3060\u3089\u6642\u9593\u3092\u904E\u3054\u3057\u305F\u3002\u304A\u3044\u3057\u3044\u3082\u306E\u3082\u98DF\u3079\u305F\u3002\u5E30\u3063\u305F\u3089\u3001\u98DF\u30D1\u30F3\u30C0\u30C3\u30B7\u30E5\u304B\u3089\u3084\u307E\u3060\u3061\u3083\u3093\u90F5\u4FBF\u304C\u5C4A\u3044\u3066\u305F http:\/\/t.co\/1hMfY4loD5",
    "id" : 363952643711844352,
    "created_at" : "2013-08-04 09:20:46 +0000",
    "user" : {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "protected" : false,
      "id_str" : "199550192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494419651342774272\/VcykhvGX_normal.jpeg",
      "id" : 199550192,
      "verified" : false
    }
  },
  "id" : 363953606690471936,
  "created_at" : "2013-08-04 09:24:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363953366499463170",
  "text" : "\u30A2\u30A4\u30B9\u8CB7\u3063\u3066\u304B\u30FC\u3048\u308D\u30FC",
  "id" : 363953366499463170,
  "created_at" : "2013-08-04 09:23:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363939841475477505",
  "text" : "\u304A\u3075\u308D\u304A\u3075\u308D\uFF01",
  "id" : 363939841475477505,
  "created_at" : "2013-08-04 08:29:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363938289469755392",
  "text" : "\u304A\u3075\u308D\u3044\u304F\u304B\u30FC",
  "id" : 363938289469755392,
  "created_at" : "2013-08-04 08:23:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363935426815344640",
  "text" : "\u6731\u306B\u4EA4\u308F\u308C\u3070\u8D64\u304F\u306A\u308B\/\/\/\/",
  "id" : 363935426815344640,
  "created_at" : "2013-08-04 08:12:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363929813666365442",
  "text" : "\u3054\u308D\u3054\u308D\u30FC",
  "id" : 363929813666365442,
  "created_at" : "2013-08-04 07:50:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363928282955128832",
  "text" : "\u30AB\u30DF\u30CA\u30EA\u30A7\u30A7\u30A7\u30A8",
  "id" : 363928282955128832,
  "created_at" : "2013-08-04 07:43:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363925661276049409",
  "text" : "\u96E2\u8131 of the world[\u89E3\u8131\u3063\u307D\u3044]",
  "id" : 363925661276049409,
  "created_at" : "2013-08-04 07:33:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363925418291634176",
  "text" : "\u7533\u3057\u8A33 of the world",
  "id" : 363925418291634176,
  "created_at" : "2013-08-04 07:32:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363924584182980608",
  "geo" : { },
  "id_str" : "363924955127218176",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u30A8\u30EB\u30B9\u3067\u8ABF\u3079\u305F\u3089\u4E00\u756A\u4E0A\u306B\u51FA\u3066\u6765\u305F\u306E\u3067\u4E00\u756A\u4E00\u822C\u7684\u306A\u30A8\u30EB\u30B9\u3060\u3068\u601D\u308F\u308C\u307E\u3059\uFF01\uFF01\uFF01\u8A8D\u8B58\u3092\u6539\u3081\u3066\u304F\u3060\u3055\u3044\uFF01\uFF01\uFF01",
  "id" : 363924955127218176,
  "in_reply_to_status_id" : 363924584182980608,
  "created_at" : "2013-08-04 07:30:45 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363924749153349632",
  "text" : "\u30CD\u30BF\u304C\u5206\u304B\u3089\u306A\u3044\u6642\u306F\u66F4\u306A\u308B\u30CD\u30BF\u3092\u91CD\u306D\u3066\u884C\u304F[\u76BF\u306A\u308B\u30CD\u30BF\u3092\u91CD\u306D\u308B\u3068\u8A00\u3046\u3068\u56DE\u8EE2\u5BFF\u53F8\u3063\u307D\u3044\u306A]",
  "id" : 363924749153349632,
  "created_at" : "2013-08-04 07:29:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363924533012467713",
  "text" : "\u300C\u7CBE\u795E\u3068\u6642\u306E\u90E8\u5C4B\u3067\u904A\u3073\u305F\u3044\u300D\n\u300C\u3044\u3084\u3001\u7CBE\u795E\u3068\u6642\u306E\u90E8\u5C4B\u3067\u52C9\u5F37\u3057\u308D\u3088\u300D\n\u300C\uFF01\uFF01\uFF01\u300D",
  "id" : 363924533012467713,
  "created_at" : "2013-08-04 07:29:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/N8WJgkc9fx",
      "expanded_url" : "http:\/\/ja.m.wikipedia.org\/wiki\/%E3%82%A2%E3%83%BC%E3%83%8B%E3%83%BC%E3%83%BB%E3%82%A8%E3%83%AB%E3%82%B9",
      "display_url" : "ja.m.wikipedia.org\/wiki\/%E3%82%A2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "363924099883479040",
  "geo" : { },
  "id_str" : "363924336677097472",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3069\u3046\u305E\u3064http:\/\/t.co\/N8WJgkc9fx",
  "id" : 363924336677097472,
  "in_reply_to_status_id" : 363924099883479040,
  "created_at" : "2013-08-04 07:28:17 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363924016681070592",
  "text" : "\u3042\u30FC\u30BF\u30A4\u30DF\u30F3\u30B0\u2026",
  "id" : 363924016681070592,
  "created_at" : "2013-08-04 07:27:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363923934221041669",
  "text" : "\u732B\u307F\u305F\u3044\u306A\u5F7C\u5973\u3088\u308A\u5F7C\u5973\u307F\u305F\u3044\u306A\u732B\u304C\u6B32\u3057\u3044",
  "id" : 363923934221041669,
  "created_at" : "2013-08-04 07:26:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363923565805965312",
  "geo" : { },
  "id_str" : "363923876238983171",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u5F7C\u5973\u307F\u305F\u3044\u306A\u732B\u304C\u6B32\u3057\u3044\u3067\u3059",
  "id" : 363923876238983171,
  "in_reply_to_status_id" : 363923565805965312,
  "created_at" : "2013-08-04 07:26:28 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363923821255864321",
  "text" : "7\u554F\u4E2D3\u554F\u89E3\u3051\u3001\u307F\u305F\u3044\u306A\u554F\u984C\u3001\u307B\u307C\u9078\u629E\u80A2\u306A\u304F3\u3064\u89E3\u304F\u611F\u3058\u3060\u3057\u3061\u3083\u3093\u3068\u52C9\u5F37\u3057\u3066\u308B\u4EBA\u306F\u5168\u90E8\u89E3\u3051\u308B\u4E0A\u3067\u78BA\u5B9F\u306B\u89E3\u3051\u305D\u3046\u306A\u306E\u3092\u9078\u3079\u308B\u3093\u3060\u308D\u30FC\u306A\u30FC\u3001\u3068\u601D\u3063\u3066\u306C\u30FC ( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 363923821255864321,
  "created_at" : "2013-08-04 07:26:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363923384884658178",
  "text" : "\u3066\u3063\u304D\u308A\u306E\"\u3066\u3063\u304D\u308A\"\u611F\u3084\u3070\u3044\u306A[\u3066\u3063\u304D\u308A]",
  "id" : 363923384884658178,
  "created_at" : "2013-08-04 07:24:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363923144568221696",
  "geo" : { },
  "id_str" : "363923280945618944",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u3042\u3001\u540C\u30581\u679A\u3092\u4E00\u7DD2\u306B\u6F70\u3059\u3093\u3067\u3059\u304B\u3002\u3066\u3063\u304D\u308A\u5225\u3005\u304B\u3068",
  "id" : 363923280945618944,
  "in_reply_to_status_id" : 363923144568221696,
  "created_at" : "2013-08-04 07:24:06 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363923097537097729",
  "text" : "\u96C6\u307E\u3063\u3066\u307F\u3093\u306A\u3067\u30D7\u30C1\u30D7\u30C1\u6F70\u3059\u30AA\u30D5\u4F1A\u3001\u5E73\u548C\u306E\u6975\u307F\u611F\u3042\u308B",
  "id" : 363923097537097729,
  "created_at" : "2013-08-04 07:23:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363922694263160833",
  "geo" : { },
  "id_str" : "363922976858574848",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u4E00\u7DD2\u306B\u3084\u308B\u610F\u5473\u2026[\u53CB\u4EBA\u5B85\u3067\u53CB\u4EBA\u304CPC\u3001\u50D5\u304C\u8AAD\u66F8\u3057\u3066\u305F\u306E\u3092\u601D\u3044\u51FA\u3057\u307E\u3057\u305F][\u3042\u308C\u6848\u5916\u697D\u3057\u3044\uFF1F]",
  "id" : 363922976858574848,
  "in_reply_to_status_id" : 363922694263160833,
  "created_at" : "2013-08-04 07:22:53 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363922442974011392",
  "text" : "\u4E16\u754C\u3067\u4E00\u756A\u5E73\u548C\u306A\u904A\u3073\u3001\u30D7\u30C1\u30D7\u30C1\u6F70\u3057",
  "id" : 363922442974011392,
  "created_at" : "2013-08-04 07:20:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363922134974091264",
  "geo" : { },
  "id_str" : "363922362653081600",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u5BB6\u3067\u30D7\u30C1\u30D7\u30C1\u6F70\u3057\u3066\u308B\u3088\u30FC\u3001\u3068\u304B\u8A00\u3046\u3068\u5411\u3053\u3046\u306E\u76EE\u8AD6\u898B\u306B\u4E57\u3063\u304B\u308C\u307E\u3059\u3088",
  "id" : 363922362653081600,
  "in_reply_to_status_id" : 363922134974091264,
  "created_at" : "2013-08-04 07:20:27 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363913227144409091",
  "text" : "\uFF1F",
  "id" : 363913227144409091,
  "created_at" : "2013-08-04 06:44:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363913215123529730",
  "text" : "\u4FF3\u53E5\u3092\u8A60\u3080\u3053\u3068\u3092\u30CF\u30A4\u30AD\u30F3\u30B0\u3068\u8A00\u3044\u307E\u3059",
  "id" : 363913215123529730,
  "created_at" : "2013-08-04 06:44:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363912569884377088",
  "text" : "\u30C4\u30E9\u30DF=\u30A2\u30CA\u30ED\u30B8\u30FC\u2026",
  "id" : 363912569884377088,
  "created_at" : "2013-08-04 06:41:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363908510792155136",
  "text" : "\u3044\u3063\u305D\u8150\u3063\u3066\u304A\u304F\u3079\u304D\u3060\u3063\u305F[\uFF1F]",
  "id" : 363908510792155136,
  "created_at" : "2013-08-04 06:25:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363908450230603776",
  "text" : "\u4E00\u4E8C\u56DE\u751F\u306E\u6642\u8150\u3063\u3066\u3055\u3048\u3044\u306A\u304B\u3063\u305F\u306E",
  "id" : 363908450230603776,
  "created_at" : "2013-08-04 06:25:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363904586299346944",
  "text" : "10L\u306F \u91CD\u3044",
  "id" : 363904586299346944,
  "created_at" : "2013-08-04 06:09:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363903906222325760",
  "text" : "\u70CF\u9F8D\u8336135\u5186\u30675\u672C\u8CB7\u3046\u56F3",
  "id" : 363903906222325760,
  "created_at" : "2013-08-04 06:07:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363894818063134720",
  "text" : "\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u7121\u9650\u751F\u7523\u30DE\u30B7\u30FC\u30F3",
  "id" : 363894818063134720,
  "created_at" : "2013-08-04 05:31:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363894732386086912",
  "text" : "\u3042\u30FC\u3001\u30C9\u30F3\u30AF\u306E\u671D\u3068\u304B\u304B",
  "id" : 363894732386086912,
  "created_at" : "2013-08-04 05:30:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363894681832140800",
  "text" : "\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u3092\u304A\u4EE3\u308F\u308A\u81EA\u7531\u306A\u304A\u5E97\u306A\u3044\u304B\u306A\u2026",
  "id" : 363894681832140800,
  "created_at" : "2013-08-04 05:30:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363880677990600705",
  "text" : "\u8B70\u8AD6\u306F\u30E0\u30A4\u30DF\u30FC",
  "id" : 363880677990600705,
  "created_at" : "2013-08-04 04:34:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363880635657502721",
  "text" : "\u30AF\u30E9\u30B7\u30C3\u30AF\u30C1\u30FC\u30BA\u30D0\u30FC\u30AC\u30FC\u306E\u7F8E\u5473\u3057\u3055\u306B\u60B6\u7D76\u3057\u3066\u308B",
  "id" : 363880635657502721,
  "created_at" : "2013-08-04 04:34:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363878812603265025",
  "text" : "\uD83D\uDC4811\u756A\u306E\u756A\u53F7\u672D\u3067\u304A\u5F85\u3061\u306E\u304A\u5BA2\u69D8",
  "id" : 363878812603265025,
  "created_at" : "2013-08-04 04:27:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363878321303465984",
  "text" : "\u98DF\u3079\u308B\u305C\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\uFF01\u514B\u670D\u3059\u308B\u305C\u3073\u305B\u304D\uFF01",
  "id" : 363878321303465984,
  "created_at" : "2013-08-04 04:25:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/W2HLABcGvx",
      "expanded_url" : "http:\/\/4sq.com\/11E5JNL",
      "display_url" : "4sq.com\/11E5JNL"
    } ]
  },
  "geo" : { },
  "id_str" : "363878114587197441",
  "text" : "I'm at \u30D5\u30EC\u30C3\u30B7\u30E5\u30CD\u30B9\u30D0\u30FC\u30AC\u30FC \u5317\u5927\u8DEF\u5E97 (\u4EAC\u90FD\u5E02\u5317\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/W2HLABcGvx",
  "id" : 363878114587197441,
  "created_at" : "2013-08-04 04:24:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363869837543481344",
  "text" : "\u5730\u9707\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 363869837543481344,
  "created_at" : "2013-08-04 03:51:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363869460001591296",
  "text" : "\u5F1F\u304C\u5927\u5B66\u306E\u8CC7\u6599\u6B32\u3057\u304C\u3063\u3066\u308B\u3089\u3057\u3044\u304C\u3069\u3053\u3067\u624B\u306B\u5165\u308B\u3093\u3060\u2026",
  "id" : 363869460001591296,
  "created_at" : "2013-08-04 03:50:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363868628040417280",
  "text" : "\"\u4E16\u4FD7\u306E\u4E16\"\u306E\"\u99AC\u304B\u3089\u843D\u99AC\"\u611F",
  "id" : 363868628040417280,
  "created_at" : "2013-08-04 03:46:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363868523304464384",
  "text" : "\u5927\u738B\u3001\u4E16\u4FD7\u306E\u4E16\u3092\u898B\u5B66\u3059\u308B\u306E\u5DFB",
  "id" : 363868523304464384,
  "created_at" : "2013-08-04 03:46:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363857780978880514",
  "text" : "\u671D\u304B\u3089\u304A\u8179\u306E\u8ABF\u5B50is\u60AA\u3044",
  "id" : 363857780978880514,
  "created_at" : "2013-08-04 03:03:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363857672740675584",
  "text" : "\u304A\u8179\u75DB\u3044\u8179\u75DB\u30DA\u30A4\u30F3",
  "id" : 363857672740675584,
  "created_at" : "2013-08-04 03:03:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363830668268019712",
  "text" : "\u30AB\u30EA\u30AB\u30EA\u306B\u713C\u3044\u305F\u8584\u3044\u98DF\u30D1\u30F3\u3068\u30B3\u30FC\u30D2\u30FC\u3067\u5E78\u305B\u306A\u671D",
  "id" : 363830668268019712,
  "created_at" : "2013-08-04 01:16:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363825226867412993",
  "text" : "\u98DF\u30D1\u30F3\u3092\u713C\u3044\u3066\u73C8\u7432\u3092\u3044\u308C\u3088\u30FC",
  "id" : 363825226867412993,
  "created_at" : "2013-08-04 00:54:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363821241506856960",
  "text" : "\u3057\u304B\u3057\u8179\u75DB\u306E\u539F\u56E0\u304C\u601D\u3044\u5F53\u305F\u3089\u3093\u307D\u3093",
  "id" : 363821241506856960,
  "created_at" : "2013-08-04 00:38:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363820731261399043",
  "text" : "\u5922\u306E\u4E2D\u3067 \u300C\u3054\u3081\u3093\u3061\u3087\u3063\u3068\u30C8\u30A4\u30EC\u3001\u304A\u8179\u75DB\u3044\u300D\u3063\u3066\u76F8\u624B\u306B\u544A\u3052\u3066\u76EE\u899A\u3081\u305F\u308F\u3051\u3060\u3051\u3069\u3001\u623B\u3089\u306A\u304F\u3066\u826F\u3044\u3088\u306D",
  "id" : 363820731261399043,
  "created_at" : "2013-08-04 00:36:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/NtTEWUyiFn",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=DD_115_REINA",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363816528791076864",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/NtTEWUyiFn",
  "id" : 363816528791076864,
  "created_at" : "2013-08-04 00:19:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363712136406499328",
  "text" : "\u6D41\u77F3\u306B\u3053\u3053\u3067\u4F55\u304B\u305F\u3079\u308B\u306E\u306F\u3084\u3081\u3066\u304A\u304F\u3067\u3057",
  "id" : 363712136406499328,
  "created_at" : "2013-08-03 17:25:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363711589704146944",
  "text" : "\u7A7A\u8179\u306E\u6A29\u5316",
  "id" : 363711589704146944,
  "created_at" : "2013-08-03 17:22:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363649407691927553",
  "geo" : { },
  "id_str" : "363649458283626496",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u306D\u30FC",
  "id" : 363649458283626496,
  "in_reply_to_status_id" : 363649407691927553,
  "created_at" : "2013-08-03 13:16:01 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363649323831013376",
  "text" : "\u30CD\u30BF\u3068\u305D\u3046\u3067\u306A\u3044\u3082\u306E\u306E\u30D0\u30A6\u30F3\u30C0\u30EA\u30FC",
  "id" : 363649323831013376,
  "created_at" : "2013-08-03 13:15:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363649100920537089",
  "text" : "\u9EBB\u96C0\u3084\u308B\u4EBA\u306B\u306F0\u672C\u5834\u304B\u3089\u59CB\u307E\u308B\u3058\u3083\u3093\u3063\u3066\u8A00\u3046\u3051\u3069\u306A [0\u306F\u81EA\u306A\u3093\u3068\u304B\u6570]",
  "id" : 363649100920537089,
  "created_at" : "2013-08-03 13:14:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363648226483634176",
  "text" : "\u6D5C\u8FBA\u3067\u9577\u8896\u9577\u30BA\u30DC\u30F3\u3067\u51B7\u305F\u3044\u70CF\u9F8D\u8336\u3068\u304B\u98F2\u307F\u305F\u3044",
  "id" : 363648226483634176,
  "created_at" : "2013-08-03 13:11:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363648119084302336",
  "text" : "\u6D77\u884C\u304D\u305F\u3044\u3001\u5165\u308A\u305F\u304F\u306A\u3044\u3051\u3069",
  "id" : 363648119084302336,
  "created_at" : "2013-08-03 13:10:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363630231761854464",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 363630231761854464,
  "created_at" : "2013-08-03 11:59:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3046\u3093\u3053\u3051\u3068\u307F",
      "screen_name" : "_Mosstomi",
      "indices" : [ 0, 10 ],
      "id_str" : "1436955463",
      "id" : 1436955463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363617493308289024",
  "geo" : { },
  "id_str" : "363618860965969921",
  "in_reply_to_user_id" : 1436955463,
  "text" : "@_Mosstomi \u304A\u304A\u30FC\u30B5\u30F3\u30AD\u30E5\u30FC\u8AAD\u3093\u3067\u307F\u308B",
  "id" : 363618860965969921,
  "in_reply_to_status_id" : 363617493308289024,
  "created_at" : "2013-08-03 11:14:26 +0000",
  "in_reply_to_screen_name" : "_Mosstomi",
  "in_reply_to_user_id_str" : "1436955463",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363616959935426560",
  "text" : "\u3044\u307E\u306E\u306A\u3057\uFF01",
  "id" : 363616959935426560,
  "created_at" : "2013-08-03 11:06:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363616939202969600",
  "text" : "\u72C2\u90FD\u2026",
  "id" : 363616939202969600,
  "created_at" : "2013-08-03 11:06:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u30FC\u307E",
      "screen_name" : "amaterasutomato",
      "indices" : [ 3, 19 ],
      "id_str" : "326549781",
      "id" : 326549781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363616865072857090",
  "text" : "RT @amaterasutomato: \u4E09\u6761\u306B\u6563\u4E71",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363616759187636224",
    "text" : "\u4E09\u6761\u306B\u6563\u4E71",
    "id" : 363616759187636224,
    "created_at" : "2013-08-03 11:06:05 +0000",
    "user" : {
      "name" : "\u3068\u30FC\u307E",
      "screen_name" : "amaterasutomato",
      "protected" : false,
      "id_str" : "326549781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604008687724724225\/kcWDoktu_normal.jpg",
      "id" : 326549781,
      "verified" : false
    }
  },
  "id" : 363616865072857090,
  "created_at" : "2013-08-03 11:06:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363616137071706112",
  "text" : "\u5B9F\u5BB6\u307E\u3067\u539F\u4ED8\u3067\u5E30\u308B\u904A\u3073\u3057\u3066\u307F\u305F\u3044\u3051\u3069\u5E30\u308A\u3082\u539F\u4ED8\u3063\u3066\u3044\u3046\u306E\u304C\u30CA\u30FC",
  "id" : 363616137071706112,
  "created_at" : "2013-08-03 11:03:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 0, 16 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363615319606038529",
  "geo" : { },
  "id_str" : "363615413189345280",
  "in_reply_to_user_id" : 230918258,
  "text" : "@takasan_san_san \u304A\u3044\u3057\u305D\u3046\uFF01",
  "id" : 363615413189345280,
  "in_reply_to_status_id" : 363615319606038529,
  "created_at" : "2013-08-03 11:00:44 +0000",
  "in_reply_to_screen_name" : "takasan_san_san",
  "in_reply_to_user_id_str" : "230918258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363614876897247233",
  "text" : "\u3070\u3093\u3054\u3071\u3093",
  "id" : 363614876897247233,
  "created_at" : "2013-08-03 10:58:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363614840822042624",
  "text" : "\u3075\u3063\u3075\u3063\u3075\u30FC\u3001\u98DF\u30D1\u30F3\u4E00\u65A4\u30928\u679A\u5207\u308A\u306B\u3057\u3066\u3082\u3089\u3063\u305F\u79C1\u306B\u6B7B\u89D2\u306F\u306A\u3044\uFF01",
  "id" : 363614840822042624,
  "created_at" : "2013-08-03 10:58:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363614373094227968",
  "text" : "\u8A66\u3057\u306B\u5A5A\u59FB\u5C4A\u3092\u63D0\u51FA\u3059\u308B(\u7F6A\u306B\u306A\u3089\u306A\u3044)",
  "id" : 363614373094227968,
  "created_at" : "2013-08-03 10:56:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363614247051198465",
  "text" : "\u8FBB\u8904\u3063\u3066\u306A\u3093\u304B\u3053\u3046\u8FBB\u65AC\u308A\u306E\u5A5A\u59FB\u5C4A\u7248\u307F\u305F\u3044\u3060\u3088\u306D",
  "id" : 363614247051198465,
  "created_at" : "2013-08-03 10:56:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363613380944203776",
  "text" : "\u8FBB\u8904\u300C\u5408\u3044\u305F\u30FC\u3044\u306E\u30FC\u306B\u30FC\u3001\u3044\u3064\u30FC\u3082\u30FC\u3046\u307E\u30FC\u304F\u3044\u304B\u3041\u306A\u3044\u300D",
  "id" : 363613380944203776,
  "created_at" : "2013-08-03 10:52:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363613191533637632",
  "text" : "\u8FBB\u8904\u300C\u5408\u3044\u305F\u304F\u3066\u5408\u3044\u305F\u304F\u3066\u9707\u3048\u308B\u300D",
  "id" : 363613191533637632,
  "created_at" : "2013-08-03 10:51:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363613101356093440",
  "text" : "\u8FBB\u8904\u300C\u4F1A\u3044\u305F\u3044\u300D",
  "id" : 363613101356093440,
  "created_at" : "2013-08-03 10:51:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363611717130919937",
  "geo" : { },
  "id_str" : "363612821004623872",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank (\u5143\u30CD\u30BF\u3092\u77E5\u3063\u3066\u308B\u304B\u5206\u304B\u3089\u306A\u3044\u4EBA\u306B\u30CD\u30BF\u3092\u30D5\u30EB\u306E\u306F)\u5B89\u76F4www \u3063\u3066\u610F\u5473\u3060\u3063\u305F\u3093\u3060\u306D\uFF1F",
  "id" : 363612821004623872,
  "in_reply_to_status_id" : 363611717130919937,
  "created_at" : "2013-08-03 10:50:26 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363611502017658882",
  "geo" : { },
  "id_str" : "363611589938642944",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u307F\u306A\u307F\u3051 \u30AB\u30C3\u30D7\u713C\u304D\u305D\u3070\u73FE\u8C61[\u691C\u7D22]",
  "id" : 363611589938642944,
  "in_reply_to_status_id" : 363611502017658882,
  "created_at" : "2013-08-03 10:45:33 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363611267241480192",
  "geo" : { },
  "id_str" : "363611336522993665",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u30AB\u30C3\u30D7\u713C\u304D\u305D\u3070\u73FE\u8C61\uFF01\uFF01\uFF01",
  "id" : 363611336522993665,
  "in_reply_to_status_id" : 363611267241480192,
  "created_at" : "2013-08-03 10:44:32 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363610394180329473",
  "text" : "\uFF1F",
  "id" : 363610394180329473,
  "created_at" : "2013-08-03 10:40:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363610331064451073",
  "text" : "\u6211\u3005\u81EA\u8EAB\u304C\u3086\u3086\u5F0F\u306B\u306A\u308B\u3053\u3068\u3060",
  "id" : 363610331064451073,
  "created_at" : "2013-08-03 10:40:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363609777160454145",
  "text" : "\u6C17\u4ED8\u3044\u305F\u3089\u5353\u4E0A\u30E9\u30A4\u30C8\u3068PC\u4EE5\u5916\u6697\u304F\u3066( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 363609777160454145,
  "created_at" : "2013-08-03 10:38:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363572638792155137",
  "text" : "\u30AF\u30EA\u30FC\u30E0\u30D1\u30F3\u3092\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\u305F\u3079\u308B\uFF01",
  "id" : 363572638792155137,
  "created_at" : "2013-08-03 08:10:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363515807797477376",
  "text" : "\u30C6\u30EC\u30D3\u304C\u304F\u3060\u3089\u306A\u3044[\u3067\u3055\u304D\u3066\u308C\u3073]",
  "id" : 363515807797477376,
  "created_at" : "2013-08-03 04:24:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 0, 9 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363512638103240704",
  "geo" : { },
  "id_str" : "363512986867990528",
  "in_reply_to_user_id" : 532309831,
  "text" : "@usiusi02 \uFF1F",
  "id" : 363512986867990528,
  "in_reply_to_status_id" : 363512638103240704,
  "created_at" : "2013-08-03 04:13:44 +0000",
  "in_reply_to_screen_name" : "usiusi02",
  "in_reply_to_user_id_str" : "532309831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 0, 9 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363512638103240704",
  "geo" : { },
  "id_str" : "363512973404286976",
  "in_reply_to_user_id" : 532309831,
  "text" : "@usiusi02 \u4E09\u4EBA\u5BC4\u308C\u3070\u725B",
  "id" : 363512973404286976,
  "in_reply_to_status_id" : 363512638103240704,
  "created_at" : "2013-08-03 04:13:41 +0000",
  "in_reply_to_screen_name" : "usiusi02",
  "in_reply_to_user_id_str" : "532309831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363507389565124610",
  "geo" : { },
  "id_str" : "363512737499848704",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u76F8\u624B\u306B\u3057\u306A\u3044\u65B9\u304C\u3044\u3044\u4EBA\u7A2E\u306F\u5B9F\u969B\u76F8\u624B\u306B\u3057\u306A\u3044\u65B9\u304C\u826F\u3044\u30E1\u30BD\u30C3\u30C9",
  "id" : 363512737499848704,
  "in_reply_to_status_id" : 363507389565124610,
  "created_at" : "2013-08-03 04:12:45 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363363741879902208",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u2026",
  "id" : 363363741879902208,
  "created_at" : "2013-08-02 18:20:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363362854092554240",
  "text" : "\u81EA\u4FE1\u3092\u6301\u305F\u306A\u3044\u8005\u306F\u81EA\u4FE1\u3092\u5931\u3046\u3053\u3068\u3055\u3048\u51FA\u6765\u306A\u3044\u3093\u3060\u306A\u3041 \u307F\u3064\u3092",
  "id" : 363362854092554240,
  "created_at" : "2013-08-02 18:17:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363307571819450368",
  "text" : "\u8266\u3053\u308C\u304C\u6B7B\u3093\u3067\u308B\u306E\u306F\u30CA\u30F3\u30C7\uFF1F\uFF01",
  "id" : 363307571819450368,
  "created_at" : "2013-08-02 14:37:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363306452145807365",
  "text" : "\u3053\u306E\u7D42\u308F\u3063\u305F\u5F8C\u306E\u8336\u756A\u672C\u5F53\u306B\u3044\u3089\u306A\u3044(\u771F\u9854)",
  "id" : 363306452145807365,
  "created_at" : "2013-08-02 14:33:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363306023030763522",
  "text" : "\u3044\u307E\u306E\u306A\u3057",
  "id" : 363306023030763522,
  "created_at" : "2013-08-02 14:31:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363305976440438786",
  "text" : "\u8996\u8074\u7387\u304C\"\u30D1\u30EB\u30B9\"",
  "id" : 363305976440438786,
  "created_at" : "2013-08-02 14:31:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3046\u3093\u3053\u3051\u3068\u307F",
      "screen_name" : "_Mosstomi",
      "indices" : [ 0, 10 ],
      "id_str" : "1436955463",
      "id" : 1436955463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363305398024945665",
  "geo" : { },
  "id_str" : "363305788351066114",
  "in_reply_to_user_id" : 1436955463,
  "text" : "@_Mosstomi \u3044\u3084\u3057\u304B\u3057\u308F\u3056\u308F\u3056\u53CB\u4EBA\u306E\u5BB6\u3067\u898B\u305F\u7532\u6590\u306E\u3042\u308BTL\u3060\u3063\u305F",
  "id" : 363305788351066114,
  "in_reply_to_status_id" : 363305398024945665,
  "created_at" : "2013-08-02 14:30:24 +0000",
  "in_reply_to_screen_name" : "_Mosstomi",
  "in_reply_to_user_id_str" : "1436955463",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363305309361537024",
  "text" : "\u30D0\u30EB\u30B9\u5F8C\u306E\"\u7D42\u308F\u3063\u305F\u611F\"\u3072\u3069\u3044",
  "id" : 363305309361537024,
  "created_at" : "2013-08-02 14:28:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363304727557046277",
  "text" : "\uFF1F",
  "id" : 363304727557046277,
  "created_at" : "2013-08-02 14:26:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363304715951407104",
  "text" : "\u304D\u3063\u3068\u300CC\u300D\u306E\u9023\u9396\u307F\u305F\u3044\u306BTwitter\u306E\u30B5\u30FC\u30D0\u3067\u9811\u5F35\u3063\u3066\u305F\u4EBA\u304C\u3044\u308B\u3093\u3060\u3088",
  "id" : 363304715951407104,
  "created_at" : "2013-08-02 14:26:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363304273422974978",
  "text" : "\u30B4\u30A6\u30E9\u30F3\u30AC\uFF01\u8840\u3082\u6D99\u3082\u306A\u3044\u6EC5\u3073\u306E\u546A\u6587\u3067\u30E0\u30B9\u30AB\u306F\u3057\u3081\u3084\u304B\u306B\u7206\u767A\u56DB\u6563\uFF01",
  "id" : 363304273422974978,
  "created_at" : "2013-08-02 14:24:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363303794932580353",
  "text" : "\u3081\u304C\u30FC\u3081\u304C\u30FC",
  "id" : 363303794932580353,
  "created_at" : "2013-08-02 14:22:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363303630390038542",
  "text" : "\u30D0\u30EB\u30B9\uFF01",
  "id" : 363303630390038542,
  "created_at" : "2013-08-02 14:21:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363303426911772675",
  "text" : "\u4E09\u5206\u5F85\u3063\u3066\u304F\u308C\u308B\u30E0\u30B9\u30AB\u306E\u512A\u3057\u3055\u306B\u6D99\u3092\u7981\u3058\u5F97\u306A\u3044",
  "id" : 363303426911772675,
  "created_at" : "2013-08-02 14:21:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363302958936489985",
  "text" : "\u547D\u4E5E\u3044\u3092\u3057\u308D\u30FC",
  "id" : 363302958936489985,
  "created_at" : "2013-08-02 14:19:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363302645152235520",
  "text" : "hahahahahaha\u3067\u3044\u3061\u3044\u3061\u306B\u3084\u3051\u3066\u3057\u307E\u3046",
  "id" : 363302645152235520,
  "created_at" : "2013-08-02 14:17:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363301804873760768",
  "text" : "HAHAHAHA",
  "id" : 363301804873760768,
  "created_at" : "2013-08-02 14:14:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363301686959280129",
  "text" : "\u3072\u3068\u304C\u3054\u307F\u306E\u3084\u3046\u3060\uFF01",
  "id" : 363301686959280129,
  "created_at" : "2013-08-02 14:14:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363301035231551488",
  "text" : "HAHAHAHAHA",
  "id" : 363301035231551488,
  "created_at" : "2013-08-02 14:11:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363300392446070784",
  "text" : "\u3053\u3053\u307E\u3067\u5F37\u304B\u3060\u3063\u305F\u30E0\u30B9\u30AB\u306E\u6025\u6FC0\u306A\u5C0F\u7269\u5316\u304C\u59CB\u307E\u308B\u2026\uFF01",
  "id" : 363300392446070784,
  "created_at" : "2013-08-02 14:08:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363300124715266048",
  "text" : "\u5F85\u6A5F\u3059\u308B\u304B\u30FC",
  "id" : 363300124715266048,
  "created_at" : "2013-08-02 14:07:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363279579986669570",
  "text" : "\u672C\u7DE8",
  "id" : 363279579986669570,
  "created_at" : "2013-08-02 12:46:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363279402185916417",
  "text" : "\u307D\u3080\u3058\u30FC\u3055\u3093\uFF01",
  "id" : 363279402185916417,
  "created_at" : "2013-08-02 12:45:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363269995695849473",
  "text" : "\u30E9\u30D4\u30E5\u30BF\u3067\u4E00\u4E8C\u3092\u4E89\u3046\u540D\u53F0\u8A5E\u304C\u51FA\u307E\u3057\u305F\u306A\u30FC",
  "id" : 363269995695849473,
  "created_at" : "2013-08-02 12:08:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D17\u90A3@ingress\u7DD1A15",
      "screen_name" : "rare_shana",
      "indices" : [ 3, 14 ],
      "id_str" : "183190953",
      "id" : 183190953
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "laputa",
      "indices" : [ 23, 30 ]
    }, {
      "text" : "\u5929\u7A7A\u306E\u57CE\u30E9\u30D4\u30E5\u30BF",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363269915748212736",
  "text" : "RT @rare_shana: \u30DE\u30DE\u3001\u843D\u3061\u308B #laputa #\u5929\u7A7A\u306E\u57CE\u30E9\u30D4\u30E5\u30BF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/rare_shana\" rel=\"nofollow\"\u003E\u3061\u3083\u3089\u304F\u306A\u3044\u3057\u3083\u306A\u305F\u3093\u3055\u3093\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "laputa",
        "indices" : [ 7, 14 ]
      }, {
        "text" : "\u5929\u7A7A\u306E\u57CE\u30E9\u30D4\u30E5\u30BF",
        "indices" : [ 15, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363269770843389953",
    "text" : "\u30DE\u30DE\u3001\u843D\u3061\u308B #laputa #\u5929\u7A7A\u306E\u57CE\u30E9\u30D4\u30E5\u30BF",
    "id" : 363269770843389953,
    "created_at" : "2013-08-02 12:07:17 +0000",
    "user" : {
      "name" : "\u7D17\u90A3@ingress\u7DD1A15",
      "screen_name" : "rare_shana",
      "protected" : false,
      "id_str" : "183190953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436501258786967552\/01fmi8Vr_normal.jpeg",
      "id" : 183190953,
      "verified" : false
    }
  },
  "id" : 363269915748212736,
  "created_at" : "2013-08-02 12:07:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363269756045885441",
  "text" : "\u30B7\u30FC\u30BF\u300C\u30D3\u30F3\uFF01\u300D\u30E0\u30B9\u30AB\u300C\u30B0\u30EF\u30FC\u30C3\uFF01\u300D",
  "id" : 363269756045885441,
  "created_at" : "2013-08-02 12:07:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363269587938181120",
  "text" : "\u30E0\u30B9\u30AB\u51FA\u3066\u304F\u308B\u3060\u3051\u3067\u9762\u767D\u3044\u304B\u3089\u30E0\u30B9\u30AB\u306E\u30B3\u30F3\u30C6\u30F3\u30C4\u529B\u304C\u3084\u3070\u3044",
  "id" : 363269587938181120,
  "created_at" : "2013-08-02 12:06:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363269461916135424",
  "text" : "\u30C9\u30FC\u30E2\u3001\u30B7\u30FC\u30BF=\u30B5\u30F3\u3001\u30DE\u30F3\u30DE\u30E6\u30FC\u30C8=\u30AF\u30E9\u30F3\u3067\u3059\u3002",
  "id" : 363269461916135424,
  "created_at" : "2013-08-02 12:06:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3089\u3074\u3085\u305F",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363269132524851200",
  "text" : "\u3074\u3085\u308B\u3074\u3085\u308B\u3074\u3085\u308B #\u3089\u3074\u3085\u305F",
  "id" : 363269132524851200,
  "created_at" : "2013-08-02 12:04:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363268784443764736",
  "text" : "\u540D\u524D\u30D0\u30EB\u30B9\uFF01\u306B\u3059\u308B\u306E\u307B\u3093\u3068\u305A\u308B\u3044",
  "id" : 363268784443764736,
  "created_at" : "2013-08-02 12:03:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363236944148307969",
  "text" : "\u305D\u3046\u304B\u4ECA\u591C\u30D0\u30EB\u30B9\u304B",
  "id" : 363236944148307969,
  "created_at" : "2013-08-02 09:56:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363184264495370243",
  "text" : "\"2\u4EBA\u7D44\u4F5C\u3063\u3066!!\"\u306E\u6EC5\u3073\u306E\u546A\u6587\u3002\u30E0\u30B9\u30AB\u306F\u6B7B\u306C\u3002",
  "id" : 363184264495370243,
  "created_at" : "2013-08-02 06:27:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363168208880009219",
  "text" : "\u898B\u4E8B\u306A\u30AE\u30E3\u30B0",
  "id" : 363168208880009219,
  "created_at" : "2013-08-02 05:23:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6D45\u672C\u30C0\u30B5\u5E73",
      "screen_name" : "fuckn15",
      "indices" : [ 3, 11 ],
      "id_str" : "353598147",
      "id" : 353598147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363168173429764097",
  "text" : "RT @fuckn15: \u5E30\u5B85\u30A5\u30FC\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363167898153385985",
    "text" : "\u5E30\u5B85\u30A5\u30FC\uFF01",
    "id" : 363167898153385985,
    "created_at" : "2013-08-02 05:22:28 +0000",
    "user" : {
      "name" : "\u6D45\u672C\u30C0\u30B5\u5E73",
      "screen_name" : "fuckn15",
      "protected" : false,
      "id_str" : "353598147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1491322397\/__iso-2022-jp_B_GyRCJD8kJCQsGyhCLkpQRw_____normal",
      "id" : 353598147,
      "verified" : false
    }
  },
  "id" : 363168173429764097,
  "created_at" : "2013-08-02 05:23:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6D45\u672C\u30C0\u30B5\u5E73",
      "screen_name" : "fuckn15",
      "indices" : [ 3, 11 ],
      "id_str" : "353598147",
      "id" : 353598147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363168159458537472",
  "text" : "RT @fuckn15: \u6E80\u5BA4\u30A5\u30FC\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363167854108999683",
    "text" : "\u6E80\u5BA4\u30A5\u30FC\uFF01",
    "id" : 363167854108999683,
    "created_at" : "2013-08-02 05:22:18 +0000",
    "user" : {
      "name" : "\u6D45\u672C\u30C0\u30B5\u5E73",
      "screen_name" : "fuckn15",
      "protected" : false,
      "id_str" : "353598147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1491322397\/__iso-2022-jp_B_GyRCJD8kJCQsGyhCLkpQRw_____normal",
      "id" : 353598147,
      "verified" : false
    }
  },
  "id" : 363168159458537472,
  "created_at" : "2013-08-02 05:23:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6D45\u672C\u30C0\u30B5\u5E73",
      "screen_name" : "fuckn15",
      "indices" : [ 3, 11 ],
      "id_str" : "353598147",
      "id" : 353598147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363168131532849152",
  "text" : "RT @fuckn15: \u304A\uFF01\u30D2\u30C8\u30AB\u30E9\u30A5\u30FC\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363167500218802177",
    "text" : "\u304A\uFF01\u30D2\u30C8\u30AB\u30E9\u30A5\u30FC\uFF01",
    "id" : 363167500218802177,
    "created_at" : "2013-08-02 05:20:54 +0000",
    "user" : {
      "name" : "\u6D45\u672C\u30C0\u30B5\u5E73",
      "screen_name" : "fuckn15",
      "protected" : false,
      "id_str" : "353598147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1491322397\/__iso-2022-jp_B_GyRCJD8kJCQsGyhCLkpQRw_____normal",
      "id" : 353598147,
      "verified" : false
    }
  },
  "id" : 363168131532849152,
  "created_at" : "2013-08-02 05:23:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363167351564275712",
  "text" : "\u7DDA\u5F62A\u3063\u3066\u3053\u3093\u306A\u3093\u306A\u306E\u304B",
  "id" : 363167351564275712,
  "created_at" : "2013-08-02 05:20:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363167024689594368",
  "text" : "\u3072\u30FC\u308D\u3063\u304C\u3063\u305F\u3042\u304B\u308A\u304C\u30FC\u3061\u3083\u3061\u3083\u30FC\u3061\u3083\u30FC\u3061\u3083\u30FC\u3061\u3083\u30FC\u3061\u3083\u3061\u3083\u3061\u3083",
  "id" : 363167024689594368,
  "created_at" : "2013-08-02 05:19:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363154798821912576",
  "text" : "\u3042\u305F\u307E\u308F\u308B\u305D\u3046",
  "id" : 363154798821912576,
  "created_at" : "2013-08-02 04:30:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363154782178906113",
  "text" : "\u8D77\u304D\u305F\u6642\u306B\u6642\u8A08\u304C15:00\u904E\u304E\u3066\u308B\u3088\u3046\u306B\u898B\u3048\u3066\u4E00\u65E5\u640D\u3057\u305F\u611F\u3058\u3057\u305F\u304B\u3089\u4ECA\u306F\u51C4\u3044\u5F97\u3057\u305F\u611F\u3058\u3057\u3066\u308B",
  "id" : 363154782178906113,
  "created_at" : "2013-08-02 04:30:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363146759398113280",
  "text" : "\u5996\u3057\u3044\u5996\u8853",
  "id" : 363146759398113280,
  "created_at" : "2013-08-02 03:58:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363103097649770497",
  "text" : "\u6DF1\u3044\u7720\u305F\u307F\u3092\u5F15\u304D\u9023\u308C\u3066\u306E\u8D77\u5E8A",
  "id" : 363103097649770497,
  "created_at" : "2013-08-02 01:04:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362978594806431744",
  "text" : "\u306F\u3084\u3081\u3060\u3051\u3069\u304A\u3084\u3059\u307F",
  "id" : 362978594806431744,
  "created_at" : "2013-08-01 16:50:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52C9\u5F37\u3057\u307E\u3059",
      "screen_name" : "lunaaaaa395",
      "indices" : [ 0, 12 ],
      "id_str" : "324633034",
      "id" : 324633034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362967795006320640",
  "geo" : { },
  "id_str" : "362967886874161152",
  "in_reply_to_user_id" : 324633034,
  "text" : "@lunaaaaa395 \u305D\u3082\u305D\u3082\u3042\u3093\u307E\u308A\u4F7F\u308F\u308C\u308B\u8A00\u8449\u3067\u3082\u306A\u3044\u3067\u3059\u3051\u308C\u3069\u306D\u30FC",
  "id" : 362967886874161152,
  "in_reply_to_status_id" : 362967795006320640,
  "created_at" : "2013-08-01 16:07:42 +0000",
  "in_reply_to_screen_name" : "lunaaaaa395",
  "in_reply_to_user_id_str" : "324633034",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362967546036625409",
  "text" : "\u3072\u304D\"\u305A\"\u3089\u308C\u308B\u3067\"\u3065\"\u3067\u306A\u3044",
  "id" : 362967546036625409,
  "created_at" : "2013-08-01 16:06:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362967432043827201",
  "text" : "\u306A\u3093\u3068\u306A\u304F\"\u3057\u304B\u3057\"\u306B\u3072\u304D\u3065\u3089\u308C\u308B\"\u3057\u304B\u3057\u3066\"",
  "id" : 362967432043827201,
  "created_at" : "2013-08-01 16:05:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52C9\u5F37\u3057\u307E\u3059",
      "screen_name" : "lunaaaaa395",
      "indices" : [ 0, 12 ],
      "id_str" : "324633034",
      "id" : 324633034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362967184047214592",
  "geo" : { },
  "id_str" : "362967348287782914",
  "in_reply_to_user_id" : 324633034,
  "text" : "@lunaaaaa395 \"\u3057\u304B\u3057\u3066\"\u3068\u304B\uFF1F",
  "id" : 362967348287782914,
  "in_reply_to_status_id" : 362967184047214592,
  "created_at" : "2013-08-01 16:05:34 +0000",
  "in_reply_to_screen_name" : "lunaaaaa395",
  "in_reply_to_user_id_str" : "324633034",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362966950562906114",
  "text" : "\u30D7\u30FC\u30EB\u306E\u76E3\u8996\u54E1\u306E\u30D0\u30A4\u30C8\u3084\u3063\u305F\u3053\u3068\u3042\u308B\u3051\u3069\u3042\u308C\u7D42\u696D\u5F8C\u7247\u4ED8\u3051\u3057\u305F\u3089\u597D\u304D\u306B\u6CF3\u3052\u305F\u3057\u975E\u5E38\u306B\u826F\u304B\u3063\u305F[\u713C\u3051\u308B\u3051\u3069]",
  "id" : 362966950562906114,
  "created_at" : "2013-08-01 16:03:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362966692160221184",
  "text" : "\u30C0\u30C3\u30C4\u3045\u3045\u3045\u3045\u3045\u3046",
  "id" : 362966692160221184,
  "created_at" : "2013-08-01 16:02:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362966521481400320",
  "text" : "\u9662\u8A66\u7D42\u308F\u3063\u305F\u3089\u3001\u304B\u3089\u59CB\u307E\u308Bhogehoge\u306F\u8272\u3005\u4E91\u3005",
  "id" : 362966521481400320,
  "created_at" : "2013-08-01 16:02:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362966088130105344",
  "text" : "\u30A2\u30A4\u30B9\u98DF\u3079\u305F\u3044\u306A\u30FC\u3068",
  "id" : 362966088130105344,
  "created_at" : "2013-08-01 16:00:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362912397415026688",
  "text" : "\u5F7C\u6C0F\u6301\u3061\u306E\u7537\u306E\u5B50\u3068\u304B\u5F7C\u5973\u6301\u3061\u306E\u5973\u306E\u5B50\u304C\u591A\u304F\u306A\u304F\u3066\u826F\u304B\u3063\u305F[PLUS\u601D\u8003]",
  "id" : 362912397415026688,
  "created_at" : "2013-08-01 12:27:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362911927103520770",
  "text" : "\u30E1\u30F3\u30C6\u306F\u5FC5\u8981\u60AA",
  "id" : 362911927103520770,
  "created_at" : "2013-08-01 12:25:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362911664405876736",
  "geo" : { },
  "id_str" : "362911864834887680",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u304A\u305F\u3063\u3057\u3083\u3067\u30FC\uFF01",
  "id" : 362911864834887680,
  "in_reply_to_status_id" : 362911664405876736,
  "created_at" : "2013-08-01 12:25:05 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362911768655302656",
  "text" : "\u4E91\u3005\u3068\u304Bhogehoge\u3068\u304B\u4FBF\u5229\u3059\u304E\u3066\u3053\u308C\u304B\u3089\u4E91\u3005\u3068\u304Bhogehoge\u3060\u3051\u3067\u4F1A\u8A71\u3067\u304D\u308B\u3088\u3046\u306B\u306A\u308B\u6642\u4EE3\u304C\u4E91\u3005",
  "id" : 362911768655302656,
  "created_at" : "2013-08-01 12:24:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362911476400402433",
  "geo" : { },
  "id_str" : "362911604414750724",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u30E1\u30F3\u30C6\u4E91\u3005\u3068\u304BTL\u3067\u898B\u307E\u3057\u305F\u304C",
  "id" : 362911604414750724,
  "in_reply_to_status_id" : 362911476400402433,
  "created_at" : "2013-08-01 12:24:03 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362911335677313025",
  "text" : "\u3046\u3075\u3075\u3046\u3075\u3075\u3046\u3075\u3075\u3075\u3075\u30FC",
  "id" : 362911335677313025,
  "created_at" : "2013-08-01 12:22:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362910798735081475",
  "text" : "\u305D\u3057\u3066\u6B8B\u3063\u305F\u306E\u306F\u7AF9\u3084\u3076\u3060\u3051",
  "id" : 362910798735081475,
  "created_at" : "2013-08-01 12:20:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362910769609850880",
  "text" : "\u7AF9\u3084\u3076\u4EE5\u5916\u713C\u3051\u305F",
  "id" : 362910769609850880,
  "created_at" : "2013-08-01 12:20:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362910706565251072",
  "text" : "\u3075\u3068\u3093\u304C\u5F37\u98A8\u306B\u3088\u308A\u98DB\u3093\u3067\u884C\u3063\u305F",
  "id" : 362910706565251072,
  "created_at" : "2013-08-01 12:20:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362910626579886080",
  "text" : "\u30B3\u30F3\u30C9\u30EB\u304C\u5730\u9762\u306B\u57CB\u3081\u3089\u308C\u3068\u308B\uFF01\uFF01",
  "id" : 362910626579886080,
  "created_at" : "2013-08-01 12:20:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362910392218943488",
  "geo" : { },
  "id_str" : "362910555809386499",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u305D\u308A\u3083\u3042\u305D\u3046\u3067\u3059\u306D\u30FC\u3002[\u3057\u304B\u3057\u3053\u308C\u3060\u3068\u30B3\u30F3\u30C9\u30EB\u304C\u5730\u9762\u306B\u57CB\u3081\u3089\u308C\u3066\u308B\u3060\u3051\u611F\u304C]",
  "id" : 362910555809386499,
  "in_reply_to_status_id" : 362910392218943488,
  "created_at" : "2013-08-01 12:19:53 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362909503005540353",
  "text" : "\u3042\u30FC\u3001\u4E0B\u534A\u8EAB\u304C\u3081\u308A\u3053\u3093\u3067\u308B\u3093\u3067\u3059\u304B",
  "id" : 362909503005540353,
  "created_at" : "2013-08-01 12:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/shigmax\/status\/362906140092297217\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/VhDjVaL0G7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQlNNi-CcAEiCi-.jpg",
      "id_str" : "362906140100685825",
      "id" : 362906140100685825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQlNNi-CcAEiCi-.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VhDjVaL0G7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362909430070784002",
  "text" : "RT @shigmax: \u30B3\u30F3\u30C9\u30EB\u304C\u5730\u9762\u306B\u3081\u308A\u3053\u3093\u3069\u308B http:\/\/t.co\/VhDjVaL0G7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/shigmax\/status\/362906140092297217\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/VhDjVaL0G7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQlNNi-CcAEiCi-.jpg",
        "id_str" : "362906140100685825",
        "id" : 362906140100685825,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQlNNi-CcAEiCi-.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/VhDjVaL0G7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362906140092297217",
    "text" : "\u30B3\u30F3\u30C9\u30EB\u304C\u5730\u9762\u306B\u3081\u308A\u3053\u3093\u3069\u308B http:\/\/t.co\/VhDjVaL0G7",
    "id" : 362906140092297217,
    "created_at" : "2013-08-01 12:02:21 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 362909430070784002,
  "created_at" : "2013-08-01 12:15:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362909356523651072",
  "text" : "\u9577\u98A8\u5442\u30E1\u30BD\u30C3\u30C9\u30FC",
  "id" : 362909356523651072,
  "created_at" : "2013-08-01 12:15:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u305A\u304D\u307E\u3055\u3084",
      "screen_name" : "mszk_p",
      "indices" : [ 0, 7 ],
      "id_str" : "859850539",
      "id" : 859850539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362899326588030978",
  "geo" : { },
  "id_str" : "362908474771914752",
  "in_reply_to_user_id" : 859850539,
  "text" : "@mszk_p \u3044\u2026\u884C\u304D\u305F\u3044\u2026\uFF01",
  "id" : 362908474771914752,
  "in_reply_to_status_id" : 362899326588030978,
  "created_at" : "2013-08-01 12:11:37 +0000",
  "in_reply_to_screen_name" : "mszk_p",
  "in_reply_to_user_id_str" : "859850539",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362905501782130688",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 362905501782130688,
  "created_at" : "2013-08-01 11:59:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362899196241645570",
  "text" : "\u7B39\u304B\u307E\u307C\u3053\u4EE5\u5916\u98DF\u3079\u305F\u3044\u3068\u306F\u9650\u3089\u306A\u3044\u306A\u3041\u301C",
  "id" : 362899196241645570,
  "created_at" : "2013-08-01 11:34:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362899006843662336",
  "text" : "\u3069\u3061\u3089\u304B\u3068\u3044\u3046\u3068\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u7B39\u304B\u307E\u307C\u3053\u98DF\u3079\u305F\u3044\u3000\uFF1C\n\uFFE3Y^Y^Y^Y^Y^Y^Y^Y^Y^Y\uFFE3",
  "id" : 362899006843662336,
  "created_at" : "2013-08-01 11:34:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362866699831226368",
  "text" : "18:30\u3068\u306F\u601D\u3048\u306C\u660E\u308B\u3055\u306B\u60B6\u7D76",
  "id" : 362866699831226368,
  "created_at" : "2013-08-01 09:25:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362832204633604096",
  "text" : "\u306E\u305E\u307F\u3093\u3068\u3075\u3041\u3063\u304F\u3093\u77E5\u308A\u5408\u3044\u304B\u3001\u307E\u305F\u77E5\u308A\u5408\u3044\u3068\u77E5\u308A\u5408\u3044\u304C\u77E5\u308A\u5408\u3044\u306E\u30D1\u30BF\u30FC\u30F3\u306E\u5974\u304B",
  "id" : 362832204633604096,
  "created_at" : "2013-08-01 07:08:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hanaki_bot",
      "screen_name" : "hanaki_bot1",
      "indices" : [ 3, 15 ],
      "id_str" : "366433499",
      "id" : 366433499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362817108796641280",
  "text" : "RT @hanaki_bot1: \u5316\u5B66\u4EE5\u5916\u30D5\u30EB\u5358\u30EF\u30F3\u30C1\u30E3\u30F3\u3042\u308B\u308F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twilog.org\/hanaki_bot1\" rel=\"nofollow\"\u003Ehanaki_bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130538684977135616",
    "text" : "\u5316\u5B66\u4EE5\u5916\u30D5\u30EB\u5358\u30EF\u30F3\u30C1\u30E3\u30F3\u3042\u308B\u308F\u3002",
    "id" : 130538684977135616,
    "created_at" : "2011-10-30 06:57:02 +0000",
    "user" : {
      "name" : "hanaki_bot",
      "screen_name" : "hanaki_bot1",
      "protected" : false,
      "id_str" : "366433499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1524663446\/4863333_225_normal.jpg",
      "id" : 366433499,
      "verified" : false
    }
  },
  "id" : 362817108796641280,
  "created_at" : "2013-08-01 06:08:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362817082800349185",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u307E\u30FC\u305F\u6A5F\u80FD\u3057\u3066\u306A\u3044bot\u3092RT\u3057\u304A\u3063\u3066\u2026",
  "id" : 362817082800349185,
  "created_at" : "2013-08-01 06:08:28 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362803051108634625",
  "text" : "\u3086\u308B\u307C:filtered\u306E\u8A33\u8A9E",
  "id" : 362803051108634625,
  "created_at" : "2013-08-01 05:12:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362628518791757826",
  "geo" : { },
  "id_str" : "362628658948620289",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u306A\u308B\u307B\u3069\u3001\u521D\u51FA\u306F\u305D\u3063\u3061\u306A\u3093\u3067\u3059\u304B",
  "id" : 362628658948620289,
  "in_reply_to_status_id" : 362628518791757826,
  "created_at" : "2013-07-31 17:39:44 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362628505621630976",
  "text" : "\u6DF1\u3005\u3068\u7A81\u304D\u523A\u3055\u3063\u3066\u6B7B\u306C",
  "id" : 362628505621630976,
  "created_at" : "2013-07-31 17:39:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 0, 6 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362628130671828993",
  "geo" : { },
  "id_str" : "362628393373671425",
  "in_reply_to_user_id" : 91551881,
  "text" : "@t_uda \u6642\u306E\u6D41\u308C\u3092\u611F\u3058\u307E\u3059\u306D\u3047",
  "id" : 362628393373671425,
  "in_reply_to_status_id" : 362628130671828993,
  "created_at" : "2013-07-31 17:38:40 +0000",
  "in_reply_to_screen_name" : "t_uda",
  "in_reply_to_user_id_str" : "91551881",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "kaikyune",
      "indices" : [ 0, 9 ],
      "id_str" : "1579901712",
      "id" : 1579901712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362628178285576192",
  "geo" : { },
  "id_str" : "362628340693221377",
  "in_reply_to_user_id" : 1579901712,
  "text" : "@kaikyune \u3067\u3057\u305F\u3063\u3051\uFF1F\u8A66\u9A13\u524D\u306B\u3082\u30C1\u30E9\u30DB\u30E9\u898B\u3089\u308C\u305F\u8A18\u61B6\u304C",
  "id" : 362628340693221377,
  "in_reply_to_status_id" : 362628178285576192,
  "created_at" : "2013-07-31 17:38:28 +0000",
  "in_reply_to_screen_name" : "kaikyune",
  "in_reply_to_user_id_str" : "1579901712",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362628238025039872",
  "text" : "\u9700\u8981\u304C\u3042\u308B\u306E\u306F\u308F\u304B\u308B\u3057\u3053\u3053\u306B\u7559\u307E\u308B\u671F\u9593\u304C\u3069\u3093\u306A\u7406\u7531\u3067\u3082\u5897\u3048\u308B\u306A\u3089\u8208\u5473\u306F\u3042\u308B\u3051\u3069\u3001\u8A2D\u7ACB\u3059\u308B\u306E\u306F\u79C1\u3067\u306F\u306A\u3044[\u4EAC\u30C9\u30DF\u30CB\u30AA\u30F3\u4F1A]",
  "id" : 362628238025039872,
  "created_at" : "2013-07-31 17:38:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakeyta",
      "indices" : [ 0, 10 ],
      "id_str" : "308815694",
      "id" : 308815694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362627604055998465",
  "geo" : { },
  "id_str" : "362627813695696896",
  "in_reply_to_user_id" : 308815694,
  "text" : "@heyakeyta \u3044\u3084\u3001\u3042\u3068\u534A\u5E74\u306E\u305F\u3081\u306B\u5954\u8D70\u3057\u307E\u3059\u304B\u306D\u3047[\u50D5\u3068\u3066\u30C9\u30DF\u30CB\u30AA\u30F3\u597D\u304D\u3067\u3059\u3051\u3069\u30A8\u30F3\u30B8\u30E7\u30A4\u52E2\u3068\u3044\u3046\u304B\u30AC\u30C1\u52E2\u304B\u3089\u3057\u305F\u3089\u30CC\u30EB\u3044\u904A\u3073\u65B9\u3057\u304B\u3057\u3066\u307E\u305B\u3093\u3057]",
  "id" : 362627813695696896,
  "in_reply_to_status_id" : 362627604055998465,
  "created_at" : "2013-07-31 17:36:22 +0000",
  "in_reply_to_screen_name" : "heyakeyta",
  "in_reply_to_user_id_str" : "308815694",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362627309150285825",
  "geo" : { },
  "id_str" : "362627488981073921",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u30A2\u30C3\u30CF\u30A4",
  "id" : 362627488981073921,
  "in_reply_to_status_id" : 362627309150285825,
  "created_at" : "2013-07-31 17:35:05 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6EC5\u3073\u306E\u6642\u306F\u8FD1\u3044",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362627428427894786",
  "text" : "\u305D\u3046\u3044\u3084\u6700\u8FD1\u30C6\u30B9\u30C8\u671F\u9593\u306A\u306E\u306B #\u6EC5\u3073\u306E\u6642\u306F\u8FD1\u3044 \u306E\u30BF\u30B0\u898B\u306A\u304F\u306A\u3063\u3061\u3083\u3063\u305F\u306A\u3041",
  "id" : 362627428427894786,
  "created_at" : "2013-07-31 17:34:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362626827887448064",
  "geo" : { },
  "id_str" : "362627241626185728",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3044\u3084\u3069\u306E\u307F\u3061\u9032\u8DEF\u6C7A\u307E\u3063\u3066\u304B\u3089\u8003\u3048\u308B\u611F\u3058\u3067\u3059\u306D[\u9662\u6B7B][\u6EC5\u3073\u306E\u6642\u306F\u8FD1\u3044]",
  "id" : 362627241626185728,
  "in_reply_to_status_id" : 362626827887448064,
  "created_at" : "2013-07-31 17:34:06 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakeyta",
      "indices" : [ 0, 10 ],
      "id_str" : "308815694",
      "id" : 308815694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362626583250485248",
  "geo" : { },
  "id_str" : "362626680763842562",
  "in_reply_to_user_id" : 308815694,
  "text" : "@heyakeyta \u305D\u3053\u307E\u3067\u30E2\u30C1\u30D9\u306A\u3044\u3067\u3059\u3045\u3045[\u3082\u30464\u56DE\u3067\u3059\u3057]",
  "id" : 362626680763842562,
  "in_reply_to_status_id" : 362626583250485248,
  "created_at" : "2013-07-31 17:31:52 +0000",
  "in_reply_to_screen_name" : "heyakeyta",
  "in_reply_to_user_id_str" : "308815694",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakeyta",
      "indices" : [ 0, 10 ],
      "id_str" : "308815694",
      "id" : 308815694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362626358242848768",
  "geo" : { },
  "id_str" : "362626496143163392",
  "in_reply_to_user_id" : 308815694,
  "text" : "@heyakeyta \u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 362626496143163392,
  "in_reply_to_status_id" : 362626358242848768,
  "created_at" : "2013-07-31 17:31:08 +0000",
  "in_reply_to_screen_name" : "heyakeyta",
  "in_reply_to_user_id_str" : "308815694",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakeyta",
      "indices" : [ 0, 10 ],
      "id_str" : "308815694",
      "id" : 308815694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362625813834776576",
  "geo" : { },
  "id_str" : "362626091308949505",
  "in_reply_to_user_id" : 308815694,
  "text" : "@heyakeyta \u3053\u306E\u524D\u307F\u305F\u3044\u306A\u5927\u4F1A\u3067\u306F\u306A\u3044\u304B\u3082\u3067\u3059\u306E\u3067(\uFF1F)",
  "id" : 362626091308949505,
  "in_reply_to_status_id" : 362625813834776576,
  "created_at" : "2013-07-31 17:29:32 +0000",
  "in_reply_to_screen_name" : "heyakeyta",
  "in_reply_to_user_id_str" : "308815694",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362625035451633664",
  "geo" : { },
  "id_str" : "362625316922986496",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u307E\u3041\u305D\u306E\u3078\u3093\u306E\"\"\u30B9\u30BF\u30F3\u30B9\"\"\u306F\u53BB\u5E74\u3068\u540C\u3058\u611F\u3058\u3067\u30FC",
  "id" : 362625316922986496,
  "in_reply_to_status_id" : 362625035451633664,
  "created_at" : "2013-07-31 17:26:27 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362624813849772032",
  "geo" : { },
  "id_str" : "362624945819365377",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u9762\u5012\u306A\u306E\u3067\u305F\u3076\u3093\u58F2\u308A\u307E\u305B\u3093[\u52DD\u624B\u306B\u6301\u3063\u3066\u6765\u3066\u3082\u3089\u3044\u307E\u3057\u3087\u3046]",
  "id" : 362624945819365377,
  "in_reply_to_status_id" : 362624813849772032,
  "created_at" : "2013-07-31 17:24:58 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362624611415883777",
  "geo" : { },
  "id_str" : "362624667502133250",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u306F\u3044\u30FC\u30FC",
  "id" : 362624667502133250,
  "in_reply_to_status_id" : 362624611415883777,
  "created_at" : "2013-07-31 17:23:52 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362624408872951809",
  "geo" : { },
  "id_str" : "362624529631154177",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3084\u308A\u305F\u3044\u3067\u3059\u306D\uFF01\u53BB\u5E74\u307B\u3069\u3044\u308D\u3044\u308D\u51FA\u6765\u308B\u3068\u3082\u9650\u308A\u307E\u305B\u3093\u304C",
  "id" : 362624529631154177,
  "in_reply_to_status_id" : 362624408872951809,
  "created_at" : "2013-07-31 17:23:19 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362624070015127553",
  "geo" : { },
  "id_str" : "362624309300183041",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u305D\u3046\u3044\u3048\u3070\u4ECA\u5E74\u306F\u304B\u3078\u308F\u306C\u3081\u3081\u3044\u305F\u30A2\u30EC\u306F\u3084\u3089\u306A\u3044\u3093\u3067\u3059\u304B\uFF1F",
  "id" : 362624309300183041,
  "in_reply_to_status_id" : 362624070015127553,
  "created_at" : "2013-07-31 17:22:27 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362622696502206464",
  "text" : "\u76F8\u624B\u306B\u3057\u306A\u3044\u65B9\u304C\u826F\u3044\u30BF\u30A4\u30D7\u306E\u4EBA\u985E\u306F\u5B9F\u969B\u76F8\u624B\u306B\u3057\u306A\u3044\u65B9\u304C\u826F\u3044",
  "id" : 362622696502206464,
  "created_at" : "2013-07-31 17:16:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362620941152436224",
  "text" : "\u30A2\u30EC\u306A\u4EBA\u3082\u3044\u308B\u3063\u307D\u3044\u304C\u2606hanaoka_\u3067\u691C\u7D22\u3057\u3066\u898B\u305F\u9650\u308A\u82B1\u5CA1\u3055\u3093\u306F\u304B\u306A\u308A\u611B\u3055\u308C\u3066\u3044\u308B",
  "id" : 362620941152436224,
  "created_at" : "2013-07-31 17:09:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362619543111217152",
  "text" : "\u8EAB\u304B\u3089\u51FA\u305F\u9306\u3060\u304B\u3089\u3068\u8A00\u3063\u3066\u305D\u308C\u3092\u548E\u3081\u308B\u306E\u306F\u3069\u3046\u306A\u306E\u3088\uFF1F",
  "id" : 362619543111217152,
  "created_at" : "2013-07-31 17:03:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362617500837486592",
  "text" : "\u7D0D\u5F97\u884C\u304B\u306A\u3044 of the world",
  "id" : 362617500837486592,
  "created_at" : "2013-07-31 16:55:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362616917527244802",
  "geo" : { },
  "id_str" : "362617106560331776",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u6B7B\u306C\u307B\u3069\u7D0D\u5F97\u884C\u304B\u306A\u3044\u3093\u3067\u3059\u3051\u3069",
  "id" : 362617106560331776,
  "in_reply_to_status_id" : 362616917527244802,
  "created_at" : "2013-07-31 16:53:49 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/362617014180802560\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/AXEK7xrXnR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQhGQNACcAAyobA.jpg",
      "id_str" : "362617014184996864",
      "id" : 362617014184996864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQhGQNACcAAyobA.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/AXEK7xrXnR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362617014180802560",
  "text" : "http:\/\/t.co\/AXEK7xrXnR",
  "id" : 362617014180802560,
  "created_at" : "2013-07-31 16:53:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362615918934753280",
  "geo" : { },
  "id_str" : "362616761239076865",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3068\u3073\u306F\u306D\u308B\u30E9\u30C3\u30AD\u30FC",
  "id" : 362616761239076865,
  "in_reply_to_status_id" : 362615918934753280,
  "created_at" : "2013-07-31 16:52:27 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362615476012060673",
  "geo" : { },
  "id_str" : "362615616181510146",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3084\u308A\u305F\u3044\u3067\u3059",
  "id" : 362615616181510146,
  "in_reply_to_status_id" : 362615476012060673,
  "created_at" : "2013-07-31 16:47:54 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362615587391811584",
  "text" : "\u3053\u306E\u6D41\u308C\u4E45\u3005\u3067\u826F\u3044",
  "id" : 362615587391811584,
  "created_at" : "2013-07-31 16:47:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362615291047444481",
  "text" : "\u30AD\u30EA\u30F3\u30EA\u30AD\u306E\u4F55\u304C\u51C4\u3044\u3063\u3066\u9006\u304B\u3089\u8AAD\u3093\u3067\u3082\u30AD\u30EA\u30F3\u30EA\u30AD\u3068\u8A00\u3046\u70B9\u3067\u3059\u3088",
  "id" : 362615291047444481,
  "created_at" : "2013-07-31 16:46:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u3084\u30BF\u30B3\u30B9(\u261D \u055E\u0A0A \u055E)\u261D",
      "screen_name" : "miya_tacos",
      "indices" : [ 0, 11 ],
      "id_str" : "747261714",
      "id" : 747261714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362614965032587265",
  "geo" : { },
  "id_str" : "362615139024912384",
  "in_reply_to_user_id" : 747261714,
  "text" : "@miya_tacos \u5F7C\u306F\u30E4\u30D0\u3044\u3067\u3059\u3088\u306D\u30FC\u30FC",
  "id" : 362615139024912384,
  "in_reply_to_status_id" : 362614965032587265,
  "created_at" : "2013-07-31 16:46:00 +0000",
  "in_reply_to_screen_name" : "miya_tacos",
  "in_reply_to_user_id_str" : "747261714",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362614592737775616",
  "geo" : { },
  "id_str" : "362614864956502016",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u307E\u3041\u50D5\u304F\u3089\u3044\u306E\u8155\u306B\uFF01\uFF01\uFF01\u306A\u308C\u3070\uFF01\uFF01\uFF01\u3053\u306E\u4F4D\u4F59\u88D5\u3067\u3059\u3088\uFF01\uFF01\uFF01\uFF01\uFF01[9\u6708\u304F\u3089\u3044\u306B\u304A\u7D75\u304B\u304D\u30C4\u30A4\u30AD\u30E3\u30B9\u3057\u3088\u3046\u304B\u3068\u601D\u3063\u3066\u305F\u308A]",
  "id" : 362614864956502016,
  "in_reply_to_status_id" : 362614592737775616,
  "created_at" : "2013-07-31 16:44:55 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362614361577107456",
  "geo" : { },
  "id_str" : "362614466392768512",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma (\u898B\u3066\u66F8\u3044\u305F\u306E\u3067)",
  "id" : 362614466392768512,
  "in_reply_to_status_id" : 362614361577107456,
  "created_at" : "2013-07-31 16:43:20 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362614340119044101",
  "text" : "\u3044\u3084\u307E\u3041\u306A\u306B\u3092\u8A00\u3063\u3066\u3082\u91CE\u66AE\u3067\u3059\u3051\u308C\u3069",
  "id" : 362614340119044101,
  "created_at" : "2013-07-31 16:42:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 53, 62 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362614098699096066",
  "text" : "\u82B1\u5CA1\u3055\u3093\u3001\u6B8B\u5FF5\u3060\u3051\u3069\u3082\u3046\u3053\u308C\u306F\u8AB0\u304C\u306A\u306B\u3092\u8A00\u3063\u3066\u3082\u30A2\u30EC\u3060\u3057\u307E\u305F\u6A5F\u4F1A\u304C\u3042\u3063\u305F\u3089\u904A\u3093\u3067\u304F\u3060\u3055\u3044\u3001\u3068\u8A00\u3046\u611F\u3058\u3067\u3059(@hanaoka_ )",
  "id" : 362614098699096066,
  "created_at" : "2013-07-31 16:41:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/362613368906997760\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/3rad9Yfggj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQhC8BUCYAAG7sg.jpg",
      "id_str" : "362613368915386368",
      "id" : 362613368915386368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQhC8BUCYAAG7sg.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/3rad9Yfggj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362613368906997760",
  "text" : "\u6BBA\u4F10\u3068\u3057\u305FTL\u306B\u30D4\u30C3\u30D4\u304C\uFF01\uFF01\n\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u30D5\u30B7\u30AE\u30BD\u30A6\u3000\uFF1C\n\uFFE3Y^Y^Y^Y^Y^Y\uFFE3 http:\/\/t.co\/3rad9Yfggj",
  "id" : 362613368906997760,
  "created_at" : "2013-07-31 16:38:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]