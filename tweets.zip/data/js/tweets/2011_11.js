Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141806398462898176",
  "text" : "\u985E\u4F53\u8AD6\u30FC",
  "id" : 141806398462898176,
  "created_at" : "2011-11-30 09:10:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141802035237502976",
  "text" : "\u96E2\u8131\u30FC",
  "id" : 141802035237502976,
  "created_at" : "2011-11-30 08:53:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141801779590463488",
  "text" : "\u4FFA\u306F\u95A2\u4FC2\u306A\u3044\u3093\u3067\u3059\u3057\uFF1F",
  "id" : 141801779590463488,
  "created_at" : "2011-11-30 08:52:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E5\u30FC\u5B50\uFF08\u308Dbot\uFF09",
      "screen_name" : "DigitalCuko",
      "indices" : [ 3, 15 ],
      "id_str" : "180848288",
      "id" : 180848288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141801726985515008",
  "text" : "RT @DigitalCuko: \uFF08\u300Cend\u300D\u2026\u2026\u2026\u3044\u30FC\u3048\u306C\u3067\u3043\u30FC\u2026\u2026\u2026\u899A\u3048\u307E\u3057\u305F\u3057)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/digitalcute.com\" rel=\"nofollow\"\u003E\u30AD\u30E5\u30FC\u5B50bot with reudy custom\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141800612848345088",
    "text" : "\uFF08\u300Cend\u300D\u2026\u2026\u2026\u3044\u30FC\u3048\u306C\u3067\u3043\u30FC\u2026\u2026\u2026\u899A\u3048\u307E\u3057\u305F\u3057)",
    "id" : 141800612848345088,
    "created_at" : "2011-11-30 08:47:55 +0000",
    "user" : {
      "name" : "\u30AD\u30E5\u30FC\u5B50\uFF08\u308Dbot\uFF09",
      "screen_name" : "DigitalCuko",
      "protected" : false,
      "id_str" : "180848288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583061166122885120\/jrbBn2LQ_normal.jpg",
      "id" : 180848288,
      "verified" : false
    }
  },
  "id" : 141801726985515008,
  "created_at" : "2011-11-30 08:52:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Sloan",
      "screen_name" : "ts572",
      "indices" : [ 25, 31 ],
      "id_str" : "956244972",
      "id" : 956244972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141801571854991360",
  "text" : "\u7D05\u8449\u3092\u898B\u308B\u3053\u3068\u306E\u52B9\u7528\u3092\u8003\u3048\u308B\u3068\u9AD8\u63DA\u3059\u308B\u306D\u3047 RT @ts572 \u89B3\u5149\u7528\u306E\u7D05\u8449\u3092\u898B\u306B\u884C\u3053\u3046\u3088\u3046",
  "id" : 141801571854991360,
  "created_at" : "2011-11-30 08:51:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141800473714884608",
  "text" : "\u6388\u696D\u3067\u3082\u5185\u8077\u3067\u308290\u5206\u96C6\u4E2D\u3092\u4FDD\u3064\u306E\u306F\u3057\u3093\u3069\u3044\u7CFB\u7537\u5B50",
  "id" : 141800473714884608,
  "created_at" : "2011-11-30 08:47:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141798652229320704",
  "text" : "\u30A6\u30A4\u30EB\u30B9\u7814\u7A76\u6240\u3053\u308F\u3001\u8FD1\u5BC4\u3089\u3093\u3068\u3053",
  "id" : 141798652229320704,
  "created_at" : "2011-11-30 08:40:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141798351220912128",
  "text" : "\u3060\u308C\u3046\u307E",
  "id" : 141798351220912128,
  "created_at" : "2011-11-30 08:38:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 3, 10 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141798313992273920",
  "text" : "RT @rpdexp: \u3069\u3070\u30A4\u30AA\u30CF\u30B6\u30FC\u30C9\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141798258950418432",
    "text" : "\u3069\u3070\u30A4\u30AA\u30CF\u30B6\u30FC\u30C9\u304B",
    "id" : 141798258950418432,
    "created_at" : "2011-11-30 08:38:34 +0000",
    "user" : {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "protected" : false,
      "id_str" : "141811283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583276832234999810\/sa3_ZPQ4_normal.jpg",
      "id" : 141811283,
      "verified" : false
    }
  },
  "id" : 141798313992273920,
  "created_at" : "2011-11-30 08:38:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141797532199170048",
  "text" : "\uFF34\uFF45\uFF38\u3067\u677F\u66F8\u3068\u304B\u3057\u3066\u308B\u4EBA\u5C45\u3093\u306E\u304B\u306A\u3002\u7FD2\u719F\u3057\u305F\u3089\u3067\u304D\u306A\u304F\u306F\u306A\u3055\u305D\u3046\u3060\u3051\u308C\u3069\u3002",
  "id" : 141797532199170048,
  "created_at" : "2011-11-30 08:35:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141796912218128384",
  "text" : "\u3055\u3063\u304D\u660E\u3089\u304B\u306B\uFF24\uFF24\uFF32\u307D\u3044\u4F55\u304B\u306E\uFF30\uFF23\u7248\u3092\u3084\u3063\u3066\u308B\u4EBA\u3044\u305F\u3051\u3069\u2026",
  "id" : 141796912218128384,
  "created_at" : "2011-11-30 08:33:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141729071527755776",
  "text" : "\u3055\u3063\u304D\u53CB\u4EBA\u3060\u3068\u601D\u3063\u3066\u8A71\u3057\u639B\u3051\u305F\u3089\u77E5\u3089\u306A\u3044\u4EBA\u3060\u3063\u305F\u3002\u6065\u305A\u304B\u3057\u3044\u3002",
  "id" : 141729071527755776,
  "created_at" : "2011-11-30 04:03:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141726485143760896",
  "text" : "@koketomi",
  "id" : 141726485143760896,
  "created_at" : "2011-11-30 03:53:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141726346995974146",
  "text" : "\u66F2\u6570\u3063\u3066\u4F55\u304B\u306E\u6570\u5B66\u7528\u8A9E\u304B\u3068\u601D\u3063\u305F(\u3057\u308D\u3081",
  "id" : 141726346995974146,
  "created_at" : "2011-11-30 03:52:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u867B\u30CE\u30FC\u30DE\u30EB",
      "screen_name" : "ayaka1111",
      "indices" : [ 3, 13 ],
      "id_str" : "104431876",
      "id" : 104431876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141719873398112257",
  "text" : "RT @ayaka1111: \u52AA\u529B\u306F\u88CF\u5207\u308B\u304Cd=(^o^)=b\u6020\u60F0\u306F\u7D76\u5BFE\u88CF\u5207\u3089\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141717265631551488",
    "text" : "\u52AA\u529B\u306F\u88CF\u5207\u308B\u304Cd=(^o^)=b\u6020\u60F0\u306F\u7D76\u5BFE\u88CF\u5207\u3089\u306A\u3044",
    "id" : 141717265631551488,
    "created_at" : "2011-11-30 03:16:43 +0000",
    "user" : {
      "name" : "\u867B\u30CE\u30FC\u30DE\u30EB",
      "screen_name" : "ayaka1111",
      "protected" : false,
      "id_str" : "104431876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606505047757758464\/GnxN4kCH_normal.jpg",
      "id" : 104431876,
      "verified" : false
    }
  },
  "id" : 141719873398112257,
  "created_at" : "2011-11-30 03:27:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141680161140645888",
  "geo" : { },
  "id_str" : "141680379219283970",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3070\u3001\u3070\u3088\u3048\u30FC\u3093(",
  "id" : 141680379219283970,
  "in_reply_to_status_id" : 141680161140645888,
  "created_at" : "2011-11-30 00:50:09 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141679918839898114",
  "geo" : { },
  "id_str" : "141680092169506816",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u30DE\u30EB\u30B3\u30D5\u9023\u9396\u3068\u3044\u3046\u3084\u3064\u304B",
  "id" : 141680092169506816,
  "in_reply_to_status_id" : 141679918839898114,
  "created_at" : "2011-11-30 00:49:00 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 1, 9 ],
      "id_str" : "112886536",
      "id" : 112886536
    }, {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 10, 24 ],
      "id_str" : "216818830",
      "id" : 216818830
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 25, 35 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 46, 61 ],
      "id_str" : "227502200",
      "id" : 227502200
    }, {
      "name" : "\u9060\u5C71\u54B2",
      "screen_name" : "g4saku_bot",
      "indices" : [ 62, 73 ],
      "id_str" : "215845940",
      "id" : 215845940
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 74, 84 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141679898686275584",
  "text" : ".@maucha_ @kokoro_G4_bot @nisehorrn @ispamgis @G4_Hirano_chan @g4saku_bot @Lisa_math \u304A\u306F\u3042\u308A\u3067\u3057\u305F\u30FC(bot\u3070\u3063\u304B\u3068\u304B\u8A00\u308F\u306A\u3044\uFF09",
  "id" : 141679898686275584,
  "created_at" : "2011-11-30 00:48:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141678206355914752",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 141678206355914752,
  "created_at" : "2011-11-30 00:41:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141553059632394241",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 141553059632394241,
  "created_at" : "2011-11-29 16:24:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141552975242993664",
  "text" : "\u3075\u3075\u3075\u3001\u3057\u3087\u3046\u3082\u306A",
  "id" : 141552975242993664,
  "created_at" : "2011-11-29 16:23:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141552895001772033",
  "text" : "\u5BDD\u30CA\u30A4\u30C8\n\n\u591C\u3060\u3057\u2026\u306D\u3047",
  "id" : 141552895001772033,
  "created_at" : "2011-11-29 16:23:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141546308992372736",
  "text" : "\u5186\u5468\u7387\u306F\uFF13\u3067\u306F\u3042\u308A\u307E\u305B\u3093",
  "id" : 141546308992372736,
  "created_at" : "2011-11-29 15:57:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u3064\u308A\u3046\u3080@0817-4100-1332",
      "screen_name" : "otsuotsu",
      "indices" : [ 0, 9 ],
      "id_str" : "53934373",
      "id" : 53934373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141545045462487041",
  "geo" : { },
  "id_str" : "141545354494611457",
  "in_reply_to_user_id" : 53934373,
  "text" : "@otsuotsu \u30B7\u30E3\u30FC\u30ED\u30C3\u30AF\u30FB\u30DB\u30FC\u30E0\u30BA\u3068\u8A00\u3046\u6642\u306B\u30B7\u30E3\u30FC\u30ED\u30C3\u30AF\u30FB\u30B7\u30A7\u2026\u304F\u3089\u3044\u307E\u3067\u8A00\u3063\u3066\u3057\u307E\u3063\u3066\u30A2\u30EC",
  "id" : 141545354494611457,
  "in_reply_to_status_id" : 141545045462487041,
  "created_at" : "2011-11-29 15:53:36 +0000",
  "in_reply_to_screen_name" : "otsuotsu",
  "in_reply_to_user_id_str" : "53934373",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 3, 10 ],
      "id_str" : "443191476",
      "id" : 443191476
    }, {
      "name" : "Yuki USHIBA",
      "screen_name" : "cowplace",
      "indices" : [ 26, 35 ],
      "id_str" : "76871547",
      "id" : 76871547
    }, {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 51, 58 ],
      "id_str" : "443191476",
      "id" : 443191476
    }, {
      "name" : "Yuki USHIBA",
      "screen_name" : "cowplace",
      "indices" : [ 72, 81 ],
      "id_str" : "76871547",
      "id" : 76871547
    }, {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 99, 106 ],
      "id_str" : "443191476",
      "id" : 443191476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141535362345480192",
  "text" : "RT @ac_key: \u3084\u2026\u30E4\u30B4\u3060\u3088\u305D\u308C\u306F\u2026 RT @cowplace: \u30C8\u30F3\u30DC\u306B\u306A\u308B\u524D\u306E\u2026\u2026 RT @ac_key: \u30A8\u30B3\u3060\u3088\u305D\u308C\u306F\uFF01 RT @cowplace: \u74B0\u5883\u3068\u304B\u306B\u6C17\u3092\u4F7F\u3046\u3053\u3068\uFF1F RT @ac_key: \u30A8\u30B4\u3060\u3088\u305D\u308C\u306F\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yuki USHIBA",
        "screen_name" : "cowplace",
        "indices" : [ 14, 23 ],
        "id_str" : "76871547",
        "id" : 76871547
      }, {
        "name" : "Atsuki Nagao",
        "screen_name" : "ac_key",
        "indices" : [ 39, 46 ],
        "id_str" : "443191476",
        "id" : 443191476
      }, {
        "name" : "Yuki USHIBA",
        "screen_name" : "cowplace",
        "indices" : [ 60, 69 ],
        "id_str" : "76871547",
        "id" : 76871547
      }, {
        "name" : "Atsuki Nagao",
        "screen_name" : "ac_key",
        "indices" : [ 87, 94 ],
        "id_str" : "443191476",
        "id" : 443191476
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141533941931851776",
    "text" : "\u3084\u2026\u30E4\u30B4\u3060\u3088\u305D\u308C\u306F\u2026 RT @cowplace: \u30C8\u30F3\u30DC\u306B\u306A\u308B\u524D\u306E\u2026\u2026 RT @ac_key: \u30A8\u30B3\u3060\u3088\u305D\u308C\u306F\uFF01 RT @cowplace: \u74B0\u5883\u3068\u304B\u306B\u6C17\u3092\u4F7F\u3046\u3053\u3068\uFF1F RT @ac_key: \u30A8\u30B4\u3060\u3088\u305D\u308C\u306F\uFF01",
    "id" : 141533941931851776,
    "created_at" : "2011-11-29 15:08:15 +0000",
    "user" : {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "protected" : false,
      "id_str" : "106036912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600553053863817216\/2TsFpIn8_normal.png",
      "id" : 106036912,
      "verified" : false
    }
  },
  "id" : 141535362345480192,
  "created_at" : "2011-11-29 15:13:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141535323304886272",
  "text" : "\u30AD\u30E3\u30E9\u3058\u3083\u306A\u3044\u3057\u306A",
  "id" : 141535323304886272,
  "created_at" : "2011-11-29 15:13:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6B21\u306E\u65E5\u8D77\u304D\u3066\u307F\u3066\u96A3\u306B\u30A2\u30A4\u30B3\u30F3\u306E\u30AD\u30E3\u30E9\u304C\u5BDD\u3066\u3044\u305F\u3089\u3069\u3046\u3057\u307E\u3059",
      "indices" : [ 15, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141535267197681664",
  "text" : "\u98F2\u307F\u8FBC\u307E\u308C\u3066\u629C\u3051\u51FA\u305B\u306A\u304F\u306A\u308B #\u6B21\u306E\u65E5\u8D77\u304D\u3066\u307F\u3066\u96A3\u306B\u30A2\u30A4\u30B3\u30F3\u306E\u30AD\u30E3\u30E9\u304C\u5BDD\u3066\u3044\u305F\u3089\u3069\u3046\u3057\u307E\u3059",
  "id" : 141535267197681664,
  "created_at" : "2011-11-29 15:13:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141525751123030018",
  "text" : "\u8FD1\u304F\u306B\u4F4F\u3093\u3067\u308B\u5148\u8F29\u304B\u3089\uFF34\uFF45\uFF58\u306E\u53C2\u8003\u66F8\u501F\u308A\u3066\u304D\u305F\u3002\u306A\u3093\u3068\u304B\u3084\u3063\u3066\u307F\u3088\u3046\u3067\u306F\u306A\u3044\u304B\u3002",
  "id" : 141525751123030018,
  "created_at" : "2011-11-29 14:35:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141520938339540992",
  "geo" : { },
  "id_str" : "141521227113172992",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4F55\u306E\u9762\u63A5\u306A\u3093\u3067\u3059\uFF1F",
  "id" : 141521227113172992,
  "in_reply_to_status_id" : 141520938339540992,
  "created_at" : "2011-11-29 14:17:44 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141519419271688193",
  "geo" : { },
  "id_str" : "141519654530203649",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u540C\u5B66\u90E8\u306E\u540C\u7D1A\u751F\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 141519654530203649,
  "in_reply_to_status_id" : 141519419271688193,
  "created_at" : "2011-11-29 14:11:29 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u79C1\u304C\u53CD\u5FDC\u3057\u305D\u3046\u306A\u5358\u8A9E\u3092\u6319\u3052\u3066\u307F\u308D\u3088\u304F\u3060\u3055\u3044",
      "indices" : [ 0, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141518479877619713",
  "text" : "#\u79C1\u304C\u53CD\u5FDC\u3057\u305D\u3046\u306A\u5358\u8A9E\u3092\u6319\u3052\u3066\u307F\u308D\u3088\u304F\u3060\u3055\u3044",
  "id" : 141518479877619713,
  "created_at" : "2011-11-29 14:06:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141518062372397056",
  "text" : "\u4E45\u3005\u306B\u4F1A\u3063\u305F\u5148\u8F29\u306B\u8FB2\u5B66\u90E8\u3060\u3068\u601D\u308F\u308C\u3066\u3044\u305F\u3002\u6587\u7CFB\u3058\u3083\u306A\u3044\u3093\u3060\u306A\u2026\u3084\u3063\u3071\u308A\u3002",
  "id" : 141518062372397056,
  "created_at" : "2011-11-29 14:05:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141500934122508288",
  "text" : "\u3072\u3067\u3047",
  "id" : 141500934122508288,
  "created_at" : "2011-11-29 12:57:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141488450284158976",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 141488450284158976,
  "created_at" : "2011-11-29 12:07:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I",
      "screen_name" : "mearythindong",
      "indices" : [ 3, 17 ],
      "id_str" : "115541150",
      "id" : 115541150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141408401493200896",
  "text" : "RT @mearythindong: \u3010\u62E1\u6563\u5E0C\u671B\u3011\u4EAC\u90FD\u5927\u5B66\u6587\u5B66\u90E8\u5728\u7C4D\u30FB\u51FA\u8EAB\u306E\u4EBA\u3044\u305F\u3089\u30EA\u30D7\u304F\u3060\u3055\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141407168040677377",
    "text" : "\u3010\u62E1\u6563\u5E0C\u671B\u3011\u4EAC\u90FD\u5927\u5B66\u6587\u5B66\u90E8\u5728\u7C4D\u30FB\u51FA\u8EAB\u306E\u4EBA\u3044\u305F\u3089\u30EA\u30D7\u304F\u3060\u3055\u3044",
    "id" : 141407168040677377,
    "created_at" : "2011-11-29 06:44:30 +0000",
    "user" : {
      "name" : "I",
      "screen_name" : "mearythindong",
      "protected" : false,
      "id_str" : "115541150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426616176223866881\/nHcn70pu_normal.jpeg",
      "id" : 115541150,
      "verified" : false
    }
  },
  "id" : 141408401493200896,
  "created_at" : "2011-11-29 06:49:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I",
      "screen_name" : "mearythindong",
      "indices" : [ 0, 14 ],
      "id_str" : "115541150",
      "id" : 115541150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141407168040677377",
  "geo" : { },
  "id_str" : "141408365988413440",
  "in_reply_to_user_id" : 115541150,
  "text" : "@mearythindong \u30CE",
  "id" : 141408365988413440,
  "in_reply_to_status_id" : 141407168040677377,
  "created_at" : "2011-11-29 06:49:16 +0000",
  "in_reply_to_screen_name" : "mearythindong",
  "in_reply_to_user_id_str" : "115541150",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u306C\u3053",
      "screen_name" : "HiroboTanuko",
      "indices" : [ 3, 16 ],
      "id_str" : "318849037",
      "id" : 318849037
    }, {
      "name" : "\u79D1\u5B66\u306B\u4F47\u3080\u4E00\u884C\u8AAD\u66F8\u5FC3",
      "screen_name" : "endBooks",
      "indices" : [ 36, 45 ],
      "id_str" : "160921673",
      "id" : 160921673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141401946316734464",
  "text" : "RT @HiroboTanuko: \u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u8CDE\u3068\u308C\u305D\u3046\u306A\u7814\u7A76 RT @endBooks: \u201D\u30B8\u30E5\u30A6\u30B7\u30DE\u30C4\u3092\u30D8\u30EA\u30A6\u30E0\u7A7A\u6C17\u306E\u4E2D\u3067\u3046\u305F\u308F\u305B\u3066\u307F\u308B\u3068\u3001\u30B8\u30E5\u30A6\u30B7\u30DE\u30C4\u81EA\u8EAB\u3082\u5909\u306A\u58F0\u306B\u306A\u3063\u305F\u3068\u601D\u3063\u305F\u3088\u3046\u3067\u3001\u9996\u3092\u50BE\u3052\u305F\u308A\u3001\u9014\u4E2D\u3067\u6B4C\u3092\u6B62\u3081\u305F\u308A\u3057\u3066\u3057\u307E\u3046\u3002\u201D\u300E\u3055\u3048\u305A\u308A\u8A00\u8A9E\u8D77\u6E90\u8AD6 \u65B0\u7248 \u5C0F\u9CE5 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u79D1\u5B66\u306B\u4F47\u3080\u4E00\u884C\u8AAD\u66F8\u5FC3",
        "screen_name" : "endBooks",
        "indices" : [ 18, 27 ],
        "id_str" : "160921673",
        "id" : 160921673
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141397890894540800",
    "text" : "\u30A4\u30B0\u30CE\u30FC\u30D9\u30EB\u8CDE\u3068\u308C\u305D\u3046\u306A\u7814\u7A76 RT @endBooks: \u201D\u30B8\u30E5\u30A6\u30B7\u30DE\u30C4\u3092\u30D8\u30EA\u30A6\u30E0\u7A7A\u6C17\u306E\u4E2D\u3067\u3046\u305F\u308F\u305B\u3066\u307F\u308B\u3068\u3001\u30B8\u30E5\u30A6\u30B7\u30DE\u30C4\u81EA\u8EAB\u3082\u5909\u306A\u58F0\u306B\u306A\u3063\u305F\u3068\u601D\u3063\u305F\u3088\u3046\u3067\u3001\u9996\u3092\u50BE\u3052\u305F\u308A\u3001\u9014\u4E2D\u3067\u6B4C\u3092\u6B62\u3081\u305F\u308A\u3057\u3066\u3057\u307E\u3046\u3002\u201D\u300E\u3055\u3048\u305A\u308A\u8A00\u8A9E\u8D77\u6E90\u8AD6 \u65B0\u7248 \u5C0F\u9CE5\u306E\u6B4C\u304B\u3089\u30D2\u30C8\u306E\u8A00\u8449\u3078\u300F\u5CA1\u30CE\u8C37\u4E00\u592B",
    "id" : 141397890894540800,
    "created_at" : "2011-11-29 06:07:38 +0000",
    "user" : {
      "name" : "\u305F\u306C\u3053",
      "screen_name" : "HiroboTanuko",
      "protected" : false,
      "id_str" : "318849037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2164141324\/DSC_0007_3_normal.jpg",
      "id" : 318849037,
      "verified" : false
    }
  },
  "id" : 141401946316734464,
  "created_at" : "2011-11-29 06:23:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141386969044369408",
  "text" : "\u3075\u3075\u3075",
  "id" : 141386969044369408,
  "created_at" : "2011-11-29 05:24:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141386836776980480",
  "text" : "@\u30B5\u30FC\u30AF\u30EB\u5404\u4F4D \u4ECA\u65E5\u306F\uFF15\u9650\u306E\u6642\u9593\u6417\u3044\u3066\u4E00\u65E6\u3044\u306A\u304F\u306A\u308A\u300120\u6642\u524D\u5F8C\u306B\u307E\u305F\u73FE\u308C\u308B\u4E88\u5B9A\u3067\u3059\u3002",
  "id" : 141386836776980480,
  "created_at" : "2011-11-29 05:23:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141386356323663873",
  "text" : "\u4E00\u5F0F\u306E\u304C\u7F8E\u3057\u3044\u3088\u306D",
  "id" : 141386356323663873,
  "created_at" : "2011-11-29 05:21:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3046\u63D0\u7763\u517CP",
      "screen_name" : "ef_Alato",
      "indices" : [ 3, 12 ],
      "id_str" : "109805549",
      "id" : 109805549
    }, {
      "name" : "\u5B66\u751F\u56E3\u4F534U",
      "screen_name" : "4u_twit",
      "indices" : [ 79, 87 ],
      "id_str" : "279704582",
      "id" : 279704582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2lJEmZ44",
      "expanded_url" : "http:\/\/a1.sphotos.ak.fbcdn.net\/hphotos-ak-snc7\/383699_246818298711670_160316957361805_698213_717151035_n.jpg",
      "display_url" : "a1.sphotos.ak.fbcdn.net\/hphotos-ak-snc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "141386200412983298",
  "text" : "RT @ef_Alato: \u5B9F\u969B\u306B\u6570\u5B66\u79D1\u306E\u7537\u304C\u3053\u308C\u3092\u6570\u5B66\u79D1\u306E\u5973\u306B\u5F0F\u3060\u3051\u66F8\u3044\u3066\u9001\u3063\u305F\u3068\u3044\u3046\u8A71\u3092\u77E5\u3063\u3066\u307E\u3059\u3002\u5F7C\u5973\u306E\u8FD4\u4E8B\u306F(y=x,y=-x)\u3060\u3063\u305F\u305D\u3046\u3067\u3059 RT @4u_twit: \u7406\u7CFB\u3060\u3063\u305F\u3089\u3001\u3053\u3046\u3084\u3063\u3066\u60F3\u3044\u3092\u4F1D\u3048\u308B\u3053\u3068\u3082\u3067\u304D\u308B\u3093\u3067\u3059\u306D\uFF01\u3059\u3066\u304D\uFF01\uFF3B\u4E00\u6A4B \u8352\u5DDD\uFF3D RT htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5B66\u751F\u56E3\u4F534U",
        "screen_name" : "4u_twit",
        "indices" : [ 65, 73 ],
        "id_str" : "279704582",
        "id" : 279704582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/2lJEmZ44",
        "expanded_url" : "http:\/\/a1.sphotos.ak.fbcdn.net\/hphotos-ak-snc7\/383699_246818298711670_160316957361805_698213_717151035_n.jpg",
        "display_url" : "a1.sphotos.ak.fbcdn.net\/hphotos-ak-snc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "141102090306064385",
    "text" : "\u5B9F\u969B\u306B\u6570\u5B66\u79D1\u306E\u7537\u304C\u3053\u308C\u3092\u6570\u5B66\u79D1\u306E\u5973\u306B\u5F0F\u3060\u3051\u66F8\u3044\u3066\u9001\u3063\u305F\u3068\u3044\u3046\u8A71\u3092\u77E5\u3063\u3066\u307E\u3059\u3002\u5F7C\u5973\u306E\u8FD4\u4E8B\u306F(y=x,y=-x)\u3060\u3063\u305F\u305D\u3046\u3067\u3059 RT @4u_twit: \u7406\u7CFB\u3060\u3063\u305F\u3089\u3001\u3053\u3046\u3084\u3063\u3066\u60F3\u3044\u3092\u4F1D\u3048\u308B\u3053\u3068\u3082\u3067\u304D\u308B\u3093\u3067\u3059\u306D\uFF01\u3059\u3066\u304D\uFF01\uFF3B\u4E00\u6A4B \u8352\u5DDD\uFF3D RT http:\/\/t.co\/2lJEmZ44",
    "id" : 141102090306064385,
    "created_at" : "2011-11-28 10:32:14 +0000",
    "user" : {
      "name" : "\u3053\u3046\u63D0\u7763\u517CP",
      "screen_name" : "ef_Alato",
      "protected" : false,
      "id_str" : "109805549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566648177269288960\/aJoMjdH2_normal.jpeg",
      "id" : 109805549,
      "verified" : false
    }
  },
  "id" : 141386200412983298,
  "created_at" : "2011-11-29 05:21:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141385840365551616",
  "text" : "\u53CB\u4EBA\u306E\u53CB\u4EBA\u3068\u558B\u3063\u3066\u305F\u3089\u5B9F\u306F\u540C\u3058\u30AF\u30E9\u30B9\u3060\u3063\u305F\u3053\u3068\u304C\u9014\u4E2D\u3067\u89E3\u3063\u3066\u30A2\u30EC\u3060\u3063\u305F",
  "id" : 141385840365551616,
  "created_at" : "2011-11-29 05:19:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141385406066343937",
  "text" : "\u6388\u696D\u7D42\u308F\u308B\u306E\u65E9\u3059\u304E\u2026",
  "id" : 141385406066343937,
  "created_at" : "2011-11-29 05:18:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsushi SUGAWARA",
      "screen_name" : "peanutsjamjam",
      "indices" : [ 3, 17 ],
      "id_str" : "12617692",
      "id" : 12617692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141385275766091776",
  "text" : "RT @peanutsjamjam: \u5F8C\u8F29\u306E\u5973\u5B50\u3068\u8A71\u3057\u3066\u305F\u3089\u540C\u7D1A\u751F\u5973\u5B50\u304C\u6905\u5B50\u3092\u8E74\u3063\u98DB\u3070\u3057\u3066\u6765\u3066\u300C\u3053\u306E\u72B6\u6CC1\u3001\u6570\u5B66\u30AC\u30FC\u30EB\u306B\u51FA\u3066\u305F\uFF01\u300D\u3068\u304B\u8A00\u3063\u3066\u307F\u305F\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141364406016688128",
    "text" : "\u5F8C\u8F29\u306E\u5973\u5B50\u3068\u8A71\u3057\u3066\u305F\u3089\u540C\u7D1A\u751F\u5973\u5B50\u304C\u6905\u5B50\u3092\u8E74\u3063\u98DB\u3070\u3057\u3066\u6765\u3066\u300C\u3053\u306E\u72B6\u6CC1\u3001\u6570\u5B66\u30AC\u30FC\u30EB\u306B\u51FA\u3066\u305F\uFF01\u300D\u3068\u304B\u8A00\u3063\u3066\u307F\u305F\u3044\u3002",
    "id" : 141364406016688128,
    "created_at" : "2011-11-29 03:54:35 +0000",
    "user" : {
      "name" : "Atsushi SUGAWARA",
      "screen_name" : "peanutsjamjam",
      "protected" : false,
      "id_str" : "12617692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57650657\/jam_normal.gif",
      "id" : 12617692,
      "verified" : false
    }
  },
  "id" : 141385275766091776,
  "created_at" : "2011-11-29 05:17:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141347084510048257",
  "text" : "\u3088\u3057\u4E8C\u9650\u9593\u306B\u5408\u3063\u305F(\u8FEB\u771F",
  "id" : 141347084510048257,
  "created_at" : "2011-11-29 02:45:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "indices" : [ 0, 8 ],
      "id_str" : "20522410",
      "id" : 20522410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141340832249806848",
  "geo" : { },
  "id_str" : "141341456483876865",
  "in_reply_to_user_id" : 20522410,
  "text" : "@halhorn \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 141341456483876865,
  "in_reply_to_status_id" : 141340832249806848,
  "created_at" : "2011-11-29 02:23:23 +0000",
  "in_reply_to_screen_name" : "halhorn",
  "in_reply_to_user_id_str" : "20522410",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141321773147889665",
  "text" : "\u305F\u3060\u677E\u5C4B\u3084\uFF32\uFF33\u306B\u6BD4\u3079\u3066\u30EA\u30F3\u30B4\u30B8\u30E5\u30FC\u30B9\u306F\u98F2\u3080\u6A5F\u4F1A\u304C\u5C11\u306A\u3044\u306A\u30FC",
  "id" : 141321773147889665,
  "created_at" : "2011-11-29 01:05:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141321599646302208",
  "text" : "\u5727\u5012\u7684\u2026\u5F71\u97FF\u529B\u2026\uFF01",
  "id" : 141321599646302208,
  "created_at" : "2011-11-29 01:04:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141321473716518912",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u30CA\u30A4\u30B9\u30A2\u30C3\u30D7\u30EB\uFF01",
  "id" : 141321473716518912,
  "created_at" : "2011-11-29 01:03:59 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141320765457973248",
  "text" : "\uFF12\u9650\u306F\u3086\u3063\u305F\u308A\u884C\u3053\u3046\u304B",
  "id" : 141320765457973248,
  "created_at" : "2011-11-29 01:01:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141320673422344192",
  "text" : "\u6696\u304B\u3044\u3053\u305F\u3064\u3067\u51B7\u305F\u3044\u8C46\u4E73\u30E9\u30C6",
  "id" : 141320673422344192,
  "created_at" : "2011-11-29 01:00:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141320342114283520",
  "text" : "\uFF15\u9650\u4F11\u8B1B\u6765\u305F\uFF01\u3053\u308C\u3067\u52DD\u3064\u308B",
  "id" : 141320342114283520,
  "created_at" : "2011-11-29 00:59:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u304F\u307B\u304F\u3068",
      "screen_name" : "hokuhokuto",
      "indices" : [ 0, 11 ],
      "id_str" : "176634531",
      "id" : 176634531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141317051301105665",
  "geo" : { },
  "id_str" : "141317490843201536",
  "in_reply_to_user_id" : 176634531,
  "text" : "@hokuhokuto \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 141317490843201536,
  "in_reply_to_status_id" : 141317051301105665,
  "created_at" : "2011-11-29 00:48:10 +0000",
  "in_reply_to_screen_name" : "hokuhokuto",
  "in_reply_to_user_id_str" : "176634531",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141316815593807872",
  "text" : "\u671D\u3054\u98EFmogmog",
  "id" : 141316815593807872,
  "created_at" : "2011-11-29 00:45:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141311241313456129",
  "geo" : { },
  "id_str" : "141311463980679169",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 141311463980679169,
  "in_reply_to_status_id" : 141311241313456129,
  "created_at" : "2011-11-29 00:24:13 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141311405751156736",
  "text" : "\u3048\u3001\u5E73\u5747\u3042\u3052\u308B\u5074\u3060\u3068\u306F\u601D\u308F\u306A\u3093\u3060",
  "id" : 141311405751156736,
  "created_at" : "2011-11-29 00:23:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u514D\u8A31\u3092\u7DDA\u8DEF\u306B\u6295\u3052\u6368\u3066\u308D",
      "screen_name" : "FucKMooT",
      "indices" : [ 3, 12 ],
      "id_str" : "221953150",
      "id" : 221953150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141311299387793410",
  "text" : "RT @fuckmoot: \u96FB\u8ECA\u306E\u540A\u308A\u9769\u306E\u8A18\u4E8B\u306B\u30C4\u30A4\u30C3\u30BF\u30FC\u306E\u5E73\u5747\u30D5\u30A9\u30ED\u30EF\u30FC\u6570\u306F88\u4EBA\u3068\u304B\u3042\u3063\u3066\u4F55\u3044\u3063\u3066\u3093\u306E\u30B3\u30A4\u30C4\u3063\u3066\u601D\u3063\u3066\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/azurea.info\/\" rel=\"nofollow\"\u003EAzurea\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141308554987577344",
    "text" : "\u96FB\u8ECA\u306E\u540A\u308A\u9769\u306E\u8A18\u4E8B\u306B\u30C4\u30A4\u30C3\u30BF\u30FC\u306E\u5E73\u5747\u30D5\u30A9\u30ED\u30EF\u30FC\u6570\u306F88\u4EBA\u3068\u304B\u3042\u3063\u3066\u4F55\u3044\u3063\u3066\u3093\u306E\u30B3\u30A4\u30C4\u3063\u3066\u601D\u3063\u3066\u308B",
    "id" : 141308554987577344,
    "created_at" : "2011-11-29 00:12:39 +0000",
    "user" : {
      "name" : "\u514D\u8A31\u3092\u7DDA\u8DEF\u306B\u6295\u3052\u6368\u3066\u308D",
      "screen_name" : "FucKMooT",
      "protected" : false,
      "id_str" : "221953150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489023886172766208\/6zuWja6l_normal.jpeg",
      "id" : 221953150,
      "verified" : false
    }
  },
  "id" : 141311299387793410,
  "created_at" : "2011-11-29 00:23:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141310181274419201",
  "text" : "\u671D\u3054\u98EF\u98DF\u3079\u308B\u305F\u3081\u306B\u671D\u3054\u98EF\u3064\u304F\u308B\u305F\u3081\u306B\u5E03\u56E3\u304B\u3089\u3067\u306A\u304D\u3083\u2026",
  "id" : 141310181274419201,
  "created_at" : "2011-11-29 00:19:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141309022203678722",
  "text" : "\u8DDD\u96E2\u611F\u304B",
  "id" : 141309022203678722,
  "created_at" : "2011-11-29 00:14:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141306693937147904",
  "text" : "\u3093\u3067\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 141306693937147904,
  "created_at" : "2011-11-29 00:05:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3068\u308A",
      "screen_name" : "kotori_y",
      "indices" : [ 1, 10 ],
      "id_str" : "2318415266",
      "id" : 2318415266
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 11, 23 ],
      "id_str" : "229754624",
      "id" : 229754624
    }, {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 34, 42 ],
      "id_str" : "112886536",
      "id" : 112886536
    }, {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 43, 53 ],
      "id_str" : "158645894",
      "id" : 158645894
    }, {
      "name" : "\u3061\u3047\u308A\u30FC",
      "screen_name" : "che_rrrry",
      "indices" : [ 54, 64 ],
      "id_str" : "2859162751",
      "id" : 2859162751
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 65, 76 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141306638375202817",
  "text" : ".@kotori_y @nisehorrrrn @ispamgis @maucha_ @eclair_15 @che_rrrry @magokoro84 \u304A\u3084\u3042\u308A\u3067\u3057\u305F\u30FC",
  "id" : 141306638375202817,
  "created_at" : "2011-11-29 00:05:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141175793635180545",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 141175793635180545,
  "created_at" : "2011-11-28 15:25:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141170491212832768",
  "text" : "\u3068\u666E\u901A\u306B\u3057\u304B\u30D7\u30EC\u30A4\u3057\u305F\u3053\u3068\u306A\u3044\u4EBA\u304C\u8A00\u3063\u3066\u307E\u3059",
  "id" : 141170491212832768,
  "created_at" : "2011-11-28 15:04:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141170339584548864",
  "text" : "\u30DD\u30B1\u30E2\u30F3\u3068\u304B\u4E71\u6570\u4F7F\u3046\u524D\u63D0\u306A\u3089200\u6642\u9593\u3067\u5EC3\u4EBA\u8A8D\u5B9A\u3055\u308C\u305D\u3046\u3060\u3051\u3069\u3001\u7D20\u76F4\u306B\u53B3\u9078\u3057\u305F\u3089200\u3068\u304B\u3059\u3050\u306A\u3093\u3058\u3083\u306A\u3044\u306E",
  "id" : 141170339584548864,
  "created_at" : "2011-11-28 15:03:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141160055889346560",
  "text" : "\u3067\u3082isibasi\u3092\u53F3\u304B\u3089isabisi\u3063\u3066\u8AAD\u3093\u3067\u300C\u3044\u3055\u3073\u3057\u300D\u3063\u3066\u643A\u5E2F\u3067\u5165\u308C\u3066\u30ED\u30FC\u30DE\u5B57\u5909\u63DB\u3059\u308B\u3068\u300Cend.\u300D\u3063\u3066\u51FA\u308B\u3093\u3060\u3088\u3002\n\u3042\u3001\u3053\u308C\u8AB0\u5F97",
  "id" : 141160055889346560,
  "created_at" : "2011-11-28 14:22:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141159686350192640",
  "text" : "\u3046\u305A\u3046\u305A\u3063\u3066\u3044\u3046\u3068\u5C45\u3066\u3082\u7ACB\u3063\u3066\u3082\u5C45\u3089\u308C\u306A\u3044\u611F\u3058\u3060\u3051\u3069\u6E26\u6E26\u3063\u3066\u8A00\u3046\u3068\u3080\u3063\u3061\u3083\u9589\u585E\u611F",
  "id" : 141159686350192640,
  "created_at" : "2011-11-28 14:21:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141159549221609472",
  "text" : "\u540D\u524D\u3088\u308A\u6E26\u3046\u305A\u306E\u30D5\u30E9\u30AF\u30BF\u30EB\u30B5\u30E0\u30CD\u30A4\u30EB\u306E\u65B9\u304C\u5370\u8C61\u7684\u307F\u305F\u3044\u3060\u3057\u306A\u30FC",
  "id" : 141159549221609472,
  "created_at" : "2011-11-28 14:20:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141159420993355778",
  "text" : "\u3048\u3093\u3069\u3063\u3066\u547C\u3073\u306B\u304F\u3044\u306E\u304B\u306A\u30FC\u3001\u672C\u540D\u96A0\u3057\u3066\u306A\u3044\u304B\u3089\u304B\u672C\u540D\u3067\u547C\u3070\u308C\u308B\u3053\u3068\u3082\u3042\u308B\u3093\u3060\u3051\u308C\u3069\u3002",
  "id" : 141159420993355778,
  "created_at" : "2011-11-28 14:20:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141159201878704128",
  "text" : "\u305F\u3060\u3067\u3055\u3048\u30C4\u30A4\u30FC\u30C8\u6570\u304C\u5C11\u306A\u3044\u304B\u3089bio\u3092\u898B\u3066\u3082\u3089\u3046\u4E8B\u306B\u306A\u308B\u3093\u3060\u304B\u3089\u8272\u3005\u66F8\u304B\u306A\u304D\u3083\u3068\u304B\u601D\u3063\u3066\u3057\u307E\u3046\u3002",
  "id" : 141159201878704128,
  "created_at" : "2011-11-28 14:19:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141159010412920833",
  "text" : "\u3061\u3087\u3063\u3068\u3060\u3051bio\u66F4\u65B0\u3057\u307E\u3057\u305F\u3002160\u5B57\u3063\u3066\u77ED\u3044\u3088\u306D\u3002",
  "id" : 141159010412920833,
  "created_at" : "2011-11-28 14:18:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141157570705489920",
  "text" : "\uFF2E\uFF26\u306720\u4EBA\u307B\u3069\u30D5\u30A9\u30ED\u30FC\u3092\u5897\u3084\u3057\u305F\u3060\u3051\u306A\u306E\u306B\uFF34\uFF2C\u306E\u6D41\u901F\u304C\u500D\u304F\u3089\u3044\u306B\u306A\u3063\u3066\u308B\u3002",
  "id" : 141157570705489920,
  "created_at" : "2011-11-28 14:12:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141131616473972736",
  "text" : "@gnawty49 \u751F\u5354\u3067\u3067\u3082\u898B\u3066\u307F\u307E\u3059\u3002\u30B5\u30F3\u30AD\u30E5\u3067\u3059\u3002",
  "id" : 141131616473972736,
  "created_at" : "2011-11-28 12:29:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 0, 16 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141127977919455233",
  "geo" : { },
  "id_str" : "141131546202603520",
  "in_reply_to_user_id" : 230918258,
  "text" : "@takasan_san_san \u3069\u3063\u304B\u3067\u610F\u5730\u306B\u306A\u3089\u306A\u304D\u3083\u3060\u3088\u306D\u30FC\u3002\u3044\u3084\u3001\u4EE3\u6570\u306E\u30CE\u30FC\u30C8\u3092\u5168\u90E8\uFF34\uFF45\uFF58\u3067\u66F8\u304D\u76F4\u3057\u305F\u3089\u52C9\u5F37\u306B\u306A\u308B\u3093\u3058\u3083\u306A\u3044\u304B\u3068\u601D\u3063\u305F\u308A\u79D1\u54F2\u95A2\u9023\u3067\u3082\u6570\u5F0F\u4F7F\u3063\u305F\u30EC\u30DD\u30FC\u30C8\u3042\u308B\u304B\u3089\u899A\u3048\u3066\u304A\u3053\u3046\u304B\u306A\u3068",
  "id" : 141131546202603520,
  "in_reply_to_status_id" : 141127977919455233,
  "created_at" : "2011-11-28 12:29:17 +0000",
  "in_reply_to_screen_name" : "takasan_san_san",
  "in_reply_to_user_id_str" : "230918258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141131124654088192",
  "text" : "\u732B\u3063\u3066\u6BB5\u968E\u3067\u7B54\u3048\u306F\u6C7A\u307E\u3063\u3066\u3044\u305F\u3002",
  "id" : 141131124654088192,
  "created_at" : "2011-11-28 12:27:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u67DA\u6728\u304B\u307B",
      "screen_name" : "kahoyuzuki",
      "indices" : [ 3, 14 ],
      "id_str" : "350279446",
      "id" : 350279446
    }, {
      "name" : "\u798F\u7530\u4E00\u884C",
      "screen_name" : "ikko",
      "indices" : [ 70, 75 ],
      "id_str" : "3811061",
      "id" : 3811061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/eNZJ6bLa",
      "expanded_url" : "http:\/\/yfrog.com\/gzprfumj",
      "display_url" : "yfrog.com\/gzprfumj"
    } ]
  },
  "geo" : { },
  "id_str" : "141131070560145409",
  "text" : "RT @kahoyuzuki: \u3053 \u306E \u30AA \u30B9 \u732B \u306B \u60DA \u308C \u305F \u3089 \u516C \u5F0F R T  http:\/\/t.co\/eNZJ6bLa via @ikko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u798F\u7530\u4E00\u884C",
        "screen_name" : "ikko",
        "indices" : [ 54, 59 ],
        "id_str" : "3811061",
        "id" : 3811061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/eNZJ6bLa",
        "expanded_url" : "http:\/\/yfrog.com\/gzprfumj",
        "display_url" : "yfrog.com\/gzprfumj"
      } ]
    },
    "geo" : { },
    "id_str" : "136563627611258880",
    "text" : "\u3053 \u306E \u30AA \u30B9 \u732B \u306B \u60DA \u308C \u305F \u3089 \u516C \u5F0F R T  http:\/\/t.co\/eNZJ6bLa via @ikko",
    "id" : 136563627611258880,
    "created_at" : "2011-11-15 21:58:00 +0000",
    "user" : {
      "name" : "\u67DA\u6728\u304B\u307B",
      "screen_name" : "kahoyuzuki",
      "protected" : false,
      "id_str" : "350279446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/594126171098349568\/gXoKLg-L_normal.jpg",
      "id" : 350279446,
      "verified" : false
    }
  },
  "id" : 141131070560145409,
  "created_at" : "2011-11-28 12:27:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141126317981700096",
  "text" : "\u5FC5\u8981\u6027\u3092\u611F\u3058\u3066\u3057\u307E\u3063\u305F\u3089\u3082\u3046\u52D5\u304F\u3057\u304B\u306A\u3044\u3088\u306A\u30FC",
  "id" : 141126317981700096,
  "created_at" : "2011-11-28 12:08:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141126151459446784",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u81EA\u5B66\u81EA\u7FD2\u51FA\u6765\u308B\u3060\u3051\u306E\u3068\u3053\u308D\u306B\u7ACB\u3066\u308C\u3070\u4F55\u3068\u304B\u306A\u308A\u305D\u3046\u306A\u3093\u3060\u3051\u3069\u306A\u30FC",
  "id" : 141126151459446784,
  "created_at" : "2011-11-28 12:07:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141125999965384704",
  "text" : "\u3010\u7DE9\u52DF\u3011\uFF08\uFF2C\uFF41\uFF09\uFF34\uFF45\uFF58\u306E\u5C0E\u5165\u304B\u3089\u57FA\u790E\u3092\u6559\u3048\u3066\u304F\u308C\u308B\u4EBA",
  "id" : 141125999965384704,
  "created_at" : "2011-11-28 12:07:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141125154481778688",
  "text" : "\u306B\u305B\u307B\u304B\u3068\u601D\u3044\u304D\u3084\u507D\u307B\u3060\u3063\u305F\u3001\u4F55\u3092\u8A00\u3063\u3066\u308B\u306E\u304B\u8A71\u304B\u3089\u306D\u3047\u3068\u601D\u3046\u304C\uFF08\uFF52\uFF59",
  "id" : 141125154481778688,
  "created_at" : "2011-11-28 12:03:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141123437497290753",
  "text" : "\u3042\u3001\u8B1B\u5E2B\u3068\u3057\u3066\u901A\u3063\u3066\u308B\u3001\u306D\uFF57",
  "id" : 141123437497290753,
  "created_at" : "2011-11-28 11:57:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141123354630426624",
  "text" : "\u53CB\u4EBA\u306E\u901A\u3063\u3066\u308B\u5927\u6D25\u306E\u587E\u3067\u305F\u3076\u3093\u3060\u3051\u3069\u4E2D\u5B66\u306E\u6570\u5B66\u3068\u56FD\u8A9E\u6559\u3048\u305F\u3044\u3063\u4EBA\u3044\u305F\u3089\u4EF2\u4ECB\u3057\u307E\u30FC\u3059\u3002\u4EBA\u624B\u4E0D\u8DB3\u3089\u3057\u3044\u306E\u3067\u3002\u9060\u3044\u3051\u3069\u30D0\u30A4\u30C8\u3057\u305F\u3044\u4EBA\u3044\u305F\u3089\u30EA\u30D7\u30E9\u30A4\u3067\u3082\u304F\u3060\u3055\u3044\u306A\u3002",
  "id" : 141123354630426624,
  "created_at" : "2011-11-28 11:56:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141119876482871296",
  "text" : "\u7D50\u5C40\u30D4\u30B6\u30BD\u30FC\u30B9\u304B\u3089\u4F5C\u3063\u3066\u30D4\u30B6\u30C8\u30FC\u30B9\u30C8\u306B\u306A\u308A\u307E\u3057\u305F\u30FC",
  "id" : 141119876482871296,
  "created_at" : "2011-11-28 11:42:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141104455897726976",
  "text" : "\u56F3\u66F8\u9928\u96E2\u8131\u3057\u3066\u30B9\u30FC\u30D1\u30FC\u5BC4\u3063\u3066\u5E30\u308D\u3046",
  "id" : 141104455897726976,
  "created_at" : "2011-11-28 10:41:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141104227341705216",
  "text" : "\u306A\u3093\u304B\u65E5\u672C\u8A9E\u304A\u304B\u3057\u3044",
  "id" : 141104227341705216,
  "created_at" : "2011-11-28 10:40:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141104121448108032",
  "text" : "\u3061\u304F\u308F\u3076\u306E\u77E5\u540D\u5EA6\u306E\u4F4E\u3055\u306B\u6CE3\u3044\u305F\u3002\u6750\u6599\u3092\u5C0F\u9EA6\u7C89\u306B\u5909\u3048\u305F\u3061\u304F\u308F\u3068\u540C\u3058\u5DE5\u7A0B\u3067\u4F5C\u3089\u308C\u308B\u7DF4\u308A\u7269\u306A\u3093\u3060\u304C",
  "id" : 141104121448108032,
  "created_at" : "2011-11-28 10:40:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141103509046177792",
  "text" : "Fresco\u304B",
  "id" : 141103509046177792,
  "created_at" : "2011-11-28 10:37:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141103451114438656",
  "text" : "\u5317\u767D\u5DDD\u306E\u30B9\u30FC\u30D1\u30FC\u3067\u58F2\u3063\u3066\u308B\u306E\u3092\u898B\u305F\u304C\u30B3\u30F3\u30D3\u30CB\u304A\u3067\u3093\u306B\u306F\u306A\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u306A\u3001\u3061\u304F\u308F\u3076",
  "id" : 141103451114438656,
  "created_at" : "2011-11-28 10:37:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141102851807117312",
  "text" : "\u305D\u3082\u305D\u3082\u3061\u304F\u308F\u3076\u77E5\u3089\u306A\u3044\u4EBA\u6CA2\u5C71\u3044\u3066\u3073\u3063\u304F\u308A\u3067\u3059 RT @superuncochan: \u95A2\u897F\u306E\u30B3\u30F3\u30D3\u30CB\u306B\u306F\u3061\u304F\u308F\u3076\u306A\u3044\u304B\u3089\u30AF\u30BD",
  "id" : 141102851807117312,
  "created_at" : "2011-11-28 10:35:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141102676028047360",
  "text" : "\u9078\u629E\u516C\u7406\u306E\u304A\u5144\u3055\u3093\u306E\u30A2\u30A4\u30B3\u30F3\u304C",
  "id" : 141102676028047360,
  "created_at" : "2011-11-28 10:34:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141102195583098881",
  "text" : "\uFF3B\u7DE9\u52DF\uFF3D\u98DF\u30D1\u30F3(\u30C8\u30FC\u30B9\u30C8\uFF09\u3068\u98DF\u3079\u308B\u3068\u7F8E\u5473\u3057\u3044\u3082\u306E",
  "id" : 141102195583098881,
  "created_at" : "2011-11-28 10:32:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141093880018898944",
  "text" : "@reflexio \u3075\u3075\u3075 \u672C\u6C17\u306A\u3089\u6C34\u66DC\u307E\u3067\u306B\u6559\u3048\u3066\u304F\u308C\uFF57",
  "id" : 141093880018898944,
  "created_at" : "2011-11-28 09:59:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141093355156283393",
  "text" : "@reflexio \u6728\u66DC\u306A\u3089\u306A\u3093\u3068\u304B\u306A\u3089\u306A\u304F\u3082\u306A\u3044\u304C",
  "id" : 141093355156283393,
  "created_at" : "2011-11-28 09:57:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141093211711082496",
  "text" : "\u5BB6\u306B\u98DF\u30D1\u30F3\u3042\u308B\u304B\u3089\u4F55\u304B\u8CB7\u3063\u3066\u5E30\u308D\u3046",
  "id" : 141093211711082496,
  "created_at" : "2011-11-28 09:56:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141093004193705985",
  "text" : "19\u6642\u307E\u3067\u30C4\u30A4\u30C3\u30BF\u30FC\u5F35\u308A\u4ED8\u3044\u3066\u304B\u3089\u6700\u5F8C\u306E\u554F\u984C\u3092\u5012\u3059",
  "id" : 141093004193705985,
  "created_at" : "2011-11-28 09:56:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141092862170378242",
  "text" : "@reflexio \u307E\u3060\u884C\u3051\u308B\u305C",
  "id" : 141092862170378242,
  "created_at" : "2011-11-28 09:55:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141092465640865792",
  "geo" : { },
  "id_str" : "141092776761769985",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u3042\u308B\u7A2E\u5B66\u554F\u306E\u918D\u9190\u5473\u3067\u3059\u3088\u306D\u30FC",
  "id" : 141092776761769985,
  "in_reply_to_status_id" : 141092465640865792,
  "created_at" : "2011-11-28 09:55:14 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141092628732198912",
  "text" : "\u8868\u73FE\u306B\u6C17\u3092\u3064\u3051\u306A\u3044\u3068\u2026\u67D0\u5927\u5148\u751F\u307F\u305F\u3044\u306A\u3053\u3068\u306B\u306A\u3063\u305F\u3089\u5927\u5909\u3060",
  "id" : 141092628732198912,
  "created_at" : "2011-11-28 09:54:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141092425421684736",
  "text" : "\u3042\u3001\u4E2D\u8EAB\u3058\u3083\u306A\u304F\u3066\u91CD\u306D\u5408\u308F\u305B\u4E91\u3005",
  "id" : 141092425421684736,
  "created_at" : "2011-11-28 09:53:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141092336431140864",
  "text" : "\u307E\u3041\u4EE3\u6570\u3068\u7DDA\u5F62\u306F\u524D\u304B\u3089\u89E3\u3063\u3066\u3044\u305F\u304C",
  "id" : 141092336431140864,
  "created_at" : "2011-11-28 09:53:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141092214934740994",
  "text" : "\u91CF\u5B50\u529B\u5B66\u306E\u8AB2\u984C\u3068\u7DDA\u5F62\u4EE3\u6570\u306E\u52C9\u5F37\u3068\u4EE3\u6570\u306E\u52C9\u5F37\u304C\u91CD\u306D\u5408\u308F\u305B\u306E\u72B6\u614B\u306B\u3042\u308B\u3053\u3068\u306B\u6C17\u4ED8\u3044\u305F",
  "id" : 141092214934740994,
  "created_at" : "2011-11-28 09:53:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141079080769564672",
  "text" : "20\u6642\u307E\u3067\u306F\u9811\u5F35\u308B",
  "id" : 141079080769564672,
  "created_at" : "2011-11-28 09:00:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141028791035244544",
  "text" : "\u6559\u79D1\u66F8\u5FD8\u308C\u305F\u304C",
  "id" : 141028791035244544,
  "created_at" : "2011-11-28 05:40:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141028649158709248",
  "text" : "\u4EE3\u6570",
  "id" : 141028649158709248,
  "created_at" : "2011-11-28 05:40:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/leiYcgBQ",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=wilhelm_S5",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "140988187446231040",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001wilhelm_S5\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/leiYcgBQ #gohantabeyo",
  "id" : 140988187446231040,
  "created_at" : "2011-11-28 02:59:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3087\u308D\u3053\u3002",
      "screen_name" : "luna_nd",
      "indices" : [ 3, 11 ],
      "id_str" : "108910807",
      "id" : 108910807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/9pyVDxqc",
      "expanded_url" : "http:\/\/j.mp\/uS212F",
      "display_url" : "j.mp\/uS212F"
    } ]
  },
  "geo" : { },
  "id_str" : "140984281710329856",
  "text" : "RT @luna_nd: \u6388\u696D\u3067\u4F7F\u3046\u3001Twitter\u306B\u3064\u3044\u3066\u306E\u7C21\u5358\u306A\u30A2\u30F3\u30B1\u30FC\u30C8\u3067\u3059\u3002\u3054\u5354\u529B\u304A\u9858\u3044\u3057\u307E\u3059\u3002    http:\/\/t.co\/9pyVDxqc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/9pyVDxqc",
        "expanded_url" : "http:\/\/j.mp\/uS212F",
        "display_url" : "j.mp\/uS212F"
      } ]
    },
    "geo" : { },
    "id_str" : "140980091491586048",
    "text" : "\u6388\u696D\u3067\u4F7F\u3046\u3001Twitter\u306B\u3064\u3044\u3066\u306E\u7C21\u5358\u306A\u30A2\u30F3\u30B1\u30FC\u30C8\u3067\u3059\u3002\u3054\u5354\u529B\u304A\u9858\u3044\u3057\u307E\u3059\u3002    http:\/\/t.co\/9pyVDxqc",
    "id" : 140980091491586048,
    "created_at" : "2011-11-28 02:27:27 +0000",
    "user" : {
      "name" : "\u306B\u3087\u308D\u3053\u3002",
      "screen_name" : "luna_nd",
      "protected" : false,
      "id_str" : "108910807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528219134660599809\/NPcJ0cGU_normal.jpeg",
      "id" : 108910807,
      "verified" : false
    }
  },
  "id" : 140984281710329856,
  "created_at" : "2011-11-28 02:44:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140976877740367872",
  "text" : "\u5E03\u56E3\u3067gdgd",
  "id" : 140976877740367872,
  "created_at" : "2011-11-28 02:14:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140974207780655105",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 140974207780655105,
  "created_at" : "2011-11-28 02:04:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 1, 10 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 11, 22 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140974153909010432",
  "text" : ".@nisehorn @magokoro84 @ispamgis \u304A\u3084\u3042\u308A\u3067\u3057\u305F",
  "id" : 140974153909010432,
  "created_at" : "2011-11-28 02:03:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140819177421283329",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 140819177421283329,
  "created_at" : "2011-11-27 15:48:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140819107237990400",
  "text" : "\u3042\u3089\u3001\u3082\u30461\u6642\u3067\u3059\u304B\u3002\u3061\u3087\u3063\u3068\u3077\u3088\u3077\u3088\u3084\u3063\u3066\u5BDD\u3088\u3046\u3002",
  "id" : 140819107237990400,
  "created_at" : "2011-11-27 15:47:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140818884096831488",
  "text" : "\u3069\u3046\u3082\u4E0A\u624B\u306B\u5BFE\u5FDC\u304C\u53D6\u308C\u306A\u3044\u306A\u30FC",
  "id" : 140818884096831488,
  "created_at" : "2011-11-27 15:46:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140818575148597248",
  "text" : "\u76F4\u524D\u306B\u3084\u308B\u304B\u3089\u304B\u30FC",
  "id" : 140818575148597248,
  "created_at" : "2011-11-27 15:45:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140818457108283392",
  "text" : "\u3069\u3046\u3057\u3066\u3053\u3046\u30EC\u30DD\u30FC\u30C8\u3063\u3066\u3084\u3063\u3064\u3051\u3063\u307D\u304F\u306A\u308B\u3093\u3060\u308D\u3046\uFF57",
  "id" : 140818457108283392,
  "created_at" : "2011-11-27 15:45:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140808053439209473",
  "text" : "@nartakio \u304A\u3064\u304B\u308C\u3055\u307E\u3067\u3057\u305F\u30FC",
  "id" : 140808053439209473,
  "created_at" : "2011-11-27 15:03:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140807121049632768",
  "text" : "\u9006\u306B\u95A2\u897F\u3067\u30C9\u30AF\u30BF\u30FC\u30DA\u30C3\u30D1\u30FC\u307F\u305F\u3053\u3068\u306A\u3044\u3093\u3060\u3088\u306A\u30FC",
  "id" : 140807121049632768,
  "created_at" : "2011-11-27 15:00:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140807046302941184",
  "text" : "\u3086",
  "id" : 140807046302941184,
  "created_at" : "2011-11-27 14:59:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140807011746070529",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u95A2\u6771\u3067\uFF32\uFF33\u898B\u305F\u3053\u3068\u306A\u3044\u304B\u3082",
  "id" : 140807011746070529,
  "created_at" : "2011-11-27 14:59:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "co1406364",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/avBlzKyE",
      "expanded_url" : "http:\/\/live.nicovideo.jp\/watch\/lv72430126",
      "display_url" : "live.nicovideo.jp\/watch\/lv724301\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "140806483007913986",
  "text" : "\u9CF4\u6EDD\u3055\u3093\u306E\u30CB\u30B3\u751F\u8996\u8074\u4E2D : \u653E\u90017 \u6700\u5F8C\u306E\u4E0D\u7B49\u5F0F\u8A55\u4FA1\u304A\u3082\u3057\u308D\u304B\u3063\u305F\uFF08\u5C0F\u5B66\u751F\u4E26\u307F\u306E\u611F\u60F3\uFF09 #co1406364 http:\/\/t.co\/avBlzKyE",
  "id" : 140806483007913986,
  "created_at" : "2011-11-27 14:57:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140805387124346882",
  "text" : "\u9CF4\u6EDD\u653E\u9001\u898B\u59CB\u3081\u3066\u307F\u305F\uFF57",
  "id" : 140805387124346882,
  "created_at" : "2011-11-27 14:53:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140801815674490881",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3088",
  "id" : 140801815674490881,
  "created_at" : "2011-11-27 14:39:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Sloan",
      "screen_name" : "ts572",
      "indices" : [ 0, 6 ],
      "id_str" : "956244972",
      "id" : 956244972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140801727954812929",
  "text" : "@ts572 \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u5927\u304D\u306A\u30C4\u30A4\u30F3\u30B7\u30E5\u30FC\uFF01",
  "id" : 140801727954812929,
  "created_at" : "2011-11-27 14:38:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140789756693983232",
  "text" : "\u3044\u3059\u53F3\u516D\u3063\u3066\u51FA\u305F\u3002\u9EBB\u96C0\u8F9E\u66F8\u30A7\u30FB\u30FB\u30FB",
  "id" : 140789756693983232,
  "created_at" : "2011-11-27 13:51:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140789652239036416",
  "text" : "\u3055\u3041\u4F4D\u6570\uFF16\u306E\u5206\u985E\u3092\u3084\u308D\u3046",
  "id" : 140789652239036416,
  "created_at" : "2011-11-27 13:50:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 1, 12 ],
      "id_str" : "229752118",
      "id" : 229752118
    }, {
      "name" : "\u304C\u3043",
      "screen_name" : "GAi9112",
      "indices" : [ 13, 21 ],
      "id_str" : "169436782",
      "id" : 169436782
    }, {
      "name" : "\u3084\u306F\u3066",
      "screen_name" : "yaoihayate",
      "indices" : [ 22, 33 ],
      "id_str" : "292948731",
      "id" : 292948731
    }, {
      "name" : "\u3061\u3047\u308A\u30FC",
      "screen_name" : "che_rrrry",
      "indices" : [ 34, 44 ],
      "id_str" : "2859162751",
      "id" : 2859162751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140787350916694016",
  "geo" : { },
  "id_str" : "140789121546321920",
  "in_reply_to_user_id" : 229752118,
  "text" : ".@nisehorrrn @GAi9112 @yaoihayate @che_rrrry \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u5927\u304D\u306A\u30C4\u30A4\u30F3\u30B7\u30E5\u30FC\uFF01",
  "id" : 140789121546321920,
  "in_reply_to_status_id" : 140787350916694016,
  "created_at" : "2011-11-27 13:48:36 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140788855161888768",
  "text" : "\u3069\u3053\u304B\u3067\u898B\u305F\u540D\u524D\u3060\u3068\u601D\u3048\u3070\u3084\u3063\u3071\u308A\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u3060\u3063\u305F",
  "id" : 140788855161888768,
  "created_at" : "2011-11-27 13:47:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140788772001419265",
  "text" : "\u4F4D\u6570\uFF11\uFF11\uFF19\u307E\u3067\u306E\u5206\u985E\u3057\u305F\uFF32\uFF45\uFF44Cat\u3055\u3093\u3063\u3066math_neko\u3055\u3093\u3060\u3063\u305F\u306E\u304B\u30FC\u3002",
  "id" : 140788772001419265,
  "created_at" : "2011-11-27 13:47:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140787894259421186",
  "text" : "@gnawty49 \u79C1\u3082\u30A2\u30EC\u3067\u3059\u304C\u6C17\u306B\u305B\u305A\u9811\u5F35\u308A\u307E\u3057\u3087\u3046\uFF57",
  "id" : 140787894259421186,
  "created_at" : "2011-11-27 13:43:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140787199070322690",
  "text" : "\u5927\u304D\u306A\u30C4\u30A4\u30F3\u30B7\u30E5\u30FC\u306A\u3046",
  "id" : 140787199070322690,
  "created_at" : "2011-11-27 13:40:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140786534218608641",
  "geo" : { },
  "id_str" : "140786698127806464",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro\u3000\u3055\u3059\u304C\u3060\uFF57\uFF57\uFF57",
  "id" : 140786698127806464,
  "in_reply_to_status_id" : 140786534218608641,
  "created_at" : "2011-11-27 13:38:59 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 0, 10 ],
      "id_str" : "158645894",
      "id" : 158645894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140783895779090433",
  "geo" : { },
  "id_str" : "140784057410785281",
  "in_reply_to_user_id" : 158645894,
  "text" : "@eclair_15 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 140784057410785281,
  "in_reply_to_status_id" : 140783895779090433,
  "created_at" : "2011-11-27 13:28:29 +0000",
  "in_reply_to_screen_name" : "eclair_15",
  "in_reply_to_user_id_str" : "158645894",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140777169994518528",
  "text" : "\u305D\u30FC\u306A\u306E\u304B\u30FC",
  "id" : 140777169994518528,
  "created_at" : "2011-11-27 13:01:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304C\u3043",
      "screen_name" : "GAi9112",
      "indices" : [ 0, 8 ],
      "id_str" : "169436782",
      "id" : 169436782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140771487228493825",
  "geo" : { },
  "id_str" : "140771866905280512",
  "in_reply_to_user_id" : 169436782,
  "text" : "@GAi9112 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF!",
  "id" : 140771866905280512,
  "in_reply_to_status_id" : 140771487228493825,
  "created_at" : "2011-11-27 12:40:03 +0000",
  "in_reply_to_screen_name" : "GAi9112",
  "in_reply_to_user_id_str" : "169436782",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Sloan",
      "screen_name" : "ts572",
      "indices" : [ 0, 6 ],
      "id_str" : "956244972",
      "id" : 956244972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140771000026529792",
  "text" : "@ts572 \u30CA\u30A4\u30B9\u3042\u304B\u3064\u304D\u30B9\u30DA\u30B7\u30E3\u30EB\uFF01",
  "id" : 140771000026529792,
  "created_at" : "2011-11-27 12:36:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140762990680080384",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 140762990680080384,
  "created_at" : "2011-11-27 12:04:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0418I\u042F I\u041D\u0186UO\u0418\u0410M\u0410Y",
      "screen_name" : "rinir7",
      "indices" : [ 3, 10 ],
      "id_str" : "53420311",
      "id" : 53420311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140759286128185344",
  "text" : "RT @rinir7: \u30AD\u30AD\u300C\u79C1\u3001\u9B54\u5973\u306E\u30AD\u30AD\u3067\u3059\uFF01\u3053\u3063\u3061\u306F\u30AF\u30ED\u30CD\u30C3\u30AB\u30FC\u306E\u30C7\u30EB\u30BF\uFF01\u300D\n\n\u03B4(x-a)\u300C\u306B\u3083\u3042\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139909423287107586",
    "text" : "\u30AD\u30AD\u300C\u79C1\u3001\u9B54\u5973\u306E\u30AD\u30AD\u3067\u3059\uFF01\u3053\u3063\u3061\u306F\u30AF\u30ED\u30CD\u30C3\u30AB\u30FC\u306E\u30C7\u30EB\u30BF\uFF01\u300D\n\n\u03B4(x-a)\u300C\u306B\u3083\u3042\u300D",
    "id" : 139909423287107586,
    "created_at" : "2011-11-25 03:33:00 +0000",
    "user" : {
      "name" : "\u0418I\u042F I\u041D\u0186UO\u0418\u0410M\u0410Y",
      "screen_name" : "rinir7",
      "protected" : false,
      "id_str" : "53420311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1405863731\/68f11bef-b1a2-4e04-a51e-774757f63343_normal.png",
      "id" : 53420311,
      "verified" : false
    }
  },
  "id" : 140759286128185344,
  "created_at" : "2011-11-27 11:50:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140739384629661697",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u3084\u3093\u306A\u304D\u3083\u3044\u3051\u306A\u3044\u306E\u306B\u7720\u6C17\u304C",
  "id" : 140739384629661697,
  "created_at" : "2011-11-27 10:30:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140686916050882560",
  "geo" : { },
  "id_str" : "140687813204127744",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u4E86\u89E3\u3057\u307E\u3057\u305F\u3002\u307E\u305F\u306A\u3093\u304B\u3042\u3063\u305F\u3089\u53C2\u52A0\u3055\u305B\u3066\u304F\u3060\u3055\u3044\u306A\u3002",
  "id" : 140687813204127744,
  "in_reply_to_status_id" : 140686916050882560,
  "created_at" : "2011-11-27 07:06:03 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 0, 16 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140668028252729344",
  "geo" : { },
  "id_str" : "140668649794048000",
  "in_reply_to_user_id" : 230918258,
  "text" : "@takasan_san_san \u91CD\u306D\u5408\u308F\u305B\u306E\u72B6\u614B\u3092\u30D9\u30AF\u30C8\u30EB\u3067\u66F8\u3044\u3066\u7D50\u679C\u3092\u4E88\u60F3\u3057\u3066\u4E91\u3005",
  "id" : 140668649794048000,
  "in_reply_to_status_id" : 140668028252729344,
  "created_at" : "2011-11-27 05:49:54 +0000",
  "in_reply_to_screen_name" : "takasan_san_san",
  "in_reply_to_user_id_str" : "230918258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140664650806210560",
  "text" : "\u3093\u30FC\u91CF\u5B50\u529B\u5B66\u306E\u54F2\u5B66\u306E\u30EC\u30DD\u30FC\u30C8\u3057\u3093\u3069\u3044\u30FB\u30FB\u30FB",
  "id" : 140664650806210560,
  "created_at" : "2011-11-27 05:34:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140649358495465472",
  "text" : "\u30EA\u30D7\u30E9\u30A4\u306A\u3089\u53CD\u5FDC\u3057\u307E\u3059\u304C\u3057\u3070\u3089\u304F\u534A\u96E2\u8131\u3057\u307E\u3059\u3002",
  "id" : 140649358495465472,
  "created_at" : "2011-11-27 04:33:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140648159578820608",
  "text" : "\u3055\u3041\u8AB2\u984C\u3092\u7247\u4ED8\u3051\u308B\u305E",
  "id" : 140648159578820608,
  "created_at" : "2011-11-27 04:28:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140635374077739009",
  "geo" : { },
  "id_str" : "140636081501646848",
  "in_reply_to_user_id" : 91776168,
  "text" : "@iddo514 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 140636081501646848,
  "in_reply_to_status_id" : 140635374077739009,
  "created_at" : "2011-11-27 03:40:29 +0000",
  "in_reply_to_screen_name" : "iddo127",
  "in_reply_to_user_id_str" : "91776168",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140629322569498625",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3058\u3083\u304220:20\u306B\u884C\u3051\u3070\u3044\u3044\u3067\u3059\u304B\u306D",
  "id" : 140629322569498625,
  "created_at" : "2011-11-27 03:13:37 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140628108406558721",
  "geo" : { },
  "id_str" : "140628694849945602",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u53C2\u52A0\u3057\u3066\u3082\u3044\u3044\u3093\u3067\u3059\uFF1F",
  "id" : 140628694849945602,
  "in_reply_to_status_id" : 140628108406558721,
  "created_at" : "2011-11-27 03:11:08 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140626018502324224",
  "geo" : { },
  "id_str" : "140626274950463488",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3082\u3057\u304B\u3057\u3066\uFF1A\u3068\u3044\u3063\u304F",
  "id" : 140626274950463488,
  "in_reply_to_status_id" : 140626018502324224,
  "created_at" : "2011-11-27 03:01:31 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140625729346998272",
  "geo" : { },
  "id_str" : "140625845571170304",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u697D\u3057\u3044\uFF1F",
  "id" : 140625845571170304,
  "in_reply_to_status_id" : 140625729346998272,
  "created_at" : "2011-11-27 02:59:48 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140625468427735040",
  "geo" : { },
  "id_str" : "140625636287971328",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u30CD\u30C8\u30B2\uFF1F",
  "id" : 140625636287971328,
  "in_reply_to_status_id" : 140625468427735040,
  "created_at" : "2011-11-27 02:58:59 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140624940205490176",
  "geo" : { },
  "id_str" : "140625183672238080",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u3054\u98EF\u306E\u6C17\u5206\u306A\u3093\u3060",
  "id" : 140625183672238080,
  "in_reply_to_status_id" : 140624940205490176,
  "created_at" : "2011-11-27 02:57:11 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140624846437625856",
  "text" : "\u304A\u306A\u304B\u3078\u3063\u305F",
  "id" : 140624846437625856,
  "created_at" : "2011-11-27 02:55:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140624353774682112",
  "text" : "\u304F\u3089\u5BFF\u53F8\u3066\u4E38\u592A\u753A\u3092\u304B\u306A\u308A\u897F\u306B\u884C\u3063\u305F\u3068\u3053\u306B\u51FA\u6765\u305F\u3088\u306D",
  "id" : 140624353774682112,
  "created_at" : "2011-11-27 02:53:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140622693077749761",
  "text" : "\u304F\u3089\u5BFF\u53F8\u3044\u30FC\u306A\u30FC",
  "id" : 140622693077749761,
  "created_at" : "2011-11-27 02:47:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140622338302541825",
  "text" : "\u81EA\u5DF1\u7D39\u4ECB\u66F8\u304D\u63DB\u3048\u308B\u304B\u306A\u30FC\u3002\u3069\u3046\u305B\u30DE\u30A4\u30CA\u30FC\u30C1\u30A7\u30F3\u30B8\u3060\u308D\u3046\u3051\u3069\u3002",
  "id" : 140622338302541825,
  "created_at" : "2011-11-27 02:45:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u3064\u308A\u3046\u3080@0817-4100-1332",
      "screen_name" : "otsuotsu",
      "indices" : [ 0, 9 ],
      "id_str" : "53934373",
      "id" : 53934373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140620995135422464",
  "geo" : { },
  "id_str" : "140621204183711744",
  "in_reply_to_user_id" : 53934373,
  "text" : "@otsuotsu \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 140621204183711744,
  "in_reply_to_status_id" : 140620995135422464,
  "created_at" : "2011-11-27 02:41:22 +0000",
  "in_reply_to_screen_name" : "otsuotsu",
  "in_reply_to_user_id_str" : "53934373",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140620881297801216",
  "text" : "\u3077\u3088\u3077\u3088\u306E\u30AD\u30E3\u30E9\u306B\u300C\u3075\u3075\u3075\u300D\u3063\u3066\u306E\u304C\u3044\u3066\u306D",
  "id" : 140620881297801216,
  "created_at" : "2011-11-27 02:40:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140620320976547840",
  "text" : "\u3075\u3075\u3075",
  "id" : 140620320976547840,
  "created_at" : "2011-11-27 02:37:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140619062098145280",
  "text" : "\u6587\u5316\u796D\u524D\u5F8C\u30673\u301C40\u3082\u30D5\u30A9\u30ED\u30EF\u30FC\u304C\u5897\u3048\u305F\u3002\u30DD\u30B9\u30C8\u6570\u5C11\u306A\u3044\u306E\u306B\u6709\u308A\u96E3\u3044\u3053\u3068\u3067\u3059\u3002",
  "id" : 140619062098145280,
  "created_at" : "2011-11-27 02:32:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140618153175691264",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 140618153175691264,
  "created_at" : "2011-11-27 02:29:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140467345071161347",
  "text" : "\u305D\u3057\u3066\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 140467345071161347,
  "created_at" : "2011-11-26 16:29:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140467220005396480",
  "text" : "\u304A\u9152\u5F15\u3063\u639B\u3051\u3066\u30A4\u30A4\u30AB\u30F3\u30B8\u306E\u7720\u6C17\u3067\u5E30\u5B85\uFF67\uFF01",
  "id" : 140467220005396480,
  "created_at" : "2011-11-26 16:29:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140429215454605312",
  "text" : "\u4EE3\u6570\u306F\u3068\u3082\u304B\u304F\u5E7E\u4F55\u3057\u3070\u3089\u304F\u89E6\u3063\u3066\u306A\u3044\u6B7B\u306C",
  "id" : 140429215454605312,
  "created_at" : "2011-11-26 13:58:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140428047886196736",
  "text" : "\u30CE RT @gnawty49: \u5E7E\u4F55\u30D0\u30EA\u30D0\u30EA\u3067\u304D\u308B\u305C\u3000\u307F\u305F\u3044\u306A\u4EBA\u3058\u3083\u306A\u304F\u3066\u3000\u4ECA\u304B\u3089\u5E7E\u4F55\u59CB\u3081\u305F\u3044\u3000\u307F\u305F\u3044\u306A\u4EBA\u3068\u4EF2\u826F\u304F\u306A\u308A\u305F\u3044",
  "id" : 140428047886196736,
  "created_at" : "2011-11-26 13:53:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140427312519852033",
  "text" : "\u7D50\u5C40\u4F1A\u3048\u306A\u304B\u3063\u305F\u4EBA\u304C\u5E7E\u4EBA\u3082\u2026\u307E\u305F\u306E\u6A5F\u4F1A\u306B\u3002",
  "id" : 140427312519852033,
  "created_at" : "2011-11-26 13:50:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140427079551422467",
  "text" : "\u8033\u304C\u51B7\u305F\u3044",
  "id" : 140427079551422467,
  "created_at" : "2011-11-26 13:49:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140423605849833472",
  "geo" : { },
  "id_str" : "140426107009769473",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01\u5FA1\u5473\u306F\uFF1F",
  "id" : 140426107009769473,
  "in_reply_to_status_id" : 140423605849833472,
  "created_at" : "2011-11-26 13:46:07 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 3, 17 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140421746993020928",
  "text" : "RT @koizumi_fifty: NF\u306E\u6C34\u5F69\u753B\u5C55\u3067\u30A2\u30F3\u30B1\u30FC\u30C8\u7528\u7D19\u306B\u66F8\u304F\u611F\u60F3\u306B\u8FF7\u3063\u305F\u6319\u53E5\u300C\u4EAC\u90FD\u306B\u884C\u304D\u305F\u304F\u306A\u308A\u307E\u3057\u305F\u300D\u3068\u66F8\u3044\u305F\u306E\u304C\u79C1\u3067\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "140418555660341249",
    "text" : "NF\u306E\u6C34\u5F69\u753B\u5C55\u3067\u30A2\u30F3\u30B1\u30FC\u30C8\u7528\u7D19\u306B\u66F8\u304F\u611F\u60F3\u306B\u8FF7\u3063\u305F\u6319\u53E5\u300C\u4EAC\u90FD\u306B\u884C\u304D\u305F\u304F\u306A\u308A\u307E\u3057\u305F\u300D\u3068\u66F8\u3044\u305F\u306E\u304C\u79C1\u3067\u3059\u3002",
    "id" : 140418555660341249,
    "created_at" : "2011-11-26 13:16:07 +0000",
    "user" : {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "protected" : false,
      "id_str" : "243012018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2415843387\/yl1qetgxg63y2x5uxbwy_normal.png",
      "id" : 243012018,
      "verified" : false
    }
  },
  "id" : 140421746993020928,
  "created_at" : "2011-11-26 13:28:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5171\u531735",
      "indices" : [ 17, 22 ]
    }, {
      "text" : "NF53",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140338998257262592",
  "text" : "\u96E2\u8131\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u304C\u6700\u60AA\u3060\u3063\u305F\u6A21\u69D8 #\u5171\u531735 #NF53",
  "id" : 140338998257262592,
  "created_at" : "2011-11-26 07:59:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140330258141425664",
  "text" : "\u3077\u3088\u3077\u3088\u5927\u4F1A\u3082\u9762\u767D\u304B\u3063\u305F\u3057KUTLS\u3082\u697D\u3057\u304B\u3063\u305F",
  "id" : 140330258141425664,
  "created_at" : "2011-11-26 07:25:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140330042701004800",
  "text" : "\u4ECA\u65E5\u30D0\u30A4\u30C8\u3063\u3066\u306E\u304C\u6094\u3084\u307E\u308C\u308B\u306A\u30FC\u3002\u5931\u6557\u3057\u305F\u3002",
  "id" : 140330042701004800,
  "created_at" : "2011-11-26 07:24:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140329491707863040",
  "geo" : { },
  "id_str" : "140329603196661760",
  "in_reply_to_user_id" : 91776168,
  "text" : "@iddo514 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 140329603196661760,
  "in_reply_to_status_id" : 140329491707863040,
  "created_at" : "2011-11-26 07:22:39 +0000",
  "in_reply_to_screen_name" : "iddo127",
  "in_reply_to_user_id_str" : "91776168",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5171\u531735",
      "indices" : [ 17, 22 ]
    }, {
      "text" : "NF53",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140329054493614080",
  "text" : "\u660E\u65E5\u6253\u3061\u4E0A\u3052\u307F\u305F\u3044\u306E\u3042\u308B\u3093\u3067\u3059\uFF1F #\u5171\u531735 #NF53",
  "id" : 140329054493614080,
  "created_at" : "2011-11-26 07:20:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5171\u531735",
      "indices" : [ 6, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140290757633380352",
  "text" : "\u4EBA\u304C\u4E00\u676F\u2026 #\u5171\u531735",
  "id" : 140290757633380352,
  "created_at" : "2011-11-26 04:48:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140289486318878720",
  "geo" : { },
  "id_str" : "140289859637096448",
  "in_reply_to_user_id" : 91776168,
  "text" : "@iddo514 \u304A\u3044\u3057\u304B\u3063\u305F\u3067\u3059",
  "id" : 140289859637096448,
  "in_reply_to_status_id" : 140289486318878720,
  "created_at" : "2011-11-26 04:44:43 +0000",
  "in_reply_to_screen_name" : "iddo127",
  "in_reply_to_user_id_str" : "91776168",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5171\u531735",
      "indices" : [ 2, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140289696059244544",
  "text" : "\u3086 #\u5171\u531735",
  "id" : 140289696059244544,
  "created_at" : "2011-11-26 04:44:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140246466777190400",
  "geo" : { },
  "id_str" : "140246604975316993",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u30AA\u30D5\u4F1A\uFF1F",
  "id" : 140246604975316993,
  "in_reply_to_status_id" : 140246466777190400,
  "created_at" : "2011-11-26 01:52:50 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140246288007577600",
  "text" : "\u5171\u531735\u306A\u3046\u30FC",
  "id" : 140246288007577600,
  "created_at" : "2011-11-26 01:51:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140221840122580992",
  "geo" : { },
  "id_str" : "140234549807423488",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud AIBO\u3055\u3093\u306F\u6765\u307E\u3057\u305F\u3088\u30FC",
  "id" : 140234549807423488,
  "in_reply_to_status_id" : 140221840122580992,
  "created_at" : "2011-11-26 01:04:56 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140230840364974080",
  "text" : "\u4E00\u756A\u4E57\u308A\uFF1F",
  "id" : 140230840364974080,
  "created_at" : "2011-11-26 00:50:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140221488010756096",
  "text" : "\u8D77\u304D\u305F\u3089\u30D5\u30A9\u30ED\u30EF\u30FC\u304C\uFF11\uFF10\u3082\u5897\u3048\u3066\u3044\u305F\u3002\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 140221488010756096,
  "created_at" : "2011-11-26 00:13:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140101035715862531",
  "text" : "\u591C\u66F4\u304B\u3057\u3057\u3059\u304E\u305F\u304B\u306A\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 140101035715862531,
  "created_at" : "2011-11-25 16:14:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140088437431730176",
  "geo" : { },
  "id_str" : "140089779445436417",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u304A\u3084\u3086",
  "id" : 140089779445436417,
  "in_reply_to_status_id" : 140088437431730176,
  "created_at" : "2011-11-25 15:29:40 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140053557863919616",
  "text" : "\u6B8B\u308A\u5B89\u3044\u3063\u3066\uFF57\uFF57\uFF57\uFF57\u6B8B\u308A\u6613\u3044\u3093\u3060\u3088\u3046",
  "id" : 140053557863919616,
  "created_at" : "2011-11-25 13:05:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140053420085227520",
  "text" : "\u30A2\u30A4\u30B3\u30F3\u306E\u65B9\u304C\u5370\u8C61\u306B\u6B8B\u308A\u5B89\u3044\u898B\u305F\u3044\u3002\u3068\u3044\u3046\u304B\u4ECA\u65E5\u30A2\u30A4\u30B3\u30F3\u306E\u8AAC\u660E\u3057\u305F\u3089\u89E3\u304B\u3063\u3066\u304F\u308C\u305F\u4EBA\u304C\u6570\u540D\u30FB\u30FB\u30FB\u3002",
  "id" : 140053420085227520,
  "created_at" : "2011-11-25 13:05:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140053182498881536",
  "text" : "@Malmach140 \u3059\u3070\u3084\u3055\u3000\u306E\u3000\u3057\u3085\u305E\u304F\u3061\u3000\u304C\u3000\u305F\u304B\u305D\u3046",
  "id" : 140053182498881536,
  "created_at" : "2011-11-25 13:04:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140052832714883072",
  "text" : "\u3068\u304B\u8A00\u3044\u3064\u3064\u4F55\u4EBA\u304B\u305D\u3046\u3044\u3046\u4EBA\u3044\u308B\u3051\u3069\u3002",
  "id" : 140052832714883072,
  "created_at" : "2011-11-25 13:02:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140052752343642112",
  "text" : "\u5B9F\u5199\u30A2\u30A4\u30B3\u30F3\u3068\u304B\u77E5\u308A\u5408\u3044\u3058\u3083\u306A\u304D\u3083\u6016\u3044\u308F\u3001\u3061\u304B\u3088\u3089\u3093\u3068\u3053",
  "id" : 140052752343642112,
  "created_at" : "2011-11-25 13:02:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140051647278755840",
  "text" : "\u306A\u3093\u304Bku\u30AF\u30E9\u30B9\u30BF\u306E\u826F\u304F\u898B\u308B\u4EBA\u305F\u3061\u3092\u4E00\u901A\u308A\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u307F\u305F\u3002\u4F55\u304B\u3042\u3063\u305F\u3089\u58F0\u304B\u3051\u3066\u307F\u3066\u304F\u3060\u3055\u3044\u306A\u3002\u660E\u65E5\u4F1A\u3046\u4EBA\u3082\u3044\u308B\u304B\u3082\u3057\u308C\u306A\u3044\uFF57",
  "id" : 140051647278755840,
  "created_at" : "2011-11-25 12:58:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140045132396376064",
  "text" : "\u74E6\u305D\u3070\u7F8E\u5473\u3057\u304B\u3063\u305F\u306A",
  "id" : 140045132396376064,
  "created_at" : "2011-11-25 12:32:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140043014327382017",
  "text" : "\u6628\u65E5\u3001\u4ECA\u65E5\u3067\u6025\u306B\u79C1\u306B\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u305F\u4EBA\u306F\u3042\u3063\u305F\u4EBA\u306E\u53EF\u80FD\u6027\u304C\u9AD8\u3044\u3067\u3059",
  "id" : 140043014327382017,
  "created_at" : "2011-11-25 12:23:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    }, {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 8, 14 ],
      "id_str" : "184844182",
      "id" : 184844182
    }, {
      "name" : "A\u00EF",
      "screen_name" : "aibossan",
      "indices" : [ 15, 24 ],
      "id_str" : "96756462",
      "id" : 96756462
    }, {
      "name" : "(\u3086\u03C9\u30FC)\u3327@\u6843",
      "screen_name" : "yuton",
      "indices" : [ 25, 31 ],
      "id_str" : "15597112",
      "id" : 15597112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140042262603243520",
  "geo" : { },
  "id_str" : "140042585317179392",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud @0_uda @aibossan @yuton 10\u6642\u3067\u3082\u3044\u3044\u3067\u3059\u3088",
  "id" : 140042585317179392,
  "in_reply_to_status_id" : 140042262603243520,
  "created_at" : "2011-11-25 12:22:08 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140042131157942272",
  "text" : "\u5B66\u796D\u95A2\u9023\u3067\u30D5\u30A9\u30ED\u30FC\u3082\u30D5\u30A9\u30ED\u30EF\u30FC\u3082\u6CA2\u5C71\u5897\u3048\u3066\u308B",
  "id" : 140042131157942272,
  "created_at" : "2011-11-25 12:20:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140041764198285312",
  "text" : "\u4ECA\u65E5\u306F\u4E00\u676F\u7279\u5B9A\u3057\u3066\u7279\u5B9A\u3055\u308C\u3066\u697D\u3057\u304B\u3063\u305F\u30FC",
  "id" : 140041764198285312,
  "created_at" : "2011-11-25 12:18:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    }, {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 8, 14 ],
      "id_str" : "184844182",
      "id" : 184844182
    }, {
      "name" : "A\u00EF",
      "screen_name" : "aibossan",
      "indices" : [ 15, 24 ],
      "id_str" : "96756462",
      "id" : 96756462
    }, {
      "name" : "(\u3086\u03C9\u30FC)\u3327@\u6843",
      "screen_name" : "yuton",
      "indices" : [ 25, 31 ],
      "id_str" : "15597112",
      "id" : 15597112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140040378719010816",
  "geo" : { },
  "id_str" : "140041433246728192",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud @0_uda @aibossan @yuton \u3069\u3063\u3061\u3067\u3082\u3044\u3044\u3067\u3059\u304C11\u6642\u306E\u307B\u3046\u304C\u5BDD\u574A\u3057\u306B\u304F\u3044\u3067\u3059",
  "id" : 140041433246728192,
  "in_reply_to_status_id" : 140040378719010816,
  "created_at" : "2011-11-25 12:17:34 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140016868315504641",
  "text" : "\u5409\u91CE\u5BB6\u306A\u3046",
  "id" : 140016868315504641,
  "created_at" : "2011-11-25 10:39:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139991780518150144",
  "text" : "\u307E\u3046\u3061\u3083\u30AF\u30EC\u30FC\u30D7\u2026",
  "id" : 139991780518150144,
  "created_at" : "2011-11-25 09:00:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139987121829195776",
  "geo" : { },
  "id_str" : "139987623119814656",
  "in_reply_to_user_id" : 91776168,
  "text" : "@iddo514 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 139987623119814656,
  "in_reply_to_status_id" : 139987121829195776,
  "created_at" : "2011-11-25 08:43:44 +0000",
  "in_reply_to_screen_name" : "iddo127",
  "in_reply_to_user_id_str" : "91776168",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139986561692471299",
  "text" : "\u5171\u5317\uFF13\uFF15\u306A\u3046",
  "id" : 139986561692471299,
  "created_at" : "2011-11-25 08:39:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 3, 12 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u611B\u306E\u6559\u5BA4",
      "indices" : [ 58, 63 ]
    }, {
      "text" : "nf53",
      "indices" : [ 64, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/fitTZVcu",
      "expanded_url" : "http:\/\/togetter.com\/li\/218881",
      "display_url" : "togetter.com\/li\/218881"
    } ]
  },
  "geo" : { },
  "id_str" : "139980143019040768",
  "text" : "RT @isaribiz: \u300C\u611B\u306E\u6559\u5BA4\u5B9F\u6CC1\u307E\u3068\u3081\u300D\u3092\u30C8\u30A5\u30AE\u30E3\u308A\u307E\u3057\u305F\u3002\u3000 http:\/\/t.co\/fitTZVcu\u3000#\u611B\u306E\u6559\u5BA4\u3000#nf53",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u611B\u306E\u6559\u5BA4",
        "indices" : [ 44, 49 ]
      }, {
        "text" : "nf53",
        "indices" : [ 50, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/fitTZVcu",
        "expanded_url" : "http:\/\/togetter.com\/li\/218881",
        "display_url" : "togetter.com\/li\/218881"
      } ]
    },
    "geo" : { },
    "id_str" : "139962713282584576",
    "text" : "\u300C\u611B\u306E\u6559\u5BA4\u5B9F\u6CC1\u307E\u3068\u3081\u300D\u3092\u30C8\u30A5\u30AE\u30E3\u308A\u307E\u3057\u305F\u3002\u3000 http:\/\/t.co\/fitTZVcu\u3000#\u611B\u306E\u6559\u5BA4\u3000#nf53",
    "id" : 139962713282584576,
    "created_at" : "2011-11-25 07:04:45 +0000",
    "user" : {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "protected" : true,
      "id_str" : "150662260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586179377114685441\/2LPKH2Xn_normal.jpg",
      "id" : 150662260,
      "verified" : false
    }
  },
  "id" : 139980143019040768,
  "created_at" : "2011-11-25 08:14:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139954433986531328",
  "text" : "\u30B0\u30E9\u30A6\u30F3\u30C9\u30B9\u30C6\u30FC\u30B8\u306E\u5BA2\u5E2D\u3068\u30B9\u30C6\u30FC\u30B8\u306E\u6E29\u5EA6\u5DEE\uFF57\uFF57\uFF57\uFF57",
  "id" : 139954433986531328,
  "created_at" : "2011-11-25 06:31:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 0, 10 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139949998774288385",
  "geo" : { },
  "id_str" : "139950229523922944",
  "in_reply_to_user_id" : 177404480,
  "text" : "@dovanyahn",
  "id" : 139950229523922944,
  "in_reply_to_status_id" : 139949998774288385,
  "created_at" : "2011-11-25 06:15:09 +0000",
  "in_reply_to_screen_name" : "dovanyahn",
  "in_reply_to_user_id_str" : "177404480",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u611B\u306E\u6559\u5BA4",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139944819085688833",
  "text" : "\uFF10\u306F\u81EA\u7136\u6570\u3067\u3059\u304B\uFF1F #\u611B\u306E\u6559\u5BA4",
  "id" : 139944819085688833,
  "created_at" : "2011-11-25 05:53:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139943899463548929",
  "text" : "RT @iddo514: \u304F\u308B\u30FC\u3069\u3055\u3093\u30A4\u30B1\u30E1\u30F3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139943837786308608",
    "text" : "\u304F\u308B\u30FC\u3069\u3055\u3093\u30A4\u30B1\u30E1\u30F3",
    "id" : 139943837786308608,
    "created_at" : "2011-11-25 05:49:45 +0000",
    "user" : {
      "name" : "\u3000",
      "screen_name" : "iddo127",
      "protected" : true,
      "id_str" : "91776168",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_1_normal.png",
      "id" : 91776168,
      "verified" : false
    }
  },
  "id" : 139943899463548929,
  "created_at" : "2011-11-25 05:50:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u611B\u306E\u6559\u5BA4",
      "indices" : [ 2, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139943505849090049",
  "text" : "\u3086 #\u611B\u306E\u6559\u5BA4",
  "id" : 139943505849090049,
  "created_at" : "2011-11-25 05:48:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6307",
      "screen_name" : "suwakoishi",
      "indices" : [ 3, 14 ],
      "id_str" : "107395166",
      "id" : 107395166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u611B\u306E\u6559\u5BA4",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139943463008477184",
  "text" : "RT @suwakoishi: \u3086 #\u611B\u306E\u6559\u5BA4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yubitter.com\/\" rel=\"nofollow\"\u003Eyubitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u611B\u306E\u6559\u5BA4",
        "indices" : [ 2, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139943348499783680",
    "text" : "\u3086 #\u611B\u306E\u6559\u5BA4",
    "id" : 139943348499783680,
    "created_at" : "2011-11-25 05:47:48 +0000",
    "user" : {
      "name" : "\u5C0F\u6307",
      "screen_name" : "suwakoishi",
      "protected" : false,
      "id_str" : "107395166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515697096406491137\/lE8jL4Su_normal.jpeg",
      "id" : 107395166,
      "verified" : false
    }
  },
  "id" : 139943463008477184,
  "created_at" : "2011-11-25 05:48:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139939598938804224",
  "text" : "KUTLS\u3067TL\u307F\u3066\u308C\u3070\u611B\u306E\u6559\u5BA4\u884C\u304B\u306A\u304F\u3066\u3082\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u8AAC",
  "id" : 139939598938804224,
  "created_at" : "2011-11-25 05:32:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 1, 12 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 13, 23 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "sigmapsi",
      "screen_name" : "sigmapsi",
      "indices" : [ 24, 33 ],
      "id_str" : "22502063",
      "id" : 22502063
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 34, 44 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139939149049372672",
  "text" : ".@sakanafsku @nisehorrn @sigmapsi @Lisa_math \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 139939149049372672,
  "created_at" : "2011-11-25 05:31:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sigmapsi",
      "screen_name" : "sigmapsi",
      "indices" : [ 0, 9 ],
      "id_str" : "22502063",
      "id" : 22502063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139936802277572608",
  "geo" : { },
  "id_str" : "139938389460922368",
  "in_reply_to_user_id" : 22502063,
  "text" : "@sigmapsi \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 139938389460922368,
  "in_reply_to_status_id" : 139936802277572608,
  "created_at" : "2011-11-25 05:28:06 +0000",
  "in_reply_to_screen_name" : "sigmapsi",
  "in_reply_to_user_id_str" : "22502063",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139938294250217472",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046",
  "id" : 139938294250217472,
  "created_at" : "2011-11-25 05:27:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "indices" : [ 0, 9 ],
      "id_str" : "105498380",
      "id" : 105498380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139937861825855488",
  "geo" : { },
  "id_str" : "139938211072966656",
  "in_reply_to_user_id" : 105498380,
  "text" : "@_Nururin \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 139938211072966656,
  "in_reply_to_status_id" : 139937861825855488,
  "created_at" : "2011-11-25 05:27:24 +0000",
  "in_reply_to_screen_name" : "_Nururin",
  "in_reply_to_user_id_str" : "105498380",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139936812721373184",
  "text" : "\u306C\u308B\u30FC\u3055\u3093\u304B\u3089\u30C1\u30E5\u30ED\u30B9\u3092\u8CB7\u3063\u305F",
  "id" : 139936812721373184,
  "created_at" : "2011-11-25 05:21:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139934783613579264",
  "text" : "\u3082\u3063\u3068\u4EBA\u3044\u308B\u304B\u3068\u601D\u3044\u304D\u3084",
  "id" : 139934783613579264,
  "created_at" : "2011-11-25 05:13:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139929481614868480",
  "geo" : { },
  "id_str" : "139932934424629248",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u9055\u3046\u3088",
  "id" : 139932934424629248,
  "in_reply_to_status_id" : 139929481614868480,
  "created_at" : "2011-11-25 05:06:26 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139929124268548096",
  "text" : "KUTLS\u306A\u3046",
  "id" : 139929124268548096,
  "created_at" : "2011-11-25 04:51:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 0, 6 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139891171081203712",
  "geo" : { },
  "id_str" : "139891610900119553",
  "in_reply_to_user_id" : 184844182,
  "text" : "@0_uda \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 139891610900119553,
  "in_reply_to_status_id" : 139891171081203712,
  "created_at" : "2011-11-25 02:22:13 +0000",
  "in_reply_to_screen_name" : "0_uda",
  "in_reply_to_user_id_str" : "184844182",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139889085325131776",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 139889085325131776,
  "created_at" : "2011-11-25 02:12:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139676420296290304",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 139676420296290304,
  "created_at" : "2011-11-24 12:07:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139637903004418048",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 139637903004418048,
  "created_at" : "2011-11-24 09:34:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139637523776421888",
  "text" : "\uFF13\uFF13\u6642\u9593\u3076\u308A\u306E\u7761\u7720\u30A1\uFF01",
  "id" : 139637523776421888,
  "created_at" : "2011-11-24 09:32:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139500166410551296",
  "text" : "\u5171\u5317\u524D\u306B\u3001\u306B\u305B\u307B\u3082\u3069\u304D\u307F\u305F\u3044\u306E\u304C\u3044\u305F",
  "id" : 139500166410551296,
  "created_at" : "2011-11-24 00:26:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139485037098827776",
  "text" : "\u884C\u304F\u3068\u3053\u306A\u3044\u306A\u30FC(\u89E3\u3063\u3066\u306F\u3044\u305F\uFF09",
  "id" : 139485037098827776,
  "created_at" : "2011-11-23 23:26:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139484913496899584",
  "text" : "\u306A\u3093\u304B\u9AD8\u3044\u3068\u3053\u308D\u304B\u3089\u30B0\u30E9\u30A6\u30F3\u30C9\u3092\u898B\u4E0B\u3057\u3066\u3044\u308B",
  "id" : 139484913496899584,
  "created_at" : "2011-11-23 23:26:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139473020203970560",
  "geo" : { },
  "id_str" : "139473214949699584",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8D77\u304D\u3066\u3044\u3089\u308C\u305F\u3089\u3075\u3089\u3063\u3068\u884C\u304F\u304B\u3082",
  "id" : 139473214949699584,
  "in_reply_to_status_id" : 139473020203970560,
  "created_at" : "2011-11-23 22:39:40 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139472322976415744",
  "geo" : { },
  "id_str" : "139472972502147073",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u306A\u304B\u6E1B\u3063\u305F\u304B\u3089\u4ECA\u884C\u304D\u305F\u3044\u3093\u3060\u304C",
  "id" : 139472972502147073,
  "in_reply_to_status_id" : 139472322976415744,
  "created_at" : "2011-11-23 22:38:42 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139472695850041345",
  "text" : "\u5171\u531735\u3084\u3063\u3071\u308A\u8AB0\u3082\u3044\u306A\u304B\u3063\u305F\u2190",
  "id" : 139472695850041345,
  "created_at" : "2011-11-23 22:37:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139472158773612545",
  "text" : "NF\u306A\u3046\u3063\uFF01",
  "id" : 139472158773612545,
  "created_at" : "2011-11-23 22:35:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/MmWJoonM",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=tohru1101",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "139163061536817152",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001tohru1101\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/MmWJoonM #gohantabeyo",
  "id" : 139163061536817152,
  "created_at" : "2011-11-23 02:07:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yutaka11235",
      "screen_name" : "yutaka11235",
      "indices" : [ 3, 15 ],
      "id_str" : "2994544423",
      "id" : 2994544423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nf53",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "s2s_event",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/0U9DE4Fv",
      "expanded_url" : "http:\/\/twitpic.com\/7i30f3",
      "display_url" : "twitpic.com\/7i30f3"
    } ]
  },
  "geo" : { },
  "id_str" : "139141599660740608",
  "text" : "RT @yutaka11235: \u30D3\u30E5\u30D5\u30A9\u30F3\u306E\u91DD\u554F\u984C\u3092\u5B9F\u9A13\u4E2D\u3060\u3057\uFF01 #nf53 #s2s_event http:\/\/t.co\/0U9DE4Fv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.docodemo.jp\/twil\/\" rel=\"nofollow\"\u003ETwil2 (Tweet Anytime, Anywhere by Mail)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nf53",
        "indices" : [ 17, 22 ]
      }, {
        "text" : "s2s_event",
        "indices" : [ 23, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/0U9DE4Fv",
        "expanded_url" : "http:\/\/twitpic.com\/7i30f3",
        "display_url" : "twitpic.com\/7i30f3"
      } ]
    },
    "geo" : { },
    "id_str" : "139141124647432192",
    "text" : "\u30D3\u30E5\u30D5\u30A9\u30F3\u306E\u91DD\u554F\u984C\u3092\u5B9F\u9A13\u4E2D\u3060\u3057\uFF01 #nf53 #s2s_event http:\/\/t.co\/0U9DE4Fv",
    "id" : 139141124647432192,
    "created_at" : "2011-11-23 00:40:03 +0000",
    "user" : {
      "name" : "\u3075\u3041\u30FC\u306A",
      "screen_name" : "naglfari11235",
      "protected" : false,
      "id_str" : "135944137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581130542571069440\/TdIb9eq__normal.jpg",
      "id" : 135944137,
      "verified" : false
    }
  },
  "id" : 139141599660740608,
  "created_at" : "2011-11-23 00:41:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138950998684217344",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 138950998684217344,
  "created_at" : "2011-11-22 12:04:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "indices" : [ 3, 16 ],
      "id_str" : "96289411",
      "id" : 96289411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138831596206817280",
  "text" : "RT @d_v_osorezan: \u300C\u30D4\u30B6\u3063\u3066\uFF11\uFF10\u56DE\u8A00\u3063\u3066\u300D\n\u300C\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u300D\n\u300C\u3058\u3083\u3042\u3001\u3053\u3053\u306F\uFF1F\u300D\n\u300C\u2026\u2026\u308F\u304B\u3089\u306D\u3048\u3002\u4E00\u4F53\u3053\u3053\u306F\u3069\u3053\u3060\u2026\uFF1F\u300D\n\u300C\u3088\u3046\u3084\u304F\u6C17\u3065\u3044\u305F\u304B\u3002\u3069\u3046\u3084\u3089\u4FFA\u305F\u3061\u3001\u3068\u3093\u3067\u3082\u306A\u3044\u6240\u3078\u8FF7\u3044\u8FBC\u3093\u3058\u307E\u3063\u305F\u307F\u305F\u3044\u3060\u305C\u2026\u2026\u300D\n\u300C\u30B7\u30C3\uFF01\u3000\u306A ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "22615416312434689",
    "text" : "\u300C\u30D4\u30B6\u3063\u3066\uFF11\uFF10\u56DE\u8A00\u3063\u3066\u300D\n\u300C\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u30D4\u30B6\u300D\n\u300C\u3058\u3083\u3042\u3001\u3053\u3053\u306F\uFF1F\u300D\n\u300C\u2026\u2026\u308F\u304B\u3089\u306D\u3048\u3002\u4E00\u4F53\u3053\u3053\u306F\u3069\u3053\u3060\u2026\uFF1F\u300D\n\u300C\u3088\u3046\u3084\u304F\u6C17\u3065\u3044\u305F\u304B\u3002\u3069\u3046\u3084\u3089\u4FFA\u305F\u3061\u3001\u3068\u3093\u3067\u3082\u306A\u3044\u6240\u3078\u8FF7\u3044\u8FBC\u3093\u3058\u307E\u3063\u305F\u307F\u305F\u3044\u3060\u305C\u2026\u2026\u300D\n\u300C\u30B7\u30C3\uFF01\u3000\u306A\u306B\u304B\u6765\u308B\uFF01\u300D",
    "id" : 22615416312434689,
    "created_at" : "2011-01-05 11:28:30 +0000",
    "user" : {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "protected" : false,
      "id_str" : "96289411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3457427933\/e9c1859b77927509e49bcdd8ea328bdb_normal.jpeg",
      "id" : 96289411,
      "verified" : false
    }
  },
  "id" : 138831596206817280,
  "created_at" : "2011-11-22 04:10:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138831027677302784",
  "text" : "\uFF16\u9023\u4F11\u3060!",
  "id" : 138831027677302784,
  "created_at" : "2011-11-22 04:07:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138829101237673984",
  "text" : "\u8D77\u304D\u305F\u3002\u304A\u306F\u3088\u3046!",
  "id" : 138829101237673984,
  "created_at" : "2011-11-22 04:00:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138667658445983745",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 138667658445983745,
  "created_at" : "2011-11-21 17:18:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138667619082444802",
  "text" : "\u5BDD\u307E\u30FC\u3059",
  "id" : 138667619082444802,
  "created_at" : "2011-11-21 17:18:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138665939842510849",
  "geo" : { },
  "id_str" : "138666115432849408",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u304A\u3084\u3059\u307F\u306A\u3055\u3086",
  "id" : 138666115432849408,
  "in_reply_to_status_id" : 138665939842510849,
  "created_at" : "2011-11-21 17:12:32 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138662362101202944",
  "text" : "\u53BB\u5E74\u306F\uFF2E\uFF26\u671F\u9593\u4E2D\u306F\u5E30\u7701\u3057\u3066\u305F\u308A\u30B5\u30FC\u30AF\u30EB\u3067\u9EBB\u96C0\u3084\u3063\u3066\u305F\u308A\u3067\u5168\u304F\u4E0D\u53C2\u52A0\u3060\u3063\u305F\u304B\u3089\u306A\u3041",
  "id" : 138662362101202944,
  "created_at" : "2011-11-21 16:57:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138661207199584257",
  "text" : "\u305C\u3072\u8CB7\u3044\u306B\u884C\u3053\u3046\uFF57\uFF57",
  "id" : 138661207199584257,
  "created_at" : "2011-11-21 16:53:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138660871755935746",
  "text" : "\uFF2E\uFF26\u3067\u3061\u3087\u3063\u3068\u30C4\u30A4\u30C3\u30BF\uFF0D\u4E0A\u306E\u4EBA\u3005\u3068\u4EF2\u826F\u304F\u306A\u3063\u3066\u307F\u3088\u3046\u304B\u3068\u601D\u3063\u3066\u3044\u308B\u304C\u2026",
  "id" : 138660871755935746,
  "created_at" : "2011-11-21 16:51:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 0, 6 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138659296589262848",
  "geo" : { },
  "id_str" : "138660312734908416",
  "in_reply_to_user_id" : 184844182,
  "text" : "@0_uda \u3077\u3088\u3077\u3088\u898B\u306B\u884C\u304D\u307E\u3059\u3002\u8155\u306F\u304B\u306A\u308A\u30A2\u30EC\u3067\u3059\u304C\uFF57\uFF57\uFF57",
  "id" : 138660312734908416,
  "in_reply_to_status_id" : 138659296589262848,
  "created_at" : "2011-11-21 16:49:29 +0000",
  "in_reply_to_screen_name" : "0_uda",
  "in_reply_to_user_id_str" : "184844182",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138658677631619072",
  "text" : "\u7D50\u5C40\uFF2E\uFF26\u30AA\u30D5\u3063\u3066\u3069\u3053\u3067\u3084\u3063\u3066\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 138658677631619072,
  "created_at" : "2011-11-21 16:42:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138642428172320768",
  "text" : "\u56FA\u6709\u3063\u3066\u8A00\u8449\u306B\u5F15\u304D\u305A\u3089\u308C\u3066\u3044\u308B\u306A\u3041\u3002\u65E5\u672C\u8A9E\u306B\u5F15\u304D\u305A\u3089\u308C\u3066\u3057\u307E\u3046\u3002",
  "id" : 138642428172320768,
  "created_at" : "2011-11-21 15:38:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138642257803878401",
  "text" : "\u6052\u7B49\u5199\u50CF\u306E\u56FA\u6709\u30D9\u30AF\u30C8\u30EB\u3063\u3066\u4EFB\u610F\u306E\u30D9\u30AF\u30C8\u30EB\u3067\u3044\u3044\u3093\u3060\u3088\u306A\uFF1F\u306A\u3093\u304B\u4E0D\u5B89\u3002",
  "id" : 138642257803878401,
  "created_at" : "2011-11-21 15:37:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138636342925082624",
  "text" : "\u722A\u304C\u4F38\u3073\u3059\u304E\u3066\u30BF\u30A4\u30D7\u3057\u306B\u304F\u3044\u304B\u3089\u722A\u3092\u5207\u308D\u3046",
  "id" : 138636342925082624,
  "created_at" : "2011-11-21 15:14:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138635439073525760",
  "text" : "\u304A\u3068\u306A\u3057\u304F\u30EF\u30FC\u30C9\u3067\u3084\u308B\u3053\u3068\u306B\u3057\u3088\u3046\u3002\u3042\u3068\u304A\u306A\u304B\u6E1B\u3063\u305F\u3002",
  "id" : 138635439073525760,
  "created_at" : "2011-11-21 15:10:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138635112064614402",
  "geo" : { },
  "id_str" : "138635221108142081",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3044\u3084\u30FC\u30CD\u30C3\u30C8\u3067\u9069\u5F53\u306B\u8ABF\u3079\u306A\u304C\u3089\u3084\u308D\u3046\u304B\u3068\u3002",
  "id" : 138635221108142081,
  "in_reply_to_status_id" : 138635112064614402,
  "created_at" : "2011-11-21 15:09:47 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "indices" : [ 3, 11 ],
      "id_str" : "115380002",
      "id" : 115380002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138634570860990464",
  "text" : "RT @nedikes: (\u30FB\u03C9\u30FB)\u2190\u7D20\u9854\u3000\n(\u3000\u30FB\u03C9\u30FB\u3000)\u2190\u9854\u304C\u5E83\u3044\u3000\n)\u30FB\u03C9\u30FB(\u2190\u9854\u304C\u6F70\u308C\u308B\u3000\n(\u256E\u30FB\u03C9\u30FB\u256D)\u2190\u4F55\u98DF\u308F\u306C\u9854\u3000\n\u7131\u30FB\u03C9\u30FB\u7131\u2190\u9854\u304B\u3089\u706B\u304C\u51FA\u308B\u3000\n(\u30FB\u03C9\/\u3000\/)\u2190\u9854\u304C\u5272\u308C\u308B\u3000\n(\u0283\u30FB\u03C9\u303D)\u2190\u9854\u306B\u6CE5\u3092\u5857\u308B\u3000\n(\u2600\u03C9\u2600)\u2190\u671D\u9854\u3000\n(\u30FB\u03C9(\u30FB\u03C9(\u30FB\u03C9\u30FB)\u2190\u9854\u304C\u63C3\u3046 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "138631673649696768",
    "text" : "(\u30FB\u03C9\u30FB)\u2190\u7D20\u9854\u3000\n(\u3000\u30FB\u03C9\u30FB\u3000)\u2190\u9854\u304C\u5E83\u3044\u3000\n)\u30FB\u03C9\u30FB(\u2190\u9854\u304C\u6F70\u308C\u308B\u3000\n(\u256E\u30FB\u03C9\u30FB\u256D)\u2190\u4F55\u98DF\u308F\u306C\u9854\u3000\n\u7131\u30FB\u03C9\u30FB\u7131\u2190\u9854\u304B\u3089\u706B\u304C\u51FA\u308B\u3000\n(\u30FB\u03C9\/\u3000\/)\u2190\u9854\u304C\u5272\u308C\u308B\u3000\n(\u0283\u30FB\u03C9\u303D)\u2190\u9854\u306B\u6CE5\u3092\u5857\u308B\u3000\n(\u2600\u03C9\u2600)\u2190\u671D\u9854\u3000\n(\u30FB\u03C9(\u30FB\u03C9(\u30FB\u03C9\u30FB)\u2190\u9854\u304C\u63C3\u3046\u3000\n(\u3042\u30FB\u03C9\u30FB\u307B)\u2190\u9854\u306B\u66F8\u3044\u3066\u3042\u308B",
    "id" : 138631673649696768,
    "created_at" : "2011-11-21 14:55:41 +0000",
    "user" : {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "protected" : false,
      "id_str" : "115380002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009659425\/___normal.png",
      "id" : 115380002,
      "verified" : false
    }
  },
  "id" : 138634570860990464,
  "created_at" : "2011-11-21 15:07:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138633432224890882",
  "geo" : { },
  "id_str" : "138633929904238593",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u307E\u3041\u4F8B\u306B\u3088\u3063\u3066\u72EC\u5B66\u3067\u3059\u306D\uFF57\u6625\u4F11\u307F\u306B\u3067\u3082\u306E\u3093\u3073\u308A\u3084\u308A\u307E\u3059\u3088\uFF57",
  "id" : 138633929904238593,
  "in_reply_to_status_id" : 138633432224890882,
  "created_at" : "2011-11-21 15:04:39 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138632311083249665",
  "geo" : { },
  "id_str" : "138632578939883520",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u305D\u308C\u3067\u3059",
  "id" : 138632578939883520,
  "in_reply_to_status_id" : 138632311083249665,
  "created_at" : "2011-11-21 14:59:17 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138632175699492865",
  "text" : "\u3067\u3082\u307E\u3041\u3001\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u3068\u3057\u3066\u306F\u4F7F\u3048\u305F\u65B9\u304C\u3044\u3044\u3067\u3059\u3088\u306D\u3047",
  "id" : 138632175699492865,
  "created_at" : "2011-11-21 14:57:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138632076386770944",
  "text" : "\u8907\u96D1\u3067\u3059\u3057\u304A\u3059\u3057\u3002\uFF23\u306E\u30B3\u30F3\u30D1\u30A4\u30E9\u306A\u3093\u304B\u306E\u5C0E\u5165\u306E\u6642\u3082\u3053\u3093\u306A\u306B\u5927\u5909\u3058\u3083\u306A\u304B\u3063\u305F\u306E\u306B\u3002",
  "id" : 138632076386770944,
  "created_at" : "2011-11-21 14:57:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138631900288925696",
  "text" : "TeX\u5165\u308C\u3066\u30EC\u30DD\u30FC\u30C8\u3084\u3063\u3066\u307F\u3088\u3046\u3068\u601D\u3063\u305F\u3051\u3069\u6163\u308C\u308B\u307E\u3067\u306B\u63D0\u51FA\u671F\u9650\u304C\u6765\u305D\u3046\u306A\u306E\u3067\u3001\u3068\u308A\u3042\u3048\u305A\u4FDD\u7559\u3002",
  "id" : 138631900288925696,
  "created_at" : "2011-11-21 14:56:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138593205582180352",
  "text" : "\u3042\u3001ac.jp\u3063\u3066\u65E5\u672C\u9078\u629E\u516C\u7406\u53A8\u306E\u30C9\u30E1\u30A4\u30F3\u3060\u3063\u305F\u3093\u3060\uFF57\uFF57\uFF57\u307F\u305F\u3044\u306A\u3063\uFF01",
  "id" : 138593205582180352,
  "created_at" : "2011-11-21 12:22:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/wx4ncvo6",
      "expanded_url" : "http:\/\/www.japan-nic.ac\/",
      "display_url" : "japan-nic.ac"
    } ]
  },
  "geo" : { },
  "id_str" : "138593067140784128",
  "text" : "RT @hyuki: @Boc963proguram http:\/\/t.co\/wx4ncvo6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B Pro  for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 36 ],
        "url" : "http:\/\/t.co\/wx4ncvo6",
        "expanded_url" : "http:\/\/www.japan-nic.ac\/",
        "display_url" : "japan-nic.ac"
      } ]
    },
    "in_reply_to_status_id_str" : "138580056535601153",
    "geo" : { },
    "id_str" : "138580843823235072",
    "in_reply_to_user_id" : 350080668,
    "text" : "@Boc963proguram http:\/\/t.co\/wx4ncvo6",
    "id" : 138580843823235072,
    "in_reply_to_status_id" : 138580056535601153,
    "created_at" : "2011-11-21 11:33:42 +0000",
    "in_reply_to_screen_name" : "yuna_art",
    "in_reply_to_user_id_str" : "350080668",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 138593067140784128,
  "created_at" : "2011-11-21 12:22:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Sloan",
      "screen_name" : "ts572",
      "indices" : [ 0, 6 ],
      "id_str" : "956244972",
      "id" : 956244972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138592938325311488",
  "text" : "@ts572 \u3042\u3001\u30B9\u30AB\u30A4\u30D7\u306Bpdf\u306E\uFF35\uFF32\uFF2C\u306F\u3063\u3066\u304A\u304D\u307E\u3057\u305F\u3002\u3044\u308D\u3044\u308D\u3002",
  "id" : 138592938325311488,
  "created_at" : "2011-11-21 12:21:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 14, 23 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138583891199008768",
  "geo" : { },
  "id_str" : "138585461596753920",
  "in_reply_to_user_id" : 112398542,
  "text" : "\u4E00\u77AC\u3086\u306E\u4EBA\u304B\u3068\u601D\u3063\u305F RT @akeopyaa \u3086\u306E\u4F55\u3057\u3066\u3093\u3060",
  "id" : 138585461596753920,
  "in_reply_to_status_id" : 138583891199008768,
  "created_at" : "2011-11-21 11:52:03 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Sloan",
      "screen_name" : "ts572",
      "indices" : [ 16, 22 ],
      "id_str" : "956244972",
      "id" : 956244972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/3VDE7MIz",
      "expanded_url" : "http:\/\/www5.hp-ez.com\/hp\/fire\/page9",
      "display_url" : "www5.hp-ez.com\/hp\/fire\/page9"
    } ]
  },
  "geo" : { },
  "id_str" : "138580723849375744",
  "text" : "\u4F55\u306E\u696D\u8005\u304B\u3068\u601D\u3063\u305F\uFF57\uFF57\uFF57 RT @ts572 \uFF12\uFF10\uFF11\uFF11\u3000\u4EAC\u90FD\u5927\u5B66\uFF11\uFF11\u6708\u796D\u3077\u3088\u3077\u3088\u901A\u5927\u4F1A\u3000http:\/\/t.co\/3VDE7MIz",
  "id" : 138580723849375744,
  "created_at" : "2011-11-21 11:33:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u732A\u9E7F\u8776",
      "screen_name" : "HakuginNisiki",
      "indices" : [ 3, 17 ],
      "id_str" : "275399703",
      "id" : 275399703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138580392725848064",
  "text" : "RT @HakuginNisiki: \u300C\u3042\u3093\u305F\u304C\u305F\u3069\u3053\u3055\u300D\u300C\u80A5\u5F8C\u3055\u300D\u300C\u80A5\u5F8C\u3069\u3053\u3055\u300D\u300C\u718A\u672C\u3055\u300D\u300C\u718A\u672C\u3069\u3053\u3055\u300D\u300C\u8239\u5834\u3055\u300D\u300C\u8239\u5834\u5C71\u306B\u306F\u72F8\u304C\u304A\u3063\u3066\u3055\u300D\u300C\u305D\u308C\u3092\u731F\u5E2B\u304C\u9244\u7832\u3067\u6483\u3063\u3066\u3055\u300D\u300C\u716E\u3066\u3055\u300D\u300C\u713C\u3044\u3066\u3055\u300D\u300C\u98DF\u3063\u3066\u3055\u300D\u300C\u305D\u308C\u3092\u6728\u306E\u8449\u3067\uFF73\uFF99\uFF84\uFF97\uFF7F\uFF73\uFF6F!\u300D\u300C\uFF8A\uFF72\uFF6F!\u300D\u3000\u3063\u3066\u71B1\u5531\u3057\u3066\u308B\u5C0F\u5B66 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "138567618599714816",
    "text" : "\u300C\u3042\u3093\u305F\u304C\u305F\u3069\u3053\u3055\u300D\u300C\u80A5\u5F8C\u3055\u300D\u300C\u80A5\u5F8C\u3069\u3053\u3055\u300D\u300C\u718A\u672C\u3055\u300D\u300C\u718A\u672C\u3069\u3053\u3055\u300D\u300C\u8239\u5834\u3055\u300D\u300C\u8239\u5834\u5C71\u306B\u306F\u72F8\u304C\u304A\u3063\u3066\u3055\u300D\u300C\u305D\u308C\u3092\u731F\u5E2B\u304C\u9244\u7832\u3067\u6483\u3063\u3066\u3055\u300D\u300C\u716E\u3066\u3055\u300D\u300C\u713C\u3044\u3066\u3055\u300D\u300C\u98DF\u3063\u3066\u3055\u300D\u300C\u305D\u308C\u3092\u6728\u306E\u8449\u3067\uFF73\uFF99\uFF84\uFF97\uFF7F\uFF73\uFF6F!\u300D\u300C\uFF8A\uFF72\uFF6F!\u300D\u3000\u3063\u3066\u71B1\u5531\u3057\u3066\u308B\u5C0F\u5B66\u751F\u4E8C\u4EBA\u7D44\u3092\u3053\u306E\u9593\u898B\u304B\u3051\u305F",
    "id" : 138567618599714816,
    "created_at" : "2011-11-21 10:41:09 +0000",
    "user" : {
      "name" : "\u732A\u9E7F\u8776",
      "screen_name" : "HakuginNisiki",
      "protected" : false,
      "id_str" : "275399703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000681370973\/cc5bab1e5a03f50d0357e63bb58e84d1_normal.jpeg",
      "id" : 275399703,
      "verified" : false
    }
  },
  "id" : 138580392725848064,
  "created_at" : "2011-11-21 11:31:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138579845297872896",
  "text" : "\u30ED\u30B0\u8AAD\u3093\u3060\u3051\u3069\u7D50\u57CE\u5148\u751F\u306F\u6570\u5B66\u79D1\u51FA\u8EAB\u3058\u3083\u306A\u3044\u3093\u3060\u306A\u30FC\u3002\u89AA\u8FD1\u611F\u3001\u3068\u3044\u3046\u304B\u3001\u5B89\u5FC3\u611F\u3002",
  "id" : 138579845297872896,
  "created_at" : "2011-11-21 11:29:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "\u65E9\u7A32\u7530\u5927\u5B66\u300C\u7406\u5DE5\u5C55\u300D\u516C\u5F0F\u30A2\u30AB\u30A6\u30F3\u30C8",
      "screen_name" : "rikoten_waseda",
      "indices" : [ 64, 79 ],
      "id_str" : "199586956",
      "id" : 199586956
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rikoten",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "mathgirl",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/Q32yL5Ww",
      "expanded_url" : "http:\/\/www.hyuki.com\/girl\/rikoten.html",
      "display_url" : "hyuki.com\/girl\/rikoten.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "138579668851892224",
  "text" : "RT @hyuki: \u65E9\u7A32\u7530\u5927\u5B66\u7406\u5DE5\u5C55\u3067\u306E\u30C1\u30E3\u30C3\u30C8\u30ED\u30B0\u3092\u516C\u958B\u3057\u307E\u3057\u305F\u3002\u300E\u6570\u5B66\u30AC\u30FC\u30EB\u300F\u8457\u8005 \u7D50\u57CE\u6D69\u6C0F \u30E9\u30A4\u30F4\u30C1\u30E3\u30C3\u30C8\u30C8\u30FC\u30AF\u30B7\u30E7\u30FC @rikoten_waseda #rikoten #mathgirl http:\/\/t.co\/Q32yL5Ww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B Pro  for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u65E9\u7A32\u7530\u5927\u5B66\u300C\u7406\u5DE5\u5C55\u300D\u516C\u5F0F\u30A2\u30AB\u30A6\u30F3\u30C8",
        "screen_name" : "rikoten_waseda",
        "indices" : [ 53, 68 ],
        "id_str" : "199586956",
        "id" : 199586956
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rikoten",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "mathgirl",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/Q32yL5Ww",
        "expanded_url" : "http:\/\/www.hyuki.com\/girl\/rikoten.html",
        "display_url" : "hyuki.com\/girl\/rikoten.h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "138554934923767808",
    "text" : "\u65E9\u7A32\u7530\u5927\u5B66\u7406\u5DE5\u5C55\u3067\u306E\u30C1\u30E3\u30C3\u30C8\u30ED\u30B0\u3092\u516C\u958B\u3057\u307E\u3057\u305F\u3002\u300E\u6570\u5B66\u30AC\u30FC\u30EB\u300F\u8457\u8005 \u7D50\u57CE\u6D69\u6C0F \u30E9\u30A4\u30F4\u30C1\u30E3\u30C3\u30C8\u30C8\u30FC\u30AF\u30B7\u30E7\u30FC @rikoten_waseda #rikoten #mathgirl http:\/\/t.co\/Q32yL5Ww",
    "id" : 138554934923767808,
    "created_at" : "2011-11-21 09:50:45 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 138579668851892224,
  "created_at" : "2011-11-21 11:29:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138544313914241024",
  "text" : "\u624B\u5148\u8DB3\u5148\u304C\u51B7\u305F\u3044",
  "id" : 138544313914241024,
  "created_at" : "2011-11-21 09:08:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u96A3\u306E\u3068\u306A\u308A",
      "screen_name" : "tonar_no_tonari",
      "indices" : [ 0, 16 ],
      "id_str" : "262045935",
      "id" : 262045935
    }, {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 17, 29 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138528227357503488",
  "geo" : { },
  "id_str" : "138544127984943104",
  "in_reply_to_user_id" : 262045935,
  "text" : "@tonar_no_tonari @modestrella \u5C0F\u9EA6\u306E\u683D\u57F9\u304B\u3089\u3084\u308B\u3068\u306A\u308B\u3068\u4FFA\u3089\u306E\u4EE3\u3067\u306F\u3057\u3093\u3069\u305D\u3046\u3067\u3059\u306D\u3047",
  "id" : 138544127984943104,
  "in_reply_to_status_id" : 138528227357503488,
  "created_at" : "2011-11-21 09:07:48 +0000",
  "in_reply_to_screen_name" : "tonar_no_tonari",
  "in_reply_to_user_id_str" : "262045935",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138461852454760449",
  "text" : "\u6587\u5B57\u60C5\u5831\u3060\u3068\u5197\u8AC7\u307D\u3055\u304C\u4F1D\u308F\u308A\u306B\u304F\u3044\u3088\u306A\u30FC\u3002\u3061\u3087\u3063\u3068\u5DE5\u592B\u3057\u306A\u304D\u3083\u3002",
  "id" : 138461852454760449,
  "created_at" : "2011-11-21 03:40:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3060\u307E\u3054 = \u6C38\u5CF6\u5B5D",
      "screen_name" : "tadamago",
      "indices" : [ 3, 12 ],
      "id_str" : "159409876",
      "id" : 159409876
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 43, 50 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138461506751840256",
  "text" : "RT @tadamago: \u4F4D\u76F8\u306E\u8A71\u306A\u306E\u306B\u5BF8\u6CD5\u306E\u3042\u308B\u306E\u304C\u6559\u6750\u4F5C\u308A\u306E\u8F9B\u3055\u3067\u3059\u306D\uFF0E RT @tenapi: \u5BF8\u6CD5\u306E\u8A08\u7B97\u3092\u9593\u9055\u3048\u305F\u304B\u3082\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "api",
        "screen_name" : "TenApi",
        "indices" : [ 29, 36 ],
        "id_str" : "3240677334",
        "id" : 3240677334
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "138459596137308160",
    "text" : "\u4F4D\u76F8\u306E\u8A71\u306A\u306E\u306B\u5BF8\u6CD5\u306E\u3042\u308B\u306E\u304C\u6559\u6750\u4F5C\u308A\u306E\u8F9B\u3055\u3067\u3059\u306D\uFF0E RT @tenapi: \u5BF8\u6CD5\u306E\u8A08\u7B97\u3092\u9593\u9055\u3048\u305F\u304B\u3082\u2026",
    "id" : 138459596137308160,
    "created_at" : "2011-11-21 03:31:54 +0000",
    "user" : {
      "name" : "\u305F\u3060\u307E\u3054 = \u6C38\u5CF6\u5B5D",
      "screen_name" : "tadamago",
      "protected" : false,
      "id_str" : "159409876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459615133291921408\/-mvuy9ZP_normal.jpeg",
      "id" : 159409876,
      "verified" : false
    }
  },
  "id" : 138461506751840256,
  "created_at" : "2011-11-21 03:39:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138461253667520513",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4E86\u89E3\u3057\u305F\u30FC",
  "id" : 138461253667520513,
  "created_at" : "2011-11-21 03:38:30 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u96A3\u306E\u3068\u306A\u308A",
      "screen_name" : "tonar_no_tonari",
      "indices" : [ 0, 16 ],
      "id_str" : "262045935",
      "id" : 262045935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138459787464687616",
  "geo" : { },
  "id_str" : "138461072456818688",
  "in_reply_to_user_id" : 262045935,
  "text" : "@tonar_no_tonari \u30D3\u30EA\u30E4\u30FC\u30C9\u3058\u3083\u306A\u304F\u3066\u3082\u826F\u304F\u306D\u2192\u9759\u89B3",
  "id" : 138461072456818688,
  "in_reply_to_status_id" : 138459787464687616,
  "created_at" : "2011-11-21 03:37:46 +0000",
  "in_reply_to_screen_name" : "tonar_no_tonari",
  "in_reply_to_user_id_str" : "262045935",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138459603766743040",
  "geo" : { },
  "id_str" : "138460828851634176",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5197\u8AC7\u3067\u3057\u305F\u304C\u3054\u3081\u3093\u306A\u3055\u3044",
  "id" : 138460828851634176,
  "in_reply_to_status_id" : 138459603766743040,
  "created_at" : "2011-11-21 03:36:48 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138459007869390848",
  "text" : "\u5927\u4F53\u30D3\u30EA\u30E4\u30FC\u30C9\u30B5\u30FC\u30AF\u30EB\u304CNF\u3067\u306A\u306B\u3084\u308C\u3063\u3066\u3093\u3067\u3059\u304B",
  "id" : 138459007869390848,
  "created_at" : "2011-11-21 03:29:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138458748539764738",
  "text" : "\u3075\u3075\u3075(\u2190NF\u306A\u3093\u306B\u3082\u3084\u3089\u306A\u3044\u90E8\u9577(\u7B11\uFF09\uFF09",
  "id" : 138458748539764738,
  "created_at" : "2011-11-21 03:28:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138457735749570561",
  "geo" : { },
  "id_str" : "138457946999885824",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5E97\u9577\u3068\u304B\u3084\u308B\u6C17\u6E80\u3005\u3058\u3083\u306A\u3044\u304B",
  "id" : 138457946999885824,
  "in_reply_to_status_id" : 138457735749570561,
  "created_at" : "2011-11-21 03:25:21 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138456882175164416",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u3054\u98EF\u98DF\u3079\u305F\u3089\uFF13\u9650\u9045\u523B\u304B\u30FC\u3068\u601D\u3063\u305F\u3089\uFF13\u9650\u4F11\u8B1B\u3060\u3063\u305F\u3002\u5E78\u305B\u3002",
  "id" : 138456882175164416,
  "created_at" : "2011-11-21 03:21:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138455483198611456",
  "text" : "\u5E74\u9F62\u3068\u6027\u5225\u8A3A\u65AD\uFF12\uFF10\u624D\u5973\u6027\u3063\u3066\u8A00\u308F\u308C\u305F\u2026",
  "id" : 138455483198611456,
  "created_at" : "2011-11-21 03:15:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138455095099662338",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u305F\u3044\u3051\u3069\u5BD2\u3044\u3093\u3060\u3088\u306A",
  "id" : 138455095099662338,
  "created_at" : "2011-11-21 03:14:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138454882238730241",
  "text" : "\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u30DF\u30EB\u30AD\u30A3\u308F\u304B\u308B\u306E\u304B\uFF57\uFF57",
  "id" : 138454882238730241,
  "created_at" : "2011-11-21 03:13:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138454057240100866",
  "text" : "\u5BD2\u3055\u3068\u5E03\u56E3\u304C\u4EF2\u826F\u304F\u79C1\u3092\u30D9\u30C3\u30C9\u306B\u62D8\u675F\u3057\u3066\u3044\u308B",
  "id" : 138454057240100866,
  "created_at" : "2011-11-21 03:09:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138453846384054272",
  "text" : "\u6570\u5B66\u697D\u3057\u3044! RT @gnawty49: \u6570\u5B66\u697D\u3057\u3044\uFF01",
  "id" : 138453846384054272,
  "created_at" : "2011-11-21 03:09:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138443913752096768",
  "text" : "\u3053\u306E\u5B63\u7BC0\u306B\u868A\u304C\u307E\u3060\u3044\u308B\u3093\u3067\u3059\u304B",
  "id" : 138443913752096768,
  "created_at" : "2011-11-21 02:29:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138443793362984960",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 138443793362984960,
  "created_at" : "2011-11-21 02:29:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138443728774889472",
  "text" : "\u5DE6\u8DB3\u3092\u868A\u306B\u523A\u3055\u308C\u305F\u306E\u304B\u75D2\u3044",
  "id" : 138443728774889472,
  "created_at" : "2011-11-21 02:28:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u308A\u305D\u307C\u308D\u30D5\u30ED\u30FC\u30BA\u30F3UDON",
      "screen_name" : "wakahou",
      "indices" : [ 3, 11 ],
      "id_str" : "44877854",
      "id" : 44877854
    }, {
      "name" : "\u5B6B\u6B63\u7FA9",
      "screen_name" : "masason",
      "indices" : [ 13, 21 ],
      "id_str" : "99008565",
      "id" : 99008565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138273209500975104",
  "text" : "RT @wakahou: @masason \u798F\u5CA1\u30C0\u30A4\u30A8\u30FC\u30DB\u30FC\u30AF\u30B9\u65E5\u672C\u4E00\u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002\u6253\u7DDA\u306F\u3064\u306A\u304C\u308B\u306E\u306B\u56DE\u7DDA\u306F\u7E4B\u304C\u3089\u306A\u3044\u3093\u3067\u3059\u306D\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5B6B\u6B63\u7FA9",
        "screen_name" : "masason",
        "indices" : [ 0, 8 ],
        "id_str" : "99008565",
        "id" : 99008565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "138241034621689857",
    "in_reply_to_user_id" : 99008565,
    "text" : "@masason \u798F\u5CA1\u30C0\u30A4\u30A8\u30FC\u30DB\u30FC\u30AF\u30B9\u65E5\u672C\u4E00\u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002\u6253\u7DDA\u306F\u3064\u306A\u304C\u308B\u306E\u306B\u56DE\u7DDA\u306F\u7E4B\u304C\u3089\u306A\u3044\u3093\u3067\u3059\u306D\uFF01",
    "id" : 138241034621689857,
    "created_at" : "2011-11-20 13:03:25 +0000",
    "in_reply_to_screen_name" : "masason",
    "in_reply_to_user_id_str" : "99008565",
    "user" : {
      "name" : "\u3068\u308A\u305D\u307C\u308D\u30D5\u30ED\u30FC\u30BA\u30F3UDON",
      "screen_name" : "wakahou",
      "protected" : false,
      "id_str" : "44877854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604994271947550720\/g1MAvLw9_normal.png",
      "id" : 44877854,
      "verified" : false
    }
  },
  "id" : 138273209500975104,
  "created_at" : "2011-11-20 15:11:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138173490011447296",
  "geo" : { },
  "id_str" : "138249747143200768",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u8FD4\u4FE1\u9045\u304F\u306A\u3063\u305F\u3051\u3069\u59CB\u3081\u305F\u306E\u3067\u3059\u3088",
  "id" : 138249747143200768,
  "in_reply_to_status_id" : 138173490011447296,
  "created_at" : "2011-11-20 13:38:02 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138226752240627712",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 138226752240627712,
  "created_at" : "2011-11-20 12:06:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138171819965431808",
  "text" : "\u587E\u306E\u81EA\u5DF1\u7D39\u4ECB\u30AB\u30FC\u30C9\u306E\u5EA7\u53F3\u306E\u9298\u306E\u6B04\u306B\uFF10\u306F\u81EA\u7136\u6570\u3063\u3066\u66F8\u304D\u305F\u304B\u3063\u305F\u3051\u3069\u9AD8\u6821\u751F\u3092\u6DF7\u4E71\u3055\u305B\u308B\u304B\u3089\u65AD\u5FF5\u3057\u305F",
  "id" : 138171819965431808,
  "created_at" : "2011-11-20 08:28:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138171378779168768",
  "text" : "\u306B\u305B\u307B\u306F\u558B\u3089\u306A\u304D\u3083\u305D\u3053\u305D\u3053\u53EF\u611B\u3044\u3088\u306A\u30FC\u3002",
  "id" : 138171378779168768,
  "created_at" : "2011-11-20 08:26:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138171046812590080",
  "text" : "\u3042\u3089\u3001\u304B\u308F\u3044\u3044",
  "id" : 138171046812590080,
  "created_at" : "2011-11-20 08:25:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5916\u52D9\u5C40\u307D\u3063\u3059\u3080",
      "screen_name" : "c_possum",
      "indices" : [ 3, 12 ],
      "id_str" : "83023370",
      "id" : 83023370
    }, {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "indices" : [ 14, 22 ],
      "id_str" : "20522410",
      "id" : 20522410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/W9PnRC6x",
      "expanded_url" : "http:\/\/twitpic.com\/7grjl6",
      "display_url" : "twitpic.com\/7grjl6"
    } ]
  },
  "geo" : { },
  "id_str" : "138171001728020480",
  "text" : "RT @c_possum: @halhorn \u4ECA\u56DE\u306ENF\u3067\u5199\u771F\u306E\u3088\u3046\u306A\u306B\u305B\u307B\u30AF\u30EA\u30B9\u30DE\u30B9\u30EA\u30FC\u30B9\u3092500\u5186\u307B\u3069\u3067\u8CA9\u58F2\u3057\u305F\u3044\u306E\u3067\u3059\u304C\u3088\u308D\u3057\u3044\u3067\u3057\u3087\u3046\u304B\u3002 http:\/\/t.co\/W9PnRC6x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HAL",
        "screen_name" : "halhorn",
        "indices" : [ 0, 8 ],
        "id_str" : "20522410",
        "id" : 20522410
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/W9PnRC6x",
        "expanded_url" : "http:\/\/twitpic.com\/7grjl6",
        "display_url" : "twitpic.com\/7grjl6"
      } ]
    },
    "geo" : { },
    "id_str" : "138162406043037696",
    "in_reply_to_user_id" : 20522410,
    "text" : "@halhorn \u4ECA\u56DE\u306ENF\u3067\u5199\u771F\u306E\u3088\u3046\u306A\u306B\u305B\u307B\u30AF\u30EA\u30B9\u30DE\u30B9\u30EA\u30FC\u30B9\u3092500\u5186\u307B\u3069\u3067\u8CA9\u58F2\u3057\u305F\u3044\u306E\u3067\u3059\u304C\u3088\u308D\u3057\u3044\u3067\u3057\u3087\u3046\u304B\u3002 http:\/\/t.co\/W9PnRC6x",
    "id" : 138162406043037696,
    "created_at" : "2011-11-20 07:50:59 +0000",
    "in_reply_to_screen_name" : "halhorn",
    "in_reply_to_user_id_str" : "20522410",
    "user" : {
      "name" : "\u5916\u52D9\u5C40\u307D\u3063\u3059\u3080",
      "screen_name" : "c_possum",
      "protected" : false,
      "id_str" : "83023370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3223552583\/b932f0089eb7bc0548877a9d9f7c32a4_normal.jpeg",
      "id" : 83023370,
      "verified" : false
    }
  },
  "id" : 138171001728020480,
  "created_at" : "2011-11-20 08:25:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138170836518580224",
  "text" : "\u30AF\u30EA\u30B9\u30DE\u30B9\u306B\u67CA\u3068\u30C4\u30EA\u30FC\u3092\u6B32\u3057\u304C\u308B\u5973\u306E\u5B50\u306B\u6BCD\u89AA\u304C\u300C\u30AD\u30EA\u30B9\u30C8\u6559\u3058\u3083\u306A\u3044\u3067\u3057\u3087\u300D\u3063\u3066\uFF57\uFF57\uFF57",
  "id" : 138170836518580224,
  "created_at" : "2011-11-20 08:24:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HAL",
      "screen_name" : "halhorn",
      "indices" : [ 0, 8 ],
      "id_str" : "20522410",
      "id" : 20522410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138072299780849666",
  "geo" : { },
  "id_str" : "138076431841361920",
  "in_reply_to_user_id" : 20522410,
  "text" : "@halhorn \u3082\u3057\u304B\u3057\u3066\uFF1A\u9CE5\u597D\u304D\uFF1F",
  "id" : 138076431841361920,
  "in_reply_to_status_id" : 138072299780849666,
  "created_at" : "2011-11-20 02:09:21 +0000",
  "in_reply_to_screen_name" : "halhorn",
  "in_reply_to_user_id_str" : "20522410",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137927148701880320",
  "geo" : { },
  "id_str" : "137930465125474304",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa",
  "id" : 137930465125474304,
  "in_reply_to_status_id" : 137927148701880320,
  "created_at" : "2011-11-19 16:29:20 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137863306043068416",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 137863306043068416,
  "created_at" : "2011-11-19 12:02:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "indices" : [ 3, 10 ],
      "id_str" : "15570902",
      "id" : 15570902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137778971113828352",
  "text" : "RT @m_soba: \u300C\u3058\u3083\u3042\u305D\u306E\u77DB\u3067\u305D\u306E\u76FE\u3092\u7A81\u3044\u305F\u3089\uFF1F\u300D\u3068\u8A00\u308F\u308C\u305F\u5546\u4EBA\u306F\u3001\u81EA\u3089\u76FE\u3092\u69CB\u3048\u3066\u7537\u306B\u7A81\u304B\u305B\u307E\u3057\u305F\u3002\u77DB\u306F\u76FE\u3092\u8CAB\u901A\u3057\u3001\u5546\u4EBA\u306E\u80F8\u306B\u7A81\u304D\u523A\u3055\u308A\u307E\u3057\u305F\u3002\u300C\u304A\u3044\u5546\u4EBA\u3001\u5927\u4E08\u592B\u304B\uFF01\uFF1F\u300D\u300C\u304F\u3063\u2026\u2026\u80F8\u30DD\u30B1\u30C3\u30C8\u306E1\u30BB\u30F3\u30C8\u30B3\u30A4\u30F3\u304C\u52A9\u3051\u3066\u304F\u308C\u305F\u305C\u2026\u2026\u300D\u2015\u2015\u3053\u306E\u3088\u3046\u306B\u3001\u7D00\u5143\u524D\u306E\u4E2D\u56FD\u306B1\u30BB ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"erased_102559\" rel=\"nofollow\"\u003Eerased_102559\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137550237949628416",
    "text" : "\u300C\u3058\u3083\u3042\u305D\u306E\u77DB\u3067\u305D\u306E\u76FE\u3092\u7A81\u3044\u305F\u3089\uFF1F\u300D\u3068\u8A00\u308F\u308C\u305F\u5546\u4EBA\u306F\u3001\u81EA\u3089\u76FE\u3092\u69CB\u3048\u3066\u7537\u306B\u7A81\u304B\u305B\u307E\u3057\u305F\u3002\u77DB\u306F\u76FE\u3092\u8CAB\u901A\u3057\u3001\u5546\u4EBA\u306E\u80F8\u306B\u7A81\u304D\u523A\u3055\u308A\u307E\u3057\u305F\u3002\u300C\u304A\u3044\u5546\u4EBA\u3001\u5927\u4E08\u592B\u304B\uFF01\uFF1F\u300D\u300C\u304F\u3063\u2026\u2026\u80F8\u30DD\u30B1\u30C3\u30C8\u306E1\u30BB\u30F3\u30C8\u30B3\u30A4\u30F3\u304C\u52A9\u3051\u3066\u304F\u308C\u305F\u305C\u2026\u2026\u300D\u2015\u2015\u3053\u306E\u3088\u3046\u306B\u3001\u7D00\u5143\u524D\u306E\u4E2D\u56FD\u306B1\u30BB\u30F3\u30C8\u30B3\u30A4\u30F3\u304C\u3042\u308B\u3053\u3068\u3092\u300C\u77DB\u76FE\u300D\u3068",
    "id" : 137550237949628416,
    "created_at" : "2011-11-18 15:18:26 +0000",
    "user" : {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "protected" : false,
      "id_str" : "15570902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484672991460982784\/o-QnjXOh_normal.png",
      "id" : 15570902,
      "verified" : false
    }
  },
  "id" : 137778971113828352,
  "created_at" : "2011-11-19 06:27:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u305D\u306E\u7B4B\u306E\u4EBA\u3092\u78BA\u5B9F\u306B\u6012\u3089\u305B\u308B\u4E00\u8A00",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137765042065129472",
  "text" : "RT @_flyingmoomin: \u300C\u9AD8\u6821\u306E\u9803\u6570\u5B66\u5F97\u610F\u3060\u3063\u305F\u308F\u30FC \u7C21\u5358\u3060\u3088\u306D\uFF3E\uFF3E\u300D\u300C\u5927\u5B66\u6570\u5B66\u3063\u3066\u3084\u308B\u3053\u3068\u3042\u308B\u306E\uFF1F\uFF3E\uFF3E\u300D\u300C\u6559\u79D1\u66F8\u306B\u8F09\u3063\u3066\u308B\u304B\u3089\u6B63\u3057\u3044\u3093\u3067\u3057\u3087\uFF3E\uFF3E\u300D\u300C\u6570\u5B66\u3063\u3066\u6697\u8A18\u3058\u3083\u3093\uFF3E\uFF3E\u300D\u300C\u3076\u3063\u3061\u3083\u3051\u4F55\u304B\u5F79\u306B\u7ACB\u3063\u3066\u308B\u306E\uFF1F\uFF3E\uFF3E\u300D\u300C\u6B8B\u308A\u306E\u8A08\u7B97\u306F\u7C21\u5358\u3060\u304B\u3089\u8AAD\u8005\u306E\u7DF4\u7FD2\u554F\u984C\u306B\u3059\u308B\u306D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u305D\u306E\u7B4B\u306E\u4EBA\u3092\u78BA\u5B9F\u306B\u6012\u3089\u305B\u308B\u4E00\u8A00",
        "indices" : [ 121, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137758274626920449",
    "text" : "\u300C\u9AD8\u6821\u306E\u9803\u6570\u5B66\u5F97\u610F\u3060\u3063\u305F\u308F\u30FC \u7C21\u5358\u3060\u3088\u306D\uFF3E\uFF3E\u300D\u300C\u5927\u5B66\u6570\u5B66\u3063\u3066\u3084\u308B\u3053\u3068\u3042\u308B\u306E\uFF1F\uFF3E\uFF3E\u300D\u300C\u6559\u79D1\u66F8\u306B\u8F09\u3063\u3066\u308B\u304B\u3089\u6B63\u3057\u3044\u3093\u3067\u3057\u3087\uFF3E\uFF3E\u300D\u300C\u6570\u5B66\u3063\u3066\u6697\u8A18\u3058\u3083\u3093\uFF3E\uFF3E\u300D\u300C\u3076\u3063\u3061\u3083\u3051\u4F55\u304B\u5F79\u306B\u7ACB\u3063\u3066\u308B\u306E\uFF1F\uFF3E\uFF3E\u300D\u300C\u6B8B\u308A\u306E\u8A08\u7B97\u306F\u7C21\u5358\u3060\u304B\u3089\u8AAD\u8005\u306E\u7DF4\u7FD2\u554F\u984C\u306B\u3059\u308B\u306D\uFF3E\uFF3E\u300D #\u305D\u306E\u7B4B\u306E\u4EBA\u3092\u78BA\u5B9F\u306B\u6012\u3089\u305B\u308B\u4E00\u8A00",
    "id" : 137758274626920449,
    "created_at" : "2011-11-19 05:05:06 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 137765042065129472,
  "created_at" : "2011-11-19 05:32:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137754969888665601",
  "text" : "\u3042\u3001\u304A\u8179\u6E1B\u3063\u3066\u308B\u3002\u5BB6\u306B\u307B\u3068\u3093\u3069\u4F55\u306B\u3082\u306A\u3044\u3057\u3001\u96E8\u3060\u3057\u306A\u3041\u3002\u3080\u3045\u3002",
  "id" : 137754969888665601,
  "created_at" : "2011-11-19 04:51:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137736039908376576",
  "text" : "\u79D1\u5B66\u54F2\u5B66\u304C\u8A8D\u77E5\u3055\u308C\u3066\u306A\u3055\u3059\u304E\u3066\u60B2\u3057\u3044\u3051\u3069\u3001\u300C\u5999\u306A\u3053\u3068\u3084\u3063\u3066\u308B\u300D\u4F4D\u306B\u306F\u601D\u3063\u3066\u3082\u3089\u3048\u308B\u304B\u3089\u307E\u3041\u826F\u3044\u304B\u3002\n\u8AAC\u660E\u3059\u308B\u306E\u9762\u5012\u306A\u306E\u3060\u3051\u308C\u3069\u3002",
  "id" : 137736039908376576,
  "created_at" : "2011-11-19 03:36:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3068\u308D\u3068\u3045\u30FC\u3093(ototorototo)",
      "screen_name" : "ototorosama",
      "indices" : [ 3, 15 ],
      "id_str" : "15422884",
      "id" : 15422884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137735757845626880",
  "text" : "RT @ototorosama: \u300C\u3042\u306A\u305F\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u8A9E\u5B66\u306E\u5358\u4F4D\u3067\u3059\u304B\uFF1F\u305D\u308C\u3068\u3082\u5C02\u9580\u306E\u5358\u4F4D\u3067\u3059\u304B\uFF1F\u300D\u300C\u4E21\u65B9\u2026\u2026\u3067\u3059\u3002\u3042\u3068\u822C\u6559\u3082\u2026\u300D\u300C\u3042\u306A\u305F\u306F\u6B63\u76F4\u306A\u4EBA\u3067\u3059\u306D\u300D\u611F\u5FC3\u3057\u305F\u795E\u69D8\u306F\u3082\u30461\u5E74\u306E\u5B66\u751F\u751F\u6D3B\u3092\u304F\u308C\u307E\u3057\u305F\u3002\u300C\uFF94\uFF92\uFF83\uFF70\uFF70\uFF70!!\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27321861645799424",
    "text" : "\u300C\u3042\u306A\u305F\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u8A9E\u5B66\u306E\u5358\u4F4D\u3067\u3059\u304B\uFF1F\u305D\u308C\u3068\u3082\u5C02\u9580\u306E\u5358\u4F4D\u3067\u3059\u304B\uFF1F\u300D\u300C\u4E21\u65B9\u2026\u2026\u3067\u3059\u3002\u3042\u3068\u822C\u6559\u3082\u2026\u300D\u300C\u3042\u306A\u305F\u306F\u6B63\u76F4\u306A\u4EBA\u3067\u3059\u306D\u300D\u611F\u5FC3\u3057\u305F\u795E\u69D8\u306F\u3082\u30461\u5E74\u306E\u5B66\u751F\u751F\u6D3B\u3092\u304F\u308C\u307E\u3057\u305F\u3002\u300C\uFF94\uFF92\uFF83\uFF70\uFF70\uFF70!!\u300D",
    "id" : 27321861645799424,
    "created_at" : "2011-01-18 11:10:14 +0000",
    "user" : {
      "name" : "\u3068\u3068\u308D\u3068\u3045\u30FC\u3093(ototorototo)",
      "screen_name" : "ototorosama",
      "protected" : false,
      "id_str" : "15422884",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433795644025618432\/jpOvA4va_normal.jpeg",
      "id" : 15422884,
      "verified" : false
    }
  },
  "id" : 137735757845626880,
  "created_at" : "2011-11-19 03:35:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137734968918020096",
  "text" : "\u7D50\u57CE\u5148\u751F\u5927\u597D\u304D\u3060\uFF57\uFF57\uFF57\uFF57",
  "id" : 137734968918020096,
  "created_at" : "2011-11-19 03:32:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30E9\u30B9\u30DC\u30B9\u3068\u805E\u3044\u3066\u4E00\u756A\u6700\u521D\u306B\u601D\u3044\u6D6E\u304B\u3076\u30AD\u30E3\u30E9",
      "indices" : [ 17, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137734915537113088",
  "text" : "RT @hyuki: \u5343\u77F3\u64AB\u5B50  #\u30E9\u30B9\u30DC\u30B9\u3068\u805E\u3044\u3066\u4E00\u756A\u6700\u521D\u306B\u601D\u3044\u6D6E\u304B\u3076\u30AD\u30E3\u30E9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B Pro  for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u30E9\u30B9\u30DC\u30B9\u3068\u805E\u3044\u3066\u4E00\u756A\u6700\u521D\u306B\u601D\u3044\u6D6E\u304B\u3076\u30AD\u30E3\u30E9",
        "indices" : [ 6, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137734681281048576",
    "text" : "\u5343\u77F3\u64AB\u5B50  #\u30E9\u30B9\u30DC\u30B9\u3068\u805E\u3044\u3066\u4E00\u756A\u6700\u521D\u306B\u601D\u3044\u6D6E\u304B\u3076\u30AD\u30E3\u30E9",
    "id" : 137734681281048576,
    "created_at" : "2011-11-19 03:31:21 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 137734915537113088,
  "created_at" : "2011-11-19 03:32:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hiroyuki Miyoshi",
      "screen_name" : "metaphusika",
      "indices" : [ 3, 15 ],
      "id_str" : "27468098",
      "id" : 27468098
    }, {
      "name" : "\u5C0F\u5C71 \u864E",
      "screen_name" : "torakoyama",
      "indices" : [ 27, 38 ],
      "id_str" : "115028565",
      "id" : 115028565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u79D1\u54F22011",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137734127947493377",
  "text" : "RT @metaphusika: \u3053\u3093\u306A\u611F\u3058\uFF1F RT @torakoyama: \u79D1\u54F2\u306B\u53C2\u52A0\u3057\u3066\u308B\u307F\u306A\u3055\u3093\u3001\u3067\u304D\u308C\u3070\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u4F7F\u3063\u3066\u4E0B\u3055\u3044\u3002#\u79D1\u54F22011 \u3068\u304B\u3067\u3044\u3044\u306E\u3067\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5C0F\u5C71 \u864E",
        "screen_name" : "torakoyama",
        "indices" : [ 10, 21 ],
        "id_str" : "115028565",
        "id" : 115028565
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u79D1\u54F22011",
        "indices" : [ 53, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137733369227251712",
    "text" : "\u3053\u3093\u306A\u611F\u3058\uFF1F RT @torakoyama: \u79D1\u54F2\u306B\u53C2\u52A0\u3057\u3066\u308B\u307F\u306A\u3055\u3093\u3001\u3067\u304D\u308C\u3070\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u4F7F\u3063\u3066\u4E0B\u3055\u3044\u3002#\u79D1\u54F22011 \u3068\u304B\u3067\u3044\u3044\u306E\u3067\u3002",
    "id" : 137733369227251712,
    "created_at" : "2011-11-19 03:26:08 +0000",
    "user" : {
      "name" : "Hiroyuki Miyoshi",
      "screen_name" : "metaphusika",
      "protected" : false,
      "id_str" : "27468098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114000033\/muga_normal.jpg",
      "id" : 27468098,
      "verified" : false
    }
  },
  "id" : 137734127947493377,
  "created_at" : "2011-11-19 03:29:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 0, 12 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137733500924203008",
  "geo" : { },
  "id_str" : "137733845767290880",
  "in_reply_to_user_id" : 131856285,
  "text" : "@momo_miku28 \u6614\u8AAD\u3093\u3060\u306E\u3067\u3046\u308D\u899A\u3048\u3067\u3059\u304C\u4E0D\u601D\u8B70\u306B\u9762\u767D\u304B\u3063\u305F\u8A18\u61B6\u304C\u3042\u308A\u307E\u3059\u3002\u8AAD\u307F\u8FD4\u305D\u3046\u304B\u306A\u30FC\u3002",
  "id" : 137733845767290880,
  "in_reply_to_status_id" : 137733500924203008,
  "created_at" : "2011-11-19 03:28:02 +0000",
  "in_reply_to_screen_name" : "momo_miku28",
  "in_reply_to_user_id_str" : "131856285",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137733682977968128",
  "text" : "\u5B9F\u5BB6\u304C\u4E09\u9DF9\u3068\u5409\u7965\u5BFA\u3068\u897F\u837B\u306E\u9593\u304F\u3089\u3044\u3060\u304B\u3089\u6E80\u8DB3\uFF08\u2190\u90FD\u5408\u304C\u60AA\u3044\u3068\uFF32\uFF34\u3057\u306A\u3044",
  "id" : 137733682977968128,
  "created_at" : "2011-11-19 03:27:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137719485581889536",
  "text" : "100\u2026",
  "id" : 137719485581889536,
  "created_at" : "2011-11-19 02:30:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan_kyoto",
      "indices" : [ 3, 17 ],
      "id_str" : "232833288",
      "id" : 232833288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kyoto",
      "indices" : [ 104, 110 ]
    }, {
      "text" : "rainy_nine",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137719446407102464",
  "text" : "RT @ninetan_kyoto: 0.1\u3349\u4EE5\u4E0A\u306E\u964D\u6C34\u78BA\u7387\u306F\uFF0C\n\u6842\uFF0811\u6642\u53F0100\uFF05\uFF0C12\u6642\u53F0100\uFF05\uFF09\uFF0C\n\u5B87\u6CBB\uFF0811\u6642\u53F0100\uFF05\uFF0C12\u6642\u53F0100\uFF05\uFF09\uFF0C\n\u5409\u7530\uFF0811\u6642\u53F0100\uFF05\uFF0C12\u6642\u53F0100\uFF05\uFF09\n\u306A\u306E\u3063 #kyoto #rainy_nine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/imoz.jp\/\" rel=\"nofollow\"\u003ESX\u306A\u3044\u3093\u96E8\u96F2\u30EC\u30FC\u30C0\u30FC\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kyoto",
        "indices" : [ 85, 91 ]
      }, {
        "text" : "rainy_nine",
        "indices" : [ 92, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137719270607044609",
    "text" : "0.1\u3349\u4EE5\u4E0A\u306E\u964D\u6C34\u78BA\u7387\u306F\uFF0C\n\u6842\uFF0811\u6642\u53F0100\uFF05\uFF0C12\u6642\u53F0100\uFF05\uFF09\uFF0C\n\u5B87\u6CBB\uFF0811\u6642\u53F0100\uFF05\uFF0C12\u6642\u53F0100\uFF05\uFF09\uFF0C\n\u5409\u7530\uFF0811\u6642\u53F0100\uFF05\uFF0C12\u6642\u53F0100\uFF05\uFF09\n\u306A\u306E\u3063 #kyoto #rainy_nine",
    "id" : 137719270607044609,
    "created_at" : "2011-11-19 02:30:07 +0000",
    "user" : {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan_kyoto",
      "protected" : false,
      "id_str" : "232833288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1203943257\/ninetan-kyoto_normal.png",
      "id" : 232833288,
      "verified" : false
    }
  },
  "id" : 137719446407102464,
  "created_at" : "2011-11-19 02:30:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137713124617883648",
  "geo" : { },
  "id_str" : "137713418923819009",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u60AA\u304F\u306A\u3044\u306E\u304B\uFF57\uFF57\uFF57",
  "id" : 137713418923819009,
  "in_reply_to_status_id" : 137713124617883648,
  "created_at" : "2011-11-19 02:06:52 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137711888237731840",
  "text" : "\u96E8\u30FC\u3042\u3081\u30FC\u30A2\u30E1\u30FC",
  "id" : 137711888237731840,
  "created_at" : "2011-11-19 02:00:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137709429486403584",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 137709429486403584,
  "created_at" : "2011-11-19 01:51:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137709341208879107",
  "text" : "\u3053\u30532\u30013\u65E5\u306E\u4E88\u5B9A\u304C\u306A\u3044\u6DF7\u305C\u306B\u4E00\u65E5\u3067\u307E\u3068\u3081\u305F\u3088\u3046\u306A\u5922\u3092\u898B\u305F\u3002",
  "id" : 137709341208879107,
  "created_at" : "2011-11-19 01:50:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gohantabeyo",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/MmWJoonM",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=tohru1101",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "137634437335760896",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001tohru1101\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/MmWJoonM #gohantabeyo",
  "id" : 137634437335760896,
  "created_at" : "2011-11-18 20:53:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137584407899947008",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 137584407899947008,
  "created_at" : "2011-11-18 17:34:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 7, 18 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137382535255699456",
  "text" : "\u30B0\u30B5\u30C3 RT @magokoro84: \u81EA\u5206\u306E\u3084\u308A\u305F\u3044\u3053\u3068\u304C\u6587\u5B66\u90E8\u3067\u5408\u3063\u3066\u305F\u306E\u304B\u3069\u3046\u304B\u7D50\u69CB\u5FAE\u5999\u3060\u3063\u305F\u308A\u3057\u307E\u3059",
  "id" : 137382535255699456,
  "created_at" : "2011-11-18 04:12:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u707C\u773C\u306E\u3042\u304B\u2606\u306D\u3053",
      "screen_name" : "math_neko",
      "indices" : [ 8, 18 ],
      "id_str" : "232545906",
      "id" : 232545906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137374790301396993",
  "text" : "\u3042\u308B\u3042\u308B RT @math_neko: \u3057\u304B\u3057\u6BCE\u65E5\u6BCE\u65E5\u30AD\u30C3\u30C8\u30AB\u30C3\u30C8\u3067\u98FD\u304D\u306A\u3044\u306E\u304B\u3001\u304A\u8179\u6E1B\u3089\u306A\u3044\u306E\u304B\u3068\u52D8\u3050\u3063\u3066\u3057\u307E\u3046",
  "id" : 137374790301396993,
  "created_at" : "2011-11-18 03:41:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u707C\u773C\u306E\u3042\u304B\u2606\u306D\u3053",
      "screen_name" : "math_neko",
      "indices" : [ 3, 13 ],
      "id_str" : "232545906",
      "id" : 232545906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137374744092737536",
  "text" : "RT @math_neko: \u30DF\u30EB\u30AB\u3055\u3093\u306E\u98DF\u3079\u3066\u308B\u5730\u57DF\u9650\u5B9A\u30AD\u30C3\u30C8\u30AB\u30C3\u30C8\u306F\u5B9F\u5728\u3059\u308B\u306E\u3067\u3057\u3087\u3046\u304B\u2026\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137374249928237056",
    "text" : "\u30DF\u30EB\u30AB\u3055\u3093\u306E\u98DF\u3079\u3066\u308B\u5730\u57DF\u9650\u5B9A\u30AD\u30C3\u30C8\u30AB\u30C3\u30C8\u306F\u5B9F\u5728\u3059\u308B\u306E\u3067\u3057\u3087\u3046\u304B\u2026\u3002",
    "id" : 137374249928237056,
    "created_at" : "2011-11-18 03:39:08 +0000",
    "user" : {
      "name" : "\u707C\u773C\u306E\u3042\u304B\u2606\u306D\u3053",
      "screen_name" : "math_neko",
      "protected" : false,
      "id_str" : "232545906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2451550753\/eyaax2hgo0ps3ldw7t1a_normal.png",
      "id" : 232545906,
      "verified" : false
    }
  },
  "id" : 137374744092737536,
  "created_at" : "2011-11-18 03:41:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137374134979133440",
  "text" : "\u305D\u308D\u305D\u308D\u5E03\u56E3\u304B\u3089\u51FA\u306A\u3044\u3068\uFF13\u9650\u9045\u523B",
  "id" : 137374134979133440,
  "created_at" : "2011-11-18 03:38:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137219895552253952",
  "text" : "\u305D\u308D\u305D\u308D\u5BDD\u308B\u3075\u308A\u3057\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 137219895552253952,
  "created_at" : "2011-11-17 17:25:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137218491878080512",
  "geo" : { },
  "id_str" : "137219805789962240",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307E\u3041\u76F8\u624B\u3057\u3066\u3089\u3093\u306A\u3044\u3082\u3093\u306A\u30FC",
  "id" : 137219805789962240,
  "in_reply_to_status_id" : 137218491878080512,
  "created_at" : "2011-11-17 17:25:25 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137217879891386369",
  "geo" : { },
  "id_str" : "137218217461563392",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u30EA\u30D7\u30E9\u30A4\u3068\u304BDM\u3068\u304B\u306F\u306A\u3044\u306E\uFF1F\u3068\u7D20\u4EBA\u8003\u3048\u3067\u805E\u3044\u3066\u307F\u308B",
  "id" : 137218217461563392,
  "in_reply_to_status_id" : 137217879891386369,
  "created_at" : "2011-11-17 17:19:07 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137217791811010561",
  "text" : "@nartakio \u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 137217791811010561,
  "created_at" : "2011-11-17 17:17:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137217710361812992",
  "text" : "\u3042\u3068\u304A\u306A\u304B\u3078\u3063\u305F",
  "id" : 137217710361812992,
  "created_at" : "2011-11-17 17:17:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137217498180370432",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u6D0B\u66F8\u306F\u6C17\u306B\u306A\u308B\u306A\u30FC",
  "id" : 137217498180370432,
  "created_at" : "2011-11-17 17:16:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137215978361724928",
  "geo" : { },
  "id_str" : "137216122373160960",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u5B9F\u306F\u884C\u3063\u305F\u3053\u3068\u306A\u3044\u3093\u3060\u3088\u306D\u3047\u2190",
  "id" : 137216122373160960,
  "in_reply_to_status_id" : 137215978361724928,
  "created_at" : "2011-11-17 17:10:47 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137215452131758080",
  "geo" : { },
  "id_str" : "137215697930563584",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u306D\u3053\u30D0\u30B9\u2026",
  "id" : 137215697930563584,
  "in_reply_to_status_id" : 137215452131758080,
  "created_at" : "2011-11-17 17:09:06 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137215617794187264",
  "text" : "\u30A2\u30A4\u30C9\u30EB\u3068\u304B\u82B8\u80FD\u754C\u306B\u306F\u305F\u3060\u7A4F\u3084\u304B\u306B\u3001\u8208\u5473\u304C\u306A\u3044",
  "id" : 137215617794187264,
  "created_at" : "2011-11-17 17:08:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3064\u3044\u305F\u3053\u3068\u306A\u3057",
      "screen_name" : "tsuitakotonasi",
      "indices" : [ 3, 18 ],
      "id_str" : "69892984",
      "id" : 69892984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137215458368692225",
  "text" : "RT @tsuitakotonasi: \u6D41\u884C\u308A\u306E\u30A2\u30A4\u30C9\u30EB\u306B\u300E\u3042\u3093\u306A\u3093\u30D6\u30B9\u3058\u3083\u3093\u3069\u3053\u304C\u3044\u3044\u306E\u300F\u307F\u305F\u3044\u306A\u3053\u3068\u3057\u304B\u8A00\u3048\u306A\u3044\u4EBA\u306F\u643A\u5E2F\u5C0F\u8AAC\u8AAD\u3093\u3067\u6CE3\u3051\u308B\u3063\u3066\u8A00\u3063\u3066\u308B\u5C64\u3068\u540C\u3058\u5C48\u8A17\u306E\u306A\u3055\u3092\u611F\u3058\u308B\u306E\u3067\u6B63\u76F4\u82E6\u624B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137191640929533952",
    "text" : "\u6D41\u884C\u308A\u306E\u30A2\u30A4\u30C9\u30EB\u306B\u300E\u3042\u3093\u306A\u3093\u30D6\u30B9\u3058\u3083\u3093\u3069\u3053\u304C\u3044\u3044\u306E\u300F\u307F\u305F\u3044\u306A\u3053\u3068\u3057\u304B\u8A00\u3048\u306A\u3044\u4EBA\u306F\u643A\u5E2F\u5C0F\u8AAC\u8AAD\u3093\u3067\u6CE3\u3051\u308B\u3063\u3066\u8A00\u3063\u3066\u308B\u5C64\u3068\u540C\u3058\u5C48\u8A17\u306E\u306A\u3055\u3092\u611F\u3058\u308B\u306E\u3067\u6B63\u76F4\u82E6\u624B\u3002",
    "id" : 137191640929533952,
    "created_at" : "2011-11-17 15:33:30 +0000",
    "user" : {
      "name" : "\u3064\u3044\u305F\u3053\u3068\u306A\u3057",
      "screen_name" : "tsuitakotonasi",
      "protected" : false,
      "id_str" : "69892984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515207057188728832\/yvIv3JOi_normal.png",
      "id" : 69892984,
      "verified" : false
    }
  },
  "id" : 137215458368692225,
  "created_at" : "2011-11-17 17:08:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137214480017920000",
  "geo" : { },
  "id_str" : "137215112460255232",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat \u5171\u5317\u306E\u3069\u3063\u304B\u3063\u3066\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u304C\u8A00\u3063\u3066\u307E\u3057\u305F\u30FC",
  "id" : 137215112460255232,
  "in_reply_to_status_id" : 137214480017920000,
  "created_at" : "2011-11-17 17:06:46 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137213973195001857",
  "text" : "\u30D4\u30F3\u30C9\u30E9\u3063\u3066\u5E73\u548C\u30C9\u30E9\uFF11\u30672000\u70B9(\u89AA\u306A\u30892900\u70B9\uFF09\u3058\u3083\u306A\u3044\u3093\u3067\u3059\u304B(\u3057\u308D\u3081",
  "id" : 137213973195001857,
  "created_at" : "2011-11-17 17:02:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137210309168476160",
  "geo" : { },
  "id_str" : "137210982941466624",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4FFA\u3068\u5168\u304F\u540C\u30D7\u30E9\u30F3\uFF57\uFF57",
  "id" : 137210982941466624,
  "in_reply_to_status_id" : 137210309168476160,
  "created_at" : "2011-11-17 16:50:22 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137209292129443840",
  "geo" : { },
  "id_str" : "137209658719997952",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u306D\u3047\u3044\u307E\u3069\u3093\u306A\u6C17\u6301\u3061\uFF1F",
  "id" : 137209658719997952,
  "in_reply_to_status_id" : 137209292129443840,
  "created_at" : "2011-11-17 16:45:06 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/OQ3UBz3V",
      "expanded_url" : "http:\/\/shindanmaker.com\/120244",
      "display_url" : "shindanmaker.com\/120244"
    } ]
  },
  "geo" : { },
  "id_str" : "137208958485151744",
  "text" : "m9(\uFF9F\u2200\uFF9F)\u300C\u3042\u3063end313124\u3060\uFF01\u300D(\uFF9F\u2200\uFF9F)\u300C\u30DB\u30F3\u30C8\u3060\uFF01\u300D(\uFF9F\u2200\uFF9F)\u300C\u3059\u3052\u3047\u7206\u767A\u3057\u305D\u3046\uFF01\u300D(\uFF9F\u2200\uFF9F)\u300C\u30DE\u30B8\u3067\u7206\u767A\u3057\u305D\u3046\u3058\u3083\u3093\uFF01\u300D http:\/\/t.co\/OQ3UBz3V  \u7206\u767A\u3057\u3059\u3046",
  "id" : 137208958485151744,
  "created_at" : "2011-11-17 16:42:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137207147162382336",
  "text" : "\u5B66\u796D\u3067KU\u30AF\u30E9\u30B9\u30BF\u306E\u30AA\u30D5\u90E8\u5C4B\u304C\u3042\u308B\u3089\u3057\u3044\u3002\u30EF\u30F3\u30C1\u30E3\u30F3\u3042\u308B\u3002",
  "id" : 137207147162382336,
  "created_at" : "2011-11-17 16:35:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137206499029159936",
  "geo" : { },
  "id_str" : "137206705388920832",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u304A\u304B\u3048\u308A\uFF67\uFF01",
  "id" : 137206705388920832,
  "in_reply_to_status_id" : 137206499029159936,
  "created_at" : "2011-11-17 16:33:22 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nanki",
      "screen_name" : "nanki",
      "indices" : [ 3, 9 ],
      "id_str" : "7908022",
      "id" : 7908022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137206547125256193",
  "text" : "RT @nanki: \u51FA\u753A\u306B\u30B9\u30BF\u30D0\u51FA\u6765\u3066\u3001\u51FA\u753A\u3075\u305F\u3070\u3068\u7D1B\u3089\u308F\u3057\u3044\u72B6\u6CC1\u306B\u306A\u3089\u306A\u3044\u304B\u306A\u3041\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137204827187970048",
    "text" : "\u51FA\u753A\u306B\u30B9\u30BF\u30D0\u51FA\u6765\u3066\u3001\u51FA\u753A\u3075\u305F\u3070\u3068\u7D1B\u3089\u308F\u3057\u3044\u72B6\u6CC1\u306B\u306A\u3089\u306A\u3044\u304B\u306A\u3041\u3002",
    "id" : 137204827187970048,
    "created_at" : "2011-11-17 16:25:54 +0000",
    "user" : {
      "name" : "nanki",
      "screen_name" : "nanki",
      "protected" : false,
      "id_str" : "7908022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562615562707038208\/XLS9kPms_normal.png",
      "id" : 7908022,
      "verified" : false
    }
  },
  "id" : 137206547125256193,
  "created_at" : "2011-11-17 16:32:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137138531222028288",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 137138531222028288,
  "created_at" : "2011-11-17 12:02:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137042996100210688",
  "text" : "\u6570\u6A2A\u30BB\u30DF\u30CA\u30FC\uFF67\uFF01",
  "id" : 137042996100210688,
  "created_at" : "2011-11-17 05:42:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137002658623004672",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 137002658623004672,
  "created_at" : "2011-11-17 03:02:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137002053405913088",
  "geo" : { },
  "id_str" : "137002340631851008",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u306B\u305B\u307B\u30FC\u3063\uFF01",
  "id" : 137002340631851008,
  "in_reply_to_status_id" : 137002053405913088,
  "created_at" : "2011-11-17 03:01:18 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u305F\u308C",
      "screen_name" : "Hetare_wexy",
      "indices" : [ 3, 15 ],
      "id_str" : "359458972",
      "id" : 359458972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136828808316731392",
  "text" : "RT @Hetare_wexy: TL\u306E\u6D41\u308C\u306F\u7D76\u3048\u305A\u3057\u3066\u3001\u3057\u304B\u3082\u3082\u3068\u306Epost\u306B\u3042\u3089\u305A\u3002\u3088\u3069\u307F\u306B\u6D6E\u304B\u3076RT\u306F\u3001\u304B\u3064\u6D88\u3048\u304B\u3064\u7D50\u3073\u3066\u3001\u4E45\u3057\u304F\u3068\u3069\u307E\u308A\u305F\u308B\u305F\u3081\u3057\u306A\u3057\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "136828694160351235",
    "text" : "TL\u306E\u6D41\u308C\u306F\u7D76\u3048\u305A\u3057\u3066\u3001\u3057\u304B\u3082\u3082\u3068\u306Epost\u306B\u3042\u3089\u305A\u3002\u3088\u3069\u307F\u306B\u6D6E\u304B\u3076RT\u306F\u3001\u304B\u3064\u6D88\u3048\u304B\u3064\u7D50\u3073\u3066\u3001\u4E45\u3057\u304F\u3068\u3069\u307E\u308A\u305F\u308B\u305F\u3081\u3057\u306A\u3057\u3002",
    "id" : 136828694160351235,
    "created_at" : "2011-11-16 15:31:17 +0000",
    "user" : {
      "name" : "\u3078\u305F\u308C",
      "screen_name" : "Hetare_wexy",
      "protected" : false,
      "id_str" : "359458972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059103041\/dbeacab501e1226adf3d3e8b853c4d86_normal.jpeg",
      "id" : 359458972,
      "verified" : false
    }
  },
  "id" : 136828808316731392,
  "created_at" : "2011-11-16 15:31:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136798023081668609",
  "geo" : { },
  "id_str" : "136798693729898497",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u304A\u306D\u30FC\u3055\u3093\u306E\u305D\u3046\u3044\u3046\u3068\u3053\u308D\u306F\u3046\u3089\u3084\u307E\u3057\u3044\u3067\u3059\u3002\u81EA\u5206\u306F\u4F55\u304C\u3084\u308A\u305F\u3044\u306E\u3084\u3089\u2026\u3002",
  "id" : 136798693729898497,
  "in_reply_to_status_id" : 136798023081668609,
  "created_at" : "2011-11-16 13:32:04 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136798270465904640",
  "text" : "\u3042\u306E\u9EC4\u8272\u3044\u30C7\u30B6\u30A4\u30F3\u597D\u304D\u306A\u3093\u3060\u3051\u3069\u306A\u3041\u3002\u30EB\u30CD\u3082\u300C11\u6708\u672B\u3067\u8FD4\u54C1\u3057\u307E\u3059\uFF08\u5272\u5F15\u306F\u666E\u6BB5\u901A\u308A\u3067\u3059\uFF77\uFF98\uFF6F\uFF09\u300D\u3068\u304B\u8A00\u3063\u3066\u306A\u3044\u3067\u5B89\u304F\u3057\u305F\u3089\u8CB7\u3046\u4EBA\u3082\u3044\u308B\u3060\u308D\u3046\u306B\u3002",
  "id" : 136798270465904640,
  "created_at" : "2011-11-16 13:30:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136797954890674177",
  "text" : "\u30EB\u30CD\u3067\u898B\u305F\u3051\u3069\u30B7\u30E5\u30D7\u30EA\u30F3\u30AC\u30FC\u3063\u3066\u548C\u66F8\u90E8\u9580\u64A4\u9000\u3057\u3061\u3083\u3046\u306E\uFF1F",
  "id" : 136797954890674177,
  "created_at" : "2011-11-16 13:29:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136797107603505152",
  "text" : "\u3068\u3042\u308B\u79D1\u5B66\u306E\u8D85\u9650\u5E30\u7D0D\u7832\n\u3060\u308C\u304B\u305D\u308C\u3089\u3057\u3044\u8AAD\u307F\u65B9\u8003\u3048\u3066\u2191",
  "id" : 136797107603505152,
  "created_at" : "2011-11-16 13:25:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 7, 14 ],
      "id_str" : "50640629",
      "id" : 50640629
    }, {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 28, 34 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 52, 59 ],
      "id_str" : "50640629",
      "id" : 50640629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136796854716334080",
  "text" : "\u5E30\u7D0D\u7832 RT @igaris \u30D4\u30BF\u30B4\u30E9\u30B9\u306E\u624B\u5165\u308A RT @hyuki: \u30A8\u30E9\u30C8\u30B9\u30C6\u30CD\u30B9\u306E\u3001\u53E4\u3044\uFF1F RT @igaris: \u30E6\u30FC\u30AF\u30EA\u30C3\u30C9\u306E\u76F8\u4E92\u6276\u52A9\u6CD5",
  "id" : 136796854716334080,
  "created_at" : "2011-11-16 13:24:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136761559522349057",
  "text" : "\u5BD2\u3044\u3068\u3044\u3046\u3088\u308A\u3001\u51B7\u305F\u3044\u3002\u624B\u5148\u8DB3\u5148\u3002",
  "id" : 136761559522349057,
  "created_at" : "2011-11-16 11:04:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136653557511360512",
  "geo" : { },
  "id_str" : "136653757063774208",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u4FFA\u306B\u306F\u89E3\u3089\u3093",
  "id" : 136653757063774208,
  "in_reply_to_status_id" : 136653557511360512,
  "created_at" : "2011-11-16 03:56:09 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136652545425809409",
  "geo" : { },
  "id_str" : "136653391446294530",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u97F3\u30B2\u30FC\u304B\u3088",
  "id" : 136653391446294530,
  "in_reply_to_status_id" : 136652545425809409,
  "created_at" : "2011-11-16 03:54:42 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136652580314025984",
  "text" : "\u306B\u305B\u307B\u306F\u300C\u3046\u306B\u3085\u30FC\u300D\u3067\u7518\u3044\u3082\u306E\u3068\u5206\u304B\u308B\u306E\u304B",
  "id" : 136652580314025984,
  "created_at" : "2011-11-16 03:51:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136652300537184256",
  "geo" : { },
  "id_str" : "136652412755787776",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u5272\u3068\u597D\u304D",
  "id" : 136652412755787776,
  "in_reply_to_status_id" : 136652300537184256,
  "created_at" : "2011-11-16 03:50:48 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136652115329294337",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u3046\u306B\u3085\u30FC",
  "id" : 136652115329294337,
  "created_at" : "2011-11-16 03:49:37 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136651877319319552",
  "text" : "\u4F4D\u6570\uFF16\u306E\u7FA4\u306E\u5206\u985E\u2026\u7D50\u5C40\u5BFE\u79F0\u7FA4\u3068\u5DE1\u56DE\u7FA4\u3057\u304B\u306A\u3044\uFF1F",
  "id" : 136651877319319552,
  "created_at" : "2011-11-16 03:48:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136651266439921664",
  "geo" : { },
  "id_str" : "136651515543830528",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u30ED\u30FC\u30BC\u30F3\u597D\u304D\u306A\u306E\uFF1F",
  "id" : 136651515543830528,
  "in_reply_to_status_id" : 136651266439921664,
  "created_at" : "2011-11-16 03:47:14 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136650986860199936",
  "text" : "\u30DE\u30B8\u304B\u3088",
  "id" : 136650986860199936,
  "created_at" : "2011-11-16 03:45:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E5\u30A2\u30AB\u30A4\u30B7\u30E3\u30A4\u30F3\u5C0F\u9CE5\u904A",
      "screen_name" : "taka_nashi",
      "indices" : [ 3, 14 ],
      "id_str" : "151319183",
      "id" : 151319183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136650882317160448",
  "text" : "RT @taka_nashi: \u305D\u308D\u305D\u308D\u307F\u3093\u306A\u300C\u30AB\u30EC\u30ED\u30B0\u300D\u306E\u4E8B\u5FD8\u308C\u3066\u308B\u3093\u3060\u308D\u3046\u306A\u30FC\u3001\u3068\u601D\u3063\u305F\u3089\u300C\u30AB\u30EC\u30ED\u30B02\u300D\u304C\u3042\u3063\u305F\u4E8B\u306B\u9A5A\u6115",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "136644470996348928",
    "text" : "\u305D\u308D\u305D\u308D\u307F\u3093\u306A\u300C\u30AB\u30EC\u30ED\u30B0\u300D\u306E\u4E8B\u5FD8\u308C\u3066\u308B\u3093\u3060\u308D\u3046\u306A\u30FC\u3001\u3068\u601D\u3063\u305F\u3089\u300C\u30AB\u30EC\u30ED\u30B02\u300D\u304C\u3042\u3063\u305F\u4E8B\u306B\u9A5A\u6115",
    "id" : 136644470996348928,
    "created_at" : "2011-11-16 03:19:15 +0000",
    "user" : {
      "name" : "\u30AD\u30E5\u30A2\u30AB\u30A4\u30B7\u30E3\u30A4\u30F3\u5C0F\u9CE5\u904A",
      "screen_name" : "taka_nashi",
      "protected" : false,
      "id_str" : "151319183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598106211997749248\/sAQfQxqY_normal.jpg",
      "id" : 151319183,
      "verified" : false
    }
  },
  "id" : 136650882317160448,
  "created_at" : "2011-11-16 03:44:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136649923587354624",
  "text" : "5555\u30C4\u30A4\u30FC\u30C8\uFF67\uFF01",
  "id" : 136649923587354624,
  "created_at" : "2011-11-16 03:40:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136649551573565440",
  "text" : "\u6700\u8FD1\u306E\u5348\u524D\u4E2D\u306E\u7720\u3055\u306F\u7570\u5E38\u3060\u306A\u30FC",
  "id" : 136649551573565440,
  "created_at" : "2011-11-16 03:39:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136648822251200512",
  "text" : "\u6628\u591C\u30AB\u30E9\u30AA\u30B1\u884C\u3063\u305F\u3051\u3069\u7089\u5FC3\u878D\u89E3\u306F\u58F0\u304C\u51FA\u306A\u304B\u3063\u305F\u306A\u3041\u3002\n\u9AD8\u3044\u58F0\u3063\u3066\u7DF4\u7FD2\u3067\u51FA\u308B\u3082\u3093\u306A\u306E\u304B\u306A\u3002",
  "id" : 136648822251200512,
  "created_at" : "2011-11-16 03:36:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136648217386430465",
  "text" : "\u3053\u306E\u90E8\u5C4B\u5BD2\u3044\u2026\u4F55\u3067\u7A93\u969B\u306E\u4EBA\u7A93\u958B\u3051\u3066\u308B\u306E\u3055",
  "id" : 136648217386430465,
  "created_at" : "2011-11-16 03:34:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 22, 28 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "\u3068\u3082",
      "screen_name" : "tomo37",
      "indices" : [ 30, 37 ],
      "id_str" : "26393410",
      "id" : 26393410
    }, {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 38, 51 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136647444900495360",
  "text" : "\u3069\u3046\u3084\u3063\u3066\u624B\u306B\u5165\u308C\u305F\u3089\u3044\u3044\u3093\u3067\u3057\u3087\u3046 RT @hyuki: @tomo37 @ellipticurve \u65E5\u672C\u306E\u66F8\u5E97\u306B\u306F\u4E26\u3073\u307E\u305B\u3093\u306E\u3067\u3054\u6CE8\u610F\u3002",
  "id" : 136647444900495360,
  "created_at" : "2011-11-16 03:31:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136647149843779584",
  "text" : "\u3042\u3001\u3082\u3046\u5C11\u3057\u30675555post\u3060",
  "id" : 136647149843779584,
  "created_at" : "2011-11-16 03:29:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136414006364737536",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 136414006364737536,
  "created_at" : "2011-11-15 12:03:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136318817579171840",
  "geo" : { },
  "id_str" : "136319991963336704",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u3061\u3087\u3063\u3068\u4F55\uFF1F\uFF57\uFF57",
  "id" : 136319991963336704,
  "in_reply_to_status_id" : 136318817579171840,
  "created_at" : "2011-11-15 05:49:53 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136318313398673408",
  "geo" : { },
  "id_str" : "136318538553114624",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u4EE5\u5F8C\u6C17\u3092\u3064\u3051\u3066",
  "id" : 136318538553114624,
  "in_reply_to_status_id" : 136318313398673408,
  "created_at" : "2011-11-15 05:44:06 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136318272311263232",
  "text" : "\u6795\u4E8C\u3064\u91CD\u306D\u3066\u5BDD\u305F\u3089\u3061\u3087\u3063\u3068\u5BDD\u9055\u3048\u305F\u611F\u3058\u306B\u306A\u3063\u305F",
  "id" : 136318272311263232,
  "created_at" : "2011-11-15 05:43:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136317563423555584",
  "geo" : { },
  "id_str" : "136318065251061760",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u4F55\u8A00\u3063\u3066\u3093\u306E\uFF1F",
  "id" : 136318065251061760,
  "in_reply_to_status_id" : 136317563423555584,
  "created_at" : "2011-11-15 05:42:14 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136317048530804736",
  "geo" : { },
  "id_str" : "136317440069091328",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u3075\u3075\u3075",
  "id" : 136317440069091328,
  "in_reply_to_status_id" : 136317048530804736,
  "created_at" : "2011-11-15 05:39:45 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136316873410228224",
  "text" : "\u3075\u3075\u3075",
  "id" : 136316873410228224,
  "created_at" : "2011-11-15 05:37:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136314092754440193",
  "text" : "\u767A\u8868\u7D42\u308F\u3063\u305F\u30FC\u3002\u3061\u3087\u3063\u3068\u65E9\u304F\u7D42\u308F\u3063\u3061\u3083\u3063\u305F\u3051\u3069\u3002",
  "id" : 136314092754440193,
  "created_at" : "2011-11-15 05:26:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u571F\u7ADC",
      "screen_name" : "rrr4t",
      "indices" : [ 3, 9 ],
      "id_str" : "158305488",
      "id" : 158305488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136313772422868992",
  "text" : "RT @rrr4t: \uFF23\u8A00\u8A9E\u306F\u96E3\uFF23",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "136312558880702464",
    "text" : "\uFF23\u8A00\u8A9E\u306F\u96E3\uFF23",
    "id" : 136312558880702464,
    "created_at" : "2011-11-15 05:20:21 +0000",
    "user" : {
      "name" : "\u571F\u7ADC",
      "screen_name" : "rrr4t",
      "protected" : false,
      "id_str" : "158305488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2682083920\/d0139525643086b45c4086cef4d98de0_normal.jpeg",
      "id" : 158305488,
      "verified" : false
    }
  },
  "id" : 136313772422868992,
  "created_at" : "2011-11-15 05:25:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/MmWJoonM",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=tohru1101",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "136307465791864832",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001tohru1101\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/MmWJoonM",
  "id" : 136307465791864832,
  "created_at" : "2011-11-15 05:00:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sigmapsi",
      "screen_name" : "sigmapsi",
      "indices" : [ 0, 9 ],
      "id_str" : "22502063",
      "id" : 22502063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136277323761729536",
  "geo" : { },
  "id_str" : "136277529936920576",
  "in_reply_to_user_id" : 22502063,
  "text" : "@sigmapsi \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 136277529936920576,
  "in_reply_to_status_id" : 136277323761729536,
  "created_at" : "2011-11-15 03:01:09 +0000",
  "in_reply_to_screen_name" : "sigmapsi",
  "in_reply_to_user_id_str" : "22502063",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136129114141753345",
  "text" : "\u306F\u3044\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 136129114141753345,
  "created_at" : "2011-11-14 17:11:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136129051348832256",
  "text" : "\u304F\u308B\u30FC\u3069\u3055\u3093\u3059\u3063\u3052\u3047",
  "id" : 136129051348832256,
  "created_at" : "2011-11-14 17:11:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136128702256922625",
  "text" : "\u5BDD\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 136128702256922625,
  "created_at" : "2011-11-14 17:09:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136127157494759424",
  "text" : "\u3042\u308C\u3001\u304B\u308F\u305A\u5927\u5148\u751F\u3082\u8A95\u751F\u65E5\u306A\u3093\u3067\u3059\uFF1F\u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01",
  "id" : 136127157494759424,
  "created_at" : "2011-11-14 17:03:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136126468836179968",
  "text" : "\u304E\u308A\u304E\u308A\u6ED1\u308A\u8FBC\u3093\u3060\u611F",
  "id" : 136126468836179968,
  "created_at" : "2011-11-14 17:00:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136125866601226240",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3086",
  "id" : 136125866601226240,
  "created_at" : "2011-11-14 16:58:30 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yggdra327",
      "screen_name" : "yggdra327",
      "indices" : [ 3, 13 ],
      "id_str" : "2590549820",
      "id" : 2590549820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136008579844026368",
  "text" : "RT @yggdra327: \u5973\u795E\u300C\u3042\u306A\u305F\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u5FC5\u4FEE\u306E\u5358\u4F4D\u3067\u3059\u304B\u3001\u305D\u308C\u3068\u3082\u9078\u629E\u306E\u5358\u4F4D\u3067\u3059\u304B\u300D \u5B66\u751F\u300C\u4E21\u65B9\u3067\u3059\u300D \u5973\u795E\u300C\u6B63\u76F4\u8005\u306E\u3042\u306A\u305F\u306B\u306F\u3082\u3046\u4E00\u5E74\u5DEE\u3057\u4E0A\u3052\u307E\u3057\u3087\u3046\u300D \u5B66\u751F\u300C\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93597838252064768",
    "text" : "\u5973\u795E\u300C\u3042\u306A\u305F\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u5FC5\u4FEE\u306E\u5358\u4F4D\u3067\u3059\u304B\u3001\u305D\u308C\u3068\u3082\u9078\u629E\u306E\u5358\u4F4D\u3067\u3059\u304B\u300D \u5B66\u751F\u300C\u4E21\u65B9\u3067\u3059\u300D \u5973\u795E\u300C\u6B63\u76F4\u8005\u306E\u3042\u306A\u305F\u306B\u306F\u3082\u3046\u4E00\u5E74\u5DEE\u3057\u4E0A\u3052\u307E\u3057\u3087\u3046\u300D \u5B66\u751F\u300C\u300D",
    "id" : 93597838252064768,
    "created_at" : "2011-07-20 08:27:18 +0000",
    "user" : {
      "name" : "\u3086\u3050\u3069\u3089",
      "screen_name" : "y99dra",
      "protected" : false,
      "id_str" : "88724501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566159220949520384\/goeJAV5a_normal.png",
      "id" : 88724501,
      "verified" : false
    }
  },
  "id" : 136008579844026368,
  "created_at" : "2011-11-14 09:12:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135929883716091905",
  "text" : "\u7D4C\u6E08\u306B\u3057\u308D\u6587\u5B66(\u4E00\u90E8\uFF09\u306B\u3057\u308D\u6570\u5F0F\u304C\u51FA\u3066\u304D\u305F\u304F\u3089\u3044\u3067\u559A\u304B\u305A\u5411\u304D\u5408\u3046\u3079\u304D\u3060\u3068\u601D\u3046\u3093\u3060\u3051\u3069\u306A\u30FC",
  "id" : 135929883716091905,
  "created_at" : "2011-11-14 03:59:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135929578043609088",
  "text" : "\u6570\u5F0F\u4F7F\u308F\u305A\u306B\u79D1\u5B66\u53F2\u3084\u308B\u306E\u306F\u7518\u3048\u3058\u3083\u306A\u3044\u306E\u304B",
  "id" : 135929578043609088,
  "created_at" : "2011-11-14 03:58:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135884692841971712",
  "geo" : { },
  "id_str" : "135884753772617730",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 135884753772617730,
  "in_reply_to_status_id" : 135884692841971712,
  "created_at" : "2011-11-14 01:00:24 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135884594066112512",
  "text" : "\u808C\u5BD2\u3044\u3001\u5E03\u56E3\u304C\u79C1\u3092\u96E2\u3055\u306A\u3044\u3002",
  "id" : 135884594066112512,
  "created_at" : "2011-11-14 00:59:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135884016971808768",
  "geo" : { },
  "id_str" : "135884127256842240",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u304A\u306F\u3088\u3046",
  "id" : 135884127256842240,
  "in_reply_to_status_id" : 135884016971808768,
  "created_at" : "2011-11-14 00:57:55 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135883152005668865",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 135883152005668865,
  "created_at" : "2011-11-14 00:54:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135883079175766017",
  "text" : "\u305D\u308D\u305D\u308D\u8D77\u304D\u308B\u304B\u306A",
  "id" : 135883079175766017,
  "created_at" : "2011-11-14 00:53:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u96A3\u306E\u3068\u306A\u308A",
      "screen_name" : "tonar_no_tonari",
      "indices" : [ 0, 16 ],
      "id_str" : "262045935",
      "id" : 262045935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135880536089559040",
  "geo" : { },
  "id_str" : "135880722807402496",
  "in_reply_to_user_id" : 262045935,
  "text" : "@tonar_no_tonari \u9332\u753B\u2026\u3058\u3083\u3069\u3046\u305B\u30C0\u30E1\u306A\u3093\u3067\u3057\u3087\u3046\u306D",
  "id" : 135880722807402496,
  "in_reply_to_status_id" : 135880536089559040,
  "created_at" : "2011-11-14 00:44:23 +0000",
  "in_reply_to_screen_name" : "tonar_no_tonari",
  "in_reply_to_user_id_str" : "262045935",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sigmapsi",
      "screen_name" : "sigmapsi",
      "indices" : [ 0, 9 ],
      "id_str" : "22502063",
      "id" : 22502063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135865897515622400",
  "geo" : { },
  "id_str" : "135866544008863745",
  "in_reply_to_user_id" : 22502063,
  "text" : "@sigmapsi \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 135866544008863745,
  "in_reply_to_status_id" : 135865897515622400,
  "created_at" : "2011-11-13 23:48:03 +0000",
  "in_reply_to_screen_name" : "sigmapsi",
  "in_reply_to_user_id_str" : "22502063",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135758626768949248",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 135758626768949248,
  "created_at" : "2011-11-13 16:39:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135753413337161728",
  "text" : "\u307E\u3041\u8A00\u8449\u306E\u30C1\u30E7\u30A4\u30B9\u306E\u8AA4\u308A\u306B\u5B9A\u8A55\u306E\u3042\u308B\u81EA\u5206\u306E\u622F\u8A00\u306A\u306E\u3067\u751A\u3060\u602A\u3057\u3052\u306A\u7D50\u8AD6\u3067\u3059\u3051\u3069\u306D\u30FC",
  "id" : 135753413337161728,
  "created_at" : "2011-11-13 16:18:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135753208969695232",
  "text" : "\u3093\u30FC\u3084\u3063\u3071\u308A\u30AB\u30B9\u306F\u4EBA\u9593\u306B\u5BFE\u3057\u3066\u4F7F\u3046\u8A00\u8449\u3058\u3083\u306A\u3044\u3063\u3066\u306E\u306F\u4ECA\u306E\u3068\u3053\u308D\u306E\u81EA\u5206\u306E\u7D50\u8AD6\u306A\u306E\u3060\u308D\u3046\u3002",
  "id" : 135753208969695232,
  "created_at" : "2011-11-13 16:17:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135752963120570368",
  "text" : "\u3042\u30FC\u672C\u4EBA\u304C\u56F0\u308B\u3060\u3051\u3060\u304B\u3089\u304B\u306A\u3002\u3042\u307E\u308A\u306B\u89AA\u4E0D\u5B5D\u3060\u3063\u305F\u308A\u3001\u5468\u308A\u306E\u4EBA\u9593\u306B\u627F\u670D\u3067\u304D\u306A\u3044\u30EC\u30D9\u30EB\u306E\u8FF7\u60D1\u3092\u639B\u3051\u3064\u3065\u3051\u308B\u4EBA\u306F\u30AB\u30B9\u306B\u3042\u305F\u308B\u306E\u304B\u306A\u3002\u305D\u308C\u3067\u3082\u3053\u306E\u8868\u73FE\u304C\u5F37\u3044\u3068\u601D\u3046\u306E\u306F\u3084\u3063\u3071\u308A\u5ACC\u3044\u306A\u306E\u304B\u3002",
  "id" : 135752963120570368,
  "created_at" : "2011-11-13 16:16:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135752550598193152",
  "text" : "\u4F8B\u3048\u3070\u5FC5\u4FEE\u306E\u5358\u4F4D\u843D\u3068\u3059\u3068\u304B\u3001\u7559\u5E74\u3057\u3061\u3083\u3046\u3068\u304B\u305D\u3046\u3044\u3046\u5B9F\u969B\u7684\u306B\u307E\u305A\u3044\u904E\u3061\u3092\u72AF\u3059\u4EBA\u3082\u79F0\u8CDB\u306F\u3057\u306A\u3044\u306B\u3057\u3066\u3082\u30AB\u30B9\u3060\u3068\u306F\u601D\u308F\u306A\u3044\u3088\u306A\u30FC",
  "id" : 135752550598193152,
  "created_at" : "2011-11-13 16:15:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135752137006252033",
  "text" : "\u3069\u3046\u3057\u3066\u3082\u3053\u306E\u4EBA\u3068\u306F\u304A\u4ED8\u304D\u5408\u3044\u3067\u304D\u306A\u3044\u306A\u3063\u3066\u4EBA\u306F\u3084\u3063\u3071\u308A\u3069\u3046\u3057\u3066\u3082\u4E00\u63E1\u308A\u3044\u308B\u3051\u3069\u3002\u305D\u308C\u3089\u306E\u4EBA\u306B\u30AB\u30B9\u3063\u3066\u8868\u73FE\u306F\u4F7F\u3044\u305F\u304F\u306A\u3044\u3057\u306A\u30FC",
  "id" : 135752137006252033,
  "created_at" : "2011-11-13 16:13:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135751902548852736",
  "text" : "\u591A\u5206\u4EBA\u9593\u306E\u904E\u5927\u8A55\u4FA1\u89B3\u304C\u3042\u308B\u3093\u3060\u308D\u3046\u306A\u30FC\u3002\u81EA\u5206\u306B\u306F\u3002",
  "id" : 135751902548852736,
  "created_at" : "2011-11-13 16:12:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135751678661107712",
  "text" : "\u3093\u30FC\u30AB\u30B9\u3068\u3044\u3046\u8A00\u8449\u304C\u5ACC\u3044\u306A\u306E\u304B\u30AB\u30B9\u3068\u8A00\u3046\u8A00\u8449\u304C\u4F7F\u308F\u308C\u308B\u6587\u8108\u304C\u5ACC\u3044\u306A\u306E\u304B\u2026",
  "id" : 135751678661107712,
  "created_at" : "2011-11-13 16:11:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135749937148329985",
  "text" : "\u716E\u5E72\u3057\u3068\u304B\u6301\u3061\u6B69\u3044\u3066\u4E0E\u3048\u3066\u307F\u308B\u3068\u304B\uFF1F\u732B\u3058\u3083\u3089\u3057\u6301\u3061\u6B69\u3044\u3066\u307F\u308B\u3068\u304B\uFF1F\u8B66\u6212\u3055\u308C\u308B\u306E\u306F\u4ED5\u65B9\u306A\u3044\u3051\u3069\u5207\u306A\u3044\u3082\u3093\u306A\u30FC\u3002",
  "id" : 135749937148329985,
  "created_at" : "2011-11-13 16:04:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135749758634561537",
  "text" : "\u70AC\u71F5\u3067\u601D\u3044\u51FA\u3057\u305F\u3051\u3069\u4E0B\u9D28\u795E\u793E\u5468\u8FBA\u306E\u7279\u5B9A\u306E\u30DD\u30A4\u30F3\u30C8\u3067\u826F\u304F\u91CE\u826F\uFF08\uFF1F\uFF09\u732B\u3092\u898B\u304B\u3051\u308B\u3093\u3060\u3051\u3069\u4EF2\u826F\u304F\u306A\u308B\u65B9\u6CD5\u306F\u306A\u3044\u3060\u308D\u3046\u304B",
  "id" : 135749758634561537,
  "created_at" : "2011-11-13 16:03:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135749541407363072",
  "text" : "\u8DB3\u5148\u624B\u5148\u306E\u51B7\u3048\u304C\u51FA\u3066\u304D\u305F\u304B\u3089\u305D\u308D\u305D\u308D\u70AC\u71F5\u3092\u51FA\u3059\u304B\u306A\u30FC",
  "id" : 135749541407363072,
  "created_at" : "2011-11-13 16:03:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135747917964247040",
  "text" : "\u5DE6\u4E0B\u306E\u300C\u3086\u300D\u6BB5\u30DC\u30FC\u30EB\u306E\u5B58\u5728\u611F\uFF57\uFF57\uFF57\uFF57",
  "id" : 135747917964247040,
  "created_at" : "2011-11-13 15:56:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135746884957511680",
  "geo" : { },
  "id_str" : "135747695687114752",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u30AB\u30B9\u3068\u3044\u3046\u8A00\u8449\u306F\u305D\u3082\u305D\u3082\u597D\u304D\u3058\u3083\u306A\u3044\u3067\u3059\u304C\u3001\u307E\u3041\u305D\u308C\u8A00\u3044\u8A33\u306B\u3057\u3061\u3083\u30C0\u30E1\u3067\u3059\u3088\u306D\u3047",
  "id" : 135747695687114752,
  "in_reply_to_status_id" : 135746884957511680,
  "created_at" : "2011-11-13 15:55:47 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135747436491718656",
  "text" : "\u53CB\u9054\uFF21\u300C\u305D\u3046\u3044\u3048\u3070\uFF22\u7D50\u5C40\u733F\u306E\u60D1\u661F\u884C\u3063\u305F\u306E\uFF1F\u300D\n\uFF08\u6620\u753B\u597D\u304D\u306E\uFF09\u53CB\u9054\uFF22\u300C\u3044\u3084\u300D\n\u4FFA\u300C\u3048\u3063\uFF22\u733F\u306E\u60D1\u661F\u306B\u884C\u304F\u7528\u4E8B\u304C\u3042\u3063\u305F\u306E\uFF1F\u300D\n\u53CB\u9054\uFF21\u300C\u3048\u3063\u300D\n\u53CB\u9054\uFF22\u300C\u3048\u3063\u300D\n\u4FFA\u300C\u2026\uFF08\u30C1\u30E7\u30C3\u30C8\u9762\u767D\u3044\u3068\u601D\u3063\u305F\u3093\u3060\u3051\u3069\u306A\uFF09\u300D",
  "id" : 135747436491718656,
  "created_at" : "2011-11-13 15:54:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135746354478710785",
  "geo" : { },
  "id_str" : "135746469331349504",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 135746469331349504,
  "in_reply_to_status_id" : 135746354478710785,
  "created_at" : "2011-11-13 15:50:54 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135746397013151745",
  "text" : "\u300C\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u300D\u3063\u3066\u306E\u306F\u3044\u3044\u8A00\u8449\u3060\u3088\u306D\u3002\u8A00\u8449\u306E\u97FF\u304D\u304C\u597D\u304D\u3002",
  "id" : 135746397013151745,
  "created_at" : "2011-11-13 15:50:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135746128745476097",
  "geo" : { },
  "id_str" : "135746272006111233",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 135746272006111233,
  "in_reply_to_status_id" : 135746128745476097,
  "created_at" : "2011-11-13 15:50:07 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135746015818039297",
  "text" : "\u306A\u3093\u304B\u81EA\u5206\u304C\u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u8352\u3076\u308B\u6642\u9593\u5E2F\u3063\u3066\u4EBA\u5C11\u306A\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\u3060\u304B\u3089\u3069\u3046\u3068\u3044\u3046\u3053\u3068\u306F\u306A\u3044\u306E\u3060\u3051\u308C\u3069\u3002",
  "id" : 135746015818039297,
  "created_at" : "2011-11-13 15:49:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135745540519505920",
  "text" : "\u5B66\u90E8\u3068\u3084\u308A\u305F\u3044\u4E8B\u3068\u3084\u308B\u6C17\u3068\u6642\u9593\u306E\u914D\u5206\u304C\u3080\u3061\u3083\u304F\u3061\u3083\u3067\u3042\u308B\u3002",
  "id" : 135745540519505920,
  "created_at" : "2011-11-13 15:47:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135745334847614976",
  "text" : "\u3066\u304B\u30D5\u30E9\u30AF\u30BF\u30EB\u5E7E\u4F55\u5B66\u306E\u672C\u3082\u8AAD\u307F\u304B\u3051\u3060\u3063\u305F\u306A\u3002",
  "id" : 135745334847614976,
  "created_at" : "2011-11-13 15:46:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135745065111912449",
  "text" : "\u306B\u305B\u307B\u3046\u3063\u305C\u3047\uFF57\uFF57\uFF57",
  "id" : 135745065111912449,
  "created_at" : "2011-11-13 15:45:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 3, 15 ],
      "id_str" : "229754624",
      "id" : 229754624
    }, {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 17, 22 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135744999609479168",
  "text" : "RT @nisehorrrrn: @np2i \u3061\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u3063\u3059\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "np2i",
        "screen_name" : "np2i",
        "indices" : [ 0, 5 ],
        "id_str" : "1154899267",
        "id" : 1154899267
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "135744864712269824",
    "text" : "@np2i \u3061\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u3063\u3059\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
    "id" : 135744864712269824,
    "created_at" : "2011-11-13 15:44:32 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "protected" : false,
      "id_str" : "229754624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1196972020\/06-12-24_23-49_kisee2_normal.jpg",
      "id" : 229754624,
      "verified" : false
    }
  },
  "id" : 135744999609479168,
  "created_at" : "2011-11-13 15:45:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135744669324820480",
  "geo" : { },
  "id_str" : "135744769296056320",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u304A\u306F\u3088\u30FC\u3054\u3056\u3044\u307E\u3059",
  "id" : 135744769296056320,
  "in_reply_to_status_id" : 135744669324820480,
  "created_at" : "2011-11-13 15:44:09 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135744534133997569",
  "text" : "\u5143\u6C17\u3044\u3063\u3071\u3044\u30AD\u30E3\u30E9\u306F\u773A\u3081\u3066\u3044\u308B\u3068\u9762\u767D\u3044\u3051\u308C\u3069\u81EA\u5206\u306F\u773A\u3081\u3066\u3044\u308B\u5074\u304C\u3044\u3044\u3088\u306D\u3002",
  "id" : 135744534133997569,
  "created_at" : "2011-11-13 15:43:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135744256957616128",
  "text" : "\u6700\u8FD1\u8A9E\u5C3E\u306B\u5C0F\u3063\u3061\u3083\u3044\u300C\u3064\u300D\u3092\u3064\u3051\u308B\u4E8B\u304C\u591A\u3044\u306A\u2026\u3002\u3066\u304B\u305D\u3082\u305D\u3082\u305D\u3093\u306A\u306B\u5143\u6C17\u3044\u3063\u3071\u3044\u30AD\u30E3\u30E9\u3058\u3083\u306A\u3044\u3002",
  "id" : 135744256957616128,
  "created_at" : "2011-11-13 15:42:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135744141685571584",
  "text" : "\u53EF\u611B\u304F\u306A\u3044\u3088\u3063\uFF01\u305F\u3068\u3048\u304B\u308F\u3044\u304F\u3066\u3082\u4E2D\u8EAB\u306F\u3055\u3057\u3066\u53EF\u611B\u304F\u306A\u3044\u3088\u3063\uFF01",
  "id" : 135744141685571584,
  "created_at" : "2011-11-13 15:41:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135743713950433280",
  "text" : "\u30A4\u30AE\u30EA\u30B9\u7D19\u5E63\u304B\u3063\uFF01",
  "id" : 135743713950433280,
  "created_at" : "2011-11-13 15:39:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u540D\u524D\u306E\u3069\u3053\u304B\u3092\u307D\u306B\u3059\u308B\u3068\u304B\u308F\u3044\u3044",
      "indices" : [ 4, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135743647646879744",
  "text" : "\u30DD\u30F3\u30C9 #\u540D\u524D\u306E\u3069\u3053\u304B\u3092\u307D\u306B\u3059\u308B\u3068\u304B\u308F\u3044\u3044",
  "id" : 135743647646879744,
  "created_at" : "2011-11-13 15:39:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135743332512055296",
  "text" : "\u305D\u3082\u305D\u3082\u306F\u30D5\u30E9\u30AF\u30BF\u30EB\u30A2\u30FC\u30C8\u306E\u58C1\u7D19\u63A2\u3057\u3066\u305F\u3089\u30D2\u30C3\u30C8\u3057\u305F\u3093\u3060\u3063\u3051\u304B\u3001\u30D5\u30E9\u30AF\u30BF\u30EB\u3002",
  "id" : 135743332512055296,
  "created_at" : "2011-11-13 15:38:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135743135648202752",
  "text" : "1\u5DFB1000\u5186\u5207\u308B\u3068\u304B\u5727\u5012\u7684\u5024\u5D29\u308C\u3063\uFF01",
  "id" : 135743135648202752,
  "created_at" : "2011-11-13 15:37:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135742962415042561",
  "text" : "\u30D5\u30E9\u30AF\u30BF\u30EB\u306E\uFF22\uFF24\u306E\u751F\u7523\u9650\u5B9A\u76E4\u304Camazon\u3067\u9A5A\u304D\u306E\u5B89\u3055\u3060\u3063\u305F\u304B\u3089\u30DD\u30C1\u3063\u3066\u3057\u307E\u3063\u305F",
  "id" : 135742962415042561,
  "created_at" : "2011-11-13 15:36:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135742248745832449",
  "text" : "\u306B\u3057\u3066\u3082\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u306F\u304A\u3082\u3057\u308D\u3044\u4EBA\u9593\u3060\u306A\u3002\u304A\u8336\u76EE\u3068\u306F\u3088\u304F\u8A00\u308F\u308C\u308B\u307F\u305F\u3044\u3060\u3051\u3069\u3002\u306A\u3093\u304B\u597D\u611F\u304C\u6301\u3066\u308B\u308F\u3002\u3042\u3063\u305F\u3053\u3068\u306A\u3044\u3051\u3069\u3002",
  "id" : 135742248745832449,
  "created_at" : "2011-11-13 15:34:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135741432760766464",
  "text" : "\u7D42\u308F\u3063\u305F\u2026",
  "id" : 135741432760766464,
  "created_at" : "2011-11-13 15:30:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135736897778614272",
  "text" : "\u3042\u30026000\u5B57\u8D85\u3048\u305F\u3002\u91CD\u3081\u306E\u30EC\u30DD\u30FC\u30C8\u3058\u3083\u3093\u3001\u3053\u308C\u3002",
  "id" : 135736897778614272,
  "created_at" : "2011-11-13 15:12:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135734241890799616",
  "text" : "\u307E\u3001\u5927\u65B9\u5148\u9031\u672B\u4F5C\u3063\u305F\u30DD\u30D1\u30FC\u306E\u30EC\u30B8\u30E5\u30E1\u306E\u305B\u3044\u306A\u3093\u3060\u308D\u3046\u3051\u3069\u3002",
  "id" : 135734241890799616,
  "created_at" : "2011-11-13 15:02:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135734107656290304",
  "text" : "\u3068\u3053\u308D\u3067\u300C\u304D\u306E\u3046\u300D\u3067\u5909\u63DB\u3059\u308B\u3068\u5E30\u7D0D\u304C\u51FA\u308B\u3093\u3067\u3059\u3051\u3069\u3053\u308C\u306F\u81EA\u5206\u304C\u60AA\u3044\u306E\uFF1F",
  "id" : 135734107656290304,
  "created_at" : "2011-11-13 15:01:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135733973958660096",
  "text" : "\u3042\u3001\u65E5\u4ED8\u5909\u3063\u305F\u30A1\uFF01\u304A\u3068\u3068\u3044\u304B\u3089\u6628\u65E5\u306B\u5411\u3051\u3066\u904A\u3093\u3060\u304B\u3089\u3057\u308F\u5BC4\u305B\u8ABF\u6574\u4E2D\u3002",
  "id" : 135733973958660096,
  "created_at" : "2011-11-13 15:01:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135733384872857600",
  "text" : "\u9019\u3046\u9019\u3046\u306E\u4F53\u3063\u3066\u4E00\u767A\u3067\u5909\u63DB\u51FA\u308B\u306E\u306B\u3001\u30EF\u30FC\u30C9\u304C\u8D64\u3044\u6CE2\u4E0B\u7DDA\u5F15\u3044\u3066\u304F\u308B\u3093\u3060\u3051\u3069\u306A\u3093\u306A\u306E\uFF1F",
  "id" : 135733384872857600,
  "created_at" : "2011-11-13 14:58:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135730035448483840",
  "text" : "\u3082\u3046\u3061\u3087\u3063\u3068\u66F8\u3044\u3066\u3042\u3068\u306F\u30C8\u30FC\u30AF\u30B9\u30AD\u30EB\uFF08\uFF09\u3068\u304B\u30B3\u30DF\u30E5\u529B\uFF08\uFF09\u3068\u304B\u4EBA\u9593\u529B\uFF08\uFF09\u3067\u306A\u3093\u3068\u304B\u3059\u308B\u304B",
  "id" : 135730035448483840,
  "created_at" : "2011-11-13 14:45:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135729830414123008",
  "text" : "\u767A\u8868\u306E\u30EC\u30B8\u30E5\u30E15000\u5B57\u8D85\u3048\u305F\uFF57\uFF57\uFF57\uFF57\u5272\u306B\u624B\u629C\u304D\u611F\u304C\u3042\u308B\u4E0D\u601D\u8B70\uFF57\uFF57\uFF57\uFF57",
  "id" : 135729830414123008,
  "created_at" : "2011-11-13 14:44:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135716057724891136",
  "geo" : { },
  "id_str" : "135716886565494785",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u8AB2\u984C\u3058\u3083\u306A\u304D\u3083\u307E\u305A\u3053\u3093\u306A\u306B\u305B\u3063\u3071\u3064\u307E\u3063\u3066\u3084\u3089\u306A\u3044\u3067\u3059\u3057\u2026",
  "id" : 135716886565494785,
  "in_reply_to_status_id" : 135716057724891136,
  "created_at" : "2011-11-13 13:53:21 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135714109529403394",
  "geo" : { },
  "id_str" : "135714607305195521",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u4ECA\u3084\u3063\u3066\u308B\u306E\u306F\u81F3\u3063\u3066\u6587\u5B66\u7684\u306A\u30A2\u30D7\u30ED\u30FC\u30C1\u306A\u306E\u3067\u3001\u7406\u5B66\u7684\u306A\u30A2\u30D7\u30ED\u30FC\u30C1\u306B\u306F\u3082\u3046\u30C1\u30E7\u30A4\u6642\u9593\u304C\u304B\u304B\u308A\u307E\u3059\u3088\u30FC",
  "id" : 135714607305195521,
  "in_reply_to_status_id" : 135714109529403394,
  "created_at" : "2011-11-13 13:44:18 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135688697243901952",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 135688697243901952,
  "created_at" : "2011-11-13 12:01:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135688401654517761",
  "text" : "\u3061\u3087\u3063\u3068\u884C\u3063\u3066\u898B\u305F\u3044\u3051\u3069\u30B5\u30FC\u30AF\u30EB\u306A\u3093\u3060\u3088\u306A\u30FC\u90E8\u5185\u6226\u8FD1\u3044\u3057\u306A\u3041\u2026",
  "id" : 135688401654517761,
  "created_at" : "2011-11-13 12:00:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135685711507636224",
  "text" : "\u3086\u30A2\u30A4\u30B3\u30F3\u5897\u6B96\u3057\u3059\u304E\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 135685711507636224,
  "created_at" : "2011-11-13 11:49:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135685524143882240",
  "text" : "\u3069\u3070\u306B\u3083\u3093\u3055\u3093\u306B\u306F\u8A00\u3044\u56DE\u3057\u304C\u9055\u3046\u72AC\u3042\u3056\u3068\u3044",
  "id" : 135685524143882240,
  "created_at" : "2011-11-13 11:48:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135685279557222400",
  "text" : "\u3044\u306C\u9B31\u9676\u3057\u3044\u306A",
  "id" : 135685279557222400,
  "created_at" : "2011-11-13 11:47:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135684984777355264",
  "text" : "\uFF33\uFF2F\uFF29\uFF23\uFF28\uFF21\u3067\u898B\u3066\u308B\uFF34\uFF2C\u306E\u3046\u3061\u4E09\u3064\u306B\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u304C\u5165\u3063\u3066\u308B\u305B\u3044\u3067\uFF30\uFF23\u306E\u753B\u9762\u304C\u300C\u3086\u300D\u3067\u57CB\u3081\u5C3D\u304F\u3055\u308C\u3066\u3044\u304F\uFF57\uFF57\uFF57\uFF57",
  "id" : 135684984777355264,
  "created_at" : "2011-11-13 11:46:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " .",
      "screen_name" : "Jojo__0707",
      "indices" : [ 0, 11 ],
      "id_str" : "1512646136",
      "id" : 1512646136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135684696339259392",
  "text" : "@Jojo__0707 \u306F\u3041",
  "id" : 135684696339259392,
  "created_at" : "2011-11-13 11:45:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135684210517229568",
  "text" : "\u3086",
  "id" : 135684210517229568,
  "created_at" : "2011-11-13 11:43:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135682878167191552",
  "text" : "\u7A7A\u69D3\u3063\u3066\u4E00\u767A\u5909\u63DB\u3055\u308C\u308B\u6DF1\u523B\u306A\u30A8\u30E9\u30FC\n\u7A7A\u9593\u3060\u3088\uFF01",
  "id" : 135682878167191552,
  "created_at" : "2011-11-13 11:38:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135646736864649216",
  "text" : "\u4F11\u61A9\u3057\u3066\u65E9\u3081\u306E\u304A\u5915\u98EF\u306B\u3057\u3088\u3046\u304B\u306A\u30FC",
  "id" : 135646736864649216,
  "created_at" : "2011-11-13 09:14:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135644694314102784",
  "text" : "\u3080\u3045\u2026\u3053\u306E\u8AB2\u984C\u7D50\u69CB\u3057\u3093\u3069\u3044\u3002\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u3002",
  "id" : 135644694314102784,
  "created_at" : "2011-11-13 09:06:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135326863873671169",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 135326863873671169,
  "created_at" : "2011-11-12 12:03:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135251378397392896",
  "text" : "\u3069\u3070\u306B\u3083\u3093\u3082\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u3082\u30A2\u30AD\u30CD\u30FC\u30BF\u3067\u51FA\u3066\u304D\u3066\u51C4\u3044\uFF57",
  "id" : 135251378397392896,
  "created_at" : "2011-11-12 07:03:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\uFF11\u884C\u3067\u77DB\u76FE\u3057\u305F\u3053\u3068\u3092\u66F8\u3044\u3066\u3044\u3051",
      "indices" : [ 30, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135219410628648960",
  "text" : "\u3053\u308C\u4E8C\u884C\u4EE5\u4E0A\u3067\u3082\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u3068\u77DB\u76FE\u3059\u308B\u304B\u3089\u554F\u984C\u306A\u3044\u3093\u3058\u3083\u2026 #\uFF11\u884C\u3067\u77DB\u76FE\u3057\u305F\u3053\u3068\u3092\u66F8\u3044\u3066\u3044\u3051",
  "id" : 135219410628648960,
  "created_at" : "2011-11-12 04:56:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\uFF11\u884C\u3067\u77DB\u76FE\u3057\u305F\u3053\u3068\u3092\u66F8\u3044\u3066\u3044\u3051",
      "indices" : [ 8, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135218901062660097",
  "text" : "\u9AB8\u9AA8\u306E\u751F\u304D\u5199\u3057 #\uFF11\u884C\u3067\u77DB\u76FE\u3057\u305F\u3053\u3068\u3092\u66F8\u3044\u3066\u3044\u3051",
  "id" : 135218901062660097,
  "created_at" : "2011-11-12 04:54:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/MmWJoonM",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=tohru1101",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "135134633074499584",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001tohru1101\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/MmWJoonM",
  "id" : 135134633074499584,
  "created_at" : "2011-11-11 23:19:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF2E\uFF28\uFF2B\u304D\u3087\u3046\u3068",
      "screen_name" : "nhk_kyoto",
      "indices" : [ 3, 13 ],
      "id_str" : "312516704",
      "id" : 312516704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134862204657868801",
  "text" : "RT @nhk_kyoto: \u4ECA\u65E5\u306F\u300C\u9BAD\u306E\u65E5\u300D\u3002\u9BAD\u306E\u6F22\u5B57\u304C\u3001\u9B5A\u3078\u3093\u306B\u300C\u5341\u4E00\u5341\u4E00\u300D\u3068\u66F8\u304F\u304B\u3089\u30CB\u30E3\u3093\u3060\u3063\u3066\u3002\u3042\u308F\u305B\u3066\u4ECA\u65E5\u306F\u300C\u3044\u305F\u3060\u304D\u307E\u3059\u306E\u65E5\u300D\u3002\u300C\uFF11\uFF11\uFF11\uFF11\u300D\u304C\u4E26\u3093\u3060\u304A\u7BB8\u306B\u898B\u3048\u308B\u304B\u3089\u30FB\u30FB\u30FB\u30FB\u30FB\u3068\u3044\u3046\u3053\u3068\u306F\u3001\u6669\u3054\u98EF\u306F\u300C\u9BAD\u3092\u3044\u305F\u3060\u304D\u307E\u3059\uFF01\u300D\u30CB\u30E3\u3093\u3061\u3083\u3063\u3066\uFF01~(=^\uFF65\u03C9\uFF65^)\uFF89&gt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nhk.or.jp\/\" rel=\"nofollow\"\u003ENHK\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134861848083316736",
    "text" : "\u4ECA\u65E5\u306F\u300C\u9BAD\u306E\u65E5\u300D\u3002\u9BAD\u306E\u6F22\u5B57\u304C\u3001\u9B5A\u3078\u3093\u306B\u300C\u5341\u4E00\u5341\u4E00\u300D\u3068\u66F8\u304F\u304B\u3089\u30CB\u30E3\u3093\u3060\u3063\u3066\u3002\u3042\u308F\u305B\u3066\u4ECA\u65E5\u306F\u300C\u3044\u305F\u3060\u304D\u307E\u3059\u306E\u65E5\u300D\u3002\u300C\uFF11\uFF11\uFF11\uFF11\u300D\u304C\u4E26\u3093\u3060\u304A\u7BB8\u306B\u898B\u3048\u308B\u304B\u3089\u30FB\u30FB\u30FB\u30FB\u30FB\u3068\u3044\u3046\u3053\u3068\u306F\u3001\u6669\u3054\u98EF\u306F\u300C\u9BAD\u3092\u3044\u305F\u3060\u304D\u307E\u3059\uFF01\u300D\u30CB\u30E3\u3093\u3061\u3083\u3063\u3066\uFF01~(=^\uFF65\u03C9\uFF65^)\uFF89&gt;\uFF9F)##)\u5F61",
    "id" : 134861848083316736,
    "created_at" : "2011-11-11 05:15:44 +0000",
    "user" : {
      "name" : "\uFF2E\uFF28\uFF2B\u304D\u3087\u3046\u3068",
      "screen_name" : "nhk_kyoto",
      "protected" : false,
      "id_str" : "312516704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605641339426832384\/hFyyW0kI_normal.jpg",
      "id" : 312516704,
      "verified" : false
    }
  },
  "id" : 134862204657868801,
  "created_at" : "2011-11-11 05:17:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D3\u30CB\u30FC\u30EB\u30BF\u30C3\u30AD\u30FC",
      "screen_name" : "vinyl_tackey",
      "indices" : [ 3, 16 ],
      "id_str" : "51709924",
      "id" : 51709924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134854213544067072",
  "text" : "RT @vinyl_tackey: \u304A\u307E\u3048\u30892011\/11\/11 11:11:11\u3067\u9A12\u3044\u3067\u308B\u3051\u3069\u5148\u982D\u306E20\u306E\u6C17\u6301\u3061\u3082\u5C11\u3057\u306F\u8003\u3048\u3066\u307F\u308D\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134813691022557184",
    "text" : "\u304A\u307E\u3048\u30892011\/11\/11 11:11:11\u3067\u9A12\u3044\u3067\u308B\u3051\u3069\u5148\u982D\u306E20\u306E\u6C17\u6301\u3061\u3082\u5C11\u3057\u306F\u8003\u3048\u3066\u307F\u308D\u3088",
    "id" : 134813691022557184,
    "created_at" : "2011-11-11 02:04:23 +0000",
    "user" : {
      "name" : "\u30D3\u30CB\u30FC\u30EB\u30BF\u30C3\u30AD\u30FC",
      "screen_name" : "vinyl_tackey",
      "protected" : false,
      "id_str" : "51709924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579849008962613248\/qLgjo7Nj_normal.jpg",
      "id" : 51709924,
      "verified" : false
    }
  },
  "id" : 134854213544067072,
  "created_at" : "2011-11-11 04:45:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3071\u308D\u3059\u3051",
      "screen_name" : "parosky1",
      "indices" : [ 3, 12 ],
      "id_str" : "255779484",
      "id" : 255779484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134849501230940161",
  "text" : "RT @parosky1: \u81EA\u5BA4\u306B\u96FB\u6C17\u30B9\u30C8\u30FC\u30D6\u3092\u7F6E\u304F\u3068\u5927\u5B66\u306B\u884C\u3051\u306A\u304F\u306A\u308B\u6DF1\u523B\u306A\u8106\u5F31\u6027\u304C\u767A\u898B\u3055\u308C\u3066\u3044\u308B\u306E\u306B\u306A\u305C\u795E\u306F\u3053\u308C\u3092 fix \u3057\u306A\u3044\u306E\u304B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\" rel=\"nofollow\"\u003Eparosky-app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134844986213662720",
    "text" : "\u81EA\u5BA4\u306B\u96FB\u6C17\u30B9\u30C8\u30FC\u30D6\u3092\u7F6E\u304F\u3068\u5927\u5B66\u306B\u884C\u3051\u306A\u304F\u306A\u308B\u6DF1\u523B\u306A\u8106\u5F31\u6027\u304C\u767A\u898B\u3055\u308C\u3066\u3044\u308B\u306E\u306B\u306A\u305C\u795E\u306F\u3053\u308C\u3092 fix \u3057\u306A\u3044\u306E\u304B\u3002",
    "id" : 134844986213662720,
    "created_at" : "2011-11-11 04:08:44 +0000",
    "user" : {
      "name" : "\u3071\u308D\u3059\u3051",
      "screen_name" : "parosky1",
      "protected" : false,
      "id_str" : "255779484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1250985074\/ys_normal.png",
      "id" : 255779484,
      "verified" : false
    }
  },
  "id" : 134849501230940161,
  "created_at" : "2011-11-11 04:26:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134849450437910529",
  "text" : "\u7D20\u6674\u3089\u3057\u3044\u4E45\u4F4F\u30B0\u30EB\u30E1\uFF57\uFF57\uFF57\u7121\u304B\u3063\u305F\u3063\u3066\u306E\u304C\u7279\u306B",
  "id" : 134849450437910529,
  "created_at" : "2011-11-11 04:26:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "indices" : [ 3, 10 ],
      "id_str" : "89620915",
      "id" : 89620915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134849158287855617",
  "text" : "RT @qusumi: \u663C\u306F\u7389\u5B50\u3092\u843D\u3068\u3057\u305F\u5473\u564C\u716E\u8FBC\u307F\u3046\u3069\u3093\u306B\u3057\u3088\u3046\u3068\u601D\u3063\u3066\u3044\u305F\u306E\u3060\u304C\u3001\u5E97\u306B\u7121\u304B\u3063\u305F\u3002\u305D\u3053\u3067\u9D28\u5357\u86EE\u854E\u9EA6\u306B\u3057\u305F\u3002\u3064\u3044\u3001\u71D7\u9152\u4E00\u5408\u983C\u3093\u3060\u3002\u71D7\u9152\u306F\u4E00\u53E3\u3067\u304B\u3089\u3060\u304C\u30DD\u30FC\u30C3\u3068\u3042\u3063\u305F\u307E\u3063\u305F\u3002\u71B1\u3044\u9D28\u5357\u3092\u305F\u3050\u308A\u305F\u3050\u308A\u30C1\u30D3\u30C1\u30D3\u98F2\u3080\u306E\u306F\u6700\u9AD8\u3060\u3002\u3053\u3046\u306A\u308B\u3068\u3053\u306E\u96E8\u3082\u307E\u305F\u30B4\u30AD\u30B2\u30F3\u4E5F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134844589277331457",
    "text" : "\u663C\u306F\u7389\u5B50\u3092\u843D\u3068\u3057\u305F\u5473\u564C\u716E\u8FBC\u307F\u3046\u3069\u3093\u306B\u3057\u3088\u3046\u3068\u601D\u3063\u3066\u3044\u305F\u306E\u3060\u304C\u3001\u5E97\u306B\u7121\u304B\u3063\u305F\u3002\u305D\u3053\u3067\u9D28\u5357\u86EE\u854E\u9EA6\u306B\u3057\u305F\u3002\u3064\u3044\u3001\u71D7\u9152\u4E00\u5408\u983C\u3093\u3060\u3002\u71D7\u9152\u306F\u4E00\u53E3\u3067\u304B\u3089\u3060\u304C\u30DD\u30FC\u30C3\u3068\u3042\u3063\u305F\u307E\u3063\u305F\u3002\u71B1\u3044\u9D28\u5357\u3092\u305F\u3050\u308A\u305F\u3050\u308A\u30C1\u30D3\u30C1\u30D3\u98F2\u3080\u306E\u306F\u6700\u9AD8\u3060\u3002\u3053\u3046\u306A\u308B\u3068\u3053\u306E\u96E8\u3082\u307E\u305F\u30B4\u30AD\u30B2\u30F3\u4E5F\u3002",
    "id" : 134844589277331457,
    "created_at" : "2011-11-11 04:07:10 +0000",
    "user" : {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "protected" : false,
      "id_str" : "89620915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1625008477\/Q_Wqusumi_____normal.jpg",
      "id" : 89620915,
      "verified" : false
    }
  },
  "id" : 134849158287855617,
  "created_at" : "2011-11-11 04:25:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3080\u3046\u307F\u3093",
      "screen_name" : "_submoomin",
      "indices" : [ 3, 14 ],
      "id_str" : "284046922",
      "id" : 284046922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134646734319128576",
  "text" : "RT @_submoomin: \u3078\u305F\u3060\u306A\u3042\u30AB\u30A4\u30B8\u304F\u3093 \u3078\u305F\u3063\u3074\u3055\u2026\uFF01\u7B54\u6848\u306E\u66F8\u304D\u65B9\u304C\u5B9F\u306B\u3078\u305F\u2026\uFF01\u30AB\u30A4\u30B8\u304F\u3093\u304C\u672C\u5F53\u306B\u66F8\u304D\u305F\u3044\u3053\u3068\u306A\u3093\u3066\u4F55\u3082\u7121\u3044\u2026\uFF01\u65E9\u304F\u5E30\u3063\u3066\u8A66\u9A13\u306E\u3053\u3068\u306F\u5FD8\u308C\u305F\u3044\u2026\u3060\u308D\uFF1F\u3000\u3060\u3051\u3069\u90E8\u5206\u70B9\u304C\u8CB0\u3048\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u304B\u3089\u305B\u3081\u3066\u554F\u984C\u6587\u3060\u3051\u3067\u3082\u5199\u3057\u3066\u3054\u307E\u304B\u305D\u3046\u3063\u3066\u8A00\u3046\u3093\u3060\u2026\uFF01\u30C0 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134644292386947072",
    "text" : "\u3078\u305F\u3060\u306A\u3042\u30AB\u30A4\u30B8\u304F\u3093 \u3078\u305F\u3063\u3074\u3055\u2026\uFF01\u7B54\u6848\u306E\u66F8\u304D\u65B9\u304C\u5B9F\u306B\u3078\u305F\u2026\uFF01\u30AB\u30A4\u30B8\u304F\u3093\u304C\u672C\u5F53\u306B\u66F8\u304D\u305F\u3044\u3053\u3068\u306A\u3093\u3066\u4F55\u3082\u7121\u3044\u2026\uFF01\u65E9\u304F\u5E30\u3063\u3066\u8A66\u9A13\u306E\u3053\u3068\u306F\u5FD8\u308C\u305F\u3044\u2026\u3060\u308D\uFF1F\u3000\u3060\u3051\u3069\u90E8\u5206\u70B9\u304C\u8CB0\u3048\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u304B\u3089\u305B\u3081\u3066\u554F\u984C\u6587\u3060\u3051\u3067\u3082\u5199\u3057\u3066\u3054\u307E\u304B\u305D\u3046\u3063\u3066\u8A00\u3046\u3093\u3060\u2026\uFF01\u30C0\u30E1\u306A\u3093\u3060\u3088\u2026\uFF01\u305D\u3046\u3044\u3046\u306E\u304C\u5B9F\u306B\u30C0\u30E1\u2026\uFF01",
    "id" : 134644292386947072,
    "created_at" : "2011-11-10 14:51:15 +0000",
    "user" : {
      "name" : "\u3080\u3046\u307F\u3093",
      "screen_name" : "_submoomin",
      "protected" : true,
      "id_str" : "284046922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603530782649397248\/Se0jPYxq_normal.png",
      "id" : 284046922,
      "verified" : false
    }
  },
  "id" : 134646734319128576,
  "created_at" : "2011-11-10 15:00:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134644363266490368",
  "text" : "\u666E\u6BB5\u3082\u6E1B\u308B\u3053\u3068\u306F\u3042\u308B\u3093\u3060\u3051\u3069\u5897\u52A0\u6570\u306E\u65B9\u304C\u591A\u3044\u304B\u3089\u5909\u4F4D\u306F\u6B63\u306A\u3093\u3060\u3088\u306D",
  "id" : 134644363266490368,
  "created_at" : "2011-11-10 14:51:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134644189119000576",
  "text" : "\u3053\u3053\u4E00\u9031\u9593\u304F\u3089\u3044\u3042\u3093\u307E\u308A\u545F\u3044\u3066\u3044\u306A\u3044\u3082\u3093\u3060\u304B\u3089\u30D5\u30A9\u30ED\u30FC\u6570\u304C\u3061\u3087\u3063\u3068\u3065\u3064\u6E1B\u3063\u3066\u308B\u6C17\u304C\u3059\u308B\u30FB\u30FB\u30FB",
  "id" : 134644189119000576,
  "created_at" : "2011-11-10 14:50:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134642877962784768",
  "text" : "65\u70B9\u306A\u3089\u5358\u4F4D\u306F\u3082\u3089\u3048\u308B\u3088\u306D",
  "id" : 134642877962784768,
  "created_at" : "2011-11-10 14:45:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hanihoh",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/IMxKrK7J",
      "expanded_url" : "http:\/\/id.hanihoh.com\/r\/?k=a1111055524ebbe335ce0b4",
      "display_url" : "id.hanihoh.com\/r\/?k=a11110555\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "134642706445111296",
  "text" : "end313124\u306E\u604B\u611B\u3068\u306F\u30FB\u30FB\u30FB\u4F59\u88D5\u304C\u3042\u3063\u3066\u76F8\u624B\u3092\u7652\u3057\u7D9A\u3051\u308B\u604B\u611B\u3067\u3042\u308B\u3002 #hanihoh http:\/\/t.co\/IMxKrK7J \u305D\u30FC\u306A\u306E\u304B\u30FC\uFF08\u767D\u76EE",
  "id" : 134642706445111296,
  "created_at" : "2011-11-10 14:44:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134640281025916928",
  "text" : "BD\u30D7\u30EC\u30A4\u30E4\u30FC\u5C4A\u3044\u305F\u3051\u3069\uFF22\uFF24\u304C\u307E\u3060\u306A\u3044\u2190",
  "id" : 134640281025916928,
  "created_at" : "2011-11-10 14:35:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4F1A\u3063\u305F\u3053\u3068\u3042\u308B\u4EBA\u304C\u30C4\u30A4\u30C3\u30BF\u30FC\u4E0A\u3068\u30EA\u30A2\u30EB\u306E\u5370\u8C61\u306E\u5DEE\u3092\u6559\u3048\u3066\u304F\u308C\u308B",
      "indices" : [ 0, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134640133306724353",
  "text" : "#\u4F1A\u3063\u305F\u3053\u3068\u3042\u308B\u4EBA\u304C\u30C4\u30A4\u30C3\u30BF\u30FC\u4E0A\u3068\u30EA\u30A2\u30EB\u306E\u5370\u8C61\u306E\u5DEE\u3092\u6559\u3048\u3066\u304F\u308C\u308B",
  "id" : 134640133306724353,
  "created_at" : "2011-11-10 14:34:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134601525384318978",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 134601525384318978,
  "created_at" : "2011-11-10 12:01:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134254526864699392",
  "text" : "\u9F3B\u8A70\u307E\u308A\u3068\u5589\u306E\u75DB\u307F\u3068\u6C17\u6020\u3055\u2026\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u305F\u3089\u3042\u3063\u305F\u304B\u304F\u3057\u3066\u5BDD\u3088\u3046\u3002",
  "id" : 134254526864699392,
  "created_at" : "2011-11-09 13:02:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D3\u30EA\u30E4\u30FC\u30C9BUZZ",
      "screen_name" : "BUZZ_1220",
      "indices" : [ 0, 10 ],
      "id_str" : "391252626",
      "id" : 391252626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133947889205514240",
  "in_reply_to_user_id" : 391252626,
  "text" : "@BUZZ_1220 \u77F3\u6A4B\u3067\u3059\u3002\u643A\u5E2F\u3092\u5FD8\u308C\u3066\u3044\u308B\u3088\u3046\u306A\u306E\u3067\u3001\u53D6\u3063\u3066\u304A\u3044\u3066\u304F\u3060\u3055\u3044\u3002\u660E\u65E5\u306E\u5348\u5F8C\u53D6\u308A\u306B\u884C\u304D\u307E\u3059\u3002",
  "id" : 133947889205514240,
  "created_at" : "2011-11-08 16:44:00 +0000",
  "in_reply_to_screen_name" : "BUZZ_1220",
  "in_reply_to_user_id_str" : "391252626",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/MmWJoonM",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=tohru1101",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "133934530779283456",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001tohru1101\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/MmWJoonM",
  "id" : 133934530779283456,
  "created_at" : "2011-11-08 15:50:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133876913390366720",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 133876913390366720,
  "created_at" : "2011-11-08 12:01:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133792324739276800",
  "text" : "\u308A\u3063\u3061\u3093\u3071\u306A\u3093\u3066\u306E\u3082\u3044\u308B\u306E\u304B\uFF57\uFF57\uFF57",
  "id" : 133792324739276800,
  "created_at" : "2011-11-08 06:25:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308A\u3063\u3061\u3093\u3071",
      "screen_name" : "rittinpa",
      "indices" : [ 3, 12 ],
      "id_str" : "275107582",
      "id" : 275107582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133792238550528002",
  "text" : "RT @rittinpa: \u3086\u3063\u3061\u3093\u3071\u3001\u304F\u3063\u3057\u30FC\u3055\u3093\u304CKTP\u7DCF\u52D5\u54E1\u3057\u3066\u3075\u3041\u307C\u3063\u3066\u6B32\u3057\u3044\u3088\u3046\u3067\u3059\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "133777189765259264",
    "text" : "\u3086\u3063\u3061\u3093\u3071\u3001\u304F\u3063\u3057\u30FC\u3055\u3093\u304CKTP\u7DCF\u52D5\u54E1\u3057\u3066\u3075\u3041\u307C\u3063\u3066\u6B32\u3057\u3044\u3088\u3046\u3067\u3059\u3088",
    "id" : 133777189765259264,
    "created_at" : "2011-11-08 05:25:42 +0000",
    "user" : {
      "name" : "\u308A\u3063\u3061\u3093\u3071",
      "screen_name" : "rittinpa",
      "protected" : false,
      "id_str" : "275107582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1294897518\/ri_normal.gif",
      "id" : 275107582,
      "verified" : false
    }
  },
  "id" : 133792238550528002,
  "created_at" : "2011-11-08 06:25:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 1, 11 ],
      "id_str" : "254452685",
      "id" : 254452685
    }, {
      "name" : "\u3046\u30FC\u308D\u3093",
      "screen_name" : "urontyan",
      "indices" : [ 12, 21 ],
      "id_str" : "189175648",
      "id" : 189175648
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 22, 32 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 33, 48 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133787059398787073",
  "text" : ".@Lisa_math @urontyan @nisehorrn @G4_Hirano_chan \u304A\u306F\u3088\u3046\u3042\u308A\u304C\u3068\u3067\u3057\u305F\u30FC",
  "id" : 133787059398787073,
  "created_at" : "2011-11-08 06:04:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 7, 14 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133786734944202752",
  "text" : "\u540C\u3058\u304F RT @khulud: [RT \u8A00\u53CA] \u306A\u306B\u3053\u306E\u79C1\u7ACB\u6587\u7CFB\u5973\u5B50\u304A\u53CB\u9054\u306B\u306A\u308A\u305F\u3044\uFF0E",
  "id" : 133786734944202752,
  "created_at" : "2011-11-08 06:03:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3061\u3085\u30FC\u3071\u3093",
      "screen_name" : "Chu_pan",
      "indices" : [ 3, 11 ],
      "id_str" : "99324807",
      "id" : 99324807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133786694381076481",
  "text" : "RT @Chu_pan: \u6570\u5B66\u306E\u300C\u79FB\u9805\u300D\u306F\u5F62\u5F0F\u7684\u306B\u53F3\u304B\u3089\u5DE6\u3001\u5DE6\u304B\u3089\u53F3\u3068\u79FB\u52D5\u3055\u305B\u308B\u3079\u304D\u3067\u306F\u306A\u304F\u3001\u4E21\u8FBA\u306B\u540C\u3058\u5206\u3060\u3051\u8DB3\u3057\u7B97\u306A\u308A\u5F15\u304D\u7B97\u3059\u308B\u3068\u3044\u3046\u610F\u5473\u7684\u306A\u65B9\u6CD5\u3067\u884C\u308F\u308C\u308B\u3079\u304D\u3067\u3042\u308B\u3002\u305D\u3046\u3067\u306A\u3051\u308C\u3070\u6570\u5B66\u306E\u5B66\u7FD2\u306B\u8E93\u304F\u3002\u3068\u3001\u79C1\u7ACB\u6587\u7CFB\u5973\u5B50\u306B\u8AAC\u5F97\u3055\u308C\u5F62\u5F0F\u7684\u79FB\u9805\u3067\u80B2\u3063\u305F\u50D5\u306F\u305F\u3044\u305D\u3046\u8208\u596E\u3057\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList!\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "133784334724374528",
    "text" : "\u6570\u5B66\u306E\u300C\u79FB\u9805\u300D\u306F\u5F62\u5F0F\u7684\u306B\u53F3\u304B\u3089\u5DE6\u3001\u5DE6\u304B\u3089\u53F3\u3068\u79FB\u52D5\u3055\u305B\u308B\u3079\u304D\u3067\u306F\u306A\u304F\u3001\u4E21\u8FBA\u306B\u540C\u3058\u5206\u3060\u3051\u8DB3\u3057\u7B97\u306A\u308A\u5F15\u304D\u7B97\u3059\u308B\u3068\u3044\u3046\u610F\u5473\u7684\u306A\u65B9\u6CD5\u3067\u884C\u308F\u308C\u308B\u3079\u304D\u3067\u3042\u308B\u3002\u305D\u3046\u3067\u306A\u3051\u308C\u3070\u6570\u5B66\u306E\u5B66\u7FD2\u306B\u8E93\u304F\u3002\u3068\u3001\u79C1\u7ACB\u6587\u7CFB\u5973\u5B50\u306B\u8AAC\u5F97\u3055\u308C\u5F62\u5F0F\u7684\u79FB\u9805\u3067\u80B2\u3063\u305F\u50D5\u306F\u305F\u3044\u305D\u3046\u8208\u596E\u3057\u305F\u3002",
    "id" : 133784334724374528,
    "created_at" : "2011-11-08 05:54:05 +0000",
    "user" : {
      "name" : "\u3061\u3085\u30FC\u3071\u3093",
      "screen_name" : "Chu_pan",
      "protected" : false,
      "id_str" : "99324807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524213104498855936\/EHS-GFYv_normal.jpeg",
      "id" : 99324807,
      "verified" : false
    }
  },
  "id" : 133786694381076481,
  "created_at" : "2011-11-08 06:03:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133785963930451969",
  "text" : "\u6559\u6388\u300C\u3053\u306E\u554F\u984C\u304C\u3067\u304D\u305F\u3089\u305D\u308C\u306F\u3068\u3063\u3066\u3082\u5B09\u3057\u3044\u306A\u3063\u3066\u300D\n\u7D76\u5BFE\u72D9\u3063\u3066\u308B\u3088\u306A\u30FC\u3002\u3053\u306E\u524D\u3055\u3089\u3063\u3068\u30CF\u30EB\u30D2\u306E\u53F0\u8A5E\u3082\u3058\u3063\u3066\u305F\u3057\u3002",
  "id" : 133785963930451969,
  "created_at" : "2011-11-08 06:00:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133710505830391809",
  "geo" : { },
  "id_str" : "133712610519564288",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u9EBB\u96C0\u724C\u3092\u5B57\u724C\u306E\u5317\u3001\u7B52\u5B50\u3001\u7D22\u5B50\u3001\u842C\u5B50\u306E\uFF17\u304B\u3089\u9806\u756A\u306B\u4E26\u3079\u3066\u884C\u304F\u3060\u3051\u306E\u30B2\u30FC\u30E0\u3067\u3059\u3002\u5B57\u724C\u306F\u6771\u5357\u897F\u5317\u767D\u767A\u4E2D\u3067\u4E00\u5468\u3067\u3059\u3002\n\u305F\u3060\uFF11\uFF16\u884C\u306B\u306A\u3063\u3061\u3083\u3046\u306E\u304C\u304B\u306A\u308A\u5384\u4ECB\u3067\u3059\u3002",
  "id" : 133712610519564288,
  "in_reply_to_status_id" : 133710505830391809,
  "created_at" : "2011-11-08 01:09:05 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133710163059290112",
  "text" : "\u3042\u3068\u9EBB\u96C0\u724C\u30B8\u30A7\u30F3\u30AC\u3068\u304B\u9EBB\u96C0\u724C\u30B9\u30D4\u30FC\u30C9\u3068\u304B\u7DCF\u3058\u3066\u30AF\u30BD\u30B2\u30FC",
  "id" : 133710163059290112,
  "created_at" : "2011-11-08 00:59:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133709978551848960",
  "text" : "\u3042\u3068\u306F\u30C8\u30E9\u30F3\u30D7\u304B\u3089\u30E9\u30F3\u30C0\u30E0\u306B\u4E00\u679A\u5F15\u3044\u3066\u51FA\u305F\u6570\u5B57\u306E\u679A\u6570\u3060\u3051\u5C71\u672D\u304B\u3089\u30E9\u30F3\u30C0\u30E0\u306B\u629C\u3044\u3066\u304B\u3089\u3084\u308B\u4E03\u4E26\u3079\u3068\u304B\uFF1F\uFF17\u304C\u629C\u3051\u308B\u3068\u30AF\u30BD\u30B2\u30FC",
  "id" : 133709978551848960,
  "created_at" : "2011-11-08 00:58:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133709680710131713",
  "text" : "\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u3001\u30AF\u30BD\u30B2\u30FC\u306A\u3089\u9EBB\u96C0\u724C\u4E03\u4E26\u3079\u3068\u304B\u30AA\u30B9\u30B9\u30E1\u3067\u3059\u3088",
  "id" : 133709680710131713,
  "created_at" : "2011-11-08 00:57:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133704517492547585",
  "geo" : { },
  "id_str" : "133704679862439936",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u306F\u3088\u3046",
  "id" : 133704679862439936,
  "in_reply_to_status_id" : 133704517492547585,
  "created_at" : "2011-11-08 00:37:34 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133703170282110978",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 133703170282110978,
  "created_at" : "2011-11-08 00:31:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133703119786868737",
  "text" : "\u4E00\u9650\uFF1F\n\u4ECA\u65E5\u306F\u96E8\u964D\u3089\u306A\u3044\u3068\u3044\u3044\u3067\u3059\u306D\u3047",
  "id" : 133703119786868737,
  "created_at" : "2011-11-08 00:31:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133702957362462720",
  "text" : "\u3088\u304F\u8003\u3048\u305F\u3089\u3057\u3070\u3089\u304F\u545F\u3044\u3066\u3044\u306A\u3044\u2026",
  "id" : 133702957362462720,
  "created_at" : "2011-11-08 00:30:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 14, 23 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133472695827431424",
  "text" : "\u3069\u3046\u3044\u3046\u3053\u3068\u3060\uFF57\uFF57\uFF57 RT @akeopyaa: \u300C\u7DDA\u300D\u3092\u300C\u7DD1\u300D\u3068\u898B\u9593\u9055\u3048\u3066\uFF12\u6642\u9593\u3082\u8DB3\u8E0F\u307F\u3057\u3066\u3044\u305F\u3002\u3053\u308C\u306F\u540A\u308B\u3079\u304D",
  "id" : 133472695827431424,
  "created_at" : "2011-11-07 09:15:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133373652396818433",
  "text" : "\u3042\u3089\u3089\u5931\u793C",
  "id" : 133373652396818433,
  "created_at" : "2011-11-07 02:42:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sigmapsi",
      "screen_name" : "sigmapsi",
      "indices" : [ 0, 9 ],
      "id_str" : "22502063",
      "id" : 22502063
    }, {
      "name" : "\u307D\u307D",
      "screen_name" : "_popopopoon_",
      "indices" : [ 10, 23 ],
      "id_str" : "154165877",
      "id" : 154165877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133372371905155072",
  "geo" : { },
  "id_str" : "133373230328201216",
  "in_reply_to_user_id" : 22502063,
  "text" : "@sigmapsi @_popopopoon_\u3064 872\uFF1D\u007B(6+5\uFF09*10-1\u007D*4!\/3",
  "id" : 133373230328201216,
  "in_reply_to_status_id" : 133372371905155072,
  "created_at" : "2011-11-07 02:40:30 +0000",
  "in_reply_to_screen_name" : "sigmapsi",
  "in_reply_to_user_id_str" : "22502063",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133372840639606784",
  "text" : "\u6587\u7CFB\u306E\u6559\u6388\u304C\u7121\u77E5\u3092\u6652\u3059\u306A\u3088\u306A\u30FC\n\u3053\u308C\u3060\u304B\u3089\u6587\u7CFB\u306F\u301C\n\u3068\u304B\u8A00\u3044\u51FA\u3059\u5974\u304C\u51FA\u3066\u304D\u3066\u9762\u5012\u3060",
  "id" : 133372840639606784,
  "created_at" : "2011-11-07 02:38:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shisoku",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/TTRlwp0Q",
      "expanded_url" : "http:\/\/shindanmaker.com\/165310",
      "display_url" : "shindanmaker.com\/165310"
    } ]
  },
  "geo" : { },
  "id_str" : "133371466145214464",
  "text" : "872\uFF1D\n\u007B(6+5\uFF09*10-1\u007D*4!\/3 RT: \u307D\u307D\u306F\u30004\u30016\u30015\u300110\u30013\u30011\u3000\u306E\uFF16\u3064\u306E\u6570\u3067\u3000872\u3000\u3092\u4F5C\u308A\u307E\u3057\u3087\u3046 http:\/\/t.co\/TTRlwp0Q #shisoku \u8AB0\u304B\u3084\u3063\u3066\u3002",
  "id" : 133371466145214464,
  "created_at" : "2011-11-07 02:33:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shisoku",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/TTRlwp0Q",
      "expanded_url" : "http:\/\/shindanmaker.com\/165310",
      "display_url" : "shindanmaker.com\/165310"
    } ]
  },
  "geo" : { },
  "id_str" : "133368042158686208",
  "text" : "end313124\u306F\u30006\u300110\u300115\u300113\u30016\u30016\u3000\u306E\uFF16\u3064\u306E\u6570\u3067\u3000288\u3000\u3092\u4F5C\u308A\u307E\u3057\u3087\u3046 http:\/\/t.co\/TTRlwp0Q #shisoku \n\n\uFF16\u00D7\uFF16\u00D7(\uFF11\uFF10-\uFF16\uFF09\u00D7(\uFF11\uFF15-\uFF11\uFF13\uFF09\uFF1D\uFF12\uFF18\uFF18",
  "id" : 133368042158686208,
  "created_at" : "2011-11-07 02:19:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133152305896882176",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 133152305896882176,
  "created_at" : "2011-11-06 12:02:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/MmWJoonM",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=tohru1101",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "132805008222720000",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001tohru1101\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/MmWJoonM",
  "id" : 132805008222720000,
  "created_at" : "2011-11-05 13:02:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132789884866932736",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 132789884866932736,
  "created_at" : "2011-11-05 12:02:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132753865975144449",
  "text" : "\u3075\u3075\u3075\u3001\u91CD\u306D\u3063\u3066\u306E\u306F\u8A00\u8449\u904A\u3073\u306E\u57FA\u672C\u3067\u3059\u3057",
  "id" : 132753865975144449,
  "created_at" : "2011-11-05 09:39:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E1\u30A4\u30C9\u30B9\u30AD\u30FC\u306E\u30C9\u30B9",
      "screen_name" : "maidskii",
      "indices" : [ 16, 25 ],
      "id_str" : "101190268",
      "id" : 101190268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u304F\u3060\u3089\u306A\u3044\u30C0\u30B8\u30E3\u30EC\u3092\u8A00\u3046\u8F29\u3092\u5730\u7344\u306E\u696D\u706B\u3067\u713C\u304D\u5C3D\u304F\u3059",
      "indices" : [ 27, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132753549267443712",
  "text" : "\u60AA\u6C17\u306F\u306A\u3044\u3093\"\u3084\u304B\u3089\"\u2026 RT @maidskii: #\u304F\u3060\u3089\u306A\u3044\u30C0\u30B8\u30E3\u30EC\u3092\u8A00\u3046\u8F29\u3092\u5730\u7344\u306E\u696D\u706B\u3067\u713C\u304D\u5C3D\u304F\u3059",
  "id" : 132753549267443712,
  "created_at" : "2011-11-05 09:38:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132751507710939136",
  "text" : "RT @JOJO_math: \u307C\u304F\u306F\u541B\u3092\u3084\u308A\u3053\u3081\u305F\u304F\u3063\u3066\u9593\u9055\u3044\u3092\u6307\u6458\u3057\u305F\u3093\u3058\u3083\u3042\u306A\u3044\u305E\u30C3\uFF01\u307C\u304F\u3089\u306F\u672C\u5F53\u306E\u6570\u5B66\u8005\u3092\u3081\u3056\u3057\u3066\u3044\u308B\u304B\u3089\u3060\uFF01\u541B\u306E\u8A3C\u660E\u304C\u8AA4\u3063\u3066\u3044\u305F\u304B\u3089\u3060\uFF01\u76F8\u624B\u304C\u4EF2\u306E\u3044\u3044\u30E4\u30C4\u3060\u304B\u3089\u3063\u3066\u3000\u30BB\u30DF\u30CA\u30FC\u304C\u5EF6\u3073\u3066\u7D42\u96FB\u3092\u9003\u3059\u3068\u308F\u304B\u3063\u3066\u308B\u304B\u3089\u3063\u3066\u3000\u6570\u5B66\u8005\u306F\u52C7\u6C17\u3092\u6301\u3063\u3066\u3000\u8AA4\u308A\u3092\u6307\u6458\u3057 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "132751015782002688",
    "text" : "\u307C\u304F\u306F\u541B\u3092\u3084\u308A\u3053\u3081\u305F\u304F\u3063\u3066\u9593\u9055\u3044\u3092\u6307\u6458\u3057\u305F\u3093\u3058\u3083\u3042\u306A\u3044\u305E\u30C3\uFF01\u307C\u304F\u3089\u306F\u672C\u5F53\u306E\u6570\u5B66\u8005\u3092\u3081\u3056\u3057\u3066\u3044\u308B\u304B\u3089\u3060\uFF01\u541B\u306E\u8A3C\u660E\u304C\u8AA4\u3063\u3066\u3044\u305F\u304B\u3089\u3060\uFF01\u76F8\u624B\u304C\u4EF2\u306E\u3044\u3044\u30E4\u30C4\u3060\u304B\u3089\u3063\u3066\u3000\u30BB\u30DF\u30CA\u30FC\u304C\u5EF6\u3073\u3066\u7D42\u96FB\u3092\u9003\u3059\u3068\u308F\u304B\u3063\u3066\u308B\u304B\u3089\u3063\u3066\u3000\u6570\u5B66\u8005\u306F\u52C7\u6C17\u3092\u6301\u3063\u3066\u3000\u8AA4\u308A\u3092\u6307\u6458\u3057\u306A\u304F\u3066\u306F\u306A\u3089\u306A\u3044\u6642\u304C\u3042\u308B\u304B\u3089\u3060\u305E\u30C3\uFF01\uFF01",
    "id" : 132751015782002688,
    "created_at" : "2011-11-05 09:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 132751507710939136,
  "created_at" : "2011-11-05 09:30:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132750915022237696",
  "text" : "BD\u30D7\u30EC\u30A4\u30E4\u30FC\u6CE8\u6587\u3057\u305F\u3002\u6A5F\u5668\u7684\u72B6\u6CC1\u306E\u56DE\u907F\u3002",
  "id" : 132750915022237696,
  "created_at" : "2011-11-05 09:27:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132747772989419520",
  "text" : "\u3042\u30FC\u5FD9\u3057\u3044\u306E\u306B\u6687\u3064\u3076\u3057",
  "id" : 132747772989419520,
  "created_at" : "2011-11-05 09:15:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30F3\u30C8\u30EC\u30EC\u30C3\u30AF\u30B9\u30AF\u30B9\u30AF\u30B9",
      "screen_name" : "Antlerxxxxx",
      "indices" : [ 3, 15 ],
      "id_str" : "200417531",
      "id" : 200417531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132746810086264832",
  "text" : "RT @Antlerxxxxx: \u85E4\u539F\u7ADC\u4E5F\u3063\u305F\u3089\u4E2D\u5B66\u751F\u3067\u306F\u30AF\u30E9\u30B9\u5168\u54E1\u3067\u6BBA\u3057\u5408\u3044\u3092\u3059\u308B\u3057\u3001\u9AD8\u6821\u306B\u5165\u3063\u3066\u304B\u3089\u306F\u4E2D\u4E8C\u75C5\u3053\u3058\u3089\u305B\u3066\u65B0\u4E16\u754C\u306E\u795E\u306B\u6210\u308A\u640D\u306D\u308B\u3057\u3001\u6210\u4EBA\u3057\u3066\u304B\u3089\u306F\u501F\u91D1\u8FD4\u6E08\u306B\u547D\u8CED\u3051\u3055\u305B\u3089\u308C\u308B\u3057\u3001\u6B21\u306F\u5FC3\u7406\u30B2\u30FC\u30E0\u3067\u307E\u305F\u6BBA\u3057\u5408\u3044\u3092\u3055\u305B\u3089\u308C\u308B\u3057\u3001\u307B\u3093\u3068\u308D\u304F\u306A\u4EBA\u751F\u6B69\u3093\u3067\u306A\u3044\u306E\u306D\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tabtter.jp\" rel=\"nofollow\"\u003ETabtter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "132441381749784576",
    "text" : "\u85E4\u539F\u7ADC\u4E5F\u3063\u305F\u3089\u4E2D\u5B66\u751F\u3067\u306F\u30AF\u30E9\u30B9\u5168\u54E1\u3067\u6BBA\u3057\u5408\u3044\u3092\u3059\u308B\u3057\u3001\u9AD8\u6821\u306B\u5165\u3063\u3066\u304B\u3089\u306F\u4E2D\u4E8C\u75C5\u3053\u3058\u3089\u305B\u3066\u65B0\u4E16\u754C\u306E\u795E\u306B\u6210\u308A\u640D\u306D\u308B\u3057\u3001\u6210\u4EBA\u3057\u3066\u304B\u3089\u306F\u501F\u91D1\u8FD4\u6E08\u306B\u547D\u8CED\u3051\u3055\u305B\u3089\u308C\u308B\u3057\u3001\u6B21\u306F\u5FC3\u7406\u30B2\u30FC\u30E0\u3067\u307E\u305F\u6BBA\u3057\u5408\u3044\u3092\u3055\u305B\u3089\u308C\u308B\u3057\u3001\u307B\u3093\u3068\u308D\u304F\u306A\u4EBA\u751F\u6B69\u3093\u3067\u306A\u3044\u306E\u306D\u3002",
    "id" : 132441381749784576,
    "created_at" : "2011-11-04 12:57:40 +0000",
    "user" : {
      "name" : "\u30A2\u30F3\u30C8\u30EC\u30EC\u30C3\u30AF\u30B9\u30AF\u30B9\u30AF\u30B9",
      "screen_name" : "Antlerxxxxx",
      "protected" : false,
      "id_str" : "200417531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3301588211\/6ead08d5dcbb62bffd64e6c2bfa44818_normal.jpeg",
      "id" : 200417531,
      "verified" : false
    }
  },
  "id" : 132746810086264832,
  "created_at" : "2011-11-05 09:11:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132299527519604736",
  "text" : "\u65E9\u7A32\u7530\u6765\u305F\u3089\u6587\u5316\u796D\u6E96\u5099\u65E5\u3060\u3063\u305F\uFF57\uFF57\uFF57\uFF57",
  "id" : 132299527519604736,
  "created_at" : "2011-11-04 03:34:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132291884931485696",
  "text" : "\u65E9\u7A32\u7530\u306A\u3046",
  "id" : 132291884931485696,
  "created_at" : "2011-11-04 03:03:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132129263708160001",
  "text" : "\u6577\u3044\u3066\u3042\u308B\u7D19\u306B\u66F8\u3044\u3066\u3042\u308B\u306E\u306Fmap\uFF1F",
  "id" : 132129263708160001,
  "created_at" : "2011-11-03 16:17:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132065006383677440",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 132065006383677440,
  "created_at" : "2011-11-03 12:02:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131872332695339008",
  "text" : "\u3086\u308A\u304B\u3082\u3081\u3067\u53CB\u4EBA\u300C\u3048\u3001\u3053\u308C\u30BB\u30EB\u30D5\u30B5\u30FC\u30D3\u30B9\uFF1F\u300D\u3063\u3066\uFF57\uFF57\uFF57\uFF57",
  "id" : 131872332695339008,
  "created_at" : "2011-11-02 23:16:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/MmWJoonM",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=tohru1101",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "131678355677392897",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001tohru1101\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/MmWJoonM",
  "id" : 131678355677392897,
  "created_at" : "2011-11-02 10:25:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131665132215484416",
  "geo" : { },
  "id_str" : "131669033400532992",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30CA\u30A4\u30B9\u304B\u30FC\u3061\u3083\u3093\u3068\u5BFF\u53F8\u5C4B\uFF01",
  "id" : 131669033400532992,
  "in_reply_to_status_id" : 131665132215484416,
  "created_at" : "2011-11-02 09:48:38 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u571F\u7ADC",
      "screen_name" : "rrr4t",
      "indices" : [ 3, 9 ],
      "id_str" : "158305488",
      "id" : 158305488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131579758751383552",
  "text" : "RT @rrr4t: \u4E00\u9650\u306B\u306F\u51FA\u308B\uFF65\uFF65\uFF65\uFF65\uFF65\uFF65\uFF65\uFF01\u3000\u51FA\u308B\u304C\uFF65\uFF65\uFF65\n\u4ECA\u56DE\u3000\u307E\u3060\u3000\u305D\u306E\u6642\u3068\u5834\u6240\u306E\n\u6307\u5B9A\u307E\u3067\u306F\u3057\u3066\u3044\u306A\u3044\n\u305D\u306E\u3053\u3068\u3092\n\u3069\u3046\u304B\u8AF8\u541B\u3089\u3082\n\u601D\u3044\u51FA\u3057\u3066\u3044\u305F\u3060\u304D\u305F\u3044\n\u3064\u307E\u308A\uFF65\uFF65\uFF65\uFF65\n\u79C1\u304C\u305D\u306E\u6C17\u306B\u306A\u308C\u3070\n\u4E00\u9650\u306B\u51FA\u308B\u306E\u306F\n\u4E00\u5E74\u5F8C\u3000\u4E8C\u5E74\u5F8C\u3068\u3044\u3046\u3053\u3068\u3082\n\u53EF\u80FD\u3060\u308D\u3046\uFF65\uFF65\uFF65\uFF65\uFF65\uFF65\uFF65 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131578286479392769",
    "text" : "\u4E00\u9650\u306B\u306F\u51FA\u308B\uFF65\uFF65\uFF65\uFF65\uFF65\uFF65\uFF65\uFF01\u3000\u51FA\u308B\u304C\uFF65\uFF65\uFF65\n\u4ECA\u56DE\u3000\u307E\u3060\u3000\u305D\u306E\u6642\u3068\u5834\u6240\u306E\n\u6307\u5B9A\u307E\u3067\u306F\u3057\u3066\u3044\u306A\u3044\n\u305D\u306E\u3053\u3068\u3092\n\u3069\u3046\u304B\u8AF8\u541B\u3089\u3082\n\u601D\u3044\u51FA\u3057\u3066\u3044\u305F\u3060\u304D\u305F\u3044\n\u3064\u307E\u308A\uFF65\uFF65\uFF65\uFF65\n\u79C1\u304C\u305D\u306E\u6C17\u306B\u306A\u308C\u3070\n\u4E00\u9650\u306B\u51FA\u308B\u306E\u306F\n\u4E00\u5E74\u5F8C\u3000\u4E8C\u5E74\u5F8C\u3068\u3044\u3046\u3053\u3068\u3082\n\u53EF\u80FD\u3060\u308D\u3046\uFF65\uFF65\uFF65\uFF65\uFF65\uFF65\uFF65\uFF65\u3068\u3044\u3046\u3053\u3068\uFF65\uFF65\uFF65\uFF65\uFF01",
    "id" : 131578286479392769,
    "created_at" : "2011-11-02 03:48:02 +0000",
    "user" : {
      "name" : "\u571F\u7ADC",
      "screen_name" : "rrr4t",
      "protected" : false,
      "id_str" : "158305488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2682083920\/d0139525643086b45c4086cef4d98de0_normal.jpeg",
      "id" : 158305488,
      "verified" : false
    }
  },
  "id" : 131579758751383552,
  "created_at" : "2011-11-02 03:53:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131422901390950400",
  "text" : "@nartakio \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 131422901390950400,
  "created_at" : "2011-11-01 17:30:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131421649256976384",
  "geo" : { },
  "id_str" : "131422201634230272",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u4E00\u5FDC\u82D7\u5B57\u306F\u907F\u3051\u308B\u3079\u304D\u304B\u3068\u3002\u30CD\u30C3\u30C8\u3068\u30EA\u30A2\u30EB\u306F\u5206\u3051\u305F\u307B\u3046\u304C\u3044\u3044\u306E\u304B\u306A\u3063\u3066\u3002",
  "id" : 131422201634230272,
  "in_reply_to_status_id" : 131421649256976384,
  "created_at" : "2011-11-01 17:27:49 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131416234595074049",
  "text" : "\u306B\u3057\u3066\u3082\u3057\u3087\u304A\u3055\u3093\u306E\u30D5\u30EA\u304C\u5927\u96D1\u628A\u3059\u304E\u3066\u30A2\u30EC",
  "id" : 131416234595074049,
  "created_at" : "2011-11-01 17:04:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25BC\u3059\u305A\u304D\u3055\u3093\u3061\u306E\uFF21\u3055\u3093\u25BC",
      "screen_name" : "nicorusan",
      "indices" : [ 0, 10 ],
      "id_str" : "95638376",
      "id" : 95638376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131410330835369984",
  "geo" : { },
  "id_str" : "131415653834952705",
  "in_reply_to_user_id" : 95638376,
  "text" : "@nicorusan \u3000\u30C4\u30A4\u30C3\u30BF\u30FC\u4E0A\u306B\u306F\u8AB0\u3060\u304B\u308F\u304B\u3089\u306A\u3044\u4EBA\u306E\u65B9\u304C\u591A\u3044\u3067\u3059\n\u6614\u3055\u3089\u3063\u3068\u8AAD\u3093\u3060\u3060\u3051\u306A\u306E\u3067\u7406\u89E3\u3057\u3066\u308B\u306A\u3093\u3066\u8A00\u3048\u306A\u3044\u306E\u3067\u3059\u304C\u3001\u7C21\u5358\u306B\u8A00\u3046\u3068\u3059\u3054\u3044\u901F\u3055\u3067\u52D5\u3044\u3066\u3044\u308B\u7269\u306E\u8A71\u3067\u3059\u3002",
  "id" : 131415653834952705,
  "in_reply_to_status_id" : 131410330835369984,
  "created_at" : "2011-11-01 17:01:48 +0000",
  "in_reply_to_screen_name" : "nicorusan",
  "in_reply_to_user_id_str" : "95638376",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u81EA\u5206\u3068\u540C\u3058\u8A95\u751F\u65E5\u306E\u6709\u540D\u4EBA",
      "indices" : [ 26, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131415144919076865",
  "text" : "\u30C8\u30FC\u30DE\u30B9\u30FB\u30A8\u30B8\u30BD\u30F3\u3000\u6298\u53E3\u4FE1\u592B\u3000\u304F\u3089\u3044\u304B\u3001\u6709\u540D\u306A\u306E\u306F\u3000#\u81EA\u5206\u3068\u540C\u3058\u8A95\u751F\u65E5\u306E\u6709\u540D\u4EBA",
  "id" : 131415144919076865,
  "created_at" : "2011-11-01 16:59:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131405410245672960",
  "geo" : { },
  "id_str" : "131407162286149633",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u306A\u3093\u3068\u3044\u3046\u30A8\u30A2\u3058\u3083\u306A\u3044\u30A8\u30A2\u30EA\u30D7\u30E9\u30A4\u3002\n\u3053\u3093\u3069\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u306E\u8A71\u3092\u6388\u696D\u3067\u767A\u8868\u3057\u306A\u304D\u3083\u306A\u306E\u3067\u3001\u3069\u306E\u307F\u3061\u52C9\u5F37\u3057\u307E\u3059\u3002\u3082\u3046\u3061\u3087\u3063\u3068\u5F85\u3063\u3066\u304F\u3060\u3055\u3044\u306A\u3002",
  "id" : 131407162286149633,
  "in_reply_to_status_id" : 131405410245672960,
  "created_at" : "2011-11-01 16:28:03 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5BFF\u53F8",
      "screen_name" : "sushi_inc",
      "indices" : [ 3, 13 ],
      "id_str" : "62873580",
      "id" : 62873580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131403050324725760",
  "text" : "RT @sushi_inc: \u5149\u901F\u306B\u8FD1\u3044\u901F\u5EA6\u3067\u56DE\u8EE2\u3059\u308B\u5BFF\u53F8\u306F\u9759\u6B62\u3057\u3066\u3044\u308B\u4EBA\u9593\u304B\u3089\u307F\u3066\u76F8\u5BFE\u7684\u306B\u6642\u9593\u306E\u9032\u307F\u304C\u9045\u304F\u306A\u308A\u3001\u9BAE\u5EA6\u3092\u4FDD\u3064\u3053\u3068\u304C\u51FA\u6765\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131349631547359234",
    "text" : "\u5149\u901F\u306B\u8FD1\u3044\u901F\u5EA6\u3067\u56DE\u8EE2\u3059\u308B\u5BFF\u53F8\u306F\u9759\u6B62\u3057\u3066\u3044\u308B\u4EBA\u9593\u304B\u3089\u307F\u3066\u76F8\u5BFE\u7684\u306B\u6642\u9593\u306E\u9032\u307F\u304C\u9045\u304F\u306A\u308A\u3001\u9BAE\u5EA6\u3092\u4FDD\u3064\u3053\u3068\u304C\u51FA\u6765\u307E\u3059\u3002",
    "id" : 131349631547359234,
    "created_at" : "2011-11-01 12:39:27 +0000",
    "user" : {
      "name" : "\u5BFF\u53F8",
      "screen_name" : "sushi_inc",
      "protected" : false,
      "id_str" : "62873580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1589165367\/sushi_normal.png",
      "id" : 62873580,
      "verified" : false
    }
  },
  "id" : 131403050324725760,
  "created_at" : "2011-11-01 16:11:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131340146468601856",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 131340146468601856,
  "created_at" : "2011-11-01 12:01:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131297901296091136",
  "text" : "\u5341\u5168\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u5341\u5168\u3067\u306F\u3042\u308A\u307E\u305B\u3093",
  "id" : 131297901296091136,
  "created_at" : "2011-11-01 09:13:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131297205557534720",
  "text" : "\u30B3\u30FC\u30EB\u306E\u6559\u5BA4\u3082\u3042\u307E\u308A\u597D\u304D\u3058\u3083\u306A\u3044\u3002\n\u3066\u304B\uFF14\u5171\u81EA\u4F53\u304C\u3002",
  "id" : 131297205557534720,
  "created_at" : "2011-11-01 09:11:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131297063232212992",
  "text" : "\u4EBA\u9593\u306F\u597D\u304D\u3060\u3051\u3069\u4EBA\u6DF7\u307F\u306F\u5ACC\u3044\u3002\n\u5927\u6559\u5BA4\u306B\u3044\u3063\u3071\u3044\u3044\u308B\u72B6\u614B\u3082\u5ACC\u3044\u3002",
  "id" : 131297063232212992,
  "created_at" : "2011-11-01 09:10:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131293461486899202",
  "text" : "\u306B\u305B\u307B\u97F3\u30B2\u30FC\u30AF\u30E9\u30B9\u30BF\u306A\u3093\u3067\u3059\uFF1F",
  "id" : 131293461486899202,
  "created_at" : "2011-11-01 08:56:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 3, 12 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131293369057030144",
  "text" : "RT @nisehorn: \u30AF\u30C3\u30AD\u30FC\u306E\u9023\u76BF\u30C8\u30EA\u30EB\u629C\u3051\u305F\u3042\u3068\u3067\u843D\u3061\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131293228656889856",
    "text" : "\u30AF\u30C3\u30AD\u30FC\u306E\u9023\u76BF\u30C8\u30EA\u30EB\u629C\u3051\u305F\u3042\u3068\u3067\u843D\u3061\u305F",
    "id" : 131293228656889856,
    "created_at" : "2011-11-01 08:55:19 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "protected" : false,
      "id_str" : "96348838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009677836\/06-12-24_23-49m_normal.jpg",
      "id" : 96348838,
      "verified" : false
    }
  },
  "id" : 131293369057030144,
  "created_at" : "2011-11-01 08:55:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131293203780476928",
  "text" : "\u8A66\u9A13\u7BC4\u56F2\u3042\u3063\u3066\u3066\u30DB\u30C3",
  "id" : 131293203780476928,
  "created_at" : "2011-11-01 08:55:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131292508847218688",
  "text" : "\u6700\u8FD1\u3075\u3041\u307C\u2252\u30D5\u30A9\u30ED\u30FC\u6570\u306E\u6CD5\u5247\u304C\u5D29\u308C\u3064\u3064\u3042\u308B\u306A\u30FC\n\u3044\u3084\u3001\u306A\u3093\u306E\u5408\u7406\u6027\u3082\u306A\u3044\u6CD5\u5247\u3060\u3057\u5D29\u308C\u3066\u3082\u3044\u3044\u3093\u3060\u3051\u3069",
  "id" : 131292508847218688,
  "created_at" : "2011-11-01 08:52:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131291922345103360",
  "text" : "\u30B3\u30FC\u30EB\u306E\u6559\u5BA4\u306A\u3046\u3063",
  "id" : 131291922345103360,
  "created_at" : "2011-11-01 08:50:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 3, 18 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131218578899861504",
  "text" : "RT @haruhalcyoncat: \u5F7C\u5973\u3068\u307E\u3067\u306F\u8A00\u308F\u306A\u3044\u304B\u3089\u4F55\u304B\u3068\u3057\u3093\u3069\u3044\u6642\u3084\u8F9B\u3044\u6642\u306B\u898B\u3066\u8A71\u305B\u308B\u3060\u3051\u3067\u305D\u3046\u3044\u3063\u305F\u6C17\u75B2\u308C\u304C\u4E00\u6C17\u306B\u5439\u304D\u98DB\u3076\u3088\u3046\u306A\u201C\u597D\u304D\u306A\u4EBA\u201D\u304C\u8EAB\u8FD1\u306B\u3044\u3066\u6B32\u3057\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131217289184935936",
    "text" : "\u5F7C\u5973\u3068\u307E\u3067\u306F\u8A00\u308F\u306A\u3044\u304B\u3089\u4F55\u304B\u3068\u3057\u3093\u3069\u3044\u6642\u3084\u8F9B\u3044\u6642\u306B\u898B\u3066\u8A71\u305B\u308B\u3060\u3051\u3067\u305D\u3046\u3044\u3063\u305F\u6C17\u75B2\u308C\u304C\u4E00\u6C17\u306B\u5439\u304D\u98DB\u3076\u3088\u3046\u306A\u201C\u597D\u304D\u306A\u4EBA\u201D\u304C\u8EAB\u8FD1\u306B\u3044\u3066\u6B32\u3057\u3044\u3002",
    "id" : 131217289184935936,
    "created_at" : "2011-11-01 03:53:34 +0000",
    "user" : {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "protected" : false,
      "id_str" : "97121312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502815992611758081\/wOrq-PHB_normal.jpeg",
      "id" : 97121312,
      "verified" : false
    }
  },
  "id" : 131218578899861504,
  "created_at" : "2011-11-01 03:58:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131218506334224384",
  "text" : "\u305D\u3046\u3044\u3084\u30C1\u30A7\u30C3\u30AF\u3057\u3066\u306D\u3047 RT : \u4ECA\u65E5\u306E\u30B3\u30FC\u30EB\u306E\u8A66\u9A13\u3063\u3066\u3069\u3053\u3067\u3042\u308B\u3093\u3067\u3059\u304B\uFF1F",
  "id" : 131218506334224384,
  "created_at" : "2011-11-01 03:58:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131217629137477632",
  "text" : "\u5F97\u3082\u8A00\u308F\u308C\u306C\u3053\u306E\u7720\u6C17\u3092\u89E3\u6D88\u3059\u308B\u306B\u306F\uFF13\u9650\u307E\u3067\u306E(\u6642\u9593\u306E\uFF09\u7A7A\u767D\u306F\u4F59\u308A\u306B\u72ED\u3059\u304E\u308B",
  "id" : 131217629137477632,
  "created_at" : "2011-11-01 03:54:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3084\u304D\u305D\u3070\u30D1\u30F3",
      "screen_name" : "VIPPER2000",
      "indices" : [ 3, 14 ],
      "id_str" : "222379599",
      "id" : 222379599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131216974528253952",
  "text" : "RT @VIPPER2000: 12\/24\u3092\u56DE\u907F\u3059\u308B\u65B9\u6CD5\n12\u670823\u65E523\u6642\u9803\uFF08\u65E5\u672C\u6642\u9593\uFF09\u3000\u7FBD\u7530\u767A\u30ED\u30B5\u30F3\u30BC\u30EB\u30B9\u884C\u304D\u306E\u98DB\u884C\u6A5F\u306B\u4E57\u308B\n12\u670823\u65E516\u6642\u9803\uFF08\u73FE\u5730\u6642\u9593\uFF09\u3000\u30ED\u30B5\u30F3\u30BC\u30EB\u30B9\u5230\u7740\n12\u670823\u65E523\u6642\u9803\uFF08\u73FE\u5730\u6642\u9593\uFF09\u3000\u30ED\u30B5\u30F3\u30BC\u30EB\u30B9\u767A\u7FBD\u7530\u884C\u304D\u306E\u98DB\u884C\u6A5F\u306B\u4E57\u308B\n12\u670825\u65E54\u6642\u9803 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129093255919972352",
    "text" : "12\/24\u3092\u56DE\u907F\u3059\u308B\u65B9\u6CD5\n12\u670823\u65E523\u6642\u9803\uFF08\u65E5\u672C\u6642\u9593\uFF09\u3000\u7FBD\u7530\u767A\u30ED\u30B5\u30F3\u30BC\u30EB\u30B9\u884C\u304D\u306E\u98DB\u884C\u6A5F\u306B\u4E57\u308B\n12\u670823\u65E516\u6642\u9803\uFF08\u73FE\u5730\u6642\u9593\uFF09\u3000\u30ED\u30B5\u30F3\u30BC\u30EB\u30B9\u5230\u7740\n12\u670823\u65E523\u6642\u9803\uFF08\u73FE\u5730\u6642\u9593\uFF09\u3000\u30ED\u30B5\u30F3\u30BC\u30EB\u30B9\u767A\u7FBD\u7530\u884C\u304D\u306E\u98DB\u884C\u6A5F\u306B\u4E57\u308B\n12\u670825\u65E54\u6642\u9803\uFF08\u65E5\u672C\u6642\u9593\uFF09\u3000\u7FBD\u7530\u5230\u7740\n\u3053\u308C\u3067\u56DE\u907F\u3067\u304D\u308B",
    "id" : 129093255919972352,
    "created_at" : "2011-10-26 07:13:25 +0000",
    "user" : {
      "name" : "\u3084\u304D\u305D\u3070\u30D1\u30F3",
      "screen_name" : "VIPPER2000",
      "protected" : false,
      "id_str" : "222379599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1676841364\/4fd02432_normal.jpg",
      "id" : 222379599,
      "verified" : false
    }
  },
  "id" : 131216974528253952,
  "created_at" : "2011-11-01 03:52:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131199148652367872",
  "text" : "\u3042\u308C\u3001\u81EA\u5206\u304C\u3044\u308B\u3002",
  "id" : 131199148652367872,
  "created_at" : "2011-11-01 02:41:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3066\u3051\u3066\u308C",
      "screen_name" : "nobumitsu_efb",
      "indices" : [ 3, 17 ],
      "id_str" : "335805395",
      "id" : 335805395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131198959623475201",
  "text" : "RT @nobumitsu_efb: \u306B\u3057\u3066\u3082\u3001\u706B\u66DC\u65E5\u306E\uFF11\u9650\u5BDD\u574A\uFF12\u9650\u9045\u523B\u304C\u30C7\u30D5\u30A9\u3059\u304E\u3066\u56F0\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131197778201292801",
    "text" : "\u306B\u3057\u3066\u3082\u3001\u706B\u66DC\u65E5\u306E\uFF11\u9650\u5BDD\u574A\uFF12\u9650\u9045\u523B\u304C\u30C7\u30D5\u30A9\u3059\u304E\u3066\u56F0\u308B",
    "id" : 131197778201292801,
    "created_at" : "2011-11-01 02:36:02 +0000",
    "user" : {
      "name" : "\u3066\u3051\u3066\u308C",
      "screen_name" : "nobumitsu_efb",
      "protected" : false,
      "id_str" : "335805395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2364046165\/mat46btxh5erxof1t804_normal.jpeg",
      "id" : 335805395,
      "verified" : false
    }
  },
  "id" : 131198959623475201,
  "created_at" : "2011-11-01 02:40:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 1, 12 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 13, 22 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 23, 38 ],
      "id_str" : "227502200",
      "id" : 227502200
    }, {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 39, 47 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131198410605858816",
  "text" : ".@magokoro84 @nisehorn @G4_Hirano_chan @i_horse \u304A\u3084\u3059\u307F\u3069\u3082\u3067\u3057\u305F\u30FC",
  "id" : 131198410605858816,
  "created_at" : "2011-11-01 02:38:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131074509863264258",
  "text" : "\u3044\u3064\u304B\u9CF4\u6EDD\u3055\u3093\u306B\u672C\u540D\u3092\u63A1\u70B9\u3057\u3066\u3082\u3089\u304A\u3046\u3002\u3057\u304B\u3057\u305D\u308C\u306F\u4ECA\u3058\u3083\u306A\u3044\u3002",
  "id" : 131074509863264258,
  "created_at" : "2011-10-31 18:26:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131062268900294656",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 131062268900294656,
  "created_at" : "2011-10-31 17:37:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131061005265547264",
  "text" : "\u72B6\u6CC1\u306B\u5FDC\u3058\u3066\u6253\u3061\u65B9\u5909\u3048\u3066\u308B\u3088\u3046\u3058\u3083\u30C7\u30B8\u30BF\u30EB\u3067\u306F\u306A\u3044\u3093\u3060\u308D\u3046\u3051\u3069\u3001\u305F\u3076\u3093\u6027\u683C\u7684\u306B\u30C7\u30B8\u30BF\u30EB\u306B\u306F\u5FB9\u305B\u306A\u3044\u3093\u3060\u308D\u3046\u306A\u30FC",
  "id" : 131061005265547264,
  "created_at" : "2011-10-31 17:32:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131060834146332672",
  "text" : "\u4E00\u822C\u306B\u306F\u6E80\u8CAB\u3042\u3063\u305F\u3089\u63A1\u7B97\u306F\u53D6\u308C\u308B\u3051\u3069\u72B6\u6CC1\u306B\u4F9D\u308B\u3093\u3060\u3088\u306A\u30FC\u2190\n\u30EA\u30A2\u30EB\u3060\u3068\u3069\u3046\u3057\u3088\u3046\u3082\u306A\u304F\u306A\u3063\u3066\u30AA\u30FC\u30D7\u30F3\u7ACB\u76F4\u3092\u639B\u3051\u308B\u3093\u3060\u3051\u308C\u3069\u3002",
  "id" : 131060834146332672,
  "created_at" : "2011-10-31 17:31:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131060117562081280",
  "geo" : { },
  "id_str" : "131060389508153346",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 131060389508153346,
  "in_reply_to_status_id" : 131060117562081280,
  "created_at" : "2011-10-31 17:30:06 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131060253470097408",
  "text" : "\u653B\u3081\u308B\u306B\u8DB3\u308B\u624B\u3068\u5B88\u308A\u306B\u5165\u308B\u3079\u304D\u624B\u3068",
  "id" : 131060253470097408,
  "created_at" : "2011-10-31 17:29:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131059483085520896",
  "geo" : { },
  "id_str" : "131060092719202304",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u305D\u3053\u306E\u5869\u6885\u304C\u3080\u305A\u304B\u3057\u3044\u3067\u3059\u3088\u306D\u3002\u914D\u724C\u3084\u30C4\u30E2\u304C\u60AA\u3044\u6642\u3067\u3082\u9811\u5F35\u3063\u3066\uFF14\u4F4D\u306F\u907F\u3051\u305F\u3044\u3067\u3059\u3002",
  "id" : 131060092719202304,
  "in_reply_to_status_id" : 131059483085520896,
  "created_at" : "2011-10-31 17:28:55 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 17, 26 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131059200636887042",
  "text" : "\u632F\u308A\u8FBC\u307E\u306A\u3044\u9EBB\u96C0\u306F\u5F37\u3044\u3067\u3059 RT @isaribiz \u914D\u724C\u3084\u30C4\u30E2\u304C\u5168\u7136\u3067\u4ED6\u5BB6\u304C\u30EA\u30FC\u30C1\u304B\u3051\u308B\u30D1\u30BF\u30FC\u30F3\u304C\u591A\u304B\u3063\u305F\u304B\u3089\u306D\u3002\u632F\u308A\u8FBC\u3080\u53EF\u80FD\u6027\u3042\u3063\u305F\u306E\u306B\u7121\u7406\u306B\u30C6\u30F3\u30D1\u30A4\u53D6\u308A\u306B\u884C\u3063\u3066\u7D50\u5C40\u632F\u308A\u8FBC\u3080\u3063\u3066\u3044\u3046\u306D^q^",
  "id" : 131059200636887042,
  "created_at" : "2011-10-31 17:25:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 7, 18 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131055852487573506",
  "text" : "\u304E\u304F\u3063 RT @magokoro84 \u82F1\u8A9E\u3068\u3044\u3046\u304B\u8A9E\u5B66\u306F\u6BCE\u65E5\u3084\u3089\u306A\u3042\u304B\u3093\u306A",
  "id" : 131055852487573506,
  "created_at" : "2011-10-31 17:12:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131052124200112129",
  "geo" : { },
  "id_str" : "131052408112562176",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u6975\u9650\u6271\u3046\u304B\u2026\u89E3\u6790\u5E83\u3044\u306A",
  "id" : 131052408112562176,
  "in_reply_to_status_id" : 131052124200112129,
  "created_at" : "2011-10-31 16:58:23 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131051862379073536",
  "text" : "\u7D50\u5C40\u30B3\u30FC\u30EB\u306E\u7BC4\u56F2\u304C\u4ECA\u3072\u3068\u3064\u4E0D\u5B89",
  "id" : 131051862379073536,
  "created_at" : "2011-10-31 16:56:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131051503703175168",
  "text" : "\u3042\u3001QT\u3058\u3083\u3093",
  "id" : 131051503703175168,
  "created_at" : "2011-10-31 16:54:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 10, 21 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131050473779240960",
  "geo" : { },
  "id_str" : "131051078216200194",
  "in_reply_to_user_id" : 349830212,
  "text" : "\u3064\u78BA\u7387\u30FB\u7D71\u8A08 QT @haguruma20: \u5B66\u90E8\u306E\u81EA\u5206\u304B\u3089\u898B\u308B\u3068\u3001\u4EE3\u6570\u30FB\u5E7E\u4F55\u30FB\u89E3\u6790\u30FB\u8A08\u7B97\u6A5F\u30FB\u57FA\u790E\u8AD6\u30FB\u6570\u54F2\u30FB\u30FB\u30FB\uFF1F",
  "id" : 131051078216200194,
  "in_reply_to_status_id" : 131050473779240960,
  "created_at" : "2011-10-31 16:53:06 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131044067831328768",
  "text" : "\u9CF4\u6EDD\u3055\u3093\u306E\u4F4F\u74B0\u5883\u306F\u3069\u3046\u306A\u3063\u3066\u3044\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 131044067831328768,
  "created_at" : "2011-10-31 16:25:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131036362534170625",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u4ECA\u65E5\u306E\u30B3\u30FC\u30EB\u306E\u4E88\u7FD2\u305B\u306A",
  "id" : 131036362534170625,
  "created_at" : "2011-10-31 15:54:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131036231021760512",
  "text" : "\u81EA\u5206\u306F\u4EE3\u6570\u30AF\u30E9\u30B9\u30BF\u306E\u81EA\u899A\u3082\u89E3\u6790\u30AF\u30E9\u30B9\u30BF\u306E\u81EA\u899A\u3082\u306A\u3044\u3051\u3069\u3069\u3053\u306B\u5C5E\u3059\u308B\u306E\u3060\u308D\u3046\u2026",
  "id" : 131036231021760512,
  "created_at" : "2011-10-31 15:54:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131035937458229248",
  "text" : "\u6388\u696D\u3082\u3069\u304D\u3092\u3084\u3063\u3066\u307F\u3066\u521D\u3081\u3066\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u306E\u30BB\u30DF\u30CA\u30FC\u306E\u51C4\u3055\u306B\u6C17\u4ED8\u304F",
  "id" : 131035937458229248,
  "created_at" : "2011-10-31 15:52:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131035702614953984",
  "text" : "\u767D\u677F\u3092\u524D\u306B\u30C6\u30F3\u30B7\u30E7\u30F3\u304C\u4E0A\u304C\u308B\u73FE\u8C61\u306B\u540D\u524D\u306A\u3044\u306E\uFF1F",
  "id" : 131035702614953984,
  "created_at" : "2011-10-31 15:52:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]