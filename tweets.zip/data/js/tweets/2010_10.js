Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29264778896",
  "geo" : { },
  "id_str" : "29266082157",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u3057\u3066\u5DE6\u624B\u3067\uFF08\u3086\u3063\u304F\u308A\u3060\u304C\uFF09\u3054\u98EF\u98DF\u3079\u305F\u308A\u30D3\u30EA\u30E4\u30FC\u30C9\u51FA\u6765\u308B\u4FFA\u304C\u3044\u308B\u3002",
  "id" : 29266082157,
  "in_reply_to_status_id" : 29264778896,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29152773350",
  "text" : "\u304A\u306F\u3088\u3046",
  "id" : 29152773350,
  "created_at" : "2010-10-30 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29124257930",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 29124257930,
  "created_at" : "2010-10-29 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29006109590",
  "text" : "\u643A\u5E2F\u3060\u304C\u5B57\u4E00\u8272\u3001\u5C0F\u56DB\u559C\u51FA\u305F\u3002",
  "id" : 29006109590,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28846030338",
  "text" : "\u4E8C\u5EA6\u5BDD\u3001\u4E8C\u5EA6\u5BDD\u3001\u4E8C\u5EA6\u5BDD\u2026\u7D50\u5C40\uFF12\u9650\u306B\u3082\u9593\u306B\u5408\u308F\u306A\u3044\uFF57\uFF14\u9650\u4F11\u8B1B\u3060\u3057\u3001\u81EA\u4E3B\u4F11\u65E5\u304B\u306A\u3002",
  "id" : 28846030338,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28883044829",
  "text" : "\u7D50\u5C40\uFF11\uFF11\u6642\u904E\u304E\u306B\u8D77\u304D\u306615\uFF5E16:30\u307E\u3067\u5348\u7761\u2026\u4E4B\u306F\u9177\u3044\u3002",
  "id" : 28883044829,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28928614176",
  "text" : "\u96E8\u30A7\u2026",
  "id" : 28928614176,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28932627326",
  "geo" : { },
  "id_str" : "28935204524",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u8ECA\u304B\u3089\u4F7F\u7528\u6E08\u306E\u3092\u6295\u3052\u3066\u697D\u3057\u3093\u3067\u305F\u963F\u5446\u304C\u6355\u307E\u3063\u305F\u3089\u3057\u3044",
  "id" : 28935204524,
  "in_reply_to_status_id" : 28932627326,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28935399173",
  "text" : "\u5BD2\u3044\u3068\u8033\u306E\u3057\u305F\u3001\u984E\u306E\u4ED8\u3051\u6839(\uFF1F)\u304C\u75DB\u3080\u306E\u306F\u4FFA\u3060\u3051\uFF1F",
  "id" : 28935399173,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28752473009",
  "text" : "\u5BD2\u3059\u304E\u308B\uFF01\u9577\u8896\u4E8C\u679A\uFF0B\u03B1\u3067\u307E\u3060\u5BD2\u3044\uFF01",
  "id" : 28752473009,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28796499486",
  "text" : "\u4ECA\u65E5\u9719\u3068\u96EA\u306E\u9593\u307F\u305F\u3044\u306E\u964D\u3063\u3066\u305F\u3001\u3067\u3001\u79CB\u306F\u3069\u3046\u3057\u305F\uFF1F\uFF57",
  "id" : 28796499486,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28644787784",
  "text" : "\u300C\u5BDD\u574A\u3057\u305F\u5922\u300D\u3092\u898B\u305F\u3002\u3084\u3084\u3053\u3057\u3044\u304B\u3089\u30DB\u30F3\u30C8\u6B62\u3081\u3066\u307B\u3057\u3044\u3002",
  "id" : 28644787784,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28670019355",
  "text" : "@chisa10404 \u30C9\u30A4\u30C4\u3001\u30ED\u30B7\u30A2\u306F\u65B9\u8A00\u304C\u304D\u3064\u3044\u3068\u805E\u304D\u307E\u3059\uFF57\u9811\u5F35\u3063\u3066\u304F\u3060\u3055\u3044\u306A\uFF57",
  "id" : 28670019355,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28671411840",
  "text" : "\u9ED2\u732B\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 28671411840,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28675164492",
  "text" : "\u4F0A\u5742\u3055\u3093\u65B0\u520A\u51FA\u305F\u306E\u304B\u30FC\u3002\u30A2\u30B5\u30AC\u30AA\u597D\u304D\u3060\u304B\u3089\u671F\u5F85\u3060\uFF57",
  "id" : 28675164492,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28675497130",
  "text" : "\u69FF\uFF08\u3042\u3055\u304C\u304A\uFF09\u306D\uFF57\u4F0A\u5742\u4F5C\u54C1\u306F\u518D\u767B\u5834\u304C\u3042\u3063\u3066\u3044\u3044\u3002",
  "id" : 28675497130,
  "created_at" : "2010-10-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28573733408",
  "text" : "\u56DB\u6697\u523B\u30AD\u30BF\u30FC\uFF01\nhttp:\/\/tenhou.net\/0\/?log=2010102415gm-0009-0000-bf20df0e&tw=1",
  "id" : 28573733408,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28575738497",
  "geo" : { },
  "id_str" : "28576473416",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u308C\u3060\u3068\u304D\u306E\u3053\u306E\u91CC\u3092\u8CB7\u3046\u3057\u304B\u306A\u304F\u306A\u3063\u3066\u307E\u305A\u3044\u3093\u3058\u3083\u306D\uFF1F",
  "id" : 28576473416,
  "in_reply_to_status_id" : 28575738497,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28581105606",
  "text" : "\u5929\u6D25\u98EF\u30A6\u30DE\u30FC\u3000\u30AB\u30CB\u3058\u3083\u306A\u304F\u3066\u30C4\u30CA\u3060\u3051\u3069\uFF57",
  "id" : 28581105606,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28491281659",
  "text" : "\u708A\u304D\u8FBC\u307F\u3054\u98EF\u306E\u6C34\u52A0\u6E1B\u3001\u3046\u307E\u304F\u3044\u3063\u305F\uFF01",
  "id" : 28491281659,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28401391685",
  "text" : "\u6625\u65E5\u91CE\u7A79\u2252\u767D\u30EC\u30F3\u3000\u3056\u304F\u308D\u2252\u970A\u5922\u3000\u4FFA\u306E\u59B9\u304C\uFF5E\u306E\u5144\u2252\u30A2\u30E9\u30E9\u30AE\u3055\u3093",
  "id" : 28401391685,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28406873124",
  "text" : "@koketomi \u3042\u30FC\u30C8\u30E9\u3069\u3089\u306E\u4E3B\u4EBA\u516C\u3060\u3063\u305F\u304B\u3082\u3002\u898B\u305F\u76EE\u3068\u8A00\u3046\u304B\u96F0\u56F2\u6C17\u304C\u4FFA\u306E\u4E2D\u3067\u306F\u88AB\u3063\u3066\u308B\uFF57",
  "id" : 28406873124,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28407142751",
  "text" : "@koketomi \u3068\u601D\u3063\u3066\u30B0\u30B0\u3063\u3066\u898B\u6BD4\u3079\u3066\u307F\u305F\u304C\u305D\u3046\u3067\u3082\u306A\u3044\u306A\uFF57\uFF57\uFF57",
  "id" : 28407142751,
  "created_at" : "2010-10-22 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28017639811",
  "text" : "@koketomi \u9EBB\u85AC\u4E91\u3005\u304C\u307E\u305A\u3044\u306E\u306F\u3088\u304F\u308F\u304B\u308B\u304C\u3001\u3069\u3046\u3082\u3053\u3046\u3044\u3046\u8ABF\u67FB\u3067\u300C\u624B\u306B\u5165\u308C\u308B\u4E8B\u304C\u51FA\u6765\u308B\u300D\u3063\u3066\u7B54\u3048\u308B\u5974\u3063\u3066\u300C\u77E5\u308A\u5408\u3044\u306E\u77E5\u308A\u5408\u3044\u306F\u30A2\u30EB\u30AB\u30A4\u30C0\u300D\u7684\u306A\u30CE\u30EA\u3067\u8A00\u3063\u3066\u308B\u6C17\u304C\u3057\u3066\u306A\u3089\u306A\u3044\u3002",
  "id" : 28017639811,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27927492121",
  "geo" : { },
  "id_str" : "27931961795",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30B3\u30FC\u30D2\u30FC\u98F2\u307F\u305F\u304F\u306A\u3063\u3061\u3083\u3063\u305F\u3058\u3083\u306A\u3044\u304B\uFF57\u30DB\u30C3\u30C8\u306B\u3059\u308B\u308F\uFF57",
  "id" : 27931961795,
  "in_reply_to_status_id" : 27927492121,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27936531675",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u306B\u30B3\u30FC\u30D2\u30FC\u98F2\u3080\u3079\u304D\u3058\u3083\u306A\u3044\u3088\u306A-\u663C\u5BDD\u3082\u3057\u3061\u3083\u3063\u305F\u3057\u660E\u65E5\u306E\u4E00\u9650\u4E0D\u5B89\u3060\u30FB\u30FB\u30FB\u3067\u3082\u7D42\u308F\u3089\u306A\u3044\u8AB2\u984Corz",
  "id" : 27936531675,
  "created_at" : "2010-10-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27793571242",
  "text" : "\u30B0\u30E9\u30D5\u306E\u6982\u5F62\u4E0E\u3048\u3066\u51FD\u6570\u6C42\u3081\u308B\u30EC\u30DD\u30FC\u30C8\u3002\u5B9F\u306F\u6388\u696D\u306E\u4F8B\u984C\u306E180\u00B0\u56DE\u8EE2\u306A\u3093\u3060\u3051\u3069\u3001\u56DE\u8EE2\u884C\u5217\u3067\u77AC\u6BBA\u3060\u3068\u30EC\u30DD\u30FC\u30C8\u306E\u610F\u5473\u306A\u3044\u3088\u306A\u30FC\u3002\u3082\u3046\u5C11\u3057\u8003\u3048\u3066\u307F\u3088\u3046\u3002",
  "id" : 27793571242,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27802533989",
  "text" : "\u4E00\u9650\u3067\u4E8C\u9805\u5206\u5E03\u3001\u4E09\u9650\u3067\u3082\u4E8C\u9805\u5206\u5E03orz",
  "id" : 27802533989,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27834148632",
  "text" : "@koketomi \u6975\u9650\u3068\u3063\u305F\u3089\u7406\u7CFB\u3060\u3051\u3069\u4E00\u5FDC\u6587\u7CFB\u306E\u7BC4\u56F2\u306B\u3042\u308B\u3002\u3053\u306E\u30B3\u30E1\u30F3\u30C8\u304C\u3059\u3067\u306B\u7406\uFF4B\uFF08\uFF52\uFF59",
  "id" : 27834148632,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27700214491",
  "text" : "\u85AC\u5B66\u90E8\u30AD\u30E3\u30F3\u30D1\u30B9\u306A\u3046\u3002\uFF14\u9650\u3084\u308B\u3068\u3053\u304B\u3089\u9060\u3044\u306A\u30FC\u3001\u9593\u306B\u5408\u3046\u304B\u306A\u30FC\u3002",
  "id" : 27700214491,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27716589993",
  "text" : "@koketomi \u98DF\u308F\u306A\u3055\u3059\u304E\u3058\u3083\u306D\uFF1F\u98DF\u3079\u3066\u6696\u304B\u304F\u3057\u3066\u5BDD\u306A\u3055\u3044\u3002\u304A\u5927\u4E8B\u306B\u3002",
  "id" : 27716589993,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27716657821",
  "text" : "\u4ECA\u30FC\u79C1\u306E\u30FC\u9858\u30FC\u3044\u3054\u3068\u304C\u30FC\u53F6\u3046\u306A\u30FC\u3089\u3070\u30FC\u3001\u4ED5\u4E8B\u304C\u30FC\u6B32\u3057\u30FC\u3044\uFF08\u5207\u5B9F\uFF09",
  "id" : 27716657821,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27618683034",
  "text" : "\u30E8\u30FC\u30B0\u30EB\u30C8\u30A6\u30DE\u30FC",
  "id" : 27618683034,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27637067242",
  "text" : "\u77E5\u308A\u5408\u3044\u306E\u77E5\u308A\u5408\u3044\u304F\u3089\u3044\u306E\u7BC4\u56F2\u3067\u5BB6\u5EAD\u6559\u5E2B\u52DF\u96C6\u3057\u3066\u308B\u4EBA\u3044\u306A\u3044\u304B\u306A\u30FC\u3002\u6771\u4EAC\u306B\u306A\u3089\u5C45\u3066\u3082\u304A\u304B\u3057\u304F\u306A\u3044\u3060\u3051\u3069\u306A\u30FC\u3002",
  "id" : 27637067242,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27646472907",
  "geo" : { },
  "id_str" : "27649565200",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u4ECA\u65E5\u3060\u306A\uFF57",
  "id" : 27649565200,
  "in_reply_to_status_id" : 27646472907,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27424721466",
  "text" : "\u30D3\u30EA\u30E4\u30FC\u30C9\u5DE6\u3067\u649E\u304F\u306E\u304C\u5B89\u5B9A\u3057\u3066\u304D\u305F\u3002",
  "id" : 27424721466,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27356871682",
  "text" : "\u30EA\u30F3\u30B7\u30E3\u30F3\u30C4\u30E2\u3001\u767C\u3001\u30C0\u30D6\u6771\u3001\u30C8\u30A4\u30C8\u30A4\u3001\u6DF7\u8001\u982D\u3001\u89AA\u306E\u500D\u6E80\u3002\u30EA\u30F3\u30B7\u30E3\u30F3\u00D7\u30DB\u30F3\u30ED\u30A6\u30C8\u30A6\u3068\u304B\u6B21\u306B\u548C\u4E86\u308B\u306E\u306F\u3044\u3064\u3060\u308D\u3046\uFF57\uFF57\u3000\u3000http:\/\/tenhou.net\/0\/?log=2010101501gm-0209-0000-f1547ac1&tw=1\u3000",
  "id" : 27356871682,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27204059524",
  "text" : "\u771F\u5B9F\u306F\u6B8B\u9177\u3060",
  "id" : 27204059524,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27215520720",
  "text" : "\u5317\u90E8\u30AD\u30E3\u30F3\u30D1\u30B9\u9060\u3059\u304Eorz",
  "id" : 27215520720,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27139204758",
  "text" : "\u30B5\u30FC\u30AF\u30EB\u3067\u30AA\u30AB\u30EB\u30C8\u30AD\u30E3\u30E9\u306B\u306A\u308A\u304B\u3051\u3066\u3044\u308B\u4EF6\u306B\u3064\u3044\u3066\u3002",
  "id" : 27139204758,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27139329336",
  "text" : "\u5076\u7136\u30D3\u30EA\u30E4\u30FC\u30C9\u3067\uFF19\u5165\u308C\u305F\u308A\u3001\u9EBB\u96C0\u3067\u56FD\u58EB\u7121\u53CC\u30C4\u30E2\u3063\u305F\u308A\u3001\u5F53\u305F\u308A\u724C\u5207\u308D\u3046\u3068\u3057\u3066\u5076\u7136\u624B\u304C\u6ED1\u3063\u3066\u5012\u308C\u305F\u304B\u3089\u5207\u308B\u306E\u3084\u3081\u305F\u308A\u3057\u305F\u3060\u3051\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 27139329336,
  "created_at" : "2010-10-12 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27001762779",
  "text" : "\u6C17\u3065\u3051\u3070\u6700\u65B0\u30C4\u30A4\u30FC\u30C8\u304C\uFF15\u65E5\u524D\u3058\u3083\u306A\u3044\u304B",
  "id" : 27001762779,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27027777470",
  "text" : "\u767E\u3001\u5343\u306E\u5FC5\u5B9A\u3082\u5076\u7136\u304C\u52DD\u308B\u3002\u305D\u3093\u306A\u30AA\u30AB\u30EB\u30C8\u2026\u3042\u308B\u3093\u3060\u306A\u3001\u3053\u308C\u304C\uFF57",
  "id" : 27027777470,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26508168517",
  "text" : "\u307E\u3076\u305F\u4EE5\u5916\u304C\u8EFD\u3044\u3002\u76F8\u5BFE\u7684\u306B\u307E\u3076\u305F\u304C\u91CD\u3044\u3002",
  "id" : 26508168517,
  "created_at" : "2010-10-06 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26473874354",
  "text" : "\u5148\u8F29\u5353\u3067\u9EBB\u96C0\u3002\u534A\u8358\u4E8C\u56DE\u3067\uFF0B\uFF14\uFF11\u3001\uFF0B\uFF11",
  "id" : 26473874354,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26474007568",
  "text" : "\u4E8C\u56DE\u76EE\u306E\u534A\u8358\u306E\u5357\u4E09\u3001\u5357\u56DB \u3055\u3057\u3066\u9AD8\u304F\u3082\u306A\u3044\u624B\u306E\u30A4\u30FC\u30B7\u30E3\u30F3\u30677700\u30012600\u306B\u632F\u308A\u8FBC\u3080\u3002\u96C6\u4E2D\u5207\u308C\u305F\u304B\u306Aorz",
  "id" : 26474007568,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26474057890",
  "text" : "\u632F\u308A\u8FBC\u3093\u3060\u306E\u305D\u308C\u3060\u3051\u3060\u3057\u3001\u4E00\u4F4D\u3001\u4E8C\u4F4D\u3060\u304B\u3089\u6E80\u8DB3\u3067\u3059\u304C\u2190",
  "id" : 26474057890,
  "created_at" : "2010-10-05 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26284062789",
  "text" : "\u96E8\u2026",
  "id" : 26284062789,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26064285862",
  "text" : "\u5B57\u4E00\u8272\u30AD\u30BF\u30FC\u3000\u56DB\u6697\u523B\u3082\u5C0F\u56DB\u559C\u3082\u8907\u5408\u3057\u305D\u3046\u306A\u624B\u3060\u3063\u305F\u3051\u3069\u6B32\u5F35\u308B\u52C7\u6C17\u306F\u3042\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u3002\nhttp:\/\/tenhou.net\/0\/?log=2010100118gm-0009-0000-73f7a7b0&tw=0",
  "id" : 26064285862,
  "created_at" : "2010-10-01 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26078383887",
  "text" : "@chisa10404 \u30D2\u30F3\u30C8\uFF1A\u93E1",
  "id" : 26078383887,
  "created_at" : "2010-10-01 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]