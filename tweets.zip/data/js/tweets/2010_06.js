Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17410248505",
  "text" : "\u30E9\u30C6\u30F3\u8A9E\u9593\u306B\u5408\u3046\u306E\u304B\uFF1F\u6628\u591C\u3082\u305D\u3046\u3060\u304C\u904A\u3073\u3059\u304E\u305Forz",
  "id" : 17410248505,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17411006787",
  "geo" : { },
  "id_str" : "17414791306",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6642\u9593\u3092\u64CD\u308B\u7A0B\u5EA6\u306E\u80FD\u529B\u306A\u3089\u904A\u3093\u3067\u3066\u3082\u304A\uFF4B\u3000\u3067\u3082\u771F\u76F8\u306F\u30FB\u30FB\u30FB\u304A\u5BDF\u3057\u304F\u3060\u3055\u3044",
  "id" : 17414791306,
  "in_reply_to_status_id" : 17411006787,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17420136549",
  "text" : "\u5E7E\u3064\u304B\u98DB\u3070\u3057\u305F\u304C\u306A\u3093\u3068\u304B\u7D42\u308F\u3063\u305F\u30FC\uFF01\u3082\u3046\u308F\u304B\u3093\u306A\u3044\u3068\u3053\u308D\u306F\u53CB\u9054\u306B\u4EFB\u305B\u3088\u3046\uFF57",
  "id" : 17420136549,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17450781098",
  "text" : "\u7720\u3044(\u79C1\u304C)\u3001\u9045\u3044(\u6559\u6388\u304C)\u3001\u5C11\u306A\u3044(\u4EBA\u304C)",
  "id" : 17450781098,
  "created_at" : "2010-06-30 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17349615185",
  "text" : "\u5148\u8F29\u5B85\u30673\u4EBA\u9EBB\u96C0\u3084\u308A\u3064\u3064\u30EF\u30FC\u30EB\u30C9\u30AB\u30C3\u30D7\u89B3\u6226\u3057\u3066\u5E30\u5B85\u306A\u3046\u3002",
  "id" : 17349615185,
  "created_at" : "2010-06-29 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17223577438",
  "text" : "\u8AB0\u304B\u30BF\u30F3\u30B9\u3068\u304B\u306B\u5165\u308C\u3068\u304F\u6E7F\u6C17\u53D6\u308A\u3092\u3001\u8FD1\u757F\u4E00\u4F53\u306B\u5927\u91CF\u306B\u6492\u3044\u3066\u304F\u308C\u308B\u3068\u3046\u308C\u3057\u3044\u306A",
  "id" : 17223577438,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17223668368",
  "text" : "\u3042\u30FC\u3001\u3007\u4E00\u5E2F\u3001\u00D7\u4E00\u4F53\u3001\u8AA4\u5909\u63DB\u2026",
  "id" : 17223668368,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17235553366",
  "geo" : { },
  "id_str" : "17235826098",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6BCD\u89AA\u306E\u6307\u306B\u5999\u306A\u8594\u8587\u306E\u6307\u8F2A\u304C\u306A\u3044\u304B\u78BA\u304B\u3081\u3068\u3051\uFF57\uFF57",
  "id" : 17235826098,
  "in_reply_to_status_id" : 17235553366,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17236859977",
  "geo" : { },
  "id_str" : "17242537941",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u77E5\u3063\u3066\u308B\u304C\u3001\u3082\u3057\u304B\u3057\u3066\u52D5\u304D\u51FA\u3057\u305F\uFF1F\uFF57",
  "id" : 17242537941,
  "in_reply_to_status_id" : 17236859977,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17244461287",
  "geo" : { },
  "id_str" : "17247357345",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3053\u3053\u3067\u5F15\u304F\u304B\uFF57\u307E\u3041\u3044\u3044\u3084\u3001\u30CD\u30BF\u632F\u3063\u305F\u306E\u4FFA\u3060\u3057\uFF57\uFF57",
  "id" : 17247357345,
  "in_reply_to_status_id" : 17244461287,
  "created_at" : "2010-06-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17150956223",
  "text" : "\u3042\u3001\u30CF\u30AC\u30EC\u30F3\u898B\u3089\u308C\u306A\u3044orz",
  "id" : 17150956223,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17160571609",
  "geo" : { },
  "id_str" : "17161009919",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3084\u3063\u3066\u307F\u305F\u3089\u4FDD\u5742\u306E\u4E2D\u306E\u4EBA\u304C\u51FA\u3066\u304D\u3066\u3061\u3087\u3063\u3068\u8907\u96D1\u306A\u6C17\u6301\u3061\u306B\u306A\u308A\u307E\u3057\u305F\uFF57\uFF57",
  "id" : 17161009919,
  "in_reply_to_status_id" : 17160571609,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17163254670",
  "text" : "\u304A\u5915\u98EF\u98DF\u3079\u308B\u30BF\u30A4\u30DF\u30F3\u30B0\u3092\u5931\u3063\u305F\u306A\u3041",
  "id" : 17163254670,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17164143102",
  "text" : "\u3053\u306E\u6E7F\u5EA6\u306F\u7570\u5E38\u3060\u3002\u8EFD\u3044\u30DF\u30B9\u3068\u30B5\u30A6\u30CA\u7A0B\u5EA6\u306E\u30D2\u30E5\u30FC\u30DF\u30C7\u30A3\u30C6\u30A3",
  "id" : 17164143102,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17164174597",
  "text" : "@chisa10404 \u6687\u3060\u304B\u3089\u805E\u304F\u304B\u3082\u30FC\u3068\u601D\u3063\u305F\u3051\u3069\u3069\u3046\u3084\u3063\u3066\uFF1F",
  "id" : 17164174597,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17165076380",
  "text" : "@chisa10404 \u3067\u3059\u3088\u306D\u30FC\uFF3E\uFF3E\uFF1B\u30CD\u30C3\u30C8\u3067\u8074\u3051\u308B\u304B\u3068\u601D\u3063\u3066\u4E00\u5FDC\u805E\u3044\u3066\u307F\u305F\u3093\u3060\u3051\u3069\uFF57",
  "id" : 17165076380,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "17081022957",
  "geo" : { },
  "id_str" : "17081328805",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u8FB2\u5DE5\u5927\u306E\u5148\u8F29\u304C\u559C\u3073\u305D\u3046\u3067\u3059\u306D\uFF57",
  "id" : 17081328805,
  "in_reply_to_status_id" : 17081022957,
  "created_at" : "2010-06-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17124337783",
  "text" : "\u4FEE\u5B66\u65C5\u884C\u751F\u591A\u3059\u304E\uFF57\uFF57",
  "id" : 17124337783,
  "created_at" : "2010-06-26 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17001715763",
  "text" : "\u81EA\u8EE2\u8ECA\u30D1\u30F3\u30AF\u3059\u308B\u3057\u3001\u591C\u306B\u306A\u3089\u3093\u3068\u632F\u3089\u3093\u3063\u3066\u8A00\u3063\u3066\u305F\u96E8\u964D\u308B\u3057\u3001\u4ECA\u65E5\u306F\u5384\u65E5\u3060\u308F\u3002\u3002",
  "id" : 17001715763,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16918658901",
  "text" : "\u30D5\u30EC\u30F3\u30C1\u30C8\u30FC\u30B9\u30C8\u98DF\u3079\u305F\u3057(\uFF1F)\u30D5\u30E9\u30F3\u30B9\u8A9E\u9811\u5F35\u308B\u304B\u3041\u2026",
  "id" : 16918658901,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16821938155",
  "text" : "\uFF12\u9650\u3092\u5BDD\u5012\u3057\u305F\u79C1\u306B\u6B7B\u89D2\u306F\u306A\u3044\u30C3\uFF01\u660E\u65E5\u306E\u4E88\u7FD2\u3092\u3059\u308B\u305F\u3081\u306E\u5E03\u77F3\u3060\u3063\u305F\u306E\u3055\u3002",
  "id" : 16821938155,
  "created_at" : "2010-06-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16821980185",
  "text" : "\u3042\u3001\u6388\u696D\u51FA\u3066\u5BDD\u5012\u3057\u305F\u306E\u306D\u3002\u30B5\u30DC\u3063\u305F\u308F\u3051\u3058\u3083\u306A\u3044\u3088\uFF57",
  "id" : 16821980185,
  "created_at" : "2010-06-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16880069405",
  "text" : "\u4E45\u3005\u306B\u5FEB\u6674\uFF01\u3067\u3082\u4F53\u80B2orz",
  "id" : 16880069405,
  "created_at" : "2010-06-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16887036052",
  "text" : "\u3060\u304B\u30898:45\u304B\u3089\u3060\u3063\u3066\u3002\u6559\u6388\u9045\u3044\u3057\u3002\u3002\u3002\u65E9\u8D77\u304D\u3057\u3066\u3093\u306E\u306B",
  "id" : 16887036052,
  "created_at" : "2010-06-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16746763348",
  "text" : "\u6559\u6388\u304C\u6765\u306A\u3044\u2026\u4F11\u8B1B\u60C5\u5831\u3082\u306A\u3057\u3002\u5FAE\u5999\u2026\u4F11\u8B1B\u306A\u3089\u4F11\u8B1B\u3067\u3044\u3044\u3051\u3069\u3001\u3084\u308B\u306A\u3089\u3084\u3063\u3066\u307B\u3057\u3044\u306A\u3002",
  "id" : 16746763348,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16744826955",
  "text" : "\u3042\u3064\u3044\u30FC\u3001\u3068\u3044\u3046\u3088\u308A\u84B8\u3057\u3066\u304D\u3082\u3061\u308F\u308B\u3044\u3002",
  "id" : 16744826955,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16665226517",
  "text" : "\u539A\u3044\u96F2\u2026\u3092\u901A\u308A\u8D8A\u3057\u3066\u56DE\u308A\u306E\u5C71\u306B\u9744(\u3082\u3084)\u304C\u304B\u304B\u3063\u3066\u308B\u3002\u96E8\u964D\u3089\u306A\u3044\u3068\u3044\u3044\u306A\u3041\u3002",
  "id" : 16665226517,
  "created_at" : "2010-06-21 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16620698221",
  "text" : "\u307E\u3060\u65E5\u66DC\u65E5\u3001\u307E\u3060\u65E5\u66DC\u65E5\u306A\u3093\u3060\u3002",
  "id" : 16620698221,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16623706945",
  "text" : "\u3042\u3041\u6708\u66DC\u65E5\u3001\u3082\u3046\u6708\u66DC\u65E5\u304B\u3041orz",
  "id" : 16623706945,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16542101789",
  "text" : "\u3042\u30FC\u3001\u820C\u706B\u50B7\u3057\u305F\u3002\u3067\u3082\u304A\u7CA5\u306F\u7C73\u304B\u3089\u4F5C\u3063\u305F\u307B\u3046\u304C\u304A\u3044\u3057\u304B\u3063\u305F\u3002",
  "id" : 16542101789,
  "created_at" : "2010-06-19 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16449976915",
  "text" : "\u30AB\u30EC\u30FC\u306E\u5996\u7CBE\uFF57\uFF57\uFF57",
  "id" : 16449976915,
  "created_at" : "2010-06-18 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16456694813",
  "text" : "\u5F85\u3061\u5408\u308F\u305B\u5834\u6240\u306B\uFF12\uFF15\u5206\u3082\u65E9\u304F\u3064\u3044\u3066\u3057\u307E\u3063\u305F\u2026",
  "id" : 16456694813,
  "created_at" : "2010-06-18 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16471821979",
  "text" : "\u30D0\u30F3\u30D0\u30F3\u30B8\u30FC\u3063\u3066\u5909\u63DB\u3067\u304D\u306A\u3044\u306E\u306D",
  "id" : 16471821979,
  "created_at" : "2010-06-18 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16348544787",
  "text" : "\u6975\u9650\u306E\u30C6\u30B9\u30C8\u304C\u30ED\u30D4\u30BF\u30EB\u7121\u53CC\u3060\u3063\u305F\u4EF6\u306B\u3064\u3044\u3066\uFF57\uFF57\uFF57\uFF57",
  "id" : 16348544787,
  "created_at" : "2010-06-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ak!",
      "screen_name" : "akiiicha",
      "indices" : [ 0, 9 ],
      "id_str" : "292884616",
      "id" : 292884616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16359166979",
  "text" : "@akiiicha \u6838\u878D\u5408\u7814\u7A76\u306E\u8CBB\u7528\u524A\u6E1B\u306F\u7121\u3044\u306A \u6587\u7CFB\u306E\u4EBA\u9593\u306E\u79D1\u5B66\u7684\u8A8D\u8B58\u304C\u5927\u4E8B\u3060\u3068\u601D\u3046\u3002",
  "id" : 16359166979,
  "created_at" : "2010-06-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16285606769",
  "text" : "\u6388\u696D\u3092\u30B5\u30DC\u3063\u3066\u660E\u65E5\u306E\u6388\u696D\u306E\u4E88\u7FD2\u3092\u3059\u308B\u306F\u4E0D\u771F\u9762\u76EE\u306A\u308A\u3084",
  "id" : 16285606769,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16298389980",
  "text" : "\u3053\u306E\u6691\u3044\u306E\u306B\u934B\u304B\u3089\u9D8F\u96D1\u708A\u3092\u98DF\u3079\u305F\u3002\u8471\u3068\u3055\u3055\u307F\u3060\u3051\u3067\u5B89\u4E0A\u304C\u308A\u3002\u304A\u3044\u3057\u304B\u3063\u305F\u3002",
  "id" : 16298389980,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16312334914",
  "text" : "\u306A\u3093\u3068\u304B\u4ECA\u65E5\u4E2D\u306B\u30D5\u30E9\u30F3\u30B9\u8A9E\u7D42\u308F\u3063\u305F\u30FC\u3002\uFF08\u307B\u3093\u3068\u306F\u7D42\u308F\u3063\u3066\u306A\u3044\u3051\u3069\u660E\u65E5\u4F11\u8B1B\u306A\u6388\u696D\u4E2D\u306B\u3084\u308C\u308B\uFF09",
  "id" : 16312334914,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16305964793",
  "geo" : { },
  "id_str" : "16312473255",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u308C\u306F\u9177\u3044\u306A\uFF57\u9664\u6E7F\u6A5F\u304B\u3051\u306A\u304C\u3089\u52A0\u6E7F\u5668\u304B\u3051\u308B\u30A4\u30E1\u30FC\u30B8\uFF57S\u30E9\u30F3\u30AF\u7D1A\u306E\u77DB\u76FE\u3060\u3088\u306A\u3002\u3000\u3042\u3068\u3053\u308C\u8DB3\u8DE1\u3064\u304B\u306A\u304F\u3066\u3044\u3044\u3088\u306D\uFF57",
  "id" : 16312473255,
  "in_reply_to_status_id" : 16305964793,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.softbankmobile.co.jp\/ja\/index.htmlhttp:\/\/www.softbankmobile.co.jp\/ja\/index.html\" rel=\"nofollow\"\u003Emobile widgets for SOFTBANK\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16197908272",
  "text" : "\u5FAE\u65B9\u306F\u3055\u3059\u304C\u306B\u307E\u3060\u89E3\u3051\u305D\u3046\u306B\u3042\u308A\u307E\u305B\u3093\u3002\u7121\u8336\u632F\u308A\u3067\u3057\u305F\u3002",
  "id" : 16197908272,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16218935361",
  "text" : "\u3055\u3066\u3001\u82F1\u4ECF\u7F85\u8A9E\u3092\u7247\u4ED8\u3051\u306A\u304F\u3066\u306F\u3002\u305F\u3060\u3067\u3055\u3048Humid\u306A\u3067\u6182\u9B31\u306A\u306E\u306B\u306A\u3002",
  "id" : 16218935361,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16215118252",
  "geo" : { },
  "id_str" : "16219127665",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5931\u671B\u304C\u865A\u6570\u306A\u3089\u2026\uFF01",
  "id" : 16219127665,
  "in_reply_to_status_id" : 16215118252,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16224390929",
  "text" : "\u82F1\u8A9E\u306F\u3084\u3063\u3064\u3051\u305F\u3002\u3055\u3066\u30E9\u30C6\u30A3\u30FC\u30CA\u3060\u2026\u3002",
  "id" : 16224390929,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16226657844",
  "text" : "\u30EA\u30C4\u30A4\u30FC\u30C8\u3068\u8FD4\u4FE1\u3063\u3066\u3069\u3046\u9055\u3046\u306E\u3055\u30FC",
  "id" : 16226657844,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16226761239",
  "geo" : { },
  "id_str" : "16231000183",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5927\u4E08\u592B\u304B\u30FC\u3002\u3042\u308C\u3060\u3063\u305F\u3089\u9069\u5F53\u306B\u9023\u7D61\u3057\u3066\u304F\u308C\u30FC\u3002",
  "id" : 16231000183,
  "in_reply_to_status_id" : 16226761239,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16231054240",
  "text" : "\u30E9\u30C6\u30F3\u8A9E\uFF11\uFF13\uFF0F\uFF13\uFF10\u3067\u632B\u6298\u3002\u4ECA\u65E5\u306E\u653E\u8AB2\u5F8C\u304C\u3093\u3070\u308B\u3053\u3068\u306B\u3059\u308B\u3002\u304A\u3084\u3059\u307F\u30FC",
  "id" : 16231054240,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16153812314",
  "text" : "\u3064\u307E\u308A\u30FB\u30FB\u30FB\u30C4\u30A4\u30C3\u30BF\u30FC\u3068\u306F\u30C1\u30E9\u30B7\u306E\u88CF\u3060\u3002\u8868\u3092\u898B\u308C\u3070\u4F01\u696D\u60C5\u5831\u3001\u88CF\u306B\u66F8\u3051\u3070\u81EA\u5DF1\u6E80\u8DB3\u3002",
  "id" : 16153812314,
  "created_at" : "2010-06-14 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "16153811631",
  "geo" : { },
  "id_str" : "16153997858",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4EAC\u5927\u306A\u3081\u3093\u306A\uFF57",
  "id" : 16153997858,
  "in_reply_to_status_id" : 16153811631,
  "created_at" : "2010-06-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.softbankmobile.co.jp\/ja\/index.htmlhttp:\/\/www.softbankmobile.co.jp\/ja\/index.html\" rel=\"nofollow\"\u003Emobile widgets for SOFTBANK\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16158711584",
  "text" : "\u8272\u3005\u6642\u9593\u306A\u3044\u306A\u3002\u5BDD\u307E\u3059\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 16158711584,
  "created_at" : "2010-06-14 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]