Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241550451483492352",
  "text" : "\u4EBA\u9593\u306E\u51FA\u4F1A\u3044\u306F\u308F\u304B\u3089\u306A\u3044\u3082\u306E\u3060\u306A\u30FC",
  "id" : 241550451483492352,
  "created_at" : "2012-08-31 14:58:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241550366875987968",
  "text" : "\u3072\u3089\u3044\u305A\u307F\u3055\u3093\u7D50\u69CB\u8DA3\u5473\u88AB\u3063\u3066\u308B\u3057\u5171\u611F\u3059\u308B\u30DD\u30A4\u30F3\u30C8\u591A\u3044\u3057\u4E0D\u601D\u8B70",
  "id" : 241550366875987968,
  "created_at" : "2012-08-31 14:57:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241550015934394370",
  "geo" : { },
  "id_str" : "241550137149771776",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u3053\u3061\u3089\u3053\u305D\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u30EA\u30D7\u30E9\u30A4\u3067\u3054\u3081\u3093\u306A\u3055\u3044\u3067\u3057\u305F",
  "id" : 241550137149771776,
  "in_reply_to_status_id" : 241550015934394370,
  "created_at" : "2012-08-31 14:56:55 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 12, 15 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241549736505638912",
  "geo" : { },
  "id_str" : "241549865237237760",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math #\u306F\u3044",
  "id" : 241549865237237760,
  "in_reply_to_status_id" : 241549736505638912,
  "created_at" : "2012-08-31 14:55:50 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241549758286684163",
  "text" : "\u8AB2\u91D1\u3057\u3066\u306A\u3044\u3051\u3069\u30C8\u30ED\u30D5\u30A3\u30FC\u3042\u3052\u305F\u3044\u30EC\u30D9\u30EB\u306B\u5171\u611F\u3057\u3066\u308B",
  "id" : 241549758286684163,
  "created_at" : "2012-08-31 14:55:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241549452601589761",
  "geo" : { },
  "id_str" : "241549627126607874",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u79C1\u306E\u8A71\u3057\u3066\u307E\u3059\uFF1F",
  "id" : 241549627126607874,
  "in_reply_to_status_id" : 241549452601589761,
  "created_at" : "2012-08-31 14:54:53 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241549269805449218",
  "text" : "\u65E5\u4ED8\u306E\u5883\u754C\u306B\u53B3\u3057\u3044",
  "id" : 241549269805449218,
  "created_at" : "2012-08-31 14:53:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241549109260079105",
  "text" : "\u4E00\u65E5\u306E\u8A31\u5BB9\u91CF\u3069\u306E\u4F4D\u304B\u77E5\u3089\u3093\u3057\u3001\u5225\u306B\u53B3\u5BC6\u306B\u3084\u308B\u3064\u3082\u308A\u306F\u306A\u3044\u304C\u3001\u65E5\u4ED8\u5909\u308F\u3063\u305F\u3089\u30EA\u30BB\u30C3\u30C8\u3055\u308C\u308B\u306E\u306F\u5F53\u305F\u308A\u524D\u3060\u3088\u306D",
  "id" : 241549109260079105,
  "created_at" : "2012-08-31 14:52:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241548956964884481",
  "text" : "\u65E5\u4ED8\u5909\u308F\u3063\u305F\u3089\u30B3\u30FC\u30D2\u30FC\u2026",
  "id" : 241548956964884481,
  "created_at" : "2012-08-31 14:52:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241548621831626753",
  "text" : "\u65E5\u4ED8\u5909\u308F\u3063\u305F\u3089\u5E7E \u4F55(\u3061\u3087\u3063\u3068\u653E\u7F6E\u6C17\u5473)",
  "id" : 241548621831626753,
  "created_at" : "2012-08-31 14:50:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241548469846806529",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u306F\u304B\u3069\u3063\u305F\u65B9\u3067\u3042\u308B",
  "id" : 241548469846806529,
  "created_at" : "2012-08-31 14:50:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241548431842242561",
  "text" : "16\u6642\u304A\u304D\u3067\u30DA\u30FC\u30B8\u306B\u3057\u306610p\u304C\u9650\u754C\u304B",
  "id" : 241548431842242561,
  "created_at" : "2012-08-31 14:50:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241547623230758912",
  "text" : "\u30B8\u30E7 \u30EB\u30C0\u30F3\u3081\u2026",
  "id" : 241547623230758912,
  "created_at" : "2012-08-31 14:46:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 12, 15 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241547308922175488",
  "geo" : { },
  "id_str" : "241547496399183872",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi #\u306F\u3044",
  "id" : 241547496399183872,
  "in_reply_to_status_id" : 241547308922175488,
  "created_at" : "2012-08-31 14:46:25 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241542160342724609",
  "geo" : { },
  "id_str" : "241547467328479234",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u305D\u308C\u306A\u3002\u3069\u3053\u306B\u3067\u3082\u3042\u308B\u3002",
  "id" : 241547467328479234,
  "in_reply_to_status_id" : 241542160342724609,
  "created_at" : "2012-08-31 14:46:18 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241541406588538880",
  "geo" : { },
  "id_str" : "241541724483239937",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u5927\u559C\u5229\u3058\u3083\u306A\u3044\u3068\u3067\u3082\uFF1F",
  "id" : 241541724483239937,
  "in_reply_to_status_id" : 241541406588538880,
  "created_at" : "2012-08-31 14:23:29 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241538136809820160",
  "geo" : { },
  "id_str" : "241540803674116096",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u5317\u6D77\u9053\u306B\u884C\u304F\u4E88\u5B9A\u304C\u3042\u308B\u304B\u3089\u5727\u5012\u7684\u306B\u3044\u3089\u306A\u3044\u308F(\u3057\u308D\u3081",
  "id" : 241540803674116096,
  "in_reply_to_status_id" : 241538136809820160,
  "created_at" : "2012-08-31 14:19:49 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241536459545391106",
  "geo" : { },
  "id_str" : "241536619830706176",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u4EAC\u90FD\u306B\u3055\u3048\u3044\u306A\u3044\u53EF\u80FD\u6027\u3060\u3063\u3066\u3042\u308B",
  "id" : 241536619830706176,
  "in_reply_to_status_id" : 241536459545391106,
  "created_at" : "2012-08-31 14:03:12 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241535613134831617",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u6765\u308B\u306A\u3089\u65E9\u3081\u306B\u9023\u7D61\u3057\u305F\u307E\u3048\u3088\u30FC",
  "id" : 241535613134831617,
  "created_at" : "2012-08-31 13:59:12 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241503900056829953",
  "text" : "\u5931\u793C\u3055\u305B\u3066\u3044\u305F\u3060\u304D\u307E\u3059",
  "id" : 241503900056829953,
  "created_at" : "2012-08-31 11:53:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241503805697564672",
  "text" : "TV\u72EC\u7279\u306E\u3042\u306E\u5ACC\u306A\u611F\u3058\u304C\u3072\u3057\u3072\u3057\u3068",
  "id" : 241503805697564672,
  "created_at" : "2012-08-31 11:52:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241503710201643010",
  "text" : "\u9AD8\u6821\u751F\u30AF\u30A4\u30BA\u306ETL\u306F\u3044\u308D\u3044\u308D\u306A\u610F\u5473\u3067\u5207\u306A\u3044\u304B\u3089\u52C9\u5F37\u306B\u623B\u308D\u3046",
  "id" : 241503710201643010,
  "created_at" : "2012-08-31 11:52:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241502539684651009",
  "geo" : { },
  "id_str" : "241502980099158016",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u305D\u3046\u3044\u3046\u610F\u5473\u3067\u306F\u9AD8\u6821\u751F\u30AF\u30A4\u30BA\u3067\u6BCD\u6821\u304C\u4E91\u3005\u3063\u3066\u76DB\u308A\u4E0A\u304C\u308C\u308B\u306E\u306F\u3061\u3087\u3063\u3068\u7FA8\u307E\u3057\u304B\u3063\u305F\u308A\u3082\u3057\u307E\u3059\u3002\u5B8C\u5168\u306B\u868A\u5E33\u306E\u5916\u306A\u306E\u3067\u3002",
  "id" : 241502980099158016,
  "in_reply_to_status_id" : 241502539684651009,
  "created_at" : "2012-08-31 11:49:32 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241502409384398848",
  "text" : "\u307E\u3041\u500B\u4EBA\u7684\u306B\u304A\u4E16\u8A71\u306B\u306A\u3063\u305F\u5148\u751F\u306F\u3044\u308B\u3051\u308C\u3069",
  "id" : 241502409384398848,
  "created_at" : "2012-08-31 11:47:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241502279042220032",
  "text" : "\u6BCD\u6821\u306E\u3053\u3068\u306F\u5ACC\u3044\u3058\u3083\u306A\u304B\u3063\u305F\u3057\u697D\u304B\u3063\u305F\u3051\u308C\u3069\u3001\u5B66\u529B\u7684\u306A\u610F\u5473\u3067\u306F\u5168\u304F\u611F\u8B1D\u3057\u3066\u3044\u306A\u3044",
  "id" : 241502279042220032,
  "created_at" : "2012-08-31 11:46:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241501004141563904",
  "text" : "\u4E2D\u9014\u534A\u7AEF\u306B\u3055\u3048\u982D\u826F\u304F\u306A\u3044\u304B\u3089\u30B3\u30F3\u30D7\u30EC\u30C3\u30AF\u30B9\u3092\u62B1\u304F\u8CC7\u683C\u3055\u3048\u306A\u3044\u304B\u3089\u697D\u3063\u3061\u3083\u697D",
  "id" : 241501004141563904,
  "created_at" : "2012-08-31 11:41:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241500631846760448",
  "text" : "\u9AD8\u6821\u751F\u306E\u30AF\u30A4\u30BA\u306F\u3069\u3046\u305C\u6BCD\u6821\u3067\u306A\u3044\u304B\u3089\u307F\u306A\u3044\u3057\u3001\u6BCD\u6821\u3067\u305F\u3068\u3057\u305F\u3089\u6065\u305A\u304B\u3057\u3044\u304B\u3089\u898B\u306A\u3044",
  "id" : 241500631846760448,
  "created_at" : "2012-08-31 11:40:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "menjolno",
      "indices" : [ 7, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241498134973382656",
  "text" : "\u30E1\u30F3\u30B8\u30E7\u30EB\u30CE #menjolno",
  "id" : 241498134973382656,
  "created_at" : "2012-08-31 11:30:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "menjolno",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241496998786760704",
  "text" : "\u5F85\u6A5F #menjolno",
  "id" : 241496998786760704,
  "created_at" : "2012-08-31 11:25:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241481852756582400",
  "text" : "\u305D\u308C\u4EE5\u4E0A\u3044\u3051\u306A\u3044",
  "id" : 241481852756582400,
  "created_at" : "2012-08-31 10:25:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 3, 12 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241481774738313216",
  "text" : "RT @hanaoka_: \u9AD8\u6821\u751F\u30AF\u30A4\u30BA\u3092\u898B\u308B\u6642\u306F\u306D\u3001\u8AB0\u306B\u3082\u90AA\u9B54\u3055\u308C\u305A\u81EA\u7531\u3067\u3001\u306A\u3093\u3068\u3044\u3046\u304B\u6551\u308F\u308C\u3066\u306A\u304D\u3083\u3042\u30C0\u30E1\u306A\u3093\u3060\u3001\u72EC\u308A\u9759\u304B\u3067\u8C4A\u304B\u3067\u2026\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.youtube.com\/watch?v=_8oxXbWE8AI\" rel=\"nofollow\"\u003E\u30B7\u30CA\u30D7\u30B9\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241481732568793088",
    "text" : "\u9AD8\u6821\u751F\u30AF\u30A4\u30BA\u3092\u898B\u308B\u6642\u306F\u306D\u3001\u8AB0\u306B\u3082\u90AA\u9B54\u3055\u308C\u305A\u81EA\u7531\u3067\u3001\u306A\u3093\u3068\u3044\u3046\u304B\u6551\u308F\u308C\u3066\u306A\u304D\u3083\u3042\u30C0\u30E1\u306A\u3093\u3060\u3001\u72EC\u308A\u9759\u304B\u3067\u8C4A\u304B\u3067\u2026\u2026",
    "id" : 241481732568793088,
    "created_at" : "2012-08-31 10:25:06 +0000",
    "user" : {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "protected" : false,
      "id_str" : "126927392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540399732707688448\/Iqz4rTVp_normal.jpeg",
      "id" : 126927392,
      "verified" : false
    }
  },
  "id" : 241481774738313216,
  "created_at" : "2012-08-31 10:25:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241480287643631618",
  "geo" : { },
  "id_str" : "241480600387739648",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u3042\u3089\u3042\u3089\u3001\u30A2\u30A4\u30B9\u307E\u3093\u3058\u3085\u3046\u3068\u304B\u3082\u30AA\u30B9\u30B9\u30E1\u3067\u3059(\u5C0F\u8C46\u597D\u304D)",
  "id" : 241480600387739648,
  "in_reply_to_status_id" : 241480287643631618,
  "created_at" : "2012-08-31 10:20:36 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241480206106374145",
  "text" : "20:30\u304B\u3089\u30E1\u30F3\u30B8\u30E7\u30EB\u30CE\u304B\u30FC\u3001\u53C2\u52A0\u3057\u3066\u307F\u3088\u3046\u304B\u306A",
  "id" : 241480206106374145,
  "created_at" : "2012-08-31 10:19:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5357\u689D\u611B\u4E43",
      "screen_name" : "nanjolno",
      "indices" : [ 3, 12 ],
      "id_str" : "119635653",
      "id" : 119635653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "menjolno",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241480082298920960",
  "text" : "RT @nanjolno: \u3088\u30FC\u30FC\u3057\uFF01\u4ECA\u65E5\u306F\u30BD\u30ED\u30C7\u30D3\u30E5\u30FC\u544A\u77E5\u3092\u8A18\u5FF5\u3057\u3066\u3001\u9EBA\u30B8\u30E7\u30EB\u30CE\u3084\u308B\u305E\u3049\uFF01\uFF01\u306A\u3093\u3068\u30B8\u30A7\u30CD\u30AA\u30F3\u306E\u30B9\u30BF\u30C3\u30D5\u3055\u3093\u8003\u6848\uFF01\uFF01(\u7B11)\u6642\u9593\u306F20:30\u304B\u3089\uFF01\uFF01\u79C1\u306F\u30AB\u30C3\u30D7\u9EBA\u3092\u3059\u3059\u308B\u3088\uFF01(\u7B11) #menjolno",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "menjolno",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241479701388996608",
    "text" : "\u3088\u30FC\u30FC\u3057\uFF01\u4ECA\u65E5\u306F\u30BD\u30ED\u30C7\u30D3\u30E5\u30FC\u544A\u77E5\u3092\u8A18\u5FF5\u3057\u3066\u3001\u9EBA\u30B8\u30E7\u30EB\u30CE\u3084\u308B\u305E\u3049\uFF01\uFF01\u306A\u3093\u3068\u30B8\u30A7\u30CD\u30AA\u30F3\u306E\u30B9\u30BF\u30C3\u30D5\u3055\u3093\u8003\u6848\uFF01\uFF01(\u7B11)\u6642\u9593\u306F20:30\u304B\u3089\uFF01\uFF01\u79C1\u306F\u30AB\u30C3\u30D7\u9EBA\u3092\u3059\u3059\u308B\u3088\uFF01(\u7B11) #menjolno",
    "id" : 241479701388996608,
    "created_at" : "2012-08-31 10:17:01 +0000",
    "user" : {
      "name" : "\u5357\u689D\u611B\u4E43",
      "screen_name" : "nanjolno",
      "protected" : false,
      "id_str" : "119635653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590128712906977281\/lWxpoTSQ_normal.jpg",
      "id" : 119635653,
      "verified" : true
    }
  },
  "id" : 241480082298920960,
  "created_at" : "2012-08-31 10:18:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241479344264970240",
  "text" : "\u56DE\u6587\u3063\u3058\u3083\u306A\u301C\u3044",
  "id" : 241479344264970240,
  "created_at" : "2012-08-31 10:15:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241478529596919810",
  "text" : "\u61D0\u304B\u3057\u3055\u306B\u9707\u3048\u308B",
  "id" : 241478529596919810,
  "created_at" : "2012-08-31 10:12:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241478501063065601",
  "text" : "#nowplaying \uFF26\uFF4C\uFF4F\uFF4F\uFF44\uFF53\u3000\uFF4F\uFF46\u3000\uFF54\uFF45\uFF41\uFF52\uFF53\uFF08\u30B7\u30F3\u30B0\u30EB\u30FB\u30F4\u30A1\u30FC\u30B8\u30E7\u30F3\uFF0F\u30DC\u30FC\u30CA\u30B9\u30FB\u30C8\u30E9\u30C3\u30AF\uFF09 - L'Arc\uFF5Een\uFF5ECiel",
  "id" : 241478501063065601,
  "created_at" : "2012-08-31 10:12:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241477966788435968",
  "geo" : { },
  "id_str" : "241478192148393985",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u3042\u305A\u304D\u3070\u30FC",
  "id" : 241478192148393985,
  "in_reply_to_status_id" : 241477966788435968,
  "created_at" : "2012-08-31 10:11:02 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241477939965870080",
  "text" : "\u91D1\u66DC\u3063\u3066\u9589\u307E\u308B\u306E\u306F\u3084\u3044\u3093\u3060\u3063\u3051\uFF1F",
  "id" : 241477939965870080,
  "created_at" : "2012-08-31 10:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241477616757006336",
  "text" : "\u30DE\u30B8\u3067\u5FB9\u591C\u8996\u91CE\u3060\u306A\u3053\u308C\u3002\u65E5\u4ED8\u5909\u308F\u308B\u304F\u3089\u3044\u306B\u81EA\u7FD2\u5BA4\u884C\u304F\u304B\uFF1F",
  "id" : 241477616757006336,
  "created_at" : "2012-08-31 10:08:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241477393448054785",
  "text" : "\u591A\u5206250ml\u304F\u3089\u3044\u306E\u30B3\u30FC\u30D2\u30FC3\u676F\u3081\u306A\u3093\u3060\u304C\u3053\u308C\u591A\u5206\u304B\u306A\u308A\u4F53\u306B\u60AA\u3044",
  "id" : 241477393448054785,
  "created_at" : "2012-08-31 10:07:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241472360551682048",
  "geo" : { },
  "id_str" : "241476764633792512",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u52C9\u5F37\u3067\u3061\u3087\u3063\u3068\u8A70\u307E\u3063\u305F\u306E\u3067\u3059\u304C\u5727\u5012\u7684\u7406\u89E3\u306B\u81F3\u308A\u307E\u3057\u305F",
  "id" : 241476764633792512,
  "in_reply_to_status_id" : 241472360551682048,
  "created_at" : "2012-08-31 10:05:21 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241472472271187969",
  "text" : "\u3042\u3063\u3001\u5727\u5012\u7684\u7406\u89E3",
  "id" : 241472472271187969,
  "created_at" : "2012-08-31 09:48:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241470894436937728",
  "text" : "\u306A\u305C\u30FC\u30FC",
  "id" : 241470894436937728,
  "created_at" : "2012-08-31 09:42:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241455506911272961",
  "text" : "@YSEM21 \u3084\u308A\u307E\u305B\u3093\u306D\u3002\u5B8C\u5168\u306B\u611F\u899A\u3067\u3059\u3002",
  "id" : 241455506911272961,
  "created_at" : "2012-08-31 08:40:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241449212343095297",
  "text" : "\u305F\u3060\u8D77\u304D\u308B\u306E\u304C\u9045\u304F\u3066\u81EA\u5DF1\u5ACC\u60AA\u3063\u3066\u3060\u3051\u3067\u3001\u30E1\u30F3\u30D8\u30E9\u3067\u306F\u3042\u308A\u307E\u305B\u3093",
  "id" : 241449212343095297,
  "created_at" : "2012-08-31 08:15:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3044\u3044\u3048",
      "indices" : [ 11, 15 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241448942674534400",
  "geo" : { },
  "id_str" : "241449104104902656",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 #\u3044\u3044\u3048",
  "id" : 241449104104902656,
  "in_reply_to_status_id" : 241448942674534400,
  "created_at" : "2012-08-31 08:15:26 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241448856682901504",
  "text" : "\u7269\u7406\u306E\u7D20\u990A\u304C\u306A\u3044\u306E\u304C\u3070\u308C\u3070\u308C\u3067\u3042\u308B",
  "id" : 241448856682901504,
  "created_at" : "2012-08-31 08:14:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241448789678903297",
  "text" : "\u6C37\u306E\u5165\u3063\u305F\u30B0\u30E9\u30B9\u306B\u3001\u71B1\u3044\u30B3\u30FC\u30D2\u30FC\u3068\u51B7\u305F\u3044\u725B\u4E73\u3092\u5225\u3005\u306B\u6CE8\u3050\u306E\u3068\u3001\u5148\u306B\u306C\u308B\u3044\u30AB\u30D5\u30A7\u30AA\u30EC\u3092\u4F5C\u3063\u3066\u304B\u3089\u6CE8\u3050\u306E\u3063\u3066\u3069\u3063\u3061\u304C\u6C37\u6EB6\u3051\u306B\u304F\u3044\u3093\u3060\u308D\u3002\u4E00\u7DD2\u306A\u6C17\u304C\u3059\u308B\u304C\u306A\u3093\u3068\u306A\u304F\u5F8C\u8005\u306E\u65B9\u304C\u6EB6\u3051\u306B\u304F\u3044\u6C17\u3082\u3059\u308B\u3002",
  "id" : 241448789678903297,
  "created_at" : "2012-08-31 08:14:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241447663537618944",
  "text" : "\u306A\u3093\u3058\u3087\u308B\u306E\u305D\u308D\u3067\u3073\u3085\u30FC\u3059\u308B\u306E\u304B",
  "id" : 241447663537618944,
  "created_at" : "2012-08-31 08:09:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5357\u689D\u611B\u4E43",
      "screen_name" : "nanjolno",
      "indices" : [ 3, 12 ],
      "id_str" : "119635653",
      "id" : 119635653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/oRWWcpeo",
      "expanded_url" : "http:\/\/www.geneonuniversal.jp\/rondorobe\/music\/yoshino_nanjo\/",
      "display_url" : "geneonuniversal.jp\/rondorobe\/musi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "241447597812887552",
  "text" : "RT @nanjolno: \u3010\u62E1\u6563\u8D85\u5E0C\u671B\uFF01\u3011\u3053\u306E\u5EA6\u3001\u5357\u689D\u611B\u4E43\u306F\u300111\/14\u306B\u30BD\u30ED\u30C7\u30D3\u30E5\u30FC\u3059\u308B\u3053\u3068\u306B\u306A\u308A\u307E\u3057\u305F\uFF01\uFF01\u5FDC\u63F4\u5B9C\u3057\u304F\u304A\u9858\u3044\u3057\u307E\u3059\uFF01\uFF01\u30B5\u30A4\u30C8\u3082\u4F5C\u3063\u3066\u9802\u304D\u307E\u3057\u305F\u2025\uFF01\uFF01 http:\/\/t.co\/oRWWcpeo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/oRWWcpeo",
        "expanded_url" : "http:\/\/www.geneonuniversal.jp\/rondorobe\/music\/yoshino_nanjo\/",
        "display_url" : "geneonuniversal.jp\/rondorobe\/musi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "241446531880853504",
    "text" : "\u3010\u62E1\u6563\u8D85\u5E0C\u671B\uFF01\u3011\u3053\u306E\u5EA6\u3001\u5357\u689D\u611B\u4E43\u306F\u300111\/14\u306B\u30BD\u30ED\u30C7\u30D3\u30E5\u30FC\u3059\u308B\u3053\u3068\u306B\u306A\u308A\u307E\u3057\u305F\uFF01\uFF01\u5FDC\u63F4\u5B9C\u3057\u304F\u304A\u9858\u3044\u3057\u307E\u3059\uFF01\uFF01\u30B5\u30A4\u30C8\u3082\u4F5C\u3063\u3066\u9802\u304D\u307E\u3057\u305F\u2025\uFF01\uFF01 http:\/\/t.co\/oRWWcpeo",
    "id" : 241446531880853504,
    "created_at" : "2012-08-31 08:05:13 +0000",
    "user" : {
      "name" : "\u5357\u689D\u611B\u4E43",
      "screen_name" : "nanjolno",
      "protected" : false,
      "id_str" : "119635653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590128712906977281\/lWxpoTSQ_normal.jpg",
      "id" : 119635653,
      "verified" : true
    }
  },
  "id" : 241447597812887552,
  "created_at" : "2012-08-31 08:09:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241447439310155776",
  "text" : "\u306A\u306B\u3053\u306E\u30E1\u30F3\u30D8\u30E9\u307F\u305F\u3044\u306A\u306E",
  "id" : 241447439310155776,
  "created_at" : "2012-08-31 08:08:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241447399799812096",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u7F8E\u5473\u3057\u304F\u3066\u6CE3\u304D\u305D\u3046\u3060\u3051\u3069\u3082\u3046\u4E94\u6642\u3067\u3082\u3063\u3068\u6CE3\u304D\u305D\u3046",
  "id" : 241447399799812096,
  "created_at" : "2012-08-31 08:08:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241444988637032448",
  "text" : "\u6BBB\u5265\u3044\u305F\u3089\u6B21\u56DE\u3059\u308B\u7A0B\u5EA6\u306B\u534A\u719F\u306E\u3086\u3067\u5375\u7F8E\u5473\u3057\u304B\u3063\u305F",
  "id" : 241444988637032448,
  "created_at" : "2012-08-31 07:59:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241432563518959618",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u3001\u30D1\u30F3\u3001\u5375\u3002\u3042\u308C\u3001\u3053\u308C\u671D\u3054\u306F\u3093\u306A\u3093\u3058\u3083\u2026",
  "id" : 241432563518959618,
  "created_at" : "2012-08-31 07:09:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241432339325005824",
  "text" : "\u305D\u3001\u305D\u308C\u306E\u3069\u3053\u304C\u30CE\u30F3\u9CE5\u30D3\u30A2\u30EB\u306A\u3093\u3067\u3059\u304B\uFF1F",
  "id" : 241432339325005824,
  "created_at" : "2012-08-31 07:08:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241432134479396864",
  "text" : "\u300C\u3053\u3053\u306E\u8981\u8ACB3\u8AAC\u660E\u3057\u3066\u3082\u3089\u3048\u307E\u3059\u304B\uFF1F\u300D\n\u300C\u3048\u3063\u3001\u5996\u7CBE\u3055\u3093\u3067\u3059\u304B\uFF1F\uFF01\u300D",
  "id" : 241432134479396864,
  "created_at" : "2012-08-31 07:08:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241431874206064640",
  "text" : "\u9662\u751F\u306E\u5148\u8F29\u304C\u8981\u8ACB3\u3068\u5996\u7CBE\u3055\u3093\u3092\u89E3\u91C8\u3057\u9593\u9055\u3048\u308B\u7D20\u6575\u30A4\u30D9\u30F3\u30C8\u306F\u697D\u3057\u304B\u3063\u305F\u306A\u3041",
  "id" : 241431874206064640,
  "created_at" : "2012-08-31 07:06:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241431692965969920",
  "text" : "@kotorin_z \u9CE5\u985E\u306F\u8870\u9000\u3057\u307E\u3057\u305F\uFF1F",
  "id" : 241431692965969920,
  "created_at" : "2012-08-31 07:06:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241431425755267072",
  "text" : "\u3074\u3088\u3074\u3088\u3044\u3046\u3068\u5929\u56FD\u306B\u3044\u3051\u308B\u3089\u3057\u3044(\u9069\u5F53)",
  "id" : 241431425755267072,
  "created_at" : "2012-08-31 07:05:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241431085483962368",
  "text" : "@kotorin_z \u3053\u3068\u308A\u3093\u306F\u3001\u5929\u4F7F\u3060\u3063\u305F\u306E\u3067\u3059\u304B",
  "id" : 241431085483962368,
  "created_at" : "2012-08-31 07:03:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241430874296553472",
  "text" : "\u304A\u3068\u306A\u3057\u304F\u52C9\u5F37\u3059\u308B\u304B\u30FC\u30B3\u30FC\u30D2\u30FC\u6DF9\u308C\u308B\u304B",
  "id" : 241430874296553472,
  "created_at" : "2012-08-31 07:03:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241430737734230016",
  "text" : "\u3069\u3053\u304B\u3068\u304A\u304F\u306B\u3067\u304B\u3051\u305F\u3044\u306A\u3041(\u73FE\u5B9F\u304B\u3089\u306F\u9003\u308C\u3089\u308C\u306A\u3044",
  "id" : 241430737734230016,
  "created_at" : "2012-08-31 07:02:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043B\u0435\u043A\u0441\u0435\u0439 \u041D\u0438\u043A\u0438\u0442\u0438\u043D",
      "screen_name" : "2222_42",
      "indices" : [ 0, 8 ],
      "id_str" : "2338297813",
      "id" : 2338297813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241429895509581824",
  "text" : "@2222_42 29\u6642\u9593\u2026\u7FCC20\u6642\u304B\u2026",
  "id" : 241429895509581824,
  "created_at" : "2012-08-31 06:59:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241429166149488641",
  "text" : "13\u6642\u304F\u3089\u3044\u306B\u8D77\u304D\u305F\u6642\u306B\u3069\u3046\u3057\u3066\u4E8C\u5EA6\u5BDD\u3057\u305F\u306E\u304B\u5C0F\u4E00\u6642\u9593\u554F\u3044\u8A70\u3081\u305F\u3044",
  "id" : 241429166149488641,
  "created_at" : "2012-08-31 06:56:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241428965993103360",
  "text" : "\u3060\u3063\u3066\u3042\u306A\u305F\u30013\u6642\u9593\u3082\u3057\u305F\u3089\u6697\u304F\u306A\u308B\u3088\u3053\u308C",
  "id" : 241428965993103360,
  "created_at" : "2012-08-31 06:55:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241428878395068416",
  "text" : "\u5727\u5012\u7684\u7D76\u671B\u611F",
  "id" : 241428878395068416,
  "created_at" : "2012-08-31 06:55:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241428765996089345",
  "text" : "\u7D76\u671B\u611F\u3084\u3070\u3044",
  "id" : 241428765996089345,
  "created_at" : "2012-08-31 06:54:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241428749546049537",
  "text" : "\u56DB\u6642\u306B\u8D77\u304D\u308B\u3068\u7D76\u671B\u611F\u3084\u3070\u3044\u3088\u306D\u30FC\u2190\u4ECA\u671D5\u6642\n\n\u3080\u304F\u308A\u2190\u4ECA",
  "id" : 241428749546049537,
  "created_at" : "2012-08-31 06:54:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241143321672683520",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 241143321672683520,
  "created_at" : "2012-08-30 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241112907730014208",
  "text" : "\u52D5\u7269\u3068\u622F\u308C\u305F\u307F",
  "id" : 241112907730014208,
  "created_at" : "2012-08-30 09:59:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "owarin",
      "screen_name" : "ls9mk",
      "indices" : [ 0, 6 ],
      "id_str" : "567896882",
      "id" : 567896882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241112671473258497",
  "geo" : { },
  "id_str" : "241112777580744706",
  "in_reply_to_user_id" : 567896882,
  "text" : "@ls9mk \u3056\u3063\u3064\u3089\u3044\u3068",
  "id" : 241112777580744706,
  "in_reply_to_status_id" : 241112671473258497,
  "created_at" : "2012-08-30 09:59:00 +0000",
  "in_reply_to_screen_name" : "ls9mk",
  "in_reply_to_user_id_str" : "567896882",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241112585624248320",
  "text" : "19\u6642\u304B\u3089\u307E\u305F\u304C\u3093\u3070\u308D\u3046\u3002\u3046\u3069\u3093\u7F8E\u5473\u3057\u304B\u3063\u305F\u3002",
  "id" : 241112585624248320,
  "created_at" : "2012-08-30 09:58:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241112515982020608",
  "text" : "\u3044\u3084\u307E\u3041\u7406\u7531\u306F\u3042\u308B",
  "id" : 241112515982020608,
  "created_at" : "2012-08-30 09:57:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241112473502109696",
  "text" : "\u7406\u7531\u3082\u306A\u3044\u611F\u60C5\u306F\u305F\u3076\u3093\u672C\u7269\u3060",
  "id" : 241112473502109696,
  "created_at" : "2012-08-30 09:57:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241094649740136448",
  "text" : "\u4F11\u61A9",
  "id" : 241094649740136448,
  "created_at" : "2012-08-30 08:46:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241069994119684096",
  "text" : "\u306A\u3093\u304B\u3059\u3054\u304F\u5145\u5B9F\u611F\u306E\u3042\u308B\u76EE\u899A\u3081\u3060\u3063\u305F(\u6CE8:\u5BDD\u3066\u305F\u3060\u3051\u3067\u3059)",
  "id" : 241069994119684096,
  "created_at" : "2012-08-30 07:09:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241069814943215618",
  "text" : "\u663C\u5BDD\u304B\u3089\u76EE\u899A\u3081\u305F",
  "id" : 241069814943215618,
  "created_at" : "2012-08-30 07:08:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240791882848952321",
  "text" : "\u3053\u308C\u306F\u2026",
  "id" : 240791882848952321,
  "created_at" : "2012-08-29 12:43:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240791847172186112",
  "text" : "[21:42:01] \u3053\u3068\u308A\u3093: \u3072\u3089\u3044\u305A\u307F\u306E\u88F8\u3068\u304B\u898B\u98FD\u304D\u305F",
  "id" : 240791847172186112,
  "created_at" : "2012-08-29 12:43:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240774148207554563",
  "geo" : { },
  "id_str" : "240774319532277760",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3044\u3063\u3066\u3089\u3063\u3057\u3083\u3044",
  "id" : 240774319532277760,
  "in_reply_to_status_id" : 240774148207554563,
  "created_at" : "2012-08-29 11:34:05 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/xwfb3kJV",
      "expanded_url" : "http:\/\/4sq.com\/QRms6a",
      "display_url" : "4sq.com\/QRms6a"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.029284, 135.77928 ]
  },
  "id_str" : "240705586793172992",
  "text" : "I'm at \u30AB\u30E9\u30AA\u30B1J (\u4EAC\u90FD\u5E02, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/xwfb3kJV",
  "id" : 240705586793172992,
  "created_at" : "2012-08-29 07:00:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240690681117569024",
  "text" : "\u7F8E\u5473\u306A\u308A\uFF01",
  "id" : 240690681117569024,
  "created_at" : "2012-08-29 06:01:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240690188639170560",
  "text" : "\u5927\u5B66\u304B\u3001\u5BB6\u306B\u3053\u3082\u308B\u304B\u2026",
  "id" : 240690188639170560,
  "created_at" : "2012-08-29 05:59:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/O0JC3rbE",
      "expanded_url" : "http:\/\/4sq.com\/SPkqtx",
      "display_url" : "4sq.com\/SPkqtx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0424442266, 135.7706844807 ]
  },
  "id_str" : "240687090596188160",
  "text" : "I'm at \u30AB\u30D5\u30A7\u30FB\u30F4\u30A7\u30EB\u30C7\u30A3 (\u4EAC\u90FD\u5E02, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/O0JC3rbE",
  "id" : 240687090596188160,
  "created_at" : "2012-08-29 05:47:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240686983796625408",
  "text" : "\u9AEA\u306E\u6BDB\u601D\u3063\u305F\u3088\u308A\u5B89\u304F\u3064\u3044\u305F\u306E\u3067\u6D6E\u3044\u305F\u304A\u91D1\u3067\u30AB\u30D5\u30A7\u30F4\u30A7\u30EB\u30C7\u30A3",
  "id" : 240686983796625408,
  "created_at" : "2012-08-29 05:47:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240658873252446208",
  "text" : "\u7F8E\u5BB9\u9662\u306A\u30FC",
  "id" : 240658873252446208,
  "created_at" : "2012-08-29 03:55:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240657348690079744",
  "text" : "\u307E\u3041\u30A2\u30DD\u30A4\u30F3\u30C8\u30E1\u30F3\u30C8\u306E\u7A2E\u985E\u306B\u3082\u3088\u308B\u3051\u308C\u3069",
  "id" : 240657348690079744,
  "created_at" : "2012-08-29 03:49:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240657310207315968",
  "text" : "5\u5206\u524D \u666E\u901A\n10\u5206\u524D \u6C17\u6301\u3061\u65E9\u3081\n15\u5206\u524D \u8FF7\u60D1",
  "id" : 240657310207315968,
  "created_at" : "2012-08-29 03:49:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240657010071318530",
  "text" : "\u30A2\u30DD\u30A4\u30F3\u30C8\u30E1\u30F3\u30C8\u306E15\u5206\u524D\u306B\u7740\u304F\u7656\u2026\u60AA\u3044\u7656\u3058\u3083\u306A\u3044\u304C\u2026",
  "id" : 240657010071318530,
  "created_at" : "2012-08-29 03:47:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240656110393110528",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \uFF24\u3057\u307E\u3057\u305F",
  "id" : 240656110393110528,
  "created_at" : "2012-08-29 03:44:22 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240635952970735616",
  "text" : "\u4E45\u3005\u306B\u5348\u524D\u306B\u8D77\u304D\u305F",
  "id" : 240635952970735616,
  "created_at" : "2012-08-29 02:24:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240635909798772736",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 240635909798772736,
  "created_at" : "2012-08-29 02:24:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240635871802568705",
  "text" : "\u5727\u5012\u7684\u3044\u3081\u3061\u3047\u3093",
  "id" : 240635871802568705,
  "created_at" : "2012-08-29 02:23:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240473735310745601",
  "text" : "\u3053\u3093\u306A\u3055\u3055\u3044\u306A\u3053\u3068\u3067\u3057\u3042\u308F\u305B\u306B\u306A\u308C\u308B\u306E\u3067\u5727\u5012\u7684",
  "id" : 240473735310745601,
  "created_at" : "2012-08-28 15:39:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240473610370809857",
  "text" : "\u30D3\u30EA\u30E4\u30FC\u30C9\u3001\u6570\u5B66 \u3042\u3068\u304A\u5915\u98EF\u306E\u30A8\u30D3\u30AF\u30EA\u30FC\u30E0\u30B3\u30ED\u30C3\u30B1\u7F8E\u5473\u3057\u304B\u3063\u305F",
  "id" : 240473610370809857,
  "created_at" : "2012-08-28 15:39:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240473351783591937",
  "text" : "\u304A\u5207\u308B\u306E\u304C\u3044\u3055\u3055\u304B\u9045\u304B\u3063\u305F\u3053\u3068\u3092\u9664\u3051\u3070\u6628\u65E5\u306F\u7D20\u6674\u3089\u3057\u3044\u3044\u3061\u306B\u3061\u3067\u3042\u3063\u305F",
  "id" : 240473351783591937,
  "created_at" : "2012-08-28 15:38:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240469182024675329",
  "text" : "\u6628\u65E5\u306F\u591A \u69D8 \u4F53\u306F\u89E6\u308C\u306A\u304B\u3063\u305F\u306E\u304C\u6B8B\u5FF5",
  "id" : 240469182024675329,
  "created_at" : "2012-08-28 15:21:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240468909705265152",
  "text" : "10\u7BC0\u307E\u3067\u3042\u308B\u304B\u3089\u4E00\u65E5\u4E8C\u7BC0\u30675\u65E5\u3067\u7D42\u308F\u308B(",
  "id" : 240468909705265152,
  "created_at" : "2012-08-28 15:20:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240465513409568770",
  "text" : "\u65E5\u4ED8\u5909\u308F\u3063\u3061\u3083\u3063\u305F\u304C\u3082\u3046\u3061\u3087\u3063\u3068",
  "id" : 240465513409568770,
  "created_at" : "2012-08-28 15:07:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240456914142650368",
  "text" : "\u307E\u3041\u8D77\u304D\u305F\u306E\u4E09\u6642\u8FD1\u3044\u3057\u306A\u30FC(",
  "id" : 240456914142650368,
  "created_at" : "2012-08-28 14:32:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240456880596582401",
  "text" : "\u3057\u304B\u3057\u7720\u304F\u306A\u3044",
  "id" : 240456880596582401,
  "created_at" : "2012-08-28 14:32:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240452568340385792",
  "text" : "\u4E8C\u7AE0\u4E8C\u7BC0\u307E\u3067\u3084\u308D\u3046",
  "id" : 240452568340385792,
  "created_at" : "2012-08-28 14:15:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 23, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240441127973552129",
  "geo" : { },
  "id_str" : "240441546510569472",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u6CD5\u5B66\u30AC\u30C1\u52E2\u304C\u76EE\u7ACB\u3061\u307E\u3059\u306D #\u306F\u3044",
  "id" : 240441546510569472,
  "in_reply_to_status_id" : 240441127973552129,
  "created_at" : "2012-08-28 13:31:46 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240441154867445760",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u96E2\u8131",
  "id" : 240441154867445760,
  "created_at" : "2012-08-28 13:30:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240441042304909312",
  "text" : "\u3044\u3084\u306F\u3084\u3001\u30AD\u30EA\u304C\u3044\u3044\u304B\u3089\u3063\u3066\u3042\u307E\u308ATwitter\u3057\u3066\u305F\u3089\u30C0\u30E1\u3060\u306A",
  "id" : 240441042304909312,
  "created_at" : "2012-08-28 13:29:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240440886033518592",
  "geo" : { },
  "id_str" : "240440995722981377",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u666E\u901A\u306B\u7A7A\u5E2D\u3042\u308A\u3067\u3059\u3088\u30FC",
  "id" : 240440995722981377,
  "in_reply_to_status_id" : 240440886033518592,
  "created_at" : "2012-08-28 13:29:35 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240440741678166016",
  "text" : "\u7A81\u7136\u306E\u731F\u5947\u6BBA\u4EBA",
  "id" : 240440741678166016,
  "created_at" : "2012-08-28 13:28:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 25, 34 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240440705611333632",
  "text" : "\u30DE\u30A6\u30B9\u304C\u30B1\u30FC\u30D6\u30EB\u306B\u5F15\u3063\u304B\u304B\u3063\u3066\u8DB3\u304C\u629C\u3051\u305F\uFF1F RT @koketomi: \u8DB3\u306B\u30B1\u30FC\u30D6\u30EB\u304C\u5F15\u3063\u304B\u304B\u3063\u3066\u30DE\u30A6\u30B9\u304C\u629C\u3051\u305F",
  "id" : 240440705611333632,
  "created_at" : "2012-08-28 13:28:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240440154114883584",
  "text" : "\u3053\u306E\u30C6\u30AD\u30B9\u30C8\u6F14\u7FD2\u591A\u304F\u3066\u697D\u3057\u3044\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 240440154114883584,
  "created_at" : "2012-08-28 13:26:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240437586324226049",
  "geo" : { },
  "id_str" : "240437821138141184",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3093\u30FC\u3001\u3061\u3087\u3063\u3068\u8003\u3048\u3055\u305B\u3066",
  "id" : 240437821138141184,
  "in_reply_to_status_id" : 240437586324226049,
  "created_at" : "2012-08-28 13:16:58 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240437273852780544",
  "text" : "\u7B39\u304B\u307E\u307C\u3053\u98DF\u3079\u305F\u304F\u306A\u3063\u305F",
  "id" : 240437273852780544,
  "created_at" : "2012-08-28 13:14:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240418579571429376",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 240418579571429376,
  "created_at" : "2012-08-28 12:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240414330699534336",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u98F2\u307F\u305F\u307F",
  "id" : 240414330699534336,
  "created_at" : "2012-08-28 11:43:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240414297606475776",
  "text" : "\u5B9A\u671F\u7684\u306B\u7720\u6C17",
  "id" : 240414297606475776,
  "created_at" : "2012-08-28 11:43:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/uwKzoPV2",
      "expanded_url" : "http:\/\/4sq.com\/MXkHIx",
      "display_url" : "4sq.com\/MXkHIx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.026247, 135.78012773 ]
  },
  "id_str" : "240405264610770944",
  "text" : "\u65E5\u4ED8\u5909\u308F\u308B\u304F\u3089\u3044\u307E\u3067\u306F\u304C\u3093\u3070\u308D\u3046 (@ \u4EAC\u90FD\u5927\u5B66\u4ED8\u5C5E\u56F3\u66F8\u9928\u4ED8\u5C5E24\u6642\u9593\u81EA\u7FD2\u5BA4) http:\/\/t.co\/uwKzoPV2",
  "id" : 240405264610770944,
  "created_at" : "2012-08-28 11:07:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 44, 55 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/K0XSO1iu",
      "expanded_url" : "http:\/\/4sq.com\/MXkJQy",
      "display_url" : "4sq.com\/MXkJQy"
    } ]
  },
  "geo" : { },
  "id_str" : "240405264719826944",
  "text" : "I just unlocked the Back to School badge on @foursquare! Time to party! Er, study. http:\/\/t.co\/K0XSO1iu",
  "id" : 240405264719826944,
  "created_at" : "2012-08-28 11:07:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240381126995226624",
  "text" : "\u5317\u90E8\u3063\u3066\u3054\u98EF\u98DF\u3079\u3089\u308C\u308B\uFF1F",
  "id" : 240381126995226624,
  "created_at" : "2012-08-28 09:31:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/NDWriWh0",
      "expanded_url" : "http:\/\/4sq.com\/QqExgC",
      "display_url" : "4sq.com\/QqExgC"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0255201234, 135.7763385773 ]
  },
  "id_str" : "240356942126645248",
  "text" : "I'm at \u30D3\u30EA\u30E4\u30FC\u30C9 BUZZ (\u4EAC\u90FD\u5E02\u5DE6\u4EAC\u533A, \u4EAC\u90FD\u5E9C) http:\/\/t.co\/NDWriWh0",
  "id" : 240356942126645248,
  "created_at" : "2012-08-28 07:55:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240327902678351872",
  "text" : "\u3082\u3046\u4E09\u6642\u304B\u3088",
  "id" : 240327902678351872,
  "created_at" : "2012-08-28 06:00:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240326376668925952",
  "text" : "\u5148\u751F\u306B",
  "id" : 240326376668925952,
  "created_at" : "2012-08-28 05:54:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240326252085534720",
  "text" : "\u3042\u3068\u5B66\u6821\u3067\u732B\u304C\u7D1B\u308C\u8FBC\u3093\u3067\u304D\u3066\u3001\u3058\u3083\u308C\u3066\u305F\u3089\u5148\u751F\u304C\u30DE\u30B8\u30AE\u30EC\u3055\u308C\u308B\u3093\u3060\u3051\u3069\u3001\u4F55\u8A00\u3063\u3066\u3093\u306E\u304B\u6ED1\u820C\u60AA\u304F\u3066\u534A\u5206\u3082\u805E\u304D\u53D6\u308C\u306A\u304F\u3066\u305D\u308C\u3092\u4F1D\u3048\u305F\u3089\u30AF\u30E9\u30B9\u304C\u697D\u3057\u3052\u306A\u96F0\u56F2\u6C17\u306B\u306A\u308B\u5922\u3092\u898B\u305F",
  "id" : 240326252085534720,
  "created_at" : "2012-08-28 05:53:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240325743970750464",
  "text" : "\u30D5\u30EC\u30F3\u30C1\u30C8\u30FC\u30B9\u30C8\u3064\u304F\u308B\u5922\u898B\u305F\u3057\u4F5C\u308B\u304B",
  "id" : 240325743970750464,
  "created_at" : "2012-08-28 05:51:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240323155875471360",
  "geo" : { },
  "id_str" : "240325451980107776",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u305B\u3044\u304B\u3064\u308A\u305A\u3080\u306F \u3082\u3069\u3089\u306A\u3044",
  "id" : 240325451980107776,
  "in_reply_to_status_id" : 240323155875471360,
  "created_at" : "2012-08-28 05:50:27 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240322106510942210",
  "text" : "\u304F\u3058\u306B\u304A\u304D \u306B\u3069\u306D\u3092\u3057\u305F\u3089 \u3082\u3046\u306B\u3058\u304B",
  "id" : 240322106510942210,
  "created_at" : "2012-08-28 05:37:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/cm5gg7Pt",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/37?prefill=nakator",
      "display_url" : "gohantabeyo.com\/nani\/37?prefil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240260631654174721",
  "text" : "\u98F2\u307F\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/cm5gg7Pt",
  "id" : 240260631654174721,
  "created_at" : "2012-08-28 01:32:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 0, 7 ],
      "id_str" : "443191476",
      "id" : 443191476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239927500233404416",
  "geo" : { },
  "id_str" : "239928108222935040",
  "in_reply_to_user_id" : 106036912,
  "text" : "@ac_key \u308F\u3056\u308F\u3056\u3069\u3046\u3082\u3067\u3059\u3001\u3042\u3068\u3067\u8A73\u3057\u304F\u307F\u3066\u307F\u307E\u3059",
  "id" : 239928108222935040,
  "in_reply_to_status_id" : 239927500233404416,
  "created_at" : "2012-08-27 03:31:33 +0000",
  "in_reply_to_screen_name" : "ac_k_y",
  "in_reply_to_user_id_str" : "106036912",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239927509242740736",
  "geo" : { },
  "id_str" : "239927968611323904",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3054\u3081\u3093\u306A\u3055\u3044?\u3067\u3057\u305F\u2026",
  "id" : 239927968611323904,
  "in_reply_to_status_id" : 239927509242740736,
  "created_at" : "2012-08-27 03:31:00 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239927013459247106",
  "geo" : { },
  "id_str" : "239927281823408128",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3082\u3057\u304B\u3057\u3066:\u30C0\u30F3\u30A8\u30DC\u3068DDR\u3063\u3066\u9055\u3046\u3082\u306E",
  "id" : 239927281823408128,
  "in_reply_to_status_id" : 239927013459247106,
  "created_at" : "2012-08-27 03:28:16 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239924119506919424",
  "geo" : { },
  "id_str" : "239926609426132992",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u606F\u3092\u3059\u308B\u3088\u3046\u306BDDR\u3068\u306F\u2026",
  "id" : 239926609426132992,
  "in_reply_to_status_id" : 239924119506919424,
  "created_at" : "2012-08-27 03:25:35 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/9YrlwWRD",
      "expanded_url" : "http:\/\/4sq.com\/QHPkOa",
      "display_url" : "4sq.com\/QHPkOa"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.0275130896, 135.7809611236 ]
  },
  "id_str" : "239918807026634752",
  "text" : "\u307C\u304F\u306F\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u306E (@ \u4EAC\u90FD\u5927\u5B66 \u6587\u5B66\u90E8\u65B0\u9928\u5B66\u751F\u30E9\u30A6\u30F3\u30B8) http:\/\/t.co\/9YrlwWRD",
  "id" : 239918807026634752,
  "created_at" : "2012-08-27 02:54:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239909598616760321",
  "text" : "\u306C\u308B\u3063\u3068\u8D77\u304D\u305F",
  "id" : 239909598616760321,
  "created_at" : "2012-08-27 02:18:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239694813946068992",
  "geo" : { },
  "id_str" : "239695287327805440",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u305C\u3072\u305C\u3072(\u30B3\u30F3\u30D3\u30FC\u30D5\u4E00\u7F36\u7D50\u69CB\u3042\u308B\u306E\u306D\u2026)",
  "id" : 239695287327805440,
  "in_reply_to_status_id" : 239694813946068992,
  "created_at" : "2012-08-26 12:06:24 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239693760013930496",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 239693760013930496,
  "created_at" : "2012-08-26 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239692529317072898",
  "text" : "\u30B7\u30F3\u30D7\u30EB\u3044\u305A\u60AA\u304F\u306A\u3044",
  "id" : 239692529317072898,
  "created_at" : "2012-08-26 11:55:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239692370826895360",
  "text" : "\u30EC\u30BF\u30B9\u3068\u30B3\u30F3\u30D3\u30FC\u30D5\u306E\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1",
  "id" : 239692370826895360,
  "created_at" : "2012-08-26 11:54:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239685561399521281",
  "text" : "\u98DF\u30D1\u30F3\u2026\u58F2\u308A\u5207\u308C\u2026",
  "id" : 239685561399521281,
  "created_at" : "2012-08-26 11:27:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239684599242952704",
  "text" : "\u3084\u3055\u3044\u306A\u3044\u306E\u304C\u306A\u3041",
  "id" : 239684599242952704,
  "created_at" : "2012-08-26 11:23:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239684591898750978",
  "text" : "\u30B3\u30F3\u30D3\u30FC\u30D5\u3001\u30C4\u30CA\u3001\u30AA\u30EA\u30FC\u30D6\u2026\u30D1\u30F3\u8CB7\u3063\u3066\u304D\u3066\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u304B\u306A",
  "id" : 239684591898750978,
  "created_at" : "2012-08-26 11:23:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239683917643399168",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u98F2\u307F\u904E\u304E\u3063\u3066\u66F8\u3053\u3046\u3068\u3057\u305F\u3089\u30B3\u30FC\u30D2\u30FC\u306E\u6C34\u7740\u3063\u3066\u2026",
  "id" : 239683917643399168,
  "created_at" : "2012-08-26 11:21:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239683742719942656",
  "text" : "\u3082\u3057\u304B\u3057\u3066:\u3046\u3069\u3093\u306F\u6D88\u5316\u306B\u3044\u3044",
  "id" : 239683742719942656,
  "created_at" : "2012-08-26 11:20:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239683667050500096",
  "text" : "\u4F55\u304B\u98DF\u3079\u306A\u3044\u3068",
  "id" : 239683667050500096,
  "created_at" : "2012-08-26 11:20:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239683601317363712",
  "text" : "\u4EBA\u9593\u306F\u3069\u3046\u3057\u3066\u304A\u306A\u304B\u304C\u3078\u308B\u306E\u304B\u306A\u2026",
  "id" : 239683601317363712,
  "created_at" : "2012-08-26 11:19:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239678131416473600",
  "text" : "@Malmach140 \u6700\u8FD1\u3084\u3063\u3068\u305D\u3046\u601D\u3046\u3088\u3046\u306B\u306A\u308A\u307E\u3057\u305F\u306D\u30FC",
  "id" : 239678131416473600,
  "created_at" : "2012-08-26 10:58:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239671683332571137",
  "text" : "\u6700\u8FD1\u306F\u9577\u304F\u3066\u30824\u5DFB\u3088\u308A\u77ED\u3044\u6F2B\u753B\u306E\u65B9\u304C\u597D\u304D\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 239671683332571137,
  "created_at" : "2012-08-26 10:32:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239671511038955520",
  "text" : "\u7269\u8A9E\u306E\u7D42\u308F\u308A\u306F\u3001\u5207\u306A\u3044\n\u3067\u3082\u4E0D\u5FC5\u8981\u306B\u5F15\u304D\u4F38\u3070\u3055\u308C\u3066\u53CE\u96C6\u304C\u3064\u304B\u306A\u304F\u306A\u3063\u305F\u7269\u8A9E\u3082\u307E\u305F\u9055\u3063\u305F\u610F\u5473\u3067\u3001\u5207\u306A\u3044",
  "id" : 239671511038955520,
  "created_at" : "2012-08-26 10:31:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239670970980380672",
  "text" : "\u4EBA\u9593\u8A66\u9A13\u3067\u306F\u4EBA\u985E\u6700\u5F37\u3082\u51FA\u3066\u6765\u305F\u3057\u5927\u8A70\u3081\u3060\u306A\u30FC",
  "id" : 239670970980380672,
  "created_at" : "2012-08-26 10:29:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239670794932846592",
  "text" : "\u307E\u3058\u3081\u306A\u6642\u9593 \u7D42\u308F\u3063\u3061\u3083\u3063\u305F\u306A\u30FC\u3001\u306A\u3093\u3068\u3082\u8A00\u3048\u306A\u3044\u723D\u3084\u304B\u3055\u3068\u5207\u306A\u3055\u3068\u2026",
  "id" : 239670794932846592,
  "created_at" : "2012-08-26 10:29:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239665739781505025",
  "text" : "\u3046\u3093\u3081\u3044\u306E\u3060\u30FC\u304F\u3055\u3044\u3069",
  "id" : 239665739781505025,
  "created_at" : "2012-08-26 10:08:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239664640878051328",
  "text" : "\u3084\u304E\u3055\u3093\u2026",
  "id" : 239664640878051328,
  "created_at" : "2012-08-26 10:04:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/KLflSOZD",
      "expanded_url" : "http:\/\/www1.odn.ne.jp\/mushimaru\/bakaessay\/goats.htm",
      "display_url" : "www1.odn.ne.jp\/mushimaru\/baka\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "239664306612994048",
  "text" : "\u3053\u308C\u306F\u2026\u51C4\u3044\u306A  http:\/\/t.co\/KLflSOZD",
  "id" : 239664306612994048,
  "created_at" : "2012-08-26 10:03:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239659843609325569",
  "text" : "\u5451\u3093\u3079\u3047\u306E\u30EC\u30E0\u30EA\u30A2",
  "id" : 239659843609325569,
  "created_at" : "2012-08-26 09:45:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239659680018882560",
  "text" : "\u306F\u308A\u3042\u308F\u305B",
  "id" : 239659680018882560,
  "created_at" : "2012-08-26 09:44:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 17, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239652622938812416",
  "geo" : { },
  "id_str" : "239655604061339648",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank #\u306F\u3044 (\u8AB0\u304B\u3084\u308B\u3068\u601D\u3063\u3066\u305F)",
  "id" : 239655604061339648,
  "in_reply_to_status_id" : 239652622938812416,
  "created_at" : "2012-08-26 09:28:43 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239652298433892352",
  "text" : "\u300C\u306A\u306B\u3084\u3063\u3066\u3093\u306E\uFF1F\u67B6\u7A7A\u751F\u7269\u306E\u30E2\u30CE\u30DE\u30CD\uFF1F\u300D\u3063\u3066\u805E\u304F\u5ACC\u304C\u3089\u305B\u601D\u3044\u3064\u3044\u305F\u306E\u3067\u597D\u304D\u306B\u4F7F\u3063\u3066\u3044\u3044\u3067\u3059\u3088",
  "id" : 239652298433892352,
  "created_at" : "2012-08-26 09:15:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239652121425874944",
  "text" : "\u3066\u304B\u3082\u304618\u6642(\u3057\u308D\u3081",
  "id" : 239652121425874944,
  "created_at" : "2012-08-26 09:14:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239651826687946752",
  "text" : "@kotorin_z \u5243\u308C\u306F\u7121\u3044\u3067\u3059",
  "id" : 239651826687946752,
  "created_at" : "2012-08-26 09:13:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239651739446415360",
  "text" : "\u5F53\u7136\u3046\u3061\u306B\u305D\u3093\u306A\u3082\u306E\u306F\u306A\u3044",
  "id" : 239651739446415360,
  "created_at" : "2012-08-26 09:13:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239651710061121536",
  "text" : "\u30AB\u30C1\u30E5\u30FC\u30B7\u30E3\u3001\u9AEA\u7559\u3081\u3081\u3044\u305F\u3082\u306E\u304C\u6B32\u3057\u3044\u3068\u304B\u601D\u3063\u305F\u304C\u7D76\u5BFE\u7740\u308B\u65B9\u304C\u65E9\u3044",
  "id" : 239651710061121536,
  "created_at" : "2012-08-26 09:13:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5207\u308C\u3088",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239651433010569216",
  "text" : "#\u5207\u308C\u3088",
  "id" : 239651433010569216,
  "created_at" : "2012-08-26 09:12:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239651380053286914",
  "text" : "\u9AEA\u306E\u6BDB\u9B31\u9676\u3057\u3044\u2026",
  "id" : 239651380053286914,
  "created_at" : "2012-08-26 09:11:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239644959974768640",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u308B\u304B\u2026",
  "id" : 239644959974768640,
  "created_at" : "2012-08-26 08:46:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239635698376925185",
  "text" : "\u305F\u3001TL\u898B\u3066\u308B\u6642\u9593\u306E\u5E45\u304C\u5E83\u3044\u8A33\u3058\u3083\u306A\u3044\u3088(",
  "id" : 239635698376925185,
  "created_at" : "2012-08-26 08:09:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239635549009367041",
  "text" : "\u5B9F\u969B\u306F\u305F\u307E\u305F\u307ETL\u307F\u3066\u308B\u6642\u306B\u30EA\u30D7\u30E9\u30A4\u304C\u304F\u308B\u3093\u3067\u3059\u3051\u3069\u306D",
  "id" : 239635549009367041,
  "created_at" : "2012-08-26 08:09:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239635490029064192",
  "text" : "\u5149\u306E\u65E9\u3055\u3067\u30EA\u30D7\u30E9\u30A4\u8FD4\u3057\u3066\u308B\u3068\u3044\u3063\u3064\u3082Twitter\u307F\u3066\u308B\u3068\u601D\u308F\u308C\u3061\u3083\u3046\u306A\u30FC",
  "id" : 239635490029064192,
  "created_at" : "2012-08-26 08:08:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239635238068830208",
  "geo" : { },
  "id_str" : "239635353223442432",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u3044\u3048\u3044\u3048\u30FC\u3001\u307E\u305F\u3084\u308A\u307E\u3057\u3087\u3046\uFF01",
  "id" : 239635353223442432,
  "in_reply_to_status_id" : 239635238068830208,
  "created_at" : "2012-08-26 08:08:15 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239635208910016512",
  "text" : "\u53CB\u4EBA\u306B\u96C6 \u5408\u8AD6\u306E\u8CEA\u554F\u3092\u53D7\u3051\u305F\u3001\u3042\u306E\u30BC\u30DF\u3057\u3070\u3089\u304F\u884C\u3051\u3066\u306A\u3044\u3093\u3060\u3088\u306A\u2026",
  "id" : 239635208910016512,
  "created_at" : "2012-08-26 08:07:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3053\u3053\u304B\u3089\u539F\u5247\u6E1B\u901F",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239627901933346816",
  "text" : "\u4E00\u7AE0\u306F\u8AAD\u307F\u7D42\u3048\u308B\u306E\u65E9\u304B\u3063\u305F\u3002 #\u3053\u3053\u304B\u3089\u539F\u5247\u6E1B\u901F",
  "id" : 239627901933346816,
  "created_at" : "2012-08-26 07:38:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239627288491196419",
  "text" : "\u30AD\u30A8\u30A7\u30A7\u30A7\u30A7\u5727\u5012\u7684\u30CF\u30A6\u30B9\u30C9\u30EB\u30D5\u30A5\u30A5\u30A5\u30A5",
  "id" : 239627288491196419,
  "created_at" : "2012-08-26 07:36:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239609464171401216",
  "geo" : { },
  "id_str" : "239609570106961920",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4E00\u3064\uFF14\uFF10\uFF10\uFF10\u5186\u3067\u898B\u7A4D\u3082\u3063\u3066\u3082\u89AA\u6E80\u304B\u2026",
  "id" : 239609570106961920,
  "in_reply_to_status_id" : 239609464171401216,
  "created_at" : "2012-08-26 06:25:47 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239609440318390272",
  "text" : "\u5727\u5012\u7684\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u304C\u5727\u5012\u7684",
  "id" : 239609440318390272,
  "created_at" : "2012-08-26 06:25:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239609070301093889",
  "geo" : { },
  "id_str" : "239609320654921730",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u308C\u3060\u3051\u3067\u4F55\u5DFB\u5206\u306A\u3093\u3060\u308D\u3046\u306D",
  "id" : 239609320654921730,
  "in_reply_to_status_id" : 239609070301093889,
  "created_at" : "2012-08-26 06:24:48 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239608626069794816",
  "text" : "\u3055\u3041\u673A\u306E\u4E0A\u3092\u7247\u3065\u3051\u3066\u30FB\u30FB\u30FB",
  "id" : 239608626069794816,
  "created_at" : "2012-08-26 06:22:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239597878690062336",
  "text" : "\u4F55\u3082\u6012\u3063\u3066\u306A\u3044\uFF0E\u5727\u5012\u7684\u7A4F\u3084\u304B\uFF0E",
  "id" : 239597878690062336,
  "created_at" : "2012-08-26 05:39:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239597779914215424",
  "text" : "\uFF08\u3086\u3067\u3064\u3064\uFF0C\u3064\u3086\u4F5C\u3063\u3066\u304B\u3051\u308B\u3060\u3051\uFF09",
  "id" : 239597779914215424,
  "created_at" : "2012-08-26 05:38:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239597695055056896",
  "text" : "\u30A8\u30F3\u30C9\u30FC\u6012\u308A\u306E\u304B\u3051\u3046\u3069\u3093\u4F5C\u308A",
  "id" : 239597695055056896,
  "created_at" : "2012-08-26 05:38:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239597334017753088",
  "text" : "\u3055\u3044\u304D\u3093\u3081\u3093\u308B\u3044\u3070\u3063\u304B\u308A\u305F\u3079\u3066\u3044\u308B\u3045",
  "id" : 239597334017753088,
  "created_at" : "2012-08-26 05:37:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239595979907661825",
  "text" : "\u3084\u3063\u3071\u308A\u304A\u3068\u306A\u3057\u304F\u3046\u3069\u3093\u3086\u3067\u308B",
  "id" : 239595979907661825,
  "created_at" : "2012-08-26 05:31:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239594588980006912",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u3060\u3057\u8AB0\u3082\u6765\u307E\u3044",
  "id" : 239594588980006912,
  "created_at" : "2012-08-26 05:26:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239594145327509504",
  "text" : "\u307C\u3063\u3061\u30B5\u30F3\u30DE\u30EB\u30AF\u30EC\u30B9\u30C8\u30E9\u30F3\u6C7A\u3081\u308B\u304B\u30FC\uFF1F\uFF1F",
  "id" : 239594145327509504,
  "created_at" : "2012-08-26 05:24:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239593978176102400",
  "text" : "\u3053\u308C\u30C9\u30EA\u30F3\u30AF\u306F\u98F2\u307F\u653E\u984C\u3058\u3083\u306A\u3044\u307D\u3044\u306A\u30FC",
  "id" : 239593978176102400,
  "created_at" : "2012-08-26 05:23:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239593092683034625",
  "text" : "@higeyaaaaaaah \u304A\u3057\u3083\u308C\u306A\u611F\u3058\u3067\u826F\u3044\u611F\u3058\u3067\u3059",
  "id" : 239593092683034625,
  "created_at" : "2012-08-26 05:20:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239592756891226113",
  "text" : "\u3042\u3046\u3001\u3081\u3044\u3093\u306F\u98DF\u3079\u653E\u984C\u3058\u3083\u306A\u3044",
  "id" : 239592756891226113,
  "created_at" : "2012-08-26 05:18:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239592610841374720",
  "text" : "@higeyaaaaaaah \u30E1\u30CC\u30FC\u5168\u4F53\u7684\u306B\u9AD8\u3081\u3067\u3059\u304C1500\u5186\u304F\u3089\u3044\u3067\u30E1\u30A4\u30F3\u3068\u30D1\u30F3\u3068\u98F2\u307F\u7269\u98DF\u3079\u653E\u984C\u306F\u3044\u3044\u306A\u30FC\u3063\u3066",
  "id" : 239592610841374720,
  "created_at" : "2012-08-26 05:18:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308B\u304F\u308B(\u3064\u3044\u304D\u3093\u3057\u305F\u3044)",
      "screen_name" : "KURUKURU888333",
      "indices" : [ 0, 15 ],
      "id_str" : "337502390",
      "id" : 337502390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239591413732487168",
  "geo" : { },
  "id_str" : "239592300026683392",
  "in_reply_to_user_id" : 337502390,
  "text" : "@KURUKURU888333 \u9593\u3068\u306F\u306A\u3093\u3060\u3063\u305F\u306E\u304B",
  "id" : 239592300026683392,
  "in_reply_to_status_id" : 239591413732487168,
  "created_at" : "2012-08-26 05:17:10 +0000",
  "in_reply_to_screen_name" : "KURUKURU888333",
  "in_reply_to_user_id_str" : "337502390",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239592054735380480",
  "text" : "\u5317\u5C71\u901A\u306E\u30B5\u30F3\u30DE\u30EB\u30AF\u30EC\u30B9\u30C8\u30E9\u30F3\u2026",
  "id" : 239592054735380480,
  "created_at" : "2012-08-26 05:16:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239591143602532352",
  "text" : "\u3042\u308C(\u30B7\u30E3\u30EF\u30FC)\u304B\u3053\u308C(\u3054\u306F\u3093)\u304B",
  "id" : 239591143602532352,
  "created_at" : "2012-08-26 05:12:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239588876174381056",
  "text" : "\u4ECA\u65E5\u306F\u3001\u65E5\u66DC\u65E5\u304B",
  "id" : 239588876174381056,
  "created_at" : "2012-08-26 05:03:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239588686273073153",
  "text" : "\u30AB\u30EC\u30FC\u98DF\u3079\u305F\u3044\u306A\u30FC",
  "id" : 239588686273073153,
  "created_at" : "2012-08-26 05:02:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239588205924581376",
  "text" : "\u307E\u3076\u305F\u3068\u304B\u3089\u3060\u304C\u304A\u3082\u3044\u305F\u3044\u3077\u306E\u3084\u3064",
  "id" : 239588205924581376,
  "created_at" : "2012-08-26 05:00:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239588099133411328",
  "text" : "\u304A\u304D\u305F",
  "id" : 239588099133411328,
  "created_at" : "2012-08-26 05:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239540692844703744",
  "geo" : { },
  "id_str" : "239587910456848385",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u4E00\u4F53\u4F55\u304C",
  "id" : 239587910456848385,
  "in_reply_to_status_id" : 239540692844703744,
  "created_at" : "2012-08-26 04:59:43 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239457048176254976",
  "text" : "\u5727\u5012\u7684\u5E30\u5B85",
  "id" : 239457048176254976,
  "created_at" : "2012-08-25 20:19:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239454578309988352",
  "text" : "\u6065\u305A\u304B\u3057\u3044\u304B\u3089\u3072\u3089\u304C\u306A\u3067\u66F8\u3044\u305F\u306E\u306B\u305D\u308C\u304C\u3086\u3048\u306B\u3082\u3063\u3068\u6065\u305A\u304B\u3057\u3044\u3053\u3068\u306B\u306A\u3063\u305F",
  "id" : 239454578309988352,
  "created_at" : "2012-08-25 20:09:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239454373044944897",
  "text" : "\u305D\u3082\u305D\u3082\u6F22\u5B57\u304C\u9055\u3063\u305F\u3001\u3042\u3089\u6065\u305A\u304B\u3057\u3044",
  "id" : 239454373044944897,
  "created_at" : "2012-08-25 20:09:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239454284557737984",
  "text" : "\u3042\u308C\u30FC\u76F8\u5BFE\u304B\u30FC\n\u308A\u3089\u3066\u3043\u3076\u304B\u30FC\u3069\u3046\u308A\u3067\u6EF2\u3093\u3067\u3053\u306A\u3044\u3067\u3085\u3042\u308B\u611F",
  "id" : 239454284557737984,
  "created_at" : "2012-08-25 20:08:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239454052382027776",
  "text" : "\u305D\u3046\u305F\u3044\uFF1F\u305D\u3046\u3064\u3044\uFF1F",
  "id" : 239454052382027776,
  "created_at" : "2012-08-25 20:07:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239453943955066880",
  "text" : "\u3048\u3001\u3082\u3057\u304B\u3057\u3066\u305D\u3046\u305F\u3044\u3044\u305D\u3046",
  "id" : 239453943955066880,
  "created_at" : "2012-08-25 20:07:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239453851483267072",
  "text" : "@kotorin_z \u4F4D\u76F8\u7A7A\u9593\u306E\u90E8\u5206\u7A7A\u9593\u306B\u4E00\u822C\u306B(?)\u5165\u308B\u4F4D\u76F8\u306E\u3088\u3046\u3067\u3059",
  "id" : 239453851483267072,
  "created_at" : "2012-08-25 20:07:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239453362414825472",
  "text" : "\u304D\u306E\u3046\u306F\u305D\u3046\u3064\u3044\u3044\u305D\u3046\u304C\u308F\u304B\u3063\u305F\u306E\u3067\u3001\u3068\u3063\u3066\u3082\u3088\u3044\u3044\u3061\u306B\u3061\u3067\u3057\u305F",
  "id" : 239453362414825472,
  "created_at" : "2012-08-25 20:05:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239452910092681216",
  "text" : "\u308F\u305F\u3057\u306F\u3001\u3053\u3053\u306B\u3044\u308B",
  "id" : 239452910092681216,
  "created_at" : "2012-08-25 20:03:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239331419703369728",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 239331419703369728,
  "created_at" : "2012-08-25 12:00:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239312930267623424",
  "geo" : { },
  "id_str" : "239313002317357056",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u304A\u304B\u3048\u308A\u30A1\uFF01",
  "id" : 239313002317357056,
  "in_reply_to_status_id" : 239312930267623424,
  "created_at" : "2012-08-25 10:47:20 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239312949502672897",
  "text" : "\u3044\u3055\u3055\u304B\u65E9\u904E\u304E\u305F",
  "id" : 239312949502672897,
  "created_at" : "2012-08-25 10:47:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239302511608090624",
  "text" : "\u6C17\u306B\u306A\u308B\u304B\u3089\u3088\u3063\u3066\u884C\u304F\u304B",
  "id" : 239302511608090624,
  "created_at" : "2012-08-25 10:05:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239302366460014592",
  "text" : "\u7518\u98DF\u3068\u725B\u4E73\u306E\u30B3\u30F3\u30DC\u306F\u5727\u5012\u7684",
  "id" : 239302366460014592,
  "created_at" : "2012-08-25 10:05:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239302305340600320",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u6771\u4EAC\u306EDONQ\u3067\u7518\u98DF\u58F2\u3063\u3066\u305F\u3051\u3069\u95A2\u897F\u5730\u533A\u306E\u5E97\u8217\u306B\u3082\u3042\u308B\u306E\u304B\u306A",
  "id" : 239302305340600320,
  "created_at" : "2012-08-25 10:04:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239301323546300418",
  "geo" : { },
  "id_str" : "239301533479624704",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u5727\u5012\u7684\u3067\u3059\u3088\u306D(^^)(^^)(^^)",
  "id" : 239301533479624704,
  "in_reply_to_status_id" : 239301323546300418,
  "created_at" : "2012-08-25 10:01:46 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239301405880492032",
  "text" : "\u307E\u3041\u79C1\u306B\u306F\u95A2\u4FC2\u306A\u3044\u3053\u3068\u306A\u3093\u3067\u3059\u3051\u3069\u306D\u3063",
  "id" : 239301405880492032,
  "created_at" : "2012-08-25 10:01:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239301222761381888",
  "text" : "\u533B\u5B66\u514D\u8A31\u3068\u5F01\u8B77\u58EB\u30D0\u30C3\u30C2\u6301\u3064\u3068\u3001\u533B\u5B66\u3068\u6CD5\u5B66\u304C\u5408\u308F\u3055\u308A\u6700\u5F37\u306B\u898B\u3048\u308B\uFF1F",
  "id" : 239301222761381888,
  "created_at" : "2012-08-25 10:00:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239294894307438592",
  "text" : "\u5727\u5012\u7684\u7406\u89E3\uFF01",
  "id" : 239294894307438592,
  "created_at" : "2012-08-25 09:35:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239294873646276608",
  "text" : "\u306A\u3093\u3067\u3053\u3093\u306A\u7C21\u5358\u306A\u3053\u3068\u306B\u6C17\u3065\u304B\u306A\u304B\u3063\u305F\u3093\u3060\u308D\u3046",
  "id" : 239294873646276608,
  "created_at" : "2012-08-25 09:35:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "k@ori.k...",
      "screen_name" : "chinchikurin48",
      "indices" : [ 0, 15 ],
      "id_str" : "3018640687",
      "id" : 3018640687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239292467894157312",
  "geo" : { },
  "id_str" : "239292698224373760",
  "in_reply_to_user_id" : 277901173,
  "text" : "@chinchikurin48 \u52C9\u5F37\u3057\u308D\u3063\u3066\u3053\u3068\u3067\u3059\u306D(",
  "id" : 239292698224373760,
  "in_reply_to_status_id" : 239292467894157312,
  "created_at" : "2012-08-25 09:26:39 +0000",
  "in_reply_to_screen_name" : "chinchikurim_ba",
  "in_reply_to_user_id_str" : "277901173",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/6dOoZcVd",
      "expanded_url" : "http:\/\/twitpic.com\/angtet",
      "display_url" : "twitpic.com\/angtet"
    } ]
  },
  "geo" : { },
  "id_str" : "239292647846584320",
  "text" : "\u7A4D\u5206\u306B\u898B\u3048\u305F\u3051\u3069\u6C17\u306E\u305B\u3044\u3060\u3063\u305F http:\/\/t.co\/6dOoZcVd",
  "id" : 239292647846584320,
  "created_at" : "2012-08-25 09:26:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239292357172940800",
  "text" : "\u3075\u3041\u307C\u3059\u305F\u30FC\u307F\u308C\u306A\u3044\u306E\u79C1\u3060\u3051\uFF1F",
  "id" : 239292357172940800,
  "created_at" : "2012-08-25 09:25:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239289020662812672",
  "text" : "\u305D\u308C\u306E\u3069\u3053\u304C\u30C8\u30EA\u30D3\u30A2\u30EB\u306A\u3093\u3067\u3059\u304B\u2026(\u6D99\u76EE)",
  "id" : 239289020662812672,
  "created_at" : "2012-08-25 09:12:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowplaying",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239288737496973312",
  "text" : "#nowplaying \u8EE2\u304C\u308B\u5CA9\u3001\u541B\u306B\u671D\u304C\u964D\u308B - ASIAN KUNG-FU GENERATION",
  "id" : 239288737496973312,
  "created_at" : "2012-08-25 09:10:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239271916089794560",
  "text" : "\u76EE\u306E\u524D\u306E\u4EBA\u3092dis\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u767A\u8A00\u3068\u304B\u6016\u304F\u3066\u51FA\u6765\u306A\u3044\u308F\u30FC",
  "id" : 239271916089794560,
  "created_at" : "2012-08-25 08:04:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239270953618661376",
  "text" : "\u516C\u5171\u306E\u30B9\u30DA\u30FC\u30B9\u3067\u4E0D\u7279\u5B9Adis\u3068\u306F\u9762\u767D\u3044",
  "id" : 239270953618661376,
  "created_at" : "2012-08-25 08:00:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239270834148089856",
  "text" : "\u6176\u5FDCdis\u3082\u304A\u3053\u306A\u3063\u3066\u3089\u3063\u3057\u3083\u308B",
  "id" : 239270834148089856,
  "created_at" : "2012-08-25 07:59:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239270756280848384",
  "text" : "\u300C\u7406\u7CFB\u306B\u6C11\u6CD5\u3084\u3089\u305B\u305F\u3089\u597D\u304D\u305D\u3046\u3060\u3088\u306A\u300D\n\u300C\u7406\u8A70\u3081\u3060\u304B\u3089\u306A\u300D\n\u300C\u3067\u3082\u3042\u3044\u3064\u3089\u65E5\u672C\u8A9E\u602A\u3057\u304F\u306D\u300D\n\u300C\u78BA\u304B\u306B\u306A\u30FC\u300D\n\n\u30A4\u30E9\u30C3",
  "id" : 239270756280848384,
  "created_at" : "2012-08-25 07:59:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 3, 14 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238680638792810496",
  "text" : "RT @nonamea774: \u30B9\u30AB\u30A4\u30D7\u3001Ctrl\uFF0BEnter\u3067\u9001\u4FE1\u3057\u3088\u3046\u3068\u3057\u3066\u3001\u6539\u884C\u3059\u308B\u2026\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/krile2.starwing.net\/\" rel=\"nofollow\"\u003EKrile2\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238679390769274881",
    "text" : "\u30B9\u30AB\u30A4\u30D7\u3001Ctrl\uFF0BEnter\u3067\u9001\u4FE1\u3057\u3088\u3046\u3068\u3057\u3066\u3001\u6539\u884C\u3059\u308B\u2026\u2026",
    "id" : 238679390769274881,
    "created_at" : "2012-08-23 16:49:35 +0000",
    "user" : {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "protected" : false,
      "id_str" : "122305557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599956952429432832\/8y-IRC09_normal.png",
      "id" : 122305557,
      "verified" : false
    }
  },
  "id" : 238680638792810496,
  "created_at" : "2012-08-23 16:54:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238606618751803392",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 238606618751803392,
  "created_at" : "2012-08-23 12:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238460529851641856",
  "text" : "\u8A9E\u5B66\u306E\u7D42\u7109\u306F\u8FD1\u3044\n\u3042\u30681\u5358\u4F4D",
  "id" : 238460529851641856,
  "created_at" : "2012-08-23 02:19:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238460372334555138",
  "text" : "\u3053\u306E\u5358\u4F4D\u3092\u3042\u306E\u5358\u4F4D\u3068\u4EA4\u63DB\u3057\u3066\u6B32\u3057\u3044\u3001\u5225\u306B\u30EC\u30FC\u30C81:1\u3067\u306A\u304F\u3066\u3082",
  "id" : 238460372334555138,
  "created_at" : "2012-08-23 02:19:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238459867696873472",
  "text" : "\u3057\u304B\u3057\u3001\u306A\u3093\u3067\u3042\u308C\u512A\u306A\u3093\u3060\u308D\u2026\u76F8\u5BFE\u8A55\u4FA1\u306B\u3057\u3066\u3082\u3084\u308A\u904E\u304E\u306A\u6C17\u304C",
  "id" : 238459867696873472,
  "created_at" : "2012-08-23 02:17:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238459722829811713",
  "text" : "\u5272\u3068\u30DB\u30AF\u30DB\u30AF\u3057\u3066\u3044\u305F",
  "id" : 238459722829811713,
  "created_at" : "2012-08-23 02:16:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238458769053462528",
  "text" : "\u8A9E\u5B66\u3082\u62BC\u3055\u3048\u3089\u308C\u3066\u305F\u3002\u4F4E\u7A7A\u98DB\u884C\u3060\u304C\u3002",
  "id" : 238458769053462528,
  "created_at" : "2012-08-23 02:12:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238458354358431745",
  "text" : "\u307E\u305FB\u7FA4\u304C\u5897\u3048\u305F",
  "id" : 238458354358431745,
  "created_at" : "2012-08-23 02:11:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/PkbDzWa6",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/14?prefill=sigmapsi",
      "display_url" : "gohantabeyo.com\/nani\/14?prefil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "238451322851045377",
  "text" : "\u3042\u3044\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/PkbDzWa6",
  "id" : 238451322851045377,
  "created_at" : "2012-08-23 01:43:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238306596340506624",
  "text" : "\u7D0D\u8C46\u306F\u85C1\u306B\u7D0D\u307E\u3063\u3066\u308B\u3063\u3066\u306E\u306F\u308F\u304B\u3089\u306A\u3044\u3067\u3082\u306A\u3044\u304C\uFF0C\u8C46\u8150\u304C\u8150\u3063\u3066\u308B\u3063\u3066\u306E\u306F\u8A8D\u3081\u3089\u308C\u306A\u3044\u305C",
  "id" : 238306596340506624,
  "created_at" : "2012-08-22 16:08:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238306491076075520",
  "text" : "\u8C46\u8150\u304C\u8150\u3063\u305F\u3089\u305D\u308C\u300C\u3061\u308A\u3068\u3066\u3061\u3093\u300D\u3058\u3083\u3093\u306D\uFF0E",
  "id" : 238306491076075520,
  "created_at" : "2012-08-22 16:07:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238306445723054082",
  "text" : "\u8C46\u8150\u3068\u7D0D\u8C46\u3063\u3066\u9006\u3058\u3083\u306A\u304B\u308D\u3046\u304B\uFF0E\u8C46\u8150\u3063\u3066\u8150\u3063\u3066\u306A\u3044\u3057\uFF0C\u7D0D\u8C46\u3063\u3066\u7D0D\u307E\u3063\u3066\u306A\u3044\u3088\u306D\uFF0E\u3069\u3053\u304B\u3067\u5165\u308C\u9055\u3044\u304C\u8D77\u304D\u3066\u3044\u308B\u306B\u9055\u3044\u306A\u3044\uFF0E",
  "id" : 238306445723054082,
  "created_at" : "2012-08-22 16:07:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238304123425001472",
  "text" : "\u3042\u3063\u3068\u3046\u3066\u304D\u306F\u3064\u307F\u307F\u3067\u3042\u308B",
  "id" : 238304123425001472,
  "created_at" : "2012-08-22 15:58:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238304083486863361",
  "text" : "\u3048\uFF0C\u95A2\u897F\u306B\u306F\u3072\u3084\u3080\u304E\u306E\u6587\u5316\u306A\u3044\u306E\u304B\u2026",
  "id" : 238304083486863361,
  "created_at" : "2012-08-22 15:58:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238300321359732736",
  "text" : "\u51B7\u9EA6\u30FC\u6885\u5E72\u3057\u30FC",
  "id" : 238300321359732736,
  "created_at" : "2012-08-22 15:43:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238296728711880704",
  "text" : "\u306A\u3093\u304B\u98DF\u3079\u3088\u3046\uFF0E\u5727\u5012\u7684\u7A7A\u8179\uFF0E",
  "id" : 238296728711880704,
  "created_at" : "2012-08-22 15:29:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238296504329187329",
  "text" : "\u4E45\u3005\u306E\u30C4\u30A4\u30FC\u30C8\u304C\u3053\u308C\u3067\u3042\u308B",
  "id" : 238296504329187329,
  "created_at" : "2012-08-22 15:28:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238296422280204289",
  "text" : "\u30D5\u30A7\u30EB\u30DE\u30FC\u300E\u4FFA\u306E\u5B9A\u7406\u306E\u8A3C\u660E\u304B\uFF1F\u6B32\u3057\u3051\u308A\u3083\u304F\u308C\u3066\u3084\u308B\uFF0E\u63A2\u305B\uFF01\u307E\u3053\u3068\u306B\u9A5A\u304F\u3079\u304D\u8A3C\u660E\u306F\u305D\u3053\u306B\u304A\u3044\u3066\u304D\u305F\uFF01\u300F",
  "id" : 238296422280204289,
  "created_at" : "2012-08-22 15:27:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237881876117864448",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 237881876117864448,
  "created_at" : "2012-08-21 12:00:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237765444226936833",
  "geo" : { },
  "id_str" : "237767258435362816",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u3044\u3064\u307E\u3067\u3042\u3063\u3061\u306B\u3044\u308B\u306E\uFF1F",
  "id" : 237767258435362816,
  "in_reply_to_status_id" : 237765444226936833,
  "created_at" : "2012-08-21 04:25:06 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237765251737714688",
  "geo" : { },
  "id_str" : "237765396449611777",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u3058\u3083\u3042\u307E\u305F\u5F8C\u65E5\u3067\u2026",
  "id" : 237765396449611777,
  "in_reply_to_status_id" : 237765251737714688,
  "created_at" : "2012-08-21 04:17:42 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 0, 12 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237592710427578368",
  "geo" : { },
  "id_str" : "237765321958772736",
  "in_reply_to_user_id" : 295467216,
  "text" : "@hymathlogic \u3059\u307F\u307E\u305B\u3093\u3001\u3042\u30682.3\u65E5\u3067\u4ED5\u4E0A\u3052\u307E\u3059\u2026",
  "id" : 237765321958772736,
  "in_reply_to_status_id" : 237592710427578368,
  "created_at" : "2012-08-21 04:17:24 +0000",
  "in_reply_to_screen_name" : "hymathlogic",
  "in_reply_to_user_id_str" : "295467216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237762322179960834",
  "geo" : { },
  "id_str" : "237765208024690688",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku 23\u6642\u524D\u304F\u3089\u3044",
  "id" : 237765208024690688,
  "in_reply_to_status_id" : 237762322179960834,
  "created_at" : "2012-08-21 04:16:57 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237592221111685120",
  "geo" : { },
  "id_str" : "237762144039493632",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u591C\u8FD4\u3057\u306B\u884C\u3063\u305F\u3089\u3044\u308B\uFF1F",
  "id" : 237762144039493632,
  "in_reply_to_status_id" : 237592221111685120,
  "created_at" : "2012-08-21 04:04:47 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237554806791745536",
  "geo" : { },
  "id_str" : "237592048612569088",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u4F55\u6642\u306B\u3069\u306E\u304F\u3089\u3044\uFF1F",
  "id" : 237592048612569088,
  "in_reply_to_status_id" : 237554806791745536,
  "created_at" : "2012-08-20 16:48:53 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237507194474606592",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u73FE\u5730\u5411\u304B\u3046\u304B",
  "id" : 237507194474606592,
  "created_at" : "2012-08-20 11:11:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237506690071789568",
  "text" : "\u8AB0\u304B\u6687\u306A\u4EBA\u3044\u307E\u305B\u3093\u304B\u306D\u3047",
  "id" : 237506690071789568,
  "created_at" : "2012-08-20 11:09:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237506663119216640",
  "text" : "\u3093\u30FC\u306A\u3093\u3067\u4EAC\u90FD\u5E30\u3063\u3066\u304D\u3066\u3059\u3050\u9762\u5B50\u63A2\u3057\u3066\u308B\u3093\u3060\u308D\u3046\u4FFA\u306F\u2026",
  "id" : 237506663119216640,
  "created_at" : "2012-08-20 11:09:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237448929933942784",
  "text" : "\u3046\u3068\u3046\u3068",
  "id" : 237448929933942784,
  "created_at" : "2012-08-20 07:20:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237446766058950656",
  "text" : "\u4E2D\u306E\u4EBA\u306F\u9055\u3063\u305F\u3068\u3044\u3046\u30AA\u30C1",
  "id" : 237446766058950656,
  "created_at" : "2012-08-20 07:11:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237445940716380161",
  "text" : "\u3053\u3053\u307E\u3067\u304D\u3066\u7720\u6C17\u3068\u304B",
  "id" : 237445940716380161,
  "created_at" : "2012-08-20 07:08:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237444206539444224",
  "text" : "\u305D\u3057\u3066\u8352\u3076\u308B\u30A4\u30F3\u30D0\u30FC\u30B9",
  "id" : 237444206539444224,
  "created_at" : "2012-08-20 07:01:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237444052298133504",
  "text" : "\u3053\u308C\u306F\u2026",
  "id" : 237444052298133504,
  "created_at" : "2012-08-20 07:00:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237443260438687745",
  "text" : "\uFF11\uFF16:\uFF12\uFF18\u4EAC\u90FD\u7740",
  "id" : 237443260438687745,
  "created_at" : "2012-08-20 06:57:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237442426120335360",
  "text" : "\u3046\u3089\u3084\u3059\u3057\u3063\u3066\u304A\u3082\u3066\u3084\u3059\u3057\u306E\u88CF\u4EBA\u683C\u3063\u3066\u8A8D\u8B58\u3067\u3044\u3044\u3088\u306D\uFF1F",
  "id" : 237442426120335360,
  "created_at" : "2012-08-20 06:54:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237441787495591936",
  "text" : "\u540D\u53E4\u5C4B",
  "id" : 237441787495591936,
  "created_at" : "2012-08-20 06:51:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237441779257987072",
  "text" : "\u3069\u3046\u3082\u540C\u3058\u540D\u5B57\u306E\u3084\u3064\u304C\u4E8C\u4EBA\u3044\u3066\u3001\u7247\u65B9\u3092\u6307\u3059\u305F\u3081\u306B\u300C\u30AD\u30E2\u3044\u65B9\u300D\u3063\u3066\u8A00\u3063\u305F\u3089\u300C\u3069\u3063\u3061\u3082\u30AD\u30E2\u30A4\u3058\u3083\u3093\u300D\u3068\u8FD4\u3059\u3068\u3044\u3046\u5727\u5012\u7684\u4F1A\u8A71\u3092\u805E\u3044\u305F\u3053\u3068\u304C\u3042\u308B",
  "id" : 237441779257987072,
  "created_at" : "2012-08-20 06:51:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237439647343603712",
  "text" : "\u3082\u3046\u3061\u3087\u3044\u3067\u540D\u53E4\u5C4B17\u6642\u306B\u306F\u304A\u5BB6\u306B\u3064\u3051\u308B\u304B\u3057\u3089\u30FC",
  "id" : 237439647343603712,
  "created_at" : "2012-08-20 06:43:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237439441629761537",
  "text" : "\u4ED9\u53F0\u3067\u306F\u30A2\u30D2\u30EB\u3068\u9D28\u306E\u30B3\u30A4\u30F3\u30ED\u30C3\u30AB\u30FC\u3092\u773A\u3081\u305F(^^)(^^)(^^)",
  "id" : 237439441629761537,
  "created_at" : "2012-08-20 06:42:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237436490311946241",
  "text" : "\u3086\u30FC\u3068\u3093\u307C\u3063\u3068\u306B\u3088\u304F\u6301\u3063\u3066\u3044\u304B\u308C\u308B\u306A\u3041",
  "id" : 237436490311946241,
  "created_at" : "2012-08-20 06:30:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237435759928438784",
  "text" : "\u307C\u304F\u306E\u307B\u3051\u3093\u3057\u3087\u3046\u306F\u3001\u30C6\u30EC\u30D5\u30A9\u30F3\u30AB\u30FC\u30C9\u304F\u3089\u3044\u306E\u3046\u3059\u3055\u306E\u3001\u3055\u3044\u3075\u306B\u306F\u3044\u308B\u307B\u3051\u3093\u3057\u3087\u3046\u3067\u3059\u3002",
  "id" : 237435759928438784,
  "created_at" : "2012-08-20 06:27:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237435215658762240",
  "text" : "\u305D\u3044\u3061\u3083\u3061\u3087\u3063\u3068\u8ABF\u5B50\u60AA\u3044\u3001\u30A2\u30D7\u30C7\u5F85\u3061",
  "id" : 237435215658762240,
  "created_at" : "2012-08-20 06:25:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237434870161346560",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u3001\u89AA\u306E\u8077\u696D\u306B\u3088\u3063\u3066\u306A\u3093\u3057\u3085\u308B\u3044\u304B\u3042\u308B\u3093\u3060\u3063\u3051\u304B",
  "id" : 237434870161346560,
  "created_at" : "2012-08-20 06:24:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237434560575574016",
  "geo" : { },
  "id_str" : "237434801932623874",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u50D5\u306E\u77E5\u3063\u3066\u308B\u4FDD\u967A\u8A3C\u3068\u306F\u304B\u306A\u308A\u9055\u3046\u53EF\u80FD\u6027\u304C",
  "id" : 237434801932623874,
  "in_reply_to_status_id" : 237434560575574016,
  "created_at" : "2012-08-20 06:24:02 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237434690129231872",
  "text" : "\u7A81\u7136\u306E\u5730\u5E95\u6E56",
  "id" : 237434690129231872,
  "created_at" : "2012-08-20 06:23:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237434399921147904",
  "text" : "\u3048\u3001\u4FDD\u967A\u8A3C\u3063\u3066\u8CA1\u5E03\u306B\u3044\u308C\u3068\u304F\u3082\u3093\u3058\u3083\u306A\u3044\u306E",
  "id" : 237434399921147904,
  "created_at" : "2012-08-20 06:22:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237434011805417472",
  "geo" : { },
  "id_str" : "237434169314119680",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u8CA1\u5E03\u306B\u5E38\u99D0\u3055\u305B\u307E\u3057\u3087\u3046\u3088\u3046",
  "id" : 237434169314119680,
  "in_reply_to_status_id" : 237434011805417472,
  "created_at" : "2012-08-20 06:21:31 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237433105437298688",
  "geo" : { },
  "id_str" : "237433523626184704",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u3067\u3001\u898B\u3064\u304B\u3063\u305F\u3093\u3067\u3059\uFF1F",
  "id" : 237433523626184704,
  "in_reply_to_status_id" : 237433105437298688,
  "created_at" : "2012-08-20 06:18:57 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237433408094101504",
  "text" : "\u30C1\u30C1\u30AB\u30AB\u6E56\u3082\u5730\u4E0B\u5316\u3057\u3088\u3046",
  "id" : 237433408094101504,
  "created_at" : "2012-08-20 06:18:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237433205194633217",
  "text" : "\u3044\u3084\u3001\u6614\u306E\u62C5\u4EFB\u304C\u305F\u3044\u3057\u305F\u3053\u3068\u306E\u306A\u3044\u602A\u6211\u304B\u4F55\u304B\u3067\u5165\u9662\u3057\u305F\u6642\u306B\u300C\u8A03\u5831 \u25EF\u25EF\u5148\u751F\u5165\u9662\u300D\u3063\u3066mixi()\u3067\u7686\u306B\u6559\u3048\u3066\u304F\u308C\u305F\u3089\u3057\u3044",
  "id" : 237433205194633217,
  "created_at" : "2012-08-20 06:17:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237432402606178305",
  "geo" : { },
  "id_str" : "237432778071891968",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u3042\u306A\u305F\u304C\u90E8\u5C4B\u3092\u3072\u3063\u304F\u308A\u8FD4\u3059\u6642\u3001\u90E8\u5C4B\u3082\u307E\u305F\u3001\u3042\u306A\u305F\u3092\u3072\u3063\u304F\u308A\u8FD4\u3059\u306E\u3067\u3042\u308B",
  "id" : 237432778071891968,
  "in_reply_to_status_id" : 237432402606178305,
  "created_at" : "2012-08-20 06:16:00 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237432480116928512",
  "text" : "\u8A03\u5831\u3068\u3044\u3046\u8A00\u8449\u3092\u9593\u9055\u3063\u3066\u4F7F\u3063\u305F\u9AD8\u6821\u540C\u5B66\u5E74\u306E\u30E1\u30F3\u30D8\u30E9\u304A\u3070\u304B\u3055\u3093\u306E\u305B\u3044\u3067\u3001\u8A03\u5831\u3063\u3066\u8A00\u8449\u304C\u3059\u3063\u304B\u308A\u30CD\u30BF\u30EF\u30FC\u30C9\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F\u3002",
  "id" : 237432480116928512,
  "created_at" : "2012-08-20 06:14:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237431092301402113",
  "text" : "RT @akeopyaa: \u30AC\u30EA\u30AC\u30EA\u541B\u9AA8\u5473\u3000\u30AB\u30EB\u30B7\u30A6\u30E0\u5165\u308A\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237430837329666048",
    "text" : "\u30AC\u30EA\u30AC\u30EA\u541B\u9AA8\u5473\u3000\u30AB\u30EB\u30B7\u30A6\u30E0\u5165\u308A\uFF01",
    "id" : 237430837329666048,
    "created_at" : "2012-08-20 06:08:17 +0000",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 237431092301402113,
  "created_at" : "2012-08-20 06:09:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237431074085539840",
  "text" : "\u30AB\u30EB\u30B7\u30A6\u30E0\u541B\u3000\u30AC\u30EA\u30AC\u30EA\uFF01",
  "id" : 237431074085539840,
  "created_at" : "2012-08-20 06:09:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237430137250013184",
  "geo" : { },
  "id_str" : "237430556697174017",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u306F\u3044",
  "id" : 237430556697174017,
  "in_reply_to_status_id" : 237430137250013184,
  "created_at" : "2012-08-20 06:07:10 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237430034682486784",
  "text" : "\u547C\u3070\u308C\u3066\u3001\u306A\u3044",
  "id" : 237430034682486784,
  "created_at" : "2012-08-20 06:05:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237429638383669248",
  "text" : "\u6D77\u304C\u898B\u3048\u305F\u3001\u3088\u3046\u306A\u2026",
  "id" : 237429638383669248,
  "created_at" : "2012-08-20 06:03:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237428939130277888",
  "text" : "@reflexio \u3042\u3001\u306F\u3044",
  "id" : 237428939130277888,
  "created_at" : "2012-08-20 06:00:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237427772715311104",
  "text" : "@reflexio \u3044\u3064\u307E\u3067\u3044\u308B\u306E\uFF1F",
  "id" : 237427772715311104,
  "created_at" : "2012-08-20 05:56:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237424360741289988",
  "text" : "@reflexio \u307E\u3058\u3067",
  "id" : 237424360741289988,
  "created_at" : "2012-08-20 05:42:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237423830207963136",
  "text" : "\u60AA\u610F\u3042\u308B\u53CB\u4EBA\u306E\u305B\u3044\u3067\u59B9\u5C5E\u6027\u6301\u3061\u306F\u6E6F\u5A46\u5A46\u3092\u611B\u3067\u306A\u3051\u308C\u3070\u3044\u3051\u306A\u3044\u3068\u3044\u3046\u5F37\u8FEB\u89B3\u5FF5\u304C",
  "id" : 237423830207963136,
  "created_at" : "2012-08-20 05:40:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237423496853069824",
  "text" : "\u6CBB\u3063\u305F",
  "id" : 237423496853069824,
  "created_at" : "2012-08-20 05:39:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237423227452928000",
  "text" : "\u96FB\u6CE2\u304C\u60AA\u304F\u306A\u3063\u305F\u6A21\u69D8",
  "id" : 237423227452928000,
  "created_at" : "2012-08-20 05:38:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237422441998209025",
  "text" : "\u5ECA\u4E0B\u306E\u8001\u5316",
  "id" : 237422441998209025,
  "created_at" : "2012-08-20 05:34:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237422389082861568",
  "text" : "\u30C4\u30FC\u30AB\u30FC\u304C\u901A\u904E",
  "id" : 237422389082861568,
  "created_at" : "2012-08-20 05:34:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237422159381790720",
  "geo" : { },
  "id_str" : "237422272300871680",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u901A\u904E\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042",
  "id" : 237422272300871680,
  "in_reply_to_status_id" : 237422159381790720,
  "created_at" : "2012-08-20 05:34:15 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237421700436856833",
  "text" : "\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
  "id" : 237421700436856833,
  "created_at" : "2012-08-20 05:31:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237421636335333377",
  "text" : "@reflexio \u30B7\u30E3\u30C3\u30AF\u306E\u59B9\u306B\u8B1D\u308B\u3002\u308A\u3063\u304F\u3093\u8A98\u3048\u3070\u3063\u3066\u304A\u306B\u3044\u3061\u3083\u3093\u306B\u63D0\u6848\u3057\u3061\u3083\u3063\u3066\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F\u3001\u3063\u3066\u3002",
  "id" : 237421636335333377,
  "created_at" : "2012-08-20 05:31:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237421126991626241",
  "text" : "\u65E7\u6A2A\u6D5C\u306B\u8B1D\u308C\u3063",
  "id" : 237421126991626241,
  "created_at" : "2012-08-20 05:29:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237421075267473408",
  "text" : "\u65B0\u6A2A\u6D5C",
  "id" : 237421075267473408,
  "created_at" : "2012-08-20 05:29:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237420076347826177",
  "text" : "\u982D\u6253\u3061\u3001\u982D\u6483\u3061",
  "id" : 237420076347826177,
  "created_at" : "2012-08-20 05:25:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237419932323823616",
  "text" : "\u9811\u5F35\u3063\u3066\u6B32\u3057\u3044",
  "id" : 237419932323823616,
  "created_at" : "2012-08-20 05:24:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237419884923998208",
  "text" : "RT @akeopyaa: \u3048\u3093\u3069\u6C0F\u304C\u6687\u3057\u306A\u3044\u3088\u3046\u306B\u306A\u306B\u304B\u9762\u767D\u3044\u4E8B\u3092\u545F\u3053\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237419798567469056",
    "text" : "\u3048\u3093\u3069\u6C0F\u304C\u6687\u3057\u306A\u3044\u3088\u3046\u306B\u306A\u306B\u304B\u9762\u767D\u3044\u4E8B\u3092\u545F\u3053\u3046",
    "id" : 237419798567469056,
    "created_at" : "2012-08-20 05:24:25 +0000",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 237419884923998208,
  "created_at" : "2012-08-20 05:24:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237419854288801792",
  "text" : "\u65B0\u5E79\u7DDA\u3067\u610F\u8B58\u9AD8\u3044\u3075\u308A\u3057\u3066\u308B\u3051\u3069\u3084\u3063\u3066\u308B\u306E\u306F\u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u3059\u3054\u3081\u3093\u306A\u3055\u3044",
  "id" : 237419854288801792,
  "created_at" : "2012-08-20 05:24:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237419527451852800",
  "text" : "\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u3092\u773A\u3081\u3064\u3064\u306A\u306B\u3057\u3088\u3046\u304B\u306A\u30FC",
  "id" : 237419527451852800,
  "created_at" : "2012-08-20 05:23:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237419269363740673",
  "text" : "\u65B0\u5E79\u7DDA\u3075\u3075\u3075",
  "id" : 237419269363740673,
  "created_at" : "2012-08-20 05:22:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237411995341713409",
  "text" : "\u6B21\u306F\u6771\u4EAC",
  "id" : 237411995341713409,
  "created_at" : "2012-08-20 04:53:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237411828735545344",
  "text" : "\u3042\u30FC\u3001\u964D\u308A\u3061\u3083\u3063\u305F\u3002\u697D\u3057\u304B\u3063\u305F\u306E\u306B\u3002",
  "id" : 237411828735545344,
  "created_at" : "2012-08-20 04:52:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237411775044276227",
  "text" : "\u305F\u307E\u306B\u52D5\u7269\u306E\u52D5\u753B\u306E\u8A71\u306F\u3059\u308B\u304C",
  "id" : 237411775044276227,
  "created_at" : "2012-08-20 04:52:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237411709344698369",
  "text" : "\u30CB\u30B3\u52D5\u306E\u8A71\u3067\u76DB\u308A\u4E0A\u304C\u308B\u306E\u306F\u3001\u3061\u3087\u3063\u3068\u3042\u308C\u304B\u3082\u306A\u3001\u307E\u3058\u3067\u3002",
  "id" : 237411709344698369,
  "created_at" : "2012-08-20 04:52:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237411245207212032",
  "text" : "\u3044\u3084\u3001\u5FC3\u5730\u60AA\u3044\u306E\u304B\uFF1F\u3044\u3084\u3001\u5FC3\u5730\u60AA\u3055\u304C\u5FC3\u5730\u826F\u3044\u306E\u304B\uFF1F",
  "id" : 237411245207212032,
  "created_at" : "2012-08-20 04:50:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237411113791283201",
  "text" : "\u7537\u5973\u306E\u6E29\u5EA6\u5DEE\u304C\u5FC3\u5730\u826F\u3044",
  "id" : 237411113791283201,
  "created_at" : "2012-08-20 04:49:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237410741236404224",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u5B9F\u5BB6\u306E\u51B7\u8535\u5EAB\u306B\u5BDD\u304B\u305B\u305F\u307E\u307E\u3060\u306A\u2026",
  "id" : 237410741236404224,
  "created_at" : "2012-08-20 04:48:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237410548076126208",
  "text" : "\u5E30\u7701",
  "id" : 237410548076126208,
  "created_at" : "2012-08-20 04:47:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237410540983566336",
  "text" : "\u98DF\u3079\u904E\u304E\u305F\u306A\u30FC\u3001\u3057\u3070\u3089\u304F\u98DF\u4E8B\u306F\u8CEA\u7D20\u306B\u3057\u3088\u3046\u3002\u898F\u5236\u304B\u3089\u5E30\u308B\u5EA6\u306B\u601D\u3063\u3066\u3044\u308B",
  "id" : 237410540983566336,
  "created_at" : "2012-08-20 04:47:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237410173197639680",
  "text" : "@ayuretti \u4FFA\u306F\u304B\u306A\u308A\u697D\u3057\u3093\u3067\u308B\u304C\u3001\u306D\u3047",
  "id" : 237410173197639680,
  "created_at" : "2012-08-20 04:46:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237409795173392384",
  "text" : "\u5973\u306E\u5B50\u7D50\u69CB\u53EF\u611B\u3044\u306E\u306B",
  "id" : 237409795173392384,
  "created_at" : "2012-08-20 04:44:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237409680413032448",
  "text" : "\u7537\u306E\u5B50\u306F\u697D\u3057\u305D\u3046\u3060\u304C\u30FC\u2026",
  "id" : 237409680413032448,
  "created_at" : "2012-08-20 04:44:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237409595302236162",
  "text" : "(\u3053\u3046\u3044\u3046\u306E\u306F\u4ED6\u4EBA\u306E\u3075\u308A\u307F\u3066\u6211\u304C\u3075\u308A\u30CA\u30F3\u30C8\u30AB)",
  "id" : 237409595302236162,
  "created_at" : "2012-08-20 04:43:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237409391886864384",
  "text" : "\u5973\u306E\u5B50\u30DE\u30B8\u9811\u5F35\u3063\u3066\u308B",
  "id" : 237409391886864384,
  "created_at" : "2012-08-20 04:43:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237408716608118784",
  "text" : "\u5973\u306E\u5B50\u9811\u5F35\u3063\u3066\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u3057\u3066\u3066\u30A2\u30EC",
  "id" : 237408716608118784,
  "created_at" : "2012-08-20 04:40:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237408566028402689",
  "text" : "\u9593\u3082\u306A\u304F\u65B0\u5BBF",
  "id" : 237408566028402689,
  "created_at" : "2012-08-20 04:39:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237408472591904769",
  "text" : "\u30CB\u30B3\u52D5\u30016V\u30E1\u30BF\u30E2\u30F3\u7B49\u306E\u8A71\u984C",
  "id" : 237408472591904769,
  "created_at" : "2012-08-20 04:39:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237407357989179392",
  "text" : "\u30DD\u30B1\u30E2\u30F3\u5EC3\u4EBA\u77E5\u8B58\u3092\u5973\u306E\u5B50\u306B\u6559\u3048\u308B\u30DE\u30F3\u306E\u96A3\u306B\u5EA7\u3063\u3066\u3044\u308B",
  "id" : 237407357989179392,
  "created_at" : "2012-08-20 04:34:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237406893600038915",
  "text" : "\u5E30\u308B\u305E\uFF5E",
  "id" : 237406893600038915,
  "created_at" : "2012-08-20 04:33:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237401888755159040",
  "text" : "\u3044\u3084\u3001\u7F8E\u5473\u3057\u304B\u3063\u305F\u3057\u3054\u99B3\u8D70\u306B\u306A\u3063\u305F\u304B\u3089\u98DF\u3079\u3055\u305B\u3066\u3044\u305F\u3060\u3044\u305F\u3001\u306E\u3060\u3051\u308C\u3069",
  "id" : 237401888755159040,
  "created_at" : "2012-08-20 04:13:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237401766830956544",
  "text" : "\u89AA\u621A\u30684\u4EBA\u524D\u983C\u3093\u3067\u30B7\u30A7\u30A2\u3057\u305F\u3051\u3069\u305F\u3076\u30932\u4EBA\u524D\u5F37\u98DF\u3079\u3055\u305B\u3089\u308C\u3066\u308B",
  "id" : 237401766830956544,
  "created_at" : "2012-08-20 04:12:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/rmD8UjtN",
      "expanded_url" : "http:\/\/4sq.com\/PpWt9W",
      "display_url" : "4sq.com\/PpWt9W"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.703509, 139.57555422 ]
  },
  "id_str" : "237401557312876546",
  "text" : "\u98DF\u3079\u904E\u304E\u305F (@ \u7AF9\u7210\u5C71\u623F) http:\/\/t.co\/rmD8UjtN",
  "id" : 237401557312876546,
  "created_at" : "2012-08-20 04:11:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237358797977440256",
  "text" : "\u8D85\u719F\u306F\u7F8E\u5473\u3057\u3044",
  "id" : 237358797977440256,
  "created_at" : "2012-08-20 01:22:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "indices" : [ 3, 16 ],
      "id_str" : "310067164",
      "id" : 310067164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237358742226759680",
  "text" : "RT @_yamadachan_: \u30D9\u30B9\u30C8\u30B9\u30EA\u30FC\u306E\u7B2C\uFF11\u4F4D\uFF01Pasco\u306E\u8D85\u719F\u3055\u3093\uFF01\u4ECA\u65E5\u306F\u884C\u304F\u5148\u3005\u3067\u6CE8\u76EE\u3092\u6D74\u3073\u305D\u3046\uFF01\u4EBA\u6C17\u8005\u3060\u306D\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237358179418247168",
    "text" : "\u30D9\u30B9\u30C8\u30B9\u30EA\u30FC\u306E\u7B2C\uFF11\u4F4D\uFF01Pasco\u306E\u8D85\u719F\u3055\u3093\uFF01\u4ECA\u65E5\u306F\u884C\u304F\u5148\u3005\u3067\u6CE8\u76EE\u3092\u6D74\u3073\u305D\u3046\uFF01\u4EBA\u6C17\u8005\u3060\u306D\uFF01",
    "id" : 237358179418247168,
    "created_at" : "2012-08-20 01:19:34 +0000",
    "user" : {
      "name" : "\u98DF\u30D1\u30F3\u5C11\u5973 \u3084\u307E\u3060\u3061\u3083\u3093",
      "screen_name" : "_yamadachan_",
      "protected" : false,
      "id_str" : "310067164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585053686205775873\/EygeOjja_normal.jpg",
      "id" : 310067164,
      "verified" : false
    }
  },
  "id" : 237358742226759680,
  "created_at" : "2012-08-20 01:21:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237358639252393985",
  "text" : "\u3082\u3046\u9175\u7D20\u304C\u3042\u3093\u307E\u308A\u306A\u3044\u3093\u3060\u306A\u30FC\u3001\u5C0F\u3055\u3044\u6642\u306F\u3044\u304F\u3089\u98F2\u3093\u3067\u3082\u5E73\u6C17\u3060\u3063\u305F\u304C",
  "id" : 237358639252393985,
  "created_at" : "2012-08-20 01:21:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237358535846006784",
  "text" : "\u671D\u725B\u4E73\u98F2\u3093\u3060\u3089\u304A\u8179\u3044\u305F\u3044",
  "id" : 237358535846006784,
  "created_at" : "2012-08-20 01:20:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u867B\u30CE\u30FC\u30DE\u30EB",
      "screen_name" : "ayaka1111",
      "indices" : [ 3, 13 ],
      "id_str" : "104431876",
      "id" : 104431876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237358167737118721",
  "text" : "RT @ayaka1111: ( ^o^)\u30C8\u30F3\u30AB\u30C4\u3046\u3081\u3048\u3048\uFF57\uFF57\uFF57\uFF57 \u3000 ( \u02D8\u2296\u02D8) \u3002o(\u5F85\u3066\u3088\u3001\u306A\u3093\u3067\u5FC5\u305A\u5343\u5207\u308A\u30AD\u30E3\u30D9\u30C4\u304C\u4E00\u7DD2\u306A\u3093\u3060\uFF1F) \u3000 |\u5185\u95A3\u5E9C| \u2517(\u260B\uFF40 )\u2513\u4E09 \u3000 ( \u25E0\u203F\u25E0 )\u261B\u541B\u304C\u77E5\u308B\u5FC5\u8981\u306F\u306A\u3044\u2026\u60AA\u3044\u304C\u8A18\u61B6\u3092\u6D88\u3055\u305B\u3066\u3082\u3089\u3046 \u3000 \u2582\u2585\u2587\u2588\u2593\u2592\u2591(\u2019\u03C9\u2019) ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237352925112971264",
    "text" : "( ^o^)\u30C8\u30F3\u30AB\u30C4\u3046\u3081\u3048\u3048\uFF57\uFF57\uFF57\uFF57 \u3000 ( \u02D8\u2296\u02D8) \u3002o(\u5F85\u3066\u3088\u3001\u306A\u3093\u3067\u5FC5\u305A\u5343\u5207\u308A\u30AD\u30E3\u30D9\u30C4\u304C\u4E00\u7DD2\u306A\u3093\u3060\uFF1F) \u3000 |\u5185\u95A3\u5E9C| \u2517(\u260B\uFF40 )\u2513\u4E09 \u3000 ( \u25E0\u203F\u25E0 )\u261B\u541B\u304C\u77E5\u308B\u5FC5\u8981\u306F\u306A\u3044\u2026\u60AA\u3044\u304C\u8A18\u61B6\u3092\u6D88\u3055\u305B\u3066\u3082\u3089\u3046 \u3000 \u2582\u2585\u2587\u2588\u2593\u2592\u2591(\u2019\u03C9\u2019)\u2591\u2592\u2593\u2588\u2587\u2585\u2582\u3046\u308F\u3042\u3042\u3042\u3042\u3042\u3042",
    "id" : 237352925112971264,
    "created_at" : "2012-08-20 00:58:41 +0000",
    "user" : {
      "name" : "\u867B\u30CE\u30FC\u30DE\u30EB",
      "screen_name" : "ayaka1111",
      "protected" : false,
      "id_str" : "104431876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606505047757758464\/GnxN4kCH_normal.jpg",
      "id" : 104431876,
      "verified" : false
    }
  },
  "id" : 237358167737118721,
  "created_at" : "2012-08-20 01:19:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237190861459443712",
  "text" : "\u8CE2\u8005\u6C0F\u4F53\u8ABF\u60AA\u3044\u306E\u304B\u2026\u304A\u5927\u4E8B\u306B\u306A\u3055\u3063\u3066\u304F\u3060\u3055\u3044\u306A",
  "id" : 237190861459443712,
  "created_at" : "2012-08-19 14:14:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237157129318977536",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 237157129318977536,
  "created_at" : "2012-08-19 12:00:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237137802549145600",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u3059\u307F\u307E\u305B\u3093\u3001\u307E\u3060\u5B9F\u5BB6\u306B\u3044\u308B\u306E\u3067\u4F1A\u8B70\u6B20\u5E2D\u3067\u304A\u9858\u3044\u3057\u307E\u3059\u2026",
  "id" : 237137802549145600,
  "created_at" : "2012-08-19 10:43:52 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237108994349600768",
  "text" : "\u517C\u306D\u3066\u3088\u308A\u540D\u3092\u805E\u3044\u3066\u3044\u305F\u3086\u3067\u5375\u306E\u3072\u3068\u3092\u30D5\u30A9\u30ED\u30EF\u30FC\u3057\u305F",
  "id" : 237108994349600768,
  "created_at" : "2012-08-19 08:49:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237107190505304064",
  "text" : "\u6216\u308B\u30AD\u30F3\u30B0\u8AAD\u3093\u3060\u3002\u78BA\u304B\u306B\u5272\u3068\u7570\u8272\u3002",
  "id" : 237107190505304064,
  "created_at" : "2012-08-19 08:42:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237079815822376962",
  "text" : "\u3053\u306E\u65E5\u5DEE\u3057\u306E\u4E2D\u534A\u8896\u3067\u51FA\u3066\u304D\u3066\u3057\u307E\u3063\u305F\u3002",
  "id" : 237079815822376962,
  "created_at" : "2012-08-19 06:53:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/O6wBnvm7",
      "expanded_url" : "http:\/\/4sq.com\/PvctH5",
      "display_url" : "4sq.com\/PvctH5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.69211589, 139.58913889 ]
  },
  "id_str" : "237079182839001089",
  "text" : "\u75C5\u9662\u304B\u3089\u306E\u30FC (@ \u4E09\u9DF9\u53F0\u99C5 (Mitakadai Sta.)) http:\/\/t.co\/O6wBnvm7",
  "id" : 237079182839001089,
  "created_at" : "2012-08-19 06:50:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237033973920972802",
  "text" : "\u660E\u502B\u9928\u306B\u3042\u3063\u305F\u672C\u3059\u3054\u304F\u7DBA\u9E97\u3060\u3063\u305F\u3057\u3001\u307B\u3068\u3093\u3069\u65B0\u54C1\u3060\u306A\u30FC\u3001\u8CB7\u3046\u306E\u3042\u308A\u3060\u306A\u30FC\u3001\u3068\u601D\u3063\u3066\u3044\u305F\u3089\u5024\u6BB5\u3082\u65B0\u54C1\u3060\u3063\u305F\u304B\u3089\u5727\u5012\u7684(^^)(^^)(^^)(^^)(^^)",
  "id" : 237033973920972802,
  "created_at" : "2012-08-19 03:51:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236817381853388800",
  "text" : "\u30D0\u30A4\u30C8\u5148\u306B\u306F\u8FF7\u60D1\u304B\u3051\u308B\u306A\u3041\u3002\u4ED5\u65B9\u306A\u3044\u3068\u3044\u3048\u3070\u4ED5\u65B9\u306A\u3044\u304C\u3002",
  "id" : 236817381853388800,
  "created_at" : "2012-08-18 13:30:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236817337171468289",
  "text" : "\u89AA\u304C\u5165\u9662\u3059\u308B\u30CF\u30D7\u30CB\u30F3\u30B0\u3002\u4E00\u65E5\u5E30\u308B\u306E\u9045\u3089\u305B\u307E\u3059\u3002",
  "id" : 236817337171468289,
  "created_at" : "2012-08-18 13:30:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236794691809591296",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 236794691809591296,
  "created_at" : "2012-08-18 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/DIXJcD8e",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=coxff2006",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236785905040510976",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/DIXJcD8e",
  "id" : 236785905040510976,
  "created_at" : "2012-08-18 11:25:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236746802307678209",
  "text" : "\u5F7C\u3089\u304B\u3089\u3057\u305F\u3089\u6BD2\u306F\u3053\u3063\u3061\u304B",
  "id" : 236746802307678209,
  "created_at" : "2012-08-18 08:50:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236746716764844033",
  "text" : "\u30AB\u30C3\u30D7\u30EB\u304C\u591A\u3044\u3068\u76EE\u306E\u6BD2",
  "id" : 236746716764844033,
  "created_at" : "2012-08-18 08:49:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/4BcQBG08",
      "expanded_url" : "http:\/\/twitpic.com\/aksv2r",
      "display_url" : "twitpic.com\/aksv2r"
    } ]
  },
  "geo" : { },
  "id_str" : "236713545016946688",
  "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u30EA\u30E0\u30FC\u30D6\u30D6\u30ED\u30C3\u30AF FRB http:\/\/t.co\/4BcQBG08",
  "id" : 236713545016946688,
  "created_at" : "2012-08-18 06:38:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236696468612861952",
  "text" : "\u7D50\u5C40\u660E\u502B\u9928\u3067\u306F\u8CB7\u3044\u7269\u305B\u305A",
  "id" : 236696468612861952,
  "created_at" : "2012-08-18 05:30:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/groAwN1v",
      "expanded_url" : "http:\/\/4sq.com\/PkYQe1",
      "display_url" : "4sq.com\/PkYQe1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.6961488482, 139.7594833374 ]
  },
  "id_str" : "236696333224923136",
  "text" : "I'm at \u30B4\u30FC\u30B4\u30FC\u30AB\u30EC\u30FC \u795E\u4FDD\u753A\u30B9\u30BF\u30B8\u30A2\u30E0 (\u5343\u4EE3\u7530\u533A, \u6771\u4EAC\u90FD) http:\/\/t.co\/groAwN1v",
  "id" : 236696333224923136,
  "created_at" : "2012-08-18 05:29:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/WmjRJlS1",
      "expanded_url" : "http:\/\/4sq.com\/PkVPu5",
      "display_url" : "4sq.com\/PkVPu5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.6957872524, 139.7587189078 ]
  },
  "id_str" : "236689940761673728",
  "text" : "\u3046\u308F\u30FC (@ \u660E\u502B\u9928\u66F8\u5E97) http:\/\/t.co\/WmjRJlS1",
  "id" : 236689940761673728,
  "created_at" : "2012-08-18 05:04:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 40, 51 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/bYoBzlRC",
      "expanded_url" : "http:\/\/4sq.com\/PkVPdR",
      "display_url" : "4sq.com\/PkVPdR"
    } ]
  },
  "geo" : { },
  "id_str" : "236689940149305344",
  "text" : "I just unlocked the \"Bookworm\" badge on @foursquare for checking in at bookstores and libraries! Long live print! http:\/\/t.co\/bYoBzlRC",
  "id" : 236689940149305344,
  "created_at" : "2012-08-18 05:04:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/dChQ9Hrl",
      "expanded_url" : "http:\/\/4sq.com\/NuLtVA",
      "display_url" : "4sq.com\/NuLtVA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.6959658722, 139.758067131 ]
  },
  "id_str" : "236687142213001217",
  "text" : "\u3046\u304A\u3042\u30FC\u30FC\u30FC\u30FC (@ \u795E\u4FDD\u753A\u99C5 (Jimbocho Sta.)) http:\/\/t.co\/dChQ9Hrl",
  "id" : 236687142213001217,
  "created_at" : "2012-08-18 04:53:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/W75lzZUE",
      "expanded_url" : "http:\/\/4sq.com\/MD8toi",
      "display_url" : "4sq.com\/MD8toi"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.6778846792, 139.5677490887 ]
  },
  "id_str" : "236655489428107265",
  "text" : "I'm at \u674F\u6797\u5927\u5B66\u533B\u5B66\u90E8\u4ED8\u5C5E\u75C5\u9662 (\u4E09\u9DF9\u5E02, \u6771\u4EAC\u90FD) w\/ 3 others http:\/\/t.co\/W75lzZUE",
  "id" : 236655489428107265,
  "created_at" : "2012-08-18 02:47:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236482121538097153",
  "geo" : { },
  "id_str" : "236483532577439744",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u884C\u3063\u3066\u898B\u308B\u30FC\uFF01\u3042\u308A\u304C\u3068\u3046\uFF01",
  "id" : 236483532577439744,
  "in_reply_to_status_id" : 236482121538097153,
  "created_at" : "2012-08-17 15:24:02 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236480034167214080",
  "geo" : { },
  "id_str" : "236481593382944768",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u305F\u3044\u713C\u304D\u3060\u3051kwsk\uFF01",
  "id" : 236481593382944768,
  "in_reply_to_status_id" : 236480034167214080,
  "created_at" : "2012-08-17 15:16:20 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236473902958784513",
  "text" : "\u305F\u3060\u7236\u89AA\u304C\u30C1\u30E7\u30B3\u306E\u7BB1\u3068\u4F3C\u305F\u3088\u3046\u306A\u7BB1\u3067\u30DC\u30FC\u30EB\u30DA\u30F3\u3092\u9001\u3063\u3066\u304F\u308C\u305F\u305B\u3044\u3067\u3057\u3070\u3089\u304F\u30DC\u30FC\u30EB\u30DA\u30F3\u3092\u51CD\u3089\u305B\u3061\u3083\u3063\u305F\u3053\u3068\u304C\u3042\u3063\u305F\u306A\u3041",
  "id" : 236473902958784513,
  "created_at" : "2012-08-17 14:45:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236473699425976321",
  "text" : "\u30C1\u30E7\u30B3\u306F\u57FA\u672C\u51B7\u51CD\u5EAB",
  "id" : 236473699425976321,
  "created_at" : "2012-08-17 14:44:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u30FC\u306B\u3083\u3093\uFF20R-univ.Math",
      "screen_name" : "ilovegalois",
      "indices" : [ 0, 12 ],
      "id_str" : "258362326",
      "id" : 258362326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236473342721396736",
  "geo" : { },
  "id_str" : "236473588683796480",
  "in_reply_to_user_id" : 258362326,
  "text" : "@ilovegalois \u3042\u30FC\u30AF\u30C3\u30AD\u30FC\u90E8\u5206\u304C\u826F\u304F\u306A\u3044\u304B\u3082\u3067\u3059\u306D\u3002\u677F\u30C1\u30E7\u30B3\u5168\u822C\u306F\u30AA\u30B9\u30B9\u30E1\u3067\u3059\u306E\u3067\u3081\u3052\u305A\u306B\u3084\u3063\u3066\u898B\u3066\u304F\u3060\u3055\u3044\u306A",
  "id" : 236473588683796480,
  "in_reply_to_status_id" : 236473342721396736,
  "created_at" : "2012-08-17 14:44:31 +0000",
  "in_reply_to_screen_name" : "ilovegalois",
  "in_reply_to_user_id_str" : "258362326",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u30FC\u306B\u3083\u3093\uFF20R-univ.Math",
      "screen_name" : "ilovegalois",
      "indices" : [ 0, 12 ],
      "id_str" : "258362326",
      "id" : 258362326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236472463167459329",
  "geo" : { },
  "id_str" : "236473177142865921",
  "in_reply_to_user_id" : 258362326,
  "text" : "@ilovegalois \u4F55\u306E\u30C1\u30E7\u30B3\u51CD\u3089\u305B\u305F\u3093\u3067\u3059\uFF1F",
  "id" : 236473177142865921,
  "in_reply_to_status_id" : 236472463167459329,
  "created_at" : "2012-08-17 14:42:53 +0000",
  "in_reply_to_screen_name" : "ilovegalois",
  "in_reply_to_user_id_str" : "258362326",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236473065700225026",
  "text" : "\u8863\u7396\u3055\u3093\u5370\u8C61\u5909\u308F\u3063\u305F\u306A",
  "id" : 236473065700225026,
  "created_at" : "2012-08-17 14:42:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5FB3\u4E95\u9752\u7A7A\uFF20\u51FA\u6483\u5F85\u6A5F\u4E2D",
      "screen_name" : "tokui_sorangley",
      "indices" : [ 3, 19 ],
      "id_str" : "261196483",
      "id" : 261196483
    }, {
      "name" : "\u5C0F\u5C71\u525B\u5FD7",
      "screen_name" : "_higetter_",
      "indices" : [ 41, 52 ],
      "id_str" : "168947108",
      "id" : 168947108
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lv100317467",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "nicolive",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/XZqF0kjN",
      "expanded_url" : "http:\/\/nico.ms\/lv100317467",
      "display_url" : "nico.ms\/lv100317467"
    } ]
  },
  "geo" : { },
  "id_str" : "236472999119814657",
  "text" : "RT @tokui_sorangley: \u697D\u3057\u307F\u3059\u304E\u308B\uFF01\uFF01\u5168\u529B\u3067\u30B4\u30F3\u30B0\uFF01\uFF01 RT @_higetter_: \u3044\u3088\u3044\u3088\u660E\u65E5\u3067\u3059\uFF01\u7269\u51C4\u3044\u6226\u3044\u304C\u898B\u3089\u308C\u308B\u7B48\u306A\u306E\u3067\u662F\u975E\u30C1\u30A7\u30C3\u30AF\u3092\uFF01\uFF01\uFF01\n\u300E\u9EBB\u96C0\u6700\u5F37\u62262012\u300F\u8457\u540D\u4EBA\u4EE3\u8868\u6C7A\u5B9A\u6226\u30FB\u96F7\u795E\u7DE8  http:\/\/t.co\/XZqF0kjN  # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5C0F\u5C71\u525B\u5FD7",
        "screen_name" : "_higetter_",
        "indices" : [ 20, 31 ],
        "id_str" : "168947108",
        "id" : 168947108
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lv100317467",
        "indices" : [ 114, 126 ]
      }, {
        "text" : "nicolive",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/XZqF0kjN",
        "expanded_url" : "http:\/\/nico.ms\/lv100317467",
        "display_url" : "nico.ms\/lv100317467"
      } ]
    },
    "geo" : { },
    "id_str" : "236472904466972672",
    "text" : "\u697D\u3057\u307F\u3059\u304E\u308B\uFF01\uFF01\u5168\u529B\u3067\u30B4\u30F3\u30B0\uFF01\uFF01 RT @_higetter_: \u3044\u3088\u3044\u3088\u660E\u65E5\u3067\u3059\uFF01\u7269\u51C4\u3044\u6226\u3044\u304C\u898B\u3089\u308C\u308B\u7B48\u306A\u306E\u3067\u662F\u975E\u30C1\u30A7\u30C3\u30AF\u3092\uFF01\uFF01\uFF01\n\u300E\u9EBB\u96C0\u6700\u5F37\u62262012\u300F\u8457\u540D\u4EBA\u4EE3\u8868\u6C7A\u5B9A\u6226\u30FB\u96F7\u795E\u7DE8  http:\/\/t.co\/XZqF0kjN  #lv100317467  #nicolive",
    "id" : 236472904466972672,
    "created_at" : "2012-08-17 14:41:48 +0000",
    "user" : {
      "name" : "\u5FB3\u4E95\u9752\u7A7A\uFF20\u51FA\u6483\u5F85\u6A5F\u4E2D",
      "screen_name" : "tokui_sorangley",
      "protected" : false,
      "id_str" : "261196483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605534236968222720\/0b69w5dD_normal.jpg",
      "id" : 261196483,
      "verified" : false
    }
  },
  "id" : 236472999119814657,
  "created_at" : "2012-08-17 14:42:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u30FC\u306B\u3083\u3093\uFF20R-univ.Math",
      "screen_name" : "ilovegalois",
      "indices" : [ 0, 12 ],
      "id_str" : "258362326",
      "id" : 258362326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236472117527453696",
  "geo" : { },
  "id_str" : "236472270623752193",
  "in_reply_to_user_id" : 258362326,
  "text" : "@ilovegalois \u3048\u30FC\u30D1\u30AD\u3063\u3066\u611F\u3058\u304C\u7D50\u69CB\u597D\u304D\u306A\u3093\u3067\u3059\u304C\u2026",
  "id" : 236472270623752193,
  "in_reply_to_status_id" : 236472117527453696,
  "created_at" : "2012-08-17 14:39:17 +0000",
  "in_reply_to_screen_name" : "ilovegalois",
  "in_reply_to_user_id_str" : "258362326",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30E0\u30C8",
      "screen_name" : "turkey2410",
      "indices" : [ 0, 11 ],
      "id_str" : "763557104",
      "id" : 763557104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236464419419353088",
  "geo" : { },
  "id_str" : "236468633738543105",
  "in_reply_to_user_id" : 763557104,
  "text" : "@turkey2410 \u304A\u304B\u3048\u308A",
  "id" : 236468633738543105,
  "in_reply_to_status_id" : 236464419419353088,
  "created_at" : "2012-08-17 14:24:50 +0000",
  "in_reply_to_screen_name" : "turkey2410",
  "in_reply_to_user_id_str" : "763557104",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236466789142376448",
  "text" : "@reflexio \u53E4\u672C\u5C4B\u306A\u3069\u6563\u7B56",
  "id" : 236466789142376448,
  "created_at" : "2012-08-17 14:17:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236466111372210176",
  "text" : "\u660E\u65E5 @akeopyaa \u3068\u795E\u4FDD\u753A\u306B\u884C\u304F\u3053\u3068\u306B\u306A\u3063\u305F\u306E\u3067\u6771\u4EAC\u4ED8\u8FD1\u306E\u4EBA\u3067\u6765\u305F\u3044\u4EBA\u3044\u305F\u3089\u30EA\u30D7\u30E9\u30A4\u4E0B\u3055\u3044\u306A\u3001\u3042\u3068\u30AA\u30B9\u30B9\u30E1\u306E\u53E4\u672C\u5C4B\u306A\u3069\u3042\u308C\u3070\u6559\u3048\u3066\u304F\u308C\u308B\u3068\u559C\u3073\u307E\u3059",
  "id" : 236466111372210176,
  "created_at" : "2012-08-17 14:14:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236465587373633536",
  "text" : "\u30A2\u30B5\u30D2\u30B9\u30FC\u30D1\u30FC\u30C9\u30E9\u30A4\u306F\u305A\u308B\u3044",
  "id" : 236465587373633536,
  "created_at" : "2012-08-17 14:12:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u30FC\u3061\u3087",
      "screen_name" : "Uuutyo",
      "indices" : [ 3, 10 ],
      "id_str" : "360341547",
      "id" : 360341547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236465524140306433",
  "text" : "RT @Uuutyo: \u4FFA\u306F\u9AD8\u6821\u751F\u63A2\u5075\u3001\u5DE5\u85E4\u65B0\u4E00\u3002\u5E7C\u99B4\u67D3\u3067\u540C\u7D1A\u751F\u306E\u6BDB\u5229\u862D\u3068\u904A\u5712\u5730\u306B\u904A\u3073\u306B\u884C\u3063\u3066\u3001\u9ED2\u305A\u304F\u3081\u306E\u7537\u306E\u602A\u3057\u3052\u306A\u53D6\u308A\u5F15\u304D\u73FE\u5834\u3092\u76EE\u6483\u3057\u305F\u3002\u53D6\u308A\u5F15\u304D\u3092\u898B\u308B\u306E\u306B\u5922\u4E2D\u306B\u306A\u3063\u3066\u3044\u305F\u30AA\u30EC\u306F\u3001\u80CC\u5F8C\u304B\u3089\u8FD1\u4ED8\u3044\u3066\u6765\u308B\u3001\u3082\u3046\u4E00\u4EBA\u306E\u4EF2\u9593\u306B\u6C17\u4ED8\u304B\u306A\u304B\u3063\u305F\u3002\u30AA\u30EC\u304C\u305D\u306E\u7537\u306B\u98F2\u307E\u3055\u308C\u305F\u306E\u306F\uFF71\uFF7B\uFF8B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236454947863027712",
    "text" : "\u4FFA\u306F\u9AD8\u6821\u751F\u63A2\u5075\u3001\u5DE5\u85E4\u65B0\u4E00\u3002\u5E7C\u99B4\u67D3\u3067\u540C\u7D1A\u751F\u306E\u6BDB\u5229\u862D\u3068\u904A\u5712\u5730\u306B\u904A\u3073\u306B\u884C\u3063\u3066\u3001\u9ED2\u305A\u304F\u3081\u306E\u7537\u306E\u602A\u3057\u3052\u306A\u53D6\u308A\u5F15\u304D\u73FE\u5834\u3092\u76EE\u6483\u3057\u305F\u3002\u53D6\u308A\u5F15\u304D\u3092\u898B\u308B\u306E\u306B\u5922\u4E2D\u306B\u306A\u3063\u3066\u3044\u305F\u30AA\u30EC\u306F\u3001\u80CC\u5F8C\u304B\u3089\u8FD1\u4ED8\u3044\u3066\u6765\u308B\u3001\u3082\u3046\u4E00\u4EBA\u306E\u4EF2\u9593\u306B\u6C17\u4ED8\u304B\u306A\u304B\u3063\u305F\u3002\u30AA\u30EC\u304C\u305D\u306E\u7537\u306B\u98F2\u307E\u3055\u308C\u305F\u306E\u306F\uFF71\uFF7B\uFF8B\uFF68\uFF7D\uFF69\uFF8A\uFF9F\uFF67\uFF84\uFF9E\uFF69\uFF99\uFF67\uFF67\uFF67\uFF67\uFF67\uFF72",
    "id" : 236454947863027712,
    "created_at" : "2012-08-17 13:30:27 +0000",
    "user" : {
      "name" : "\u3086\u30FC\u3061\u3087",
      "screen_name" : "Uuutyo",
      "protected" : false,
      "id_str" : "360341547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/589584142259466240\/ePurB1O4_normal.png",
      "id" : 360341547,
      "verified" : false
    }
  },
  "id" : 236465524140306433,
  "created_at" : "2012-08-17 14:12:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236465226403430400",
  "text" : "\u4ECA\u307E\u3067\u3067\u3082\u6642\u6298\u5207\u308C\u308B\u3053\u3068\u304C\u3042\u308B\u3068\u3044\u3046\u306E\u306B\u2026\u30C4\u30A4\u30FC\u30C8\u8AAD\u307F\u8FBC\u307F\u304C\u7279\u306B\u2026",
  "id" : 236465226403430400,
  "created_at" : "2012-08-17 14:11:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236464948564353025",
  "text" : "\u3048\u30FCAPI\u6E1B\u308B\u306E\u56F0\u308B\u3093\u3060\u3051\u3069",
  "id" : 236464948564353025,
  "created_at" : "2012-08-17 14:10:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7DCA\u6025\u5730\u9707\u901F\u5831bot\uFF08\u03B1\uFF09",
      "screen_name" : "zishin3255_2",
      "indices" : [ 3, 16 ],
      "id_str" : "269270524",
      "id" : 269270524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/hn4smeh1",
      "expanded_url" : "http:\/\/mitsugogo.sakura.ne.jp\/wp\/archives\/297",
      "display_url" : "mitsugogo.sakura.ne.jp\/wp\/archives\/297"
    } ]
  },
  "geo" : { },
  "id_str" : "236464849104826368",
  "text" : "RT @zishin3255_2: \u3010\u91CD\u8981\u3011TwitterAPI\u4ED5\u69D8\u5909\u66F4\u306B\u3088\u308B\u3001\u30C4\u30A4\u30FC\u30C8\u56DE\u6570\u306E\u5909\u66F4\u306E\u304A\u77E5\u3089\u305B\u3000http:\/\/t.co\/hn4smeh1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/hn4smeh1",
        "expanded_url" : "http:\/\/mitsugogo.sakura.ne.jp\/wp\/archives\/297",
        "display_url" : "mitsugogo.sakura.ne.jp\/wp\/archives\/297"
      } ]
    },
    "geo" : { },
    "id_str" : "236463644353904640",
    "text" : "\u3010\u91CD\u8981\u3011TwitterAPI\u4ED5\u69D8\u5909\u66F4\u306B\u3088\u308B\u3001\u30C4\u30A4\u30FC\u30C8\u56DE\u6570\u306E\u5909\u66F4\u306E\u304A\u77E5\u3089\u305B\u3000http:\/\/t.co\/hn4smeh1",
    "id" : 236463644353904640,
    "created_at" : "2012-08-17 14:05:00 +0000",
    "user" : {
      "name" : "\u7DCA\u6025\u5730\u9707\u901F\u5831bot\uFF08\u03B1\uFF09",
      "screen_name" : "zishin3255_2",
      "protected" : false,
      "id_str" : "269270524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1887654197\/21_normal.jpg",
      "id" : 269270524,
      "verified" : false
    }
  },
  "id" : 236464849104826368,
  "created_at" : "2012-08-17 14:09:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u304BC\u30C9\u30A5\u30FC",
      "screen_name" : "hiroskii_mk2",
      "indices" : [ 0, 13 ],
      "id_str" : "247411674",
      "id" : 247411674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236464360065728512",
  "geo" : { },
  "id_str" : "236464464004780032",
  "in_reply_to_user_id" : 247411674,
  "text" : "@hiroskii_mk2 \u30DE\u30B8\u3067\u3059\u304B(\u305D\u308C\u3092\u78BA\u8A8D\u3057\u306B\u884C\u304F)",
  "id" : 236464464004780032,
  "in_reply_to_status_id" : 236464360065728512,
  "created_at" : "2012-08-17 14:08:16 +0000",
  "in_reply_to_screen_name" : "hiroskii_mk2",
  "in_reply_to_user_id_str" : "247411674",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236464201089032192",
  "text" : "\u660E\u502B\u9928\u306A\u308B\u3068\u3053\u308D\u306B\u884C\u3063\u3066\u898B\u305F\u3044",
  "id" : 236464201089032192,
  "created_at" : "2012-08-17 14:07:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236464106960465922",
  "text" : "\u304A\u663C\u904E\u304E\u304B\u3089\u5915\u65B9\u306B\u306A\u3089\u306A\u3044\u304F\u3089\u3044\u307E\u3067\u304B\u306A",
  "id" : 236464106960465922,
  "created_at" : "2012-08-17 14:06:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236464010516639745",
  "text" : "\u660E\u65E5 @akeopyaa \u3068\u795E\u4FDD\u753A\u306B\u884C\u304F\u3053\u3068\u306B\u306A\u3063\u305F\u306E\u3067\u6771\u4EAC\u4ED8\u8FD1\u306E\u4EBA\u3067\u6765\u305F\u3044\u4EBA\u3044\u305F\u3089\u30EA\u30D7\u30E9\u30A4\u4E0B\u3055\u3044\u306A\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 236464010516639745,
  "created_at" : "2012-08-17 14:06:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236462595543031808",
  "text" : "\u5727\u5012\u7684\u4E45\u3005\u306Bmixi\u30DC\u30A4\u30B9()\u3092\u4F7F\u3063\u305F",
  "id" : 236462595543031808,
  "created_at" : "2012-08-17 14:00:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236454291680919553",
  "geo" : { },
  "id_str" : "236454544350015489",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u305D\u3046\u3044\u3048\u3070\u305D\u3046\u3067\u3057\u305F",
  "id" : 236454544350015489,
  "in_reply_to_status_id" : 236454291680919553,
  "created_at" : "2012-08-17 13:28:51 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236452185871900674",
  "geo" : { },
  "id_str" : "236454031470501888",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori HN\u3068\u3057\u3066\u306F\u5727\u5012\u7684\u306B\u512A\u79C0",
  "id" : 236454031470501888,
  "in_reply_to_status_id" : 236452185871900674,
  "created_at" : "2012-08-17 13:26:48 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236453737470758912",
  "text" : "\u9AD8\u6821\u306E\u540C\u671F\u304B\u3089\u9AD8\u6821\u306E\u540C\u671F\u3092\u4F1D\u3063\u3066\u6355\u6349\u3057\u3066\u30EA\u30B9\u30C8\u306B\u653E\u308A\u8FBC\u3080\u904A\u3073\u304C\u697D\u3057\u3044",
  "id" : 236453737470758912,
  "created_at" : "2012-08-17 13:25:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236450036240764928",
  "geo" : { },
  "id_str" : "236450084403961859",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u305D\u308C\u306A",
  "id" : 236450084403961859,
  "in_reply_to_status_id" : 236450036240764928,
  "created_at" : "2012-08-17 13:11:07 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236449874084761601",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa mail\u3057\u305F",
  "id" : 236449874084761601,
  "created_at" : "2012-08-17 13:10:17 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3080\u308ABABEL",
      "screen_name" : "CKPOMHOCTb",
      "indices" : [ 0, 11 ],
      "id_str" : "190136474",
      "id" : 190136474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236440411550392320",
  "geo" : { },
  "id_str" : "236448601633607680",
  "in_reply_to_user_id" : 190136474,
  "text" : "@CKPOMHOCTb \u306F\u3044\u3001\u3068\u8A00\u3063\u3066\u3082\u3042\u3055\u3063\u3066\u306B\u306F\u5E30\u3063\u3066\u3057\u307E\u3044\u307E\u3059",
  "id" : 236448601633607680,
  "in_reply_to_status_id" : 236440411550392320,
  "created_at" : "2012-08-17 13:05:14 +0000",
  "in_reply_to_screen_name" : "CKPOMHOCTb",
  "in_reply_to_user_id_str" : "190136474",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236448043518545920",
  "text" : "\u5727\u5012\u7684\u304D\u305F\u304F\u3045\u30FC",
  "id" : 236448043518545920,
  "created_at" : "2012-08-17 13:03:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236439357513416704",
  "text" : "1%\u3042\u3042",
  "id" : 236439357513416704,
  "created_at" : "2012-08-17 12:28:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236439264383090688",
  "text" : "\u4ECA\u601D\u3048\u3070\u30B3\u30FC\u30D2\u30FC\u304F\u3089\u3044\u3054\u99B3\u8D70\u3059\u308C\u3070\u826F\u304B\u3063\u305F\u306A\u3041",
  "id" : 236439264383090688,
  "created_at" : "2012-08-17 12:28:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236438408166252546",
  "text" : "3%\u3057\u304B\u306A\u3044\u5145\u96FB",
  "id" : 236438408166252546,
  "created_at" : "2012-08-17 12:24:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 23, 32 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236438325928534016",
  "text" : "\u3044\u304D\u306A\u308A\u7A81\u767A\u30B5\u30B7\u30AA\u30D5\u3067\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F RT @pankashi: \u521D\u30AA\u30D5\u4F1A\u3060\u3063\u305F...\u30B3\u30DF\u30E5\u969C\u767A\u63EE\u3047",
  "id" : 236438325928534016,
  "created_at" : "2012-08-17 12:24:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236438089789227009",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u3055\u3093\u3068\u3064\u304B\u306E\u9593\u306E\u304A\u3057\u3083\u3079\u308A\u3092\u697D\u3057\u3093\u3060(^^)(^^)(^^)",
  "id" : 236438089789227009,
  "created_at" : "2012-08-17 12:23:28 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236428232105271297",
  "geo" : { },
  "id_str" : "236428683496267777",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u4E95\u306E\u982D\u516C\u5712\u306E\u30B9\u30BF\u30D0\u306B\u3044\u307E\u3059\u3088(\u30C1\u30E9\u30C3",
  "id" : 236428683496267777,
  "in_reply_to_status_id" : 236428232105271297,
  "created_at" : "2012-08-17 11:46:05 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236427950164164609",
  "text" : "\u307F\u3064\u304D\u3083\u3059\u3068\u304B\u82B1\u5CA1\u3055\u3093\u3068\u304B\u6771\u4EAC\u306B\u3044\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 236427950164164609,
  "created_at" : "2012-08-17 11:43:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236424099931496448",
  "text" : "\u4E00\u822C\u30AF\u30E9\u30B9\u30BF\u306E\u53CB\u4EBA\u306B\u30B7\u30E5\u30FC\u30C6\u30A3\u30F3\u30B0\u30B9\u30BF\u30FC\u3092\u52E7\u3081\u305F(^^)(^^)(^^)(^^)(^^)(^^)",
  "id" : 236424099931496448,
  "created_at" : "2012-08-17 11:27:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/P7o2Z30c",
      "expanded_url" : "http:\/\/4sq.com\/NIypwn",
      "display_url" : "4sq.com\/NIypwn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.7007775651, 139.5781847835 ]
  },
  "id_str" : "236422102054498304",
  "text" : "I'm at Starbucks Coffee \u4E95\u306E\u982D\u516C\u5712\u5E97 (\u6B66\u8535\u91CE\u5E02, \u6771\u4EAC\u90FD) http:\/\/t.co\/P7o2Z30c",
  "id" : 236422102054498304,
  "created_at" : "2012-08-17 11:19:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/hnOCbgda",
      "expanded_url" : "http:\/\/4sq.com\/PqdZKv",
      "display_url" : "4sq.com\/PqdZKv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.704023, 139.579074 ]
  },
  "id_str" : "236411580873576449",
  "text" : "I'm at HUB \u5409\u7965\u5BFA\u5E97 (\u6B66\u8535\u91CE\u5E02, \u6771\u4EAC\u90FD) http:\/\/t.co\/hnOCbgda",
  "id" : 236411580873576449,
  "created_at" : "2012-08-17 10:38:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236403111407804416",
  "text" : "\u300C\u30AD\u30FC\u30F3\u300D\u304C\u300C\u982D\u30C3\uFF01\u300D\u3066\u306A\u308B\uFF01",
  "id" : 236403111407804416,
  "created_at" : "2012-08-17 10:04:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/VKa0zy7F",
      "expanded_url" : "http:\/\/4sq.com\/RmsQJo",
      "display_url" : "4sq.com\/RmsQJo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.7050319579, 139.5804567119 ]
  },
  "id_str" : "236381365308899328",
  "text" : "I'm at \u65B0\u5BBF\u306D\u304E\u3057\u5409\u7965\u5BFA\u5E97 http:\/\/t.co\/VKa0zy7F",
  "id" : 236381365308899328,
  "created_at" : "2012-08-17 08:38:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/91ahfYav",
      "expanded_url" : "http:\/\/4sq.com\/NtNIwN",
      "display_url" : "4sq.com\/NtNIwN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.70220544, 139.58035303 ]
  },
  "id_str" : "236368412085989376",
  "text" : "\u3064\u3044\u305F (@ \u4EAC\u738B \u4E95\u306E\u982D\u7DDA \u5409\u7965\u5BFA\u99C5) http:\/\/t.co\/91ahfYav",
  "id" : 236368412085989376,
  "created_at" : "2012-08-17 07:46:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236368310307000320",
  "text" : "\u4ECA\u56DE\u306E\u5E30\u7701\u306F\u601D\u3063\u305F\u3088\u308A\u4E88\u5B9A\u304B\u3064\u304B\u3064\u3067\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u305F\u3061\u3068\u7D61\u3080\u6A5F\u4F1A\u306F\u3042\u3093\u307E\u308A\u306A\u3044\u306A\u3041\u3001\u6B8B\u5FF5",
  "id" : 236368310307000320,
  "created_at" : "2012-08-17 07:46:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/hBM3dmCI",
      "expanded_url" : "http:\/\/4sq.com\/P2flsz",
      "display_url" : "4sq.com\/P2flsz"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.6974993722, 139.5827043056 ]
  },
  "id_str" : "236367988478078976",
  "text" : "\u901A\u904E\u30A1\uFF01 (@ \u4E95\u306E\u982D\u516C\u5712\u99C5 (Inokashira-k\u014Den Sta.)) http:\/\/t.co\/hBM3dmCI",
  "id" : 236367988478078976,
  "created_at" : "2012-08-17 07:44:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/PmPT1NEx",
      "expanded_url" : "http:\/\/4sq.com\/NrViDy",
      "display_url" : "4sq.com\/NrViDy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.69211589, 139.58913889 ]
  },
  "id_str" : "236367852775546880",
  "text" : "I'm at \u4E09\u9DF9\u53F0\u99C5 (Mitakadai Sta.) (\u4E09\u9DF9\u5E02, \u6771\u4EAC\u90FD) http:\/\/t.co\/PmPT1NEx",
  "id" : 236367852775546880,
  "created_at" : "2012-08-17 07:44:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236131266561449984",
  "text" : "\u3086\u308B\u3084\u304B\u306B\u3001\u304A\u3060\u3084\u304B\u306B\u3001\u305F\u304A\u3084\u304B\u306B\u3001\u3042\u308F\u304F\u3001\u3046\u3059\u304F\u3001\u3055\u308A\u3052\u306A\u304F\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 236131266561449984,
  "created_at" : "2012-08-16 16:04:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/Z6OTSGA5",
      "expanded_url" : "http:\/\/matome.naver.jp\/odai\/2134481913892690601",
      "display_url" : "matome.naver.jp\/odai\/213448191\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236128084066177024",
  "text" : "\u3053\u308C\u884C\u304F\u304B\u3082\uFF1F http:\/\/t.co\/Z6OTSGA5",
  "id" : 236128084066177024,
  "created_at" : "2012-08-16 15:51:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236126800328146945",
  "text" : "\u30D2\u30E9\u30E1\u30AB\u30EC\u30A4\u306F\u9583\u304B\u306A\u3044",
  "id" : 236126800328146945,
  "created_at" : "2012-08-16 15:46:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236126327273558018",
  "text" : "\u30AF\n\u7530\n\u3001\u3001\u3001\u3001",
  "id" : 236126327273558018,
  "created_at" : "2012-08-16 15:44:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236126183073386496",
  "text" : "\u53F3\u9B5A\u5DE6\u9B5A",
  "id" : 236126183073386496,
  "created_at" : "2012-08-16 15:44:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236126110713257984",
  "text" : "\u53F3\u5F80\u5DE6\u9B5A",
  "id" : 236126110713257984,
  "created_at" : "2012-08-16 15:43:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236125348968923136",
  "text" : "\u3055\u304B\u306A\u3067\u9006\u64AB\u3067\u3059\u308B\u6700\u4E2D\u3067",
  "id" : 236125348968923136,
  "created_at" : "2012-08-16 15:40:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236125179774922752",
  "text" : "\u304A\u3055\u304B\u306A\u3092\u9006\u64AB\u3067",
  "id" : 236125179774922752,
  "created_at" : "2012-08-16 15:40:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236124596267520001",
  "text" : "\u307E\u3055\u304B\u306A\u2026",
  "id" : 236124596267520001,
  "created_at" : "2012-08-16 15:37:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236124235158925312",
  "geo" : { },
  "id_str" : "236124457742258176",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u3055\u304B\u306A",
  "id" : 236124457742258176,
  "in_reply_to_status_id" : 236124235158925312,
  "created_at" : "2012-08-16 15:37:12 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236121047383035904",
  "text" : "\u5727\u5012\u7684\u5E30\u5B85\u3057\u305F\u3051\u3069\u5BB6\u65CF\u307F\u3093\u306A\u5BDD\u3066\u308B\uFF01",
  "id" : 236121047383035904,
  "created_at" : "2012-08-16 15:23:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236069935711920128",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 236069935711920128,
  "created_at" : "2012-08-16 12:00:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/3M4wtO6H",
      "expanded_url" : "http:\/\/4sq.com\/Oyrx8k",
      "display_url" : "4sq.com\/Oyrx8k"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.703943, 139.580777 ]
  },
  "id_str" : "235954047520215040",
  "text" : "I'm at Starbucks Coffee \u5409\u7965\u5BFA\u99C5\u524D\u5E97 (\u6B66\u8535\u91CE\u5E02, \u6771\u4EAC\u90FD) http:\/\/t.co\/3M4wtO6H",
  "id" : 235954047520215040,
  "created_at" : "2012-08-16 04:20:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 0, 9 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235670905668374528",
  "geo" : { },
  "id_str" : "235671028691529728",
  "in_reply_to_user_id" : 126927392,
  "text" : "@hanaoka_ \u8D77\u304D\u305F\u305C\u2026.\u3080\u304F\u308A\u3068\u2026",
  "id" : 235671028691529728,
  "in_reply_to_status_id" : 235670905668374528,
  "created_at" : "2012-08-15 09:35:26 +0000",
  "in_reply_to_screen_name" : "hanaoka_",
  "in_reply_to_user_id_str" : "126927392",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 0, 10 ],
      "id_str" : "158645894",
      "id" : 158645894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235670299616632832",
  "geo" : { },
  "id_str" : "235670651619389440",
  "in_reply_to_user_id" : 158645894,
  "text" : "@eclair_15 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 235670651619389440,
  "in_reply_to_status_id" : 235670299616632832,
  "created_at" : "2012-08-15 09:33:56 +0000",
  "in_reply_to_screen_name" : "eclair_15",
  "in_reply_to_user_id_str" : "158645894",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235670511189913600",
  "text" : "\u307E\u3055\u306B\u3001\u5727\u5012\u7684\u3067\u3042\u308B",
  "id" : 235670511189913600,
  "created_at" : "2012-08-15 09:33:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235670461407711232",
  "text" : "RT @the_TQFT: \u9CF4\u304B\u306C\u306A\u3089\u3001\u3050\u3072\u3083\u307A\u308Dwwwww\u30D5\u30D2\u30D2www\u30DB\u30C8\u30C8\u30AE\u30B9(^^)(^^)(^^)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "235670174261456896",
    "text" : "\u9CF4\u304B\u306C\u306A\u3089\u3001\u3050\u3072\u3083\u307A\u308Dwwwww\u30D5\u30D2\u30D2www\u30DB\u30C8\u30C8\u30AE\u30B9(^^)(^^)(^^)",
    "id" : 235670174261456896,
    "created_at" : "2012-08-15 09:32:02 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 235670461407711232,
  "created_at" : "2012-08-15 09:33:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 41, 52 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/clVBnemF",
      "expanded_url" : "http:\/\/4sq.com\/RTmpMO",
      "display_url" : "4sq.com\/RTmpMO"
    } ]
  },
  "geo" : { },
  "id_str" : "235586579110981632",
  "text" : "I just unlocked the \"Superstar\" badge on @foursquare for checking in to fifty different places! http:\/\/t.co\/clVBnemF",
  "id" : 235586579110981632,
  "created_at" : "2012-08-15 03:59:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/e8QpvLvM",
      "expanded_url" : "http:\/\/4sq.com\/RTmr7w",
      "display_url" : "4sq.com\/RTmr7w"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.4322114308, 139.3991392851 ]
  },
  "id_str" : "235586579425529857",
  "text" : "I'm at \u6771\u540D\u9AD8\u901F\u9053\u8DEF EXPASA \u6D77\u8001\u540D \u4E0A\u308A (\u6D77\u8001\u540D\u5E02, \u795E\u5948\u5DDD\u770C) w\/ 4 others http:\/\/t.co\/e8QpvLvM",
  "id" : 235586579425529857,
  "created_at" : "2012-08-15 03:59:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/zHep9039",
      "expanded_url" : "http:\/\/4sq.com\/QA7txr",
      "display_url" : "4sq.com\/QA7txr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.240261, 139.14603016 ]
  },
  "id_str" : "235570145274261506",
  "text" : "I'm at \u3055\u304B\u306A\u306E\u98DF\u5802 \u3053\u3058\u307E http:\/\/t.co\/zHep9039",
  "id" : 235570145274261506,
  "created_at" : "2012-08-15 02:54:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235375738008780800",
  "geo" : { },
  "id_str" : "235375998533763072",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u305D\u3053\u307E\u3067\u306E\u610F\u56F3\u306F\u3042\u308A\u307E\u305B\u3093\u3001\u3068\u3048\u3093\u3069\u306F\u307E\u3093\u3056\u3089\u3067\u3082\u306A\u3055\u305D\u3046\u306A\u8868\u60C5\u3067\u3057\u308C\u3063\u3068\u30EA\u30D7\u30E9\u30A4\u3092\u8FD4\u3057\u307E\u3059\u3002",
  "id" : 235375998533763072,
  "in_reply_to_status_id" : 235375738008780800,
  "created_at" : "2012-08-14 14:03:05 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235375057914978306",
  "text" : "\u307E\u3041\u50D5\u3082\u4E0A\u624B\u3044\u306A\u3093\u3066\u53E3\u304C\u88C2\u3051\u3066\u3082\u8A00\u3048\u307E\u305B\u3093\u304C",
  "id" : 235375057914978306,
  "created_at" : "2012-08-14 13:59:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235374989816258561",
  "text" : "\u6771\u4EAC\u306E\u30D3\u30EA\u30E4\u30FC\u30C9\u306E\u304A\u5E97\u3067\u3001\u30AB\u30C3\u30D7\u30EB\u3067\u904A\u3073\u306B\u6765\u3066\u3044\u308B\u7537\u306E\u4EBA\u306E\u65B9\u304C(\u5BFE\u3057\u3066\u4E0A\u624B\u3067\u3082\u306A\u3044\u306E\u306B)\u3061\u3087\u3063\u3068\u30C9\u30E4\u9854\u3067\u7C8B\u3063\u3066\u308B\u7387\u306E\u9AD8\u3055\u306F\u7570\u5E38",
  "id" : 235374989816258561,
  "created_at" : "2012-08-14 13:59:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235373842665713664",
  "text" : "\u65E5\u672C\u8A9E\u306E\u30C1\u30E7\u30A4\u30B9\u304C\u4ECA\u3072\u3068\u3064",
  "id" : 235373842665713664,
  "created_at" : "2012-08-14 13:54:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235373373742526464",
  "text" : "\u6D74\u8863\u306B\u5973\u306E\u5B50\u3092\u57CB\u3081\u8FBC\u307F\u305F\u3044 \n\u2026\u57CB\u3081\u8FBC\u307F\u305F\u3044\uFF1F\uFF1F",
  "id" : 235373373742526464,
  "created_at" : "2012-08-14 13:52:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305B\u3064\u306A",
      "screen_name" : "seihosetuna",
      "indices" : [ 3, 15 ],
      "id_str" : "141997069",
      "id" : 141997069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235372953171288064",
  "text" : "RT @seihosetuna: \u5973\u306E\u5B50\u306B\u3001\u6D74\u8863\u7740\u305B\u305F\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "235372662799605760",
    "text" : "\u5973\u306E\u5B50\u306B\u3001\u6D74\u8863\u7740\u305B\u305F\u3044",
    "id" : 235372662799605760,
    "created_at" : "2012-08-14 13:49:50 +0000",
    "user" : {
      "name" : "\u305B\u3064\u306A",
      "screen_name" : "seihosetuna",
      "protected" : false,
      "id_str" : "141997069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1822446414\/image_normal.jpg",
      "id" : 141997069,
      "verified" : false
    }
  },
  "id" : 235372953171288064,
  "created_at" : "2012-08-14 13:50:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235372619413737472",
  "text" : "\uFF15\uFF10\uFF10\u3088\u308A\u5C0F\u3055\u306A\u30D1\u30C3\u30AF\u3067\u58F2\u3063\u3066\u308B\u3088\u306D\u3001\u751F\u30AF\u30EA\u30FC\u30E0\u3002",
  "id" : 235372619413737472,
  "created_at" : "2012-08-14 13:49:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u3086\u03C9\u30FC)\u3327@\u6843",
      "screen_name" : "yuton",
      "indices" : [ 0, 6 ],
      "id_str" : "15597112",
      "id" : 15597112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235371744079265793",
  "geo" : { },
  "id_str" : "235371864980066305",
  "in_reply_to_user_id" : 15597112,
  "text" : "@yuton \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 235371864980066305,
  "in_reply_to_status_id" : 235371744079265793,
  "created_at" : "2012-08-14 13:46:40 +0000",
  "in_reply_to_screen_name" : "yuton",
  "in_reply_to_user_id_str" : "15597112",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235371754535649282",
  "text" : "@yuki_migo \u30B9\u30FC\u30D1\u30FC\u306E\u4E73\u88FD\u54C1\u58F2\u308A\u5834\uFF1F",
  "id" : 235371754535649282,
  "created_at" : "2012-08-14 13:46:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235370830920568833",
  "text" : "\u660E\u65E5\u6771\u4EAC\u306B\u5E30\u308B",
  "id" : 235370830920568833,
  "created_at" : "2012-08-14 13:42:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235370005288611840",
  "text" : "\u30D5\u30D5\u30D5\u8776\u3063\u3066\u3061\u3087\u3046\u3061\u3087\u77E5\u3063\u3066\u308B\u4EBA\u3044\u307E\u3059\uFF1F",
  "id" : 235370005288611840,
  "created_at" : "2012-08-14 13:39:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235366156238733313",
  "text" : "@ayuretti \u3042\u307E\u308A\u4F7F\u3048\u306A\u3044\u5370\u8C61\u3002\u30A8\u30B9\u30D1\u30FC\u3060\u3063\u305F\u304B\u306A\u3002",
  "id" : 235366156238733313,
  "created_at" : "2012-08-14 13:23:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235365638741315584",
  "text" : "@ayuretti \u30D6\u30FC\u30D4\u30C3\u30AF\u3063\u3066\u30DD\u30B1\u30E2\u30F3\u3044\u305F\u3088\u306D",
  "id" : 235365638741315584,
  "created_at" : "2012-08-14 13:21:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235365491038900224",
  "text" : "@Malmach140 \u6D41\u77F3\u306B\u5E97\u54E1\u3055\u3093\u306F\u3057\u3066\u306A\u3044\u3068\u601D\u3044\u307E\u3059\u3088\u30FC",
  "id" : 235365491038900224,
  "created_at" : "2012-08-14 13:21:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235365204135919616",
  "text" : "@Malmach140 \u3042\u30FC\u3001\u304A\u5BA2\u3055\u3093\u306E\u306F\u306A\u3057\u3067\u3059",
  "id" : 235365204135919616,
  "created_at" : "2012-08-14 13:20:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30D6\u30FC\u30E1\u30E9\u30F3",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235364965920432128",
  "text" : "\u5973\u6027\u306E\u4F4E\u97F3\u306F\u3082\u3066\u306F\u3084\u3055\u308C\u308B\u304C\u7537\u6027\u306E\u9AD8\u97F3\u306F\u5F97\u3066\u3057\u3066\u30A2\u30EC\u3001 #\u30D6\u30FC\u30E1\u30E9\u30F3",
  "id" : 235364965920432128,
  "created_at" : "2012-08-14 13:19:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235364714484482049",
  "text" : "@Malmach140 \u8077\u7A2E\u306B\u3082\u4F9D\u308B\u3093\u3067\u3057\u3087\u3046\u304C\u3001\u3093\u30FC\u3001\u3084\u3063\u3071\u308A\u60AA\u5370\u8C61\u3067\u3059\u306D\u30FC",
  "id" : 235364714484482049,
  "created_at" : "2012-08-14 13:18:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235364410716209153",
  "text" : "\u5E97\u54E1\u3055\u3093\u306B\u3082\u3054\u98EF\u306B\u3082\u97F3\u697D\u306B\u3082\u5931\u793C\u2026\u3063\u3066\u306E\u306F\u5F8C\u4ED8\u3051\u304B\u306A\u3002\u81EA\u5206\u304C\u6C17\u306B\u98DF\u308F\u306A\u3044\u3060\u3051\u304B\u3002",
  "id" : 235364410716209153,
  "created_at" : "2012-08-14 13:17:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235364114355073024",
  "text" : "\u30EC\u30B8\u3067\u30A4\u30E4\u30DB\u30F3\u3057\u3066\u308B\u4EBA\u3082\u3042\u307E\u308A\u597D\u5370\u8C61\u3058\u3083\u306A\u3044\u3051\u308C\u3069\u3001\u3054\u98EF\u98DF\u3079\u3066\u308B\u3068\u304D\u306B\u30A4\u30E4\u30DB\u30F3\u3057\u3066\u308B\u4EBA\u3082\u304B\u306A\u308A\u5370\u8C61\u60AA\u3044",
  "id" : 235364114355073024,
  "created_at" : "2012-08-14 13:15:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235362907951607808",
  "text" : "\u8AB0\u3082\u7D0D\u5F97\u3057\u306A\u3044\u30AA\u30C1\u306E\u5C0F\u8AAC\u304C\u8AAD\u307F\u305F\u3044",
  "id" : 235362907951607808,
  "created_at" : "2012-08-14 13:11:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235362401921413121",
  "text" : "\u305D\u3046\u3064\u3044\u3044\u305D\u3046\u3060\u3051\u307E\u3060\u307E\u3060\u3057\u3063\u304F\u308A\u3053\u306A\u3044",
  "id" : 235362401921413121,
  "created_at" : "2012-08-14 13:09:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235361819240312832",
  "text" : "\u305D\u3057\u3066\u307F\u3093\u306A\u5E7C\u7A1A\u5712\u5150\u304B\u5C0F\u5B66\u6821\u4F4E\u5B66\u5E74\u3060\u3068\u601D\u3063\u3066\u305F\u3089\u3082\u3046\u4E2D\u5B66\u751F\u2026\u3068\u601D\u3063\u3066\u305F\u3089\u89AA\u621A\u306E\u304A\u3070\u3055\u3093\u306B\u306F\u3082\u3046\u6210\u4EBA\u304B\u30FC\u3068\u8A00\u308F\u308C\u305F.",
  "id" : 235361819240312832,
  "created_at" : "2012-08-14 13:06:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235361336916312065",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u3001\u8AB0\u304C\u4F55\u51E6\u306E\u5B50\u304B\u5206\u304B\u3089\u306A\u3044\u3088\u3001\u6B73\u3092\u53D6\u3063\u305F\u3088",
  "id" : 235361336916312065,
  "created_at" : "2012-08-14 13:04:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235361145001758720",
  "text" : "\u5468\u308A\u306E\u30DC\u30C9\u30B2\u304C\u30AC\u30C1\u3059\u304E\u308B\u3068\u3044\u3046\u8AAC\u3082",
  "id" : 235361145001758720,
  "created_at" : "2012-08-14 13:04:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235361052152446976",
  "text" : "\u89AA\u621A\u306E\u5B50\u4F9B\u9054\u3068UNO\u3084\u3063\u305F\u3051\u3069\u3001\u307F\u3093\u306A\u81EA\u5206\u306E\u90FD\u5408\u306E\u60AA\u3044\u8272\u306B\u5909\u308F\u308B\u3068\u9854\u306B\u51FA\u308B\u304B\u3089\u3001\u306A\u3093\u3068\u3044\u3046\u304B\u5727\u5012\u7684\u4E00\u822C\u30AF\u30E9\u30B9\u30BF",
  "id" : 235361052152446976,
  "created_at" : "2012-08-14 13:03:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235345169648590848",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 235345169648590848,
  "created_at" : "2012-08-14 12:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235287469266976768",
  "text" : "\u30E9\u30A4\u30C8\u7248\u306F\u4F5C\u308C\u308B\u30BF\u30B9\u30AF\u306B\u5236\u9650\u304C",
  "id" : 235287469266976768,
  "created_at" : "2012-08-14 08:11:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235287394910351360",
  "text" : "\u3086\u308B\u307C todo\u7BA1\u7406\u30A2\u30D7\u30EA",
  "id" : 235287394910351360,
  "created_at" : "2012-08-14 08:11:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/XRM6wG5w",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=masa2016",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235267397030903808",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/XRM6wG5w",
  "id" : 235267397030903808,
  "created_at" : "2012-08-14 06:51:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235262651435978752",
  "text" : "\u3060\u3044\u3088\u3093\u306F\u6E80\u305F\u3055\u306A\u3044\u3093\u3060\u3063\u305F",
  "id" : 235262651435978752,
  "created_at" : "2012-08-14 06:32:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235262441133580288",
  "text" : "\u3060\u3044\u306B\u304B\u3055\u3093\u3053\u3046\u308A\u3092\u307F\u305F\u3057\u3064\u3064\u3060\u3044\u3088\u3093\u304B\u3055\u3093\u3053\u3046\u308A\u3092\u307F\u305F\u3059\u7A7A\u9593",
  "id" : 235262441133580288,
  "created_at" : "2012-08-14 06:31:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235201647943491584",
  "text" : "\u3053\u308C\u3063\u3066\u30B5\u30D7\u30E9\u30A4\u306F\u3075\u3064\u30FC\u306E\u3057\u304B\u306A\u3044\u306E\u304B\u306A",
  "id" : 235201647943491584,
  "created_at" : "2012-08-14 02:30:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30B5\u30D2",
      "screen_name" : "asa_hit",
      "indices" : [ 3, 11 ],
      "id_str" : "12909092",
      "id" : 12909092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/Tu7NaDws",
      "expanded_url" : "http:\/\/aol.it\/OVhJkN",
      "display_url" : "aol.it\/OVhJkN"
    } ]
  },
  "geo" : { },
  "id_str" : "235201551336103936",
  "text" : "RT @asa_hit: \u30C9\u30DF\u30CB\u30AA\u30F3\u306E\u300C\u516C\u5F0F\u300DiOS\u30A2\u30D7\u30EA\u304C\u4ECA\u9031\u516C\u958B\u306B\u306A\u308B\u3088\u3046\u3067\u3059\u3002\u3064\u3044\u306B\u3002 Dominion officially coming to the App Store this week http:\/\/t.co\/Tu7NaDws via TUAW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/Tu7NaDws",
        "expanded_url" : "http:\/\/aol.it\/OVhJkN",
        "display_url" : "aol.it\/OVhJkN"
      } ]
    },
    "geo" : { },
    "id_str" : "235200281321816064",
    "text" : "\u30C9\u30DF\u30CB\u30AA\u30F3\u306E\u300C\u516C\u5F0F\u300DiOS\u30A2\u30D7\u30EA\u304C\u4ECA\u9031\u516C\u958B\u306B\u306A\u308B\u3088\u3046\u3067\u3059\u3002\u3064\u3044\u306B\u3002 Dominion officially coming to the App Store this week http:\/\/t.co\/Tu7NaDws via TUAW",
    "id" : 235200281321816064,
    "created_at" : "2012-08-14 02:24:51 +0000",
    "user" : {
      "name" : "\u30A2\u30B5\u30D2",
      "screen_name" : "asa_hit",
      "protected" : false,
      "id_str" : "12909092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603606421192581120\/hcjcUvHv_normal.png",
      "id" : 12909092,
      "verified" : false
    }
  },
  "id" : 235201551336103936,
  "created_at" : "2012-08-14 02:29:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306A\u3044\u3093\u305F\u3093",
      "screen_name" : "ninetan",
      "indices" : [ 13, 21 ],
      "id_str" : "57847957",
      "id" : 57847957
    }, {
      "name" : "\u30E6\u30FC\u30EA_\u975E\u516C\u5F0Fbot@ver 1.2",
      "screen_name" : "yuri_mathgirl",
      "indices" : [ 22, 36 ],
      "id_str" : "585531917",
      "id" : 585531917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235195811850514432",
  "text" : ".  @ispamgis @ninetan @yuri_mathgirl @Kyo_Hiiragi @9110alice \u304A\u3084\u3059\u307F\u3069\u3046\u3082\u3067\u3057\u305F\u30FC",
  "id" : 235195811850514432,
  "created_at" : "2012-08-14 02:07:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235195167282450432",
  "geo" : { },
  "id_str" : "235195389769314304",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u30D0\u30A4\u30C8\u304C\u7121\u3051\u308C\u3070\u305D\u3046\u3057\u305F\u3044\u3093\u3060\u3051\u3069\u306D\u3047",
  "id" : 235195389769314304,
  "in_reply_to_status_id" : 235195167282450432,
  "created_at" : "2012-08-14 02:05:25 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235194609892990976",
  "geo" : { },
  "id_str" : "235194967193182208",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u306D\u3047\u2026\u90E8\u5C4B\u306F3\u968E\u3060\u304B\u3089\u307E\u3041\u5927\u4E08\u592B\u3060\u308D\u3046\u3051\u308C\u3069",
  "id" : 235194967193182208,
  "in_reply_to_status_id" : 235194609892990976,
  "created_at" : "2012-08-14 02:03:44 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235194220137304065",
  "text" : "\u3044\u3044\u3066\u3093\u304D\u3067\u3059\u306D\u3047(\u3057\u308D\u3081",
  "id" : 235194220137304065,
  "created_at" : "2012-08-14 02:00:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234991171213086721",
  "text" : "\u3082\u3046\u5BDD\u3061\u3083\u3046(^^)(^^)(^^)\u304A\u3084\u3059\u307F\u306A\u3055\u3044(^^)(^^)(^^)(^^)(^^)",
  "id" : 234991171213086721,
  "created_at" : "2012-08-13 12:33:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234968939736727552",
  "text" : "\u5B9F\u5BB6\u306B\u306F\u3048\u3093\u3069\u304C\u6614\u66F8\u3044\u305F\u3068\u3055\u308C\u308B\u7D75\u304C\u3044\u304F\u3064\u304B\u6B8B\u3063\u3066\u3044\u308B\u304C\u2026",
  "id" : 234968939736727552,
  "created_at" : "2012-08-13 11:05:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234968794936795136",
  "text" : "@Malmach140 \u305D\u306E\u9803\u306E\u8A18\u61B6\u306F\u3069\u3053\u3078\u3084\u3089\u3001\u4ECA\u3067\u306F\u4F55\u306B\u3082\u66F8\u3051\u307E\u305B\u3093\u3088(^^)(^^)(^^)",
  "id" : 234968794936795136,
  "created_at" : "2012-08-13 11:05:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234968104084574208",
  "geo" : { },
  "id_str" : "234968509216591872",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 234968509216591872,
  "in_reply_to_status_id" : 234968104084574208,
  "created_at" : "2012-08-13 11:03:52 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234968458847203329",
  "text" : "\u7530\u820E\u306E\u56F3\u66F8\u9928\u306E\u9759\u3051\u3055\u3084\u3070\u3044",
  "id" : 234968458847203329,
  "created_at" : "2012-08-13 11:03:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234968409216020481",
  "text" : "\u660E\u65E5\u306F\u7530\u820E\u306E\u5727\u5012\u7684\u56F3\u66F8\u9928\u306B\u3053\u3082\u3063\u3066\u52C9\u5F37\u3059\u308B\u305E\u30FC.\u30ED\u30B0\u30CF\u30A6\u30B9.log-hauss.",
  "id" : 234968409216020481,
  "created_at" : "2012-08-13 11:03:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234967723925438464",
  "text" : "\u767D\u3068\u9ED2\u306F\u8272\u3058\u3083\u306A\u3044\u3063\u3066\u3061\u3044\u3061\u3083\u3044\u3068\u304D\u901A\u3063\u3066\u305F\u304A\u7D75\u304B\u304D\u6559\u5BA4\u3067\u7FD2\u3063\u305F\u3051\u3069\u3001\u3042\u308C\u306F\u5618\u3060\u306A\u3002",
  "id" : 234967723925438464,
  "created_at" : "2012-08-13 11:00:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234967086764527616",
  "text" : "\u3068\u306F\u3044\u3048\u5999\u306A\u304A\u5929\u6C17\u3002\u72D0\u306E\u5AC1\u5165\u308A\u3002",
  "id" : 234967086764527616,
  "created_at" : "2012-08-13 10:58:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234966980346662912",
  "text" : "\u9759\u5CA1\u306F\u6771\u4EAC\u3088\u308A\u6DBC\u3057\u3044\u3001\u6771\u4EAC\u306F\u4EAC\u90FD\u3088\u308A\u6DBC\u3057\u3044",
  "id" : 234966980346662912,
  "created_at" : "2012-08-13 10:57:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234966514724376576",
  "text" : "\u30A2\u30A4\u30B9\u98DF\u3079\u305F\u3089\u304A\u306A\u304B\u3044\u305F\u304F\u306A\u3063\u305F",
  "id" : 234966514724376576,
  "created_at" : "2012-08-13 10:55:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234966448370495488",
  "text" : "\u30A2\u30A4\u30B9\u307E\u3093\u3058\u3085\u3046\u3068\u3001\u3042\u305A\u304D\u30D0\u30FC\u8CB7\u3063\u3066\u5E30\u3063\u305F\u3089\u3001\u5C0F\u8C46\u304C\u88AB\u3063\u3066\u3057\u307E\u3063\u305F",
  "id" : 234966448370495488,
  "created_at" : "2012-08-13 10:55:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234966193235173378",
  "text" : "\u3075\u3064\u30FC\u306E\u3075\u304F\u3064\u30FC",
  "id" : 234966193235173378,
  "created_at" : "2012-08-13 10:54:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234818712958541824",
  "text" : "@i_horse \u304B\u306D\u3081\u306E\u3082\u306E\uFF1F",
  "id" : 234818712958541824,
  "created_at" : "2012-08-13 01:08:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234815040375644161",
  "text" : "@i_horse \u6614\u306F\u3042\u3063\u305F\u306E\u304B\u3082",
  "id" : 234815040375644161,
  "created_at" : "2012-08-13 00:54:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234814679724212224",
  "text" : "@i_horse \u3055\u3041\u2026",
  "id" : 234814679724212224,
  "created_at" : "2012-08-13 00:52:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234814466905219072",
  "text" : "@i_horse \u6539\u5909\u3068\u304B\u306A\u3044\u308F\u30FC",
  "id" : 234814466905219072,
  "created_at" : "2012-08-13 00:51:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234813699070758914",
  "text" : "\u5893\u5834\u306B\u30EA\u30B9\u304C\u3044\u308B\u7A0B\u5EA6\u306B\u306F\u7530\u820E",
  "id" : 234813699070758914,
  "created_at" : "2012-08-13 00:48:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234787109087625217",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 234787109087625217,
  "created_at" : "2012-08-12 23:03:03 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234620340767191040",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 234620340767191040,
  "created_at" : "2012-08-12 12:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234513796553646080",
  "text" : "\u30B7\u30F3\u30D0\u30B7",
  "id" : 234513796553646080,
  "created_at" : "2012-08-12 04:57:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/45aQCevl",
      "expanded_url" : "http:\/\/4sq.com\/Mprxq1",
      "display_url" : "4sq.com\/Mprxq1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.6661177442, 139.7562807798 ]
  },
  "id_str" : "234513635026825216",
  "text" : "\u5727\u5012\u7684\u30B5\u30A6\u30CA (@ \u30AA\u30A2\u30B7\u30B9\u30B5\u30A6\u30CA \u30A2\u30B9\u30C6\u30A3\u30EB) http:\/\/t.co\/45aQCevl",
  "id" : 234513635026825216,
  "created_at" : "2012-08-12 04:56:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234493987044605952",
  "text" : "\u4E45\u3005\u306B\u3042\u3063\u3055\u308A\u306E\u30E9\u30FC\u30E1\u30F3\u98DF\u3079\u305F\u4E94\u53CD\u7530",
  "id" : 234493987044605952,
  "created_at" : "2012-08-12 03:38:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234292136068124672",
  "text" : "\u5409\u7965\u5BFA \u5348\u5F8C\u304B\u3089 \u9EBB\u96C0 \u304F\u308B\u4EBA\u3044\u308B\uFF1F(\u3060\u3081\u3067\u3082\u3068\u3082\u3068)",
  "id" : 234292136068124672,
  "created_at" : "2012-08-11 14:16:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234287981979107328",
  "text" : "\u305D\u3046\u304B\u3001\u9EBB\u96C0\u306E\u30E1\u30F3\u30C4\u304C\u6355\u307E\u3089\u306A\u3044\u306E\u306F\u30B3\u30DF\u30B1\u3082\u3042\u308B\u304B\u3089\u304B\u306A",
  "id" : 234287981979107328,
  "created_at" : "2012-08-11 13:59:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234285501643898880",
  "text" : "\u6570\u306E\u5B50\u306F\u307E\u3060\u5B50\u4F9B\u3067\u3055\u3048\u306A\u3044\u306E\u306B\u5B50\u6301\u3061\uFF1F\uFF1F\uFF1F",
  "id" : 234285501643898880,
  "created_at" : "2012-08-11 13:49:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234285406349307905",
  "text" : "\u4ECA\u65E5\u306E\u30CF\u30A4\u30E9\u30A4\u30C8\n\u6BCD\u300C\u3053\u306E\u30B5\u30E9\u30C0\u306B\u5165\u3063\u3066\u308B\u5B50\u6301\u3061\u6570\u306E\u5B50\u307F\u305F\u3044\u306A\u306E\u306A\u3093\u3060\u308D\u3046\u306D\u300D\n\u4FFA,\u5F1F\u300C\u300D",
  "id" : 234285406349307905,
  "created_at" : "2012-08-11 13:49:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234257992105734145",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 234257992105734145,
  "created_at" : "2012-08-11 12:00:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233904734703083520",
  "geo" : { },
  "id_str" : "233908180453842944",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u3060\u3044\u305F\u3044\u4E00\u9031\u9593\u3061\u3087\u3063\u3068\u304F\u3089\u3044\u304B\u306A\u30FC",
  "id" : 233908180453842944,
  "in_reply_to_status_id" : 233904734703083520,
  "created_at" : "2012-08-10 12:50:30 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233884869485273088",
  "text" : "\u4E45\u3005\u306B\u3042\u3063\u305F\u53CB\u4EBA\u304B\u3089\u6EF2\u307F\u51FA\u308B\u4E00\u822C\u30AF\u30E9\u30B9\u30BF\u611F\u306B\u6253\u3061\u9707\u3048\u3066\u3044\u308B",
  "id" : 233884869485273088,
  "created_at" : "2012-08-10 11:17:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233880977708027905",
  "geo" : { },
  "id_str" : "233884464827207681",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u5E30\u3063\u3066\u6765\u3066\u307E\u3059\u3088\u30FC",
  "id" : 233884464827207681,
  "in_reply_to_status_id" : 233880977708027905,
  "created_at" : "2012-08-10 11:16:16 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233843184197844992",
  "text" : "\u5409\u7965\u5BFA\u30A1\uFF01",
  "id" : 233843184197844992,
  "created_at" : "2012-08-10 08:32:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233840806375604224",
  "text" : "\u4E95\u306E\u982D\u516C\u5712\u901A\u904E\u30A1\uFF01",
  "id" : 233840806375604224,
  "created_at" : "2012-08-10 08:22:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233840488761942017",
  "text" : "@reflexio \u3075\u3075\u3075",
  "id" : 233840488761942017,
  "created_at" : "2012-08-10 08:21:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 44, 55 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/wNJ1WWhM",
      "expanded_url" : "http:\/\/4sq.com\/TmJgP9",
      "display_url" : "4sq.com\/TmJgP9"
    } ]
  },
  "geo" : { },
  "id_str" : "233839849050882048",
  "text" : "I just unlocked the \"Trainspotter\" badge on @foursquare for checking in at trains and subway stations! http:\/\/t.co\/wNJ1WWhM",
  "id" : 233839849050882048,
  "created_at" : "2012-08-10 08:18:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/7CEUk83l",
      "expanded_url" : "http:\/\/4sq.com\/TmJjdY",
      "display_url" : "4sq.com\/TmJjdY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 35.69211589, 139.58913889 ]
  },
  "id_str" : "233839849319305216",
  "text" : "\u5727\u5012\u7684\u61D0\u304B\u3057\u307F (@ \u4E09\u9DF9\u53F0\u99C5 (Mitakadai Sta.)) http:\/\/t.co\/7CEUk83l",
  "id" : 233839849319305216,
  "created_at" : "2012-08-10 08:18:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233838052206841856",
  "text" : "\u5727\u5012\u7684\u5E30\u7701\u3048\u3093\u3069",
  "id" : 233838052206841856,
  "created_at" : "2012-08-10 08:11:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233572299637399552",
  "geo" : { },
  "id_str" : "233572480244146176",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u6642\u9593\u7684\u4F59\u88D5\u304C\u3042\u308C\u3070\u3044\u3044\u3051\u3069\u306A\u30FC\u3001\u307E\u3041\u4ECA\u56DE\u306F\u898B\u9001\u308A\u3063\u3066\u4E8B\u306B\u3057\u3068\u6765\u307E\u3059\u304B\u30FC",
  "id" : 233572480244146176,
  "in_reply_to_status_id" : 233572299637399552,
  "created_at" : "2012-08-09 14:36:33 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233561003886014465",
  "geo" : { },
  "id_str" : "233569264236384256",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u53C2\u52A0\u3057\u307E\u3059\u3088\u30FC",
  "id" : 233569264236384256,
  "in_reply_to_status_id" : 233561003886014465,
  "created_at" : "2012-08-09 14:23:46 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233556577624403968",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u8AB0\u3082\u6355\u307E\u3089\u306A\u3044\u3088\u3046\u3060\u3051\u3069\u3069\u3046\u3057\u3088\u3046\u304B\u30022\u4EBA\u3067\u305D\u308C\u305E\u308C\u666E\u901A\u306E\u30D1\u30D5\u30A7\u3092\u98DF\u3079\u306B\u884C\u304F\uFF1F",
  "id" : 233556577624403968,
  "created_at" : "2012-08-09 13:33:22 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233555408927723521",
  "text" : "TL\u306B\u51FA\u3066\u304F\u308B\u98DF\u3079\u7269\u306E\u5358\u8A9E\u3092\u546A\u3044\u306A\u304C\u3089\u4E2D\u91CE",
  "id" : 233555408927723521,
  "created_at" : "2012-08-09 13:28:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233553386614706177",
  "text" : "\u65B0\u5BBF\u3045\u30FC",
  "id" : 233553386614706177,
  "created_at" : "2012-08-09 13:20:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233553022188396544",
  "text" : "\u3088\u3064\u3084\u30FC\u30FC",
  "id" : 233553022188396544,
  "created_at" : "2012-08-09 13:19:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233552878353133569",
  "text" : "\u30EF\u30FC\u30D7\u6280\u8853\u306F\u3088",
  "id" : 233552878353133569,
  "created_at" : "2012-08-09 13:18:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233552711973478400",
  "geo" : { },
  "id_str" : "233552844035334145",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u4F55\u3082\u304B\u3082\u4E0D\u53EF\u80FD\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u30FC",
  "id" : 233552844035334145,
  "in_reply_to_status_id" : 233552711973478400,
  "created_at" : "2012-08-09 13:18:31 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233552605249429505",
  "text" : "@i_horse \u3042\u3089\u3089\u30C9\u30F3\u30DE\u30A4",
  "id" : 233552605249429505,
  "created_at" : "2012-08-09 13:17:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233552124183715840",
  "geo" : { },
  "id_str" : "233552583036387328",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u660E\u65E5\u4E00\u306E\u65B0\u5E79\u7DDA\u3082\u8F9E\u3055\u306A\u3044\u899A\u609F\uFF1F",
  "id" : 233552583036387328,
  "in_reply_to_status_id" : 233552124183715840,
  "created_at" : "2012-08-09 13:17:29 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233551998295875585",
  "text" : "@i_horse \u660E\u65E5",
  "id" : 233551998295875585,
  "created_at" : "2012-08-09 13:15:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233551869719502848",
  "text" : "\u3057\u3085\u304C\u308B\u3093\u541B\u3068\u30D1\u30D5\u30A7\u98DF\u3079\u306B\u884C\u304F\u3051\u3069\u304F\u308B\u4EBA\u3044\u307E\u305B\u3093\uFF1F@\u6771\u4EAC",
  "id" : 233551869719502848,
  "created_at" : "2012-08-09 13:14:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233551452369461249",
  "text" : "\u3082\u3046\u897F\u837B\u304B\u3089\u30BF\u30AF\u30B7\u30FC\u4E57\u3063\u3061\u3083\u3046\u3082\u3093\u306D",
  "id" : 233551452369461249,
  "created_at" : "2012-08-09 13:13:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233550852168744960",
  "geo" : { },
  "id_str" : "233551252045312000",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u3068\u308A\u3042\u3048\u305A\u8AB0\u304BTL\u3067\u3001\u6765\u305D\u3046\u306A\u4EBA\u2026",
  "id" : 233551252045312000,
  "in_reply_to_status_id" : 233550852168744960,
  "created_at" : "2012-08-09 13:12:12 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233550971861606400",
  "text" : "\u305D\u3057\u3066\u3072\u3055\u3073\u3055\u306E\u4E2D\u592E\u7DDA",
  "id" : 233550971861606400,
  "created_at" : "2012-08-09 13:11:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233550564485652480",
  "text" : "\u6052\u4F8B\u3060\u304C\u30A8\u30B9\u30AB\u30EC\u30FC\u30BF\u30FC\u3069\u3063\u3061\u3060\u3063\u3051",
  "id" : 233550564485652480,
  "created_at" : "2012-08-09 13:09:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233548766161039360",
  "text" : "\u65B0\u5E79\u7DDA\u964D\u308A\u969B\u306E\u306B\u305B\u307B\u30FC",
  "id" : 233548766161039360,
  "created_at" : "2012-08-09 13:02:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233548635575570434",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 233548635575570434,
  "created_at" : "2012-08-09 13:01:48 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233547184715485184",
  "text" : "\u54C1\u5DDD\u30FC",
  "id" : 233547184715485184,
  "created_at" : "2012-08-09 12:56:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233545418405986305",
  "text" : "\u3082\u3046\u304A\u8179\u6E1B\u3063\u3066\u300C\u304A\u8179\u6E1B\u3063\u305F\u300D\u3068\u8A00\u308F\u3093\u3070\u304B\u308A\u306B\u304A\u8179\u6E1B\u3063\u305F\u3002\u306A\u305C\u306A\u3089\u304A\u8179\u304C\u6E1B\u3063\u3066\u3044\u308B\u3002",
  "id" : 233545418405986305,
  "created_at" : "2012-08-09 12:49:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233545264986730496",
  "text" : "\u306F\u3088\u7740\u304B\u306A\u3044\u304B\u306A\u30FC",
  "id" : 233545264986730496,
  "created_at" : "2012-08-09 12:48:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233544039088132097",
  "text" : "\u305D\u3093\u306A\u611F\u3058\u3067\u65B0\u6A2A\u6D5C\u306B\u3064\u304F\u306A\u30FC",
  "id" : 233544039088132097,
  "created_at" : "2012-08-09 12:43:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233543898264391680",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F\u3001\u3067\u3082\u5B9F\u5BB6\u3067\u304A\u523A\u8EAB\u3068\u3054\u98EF\u3068\u304A\u5473\u564C\u6C41\u304C\u5F85\u3063\u3066\u3044\u308B\u3089\u3057\u3044\u304B\u3089\u5727\u5012\u7684\u6211\u6162",
  "id" : 233543898264391680,
  "created_at" : "2012-08-09 12:42:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233543233664319488",
  "text" : "\u9006\u306A\u3089\u308F\u3093\u3061\u3083\u3093\uFF1F",
  "id" : 233543233664319488,
  "created_at" : "2012-08-09 12:40:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 3, 12 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233543164592525313",
  "text" : "RT @hanaoka_: \u300C\u5408\u5426\u5224\u5B9A\u307C\u304F\u306F\u3069\u3046\u3067\u3059\u304B\uFF1F\u300D\u300C\u30AA\u30C3\u3001\u541B\u4EAC\u5927\u751F\u3063\u307D\u3044\u306D\u3001\u3044\u3044\u306D\uFF5E\uFF5E\u304D\u3063\u3068\u5408\u683C\u3059\u308B\u3088\u300D\u300C\u79C1\u306F\u6771\u5927\u751F\u3067\u3059\u300D\u3063\u3066\u3084\u308A\u305F\u3044\u304B\u3089\u8AB0\u304B\u6771\u5927\u751F\u6765\u3066\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233542992349241345",
    "text" : "\u300C\u5408\u5426\u5224\u5B9A\u307C\u304F\u306F\u3069\u3046\u3067\u3059\u304B\uFF1F\u300D\u300C\u30AA\u30C3\u3001\u541B\u4EAC\u5927\u751F\u3063\u307D\u3044\u306D\u3001\u3044\u3044\u306D\uFF5E\uFF5E\u304D\u3063\u3068\u5408\u683C\u3059\u308B\u3088\u300D\u300C\u79C1\u306F\u6771\u5927\u751F\u3067\u3059\u300D\u3063\u3066\u3084\u308A\u305F\u3044\u304B\u3089\u8AB0\u304B\u6771\u5927\u751F\u6765\u3066\u3088",
    "id" : 233542992349241345,
    "created_at" : "2012-08-09 12:39:23 +0000",
    "user" : {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "protected" : false,
      "id_str" : "126927392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540399732707688448\/Iqz4rTVp_normal.jpeg",
      "id" : 126927392,
      "verified" : false
    }
  },
  "id" : 233543164592525313,
  "created_at" : "2012-08-09 12:40:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233540488261672960",
  "text" : "@\u8ECA\u5185\u8CA9\u58F2\u306E\u4EBA \u304A\u8179\u6E1B\u3063\u305F\u3093\u3067\u306A\u3093\u304B\u4E0B\u3055\u3044",
  "id" : 233540488261672960,
  "created_at" : "2012-08-09 12:29:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233531496542109696",
  "geo" : { },
  "id_str" : "233533634450190339",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u3061\u306A\u307F\u306B\u98DF\u3079\u308B\u3068\u3057\u305F\u3089\u4F55\u51E6\u306B\u98DF\u3079\u306B\u884C\u304F\u4E88\u5B9A\u3067\u3059\uFF1F",
  "id" : 233533634450190339,
  "in_reply_to_status_id" : 233531496542109696,
  "created_at" : "2012-08-09 12:02:11 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233533184292319232",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 233533184292319232,
  "created_at" : "2012-08-09 12:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233530525443301377",
  "geo" : { },
  "id_str" : "233531060804276224",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u5915\u65B96\u6642\u306B\u53CB\u4EBA\u3068\u306E\u5F85\u3061\u5408\u308F\u305B\u304C\u3042\u308B\u306E\u3067\u5915\u65B9\u306B\u306A\u3089\u306A\u3044\u6642\u9593\u306A\u3089\u6687\u3067\u3059\u3088(\u30D1\u30D5\u30A7\u306F\u3042\u308A\u3067\u3082\u306A\u3057\u3067\u3082",
  "id" : 233531060804276224,
  "in_reply_to_status_id" : 233530525443301377,
  "created_at" : "2012-08-09 11:51:58 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233530196228198400",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u660E\u65E5\u306E\u8A71\u3063\u3066\u3069\u3046\u306A\u3063\u3066\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 233530196228198400,
  "created_at" : "2012-08-09 11:48:32 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233529535642075136",
  "text" : "\u5727\u5012\u7684\u7A7A\u8179",
  "id" : 233529535642075136,
  "created_at" : "2012-08-09 11:45:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233523895196585986",
  "text" : "\u3057\u304B\u3057\u540D\u53E4\u5C4B\u3042\u305F\u308A\u3067\u8AAD\u307F\u7D42\u3048\u308B\u3042\u305F\u308A\u9593\u304C\u60AA\u3044",
  "id" : 233523895196585986,
  "created_at" : "2012-08-09 11:23:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233523699217735680",
  "text" : "\u59B9\u3068\u306E\u30E1\u30FC\u30EB\u304C\u3072\u305F\u3059\u3089\u4E0D\u6BDB",
  "id" : 233523699217735680,
  "created_at" : "2012-08-09 11:22:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233523357696528384",
  "text" : "\u3057\u304B\u3057\u65B0\u5E79\u7DDA\u3082\u3044\u3055\u3055\u304B\u6DF7\u3093\u3067\u3044\u308B",
  "id" : 233523357696528384,
  "created_at" : "2012-08-09 11:21:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233522540105056256",
  "text" : "\u30AA\u30C1\u306F\u3046\u3093\u3001\u8A55\u4FA1\u304C\u5225\u308C\u308B\u3093\u3060\u308D\u3046\u306A\u30FC\u3002",
  "id" : 233522540105056256,
  "created_at" : "2012-08-09 11:18:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233522199028449280",
  "text" : "\u7518\u3059\u304E\u3066\u5589\u304C\u4E7E\u3044\u305F\u3088\u3002\u540D\u53E4\u5C4B\u3002",
  "id" : 233522199028449280,
  "created_at" : "2012-08-09 11:16:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233522028479655936",
  "text" : "\u4E45\u3005\u306B\u3053\u3093\u306A\u306B\u7518\u3044\u604B\u611B\u5C0F\u8AAC\u3092\u8AAD\u3093\u3060\u3002\u3057\u304B\u3057\u3066\u3055\u304B\u306A\u306F\u306A\u3093\u3067\u3053\u308C\u3092\u52E7\u3081\u3066\u304F\u308C\u305F\u3093\u3060\u308D\u3046\u306A\u3002",
  "id" : 233522028479655936,
  "created_at" : "2012-08-09 11:16:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233521740620386304",
  "text" : "\u967D\u3060\u307E\u308A\u306E\u5F7C\u5973 \u8AAD\u4E86",
  "id" : 233521740620386304,
  "created_at" : "2012-08-09 11:14:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233503393912598529",
  "text" : "\u3057\u3085\u304C\u308B\u3093\u3068\u5727\u5012\u7684\u8CE2\u8005\u3068\u3086\u304D\u307F\u3093\u304C\u697D\u3057\u3052\u3060\u3063\u305F\u306E\u304B\u30FC\u3002\u884C\u304D\u305F\u304B\u3063\u305F\u306A\u30FC\u3002",
  "id" : 233503393912598529,
  "created_at" : "2012-08-09 10:02:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/GK3dDDgb",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/122?prefill=yusuehiro",
      "display_url" : "gohantabeyo.com\/nani\/122?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233083073200287745",
  "text" : "\u30DA\u30A2\u30D7\u30ED\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/GK3dDDgb",
  "id" : 233083073200287745,
  "created_at" : "2012-08-08 06:11:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 0, 6 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233067308770263040",
  "geo" : { },
  "id_str" : "233067543907151872",
  "in_reply_to_user_id" : 184844182,
  "text" : "@0_uda \u30CA\u30A4\u30B9\u30E2\u30F3\u30B9\u30BF\u30FC\uFF01",
  "id" : 233067543907151872,
  "in_reply_to_status_id" : 233067308770263040,
  "created_at" : "2012-08-08 05:10:07 +0000",
  "in_reply_to_screen_name" : "0_uda",
  "in_reply_to_user_id_str" : "184844182",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233064195145465856",
  "text" : "14\u6642\u96C6\u5408\u3067\u3082\u826F\u304B\u3063\u305F\u306A\u3053\u308A\u3083",
  "id" : 233064195145465856,
  "created_at" : "2012-08-08 04:56:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233048515171995649",
  "text" : "\u7D50\u5C40\u30AB\u30EB\u30AB\u30BD\u30F3\u30CC\u3092\u53D6\u3063\u305F(\u30B5\u30A4\u30BA\u7684\u306B\u6301\u3063\u3066\u5E30\u308C\u305D\u3046\u3060\u3063\u305F\u304B\u3089)",
  "id" : 233048515171995649,
  "created_at" : "2012-08-08 03:54:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233047075955302401",
  "text" : "\u30AB\u30BF\u30F3\u3068\u30AB\u30EB\u30AB\u30BD\u30F3\u30CC\u306E\u4E8C\u629E\u3067\u8FF7\u3046\u306A\u3046",
  "id" : 233047075955302401,
  "created_at" : "2012-08-08 03:48:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233043084471070720",
  "text" : "\u3068\u601D\u3063\u305F\u304C\u305D\u3053\u307E\u3067\u30C6\u30A4\u30B9\u30C8\u5909\u308F\u3089\u306A\u3044\u304B",
  "id" : 233043084471070720,
  "created_at" : "2012-08-08 03:32:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233042990426365952",
  "text" : "@9110alice \u30B9\u30D7\u30FC\u30C8\u30CB\u30AF\u306E\u604B\u4EBA\u3001\u306F\u8AAD\u307F\u307E\u3057\u305F\uFF1F",
  "id" : 233042990426365952,
  "created_at" : "2012-08-08 03:32:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233042815821701120",
  "text" : "\u6D77\u8FBA\u306B\u6253\u3061\u4E0A\u3052\u3089\u308C\u305F\u5E03\u56E3\u3068\u304B\u304D\u3063\u3068\u3059\u306A\u307E\u307F\u308C\u3067\u3001\u6F6E\u3067\u30D9\u30BF\u30D9\u30BF\u3057\u3066\u30A2\u30EC\u306B\u9055\u3044\u306A\u3044",
  "id" : 233042815821701120,
  "created_at" : "2012-08-08 03:31:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u304BC\u30C9\u30A5\u30FC",
      "screen_name" : "hiroskii_mk2",
      "indices" : [ 0, 13 ],
      "id_str" : "247411674",
      "id" : 247411674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233041879799824384",
  "geo" : { },
  "id_str" : "233042149808144384",
  "in_reply_to_user_id" : 247411674,
  "text" : "@hiroskii_mk2 \u3069\u3046\u304B\u3093\u304C\u3048\u3066\u3082\u30C9\u30ED\u30C9\u30ED",
  "id" : 233042149808144384,
  "in_reply_to_status_id" : 233041879799824384,
  "created_at" : "2012-08-08 03:29:12 +0000",
  "in_reply_to_screen_name" : "hiroskii_mk2",
  "in_reply_to_user_id_str" : "247411674",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233041997559103488",
  "text" : "\u30A4\u30A8\u30B5\u30D6\u3088\u3063\u3066\u5E30\u308B\u3051\u3069\u3042\u305D\u3053\u6563\u8CA1\u3057\u304C\u3061\u3060\u304B\u3089\u306A\u3041(^^)(^^)(^^)",
  "id" : 233041997559103488,
  "created_at" : "2012-08-08 03:28:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 0, 9 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233041093246201856",
  "geo" : { },
  "id_str" : "233041671829471232",
  "in_reply_to_user_id" : 194178083,
  "text" : "@seraph_2 \u5727\u5012\u7684\u5927\u90FD\u4F1A\uFF01\uFF01\uFF01",
  "id" : 233041671829471232,
  "in_reply_to_status_id" : 233041093246201856,
  "created_at" : "2012-08-08 03:27:18 +0000",
  "in_reply_to_screen_name" : "seraph_2",
  "in_reply_to_user_id_str" : "194178083",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233031305036718080",
  "text" : "\u4FFA\u306F\u4ECA\u4F55\u304C\u98DF\u3079\u305F\u3044\u306E\u3060\u308D\u3046",
  "id" : 233031305036718080,
  "created_at" : "2012-08-08 02:46:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233030241868718080",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u6EA2\u308C\u308B\u7A7A\u8179\u304C\u6B62\u307E\u3089\u306A\u3044\u306E\u3092\u306A\u3093\u3068\u304B\u305B\u306A\u3070",
  "id" : 233030241868718080,
  "created_at" : "2012-08-08 02:41:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233030065770868736",
  "text" : "\u624B\u3092\u3064\u306A\u3044\u3067\u308B\u8AC7\u7B11\u3057\u3066\u308B\u7537\u5B50\u4E8C\u4EBA\u3068\u3059\u308C\u9055\u3063\u305F\u3002\u4F55\u3082\u3044\u3046\u307E\u3044\u3002",
  "id" : 233030065770868736,
  "created_at" : "2012-08-08 02:41:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233029421362196482",
  "text" : "\u795E\u3055\u3073\u305F\u53E4\u4E09\u6761",
  "id" : 233029421362196482,
  "created_at" : "2012-08-08 02:38:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232985736729731073",
  "text" : "\u95A2\u6771\u4EBA\u304C\u3001\u95A2\u897F\u4EBA\u304C\u3001\u7406\u7CFB\u304C\u3001\u6587\u7CFB\u304C\u3001\u304B\u3089\u59CB\u307E\u308B\u4E00\u90E8\u306E\u6587\u8A00\u306F\u3001\u3061\u3087\u3063\u3068\u54C0\u3057\u3044\u4E8B\u304C\u3042\u308B",
  "id" : 232985736729731073,
  "created_at" : "2012-08-07 23:45:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232985087229186049",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 232985087229186049,
  "created_at" : "2012-08-07 23:42:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232984903401222145",
  "text" : "\u305F\u3060\u95A2\u897F\u307B\u3069\u8868\u306B\u51FA\u3066\u304D\u3066\u306F\u3044\u306A\u304B\u3063\u305F\u304B\u306A\u30FC",
  "id" : 232984903401222145,
  "created_at" : "2012-08-07 23:41:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 26, 34 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232984805338411009",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u7121\u3044\u3067\u3082\u306A\u3044(\u81EA\u5206\u306E\u5468\u308A\u306F\u3042\u3063\u305F) RT @i_horse: \u30DC\u30B1\u3068\u30C4\u30C3\u30B3\u30DF\u306E\u6587\u5316\u304C\u306A\u3044\u3068\u304B\u60F3\u50CF\u3067\u304D\u306A\u3044",
  "id" : 232984805338411009,
  "created_at" : "2012-08-07 23:41:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232808375648415744",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 232808375648415744,
  "created_at" : "2012-08-07 12:00:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232799120593649664",
  "text" : "\u3055\u3041\u305D\u3046\u3058\u305D\u3046\u3058",
  "id" : 232799120593649664,
  "created_at" : "2012-08-07 11:23:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232798782742482945",
  "text" : "\u70AD\u9178\u6C34\u306F\u6B63\u7FA9",
  "id" : 232798782742482945,
  "created_at" : "2012-08-07 11:22:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308C\u3075",
      "screen_name" : "leff2",
      "indices" : [ 3, 9 ],
      "id_str" : "21846614",
      "id" : 21846614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232798731836194816",
  "text" : "RT @leff2: \u70AD\u9178\u6C34\u306F\u6B63\u7FA9\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232797962311462912",
    "text" : "\u70AD\u9178\u6C34\u306F\u6B63\u7FA9\uFF01",
    "id" : 232797962311462912,
    "created_at" : "2012-08-07 11:18:54 +0000",
    "user" : {
      "name" : "\u308C\u3075",
      "screen_name" : "leff2",
      "protected" : false,
      "id_str" : "21846614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000496840295\/f1c7bb9c9dcf459cf8b60daa276d1a14_normal.jpeg",
      "id" : 21846614,
      "verified" : false
    }
  },
  "id" : 232798731836194816,
  "created_at" : "2012-08-07 11:21:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232788159178620928",
  "text" : "\u3042\u305A\u304D\u30D0\u30FC\u304A\u3044\u3057\u3044",
  "id" : 232788159178620928,
  "created_at" : "2012-08-07 10:39:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF2F\u5C71",
      "screen_name" : "oldham_10",
      "indices" : [ 0, 10 ],
      "id_str" : "559501096",
      "id" : 559501096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232739051692756992",
  "geo" : { },
  "id_str" : "232763887626358784",
  "in_reply_to_user_id" : 559501096,
  "text" : "@oldham_10 \u304A\u304D\u306B\u306A\u3055\u3089\u305A\u30FC",
  "id" : 232763887626358784,
  "in_reply_to_status_id" : 232739051692756992,
  "created_at" : "2012-08-07 09:03:30 +0000",
  "in_reply_to_screen_name" : "oldham_10",
  "in_reply_to_user_id_str" : "559501096",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232763611930578944",
  "text" : "\u6EA2\u308C\u308B\u7A7A\u8179\u304C\u6B62\u307E\u3089\u306A\u3044",
  "id" : 232763611930578944,
  "created_at" : "2012-08-07 09:02:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 13, 28 ],
      "id_str" : "227502200",
      "id" : 227502200
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrrn",
      "indices" : [ 29, 43 ],
      "id_str" : "295216106",
      "id" : 295216106
    }, {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 44, 53 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232677755878264832",
  "text" : ".  @ispamgis @G4_Hirano_chan @nisehorrrrrrn @reflexio @9110alice \u304A\u306F\u3088\u3046\u3042\u308A\u3067\u3057\u305F\u30FC",
  "id" : 232677755878264832,
  "created_at" : "2012-08-07 03:21:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232677474834739200",
  "text" : "@reflexio \u3044\u3084\u3001\u666E\u901A\u306B\u6D3B\u52D5\u3057\u3066\u3044\u308B\u3088",
  "id" : 232677474834739200,
  "created_at" : "2012-08-07 03:20:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232651635304833024",
  "text" : "\u8D77\u304D\u305F\u304C",
  "id" : 232651635304833024,
  "created_at" : "2012-08-07 01:37:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232450992103370752",
  "text" : "RT @shigmax: \u6B7B\u56E0: \u66F8\u985E\u4E0D\u5099",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "232367180711354368",
    "text" : "\u6B7B\u56E0: \u66F8\u985E\u4E0D\u5099",
    "id" : 232367180711354368,
    "created_at" : "2012-08-06 06:47:07 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 232450992103370752,
  "created_at" : "2012-08-06 12:20:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF2F\u5C71",
      "screen_name" : "oldham_10",
      "indices" : [ 0, 10 ],
      "id_str" : "559501096",
      "id" : 559501096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232450631049297920",
  "geo" : { },
  "id_str" : "232450888067870720",
  "in_reply_to_user_id" : 559501096,
  "text" : "@oldham_10 \u4FFA\u306F\u4E00\u5FDC\u660E\u65E55\u6642\u304F\u3089\u3044\u304B\u3089\u884C\u304F\u4E88\u5B9A\u30FC",
  "id" : 232450888067870720,
  "in_reply_to_status_id" : 232450631049297920,
  "created_at" : "2012-08-06 12:19:45 +0000",
  "in_reply_to_screen_name" : "oldham_10",
  "in_reply_to_user_id_str" : "559501096",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF2F\u5C71",
      "screen_name" : "oldham_10",
      "indices" : [ 0, 10 ],
      "id_str" : "559501096",
      "id" : 559501096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232450116420771840",
  "geo" : { },
  "id_str" : "232450252400128000",
  "in_reply_to_user_id" : 559501096,
  "text" : "@oldham_10 \u3046\u3080\uFF0E\u307E\u305F\u304A\u76C6\u660E\u3051\u3066\u304B\u3089\u3060\u306A\u30FC\uFF0E\u660E\u65E5\u30B5\u30FC\u30AF\u30EB\u306F\u6765\u308B\uFF1F",
  "id" : 232450252400128000,
  "in_reply_to_status_id" : 232450116420771840,
  "created_at" : "2012-08-06 12:17:13 +0000",
  "in_reply_to_screen_name" : "oldham_10",
  "in_reply_to_user_id_str" : "559501096",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF2F\u5C71",
      "screen_name" : "oldham_10",
      "indices" : [ 0, 10 ],
      "id_str" : "559501096",
      "id" : 559501096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232449612760367104",
  "geo" : { },
  "id_str" : "232449854541021184",
  "in_reply_to_user_id" : 559501096,
  "text" : "@oldham_10 iwa\u3055\u3093\u306F\u591A\u5206\u3082\u3046\u5E30\u7701\u3060\u3057sigmax\u3055\u3093\u9662\u6B7B\u3060\u3057\u3061\u3087\u3063\u3068\u3057\u3093\u3069\u3044\u304B\u3082\u306A\u30FC\uFF0E\uFF08\u4FFA\u3082\u660E\u65E5\u663C\u304B\u3089\u30D0\u30A4\u30C8\uFF09",
  "id" : 232449854541021184,
  "in_reply_to_status_id" : 232449612760367104,
  "created_at" : "2012-08-06 12:15:38 +0000",
  "in_reply_to_screen_name" : "oldham_10",
  "in_reply_to_user_id_str" : "559501096",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF2F\u5C71",
      "screen_name" : "oldham_10",
      "indices" : [ 0, 10 ],
      "id_str" : "559501096",
      "id" : 559501096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232415018535251969",
  "geo" : { },
  "id_str" : "232449244542427137",
  "in_reply_to_user_id" : 559501096,
  "text" : "@oldham_10 \u30D0\u30A4\u30C8\u3060\u3063\u305F\u304B\u3089\u4ECA\u898B\u305F\u3002\u30E1\u30F3\u30C4\u306F\uFF1F",
  "id" : 232449244542427137,
  "in_reply_to_status_id" : 232415018535251969,
  "created_at" : "2012-08-06 12:13:13 +0000",
  "in_reply_to_screen_name" : "oldham_10",
  "in_reply_to_user_id_str" : "559501096",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232276146622959617",
  "text" : "\u3057\u308C\u3063\u3068\u4E8C\u5EA6\u5BDD\u3057\u305F\u3089\u3053\u306E\u6642\u9593\u3067\u3042\u308B",
  "id" : 232276146622959617,
  "created_at" : "2012-08-06 00:45:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232083681567703042",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 232083681567703042,
  "created_at" : "2012-08-05 12:00:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232059499622563841",
  "geo" : { },
  "id_str" : "232059711271350272",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u5FD8\u308C\u3066\u305F\u4ECA\u304B\u3089\u5165\u308B",
  "id" : 232059711271350272,
  "in_reply_to_status_id" : 232059499622563841,
  "created_at" : "2012-08-05 10:25:21 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 2, 10 ],
      "id_str" : "145536184",
      "id" : 145536184
    }, {
      "name" : "\u660E\u65E5\u5948@\u898F\u5236",
      "screen_name" : "saionjiasuna1",
      "indices" : [ 22, 36 ],
      "id_str" : "584394248",
      "id" : 584394248
    }, {
      "name" : "\u516C\u5171\u4EA4\u901A\u6A5F\u95A2\u3092\u4F7F\u304A\u3046",
      "screen_name" : "yasuand",
      "indices" : [ 37, 45 ],
      "id_str" : "351349087",
      "id" : 351349087
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 56, 66 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 67, 77 ],
      "id_str" : "157989076",
      "id" : 157989076
    }, {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 78, 91 ],
      "id_str" : "264005011",
      "id" : 264005011
    }, {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 92, 100 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232059624906448896",
  "text" : ". @chr1233 @Italiasan @saionjiasuna1 @yasuand @ispamgis @nisehorrn @typekanon @carotene4035 @shigmax \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 232059624906448896,
  "created_at" : "2012-08-05 10:25:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232059470241472512",
  "text" : "\u305D\u306E\u524D\u306B\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\u304B\u3048\u3055\u306A\u3070",
  "id" : 232059470241472512,
  "created_at" : "2012-08-05 10:24:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232059384933535744",
  "text" : "\u826F\u3044\u751F\u6D3B\u30EA\u30BA\u30E0\u3092\u4E00\u767A\u3067\u30C4\u30E2\u308B\u7B97\u6BB5",
  "id" : 232059384933535744,
  "created_at" : "2012-08-05 10:24:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232059249948246016",
  "text" : "\u660E\u65E5\u4E5D\u6642\u306B\u8033\u9F3B\u79D1\u3063\u3068\u3002\u3055\u3066\u30016\u6642\u304F\u3089\u3044\u307E\u3067\u5BDD\u308B\u304B\u30FC\u3002",
  "id" : 232059249948246016,
  "created_at" : "2012-08-05 10:23:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231950695853600768",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 231950695853600768,
  "created_at" : "2012-08-05 03:12:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231950610881196033",
  "text" : "\u8D77\u304D\u305F\u3001\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u305F\u3002\u305D\u3057\u3066\u4E00\u6708\u3076\u308A\u306E\u2026",
  "id" : 231950610881196033,
  "created_at" : "2012-08-05 03:11:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231888691675672576",
  "text" : "\u304A\u306F\u3088\u3046\uFF34\uFF2C\u2026\u3060\u304C\u6562\u3048\u3066\u8A00\u304A\u3046\u2026\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3001\u3068\u3002",
  "id" : 231888691675672576,
  "created_at" : "2012-08-04 23:05:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231721259782782976",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 231721259782782976,
  "created_at" : "2012-08-04 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/rTeTGU1b",
      "expanded_url" : "http:\/\/twitpic.com\/af7ybk",
      "display_url" : "twitpic.com\/af7ybk"
    } ]
  },
  "geo" : { },
  "id_str" : "231611774422622209",
  "text" : "\u30D5\u30EC\u30C3\u30B7\u30E5\u30CD\u30B9\u306E\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u30CE\u30FC\u30C8\u306B\u3086\u6559\u306E\u722A\u75D5\u3092\u6B8B\u3057\u3066\u7F6E\u3044\u305F http:\/\/t.co\/rTeTGU1b",
  "id" : 231611774422622209,
  "created_at" : "2012-08-04 04:45:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231408494249644033",
  "geo" : { },
  "id_str" : "231408560905543681",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u305D\u308C\u306F\u3084\u3081\u3068\u304D\u307E\u3057\u3087\u3046",
  "id" : 231408560905543681,
  "in_reply_to_status_id" : 231408494249644033,
  "created_at" : "2012-08-03 15:17:54 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231407774188326913",
  "geo" : { },
  "id_str" : "231408367283871745",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u4ECA\u304B\u30894\u6642\u304F\u3089\u3044\u307E\u3067\u9EBB\u96C0\u306A\u306E\u3067\u3059\u304C\u2026",
  "id" : 231408367283871745,
  "in_reply_to_status_id" : 231407774188326913,
  "created_at" : "2012-08-03 15:17:08 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231407694672719872",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u304A\u6687\u3067\u3059\u304B\uFF1F",
  "id" : 231407694672719872,
  "created_at" : "2012-08-03 15:14:28 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231407297430175744",
  "text" : "@reflexio \u308F\u3093\u3061\u3083\u3093\u3042\u308B\u306D",
  "id" : 231407297430175744,
  "created_at" : "2012-08-03 15:12:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231405483825709057",
  "text" : "\u3053\u306E\u6642\u9593\u306B",
  "id" : 231405483825709057,
  "created_at" : "2012-08-03 15:05:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231405395380408320",
  "text" : "\u3068\u8A00\u3046\u308F\u3051\u3067\u4E00\u4EBA\u6B20\u3051\u306E\u5353\u304C\u3042\u308B\u306E\u3067\u3059\u304C\u30FC\uFF1F",
  "id" : 231405395380408320,
  "created_at" : "2012-08-03 15:05:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231405275230388224",
  "text" : "\u306F\u3041\u3001\u30EC\u30DD\u30FC\u30C8\u7D42\u308F\u3063\u305F\u3068\u601D\u3063\u305F\u3089\u9EBB\u96C0\u306E\u8A98\u3044\u304B\u3088\u3001\u5168\u304F(\u6E80\u9762\u306E\u7B11\u307F)",
  "id" : 231405275230388224,
  "created_at" : "2012-08-03 15:04:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231400592583561217",
  "text" : "\u3046\u30FC\u308D\u3093\u3061\u3083\u3067\u304C\u307E\u3093\u3057\u3088\u3046",
  "id" : 231400592583561217,
  "created_at" : "2012-08-03 14:46:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231400481019281408",
  "text" : "\u304A\u3055\u3051\u306E\u307F\u305F\u3044\u3068\u304A\u3082\u3063\u305F\u3051\u308C\u3069\u3042\u3063\u3068\u3046\u3066\u304D\u304F\u3046\u3075\u304F\u3060\u3063\u305F",
  "id" : 231400481019281408,
  "created_at" : "2012-08-03 14:45:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231399804792631296",
  "text" : "\u3068\u3044\u3046\u304B\u306A\u3093\u3067Web\u304B\u3089\u9811\u5F35\u3063\u3066\u308B\u3093\u3060\u308D\u2026",
  "id" : 231399804792631296,
  "created_at" : "2012-08-03 14:43:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 0, 9 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231398870893080578",
  "geo" : { },
  "id_str" : "231399079953973248",
  "in_reply_to_user_id" : 194178083,
  "text" : "@seraph_2 \u304A\u304B\u3048\u308A\u306A\u3055\u3044",
  "id" : 231399079953973248,
  "in_reply_to_status_id" : 231398870893080578,
  "created_at" : "2012-08-03 14:40:14 +0000",
  "in_reply_to_screen_name" : "seraph_2",
  "in_reply_to_user_id_str" : "194178083",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231398708359602177",
  "text" : "\u30B3\u30B9\u30C8\u3082\u30AB\u30ED\u30EA\u30FC\u3082\u5727\u5012\u7684\u3067\u3042\u308B",
  "id" : 231398708359602177,
  "created_at" : "2012-08-03 14:38:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231398585625890816",
  "text" : "\uFF08\u30AF\u30EA\u30FC\u30E0\u30C1\u30FC\u30BA\uFF0C\u30AA\u30EA\u30FC\u30D6\uFF0C\u30B9\u30E2\u30FC\u30AF\u30B5\u30FC\u30E2\u30F3\u306E\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u304C\u98DF\u3079\u305F\u3044\uFF09",
  "id" : 231398585625890816,
  "created_at" : "2012-08-03 14:38:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231398456344850432",
  "text" : "\u306A\u3093\u304B\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u306E\u5177\u6750\u6301\u3061\u5BC4\u3063\u3066\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u30AA\u30D5\u307F\u305F\u3044\u306E\u51FA\u6765\u306A\u3044\u304B\u306A\uFF08\u601D\u3044\u3064\u304D",
  "id" : 231398456344850432,
  "created_at" : "2012-08-03 14:37:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231398180774899713",
  "text" : "@coxff2006 \u306A\u3093\u304B\u4F7F\u3044\u65B9\u306F\u30D9\u30FC\u30B3\u30F3\u3068\u304B\u30CF\u30E0\u3068\u3042\u307E\u308A\u5909\u308F\u3089\u306A\u3044\u5370\u8C61\u3092\u53D7\u3051\u305F\u304B\u3089\u30DE\u30E8\u30CD\u30FC\u30BA\u306A\u3093\u304B\u3082\u3042\u3046\u306E\u304B\u3082[\u8981\u691C\u8A3C]",
  "id" : 231398180774899713,
  "created_at" : "2012-08-03 14:36:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231397950843154433",
  "text" : "\u3053\u306E\u6642\u9593\u306B\u30B5\u30F3\u30C9\u30A6\u30A3\u30C3\u30C1\u306E\u753B\u50CF\u3068\u304B\u3069\u3046\u8003\u3048\u3066\u3082\u5730\u96F7\u3060\u3063\u305F\uFF0E\u53CD\u7701\uFF0E",
  "id" : 231397950843154433,
  "created_at" : "2012-08-03 14:35:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231397823990620160",
  "text" : "@coxff2006 \uFF47\uFF47\u3063\u3066\u307F\u305F\u3051\u308C\u3069\u5869\u30B3\u30B7\u30E7\u30A6\u3067\u3044\u3044\u307F\u305F\u3044\uFF0E\u8584\u5207\u308A\u306E\u304D\u3085\u3046\u308A\u3068\u52A0\u30B9\u30E9\u30A4\u30B9\u30C1\u30FC\u30BA\u5165\u308C\u3066\u3082\u304A\u3044\u3057\u305D\u3046\uFF0E\uFF08\u304A\u306A\u304B\u3078\u3063\u305F\u3069\u3046\u3057\u3066\u304F\u308C\u308B\uFF09",
  "id" : 231397823990620160,
  "created_at" : "2012-08-03 14:35:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231396683974578176",
  "text" : "@coxff2006 \u30B5\u30F3\u30C9\u30A4\u30C3\u30C1\u306E\u30A4\u30E1\u30FC\u30B8\u5F37\u3044\u306A\u30FC\u2026\u3054\u306F\u3093\u306E\u304A\u304B\u305A\u306B\u3082\u306A\u308B\u306E\u304B\u306A\uFF0E",
  "id" : 231396683974578176,
  "created_at" : "2012-08-03 14:30:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231396554261553155",
  "text" : "Dogs and Heng-Keng (\u72EC\u65AD\u3068\u504F\u898B)",
  "id" : 231396554261553155,
  "created_at" : "2012-08-03 14:30:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 3, 12 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u590F\u4F11\u307F\u306E\u97F3\u30B2\u30FC\u30AF\u30E9\u30B9\u30BF\u30D5\u30A9\u30ED\u30FC\u796D\u308A",
      "indices" : [ 18, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231395613504319488",
  "text" : "RT @seraph_2: \u516D\u6BB5  #\u590F\u4F11\u307F\u306E\u97F3\u30B2\u30FC\u30AF\u30E9\u30B9\u30BF\u30D5\u30A9\u30ED\u30FC\u796D\u308A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/shootingstar067.com\/\" rel=\"nofollow\"\u003EShootingStar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u590F\u4F11\u307F\u306E\u97F3\u30B2\u30FC\u30AF\u30E9\u30B9\u30BF\u30D5\u30A9\u30ED\u30FC\u796D\u308A",
        "indices" : [ 4, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231395568465895425",
    "text" : "\u516D\u6BB5  #\u590F\u4F11\u307F\u306E\u97F3\u30B2\u30FC\u30AF\u30E9\u30B9\u30BF\u30D5\u30A9\u30ED\u30FC\u796D\u308A",
    "id" : 231395568465895425,
    "created_at" : "2012-08-03 14:26:17 +0000",
    "user" : {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "protected" : false,
      "id_str" : "194178083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591005331796275201\/i8T0aydI_normal.jpg",
      "id" : 194178083,
      "verified" : false
    }
  },
  "id" : 231395613504319488,
  "created_at" : "2012-08-03 14:26:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231395564565168128",
  "text" : "@coxff2006 \u3042\u308C\u3084\u3063\u3066\u307F\u305F\u3044\uFF08\u5B9F\u306F\u3084\u3063\u305F\u3053\u3068\u306A\u3057\uFF09",
  "id" : 231395564565168128,
  "created_at" : "2012-08-03 14:26:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231395289590820864",
  "text" : "@coxff2006 \u306A\u3093\u304B\u305C\u3093\u307E\u3044\u307F\u305F\u3044\u306E\u304F\u308B\u304F\u308B\u3063\u3066\u3084\u308B\u3084\u3064\uFF1F",
  "id" : 231395289590820864,
  "created_at" : "2012-08-03 14:25:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 0, 10 ],
      "id_str" : "158645894",
      "id" : 158645894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231394879153000448",
  "geo" : { },
  "id_str" : "231395151333978113",
  "in_reply_to_user_id" : 158645894,
  "text" : "@eclair_15 \u3044\u3044\u3067\u3059\u306D\uFF01\uFF08\u3067\u3082\u305D\u308C\u3092\u306A\u305C\u30A8\u30AF\u30EC\u3055\u3093\u304C\uFF09",
  "id" : 231395151333978113,
  "in_reply_to_status_id" : 231394879153000448,
  "created_at" : "2012-08-03 14:24:37 +0000",
  "in_reply_to_screen_name" : "eclair_15",
  "in_reply_to_user_id_str" : "158645894",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231394841261641728",
  "text" : "\u307E\u3063\u305F\u308A\u898B\u305F\u3044",
  "id" : 231394841261641728,
  "created_at" : "2012-08-03 14:23:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231394810215428096",
  "text" : "\u554F\u984C\u306F\u3044\u3048\u306B\u30C6\u30EC\u30D3\u304C\u306A\u3044\u3093\u3060\u3088\u306A\u30FC\uFF0C\u8AB0\u304B\u306E\u304A\u3046\u3061\u3067\u898B\u3063\u305F\u308A\u30DE\u30BF\u30A4",
  "id" : 231394810215428096,
  "created_at" : "2012-08-03 14:23:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231394704061788160",
  "text" : "\u3067\uFF0C\u30AA\u30EA\u30F3\u30D4\u30C3\u30AF\uFF0C\u30DC\u30D6\u30B9\u30EC\u30FC\u3068\u30AB\u30FC\u30EA\u30F3\u30B0\u3063\u3066\u3044\u3064\u3084\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 231394704061788160,
  "created_at" : "2012-08-03 14:22:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231394061762850816",
  "text" : "\u306A\u306E\u3067\u3084\u3089\u306A\u3055\u3059\u304E\u308B\u3068\u3068\u3063\u3066\u3082\u5F8C\u6094\uFF0E\u4ECA\u56DE\uFF0E",
  "id" : 231394061762850816,
  "created_at" : "2012-08-03 14:20:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231393954581585920",
  "text" : "\u3084\u308A\u3059\u304E\u3061\u3083\u3063\u305F\u65B9\u304C\u5F8C\u6094\u306F\u5C11\u306A\u304F\u3066\u6E08\u3080\u3068\u601D\u3046\u306E",
  "id" : 231393954581585920,
  "created_at" : "2012-08-03 14:19:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231393822960128000",
  "text" : "\u904E\u304E\u305F\u308B\u306F\u306A\u304A\u53CA\u3070\u3056\u308B\u304C\u5982\u3057\uFF1F",
  "id" : 231393822960128000,
  "created_at" : "2012-08-03 14:19:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231393137652809728",
  "geo" : { },
  "id_str" : "231393649966067712",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u300C\u304A\u3084\u3059\u307F\u306A\u3055\u3044\uFF0E\u300D\u3068\u304B\u300C\u304A\u3086\u3046\u306F\u3093\u300D\u3068\u304B\u97FF\u304D\u3082\u610F\u5473\u3082\u307B\u3093\u308F\u304B\u3057\u305F\u8A00\u8449\u306F\u611F\u899A\u7684\u306B\u597D\u304D\u3067\u3059\u306D\u30FC\uFF0E\u610F\u5473\u3060\u3063\u305F\u3089\u300C\u3084\u3063\u3066\u3084\u308A\u3059\u304E\u308B\u3053\u3068\u306F\u306A\u3044\u300D\u3068\u304B\uFF1F",
  "id" : 231393649966067712,
  "in_reply_to_status_id" : 231393137652809728,
  "created_at" : "2012-08-03 14:18:39 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231393275041443840",
  "text" : "\u3042\uFF0C\u7269\u7406\u306E\u52C9\u5F37\u3092\uFF0C\u3063\u3066\u610F\u5473\u3068\u52C9\u5F37\u5168\u822C\u306B\u3064\u3044\u3066\u6642\u9593\u7684\u306B\uFF0C\u3063\u3066\u610F\u5473\u3068\u4E21\u65B9\u3067\u3057",
  "id" : 231393275041443840,
  "created_at" : "2012-08-03 14:17:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231392684219179009",
  "geo" : { },
  "id_str" : "231392965241733120",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u300C\u5168\u529B\u3067\u529B\u3092\u629C\u304F\u300D\u3063\u3066\u8A00\u3046\u30D1\u30E9\u30C9\u30AD\u30B7\u30AB\u30EB\u306A\u8868\u73FE\u3082\u3042\u308A\u307E\u3059\uFF0E\u7D50\u69CB\u597D\u304D\u306A\u8A00\u8449\uFF0E",
  "id" : 231392965241733120,
  "in_reply_to_status_id" : 231392684219179009,
  "created_at" : "2012-08-03 14:15:56 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231392745774796800",
  "text" : "\u52C9\u5F37\u4E0D\u8DB3\uFF0E\u7269\u7406\u7684\u306B\uFF0E",
  "id" : 231392745774796800,
  "created_at" : "2012-08-03 14:15:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231392453536657408",
  "text" : "\u307E\u3041\u7DCF\u3058\u3066\u30C6\u30F3\u30B7\u30E7\u30F3\u306F\u4F4E\u3081\u306A\u306E\u3060\u3051\u308C\u3069\uFF0E",
  "id" : 231392453536657408,
  "created_at" : "2012-08-03 14:13:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231390139555917825",
  "geo" : { },
  "id_str" : "231392358476967936",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u3093\u30FC\u9811\u5F35\u308B\u3063\u3066\u5FC5\u305A\u3057\u3082\u529B\u3092\u5165\u308C\u308B\u3053\u3068\u3060\u3051\u3092\u6307\u3055\u306A\u3044\u3064\u3082\u308A\u3067\u8A00\u3063\u305F\u306E\u3067\u3059\uFF0E\u5272\u5408\u306A\u3093\u3067\u3082\u697D\u3057\u3093\u3067\u3057\u307E\u3046\u65B9\u3060\u3068\u601D\u3044\u307E\u3059\u3057\uFF0E",
  "id" : 231392358476967936,
  "in_reply_to_status_id" : 231390139555917825,
  "created_at" : "2012-08-03 14:13:31 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231389184177360896",
  "geo" : { },
  "id_str" : "231389602823430146",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u9811\u5F35\u308A\u307E\u3059",
  "id" : 231389602823430146,
  "in_reply_to_status_id" : 231389184177360896,
  "created_at" : "2012-08-03 14:02:34 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231389098043117569",
  "text" : "\u307F\u3093\u306A\u304C\u697D\u3057\u3052\u3067\u3044\u3044\u306A\u30FC(\u9060\u3044\u76EE",
  "id" : 231389098043117569,
  "created_at" : "2012-08-03 14:00:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231388840277991424",
  "text" : "\u3046\u30FC",
  "id" : 231388840277991424,
  "created_at" : "2012-08-03 13:59:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 0, 9 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231329783630409729",
  "in_reply_to_user_id" : 126927392,
  "text" : "@hanaoka_ \u3068\u8A00\u3046\u308F\u3051\u3067\u304A\u501F\u308A\u3057\u3066\u3044\u305F\u672C\u306F\u304F\u3063\u3061\u3093\u3071\u90B8\u306B\u9810\u3051\u3066\u304A\u304D\u307E\u3057\u305F\uFF0E",
  "id" : 231329783630409729,
  "created_at" : "2012-08-03 10:04:52 +0000",
  "in_reply_to_screen_name" : "hanaoka_",
  "in_reply_to_user_id_str" : "126927392",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231329585344679936",
  "text" : "\u3088\u308A\u306B\u3088\u3063\u3066\u3086\u30DF\u30B5\u304C\u884C\u308F\u308C\u3066\u3044\u308B\u6700\u4E2D\u306E\u304F\u3063\u3061\u3093\u3071\u90B8\u306E\u6238\u3092\u53E9\u304F\u3053\u3068\u306B\u306A\u308D\u3046\u3068\u306F\uFF0E",
  "id" : 231329585344679936,
  "created_at" : "2012-08-03 10:04:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231329389856559107",
  "text" : "\u5E30\u5B85\uFF0E",
  "id" : 231329389856559107,
  "created_at" : "2012-08-03 10:03:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231318674395496448",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u4ECA\u304B\u3089\u884C\u304F\uFF0E10\u5206\u304F\u3089\u3044\uFF1F",
  "id" : 231318674395496448,
  "created_at" : "2012-08-03 09:20:44 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231318581852385280",
  "text" : "\u308C\u307D\u30FC\u3068\u3042\u3068\u4E00\u3064\u3063\u3066\u3068\u3053\u308D\u3067\u3044\u3063\u305F\u3093\u51FA\u304B\u3051\u308B\u304B\uFF0E\uFF0E\uFF0E",
  "id" : 231318581852385280,
  "created_at" : "2012-08-03 09:20:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 0, 9 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231296702844395520",
  "in_reply_to_user_id" : 126927392,
  "text" : "@hanaoka_ \u304D\u3087\u3046\u304F\u3063\u3061\u3093\u3071\u90B8\u884C\u304B\u308C\u307E\u3059\uFF1F",
  "id" : 231296702844395520,
  "created_at" : "2012-08-03 07:53:25 +0000",
  "in_reply_to_screen_name" : "hanaoka_",
  "in_reply_to_user_id_str" : "126927392",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231291313025318912",
  "text" : "\u3053\u306E\u524D\u306F\u5869\u9921\u3060\u3063\u305F\u304B\u3089\u4ECA\u5EA6\u306F\u7518\u9162\u3063\u307D\u3044\u306E\u306B\u3057\u3066\u307F\u3088\u3046\uFF0E\u5929\u6D25\u98EF\uFF0E",
  "id" : 231291313025318912,
  "created_at" : "2012-08-03 07:32:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231263409277116416",
  "text" : "\u3082\u3046\u3072\u3068\u62BC\u3057\u30A3",
  "id" : 231263409277116416,
  "created_at" : "2012-08-03 05:41:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231263384564273152",
  "text" : "\u5E8A\u3068\u30B3\u30BF\u30C4\u673A\u306F\u304B\u306A\u308A\u304D\u308C\u3044\u306B\u306A\u3063\u305F\uFF08\u52C9\u5F37\u673A\u306F\u6C5A\u304F\u306A\u3063\u305F\uFF09",
  "id" : 231263384564273152,
  "created_at" : "2012-08-03 05:41:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231252509275074562",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u90E8\u5C4B\u304C\u8352\u308C\u904E\u304E\u3066\u3066\u30A2\u30EC",
  "id" : 231252509275074562,
  "created_at" : "2012-08-03 04:57:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231252470838464513",
  "text" : "@setsuna3021181 \u305D\u308C\u3082\u3042\u308A\u307E\u3059\u306D\u30FC\uFF0E\u6700\u5F8C\u306E\u30EC\u30DD\u30FC\u30C8\u3084\u308B\u305F\u3081\u306E\u74B0\u5883\u3065\u304F\u308A\u3067\u3059\uFF08",
  "id" : 231252470838464513,
  "created_at" : "2012-08-03 04:57:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231252104684126208",
  "text" : "\u6383\u9664\u30FC",
  "id" : 231252104684126208,
  "created_at" : "2012-08-03 04:56:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231247637733601280",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u305F\u308915\u6642\u307E\u3067\u90E8\u5C4B\u306E\u7C21\u6613\u7247\u4ED8\u3051\u3057\u3066\u304B\u3089\u30EC\u30DD\u30FC\u30C8\u3092\u7247\u4ED8\u3051\u3088\u3046\uFF0E",
  "id" : 231247637733601280,
  "created_at" : "2012-08-03 04:38:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/togetter.com\" rel=\"nofollow\"\u003ETogetter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 1, 8 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/PERSMiVZ",
      "expanded_url" : "http:\/\/togetter.com\/li\/349474",
      "display_url" : "togetter.com\/li\/349474"
    } ]
  },
  "geo" : { },
  "id_str" : "231246671051378688",
  "text" : ".@tenapi \u3055\u3093\u306E\u300C\u56DE\u6587\u3068\u3044\u3046\u7570\u6587\u5316TL\u300D\u3092\u304A\u6C17\u306B\u5165\u308A\u306B\u3057\u307E\u3057\u305F\u3002 http:\/\/t.co\/PERSMiVZ",
  "id" : 231246671051378688,
  "created_at" : "2012-08-03 04:34:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/PERSMiVZ",
      "expanded_url" : "http:\/\/togetter.com\/li\/349474",
      "display_url" : "togetter.com\/li\/349474"
    } ]
  },
  "geo" : { },
  "id_str" : "231246551798923264",
  "text" : "\u56DE\u6587\u3068\u3044\u3046\u7570\u6587\u5316TL http:\/\/t.co\/PERSMiVZ",
  "id" : 231246551798923264,
  "created_at" : "2012-08-03 04:34:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231190671623598080",
  "text" : "\u4F55\u51E6\u304B\u3067\u805E\u3044\u305F\u8A71\u3060\u306A\u3001\u5927\u6839\u3092\u304B\u3058\u308B\u8A71",
  "id" : 231190671623598080,
  "created_at" : "2012-08-03 00:52:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231190504048582656",
  "text" : "\u7A7A\u8179\u6642\u306B\u306F(\u4E2D\u7565)\u5927\u6839\u3092\u304B\u3058\u308B\u7A7A\u8179\u6642\u306B\u306F(\u4E2D\u7565)\u5927\u6839\u3092\u304B\u3058\u308B\u7A7A\u8179\u6642\u306B\u306F(\u4E2D\u7565)\u5927\u6839\u3092\u304B\u3058\u308B\u7A7A\u8179\u6642\u306B\u306F(\u4E2D\u7565)\u5927\u6839\u3092\u304B\u3058\u308B\u7A7A\u8179\u6642\u306B\u306F(\u4E2D\u7565)\u5927\u6839\u3092\u304B\u3058\u308B",
  "id" : 231190504048582656,
  "created_at" : "2012-08-03 00:51:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 3, 13 ],
      "id_str" : "157989076",
      "id" : 157989076
    }, {
      "name" : "\u795E\u5948\u5DDD\u65B0\u805E\u793E\u30ED\u30FC\u30AB\u30EB\u30CB\u30E5\u30FC\u30B9",
      "screen_name" : "KanalocoLocal",
      "indices" : [ 109, 123 ],
      "id_str" : "73661746",
      "id" : 73661746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/cgfHdlw7",
      "expanded_url" : "http:\/\/news.kanaloco.jp\/localnews\/article\/1208020020\/",
      "display_url" : "news.kanaloco.jp\/localnews\/arti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "231190399706873856",
  "text" : "RT @typekanon: \u307E\u305F\u72EC\u7279\u306A\u30AD\u30E3\u30E9\u3060\u306A\u3041\u30FB\u30FB\u30FB\u3000\uFF0F\u3000\u30DE\u30B0\u30ED\u306E\u30AD\u30E3\u30E9\u3001\u540D\u524D\u3092\u4ED8\u3051\u3066\u306D\/\u4E09\u6D66\uFF1A\u30ED\u30FC\u30AB\u30EB\u30CB\u30E5\u30FC\u30B9 : \u30CB\u30E5\u30FC\u30B9 : \u30AB\u30CA\u30ED\u30B3 -- \u795E\u5948\u5DDD\u65B0\u805E\u793E http:\/\/t.co\/cgfHdlw7 via @KanalocoLocal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u795E\u5948\u5DDD\u65B0\u805E\u793E\u30ED\u30FC\u30AB\u30EB\u30CB\u30E5\u30FC\u30B9",
        "screen_name" : "KanalocoLocal",
        "indices" : [ 94, 108 ],
        "id_str" : "73661746",
        "id" : 73661746
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/cgfHdlw7",
        "expanded_url" : "http:\/\/news.kanaloco.jp\/localnews\/article\/1208020020\/",
        "display_url" : "news.kanaloco.jp\/localnews\/arti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "231189553162108928",
    "text" : "\u307E\u305F\u72EC\u7279\u306A\u30AD\u30E3\u30E9\u3060\u306A\u3041\u30FB\u30FB\u30FB\u3000\uFF0F\u3000\u30DE\u30B0\u30ED\u306E\u30AD\u30E3\u30E9\u3001\u540D\u524D\u3092\u4ED8\u3051\u3066\u306D\/\u4E09\u6D66\uFF1A\u30ED\u30FC\u30AB\u30EB\u30CB\u30E5\u30FC\u30B9 : \u30CB\u30E5\u30FC\u30B9 : \u30AB\u30CA\u30ED\u30B3 -- \u795E\u5948\u5DDD\u65B0\u805E\u793E http:\/\/t.co\/cgfHdlw7 via @KanalocoLocal",
    "id" : 231189553162108928,
    "created_at" : "2012-08-03 00:47:39 +0000",
    "user" : {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "protected" : false,
      "id_str" : "157989076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567650679301210115\/Z61ZaG8t_normal.jpeg",
      "id" : 157989076,
      "verified" : false
    }
  },
  "id" : 231190399706873856,
  "created_at" : "2012-08-03 00:51:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u3058\u308A\u3002",
      "screen_name" : "hijityeee",
      "indices" : [ 0, 10 ],
      "id_str" : "455641948",
      "id" : 455641948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231185793392185344",
  "geo" : { },
  "id_str" : "231185935038038016",
  "in_reply_to_user_id" : 455641948,
  "text" : "@hijityeee \u304A\u5927\u4E8B\u306B\u2026",
  "id" : 231185935038038016,
  "in_reply_to_status_id" : 231185793392185344,
  "created_at" : "2012-08-03 00:33:16 +0000",
  "in_reply_to_screen_name" : "hijityeee",
  "in_reply_to_user_id_str" : "455641948",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231078128032837632",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u75C5\u307F\u4E0A\u304C\u308A\u3060\u3063\u305F\uFF0E\u5FD8\u308C\u304B\u3051\u3066\u305F\uFF0E\u5BDD\u307E\u3059\uFF0E",
  "id" : 231078128032837632,
  "created_at" : "2012-08-02 17:24:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231077661907251201",
  "text" : "\u3053\u308C\u3060\u308C\u304B\u307E\u3068\u3081\u4F5C\u3063\u3066\u304F\u308C\u306A\u3044\u304B\u306A\u30FC\uFF08\u6BBF\u4E0B\u306E\u9061\u53CA\u3075\u3041\u307C\u3092\u773A\u3081\u306A\u304C\u3089",
  "id" : 231077661907251201,
  "created_at" : "2012-08-02 17:23:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30BB\u30F3\u30B1\u30A4",
      "screen_name" : "a33554432",
      "indices" : [ 0, 10 ],
      "id_str" : "97614100",
      "id" : 97614100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231076293649776640",
  "geo" : { },
  "id_str" : "231076372838244352",
  "in_reply_to_user_id" : 97614100,
  "text" : "@a33554432 (\u65E2\u51FA\u2026\u3068\u306F\u8A00\u308F\u306A\u3044\u3067\u7F6E\u304F\u304B\uFF0E)",
  "id" : 231076372838244352,
  "in_reply_to_status_id" : 231076293649776640,
  "created_at" : "2012-08-02 17:17:55 +0000",
  "in_reply_to_screen_name" : "a33554432",
  "in_reply_to_user_id_str" : "97614100",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron kul",
      "screen_name" : "kul_Ron",
      "indices" : [ 0, 8 ],
      "id_str" : "2909728068",
      "id" : 2909728068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231076121616187392",
  "geo" : { },
  "id_str" : "231076254584037376",
  "in_reply_to_user_id" : 486743999,
  "text" : "@kuL_Ron \u306F\u3044",
  "id" : 231076254584037376,
  "in_reply_to_status_id" : 231076121616187392,
  "created_at" : "2012-08-02 17:17:26 +0000",
  "in_reply_to_screen_name" : "Ronald_KUL",
  "in_reply_to_user_id_str" : "486743999",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231075967144194049",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B...\u30D5\u30A9\u30ED\u30EF\u30FC\u6E1B\u3063\u3066\u306A\u3044\u3068\u3044\u3044\u306A\u30FC\uFF08\u3057\u308D\u3081",
  "id" : 231075967144194049,
  "created_at" : "2012-08-02 17:16:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231075762789298176",
  "text" : "\u7D50\u5C40\u3053\u306E\u3069\u3093\u3069\u3093\u96D1\u306B\u306A\u3063\u3066\u3044\u304FTL\u3067\u751F\u304D\u6B8B\u308B\u306E\u306F\u3044\u3064\u3082\u306E\u30E1\u30F3\u30D0\u30FC\u2026",
  "id" : 231075762789298176,
  "created_at" : "2012-08-02 17:15:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231075118435168256",
  "text" : "\u307E\u3041\uFF0E\uFF0E\uFF0E\u305D\u308D\u305D\u308D\u843D\u3061\u7740\u3053\u3046\u304B\uFF0E",
  "id" : 231075118435168256,
  "created_at" : "2012-08-02 17:12:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u81EA\u5206",
      "indices" : [ 11, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231074128977858560",
  "text" : "\u5F15\u304D\u91D1\u5F3E\u3044\u305F\u306E\u8AB0\u3060\u3088 #\u81EA\u5206",
  "id" : 231074128977858560,
  "created_at" : "2012-08-02 17:09:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 7, 18 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u602A\u6587",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231073912224636929",
  "text" : "#\u602A\u6587 RT @hrizm_math: \u6587\u3076(^^)\u6587\u6587\u3076(^^)\u3093\u3076(^\u3076^)\u6587(^^)(\u6587^^)\u3076\u3076(^^)\u3093\u3093\u6587(^^\u6587)(^^)\u6587\u6587(^\u3076\u3076\u3076^)\u3093\u6587\u3076\u3076\u3093\u3076(^^)\u3076\u3076\u6587\u3076\u3093\u3076 #(^^)",
  "id" : 231073912224636929,
  "created_at" : "2012-08-02 17:08:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DhiArk",
      "screen_name" : "dhi_ark",
      "indices" : [ 3, 11 ],
      "id_str" : "116467602",
      "id" : 116467602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE\u6587",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231073667847712768",
  "text" : "RT @dhi_ark: \u30E4\u30C9\u30F3\u300C\u3069\u3084\u300D #\u56DE\u6587",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sourceforge.jp\/projects\/opentween\/\" rel=\"nofollow\"\u003EOpenTween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u56DE\u6587",
        "indices" : [ 8, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231071835096227840",
    "text" : "\u30E4\u30C9\u30F3\u300C\u3069\u3084\u300D #\u56DE\u6587",
    "id" : 231071835096227840,
    "created_at" : "2012-08-02 16:59:53 +0000",
    "user" : {
      "name" : "DhiArk",
      "screen_name" : "dhi_ark",
      "protected" : false,
      "id_str" : "116467602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538434634803974144\/ixl40f-T_normal.png",
      "id" : 116467602,
      "verified" : false
    }
  },
  "id" : 231073667847712768,
  "created_at" : "2012-08-02 17:07:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6C17\u5206",
      "indices" : [ 22, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231073454554759170",
  "text" : "\u306A\u3093\u3067\u3053\u3093\u306ATL\u306B\u306A\u3063\u3061\u3083\u3063\u305F\u3093\u3060\u308D\u3046\u306A\u30FC #\u6C17\u5206",
  "id" : 231073454554759170,
  "created_at" : "2012-08-02 17:06:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7CD6\u5206",
      "indices" : [ 36, 39 ]
    }, {
      "text" : "\u7B49\u5206",
      "indices" : [ 40, 43 ]
    }, {
      "text" : "\u5F53\u5206",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231073255514075136",
  "text" : "4\u4EBA\u3044\u305F\u3068\u306F\u3044\u3048\u30DB\u30FC\u30EB\u306E\u30B1\u30FC\u30AD\u4E00\u3064\u5206\u98DF\u3079\u305F\u3057\u3057\u3070\u3089\u304F\u306F\u63A7\u3048\u306A\u304D\u3083\u304B\u306A\u3041 #\u7CD6\u5206 #\u7B49\u5206 #\u5F53\u5206",
  "id" : 231073255514075136,
  "created_at" : "2012-08-02 17:05:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3055\u304B\u306A\u6587",
      "indices" : [ 7, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231072936499499008",
  "text" : "\u3046\u304A\u30FC\u3046\u304A\u30FC #\u3055\u304B\u306A\u6587",
  "id" : 231072936499499008,
  "created_at" : "2012-08-02 17:04:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u8A02\u6B63\u6587",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231072865812881408",
  "text" : "\u3042\uFF0C\u7A7A\u98DB\u3076\u866B\u306A\u3089\uFF0E #\u8A02\u6B63\u6587",
  "id" : 231072865812881408,
  "created_at" : "2012-08-02 17:03:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231072761995468800",
  "text" : "\u866B\u306A\u3089\u4F55\u3067\u3082\u3044\u3044\u3058\u3083\u306A\u3044\u3067\u3059\u304B\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 231072761995468800,
  "created_at" : "2012-08-02 17:03:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u65B0\u805E",
      "indices" : [ 9, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231072637881823232",
  "text" : "\u7A93\u62ED\u304F\u3068\u304D\u306B\u4FBF\u5229 #\u65B0\u805E",
  "id" : 231072637881823232,
  "created_at" : "2012-08-02 17:03:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u7591\u554F\u6587",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231072211648278529",
  "geo" : { },
  "id_str" : "231072287246405633",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u50D5\u306E\u306F\u3042\u304F\u307E\u3067 #\u7591\u554F\u6587",
  "id" : 231072287246405633,
  "in_reply_to_status_id" : 231072211648278529,
  "created_at" : "2012-08-02 17:01:41 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u534A\u5206",
      "indices" : [ 4, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231072060544270336",
  "text" : "1\/\uFF12 #\u534A\u5206",
  "id" : 231072060544270336,
  "created_at" : "2012-08-02 17:00:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231071897310351360",
  "text" : "\u3082\u3046\u6587\u3063\u3066\u4ED8\u3044\u305F\u3089\u306A\u3093\u3067\u3082\u3044\u3044\u3093\u3058\u3083",
  "id" : 231071897310351360,
  "created_at" : "2012-08-02 17:00:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u8B1D\u7F6A\u6587",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231071667294720001",
  "geo" : { },
  "id_str" : "231071739147345920",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3059\u307F\u307E\u305B\u3093 #\u8B1D\u7F6A\u6587",
  "id" : 231071739147345920,
  "in_reply_to_status_id" : 231071667294720001,
  "created_at" : "2012-08-02 16:59:30 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231071681920249856",
  "text" : "@ayuretti \u6C17\u306B\u305B\u305A\u30AC\u30F3\u30AC\u30F3\u884C\u304D\u307E\u3057\u3087\u3046\uFF0E\u3053\u3063\u3061\u3082\u3046\u5927\u5909\u306A\u3053\u3068\u306B\u306A\u3063\u3066\u308B\u306E\u3067\uFF0E",
  "id" : 231071681920249856,
  "created_at" : "2012-08-02 16:59:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231071324775268352",
  "text" : "\u77E5\u3063\u3066\u305F\u3088\uFF0E\u89AA\u65B9\u3060\u3088\u306D\uFF0E",
  "id" : 231071324775268352,
  "created_at" : "2012-08-02 16:57:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u304A\u3084\u6587",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231071294551101441",
  "text" : "\u300C\u304A\u3084\uFF1F\u7A7A\u304B\u3089\u5973\u306E\u5B50\u304C\uFF1F\u300D #\u304A\u3084\u6587",
  "id" : 231071294551101441,
  "created_at" : "2012-08-02 16:57:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231071175646797825",
  "text" : "\u53B3\u5BC6\u306B\u306F\u7121\u3044\u6587\u3067\u306F\u306A\u3044\u5206\u30A2\u30EC",
  "id" : 231071175646797825,
  "created_at" : "2012-08-02 16:57:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231070832728870912",
  "geo" : { },
  "id_str" : "231070879554101248",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u3055\u3044\u3067\u3059\u304B\u2026",
  "id" : 231070879554101248,
  "in_reply_to_status_id" : 231070832728870912,
  "created_at" : "2012-08-02 16:56:05 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231070282671083520",
  "text" : "\u3086\u308B\u307C\uFF1A\u30C8\u30DE\u30C8\u3092\u7E8F\u3046\u72B6\u6CC1",
  "id" : 231070282671083520,
  "created_at" : "2012-08-02 16:53:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231070177742180354",
  "text" : "\u72B6\u6CC1\u304C\u60F3\u5B9A\u3067\u304D\u306A\u3044\uFF0C",
  "id" : 231070177742180354,
  "created_at" : "2012-08-02 16:53:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE\u6587",
      "indices" : [ 9, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231070157286555650",
  "text" : "\u3046\uFF0C\u30C8\u30DE\u30C8\u7E8F\u3046\uFF1F #\u56DE\u6587",
  "id" : 231070157286555650,
  "created_at" : "2012-08-02 16:53:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231069839710621696",
  "text" : "\u3044\u3044\u52A0\u6E1B\u7121\u7406\u304C\u3042\u308B\uFF0E\u3082\u3063\u3068\u3084\u308C\uFF0E",
  "id" : 231069839710621696,
  "created_at" : "2012-08-02 16:51:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231069528698806272",
  "text" : "\u306A\u3093\u3060\u3053\u308C",
  "id" : 231069528698806272,
  "created_at" : "2012-08-02 16:50:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5916\u805E",
      "indices" : [ 23, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231069276914728962",
  "text" : "\u3060\u3093\u3060\u3093\u96D1\u306B\u306A\u3063\u3066\u3044\u304F\u69D8\u3092\u3054\u89A7\u304F\u3060\u3055\u3044\uFF0E\u6065\u3082 #\u5916\u805E \u3082\u306A\u3044",
  "id" : 231069276914728962,
  "created_at" : "2012-08-02 16:49:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5185\u5206",
      "indices" : [ 15, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231068960173473792",
  "text" : "A----P-------B #\u5185\u5206",
  "id" : 231068960173473792,
  "created_at" : "2012-08-02 16:48:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5916\u5206",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231068900266237953",
  "text" : "A-----B-----------Q  #\u5916\u5206",
  "id" : 231068900266237953,
  "created_at" : "2012-08-02 16:48:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4F1A\u8A71\u6587",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231068744191967233",
  "text" : "\u300C\u99C5\u306B\u306F\u3069\u3046\u3084\u3063\u3066\u884C\u3063\u305F\u3089\u3044\u3044\u306E\u304B\u6559\u3048\u3066\u304F\u3060\u3055\u3044\u300D #\u4F1A\u8A71\u6587",
  "id" : 231068744191967233,
  "created_at" : "2012-08-02 16:47:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231068539665129473",
  "text" : "@ayuretti \u3053\u3063\u3061\u96D1\u306A\u56DE\u6587\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306B\u306A\u3063\u3066\u3066\u3061\u3087\u3063\u3068\u9762\u767D\u3044\uFF0E",
  "id" : 231068539665129473,
  "created_at" : "2012-08-02 16:46:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231068274446716929",
  "geo" : { },
  "id_str" : "231068449500188672",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u3078\u3047\uFF0C\u68D2\u306D\u2026\uFF08\u68D2",
  "id" : 231068449500188672,
  "in_reply_to_status_id" : 231068274446716929,
  "created_at" : "2012-08-02 16:46:26 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231068138475753472",
  "geo" : { },
  "id_str" : "231068214178762752",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u30D2\u30F3\u30C8\uFF1A\u830E",
  "id" : 231068214178762752,
  "in_reply_to_status_id" : 231068138475753472,
  "created_at" : "2012-08-02 16:45:29 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231068151553597440",
  "text" : "\uFF08\u3067\u3082\uFF0C\u3053\u306ETL\u306E\u9069\u5F53\u306A\u611F\u3058\uFF0C\u4E0D\u601D\u8B70\u3068\u5ACC\u3044\u3058\u3083\u306A\u3044\u305C\uFF01\uFF09",
  "id" : 231068151553597440,
  "created_at" : "2012-08-02 16:45:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231068094066475008",
  "text" : "\u306A\u3093\u3067\u3082\u3042\u308A\u304B",
  "id" : 231068094066475008,
  "created_at" : "2012-08-02 16:45:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231067997656203264",
  "geo" : { },
  "id_str" : "231068050529611777",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u305D\u308C\u306A\u30FC\u2026",
  "id" : 231068050529611777,
  "in_reply_to_status_id" : 231067997656203264,
  "created_at" : "2012-08-02 16:44:50 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231067951162339328",
  "text" : "\u4F55\u3067\u3082\u306A\u3044\u30DD\u30B9\u30C8\u306B\u56DE\u6587\u3063\u3066\u3064\u3051\u308B\u306E\u30BA\u30EB\u3044\uFF0E",
  "id" : 231067951162339328,
  "created_at" : "2012-08-02 16:44:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 15, 26 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE\u6587",
      "indices" : [ 42, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231067736376229888",
  "geo" : { },
  "id_str" : "231067845474258944",
  "in_reply_to_user_id" : 230481483,
  "text" : "\u56DE\u6587\u3068\u306F\u306A\u3093\u3060\u3063\u305F\u306E\u304B QT @sakanafsku: \u8AB0\u304B\u30EC\u30DD\u30FC\u30C8\u66F8\u3044\u3066\u304F\u3060\u3055\u3044 #\u56DE\u6587",
  "id" : 231067845474258944,
  "in_reply_to_status_id" : 231067736376229888,
  "created_at" : "2012-08-02 16:44:02 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231067404267036673",
  "geo" : { },
  "id_str" : "231067730852319232",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3067\u3082\u304D\u3063\u3068\u5352\u696D\u306B\u5FC5\u8981\u306A\u5358\u4F4D\u6570\u306F\u305D\u308C\u306B\u5FDC\u3058\u3066\u7206\u767A\u7684\u306B\u5897\u3048\u308B\u306E\u3067\u7D50\u5C40\u52C9\u5F37\u3057\u306A\u3044\u3068\u3044\u3051\u306A\u3044\u3067\u3059\u306D\uFF08\u771F\u9854",
  "id" : 231067730852319232,
  "in_reply_to_status_id" : 231067404267036673,
  "created_at" : "2012-08-02 16:43:34 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 23, 33 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231067402044076032",
  "text" : "\u56DE\u6587\u3063\u3058\u3083\u306A\uFF5E\u3044 QT @ayuretti: @end313124 \u30DF\u30E3\u30F3\u30DE\u30FC\u30DF\u30E3\u30F3\u30DE\u30FC",
  "id" : 231067402044076032,
  "created_at" : "2012-08-02 16:42:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231067176856059904",
  "geo" : { },
  "id_str" : "231067300365737984",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u5358\u4F4D\u7206\u6483\u51FA\u6765\u308B\u30AF\u30E9\u30B7\u30B9\u958B\u767A\u306F\u3088",
  "id" : 231067300365737984,
  "in_reply_to_status_id" : 231067176856059904,
  "created_at" : "2012-08-02 16:41:52 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231067054936059905",
  "text" : "@ayuretti \u30C1\u30EA\u96E2\u5730",
  "id" : 231067054936059905,
  "created_at" : "2012-08-02 16:40:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231066743114698752",
  "geo" : { },
  "id_str" : "231066830284931072",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3044\u3048\u3044\u3048\u30FC",
  "id" : 231066830284931072,
  "in_reply_to_status_id" : 231066743114698752,
  "created_at" : "2012-08-02 16:40:00 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE\u6587",
      "indices" : [ 11, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231066803357495298",
  "text" : "\u3042\uFF0C\u30A4\u30BF\u30EA\u30A2\u30EA\u30BF\u30A4\u30A2\uFF0E#\u56DE\u6587",
  "id" : 231066803357495298,
  "created_at" : "2012-08-02 16:39:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231066523765178370",
  "text" : "\u30B9\u30A4\u30B9\u30A4\u9162",
  "id" : 231066523765178370,
  "created_at" : "2012-08-02 16:38:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231066482036056064",
  "text" : "\u30B9\u30A4\u30B9\u30A4\u5DE3\uFF1F",
  "id" : 231066482036056064,
  "created_at" : "2012-08-02 16:38:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231066382916268032",
  "text" : "@ayuretti \u30C9\u30A4\u30C4\u4E95\u6238",
  "id" : 231066382916268032,
  "created_at" : "2012-08-02 16:38:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 7, 23 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 25, 35 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u602A\u6587",
      "indices" : [ 0, 3 ]
    }, {
      "text" : "\u56DE\u6587",
      "indices" : [ 58, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231065987439538176",
  "text" : "#\u602A\u6587 RT @Jelly_in_a_tank: @end313124 \u3046\u308F\u3001\u3048\u3093\u3069\u3055\u3093\u3053\u308F\u3002\uFF7A\uFF9D\uFF7B\uFF84\uFF9E\uFF9D\uFF74\uFF9C\uFF73\u3002 #\u56DE\u6587",
  "id" : 231065987439538176,
  "created_at" : "2012-08-02 16:36:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231065906393006080",
  "text" : "\u67D4\u8EDF\u3055\u3068\u304B\u3063\u3066\u5927\u4E8B\u3060\u3068\u601D\u3046\u3093\u3060\uFF0E\u76F8\u624B\u306B\u540C\u610F\u306F\u5FC5\u305A\u3057\u3082\u3057\u306A\u304F\u3066\u3044\u3044\u3051\u308C\u3069\uFF0C\u305D\u306E\u5B58\u5728\u3092\u6839\u3053\u305D\u304E\u5426\u5B9A\u3057\u3066\u3057\u307E\u3046\u3088\u3046\u306A\u614B\u5EA6\u306F\u3061\u3087\u3063\u3068\uFF0E\uFF0E\uFF0E",
  "id" : 231065906393006080,
  "created_at" : "2012-08-02 16:36:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231065635986239488",
  "text" : "\u504F\u898B\u3092\u6301\u3064\u306E\u306F\u4ED5\u65B9\u306A\u3044\u3051\u308C\u3069\uFF0C\u305D\u308C\u3092\u6307\u6458\u3055\u308C\u305F\u3068\u304D\u306B\u614B\u5EA6\u3092\u6539\u3081\u308B\u52AA\u529B\u3092\u51FA\u6765\u306A\u3044\u306E\u306F\u30C0\u30E1\u3060\u306D\uFF0E\u3053\u308C\u8A00\u3063\u3066\u304B\u3089\u30D6\u30ED\u30C3\u30AF\u3059\u3079\u304D\u3060\u3063\u305F\uFF0E",
  "id" : 231065635986239488,
  "created_at" : "2012-08-02 16:35:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231065365130645504",
  "text" : "\u3048\uFF0C\u3044\u3084\uFF0C\u9055\u3046\u3088\u3055\u3089\u3057RT\u3068\u304B\u3058\u3083\u306A\u3044\u3063\u3066\u3070\uFF0C\u307B\u3093\u3068\u3060\u3088\uFF0C\u4FE1\u3058\u3066\u3088\uFF0E",
  "id" : 231065365130645504,
  "created_at" : "2012-08-02 16:34:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231065308041973760",
  "text" : "\u4FFA\u306F\u8A55\u4FA1\u3059\u308B\uFF08\u68D2\u8AAD\u307F",
  "id" : 231065308041973760,
  "created_at" : "2012-08-02 16:33:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231064855929556992",
  "text" : "\u3093\u30FC\u3053\u308C\u306F\u30C0\u30E1\u3060\u306D\uFF0E\u6B8B\u5FF5\u3060\u3060\u3051\u308C\u3069\uFF0E",
  "id" : 231064855929556992,
  "created_at" : "2012-08-02 16:32:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    }, {
      "name" : "\u306D\u3080\u308ABABEL",
      "screen_name" : "CKPOMHOCTb",
      "indices" : [ 11, 22 ],
      "id_str" : "190136474",
      "id" : 190136474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231064489087365121",
  "geo" : { },
  "id_str" : "231064676082016257",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 @CKPOMHOCTb \u3076\u3063\u3061\u3083\u3051\u300C\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01\u300D\u300C\u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01\u300D\u306E\u3084\u308A\u3068\u308A\u3092\u3057\u305F\u304F\u3066\u98F2\u3080\u98F2\u307F\u7269\u3067\u3059\uFF0E",
  "id" : 231064676082016257,
  "in_reply_to_status_id" : 231064489087365121,
  "created_at" : "2012-08-02 16:31:26 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231064033820807168",
  "geo" : { },
  "id_str" : "231064173755375616",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u56DE\u6587\u305D\u306E\u3082\u306E\u306E\u51FA\u6765\u306F\u514E\u3082\u89D2\u5BFE\u5FDC\u306F\u3068\u308C\u3066\u3044\u308B(\u89E3\u8AAC\u3057\u306A\u3044\u65B9\u304C\u3088\u304B\u3063\u305F\uFF0E)",
  "id" : 231064173755375616,
  "in_reply_to_status_id" : 231064033820807168,
  "created_at" : "2012-08-02 16:29:26 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231063746355798016",
  "geo" : { },
  "id_str" : "231063903705128960",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 231063903705128960,
  "in_reply_to_status_id" : 231063746355798016,
  "created_at" : "2012-08-02 16:28:22 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231063717171826690",
  "text" : "\u5E7B\u60F3\u2026",
  "id" : 231063717171826690,
  "created_at" : "2012-08-02 16:27:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u56DE\u6587",
      "indices" : [ 27, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231063505376256001",
  "text" : "\u30A4\u30E9\u2026\u30AD\u30B9\u5ACC\u3044 RT @ayuretti: \u30AD\u30B9\u597D\u304D #\u56DE\u6587",
  "id" : 231063505376256001,
  "created_at" : "2012-08-02 16:26:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231063282654523392",
  "text" : "\u304B\u308C\u3053\u308C\u4E00\u30F6\u6708\u304F\u3089\u3044\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u98F2\u3093\u3067\u306A\u3044\u306E\u304B\uFF08Twilog\u8ABF\u3079\uFF09",
  "id" : 231063282654523392,
  "created_at" : "2012-08-02 16:25:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231062652368060416",
  "text" : "\u3055\u3063\u304D\u306E\u30EC\u30DD\u30FC\u30C8\u306E\u30DD\u30B9\u30C8\u5730\u5473\u306B\u4F38\u3073\u3066\u3066\u3073\u3063\u304F\u308A\u3057\u3066\u3044\u308B\uFF0E\u306A\u3093\u3067\u3053\u308C\u304C\u4F38\u3073\u308B\u306E\u3055\uFF0E\u307E\u3041\u5730\u5473\u3060\u3051\u308C\u3069\uFF0E",
  "id" : 231062652368060416,
  "created_at" : "2012-08-02 16:23:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231062363099496448",
  "text" : "\u7A81\u7136\u306E\u25CB\u25CB\u306F\u4F7F\u3044\u3059\u304E\u306F\u826F\u304F\u306A\u3044\u306D\uFF08\u771F\u9854",
  "id" : 231062363099496448,
  "created_at" : "2012-08-02 16:22:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u985E\u660C\u4FCA",
      "screen_name" : "ohruimasatoshi",
      "indices" : [ 0, 15 ],
      "id_str" : "1454075539",
      "id" : 1454075539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231062288478633986",
  "text" : "@OhruiMasatoshi \u6848\u5916\u305D\u3046\u3067\u3082\u306A\u3044\u3067\u3059\u3088\u2026",
  "id" : 231062288478633986,
  "created_at" : "2012-08-02 16:21:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231062133771743233",
  "text" : "\u5927\u76EE\u306B\u898B\u305F\u3089\u826F\u304F\u898B\u3048\u308B\u3088\u306D\uFF0E",
  "id" : 231062133771743233,
  "created_at" : "2012-08-02 16:21:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231062084245393411",
  "text" : "\u591A\u3081\u3060\u3088\uFF0C\u5927\u76EE\u3063\u3066\u306A\u3093\u3060\u3088\uFF0E\u5927\u76EE\u306B\u898B\u308D\u3088\uFF0E",
  "id" : 231062084245393411,
  "created_at" : "2012-08-02 16:21:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231062021687345152",
  "text" : "\u5FC3\u306A\u3057\u304B\u30CD\u30BF\u30DD\u30B9\u30C8\u5927\u76EE\u306B\u304A\u9001\u308A\u3057\u3066\u304A\u308A\u307E\u3059\u304A\u76F8\u624B\u306Fend\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F \n\uFF1E \u7A81\u7136\u306E\u7D42\u4E86\uFF1C\n\uFFE3Y^Y^Y^Y^Y^\uFFE3",
  "id" : 231062021687345152,
  "created_at" : "2012-08-02 16:20:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231061688684785664",
  "text" : "\u30D3\u30FC\u30E0\u51FA\u305B\u308B\u3088\u3046\u306B\u306A\u308B\u306A\u3089\u30D3\u30FC\u30E0\u79D1\u5B66\u5C65\u4FEE\u3057\u3088\u3046\u304B\u3068\u601D\u3063\u305F\u3051\u308C\u3069\u305D\u3046\u3044\u3046\u610F\u5473\u5408\u3044\u306A\u3089\u3084\u3081\u3066\u304A\u304F\u304B\u30FC",
  "id" : 231061688684785664,
  "created_at" : "2012-08-02 16:19:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5343\u53CD\u7530\u3048\u308B\u3068\u7D50\u5A5A\u3057\u305F\u3044",
      "screen_name" : "Xe_no",
      "indices" : [ 0, 6 ],
      "id_str" : "146107191",
      "id" : 146107191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231061449206812672",
  "geo" : { },
  "id_str" : "231061589573390336",
  "in_reply_to_user_id" : 146107191,
  "text" : "@Xe_no \u306A\uFF0C\u306A\u308B\u307B\u3069(\u771F\u9854",
  "id" : 231061589573390336,
  "in_reply_to_status_id" : 231061449206812672,
  "created_at" : "2012-08-02 16:19:10 +0000",
  "in_reply_to_screen_name" : "Xe_no",
  "in_reply_to_user_id_str" : "146107191",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u985E\u660C\u4FCA",
      "screen_name" : "ohruimasatoshi",
      "indices" : [ 0, 15 ],
      "id_str" : "1454075539",
      "id" : 1454075539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231061390083903489",
  "text" : "@OhruiMasatoshi \u82B1\u706B\u3084\u3089\u9A12\u3050\u306E\u3092\u3084\u3081\u3066\u6B32\u3057\u3044\u306E\u306F\u540C\u610F\u3060\u3051\u308C\u3069\uFF0C\u6771\u5927\u751F\u3060\u3063\u3066\u4EAC\u5927\u751F\u3060\u3063\u3066\u591C\u9A12\u3044\u3060\u308A\u306F\u3059\u308B\u3093\u3060\u304B\u3089\u5F8C\u8005\u306F\u504F\u898B\u306A\u3093\u3058\u3083",
  "id" : 231061390083903489,
  "created_at" : "2012-08-02 16:18:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5343\u53CD\u7530\u3048\u308B\u3068\u7D50\u5A5A\u3057\u305F\u3044",
      "screen_name" : "Xe_no",
      "indices" : [ 0, 6 ],
      "id_str" : "146107191",
      "id" : 146107191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231061054820585472",
  "geo" : { },
  "id_str" : "231061139436486657",
  "in_reply_to_user_id" : 146107191,
  "text" : "@Xe_no \u30D3\u30FC\u30E0\u79D1\u5B66\u53D6\u3063\u3066\u308B\u4EBA\u3063\u3066\u30D3\u30FC\u30E0\u51FA\u305B\u308B\u3088\u3046\u306B\u306A\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 231061139436486657,
  "in_reply_to_status_id" : 231061054820585472,
  "created_at" : "2012-08-02 16:17:23 +0000",
  "in_reply_to_screen_name" : "Xe_no",
  "in_reply_to_user_id_str" : "146107191",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231060952194363392",
  "text" : "\u307E\u3041\u30AF\u30AA\u30EA\u30C6\u30A3\u306F\u4FDD\u8A3C\u3057\u304B\u306D\u308B\u304C\u306D\uFF08",
  "id" : 231060952194363392,
  "created_at" : "2012-08-02 16:16:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231060793767124992",
  "text" : "\u300E\u30EC\u30DD\u30FC\u30C8\u306A\u3093\u3066\u52E2\u3044\u306A\u3093\u3060\uFF01\u305D\u306E\u6C17\u306B\u306A\u308C\u3070\u8AB0\u3060\u3063\u3066\u66F8\u3051\u308B\uFF01\u300F",
  "id" : 231060793767124992,
  "created_at" : "2012-08-02 16:16:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231060514661355520",
  "text" : "\u79C1\u306F\u751F\u304D\u3066\u3044\u307E\u3059\uFF0E",
  "id" : 231060514661355520,
  "created_at" : "2012-08-02 16:14:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231060459464318977",
  "text" : "DEAD END...\n\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F \n\uFF1E \u7A81\u7136\u306E\u6B7B\u5F8C\uFF1C\n \uFFE3Y^Y^Y^Y^Y^\uFFE3",
  "id" : 231060459464318977,
  "created_at" : "2012-08-02 16:14:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231058670472003584",
  "text" : "\u53CB\u4EBAA\u304B\u3089\u53CB\u4EBAB\u3078\u30E1\u30FC\u30EB\nB\u300C\u307E\u30FC\u3058\u3083\u3093\u3084\u308A\u305F\u3044\u300D\nA\u300C\u7CFB\u767B\u9332\u306B\u5FC5\u8981\u306A\u5F79\u306F\u63C3\u3063\u3066\u308B\u306E\uFF1F\u300D\nB\u300C\u6CE3\u3044\u305F\u300D\nA\u300C\u9CF4\u3044\u305F\u3089\u85E9\u6570\u4E0B\u304C\u308B\u3088\uFF1F\u300D",
  "id" : 231058670472003584,
  "created_at" : "2012-08-02 16:07:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u985E\u660C\u4FCA",
      "screen_name" : "ohruimasatoshi",
      "indices" : [ 0, 15 ],
      "id_str" : "1454075539",
      "id" : 1454075539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231057494762459137",
  "text" : "@OhruiMasatoshi \u685C\u306E\u5B63\u7BC0\u4EE5\u5916\u306F\u9759\u304B\u306A\u3093\u3067\u3059\u3051\u3069\u306D\u3047\u2026",
  "id" : 231057494762459137,
  "created_at" : "2012-08-02 16:02:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u985E\u660C\u4FCA",
      "screen_name" : "ohruimasatoshi",
      "indices" : [ 0, 15 ],
      "id_str" : "1454075539",
      "id" : 1454075539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231054629369176065",
  "text" : "@OhruiMasatoshi \u3044\u3084\uFF0C\u3059\u307F\u307E\u305B\u3093\uFF0C\u50D5\u304C\u305D\u306E\u8FBA\u308A\u51FA\u8EAB\u306A\u3082\u306E\u3067\u3064\u3044\u8FD1\u3044\u306E\u304B\u306A\u30FC\uFF0C\u3068",
  "id" : 231054629369176065,
  "created_at" : "2012-08-02 15:51:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u985E\u660C\u4FCA",
      "screen_name" : "ohruimasatoshi",
      "indices" : [ 0, 15 ],
      "id_str" : "1454075539",
      "id" : 1454075539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231051356440518658",
  "text" : "@OhruiMasatoshi \u3082\u3057\u304B\u3057\u3066\uFF1AI\u982D\u516C\u5712",
  "id" : 231051356440518658,
  "created_at" : "2012-08-02 15:38:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230995115844435968",
  "geo" : { },
  "id_str" : "231049684448321536",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u9045\u304F\u306A\u3063\u3066\u3054\u3081\u3093\u3088\uFF0E\u30B5\u30A4\u30BA\u306B\u306F\u4F9D\u308B\u3051\u308C\u3069\u4E8C\u4EBA\u2026\u3058\u3083\u306A\u3044\u3088\u306D\uFF1F",
  "id" : 231049684448321536,
  "in_reply_to_status_id" : 230995115844435968,
  "created_at" : "2012-08-02 15:31:52 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231048904131637248",
  "geo" : { },
  "id_str" : "231049227562795008",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u4ECA\u65E5\u306E\u30AB\u30E9\u30AA\u30B1\u306A\u306E\u3067\u3059\u304C\u6050\u308D\u3057\u304F\u306E\u3069\u75DB\u3044\u306E\u3068\u30EC\u30DD\u30FC\u30C8\u3092\u6BB2\u6EC5\u3067\u304D\u306A\u304B\u3063\u305F\u306E\u3067\u30D1\u30B9\u3057\u3066\u3082\u5927\u4E08\u592B\u3067\u3057\u3087\u3046\u304B\uFF0E\uFF08\u884C\u304D\u305F\u3044\u306E\u3060\u3051\u308C\u3069\uFF0E\uFF09",
  "id" : 231049227562795008,
  "in_reply_to_status_id" : 231048904131637248,
  "created_at" : "2012-08-02 15:30:03 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231049054635823104",
  "text" : "00:00\u63D0\u51FA\u304B\u3068\u601D\u3063\u3066\u9854\u304C\u84BC\u304F\u306A\u3063\u305F\u30EC\u30DD\u30FC\u30C8\u304C17\uFF1A\uFF10\uFF10\u63D0\u51FA\u3067\u80F8\u3092\u306A\u3067\u304A\u308D\u3059\u5348\u524D0\u6642\u904E\u304E\uFF0E",
  "id" : 231049054635823104,
  "created_at" : "2012-08-02 15:29:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230996466980769792",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 230996466980769792,
  "created_at" : "2012-08-02 12:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230981385748365312",
  "geo" : { },
  "id_str" : "230993434285047809",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u3059\u304D\u3067\u3059\u3088\u30FC",
  "id" : 230993434285047809,
  "in_reply_to_status_id" : 230981385748365312,
  "created_at" : "2012-08-02 11:48:21 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230980084822073344",
  "geo" : { },
  "id_str" : "230980436543819777",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u591A\u52069\u306E\u591C\u304B\u3089\u3044\u308B\u3068\u601D\u3044\u307E\u3059\u300210\u306E\u591C\u306F\u4E88\u5B9A\u5165\u308A\u305D\u3046\u306A\u306E\u3067\u663C\u304B\u3089\u5915\u65B9\u306A\u3089\u3044\u3051\u305D\u3046\u3067\u3059\u3002",
  "id" : 230980436543819777,
  "in_reply_to_status_id" : 230980084822073344,
  "created_at" : "2012-08-02 10:56:42 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230979673738338304",
  "geo" : { },
  "id_str" : "230979912465543168",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u307E\u3041\u6C7A\u307E\u3063\u305F\u3089\u30EA\u30D7\u30E9\u30A4\u4E0B\u3055\u3044\u306A\u30FC",
  "id" : 230979912465543168,
  "in_reply_to_status_id" : 230979673738338304,
  "created_at" : "2012-08-02 10:54:37 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230978904389713920",
  "geo" : { },
  "id_str" : "230979062850535424",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u5834\u6240\u3068\u6642\u9593\u306B\u3088\u308B\u3051\u308C\u3069\u3042\u307E\u308A\u9045\u304F\u306A\u3051\u308C\u3070\u884C\u304D\u305F\u3044\u304B\u3082\u30FC\u3002\u6771\u4EAC\u3060\u3088\u306D\uFF1F",
  "id" : 230979062850535424,
  "in_reply_to_status_id" : 230978904389713920,
  "created_at" : "2012-08-02 10:51:14 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230978458019303424",
  "geo" : { },
  "id_str" : "230978624893906944",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u4F55\u51E6\u306B\uFF1F",
  "id" : 230978624893906944,
  "in_reply_to_status_id" : 230978458019303424,
  "created_at" : "2012-08-02 10:49:30 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230978059921133569",
  "geo" : { },
  "id_str" : "230978295494213634",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve 3\u65E5\u9045\u304B\u3063\u305F\u3089\u30EF\u30F3\u30C1\u30E3\u30F3\u3042\u3063\u305F\u304C\u2026",
  "id" : 230978295494213634,
  "in_reply_to_status_id" : 230978059921133569,
  "created_at" : "2012-08-02 10:48:11 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u30FC",
      "screen_name" : "ellipticurve",
      "indices" : [ 0, 13 ],
      "id_str" : "404669853",
      "id" : 404669853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230977390388596736",
  "geo" : { },
  "id_str" : "230977938064039936",
  "in_reply_to_user_id" : 404669853,
  "text" : "@ellipticurve \u6771\u5927\u306E\u30AA\u30FC\u30D7\u30F3\u30AD\u30E3\u30F3\u30D1\u30B9\u3063\u3066\u3044\u3064\u306A\u3093\u3067\u3059\uFF1F",
  "id" : 230977938064039936,
  "in_reply_to_status_id" : 230977390388596736,
  "created_at" : "2012-08-02 10:46:46 +0000",
  "in_reply_to_screen_name" : "ellipticurve",
  "in_reply_to_user_id_str" : "404669853",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sakanafsku",
      "screen_name" : "sakanafsku",
      "indices" : [ 0, 11 ],
      "id_str" : "2226737970",
      "id" : 2226737970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230974309697482752",
  "geo" : { },
  "id_str" : "230974504682287104",
  "in_reply_to_user_id" : 230481483,
  "text" : "@sakanafsku \u30EC\u30DD\u30FC\u30C8\u3084\u308A\u307E\u3057\u3087\u3046(",
  "id" : 230974504682287104,
  "in_reply_to_status_id" : 230974309697482752,
  "created_at" : "2012-08-02 10:33:07 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230908043645308929",
  "text" : "\u3058\u3085\u308B\u3058\u3085\u308B",
  "id" : 230908043645308929,
  "created_at" : "2012-08-02 06:09:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230901281873616897",
  "text" : "\u98DF\u6B32\u3068\u7A7A\u8179\u611F\u304C\u5168\u7136\u5BFE\u5FDC\u3057\u306A\u3044\uFF0E\uFF0E\uFF0E\u98DF\u6B32\u306A\u3044\u306E\u306B\uFF0C\u7A7A\u8179\u611F\u3060\u3051\u304C\u3042\u308B\u306E\u306F\u6C17\u6301\u3061\u60AA\u3044\uFF0E",
  "id" : 230901281873616897,
  "created_at" : "2012-08-02 05:42:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230900164259373057",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u4E00\u672C\u4E0A\u3052\u3066\uFF0C\u30B5\u30FC\u30AF\u30EB\u306B\u52E4\u3057\u3093\u3067\u5E30\u3063\u3066\u3082\u3046\u4E00\u672C\uFF0C\u304C\u7406\u60F3\u306E\u30B3\u30FC\u30B9\uFF0E",
  "id" : 230900164259373057,
  "created_at" : "2012-08-02 05:37:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230888391896600576",
  "text" : "iid\u304B\u3089\u6EF2\u307F\u51FA\u308B\u5F10\u5BFA\u611F (\u518D\u63B2)",
  "id" : 230888391896600576,
  "created_at" : "2012-08-02 04:50:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230882047760138240",
  "text" : "\u308F\u304B\u3089\u3093\u307D\u3049\u3049\u304A\u3049\u3049\u304A\u304A\u304A\u304A\u3093",
  "id" : 230882047760138240,
  "created_at" : "2012-08-02 04:25:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230879470842691586",
  "text" : "\u9A5A\u304F\u307B\u3069\u5589\u3044\u305F\u3044",
  "id" : 230879470842691586,
  "created_at" : "2012-08-02 04:15:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230879450764562432",
  "text" : "(-k)! \u30B4\u30B4\u30B4\u30B4\u30B4\u30B4\u30B4\u30B4\u2026",
  "id" : 230879450764562432,
  "created_at" : "2012-08-02 04:15:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230847969220509696",
  "geo" : { },
  "id_str" : "230848324100579329",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u305D\u308C\u306A\u3001\u9762\u767D\u3044\u3051\u3069\u3002",
  "id" : 230848324100579329,
  "in_reply_to_status_id" : 230847969220509696,
  "created_at" : "2012-08-02 02:11:44 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230847828270923776",
  "geo" : { },
  "id_str" : "230847939784871936",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u5727\u5012\u7684\uFF01",
  "id" : 230847939784871936,
  "in_reply_to_status_id" : 230847828270923776,
  "created_at" : "2012-08-02 02:10:12 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230842534421753856",
  "text" : "\u3068\u3044\u3046\u304B\u534A\u671F\u3067\u8A9E\u5B66\u4E8C\u3064\u3065\u3064\u5C65\u4FEE\u3067\u304D\u308B\u30B7\u30B9\u30C6\u30E0\u4E0A\u3001\u30AF\u30E9\u30B9\u6307\u5B9A\u306E\u5730\u96F7\u304B\u3082\u3057\u308C\u306A\u3044\u8A9E\u5B66\u3092\u9811\u5F35\u308B\u7406\u7531\u306F\u306A\u3044\u3088\u306A\u30FC",
  "id" : 230842534421753856,
  "created_at" : "2012-08-02 01:48:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230842131571425281",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u30B3\u30FC\u30EB\u306E\u65B9\u304C\u5358\u4F4D\u53D6\u308A\u3084\u3059\u3044\u3057\u52B9\u7387\u7684\u3060\u304B\u3089\u306A\u30FC\u898B\u9003\u3057\u5B89\u5B9A",
  "id" : 230842131571425281,
  "created_at" : "2012-08-02 01:47:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u65E5\u5948@\u898F\u5236",
      "screen_name" : "saionjiasuna1",
      "indices" : [ 0, 14 ],
      "id_str" : "584394248",
      "id" : 584394248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230840794393763842",
  "geo" : { },
  "id_str" : "230841850515320832",
  "in_reply_to_user_id" : 584394248,
  "text" : "@saionjiasuna1 \u3076\u3063\u3061\u3083\u3051\u30CA\u30A4\u30B9\u5224\u65AD\uFF01",
  "id" : 230841850515320832,
  "in_reply_to_status_id" : 230840794393763842,
  "created_at" : "2012-08-02 01:46:00 +0000",
  "in_reply_to_screen_name" : "saionjiasuna1",
  "in_reply_to_user_id_str" : "584394248",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230696493890281472",
  "text" : "\u597D\u304D\u3082\u5ACC\u3044\u3082\u306B\u3093\u3052\u3093\u3060\u3088\u306D",
  "id" : 230696493890281472,
  "created_at" : "2012-08-01 16:08:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E73\u6CC9",
      "screen_name" : "hrizm_math",
      "indices" : [ 0, 11 ],
      "id_str" : "455059629",
      "id" : 455059629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230696169351831552",
  "geo" : { },
  "id_str" : "230696273634799616",
  "in_reply_to_user_id" : 455059629,
  "text" : "@hrizm_math \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 230696273634799616,
  "in_reply_to_status_id" : 230696169351831552,
  "created_at" : "2012-08-01 16:07:32 +0000",
  "in_reply_to_screen_name" : "hrizm_math",
  "in_reply_to_user_id_str" : "455059629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230695911506989057",
  "text" : "\uFF21\u300C\u597D\u304D\u3067\u3059\uFF01\u300D\n\uFF22\u300C\u597D\u304D\u5ACC\u3044\u3059\u308B\u306A\u3088\u300D\n\uFF21\u300C\u300D",
  "id" : 230695911506989057,
  "created_at" : "2012-08-01 16:06:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230695622926286849",
  "text" : "\u597D\u304D\u5ACC\u3044\u306F\u3088\u304F\u306A\u3044\u3063\u3066\u3044\u3046\u3051\u308C\u3069\u3001\u597D\u304D\u306F\u826F\u3044\u3093\u3058\u3083",
  "id" : 230695622926286849,
  "created_at" : "2012-08-01 16:04:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230694524626808833",
  "text" : "\u4ECA\u5EA6\u306F\u8179\u75DB\u306E\u6CE2",
  "id" : 230694524626808833,
  "created_at" : "2012-08-01 16:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230687400903467009",
  "text" : "\u3081\u304D\u3081\u304D\u3068\u4F3C\u305F\u3068\u3053\u308D\u304C\u3042\u308B\u8A9E\u611F\u2026",
  "id" : 230687400903467009,
  "created_at" : "2012-08-01 15:32:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230687091732926466",
  "text" : "\u5DFB\u3044\u3066\u308B\u611F\u3042\u308B\u304B\u306A",
  "id" : 230687091732926466,
  "created_at" : "2012-08-01 15:31:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230686175541739520",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u30A2\u30A4\u30B3\u30F3\u306B\u5BFE\u5FDC\u3059\u308B\u30AD\u30E3\u30C3\u30C1\u30FC\u306A\u64EC\u97F3\u8A9E\u6B32\u3057\u3044\u3088\u306A\u30FC\u3002\u3074\u3088\u3074\u3088\u7136\u308A\u3001\u3058\u3085\u308B\u7136\u308A\u3002",
  "id" : 230686175541739520,
  "created_at" : "2012-08-01 15:27:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230685814726746114",
  "text" : "\u6E26\u6E26\u3067\u3082\u3044\u3044\u306E\u3060\u304C\u3001\u30A6\u30BA\u30A6\u30BA\u611F\u304C\u51FA\u3061\u3083\u3063\u3066\u4E0D\u672C\u610F\u306A\u306E\u3088\u306D\u30FC",
  "id" : 230685814726746114,
  "created_at" : "2012-08-01 15:25:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230685577056501760",
  "text" : "\u307E\u3058\u304B\u30FC\u3002\u3058\u3083\u3042\u3093\u307E\u308A\u3050\u308B\u3050\u308B\u8A00\u308F\u306A\u3044\u65B9\u304C\u826F\u3044\u306E\u304B\u306A\u30FC\u3002",
  "id" : 230685577056501760,
  "created_at" : "2012-08-01 15:25:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308B\u304F\u308B(\u3064\u3044\u304D\u3093\u3057\u305F\u3044)",
      "screen_name" : "KURUKURU888333",
      "indices" : [ 3, 18 ],
      "id_str" : "337502390",
      "id" : 337502390
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 20, 30 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230685484337201153",
  "text" : "RT @KURUKURU888333: @end313124 \u3050\u308B\u3050\u308B\u306F\u5144\u306A\u306E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "230685116429643776",
    "geo" : { },
    "id_str" : "230685278514335746",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u3050\u308B\u3050\u308B\u306F\u5144\u306A\u306E",
    "id" : 230685278514335746,
    "in_reply_to_status_id" : 230685116429643776,
    "created_at" : "2012-08-01 15:23:50 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u304F\u308B\u304F\u308B(\u3064\u3044\u304D\u3093\u3057\u305F\u3044)",
      "screen_name" : "KURUKURU888333",
      "protected" : true,
      "id_str" : "337502390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3042113676\/8172d9b82b4cedcc383d32dad465b6b6_normal.jpeg",
      "id" : 337502390,
      "verified" : false
    }
  },
  "id" : 230685484337201153,
  "created_at" : "2012-08-01 15:24:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230685116429643776",
  "text" : "\u3088\u304F\u8003\u3048\u305F\u3089\u3050\u308B\u3050\u308B\u3063\u3066\u3001\u304F\u308B\u304F\u308B(\u656C\u79F0\u7565)\u3068\u3060\u3060\u304B\u3076\u308A\u3067\u3042\u308B",
  "id" : 230685116429643776,
  "created_at" : "2012-08-01 15:23:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230684790028918784",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u3072\u3069\u304B\u3063\u305F\u3002\u3054\u3081\u3093\u306A\u3055\u3044\u3002",
  "id" : 230684790028918784,
  "created_at" : "2012-08-01 15:21:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230684683518758912",
  "text" : "\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B",
  "id" : 230684683518758912,
  "created_at" : "2012-08-01 15:21:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230668733058789376",
  "text" : "\u9A5A\u304F\u306B\u306F\u5024\u3057\u306A\u3044\u307B\u3069\u306E\u7720\u3055\u306A\u306E\u304B\u3001\u5168\u7136\u7720\u304F\u306A\u3044\u306E\u304B",
  "id" : 230668733058789376,
  "created_at" : "2012-08-01 14:18:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230668583611559937",
  "text" : "\u9A5A\u304F\u307B\u3069\u7720\u304F\u306A\u3044",
  "id" : 230668583611559937,
  "created_at" : "2012-08-01 14:17:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230656307181531136",
  "text" : "\u771F\u306B\u6DF7\u96D1\u3057\u3066\u3044\u308B\u96FB\u8ECA\u306E\u4E2D\u3067\u306F\u3001\u643A\u5E2F\u3055\u3048\u89E6\u308C\u306A\u3044",
  "id" : 230656307181531136,
  "created_at" : "2012-08-01 13:28:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230653980127145985",
  "text" : "\u3068\u3044\u3046\u304B\u6B21\u5143\u304C\u9055\u3046\u3068\u3044\u3046\u30AA\u30C1\u304C\u7528\u610F\u306B\u4E88\u60F3\u3067\u304D\u308B\u30DF\u30B9KU",
  "id" : 230653980127145985,
  "created_at" : "2012-08-01 13:19:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230653826816950272",
  "text" : "\u30DF\u30B9KU\u3068\u304B\u904E\u3061\u306EKU\u304B\u3068",
  "id" : 230653826816950272,
  "created_at" : "2012-08-01 13:18:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230653668301631488",
  "text" : "@ayuretti \u3046\u3080\u3002\u3042\u308A\u304C\u3068\u3046\u3002",
  "id" : 230653668301631488,
  "created_at" : "2012-08-01 13:18:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230653265090596864",
  "text" : "@ayuretti \u4F53\u8ABF\u60AA\u304F\u3066\u3072\u305F\u3059\u3089\u5BDD\u308B\u3068\u3053\u3046\u3044\u3046\u3053\u3068\u306B\u306A\u308B",
  "id" : 230653265090596864,
  "created_at" : "2012-08-01 13:16:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230652872105291776",
  "text" : "\u76EE\u899A\u3081\u305F\u304C\u3001\uFF12\uFF12\u6642",
  "id" : 230652872105291776,
  "created_at" : "2012-08-01 13:15:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3054\u307F\u53CE\u96C6\u8005",
      "screen_name" : "cruz__F",
      "indices" : [ 0, 8 ],
      "id_str" : "2615705894",
      "id" : 2615705894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230562513614422016",
  "geo" : { },
  "id_str" : "230563926092443648",
  "in_reply_to_user_id" : 116143819,
  "text" : "@cruz__F \u5272\u3068\u3044\u3044\u5370\u8C61\u3067\u8A9E\u3089\u308C\u3066\u308B\u30A4\u30E1\u30FC\u30B8\u306A\u3093\u3067\u3059\u3051\u3069\u306D\u3047",
  "id" : 230563926092443648,
  "in_reply_to_status_id" : 230562513614422016,
  "created_at" : "2012-08-01 07:21:38 +0000",
  "in_reply_to_screen_name" : "0scarfe",
  "in_reply_to_user_id_str" : "116143819",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230560594028277760",
  "text" : "\u3061\u3087\u3063\u3068\u65E9\u304F\u3064\u304D\u3059\u304E\u305F\u304B\u306A\u2026\u6D3B\u52D5\u9650\u754C\u304C\u304C\u304C\u304C\u304C",
  "id" : 230560594028277760,
  "created_at" : "2012-08-01 07:08:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230559715187363841",
  "text" : "\u3068\u306F\u8A00\u3048\u30B0\u30B0\u3063\u3066\u898B\u305F\u3089\u307E\u305F\u308F\u304B\u3089\u306A\u304F\u306A\u3063\u305F\u3002\u98A8\u90AA\u306B\u30DD\u30AB\u30EA\u3002\u826F\u3044\u306E\u304B\u3001\u60AA\u3044\u306E\u304B\u3002",
  "id" : 230559715187363841,
  "created_at" : "2012-08-01 07:04:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230559003120394240",
  "text" : "\u4ECA\u307E\u3055\u306B\u30DD\u30AB\u30EA\u98F2\u3093\u3067\u305F",
  "id" : 230559003120394240,
  "created_at" : "2012-08-01 07:02:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u308B\u306B\u3083\u3093@\u30A2\u30E9\u30B5\u30FC(*\u272A\u25BD\u272A)\u2606*\u00B0",
      "screen_name" : "teizuisun",
      "indices" : [ 3, 13 ],
      "id_str" : "217332777",
      "id" : 217332777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230558919171387392",
  "text" : "RT @teizuisun: \u306A\u3093\u304B\u307E\u305F\u708E\u5929\u4E0B\u3067\u306E\u30B9\u30DD\u30FC\u30C4\u6642\u306B\u30DD\u30AB\u30EA\u98F2\u307E\u305B\u305F\u3089\u5B50\u3069\u3082\u304C\u30D5\u30E9\u30D5\u30E9\u306B\u306A\u3063\u305F\u3063\u3066\u9A12\u3044\u3060\u4EBA\u304C\u2026\u3002\u3060\u3081\u3060\u3088\u3042\u308C\u306F\u5065\u5EB7\u4F53\u5411\u3051\u306B\u4F5C\u3063\u3066\u3093\u3060\u304B\u3089\u75C5\u4EBA\u3084\u30B9\u30DD\u30FC\u30C4\u6642\u306F\u8584\u3081\u306A\u3044\u3068\u2026\u3002\u30A4\u30F3\u30B9\u30EA\u30F3\u51FA\u307E\u304F\u3063\u3066\u4F4E\u8840\u7CD6\u306B\u306A\u308B\u3057\u6FC3\u5EA6\u9AD8\u3059\u304E\u3066\u5371\u306A\u3044\u3088\u3002\u30B9\u30DD\u30FC\u30C4\u6642\u306B\u30DD\u30AB\u30EA\u539F\u6DB2\u3068 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230168877752012800",
    "text" : "\u306A\u3093\u304B\u307E\u305F\u708E\u5929\u4E0B\u3067\u306E\u30B9\u30DD\u30FC\u30C4\u6642\u306B\u30DD\u30AB\u30EA\u98F2\u307E\u305B\u305F\u3089\u5B50\u3069\u3082\u304C\u30D5\u30E9\u30D5\u30E9\u306B\u306A\u3063\u305F\u3063\u3066\u9A12\u3044\u3060\u4EBA\u304C\u2026\u3002\u3060\u3081\u3060\u3088\u3042\u308C\u306F\u5065\u5EB7\u4F53\u5411\u3051\u306B\u4F5C\u3063\u3066\u3093\u3060\u304B\u3089\u75C5\u4EBA\u3084\u30B9\u30DD\u30FC\u30C4\u6642\u306F\u8584\u3081\u306A\u3044\u3068\u2026\u3002\u30A4\u30F3\u30B9\u30EA\u30F3\u51FA\u307E\u304F\u3063\u3066\u4F4E\u8840\u7CD6\u306B\u306A\u308B\u3057\u6FC3\u5EA6\u9AD8\u3059\u304E\u3066\u5371\u306A\u3044\u3088\u3002\u30B9\u30DD\u30FC\u30C4\u6642\u306B\u30DD\u30AB\u30EA\u539F\u6DB2\u3068\u304B\u3001\u5E73\u5E38\u6642\u306B\u30AB\u30EB\u30D4\u30B9\u539F\u6DB2\u3067\u98F2\u3080\u30EC\u30D9\u30EB\u3002",
    "id" : 230168877752012800,
    "created_at" : "2012-07-31 05:11:51 +0000",
    "user" : {
      "name" : "\u306F\u308B\u306B\u3083\u3093@\u30A2\u30E9\u30B5\u30FC(*\u272A\u25BD\u272A)\u2606*\u00B0",
      "screen_name" : "teizuisun",
      "protected" : false,
      "id_str" : "217332777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583271213297848320\/70nx_MV5_normal.jpg",
      "id" : 217332777,
      "verified" : false
    }
  },
  "id" : 230558919171387392,
  "created_at" : "2012-08-01 07:01:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230555460695101440",
  "text" : "\u4F55\u304B\u80C3\u306B\u3044\u308C\u3066\u304A\u304B\u306A\u3044\u3068\u6B7B\u306B\u81F3\u308B",
  "id" : 230555460695101440,
  "created_at" : "2012-08-01 06:48:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230555085644627969",
  "text" : "\u307B\u304F\u3076\u3067\u304A\u3046\u3069\u3093",
  "id" : 230555085644627969,
  "created_at" : "2012-08-01 06:46:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230531822256275456",
  "text" : "\u5727\u5012\u7684\u8170\u75DB\uFF01\u306A\u3093\u3082\u3067\u304D\u306D\u3047",
  "id" : 230531822256275456,
  "created_at" : "2012-08-01 05:14:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/NwS0iZ99",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=tira_orange",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "230527775767941121",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/NwS0iZ99",
  "id" : 230527775767941121,
  "created_at" : "2012-08-01 04:57:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230452863866925056",
  "geo" : { },
  "id_str" : "230453080469164032",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u305F\u3060\u306E\u98A8\u90AA\u306A\u3093\u3067\u3059\u304C\u306D\u3047\u2026",
  "id" : 230453080469164032,
  "in_reply_to_status_id" : 230452863866925056,
  "created_at" : "2012-08-01 00:01:10 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230452927104446465",
  "text" : "5\u9650\u8A66\u9A13\u3060\u3057\u4EBA\u306B\u30CE\u30FC\u3068\u501F\u308A\u3066\u308B\u304B\u3089\u7121\u7406\u306B\u3067\u3082\u3044\u304B\u306A\u304D\u3083\u3060\u306A\u2026",
  "id" : 230452927104446465,
  "created_at" : "2012-08-01 00:00:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230452492423540736",
  "geo" : { },
  "id_str" : "230452692567326722",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u8170\u75DB\u3044",
  "id" : 230452692567326722,
  "in_reply_to_status_id" : 230452492423540736,
  "created_at" : "2012-07-31 23:59:38 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230452333098708992",
  "text" : "\u3053\u3057\u3044\u305F\u3044",
  "id" : 230452333098708992,
  "created_at" : "2012-07-31 23:58:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230441786806525952",
  "text" : "\u305D\u3093\u306A\u3053\u3068\u3088\u308A\u3057\u3083\u308F\u30FC\u3042\u3073\u305F\u3044",
  "id" : 230441786806525952,
  "created_at" : "2012-07-31 23:16:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230440188910923776",
  "text" : "\u4F53\u304C\u8ECB\u3080",
  "id" : 230440188910923776,
  "created_at" : "2012-07-31 23:09:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230349642091622401",
  "text" : "\u3068\u3082\u3042\u308C2\u6642\u9593\u534A\u3067\u534A\u5E74\u306E\u30CE\u30FC\u30C8\u306F\u30C6\u30AD\u30B9\u30C8\u306B\u8D77\u3053\u305B\u308B\u3068\u3044\u3046\u30C7\u30FC\u30BF\u304C\u53D6\u308C\u305F\uFF0E",
  "id" : 230349642091622401,
  "created_at" : "2012-07-31 17:10:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230349181632512000",
  "text" : "\u3053\u3053\u6700\u8FD1\u304B\u306A\u308A\u30AF\u30FC\u30E9\u30FC\u306E\u52B9\u3044\u305F\u7A7A\u9593\u306B\u9589\u3058\u3053\u3082\u3063\u3066\u305F\u304B\u3089\u306A\u2026\u304A\u3084\u3059\u307F\u306A\u3055\u3044\uFF0E",
  "id" : 230349181632512000,
  "created_at" : "2012-07-31 17:08:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230348963088310272",
  "text" : "\u9069\u5F53\u306B\u85AC\u98F2\u3093\u3067\u5BDD\u3088\u3046\uFF0E",
  "id" : 230348963088310272,
  "created_at" : "2012-07-31 17:07:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230348760868331520",
  "text" : "\u97F3\u30B2\u30FC\u30DE\u30FC\u304C\u3069\u306E\u304F\u3089\u3044\u53E9\u3044\u3066\u3093\u306E\u304B\u77E5\u3089\u306A\u3044\u3051\u308C\u3069\u305D\u306E\u6C17\u6301\u3061\u306E\u4E00\u7AEF\u304C\u89E3\u3063\u305F\u6C17\u304C\uFF0E\u624B\u75DB\u3044\uFF0E\u505C\u6EDE\uFF0E",
  "id" : 230348760868331520,
  "created_at" : "2012-07-31 17:06:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230348624415055872",
  "text" : "\u4E88\u5B9A\u3088\u308A5\u5206\u9045\u308C\u3066\u7D42\u308F\u3063\u305F\u3041\u3041\u3041\u3041\u3041",
  "id" : 230348624415055872,
  "created_at" : "2012-07-31 17:06:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230339783103242240",
  "text" : "\u306A\u3093\u3068\u304B2\u6642\u306B\u306F\u7D42\u3048\u308B\u4E88\u5B9A\u3002",
  "id" : 230339783103242240,
  "created_at" : "2012-07-31 16:30:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230332486264168448",
  "text" : "\u3055\u3066\u30D9\u30B9\u30C8\u30B3\u30F3\u30C7\u30A3\u30B7\u30E7\u30F3\u306E\u307E\u307E\u5F8C\u534A\u6226",
  "id" : 230332486264168448,
  "created_at" : "2012-07-31 16:01:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230332072848404480",
  "geo" : { },
  "id_str" : "230332290331443200",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 230332290331443200,
  "in_reply_to_status_id" : 230332072848404480,
  "created_at" : "2012-07-31 16:01:12 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230332184597233665",
  "text" : "\u3068\u3044\u3046\u304B\u3053\u308C\u30A8\u30D4\u30AF\u30ED\u30B9\u306B\u3064\u3044\u3066\u7E8F\u3081\u3066\u3042\u308B\u3051\u308C\u3069\u30A8\u30D4\u30AF\u30ED\u30B9\u304C\u66F8\u3044\u305F\u3063\u3066\u77E5\u3089\u306A\u304B\u3063\u305F\u3089\u9177\u3044\u8852\u5B66\u8005\u3063\u3077\u308A\u3060\uFF08\uFF3E\uFF3E\uFF09\uFF08\uFF3E\uFF3E\uFF09\uFF08\uFF3E\uFF3E\uFF09",
  "id" : 230332184597233665,
  "created_at" : "2012-07-31 16:00:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230327205174050816",
  "text" : "\u3068\u308A\u3042\u3048\u305A13\u679A\uFF08\/20\u679A\uFF09\u7D42\u308F\u3063\u305F",
  "id" : 230327205174050816,
  "created_at" : "2012-07-31 15:40:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230327085208584193",
  "text" : "\u6B63\u76F4\u3053\u306E\u611F\u899A\u306F\u98A8\u90AA\u3072\u3044\u3066\u308B\u6642\u306E\u30A2\u30EC\u3060\u304C\u30FC\uFF1F",
  "id" : 230327085208584193,
  "created_at" : "2012-07-31 15:40:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230324483230158849",
  "geo" : { },
  "id_str" : "230326945727004672",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u5049\u304F\u306A\u3044\u304B\u3089\u300C\u81EA\u5BA4\u30CE\u30FC\u30C8\u306E\u307F\u6301\u8FBC\u307F\u53EF\u300D\u3092\u30AF\u30EA\u30A2\u3059\u308B\u305F\u3081\u3060\u3051\u306B\u4EBA\u306E\u30CE\u30FC\u30C8\u3092\u8D77\u3053\u3057\u3066\u3044\u308B\uFF0E",
  "id" : 230326945727004672,
  "in_reply_to_status_id" : 230324483230158849,
  "created_at" : "2012-07-31 15:39:57 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230324307979554816",
  "text" : "\u534A\u5E74\u5206\u306E\u30CE\u30FC\u30C8\u3092\u30C6\u30AD\u30B9\u30C8\u306B\u8D77\u3053\u3059\u7C21\u5358\u306A\u304A\u4ED5\u4E8B\uFF0E\u306E\u3069\u3044\u305F\u3044\uFF0E",
  "id" : 230324307979554816,
  "created_at" : "2012-07-31 15:29:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]