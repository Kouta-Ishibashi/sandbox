Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86445774283603969",
  "text" : "\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u98F2\u307F\u305F\u3044\u3051\u3069\u3001\u4ECA\u98F2\u3093\u3060\u3089\u660E\u65E5\u306E\u4E00\u9650\u306F\u30C0\u30E1\u306B\u306A\u308B\u6C17\u304C\u3059\u308B\u3002\u725B\u4E73\u3060\u3051\u306B\u3057\u3066\u304A\u304F\u304B\u3002",
  "id" : 86445774283603969,
  "created_at" : "2011-06-30 14:47:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86445184568664065",
  "geo" : { },
  "id_str" : "86445606658252801",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6587\u5B66\u90E8\u82F1\u8A9E\u306E\u7BC4\u56F2\u3063\u3066\u308F\u304B\u308A\u307E\u3057\u305F\u3067\u3057\u3087\u3046\u304B\u2026\uFF1F",
  "id" : 86445606658252801,
  "in_reply_to_status_id" : 86445184568664065,
  "created_at" : "2011-06-30 14:46:53 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 0, 9 ],
      "id_str" : "256321768",
      "id" : 256321768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86442274296303617",
  "geo" : { },
  "id_str" : "86445470666342400",
  "in_reply_to_user_id" : 256321768,
  "text" : "@mar1e666 \u3044\u3084\u3001\u52DD\u624B\u306B\u9A5A\u3044\u3066\u3059\u3044\u307E\u305B\u3093\u3002\u3063\u3066\u611F\u3058\u3067\u3059\u304C\u3002",
  "id" : 86445470666342400,
  "in_reply_to_status_id" : 86442274296303617,
  "created_at" : "2011-06-30 14:46:20 +0000",
  "in_reply_to_screen_name" : "mar1e666",
  "in_reply_to_user_id_str" : "256321768",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 0, 9 ],
      "id_str" : "256321768",
      "id" : 256321768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86440186090749952",
  "geo" : { },
  "id_str" : "86440676761407488",
  "in_reply_to_user_id" : 256321768,
  "text" : "@mar1e666 \u51C4\u304F\u30C9\u30AD\u30C3\u3068\u3057\u305F\u3093\u3067\u3059\u304C\uFF57",
  "id" : 86440676761407488,
  "in_reply_to_status_id" : 86440186090749952,
  "created_at" : "2011-06-30 14:27:17 +0000",
  "in_reply_to_screen_name" : "mar1e666",
  "in_reply_to_user_id_str" : "256321768",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86426316970274816",
  "text" : "\u30CD\u30C3\u30C8\u9280\u884C\u306E\u660E\u7D30\u306B\u3001\u632F\u308A\u8FBC\u307F\u3000\uFF13\uFF12\uFF10\uFF10\uFF10\u3000\u3063\u3066\uFF57\uFF57\uFF57\uFF57",
  "id" : 86426316970274816,
  "created_at" : "2011-06-30 13:30:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86426002963697664",
  "text" : "RT @JOJO_math: \u307E\u2026\u307E\u305A\u3044\uFF01\u3000\u30B8\u30E7\u30B8\u30E7\u306F\u6BB4\u3089\u308C\u305F\u3053\u3068\u3088\u308A\u3082\u3000\u30A8\u30EA\u30CA\u3055\u3093\u306B\u8CB7\u3063\u3066\u3082\u3089\u3063\u305F\u670D\u306E\u5024\u6BB5\u3067Make 10\u304C\u3067\u304D\u306A\u3044\u3053\u3068\u3092\u6012\u308B\u30BF\u30A4\u30D7\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86425769072541697",
    "text" : "\u307E\u2026\u307E\u305A\u3044\uFF01\u3000\u30B8\u30E7\u30B8\u30E7\u306F\u6BB4\u3089\u308C\u305F\u3053\u3068\u3088\u308A\u3082\u3000\u30A8\u30EA\u30CA\u3055\u3093\u306B\u8CB7\u3063\u3066\u3082\u3089\u3063\u305F\u670D\u306E\u5024\u6BB5\u3067Make 10\u304C\u3067\u304D\u306A\u3044\u3053\u3068\u3092\u6012\u308B\u30BF\u30A4\u30D7\uFF01",
    "id" : 86425769072541697,
    "created_at" : "2011-06-30 13:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 86426002963697664,
  "created_at" : "2011-06-30 13:28:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86425284374568960",
  "geo" : { },
  "id_str" : "86425681067655168",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \uFF4D\uFF4A\uFF4B\uFF59\u5148\u8F29\u2026\uFF57\uFF57\uFF57\uFF57 \u3042\u308C\u306F\u5B8C\u5168\u653E\u7F6E\u3067\u304A\uFF4B \u4FFA\u3082\u4E00\u5207\u304B\u304B\u308F\u3089\u306A\u304B\u3063\u305F\u3002\u3068\u4F1D\u3048\u3066\u304F\u308C\u305F\u307E\u3048\uFF57",
  "id" : 86425681067655168,
  "in_reply_to_status_id" : 86425284374568960,
  "created_at" : "2011-06-30 13:27:42 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86424986549633025",
  "text" : "\u6728\u66DC\u6DF1\u591C\u306E\u9031\u672B\u611F\u899A\u304C\u3057\u3070\u3089\u304F\u7D9A\u304F\u306E\u306F\u53BB\u5E74\u306E\u5F8C\u671F\u306E\u305B\u3044\u3060\u3088\u306A\u30FB\u30FB\u30FB",
  "id" : 86424986549633025,
  "created_at" : "2011-06-30 13:24:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86424643006767104",
  "geo" : { },
  "id_str" : "86424798275710976",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u8FB2\uFF4B\u2026\u3044\u3084\u3001\u306A\u3093\u3067\u3082\u306A\u3044",
  "id" : 86424798275710976,
  "in_reply_to_status_id" : 86424643006767104,
  "created_at" : "2011-06-30 13:24:12 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86423413211668480",
  "text" : "\u3068\u304B\u8A00\u3044\u306A\u304C\u3089\u30DC\u30E0\u30C3\u30BF\u2015\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u308B\u306E\u306F\u306A\u3093\u306A\u3093\u3067\u3057\u3087\u3046\uFF57",
  "id" : 86423413211668480,
  "created_at" : "2011-06-30 13:18:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86423209288806400",
  "text" : "\u305D\u3082\u305D\u3082\u7206\u767A\u3057\u308D\u3063\u3066\u8A00\u3063\u305F\u3089\u30DB\u30F3\u30C8\u306B\u7206\u767A\u3059\u308B\u306E\uFF4B\u2026\u2026\u305D\u308D\u305D\u308D\u3084\u3081\u3088\u3046\u3002\u3046\u3093\u3002",
  "id" : 86423209288806400,
  "created_at" : "2011-06-30 13:17:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86422952312176640",
  "text" : "\u5F7C\u6C0F\u5F7C\u5973\u3044\u308B\u4EBA\u3063\u3066\u610F\u5473\u3060\u3063\u305F\u3068\u3057\u3066\u3082\u3001\u305D\u306E\u70BA\u306E\u52AA\u529B\u3084\u3089\u5FC3\u304C\u3051\u3084\u3089\u3092\u672C\u6C17\u3067\u3057\u3066\u306A\u3044\u4EBA\u304C\u7C21\u5358\u306B\u7206\u767A\u3057\u308D\u306A\u3093\u3066\u8A00\u3048\u306A\u3044\u306F\u305A\u306A\u3093\u3060\u3051\u3069\u306A\u3002",
  "id" : 86422952312176640,
  "created_at" : "2011-06-30 13:16:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86422709696864256",
  "text" : "\u30EA\u30A2\u5145\u539F\u7406\u4E3B\u7FA9\u8005\u304B\u3089\u8A00\u308F\u305B\u3066\u3082\u3089\u3048\u3070\u30EA\u30A2\u5145\u7206\u767A\u3057\u308D\u3068\u304B\u307B\u3068\u3093\u3069\u5168\u4EBA\u985E\u7206\u767A\u3059\u308B\u308F\u3002",
  "id" : 86422709696864256,
  "created_at" : "2011-06-30 13:15:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86422354229608448",
  "text" : "\u30DC\u30E0\u3063\u305F\u30FC\u898B\u3066\u308B\u3068\u5B9A\u671F\u7684\u306B\u6570\u5B66\u304C\u7206\u767A\u3057\u3066\u3044\u3066\u60B2\u3057\u3044\u3002\u5F97\u610F\u3067\u306A\u304B\u3063\u305F\u308A\u597D\u304D\u3058\u3083\u306A\u3044\u4EBA\u304C\u591A\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u3068\u306F\u601D\u3046\u3051\u3069\u7206\u767A\u3055\u305B\u308B\u306A\u3093\u3066\u3072\u3069\u3044\u3058\u3083\u306A\u3044\u304B\u30FB\u30FB\u30FB\u3002",
  "id" : 86422354229608448,
  "created_at" : "2011-06-30 13:14:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86403717338894336",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 86403717338894336,
  "created_at" : "2011-06-30 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86282343643480064",
  "text" : "\u6D74\u8863\u4F3C\u5408\u3046\u306E\u306F\u826F\u3044\u3088\u306D\u3047\u3002",
  "id" : 86282343643480064,
  "created_at" : "2011-06-30 03:58:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3042\u308B\u99D2\u5834\u306E\u5E73\u6210\uFF38\u5E74",
      "screen_name" : "SKC38",
      "indices" : [ 3, 9 ],
      "id_str" : "218891314",
      "id" : 218891314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86282160713113600",
  "text" : "RT @SKC38: \u6D74\u8863\u304C\u4F3C\u5408\u3046=\u80F8\u304C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86276537191628800",
    "text" : "\u6D74\u8863\u304C\u4F3C\u5408\u3046=\u80F8\u304C\u2026",
    "id" : 86276537191628800,
    "created_at" : "2011-06-30 03:35:04 +0000",
    "user" : {
      "name" : "\u3068\u3042\u308B\u99D2\u5834\u306E\u5E73\u6210\uFF38\u5E74",
      "screen_name" : "SKC38",
      "protected" : false,
      "id_str" : "218891314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583201304152965120\/BKiKxEml_normal.jpg",
      "id" : 218891314,
      "verified" : false
    }
  },
  "id" : 86282160713113600,
  "created_at" : "2011-06-30 03:57:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86270554973282305",
  "geo" : { },
  "id_str" : "86273304603787264",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4",
  "id" : 86273304603787264,
  "in_reply_to_status_id" : 86270554973282305,
  "created_at" : "2011-06-30 03:22:13 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86267355423973377",
  "geo" : { },
  "id_str" : "86273056464580608",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3058\u3083\u3042\u660E\u65E5\u306E\u79D1\u5B66\u54F2\u5B66\u3067",
  "id" : 86273056464580608,
  "in_reply_to_status_id" : 86267355423973377,
  "created_at" : "2011-06-30 03:21:14 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86265524555743232",
  "geo" : { },
  "id_str" : "86266730141323264",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8CFC\u8AAD\u30EC\u30DD\u30FC\u30C8\u306F\u8A73\u7D30\u77E5\u3063\u3066\u308B\u305C\u3044\u3002\uFF15\u9650\u3067\u9802\u3053\u3046\u3002\u3042\u3001\u3067\u308B\uFF1F",
  "id" : 86266730141323264,
  "in_reply_to_status_id" : 86265524555743232,
  "created_at" : "2011-06-30 02:56:05 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86265121214701568",
  "text" : "\u304A\u305D\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
  "id" : 86265121214701568,
  "created_at" : "2011-06-30 02:49:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86264972996378624",
  "text" : "\u3042\u3089\u3001\u79C1\u306E\u5348\u524D\u4E2D\u306F\u4F55\u51E6\u306B",
  "id" : 86264972996378624,
  "created_at" : "2011-06-30 02:49:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86114415019163648",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u2026",
  "id" : 86114415019163648,
  "created_at" : "2011-06-29 16:50:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86114324061495296",
  "text" : "\u96C6\u56E3\u306F\u82E6\u624B\u3067\u3082\u96C6\u5408\u306F\u5F97\u610F\u306B\u306A\u308A\u305F\u3044",
  "id" : 86114324061495296,
  "created_at" : "2011-06-29 16:50:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86114187230720000",
  "text" : "o\uFF4F\uFF2F\uFF08\u96C6\u5408\u3068\u4F4D\u76F8\u3084\u3089\u306A\u3044\u3068\u306A\uFF09",
  "id" : 86114187230720000,
  "created_at" : "2011-06-29 16:49:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86114032314101760",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 86114032314101760,
  "created_at" : "2011-06-29 16:49:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86103542867296256",
  "geo" : { },
  "id_str" : "86103997970268160",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4E8C\u884C\u3067\u8A3C\u660E\u7D42\u3048\u308C\u3070\u3044\u3044\u3063\uFF01\u2190",
  "id" : 86103997970268160,
  "in_reply_to_status_id" : 86103542867296256,
  "created_at" : "2011-06-29 16:09:27 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86092075174608896",
  "geo" : { },
  "id_str" : "86092344537001984",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 43\u3060\u3063\u305F\u306F\u305A\u300245\u6709\u308C\u3070\u9593\u9055\u3044\u306A\u3044\u3002",
  "id" : 86092344537001984,
  "in_reply_to_status_id" : 86092075174608896,
  "created_at" : "2011-06-29 15:23:09 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86091412705259520",
  "geo" : { },
  "id_str" : "86091934430531584",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u767A\u8868\u4E8C\u56DE\u7D42\u308F\u3063\u3066\u3093\u3060\u3088\u306A\u2026\u307E\u3041\u884C\u3063\u3066\u4ED6\u306E\u3053\u3068\u3059\u308B\u3064\u3082\u308A\u3002\u958B\u5E55\u3044\u306A\u304B\u3063\u305F\u3089\u30D7\u30EA\u30F3\u30C8\u53D6\u3063\u3066\u304A\u3044\u3066\u304F\u308C\uFF57",
  "id" : 86091934430531584,
  "in_reply_to_status_id" : 86091412705259520,
  "created_at" : "2011-06-29 15:21:31 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86090877595947008",
  "geo" : { },
  "id_str" : "86091168626118656",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u308F\u304B\u3063\u305F\u3089\u6559\u3048\u3066\u304F\u3060\u3055\u3044\u2026",
  "id" : 86091168626118656,
  "in_reply_to_status_id" : 86090877595947008,
  "created_at" : "2011-06-29 15:18:28 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86089968556060672",
  "geo" : { },
  "id_str" : "86090795165290497",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u590F\u307E\u3067\u6211\u6162\u3057\u305F\u65B9\u304C\u30FB\u30FB\u30FB\u3058\u3083\u306A\u304D\u3083\u90F5\u9001\u3057\u3066\u3082\u3089\u3063\u305F\u3089\uFF1F\u3053\u306E\u6642\u671F\u9031\u672B\u3092\u3064\u3076\u3059\u306E\u306F\u30AD\u30C4\u3044\u3060\u308D\u3002\u30EC\u30DD\u30FC\u30C8\u3068\u304B\u3082\u308D\u3082\u308D\u3067\u3002",
  "id" : 86090795165290497,
  "in_reply_to_status_id" : 86089968556060672,
  "created_at" : "2011-06-29 15:16:59 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86089628339286016",
  "geo" : { },
  "id_str" : "86090534854201344",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u308C\uFF1F\u4ECA\u9031\u306E\u6587\u5B66\u90E8\u82F1\u8A9E\u51FA\u3066\u305F\u3063\u3051\uFF1F",
  "id" : 86090534854201344,
  "in_reply_to_status_id" : 86089628339286016,
  "created_at" : "2011-06-29 15:15:57 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86069858940366848",
  "text" : "JR\u5BD2\u3044",
  "id" : 86069858940366848,
  "created_at" : "2011-06-29 13:53:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86068416481464320",
  "text" : "\u30A8\u30F3\u30B8\u30F3\u3092\u304B\u3051\u308B\u3075\u308A\u3063\u3066\u3053\u3068\u306F\u305D\u308D\u305D\u308D\u514D\u8A31\u53D6\u308A\u306B\u884C\u304F\u8FBA\u308A\u304B\u306A",
  "id" : 86068416481464320,
  "created_at" : "2011-06-29 13:48:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86067770604797953",
  "text" : "\u305D\u308D\u305D\u308D\u52C9\u5F37\u3084\u3089\u30EC\u30DD\u30FC\u30C8\u3084\u3089\u30A8\u30F3\u30B8\u30F3\u3092\u304B\u3051\u308B\u3075\u308A\u3092\u3057\u306A\u304F\u3063\u3061\u3083\u306A",
  "id" : 86067770604797953,
  "created_at" : "2011-06-29 13:45:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86067384045146113",
  "text" : "\u3042\u308C\u3001\u4F5C\u308D\u3046\u3068\u3057\u3066\u308B\u3082\u306E\u306E\u30A4\u30E1\u30FC\u30B8\u305D\u306E\u3082\u306E\u3060",
  "id" : 86067384045146113,
  "created_at" : "2011-06-29 13:43:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3053\u3068\u3058",
      "screen_name" : "makotoji16",
      "indices" : [ 3, 14 ],
      "id_str" : "33113346",
      "id" : 33113346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86021541267128320",
  "text" : "RT @makotoji16: \u90E8\u5C4B\u304C\u6C5A\u3044\u3093\u3058\u3083\u306A\u3044\u30FB\u30FB\u30FB\u9006\u306B\u8003\u3048\u308B\u3093\u3060\u3002\u4E16\u754C\u304C\u7F8E\u3057\u3059\u304E\u308B\u3093\u3060\u3068\u30FB\u30FB\u30FB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85990794405744641",
    "text" : "\u90E8\u5C4B\u304C\u6C5A\u3044\u3093\u3058\u3083\u306A\u3044\u30FB\u30FB\u30FB\u9006\u306B\u8003\u3048\u308B\u3093\u3060\u3002\u4E16\u754C\u304C\u7F8E\u3057\u3059\u304E\u308B\u3093\u3060\u3068\u30FB\u30FB\u30FB",
    "id" : 85990794405744641,
    "created_at" : "2011-06-29 08:39:37 +0000",
    "user" : {
      "name" : "\u307E\u3053\u3068\u3058",
      "screen_name" : "makotoji16",
      "protected" : false,
      "id_str" : "33113346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582705014235250688\/fdMXbvJJ_normal.jpg",
      "id" : 33113346,
      "verified" : false
    }
  },
  "id" : 86021541267128320,
  "created_at" : "2011-06-29 10:41:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86013853095313409",
  "text" : "RT @38valleys: \u3010\u9AED\u7537\u7235in\u6570\u5B66\u79D1\u3011\u300E\u30DE\u30B9\u30DE\u30C6\u30A3\u30FC\u30AF\u30B9\uFF01\u300F\u300C\u5E7C\u6C17\u306A\u5B66\u90E8\u751F\u306B\u74B0\u8AD6\u3092\u6559\u3048\u3066\u3042\u30FC\u3052\u308B\uFF01\u306E\u5DFB\u300D\u300C\u6574\u9589\u6574\u57DFA\u306E\u5546\u4F53K\u3068\u6709\u9650\u6B21\u62E1\u5927L\u3092\u3068\u3063\u3066\u300D\u300C\u5206\u96E2\u6027\u3069\u3053\u3044\u3063\u3066\u30FC\u3093ww\u300D\u300C\u3042\u5FD8\u308C\u3066\u307E\u3057\u305F\u300D\u300C\u5F8C\u30CD\u30FC\u30BF\u30FC\u6027\u3068\u304B\u8981\u3089\u3078\u3093\u306E\u304B\u30FC\u3044ww\u300D\u300C\u4F53\u4E0A\u6709\u9650\u751F\u6210\u306E\u74B0\u3057\u304B\u8003\u3048 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85996149613400064",
    "text" : "\u3010\u9AED\u7537\u7235in\u6570\u5B66\u79D1\u3011\u300E\u30DE\u30B9\u30DE\u30C6\u30A3\u30FC\u30AF\u30B9\uFF01\u300F\u300C\u5E7C\u6C17\u306A\u5B66\u90E8\u751F\u306B\u74B0\u8AD6\u3092\u6559\u3048\u3066\u3042\u30FC\u3052\u308B\uFF01\u306E\u5DFB\u300D\u300C\u6574\u9589\u6574\u57DFA\u306E\u5546\u4F53K\u3068\u6709\u9650\u6B21\u62E1\u5927L\u3092\u3068\u3063\u3066\u300D\u300C\u5206\u96E2\u6027\u3069\u3053\u3044\u3063\u3066\u30FC\u3093ww\u300D\u300C\u3042\u5FD8\u308C\u3066\u307E\u3057\u305F\u300D\u300C\u5F8C\u30CD\u30FC\u30BF\u30FC\u6027\u3068\u304B\u8981\u3089\u3078\u3093\u306E\u304B\u30FC\u3044ww\u300D\u300C\u4F53\u4E0A\u6709\u9650\u751F\u6210\u306E\u74B0\u3057\u304B\u8003\u3048\u3066\u307E\u305B\u3093\u300D\u300C\u4E8B\u60C5\u304C\u5909\u308F\u3063\u305F\u3002\u7D9A\u3051\u3066\uFF1F\u300D",
    "id" : 85996149613400064,
    "created_at" : "2011-06-29 09:00:54 +0000",
    "user" : {
      "name" : "\u306E\u3089\u3093\u3076\u308B",
      "screen_name" : "nolimbre",
      "protected" : false,
      "id_str" : "62256126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599829445105438720\/xfix_1cZ_normal.jpg",
      "id" : 62256126,
      "verified" : false
    }
  },
  "id" : 86013853095313409,
  "created_at" : "2011-06-29 10:11:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "indices" : [ 3, 17 ],
      "id_str" : "199329343",
      "id" : 199329343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86008146233016320",
  "text" : "RT @Satomii_Opera: \u5973\u300C\u306D\u3048\u3001\u79C1\u306E\u3069\u3053\u304C\u597D\u304D\uFF1F\u300D\n\u7537\u300C3.14159265358979323846264338327950288419716939937510582097494459230781640628620899862803482534211706 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85986969565409281",
    "text" : "\u5973\u300C\u306D\u3048\u3001\u79C1\u306E\u3069\u3053\u304C\u597D\u304D\uFF1F\u300D\n\u7537\u300C3.141592653589793238462643383279502884197169399375105820974944592307816406286208998628034825342117067982148086513282306647",
    "id" : 85986969565409281,
    "created_at" : "2011-06-29 08:24:25 +0000",
    "user" : {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "protected" : false,
      "id_str" : "199329343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212059931\/satomii_opera_normal.jpg",
      "id" : 199329343,
      "verified" : false
    }
  },
  "id" : 86008146233016320,
  "created_at" : "2011-06-29 09:48:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85966184146673664",
  "geo" : { },
  "id_str" : "85974847057965056",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u4F55\u3084\u3089\u6700\u8FD1\u30DF\u30EB\u30AD\u30A3\u30C4\u30A4\u30FC\u30C8\u304C\u591A\u3044\u3067\u3059\u306D\u3047\uFF57\u826F\u3044\u610F\u5473\u3067\u3002",
  "id" : 85974847057965056,
  "in_reply_to_status_id" : 85966184146673664,
  "created_at" : "2011-06-29 07:36:15 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85945548242300928",
  "text" : "\u5370\u8C61\u3068\u3057\u3066\u306F\u5927\u5C71\u30A2\u30FC\u30E0\u30ED\u30C3\u30AF\u306B\u8FD1\u3044\u306E\u304B\u306A\u3002\u3042\u306E\u611F\u3058\u306F\u5065\u5728\u3060\u3063\u305F\u306A\u3002",
  "id" : 85945548242300928,
  "created_at" : "2011-06-29 05:39:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85945140623065088",
  "text" : "\u56EE\u7269\u8A9E\u306E\u3064\u3044\u3067\u306BSPA\u8CB7\u3063\u3066\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u3092\u30C1\u30A7\u30C3\u30AF\n\n\u4E00\u968E\u306E\u672C\u5C4B\u3067\u8CB7\u3063\u3066\u4E8C\u968E\u3067\u4E8C\u518A\u8AAD\u307F\u7D42\u3048\u3066\u3057\u307E\u3063\u305F",
  "id" : 85945140623065088,
  "created_at" : "2011-06-29 05:38:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85939338059333632",
  "text" : "@np2i \u3042\u3001\u3059\u307F\u307E\u305B\u3093\u3002\u3064\u3044\u3002",
  "id" : 85939338059333632,
  "created_at" : "2011-06-29 05:15:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85939148036390912",
  "text" : "\u30D0\u30C3\u30C9\u30A8\u30F3\u30C9\u2026\u3067\u3082\u82B1\u7269\u8A9E\u306B\u7E4B\u304C\u308B\u306A\u3089\u2026\u3042\u308B\u3044\u306F\u2026\uFF1F",
  "id" : 85939148036390912,
  "created_at" : "2011-06-29 05:14:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85915985781080064",
  "text" : "\u306A\u3067\u3053\u304C\u8A9E\u308A\u90E8\u2026\u3060\u3068\uFF01",
  "id" : 85915985781080064,
  "created_at" : "2011-06-29 03:42:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85912685392314368",
  "text" : "\u30EB\u30CD\u3067\u56EE\u7269\u8A9E\u8CB7\u304A\u3046",
  "id" : 85912685392314368,
  "created_at" : "2011-06-29 03:29:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85912577292500992",
  "text" : "\u5BDB\u5BB9\u306A\u79C1\u306F\u7B11\u3063\u3066\u8A31\u3059\uFF01\n\n\u307E\u3041\u307C\u30FC\u3063\u3068\u3059\u308B\u306E\u597D\u304D\u3060\u3057\u306A",
  "id" : 85912577292500992,
  "created_at" : "2011-06-29 03:28:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85909942552371200",
  "text" : "\uFF12\u9650\u306E\u82F1\u8A9E\u30D7\u30EC\u30BC\u30F3\u306E\u30B0\u30EB\u30FC\u30D7\u30E1\u30F3\u30D0\u30FC\u4FFA\u3057\u304B\u5C45\u306A\u304F\u3066\u30E9\u30B9\u30C8\uFF12\uFF10\u5206\u307C\u30FC\u3063\u3068\u3057\u3066\u305F\u3002",
  "id" : 85909942552371200,
  "created_at" : "2011-06-29 03:18:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85903215920562176",
  "text" : "\u7D50\u5C40\uFF11\uFF0F\uFF08\uFF12\uFF0Bsin\uFF58\uFF09\u306E\u539F\u59CB\u51FD\u6570\u304C\u308F\u304B\u3089\u306A\u3044\u2026\n\n\u8907\u7D20\u7BC4\u56F2\u306B\u5E83\u3052\u305F\u65B9\u304C\u6EB6\u3051\u308B\u3093\u3058\u3083\u2026",
  "id" : 85903215920562176,
  "created_at" : "2011-06-29 02:51:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85882454287728640",
  "text" : "\u3042\u3001\u5E73\u4E43\u3061\u3083\u3093\u629C\u3051\u305F\u3051\u3069\u307E\u3041\u3044\u3044\u304B",
  "id" : 85882454287728640,
  "created_at" : "2011-06-29 01:29:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u539F\u2252\u306B\u305B\u7269\u7406\u5B66\u5F92",
      "screen_name" : "hhara_iwate",
      "indices" : [ 0, 12 ],
      "id_str" : "276105342",
      "id" : 276105342
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 13, 23 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 24, 35 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85866587546058752",
  "geo" : { },
  "id_str" : "85882219754819584",
  "in_reply_to_user_id" : 276105342,
  "text" : "@hhara_iwate @nisehorrn @magokoro84 \u304A\u3084\u3059\u307F\u222A\u304A\u306F\u3088\u3046\u3042\u308A\u304C\u3068\u3067\u3057\u305F\u30FC",
  "id" : 85882219754819584,
  "in_reply_to_status_id" : 85866587546058752,
  "created_at" : "2011-06-29 01:28:11 +0000",
  "in_reply_to_screen_name" : "hhara_iwate",
  "in_reply_to_user_id_str" : "276105342",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "177139869",
      "id" : 177139869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85881850769321984",
  "text" : "RT @wwwwww_bot: \u533B\u8005\u300C\u3042\u3001\u3053\u306E\u624B\u8853\u9032\u7814\u30BC\u30DF\u3067\u3084\u3063\u305F\u3053\u3068\u304C\u3042\u308B\uFF01\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85879803193995265",
    "text" : "\u533B\u8005\u300C\u3042\u3001\u3053\u306E\u624B\u8853\u9032\u7814\u30BC\u30DF\u3067\u3084\u3063\u305F\u3053\u3068\u304C\u3042\u308B\uFF01\u300D",
    "id" : 85879803193995265,
    "created_at" : "2011-06-29 01:18:35 +0000",
    "user" : {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "protected" : false,
      "id_str" : "177139869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603569585434939393\/ptUiuLbP_normal.jpg",
      "id" : 177139869,
      "verified" : false
    }
  },
  "id" : 85881850769321984,
  "created_at" : "2011-06-29 01:26:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85866733830799360",
  "text" : "@ayu167 \u3053\u3063\u3061\u6700\u9AD8\u6C17\u6E29\uFF13\uFF15\u3084\u3063\u3066\u2026",
  "id" : 85866733830799360,
  "created_at" : "2011-06-29 00:26:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85866222775836673",
  "text" : "\u304A\u306F\u3088\u3046 \u304A\u306F\u3088\u3046",
  "id" : 85866222775836673,
  "created_at" : "2011-06-29 00:24:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85757715783229441",
  "text" : "\u3042\u3001\u7121\u5730\u3067\u3059\u3002\u30AD\u30E3\u30E9\u3082\u306E\u3068\u304B\u3058\u3083\u306A\u3044\u3067\u3059\u3088\u3002",
  "id" : 85757715783229441,
  "created_at" : "2011-06-28 17:13:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85757529405136897",
  "text" : "\uFF08\u305D\u308D\u305D\u308D\u62B1\u304D\u6795\u3082\u6691\u82E6\u3057\u304F\u306A\u3063\u3066\u304D\u305F\u306A\u3041\u2026\uFF09",
  "id" : 85757529405136897,
  "created_at" : "2011-06-28 17:12:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85756702938501120",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 85756702938501120,
  "created_at" : "2011-06-28 17:09:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85756663134560256",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u304B\u2026\u4ECA\u65E5\u306E\u4E8C\u9650\u306F\u8D77\u304D\u306A\u304F\u3063\u3061\u3083",
  "id" : 85756663134560256,
  "created_at" : "2011-06-28 17:09:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85728756316119040",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3064\u3064\u8003\u3048\u3088\u3046",
  "id" : 85728756316119040,
  "created_at" : "2011-06-28 15:18:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85728521305079809",
  "text" : "\uFF11\uFF0F\uFF08\uFF12\uFF0Bsin\uFF58\uFF09\u306E\u539F\u59CB\u51FD\u6570\u306F\uFF1F\u306A\u306B\u304B\u7C21\u5358\u306A\u4E8B\u3092\u898B\u9003\u3057\u3066\u308B\u6C17\u304C\u3059\u308B\u3093\u3060\u3051\u3069\u2026",
  "id" : 85728521305079809,
  "created_at" : "2011-06-28 15:17:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daisuke Saito",
      "screen_name" : "dsk_saito",
      "indices" : [ 3, 13 ],
      "id_str" : "100411906",
      "id" : 100411906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85728074171301888",
  "text" : "RT @dsk_saito: \u5A18\u306B\u300C\u967D\u5B50\u30FB\u91CF\u5B50\u30FB\u96FB\u5B50\u300D\u3068\u540D\u524D\u3092\u3064\u3051\u3066\u3057\u307E\u3063\u305F\u7269\u7406\u5C4B\u306E\u89AA\u7236\u3055\u3093\u306F\u3001\u300C\u5A18\u306F\u89B3\u6E2C\u3059\u308B\u3068\u72B6\u614B\u304C\u5909\u308F\u3063\u3066\u3057\u307E\u3046\u3093\u3060\u300D\u3068\u5606\u304F\u3053\u3068\u306B\u6C17\u304C\u3064\u3044\u305F\u3002\u300C\u3069\u3053\u306B\u3044\u308B\u3093\u3060\u3068\u805E\u304F\u4F55\u3084\u3063\u3066\u308B\u304B\u308F\u304B\u3089\u305A\u300D\u300C\u4F55\u3084\u3063\u3066\u308B\u3093\u3060\u3068\u805E\u304F\u3068\u3069\u3053\u306B\u3044\u308B\u304B\u308F\u304B\u3089\u306A\u3044\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "85718489347784705",
    "text" : "\u5A18\u306B\u300C\u967D\u5B50\u30FB\u91CF\u5B50\u30FB\u96FB\u5B50\u300D\u3068\u540D\u524D\u3092\u3064\u3051\u3066\u3057\u307E\u3063\u305F\u7269\u7406\u5C4B\u306E\u89AA\u7236\u3055\u3093\u306F\u3001\u300C\u5A18\u306F\u89B3\u6E2C\u3059\u308B\u3068\u72B6\u614B\u304C\u5909\u308F\u3063\u3066\u3057\u307E\u3046\u3093\u3060\u300D\u3068\u5606\u304F\u3053\u3068\u306B\u6C17\u304C\u3064\u3044\u305F\u3002\u300C\u3069\u3053\u306B\u3044\u308B\u3093\u3060\u3068\u805E\u304F\u4F55\u3084\u3063\u3066\u308B\u304B\u308F\u304B\u3089\u305A\u300D\u300C\u4F55\u3084\u3063\u3066\u308B\u3093\u3060\u3068\u805E\u304F\u3068\u3069\u3053\u306B\u3044\u308B\u304B\u308F\u304B\u3089\u306A\u3044\u300D",
    "id" : 85718489347784705,
    "created_at" : "2011-06-28 14:37:35 +0000",
    "user" : {
      "name" : "Daisuke Saito",
      "screen_name" : "dsk_saito",
      "protected" : false,
      "id_str" : "100411906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621890092\/dsk_saito_normal.jpg",
      "id" : 100411906,
      "verified" : false
    }
  },
  "id" : 85728074171301888,
  "created_at" : "2011-06-28 15:15:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85678900591607809",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 85678900591607809,
  "created_at" : "2011-06-28 12:00:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85569659428020224",
  "geo" : { },
  "id_str" : "85570022218539008",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8997\u304D\u306B\u884C\u304F\u52C7\u6C17\u3055\u3048\u306A\u3044\u308F\uFF57\uFF57",
  "id" : 85570022218539008,
  "in_reply_to_status_id" : 85569659428020224,
  "created_at" : "2011-06-28 04:47:37 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85568150820757504",
  "geo" : { },
  "id_str" : "85569300701777920",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3069\u3053\u3067\u306A\u306B\u3084\u3063\u3066\u3093\u3059\u304B\uFF57\uFF57",
  "id" : 85569300701777920,
  "in_reply_to_status_id" : 85568150820757504,
  "created_at" : "2011-06-28 04:44:45 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85556405951676416",
  "text" : "\u9593\u63A5\u8A3C\u660E\u304B\u3068\u601D\u3063\u305F\u3089\u9593\u63A5\u7167\u660E\u306E\u8A71\u3060\u3063\u305F\u307F\u305F\u3044",
  "id" : 85556405951676416,
  "created_at" : "2011-06-28 03:53:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85551806092017664",
  "text" : "\u6559\u6388\u304C\u4F11\u8B1B\u3057\u306A\u3044\u3093\u3060\u3082\u3093\u3001\u81EA\u5206\u3067\u3084\u308B\u3057\u304B\u306A\u3044\u3058\u3083\u306A\u3044\u3002",
  "id" : 85551806092017664,
  "created_at" : "2011-06-28 03:35:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85551611476316160",
  "text" : "\u6691\u3055\u306B\u6BD4\u4F8B\u3057\u3066\u81EA\u4E3B\u4F11\u8B1B\u304C\u3059\u3053\u3057\u3065\u3064\u73FE\u308C\u3066\u304D\u305F\u306A\u2026",
  "id" : 85551611476316160,
  "created_at" : "2011-06-28 03:34:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85519286159937536",
  "text" : "\u306A\u3093\u304B\u9AEA\u3082\u3069\u3063\u3061\u3083\u3063\u3066\u308B\u2026\uFF1F",
  "id" : 85519286159937536,
  "created_at" : "2011-06-28 01:26:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85243525918232576",
  "text" : "\u4E8C\u9650\u306E\u30B3\u30F3\u30D7\u30ED\u306F\u51FA\u305F\u304B\u3063\u305F\u3093\u3060\u3051\u3069\u306A\u30FC",
  "id" : 85243525918232576,
  "created_at" : "2011-06-27 07:10:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85243466342338560",
  "text" : "\u4E8C\u9650\u5BDD\u574A\u3057\u3066\u7D50\u5C40\u5BB6\u304B\u3089\u51FA\u3066\u3044\u306A\u3044\u2026\u3002",
  "id" : 85243466342338560,
  "created_at" : "2011-06-27 07:10:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "85018549147541504",
  "geo" : { },
  "id_str" : "85021764287082496",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 5\u9650\u306E\u4E88\u7FD2\u306F\u9593\u306B\u5408\u308F\u306A\u304B\u3063\u305F\u3002\u306E\u3067\u4ECA\u65E5\u306F\u2026\u3002\u5927\u4E08\u592B\u304B\u306A\uFF1F",
  "id" : 85021764287082496,
  "in_reply_to_status_id" : 85018549147541504,
  "created_at" : "2011-06-26 16:29:02 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84954155130683392",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 84954155130683392,
  "created_at" : "2011-06-26 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84828552394055680",
  "geo" : { },
  "id_str" : "84828899548217344",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u6708\u9905\uFF01",
  "id" : 84828899548217344,
  "in_reply_to_status_id" : 84828552394055680,
  "created_at" : "2011-06-26 03:42:40 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84591752190763008",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 84591752190763008,
  "created_at" : "2011-06-25 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "84347083557056512",
  "geo" : { },
  "id_str" : "84347230772928513",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u306F\u3088\u3046",
  "id" : 84347230772928513,
  "in_reply_to_status_id" : 84347083557056512,
  "created_at" : "2011-06-24 19:48:41 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84347087432597504",
  "text" : "RT @JOJO_math: \u3042\u2026\u3042\u308A\u306E\u307E\u307E\u3000\u4ECA\u8D77\u3053\u3063\u305F\u4E8B\u3092\u8A71\u3059\u305C\uFF01\u300E\u304A\u308C\u306F\u3084\u3064\u306E\u524D\u3067\uFF13\u6B21\u5143\u5358\u4F4D\u7403\u3092\uFF15\u500B\u306B\u5207\u308A\u5206\u3051\u3066\u7D44\u307F\u76F4\u3057\u305F\u3068\u601D\u3063\u305F\u3089\u3044\u3064\u306E\u307E\u306B\u304B\uFF12\u500B\u306E\u5358\u4F4D\u7403\u304C\u3067\u304D\u3066\u3044\u305F\u300F\u306A\u2026\u4F55\u3092\u8A00\u3063\u3066\u3044\u308B\u306E\u304B\uFF08\u7565\uFF09\u932F\u8996\u3060\u3068\u304B\u8D85\u30B9\u30D4\u30FC\u30C9\u3060\u3068\u304B\u305D\u3093\u306A\u30C1\u30E3\u30C1\u306A\u3082\u3093\u3058\u3083\u3042\u65AD\u3058\u3066\u306D\u3048\u3000\u3082\u3063\u3068\u6050 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84342039101194240",
    "text" : "\u3042\u2026\u3042\u308A\u306E\u307E\u307E\u3000\u4ECA\u8D77\u3053\u3063\u305F\u4E8B\u3092\u8A71\u3059\u305C\uFF01\u300E\u304A\u308C\u306F\u3084\u3064\u306E\u524D\u3067\uFF13\u6B21\u5143\u5358\u4F4D\u7403\u3092\uFF15\u500B\u306B\u5207\u308A\u5206\u3051\u3066\u7D44\u307F\u76F4\u3057\u305F\u3068\u601D\u3063\u305F\u3089\u3044\u3064\u306E\u307E\u306B\u304B\uFF12\u500B\u306E\u5358\u4F4D\u7403\u304C\u3067\u304D\u3066\u3044\u305F\u300F\u306A\u2026\u4F55\u3092\u8A00\u3063\u3066\u3044\u308B\u306E\u304B\uFF08\u7565\uFF09\u932F\u8996\u3060\u3068\u304B\u8D85\u30B9\u30D4\u30FC\u30C9\u3060\u3068\u304B\u305D\u3093\u306A\u30C1\u30E3\u30C1\u306A\u3082\u3093\u3058\u3083\u3042\u65AD\u3058\u3066\u306D\u3048\u3000\u3082\u3063\u3068\u6050\u308D\u3057\u3044\u9078\u629E\u516C\u7406\u306E\u7247\u9C57\u3092\u5473\u308F\u3063\u305F\u305C\u2026",
    "id" : 84342039101194240,
    "created_at" : "2011-06-24 19:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 84347087432597504,
  "created_at" : "2011-06-24 19:48:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tenki.jp",
      "screen_name" : "tenkijp",
      "indices" : [ 3, 11 ],
      "id_str" : "43041891",
      "id" : 43041891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tenki_saitama",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/R4avzUH",
      "expanded_url" : "http:\/\/tenki.jp\/docs\/note\/setsuden_heat_syndrome\/",
      "display_url" : "tenki.jp\/docs\/note\/sets\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "84114475904532481",
  "text" : "RT @tenkijp: \u57FC\u7389\u770C\u718A\u8C37\u5E02\u306712:57\u306B39.3\u2103\u3092\u89B3\u6E2C\u3057\u307E\u3057\u305F\u3002\u65E5\u672C\u4E00\u6691\u3044\u718A\u8C37\u3067\u3082\u89B3\u6E2C\u53F2\u4E0A6\u756A\u76EE\u306B\u6691\u3044\u6C17\u6E29\u3067\u3059\u3002\u897F\u65E5\u672C\u3084\u6771\u65E5\u672C\u3092\u4E2D\u5FC3\u306B\u5927\u5909\u6691\u304F\u306A\u3063\u3066\u3044\u307E\u3059\u3002\u71B1\u4E2D\u75C7\u5BFE\u7B56\u3092\u4E07\u5168\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002 #tenki_saitama http:\/\/t.co\/R4avzUH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tenki_saitama",
        "indices" : [ 89, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 123 ],
        "url" : "http:\/\/t.co\/R4avzUH",
        "expanded_url" : "http:\/\/tenki.jp\/docs\/note\/setsuden_heat_syndrome\/",
        "display_url" : "tenki.jp\/docs\/note\/sets\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "84113945643843584",
    "text" : "\u57FC\u7389\u770C\u718A\u8C37\u5E02\u306712:57\u306B39.3\u2103\u3092\u89B3\u6E2C\u3057\u307E\u3057\u305F\u3002\u65E5\u672C\u4E00\u6691\u3044\u718A\u8C37\u3067\u3082\u89B3\u6E2C\u53F2\u4E0A6\u756A\u76EE\u306B\u6691\u3044\u6C17\u6E29\u3067\u3059\u3002\u897F\u65E5\u672C\u3084\u6771\u65E5\u672C\u3092\u4E2D\u5FC3\u306B\u5927\u5909\u6691\u304F\u306A\u3063\u3066\u3044\u307E\u3059\u3002\u71B1\u4E2D\u75C7\u5BFE\u7B56\u3092\u4E07\u5168\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002 #tenki_saitama http:\/\/t.co\/R4avzUH",
    "id" : 84113945643843584,
    "created_at" : "2011-06-24 04:21:42 +0000",
    "user" : {
      "name" : "tenki.jp",
      "screen_name" : "tenkijp",
      "protected" : false,
      "id_str" : "43041891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473482990178156544\/QukY2N-0_normal.png",
      "id" : 43041891,
      "verified" : true
    }
  },
  "id" : 84114475904532481,
  "created_at" : "2011-06-24 04:23:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83938718314020864",
  "text" : "\u306E\u524D\u306B\u4ECA\u65E5\u306E\u5929\u6C17\n\u66C7\u306E\u3061\u96E8 \u6700\u9AD8\u6C17\u6E29 32\u2103 \n\u524D\u65E5\u5DEE (-1) \n\u6700\u4F4E\u6C17\u6E29 25\u2103 \n\u524D\u65E5\u5DEE (0) \n \u6642\u9593\u5E2F(\u6642) 0-6 6-12 12-18 18-24 \n\u964D\u6C34\u78BA\u7387    10%  10%   20%   50% \n\u98A8 \u5357\u897F\u306E\u98A8",
  "id" : 83938718314020864,
  "created_at" : "2011-06-23 16:45:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83938365581434880",
  "text" : "\u9AEA\u304B\u308F\u3044\u3066\u306A\u3044\u304B\u3089\u5BDD\u7656\u306B\u306A\u308B\u306A\u30FB\u30FB\u30FB\u3067\u3082\u3082\u3046\u3044\u3044\u3084\u3002\u5BDD\u308B\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 83938365581434880,
  "created_at" : "2011-06-23 16:44:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83937973342703616",
  "geo" : { },
  "id_str" : "83938127072337920",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u30CD\u30BF\u30D0\u30EC\u3057\u306A\u3044\u3067\u306D\uFF01\u5148\u9031\u5206\u3067\u3082\u3046\u6CE3\u304D\u305D\u3046\u3060\u3063\u305F\u3002",
  "id" : 83938127072337920,
  "in_reply_to_status_id" : 83937973342703616,
  "created_at" : "2011-06-23 16:43:03 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83936738254393344",
  "text" : "\u3042\u30FC2\u9650\u4F11\u8B1B\u30671\u9650\u51FA\u308B\u6C17\u3057\u306A\u3044\u3088\u306A\u30FC\u30FB\u30FB\u30FB\u3002\u884C\u3063\u3066\u5FAE\u7A4D\u304C\u30D9\u30B9\u30C8\u304B\u3002",
  "id" : 83936738254393344,
  "created_at" : "2011-06-23 16:37:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83936432342843393",
  "text" : "\u3042\u306E\u82B1\u3082\uFF23\u3082\u6700\u7D42\u56DE\u304B\u30FB\u30FB\u30FB\u898B\u308B\u306E\u306F\u3061\u3087\u3046\u306920\u6642\u9593\u5F8C\u3050\u3089\u3044\u304B\u306A\uFF1F",
  "id" : 83936432342843393,
  "created_at" : "2011-06-23 16:36:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83932770220515329",
  "text" : "\u8CDE\u5473\u671F\u9650\u4E00\u6642\u9593\u5F31\u3082\u904E\u304E\u305F\u725B\u4E73\u3092\u98F2\u3093\u3067\u3057\u307E\u3063\u305F\u3002\u3002\u3002",
  "id" : 83932770220515329,
  "created_at" : "2011-06-23 16:21:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83866977302622208",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 83866977302622208,
  "created_at" : "2011-06-23 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 3, 16 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83796562177830912",
  "text" : "RT @galletti_bot: \u4ECA\u65E5\u306F\u306A\u3093\u3068\u6691\u3044\u3053\u3068\u304B\u3002\u6E29\u5EA6\u8A08\u304C\u56DB\u5341\u3068\u4E8C\u5341\u4E03\u30D5\u30A3\u30FC\u30C8\u307E\u3067\u9019\u3044\u767B\u3063\u3066\u3044\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83796348159270912",
    "text" : "\u4ECA\u65E5\u306F\u306A\u3093\u3068\u6691\u3044\u3053\u3068\u304B\u3002\u6E29\u5EA6\u8A08\u304C\u56DB\u5341\u3068\u4E8C\u5341\u4E03\u30D5\u30A3\u30FC\u30C8\u307E\u3067\u9019\u3044\u767B\u3063\u3066\u3044\u308B\u3002",
    "id" : 83796348159270912,
    "created_at" : "2011-06-23 07:19:40 +0000",
    "user" : {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "protected" : false,
      "id_str" : "99320050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1835516629\/galletti_128_normal.png",
      "id" : 99320050,
      "verified" : false
    }
  },
  "id" : 83796562177830912,
  "created_at" : "2011-06-23 07:20:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83795336371503104",
  "text" : "\u65E5\u5149\u6D74\u3058\u3083\u306A\u304F\u3066\u65E5\u5149\u907F\u3051",
  "id" : 83795336371503104,
  "created_at" : "2011-06-23 07:15:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83788871065808896",
  "geo" : { },
  "id_str" : "83795118708097024",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u6D41\u5C40\u3057\u306A\u3044\u306E\u304B\u3001\u53B3\u3057\u3044\u306A\u3002\u305F\u3044\u3066\u3044\u30C0\u30D6\u30ED\u30F3\u307E\u3067\u306F\u6E05\u7B97\u306A\u3093\u3060\u3051\u3069\u306D\u30FC\u3002",
  "id" : 83795118708097024,
  "in_reply_to_status_id" : 83788871065808896,
  "created_at" : "2011-06-23 07:14:47 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83786650458656768",
  "geo" : { },
  "id_str" : "83787866102173697",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \u5FDC\u2606\u63F4\u2606\u63A8\u2606\u5968\uFF01",
  "id" : 83787866102173697,
  "in_reply_to_status_id" : 83786650458656768,
  "created_at" : "2011-06-23 06:45:58 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83787518318874624",
  "text" : "RT @JOJO_math: \u3060\u304Ccot(r)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83783357472849920",
    "text" : "\u3060\u304Ccot(r)",
    "id" : 83783357472849920,
    "created_at" : "2011-06-23 06:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 83787518318874624,
  "created_at" : "2011-06-23 06:44:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83779217963229184",
  "geo" : { },
  "id_str" : "83787443073069056",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u30C8\u30EA\u30ED\u30F3\u306F\u6E05\u7B97\uFF1F\u6D41\u5C40\uFF1F",
  "id" : 83787443073069056,
  "in_reply_to_status_id" : 83779217963229184,
  "created_at" : "2011-06-23 06:44:17 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83719381586153472",
  "text" : "RT @JOJO_math: \u300E\u5E2F\u5206\u6570\u300F\u2026\u305D\u3093\u306A\u6982\u5FF5\u306F\u4F7F\u3046\u5FC5\u8981\u304C\u306D\u30FC\u3093\u3060\u3000\u306A\u305C\u306A\u3089\u30AA\u30EC\u3084\u30AA\u30EC\u305F\u3061\u306E\u4EF2\u9593\u306F\u3000\u305D\u306E\u6982\u5FF5\u3092\u982D\u306E\u4E2D\u3067\u7406\u89E3\u3057\u305F\u6642\u306B\u306F\uFF01\u5B9F\u969B\u306B\u5C0F\u5B66\u6821\u3092\u5352\u696D\u3057\u3066\u7B97\u6570\u304C\u3082\u3046\u3059\u3067\u306B\u7D42\u308F\u3063\u3066\u308B\u304B\u3089\u3060\uFF01\u3060\u304B\u3089\u4F7F\u3063\u305F\u4E8B\u304C\u306D\u30A7\u30FC\u30C3\uFF01\u300E\u4EEE\u5206\u6570\u300F\u306A\u3089\u4F7F\u3063\u3066\u3082\u3044\u3044\u30C3\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83707861645004800",
    "text" : "\u300E\u5E2F\u5206\u6570\u300F\u2026\u305D\u3093\u306A\u6982\u5FF5\u306F\u4F7F\u3046\u5FC5\u8981\u304C\u306D\u30FC\u3093\u3060\u3000\u306A\u305C\u306A\u3089\u30AA\u30EC\u3084\u30AA\u30EC\u305F\u3061\u306E\u4EF2\u9593\u306F\u3000\u305D\u306E\u6982\u5FF5\u3092\u982D\u306E\u4E2D\u3067\u7406\u89E3\u3057\u305F\u6642\u306B\u306F\uFF01\u5B9F\u969B\u306B\u5C0F\u5B66\u6821\u3092\u5352\u696D\u3057\u3066\u7B97\u6570\u304C\u3082\u3046\u3059\u3067\u306B\u7D42\u308F\u3063\u3066\u308B\u304B\u3089\u3060\uFF01\u3060\u304B\u3089\u4F7F\u3063\u305F\u4E8B\u304C\u306D\u30A7\u30FC\u30C3\uFF01\u300E\u4EEE\u5206\u6570\u300F\u306A\u3089\u4F7F\u3063\u3066\u3082\u3044\u3044\u30C3\uFF01",
    "id" : 83707861645004800,
    "created_at" : "2011-06-23 01:28:04 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 83719381586153472,
  "created_at" : "2011-06-23 02:13:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83692247303983104",
  "text" : "\u3044\u304B\u306B\u3082\u65E5\u672C\u306E\u590F\u306E\u671D\u3063\u3066\u65E5\u672C\u306E\u590F\u306E\u671D\u3060\u306A",
  "id" : 83692247303983104,
  "created_at" : "2011-06-23 00:26:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83685229931397120",
  "text" : "\uFF33\uFF302\u306E\u7D42\u308F\u3063\u3066\u3057\u307E\u3063\u305F\u30B3\u30F3\u30C6\u30F3\u30C4\u611F\u306F\u7570\u5E38",
  "id" : 83685229931397120,
  "created_at" : "2011-06-22 23:58:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83685112583176192",
  "text" : "\u7D50\u5C40\u671D\u304B\u3089\u30AD\u30F3\u30B0\u30C0\u30E0\u30CF\u30FC\u30C4\u3084\u3063\u3066\u305F\u30FB\u30FB\u30FB\u4F55\u3084\u3063\u3066\u3093\u3060\u304B\u306A\u3041",
  "id" : 83685112583176192,
  "created_at" : "2011-06-22 23:57:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83666305080766464",
  "text" : "\u6628\u591C\u306E\u8352\u3076\u308A\u5177\u5408\u3067\uFF14\uFF13tpd(tweet per day)\u304B\u3002\uFF12\uFF10\uFF10tpd\u3068\u304B\u4FFA\u306B\u306F\u7121\u7406\u3060\u306A\u3002",
  "id" : 83666305080766464,
  "created_at" : "2011-06-22 22:42:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83665544301125632",
  "text" : "\uFF23\u3068\u3042\u306E\u82B1\u307F\u3066\u6642\u9593\u6F70\u305D\u3046\u304B\u3068\u601D\u3063\u305F\u304C\u3042\u306E\u82B1\u306A\u3093\u304B\u898B\u3061\u3083\u3063\u305F\u3089\u5927\u5B66\u884C\u304F\u6C17\u7121\u304F\u306A\u308A\u305D\u3046",
  "id" : 83665544301125632,
  "created_at" : "2011-06-22 22:39:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83661665442332672",
  "text" : "\uFF12\u9650\u304B\u3089\u306A\u306E\u306B\u76EE\u304C\u899A\u3081\u3066\u3057\u307E\u3063\u305F\u306A\u2026",
  "id" : 83661665442332672,
  "created_at" : "2011-06-22 22:24:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83660590618394625",
  "text" : "\u6700\u9AD8\u6C17\u6E29\uFF13\uFF11\u2103\u3063\u3066\u4F55\u3055",
  "id" : 83660590618394625,
  "created_at" : "2011-06-22 22:20:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83660401006485505",
  "text" : "\u304A\u306F\u3088\u3046 \u304A\u306F\u3088\u3046",
  "id" : 83660401006485505,
  "created_at" : "2011-06-22 22:19:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 17, 28 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83569477760974848",
  "geo" : { },
  "id_str" : "83570027604873216",
  "in_reply_to_user_id" : 213268728,
  "text" : "\u5834\u672B\u904E\u304E\u3066\u6765\u3066\u306A\u3044(\uFF77\uFF98\uFF6F QT @magokoro84: \u30B5\u30FC\u30AF\u30EB\u306E\u65B0\u6B53\u7528\u30A2\u30C9\u30EC\u30B9\u306B\u5927\u548C\u8A3C\u5238\u3068\u30B5\u30F3\u30C8\u30EA\u30FC\u3092\u4E0D\u6CD5\u89E3\u96C7\u3055\u308C\u305F\u3093\u3067\u3084\u308B\u3053\u3068\u306A\u3044\u304B\u3089\u4EAC\u5927\u5165\u308A\u76F4\u3057\u3066\u5927\u4F01\u696D\u3068\u6226\u3063\u3066\u308B\u3093\u3067\u3059\u3051\u3069\u5FA1\u5B85\u306E\u30B5\u30FC\u30AF\u30EB\u5165\u308C\u307E\u3059\u304B\uFF1F\u3063\u3066\u3044\u3046\u30E1\u30FC\u30EB\u6765\u3066\u305F\u3051\u3069\u3044\u308D\u3093\u306A\u3068\u3053\u308D\u306B\u4F3C\u305F\u3088\u3046\u306A\u30E1\u30FC\u30EB\u9001\u3089\u308C\u3066\u308B\u307F\u305F\u3044",
  "id" : 83570027604873216,
  "in_reply_to_status_id" : 83569477760974848,
  "created_at" : "2011-06-22 16:20:21 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83560626156343296",
  "geo" : { },
  "id_str" : "83560875939741696",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4ECA\u65E5\u3060\uFF52",
  "id" : 83560875939741696,
  "in_reply_to_status_id" : 83560626156343296,
  "created_at" : "2011-06-22 15:43:59 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83536362703290368",
  "geo" : { },
  "id_str" : "83536757299220481",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u590F\u306E\u591C\u3002\u4ECA\u591C\u306F\u307E\u3055\u306B\u305D\u3093\u306A\u611F\u3058\u3060\u3002\u6E7F\u6C17\u3068\u71B1\u6C17\u3068\u2026",
  "id" : 83536757299220481,
  "in_reply_to_status_id" : 83536362703290368,
  "created_at" : "2011-06-22 14:08:09 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 11, 21 ],
      "id_str" : "133376125",
      "id" : 133376125
    }, {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 22, 31 ],
      "id_str" : "256321768",
      "id" : 256321768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83529328176013312",
  "geo" : { },
  "id_str" : "83529704174391297",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 @blackpiyu @mar1e666 \u5922\u843D\u3061\u3068\u304B\u65AC\u65B0\u3060",
  "id" : 83529704174391297,
  "in_reply_to_status_id" : 83529328176013312,
  "created_at" : "2011-06-22 13:40:08 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83524981950128128",
  "geo" : { },
  "id_str" : "83525136157900800",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u5358\u5C04\u306F\u5C11\u306A\u3044",
  "id" : 83525136157900800,
  "in_reply_to_status_id" : 83524981950128128,
  "created_at" : "2011-06-22 13:21:58 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83525014070112256",
  "text" : "\u51FA\u753A\u7740\u3044\u305F\u3002\u96E2\u8131\u3002",
  "id" : 83525014070112256,
  "created_at" : "2011-06-22 13:21:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83524707139334144",
  "text" : "\u524D\u8005\u3041\u2026",
  "id" : 83524707139334144,
  "created_at" : "2011-06-22 13:20:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83524641200685056",
  "text" : "\u30DC\u30E0\u30C3\u30BF\u30FC\u3068\u30D5\u30E9\u30F3\u30DC\u30C3\u30C8\u3063\u3066\u3069\u3046\u9055\u3046\u3093\u3060\u308D\u3002\u5168\u5C04\u3057\u304B\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u306A\u3044\u3002",
  "id" : 83524641200685056,
  "created_at" : "2011-06-22 13:20:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83523819054174208",
  "text" : "\u305D\u3082\u305D\u3082\u4E16\u306E\u4E2D\u306B\u6570\u5B57\u304C\u6EA2\u308C\u3059\u304E\u3066\u3044\u308B\u2026",
  "id" : 83523819054174208,
  "created_at" : "2011-06-22 13:16:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83523669153955840",
  "text" : "\u6570\u5B66\u5973\u5B50\u3088\u308D\u3057\u304F\u898B\u3048\u308B\u6570\u5B57\u5168\u3066\u3092\u8DB3\u305D\u3046\u3068\u3059\u308B\u2192\u60C5\u5831\u51E6\u7406\u3057\u304D\u308C\u305A\u306B\u9813\u632B \u3092\u7E70\u308A\u8FD4\u3059",
  "id" : 83523669153955840,
  "created_at" : "2011-06-22 13:16:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83522360380104704",
  "text" : "\u8352\u3076\u308A\u3059\u304E\u304B\u306A\u3002\u30D0\u30A4\u30C8\u5E30\u308A\u3063\u3066\u6563\u3005\u558B\u308A\u6563\u3089\u3057\u3066\u308B\u306F\u305A\u306A\u306E\u306B\u306A\u30FC\u3002",
  "id" : 83522360380104704,
  "created_at" : "2011-06-22 13:10:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 10, 17 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83522167928659969",
  "text" : "\u30C8\u30EA\u30D3\u30A2\u30EB\uFF01 RT @khulud: \u3069\u3070\u306B\u3083\u3093\u306F\u3044\u3063\u3071\u3044\u3044\u3059\u304E\u3066\u3082\u3046\u3069\u308C\u304C\u672C\u7269\u304B\u306A\u3093\u3066\u8003\u3048\u3066\u3082\u30CA\u30F3\u30BB\u30F3\u30B9\uFF0E",
  "id" : 83522167928659969,
  "created_at" : "2011-06-22 13:10:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 22, 31 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83521998189371392",
  "text" : "\u5B9F\u5BB6\u306E\u5411\u304B\u3044\u306E\u58C1\u306E\u5A7F\u3046\u3082\u304A\u5893\u3060\u3063\u305F\u304B RT @akeopyaa: \u5B9F\u5BB6\u306E\u524D\u3082\u304A\u5893\u3067\u3059\u3002\u982D\u306E\u4E2D\u306F\u304A\u99AC\u9E7F\u3067\u3059\u3002\u8AB0\u304B\u52A9\u3051\u3066\u304F\u3060\u3055\u3044\u3002\u304A\u5A7F\u306B\u8CB0\u3063\u3066\u304F\u3060\u3055\u3044\u3002",
  "id" : 83521998189371392,
  "created_at" : "2011-06-22 13:09:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u539F\u2252\u306B\u305B\u7269\u7406\u5B66\u5F92",
      "screen_name" : "hhara_iwate",
      "indices" : [ 3, 15 ],
      "id_str" : "276105342",
      "id" : 276105342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83521666780643328",
  "text" : "RT @hhara_iwate: \u6B21\u306F\u3001\u5165\u9662\u4E2D\u306B\u5927\u767A\u898B\u3092\u3057\u305F\u8A71\u3002\n\u203B\u5165\u9662\u3068\u306F\u3001\u5927\u5B66\u9662\u306B\u5165\u308B\u3053\u3068\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83521412664541184",
    "text" : "\u6B21\u306F\u3001\u5165\u9662\u4E2D\u306B\u5927\u767A\u898B\u3092\u3057\u305F\u8A71\u3002\n\u203B\u5165\u9662\u3068\u306F\u3001\u5927\u5B66\u9662\u306B\u5165\u308B\u3053\u3068\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
    "id" : 83521412664541184,
    "created_at" : "2011-06-22 13:07:11 +0000",
    "user" : {
      "name" : "\u539F\u2252\u306B\u305B\u7269\u7406\u5B66\u5F92",
      "screen_name" : "hhara_iwate",
      "protected" : false,
      "id_str" : "276105342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1300186277\/image_normal.jpg",
      "id" : 276105342,
      "verified" : false
    }
  },
  "id" : 83521666780643328,
  "created_at" : "2011-06-22 13:08:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 18, 27 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 29, 39 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83521587936116737",
  "text" : "\u8FC5\u901F\u306B\u3058\u3087\u3046\u305A\u306B\u96C6\u3081\u3066\u304D\u305F\u306A RT @akeopyaa: @end313124 \u307E\u305F\u307E\u305F\u4E94\u6761\u8AC7\u3092\u3002\u3068\u3001\u304F\u3060\u3089\u306A\u3044\u3053\u3068\u3092\u8A00\u3044\u306B\uFF16\u7573\u306E\u90E8\u5C4B\u304B\u3089\u53C2\u4E0A\u3057\u307E\u3057\u305F\u3002",
  "id" : 83521587936116737,
  "created_at" : "2011-06-22 13:07:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83521009801637889",
  "text" : "\u4E00\u756A\u304F\u3058\u3063\u3066\u4F55\u304C\u4E00\u756A\u306A\u306E\u304B\u306A\uFF1F",
  "id" : 83521009801637889,
  "created_at" : "2011-06-22 13:05:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83520889261535232",
  "text" : "\u3067\u3082\u307E\u3060\u6771\u798F\u5BFA\u3002\u8C46\u8150\u304F\u3058\uFF1F\u4E00\u7B49\u3001\u3056\u308B\u8C46\u8150\u3002\n\u3042\u3001\u4FFA\u304C\u597D\u304D\u306A\u3060\u3051\u304B\u3002",
  "id" : 83520889261535232,
  "created_at" : "2011-06-22 13:05:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83520440043175936",
  "text" : "\u64EC\u97F3\u8A9E\u306E\u4E09\u9023\u306F\u8AAD\u307F\u306B\u304F\u3044\u306A\u3002\u3042\u30FC\u7947\u5712\u56DB\u6761\u3060\u3051\u306B\u56DB\u9023\u306B\u3059\u3079\u304D\u3060\u3063\u305F\u304B\u2026\u3002\u64EC\u97F3\u56DB\u4E57\uFF1F",
  "id" : 83520440043175936,
  "created_at" : "2011-06-22 13:03:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83519919005765632",
  "text" : "\u6E7F\u5EA6\u306E\u305B\u3044\u3067\u9AEA\u304C\u3082\u308F\u3082\u308F\u3082\u3055\u3082\u3055\u3079\u305F\u3079\u305F\u3059\u308B\u2026\u4E0D\u5FEB\u3002",
  "id" : 83519919005765632,
  "created_at" : "2011-06-22 13:01:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83519488322060288",
  "text" : "\u5145\u96FB\u306E\u6E1B\u308A\u304C\u306F\u3084\u3044\u306F\u3084\u3044",
  "id" : 83519488322060288,
  "created_at" : "2011-06-22 12:59:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83519343220097024",
  "text" : "\u3044\u3084\u306F\u3084\u306F\u3084\u3044",
  "id" : 83519343220097024,
  "created_at" : "2011-06-22 12:58:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 25, 34 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 36, 46 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83518125353598976",
  "text" : "\u4E94\u91CC\u9727\u4E2D\u3067\u3001\u6697\u4E2D\u6A21\u7D22\u3067\u4EBA\u4E8B\u4E0D\u8096\u3067\u6709\u8C61\u7121\u8C61\u3060 RT @akeopyaa: @end313124 \u4E94\u91CC\u9727\u4E2D\u3060\u306A",
  "id" : 83518125353598976,
  "created_at" : "2011-06-22 12:54:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83517671022395392",
  "text" : "\u91E3\u308C\u305F\u3001\u3067\u3057\u305F\u3002\u3067\u3082\u30D5\u30A9\u30ED\u30EF\u30FC\u306B\u30DD\u30B1\u30E2\u30F3\u30AF\u30E9\u30B9\u30BF\u6B86\u3069\u3044\u306A\u3044\u304B\u3089\uFF2F\uFF2B",
  "id" : 83517671022395392,
  "created_at" : "2011-06-22 12:52:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83517460246044672",
  "text" : "\u6728\u7BB1\u306F\u30AB\u30BF\u30CA\u30AB\u306E\u65B9\u304C\u30DD\u30B1\u30E2\u30F3\u30AF\u30E9\u30B9\u30BF\u3092\u9023\u308C\u305F\u304B\u306A\u3002",
  "id" : 83517460246044672,
  "created_at" : "2011-06-22 12:51:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83516962830946304",
  "text" : "\u9AD8\u7D1A\u306A\u6728\u7BB1\u306E\u7D20\u6750\u306F(ry",
  "id" : 83516962830946304,
  "created_at" : "2011-06-22 12:49:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83516865086889984",
  "text" : "\u7A74\u3092\u958B\u3051\u308B\u9053\u5177\u306F\u300C\u304D\u308A\u300D(\uFF77\uFF98\uFF6F",
  "id" : 83516865086889984,
  "created_at" : "2011-06-22 12:49:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83516670223716352",
  "text" : "\u8108\u7D61\u304C\u306A\u3044\uFF1F\u81F3\u308B\u3068\u3053\u308D\u3067\u9023\u7D9A\u3067\u5FAE\u5206\u4E0D\u53EF\u80FD\u306A\u3060\u3051\u3067\u3059(\uFF77\uFF98\uFF6F",
  "id" : 83516670223716352,
  "created_at" : "2011-06-22 12:48:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83516424475258881",
  "text" : "\u3042\u30FC\u3001\u3057\u3087\u3046\u3082\u306A\u3044\u3002",
  "id" : 83516424475258881,
  "created_at" : "2011-06-22 12:47:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83516364299571200",
  "text" : "\u866B\u7121\u8996\u30B9\u30EB\u30FC",
  "id" : 83516364299571200,
  "created_at" : "2011-06-22 12:47:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83516304459436032",
  "text" : "\u7121\u8996\u866B\u3059\u308B\u3002",
  "id" : 83516304459436032,
  "created_at" : "2011-06-22 12:46:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83516225841410048",
  "text" : "\u30E0\u30B7\u30E0\u30B7\u3059\u308B\u2026\u3002",
  "id" : 83516225841410048,
  "created_at" : "2011-06-22 12:46:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83515987613319168",
  "text" : "\u305D\u308C\u3067\u3082\u300C\u30D0\u30F3\u30D1\u30A4\u30A2\u30CF\u30F3\u30BF\u30FC\u304C\u8D85\u9811\u5F35\u3063\u3066\u308B\u3093\u3060\u3088\uFF01\u300D\u3063\u3066\u7B54\u3048\u305F\u3068\u3082\u3061\u3083\u3093\u2026",
  "id" : 83515987613319168,
  "created_at" : "2011-06-22 12:45:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83515649590165504",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u6570\u5B66\u5973\u5B50\u306B\u30D0\u30F3\u30D1\u30A4\u30A2\u304C\u4E00\u65E5\u306B\u4E00\u4EBA\u8840\u3092\u5438\u3044\u30D0\u30F3\u30D1\u30A4\u30A2\u3092\u4F5C\u308B\u3068\u4E00\u6708\u3067\u5168\u4EBA\u985E\u3092\u30D0\u30F3\u30D1\u30A4\u30A2\u306B\u3057\u3066\u3057\u307E\u3046\u3063\u3066\u3042\u3063\u305F\u3051\u3069\u3001\u305D\u306E\u70B9\u3067\u307E\u3088\u3044\u30AD\u30E7\u30F3\u30B7\u30FC\u306F\u30EA\u30A2\u30EA\u30C6\u30A3\u304C\u3042\u3063\u305F\u3093\u3060\u306A\u3002",
  "id" : 83515649590165504,
  "created_at" : "2011-06-22 12:44:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83514948638085120",
  "geo" : { },
  "id_str" : "83515222085742592",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u732B\u4E00\u5339\u3067\u5165\u90E8\u306B\u8DB3\u308B\uFF6F\uFF01",
  "id" : 83515222085742592,
  "in_reply_to_status_id" : 83514948638085120,
  "created_at" : "2011-06-22 12:42:35 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "83514628444917760",
  "geo" : { },
  "id_str" : "83515087377276928",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u7A81\u3063\u8FBC\u307F\u30B5\u30F3\u30AF\u30B9\u3002\u3053\u3046\u3044\u3046\u306E\u30EA\u30A2\u30EB\u3067\u8A00\u3046\u3068\u4E00\u5207\u4F1D\u308F\u3089\u305A\u306B\u5207\u306A\u3044\u304B\u3089\u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u3042\u308A\u304C\u305F\u3044\uFF57",
  "id" : 83515087377276928,
  "in_reply_to_status_id" : 83514628444917760,
  "created_at" : "2011-06-22 12:42:03 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83514591480516608",
  "text" : "\u5927\u962A\u57CE\u306B\u3044\u305F\u306E\u3082\u96F6\u8FD1\u304B\u3063\u305F\u306A\u3002",
  "id" : 83514591480516608,
  "created_at" : "2011-06-22 12:40:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83514321417678848",
  "text" : "\u54F2\u5B66\u306E\u9053\u306B\u5C45\u308B\u732B\u306E\u8B66\u6212\u30EC\u30D9\u30EB\u306F\u8CA0\u306E\u5024",
  "id" : 83514321417678848,
  "created_at" : "2011-06-22 12:39:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83514103569727488",
  "text" : "\u732B\u306E\u6069\u8FD4\u3057\u304C\u597D\u304D\u3060\u304C\u732B\u304C\u597D\u304D\u306A\u306E\u304B\u732B\u306E\u6069\u8FD4\u3057\u304C\u597D\u304D\u306A\u306E\u304B\u89E3\u3089\u306A\u3044\u3002",
  "id" : 83514103569727488,
  "created_at" : "2011-06-22 12:38:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83513248984473600",
  "text" : "Rt\u3067\u6642\u9593\u3092\u5909\u6570\u3068\u3057\u305F\u534A\u5F84\u306E\u51FD\u6570\u3092\u601D\u3044\u51FA\u3057\u305F\u79C1\u306F\u75C5\u5E7E\u4F55\u3082\u3057\u308C\u306A\u3044\u3002",
  "id" : 83513248984473600,
  "created_at" : "2011-06-22 12:34:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83512964442886144",
  "text" : "\u8352\u3076\u308B\u30C4\u30A4\u30FC\u30C8(\u30EA\u30D7\u30E9\u30A4\u3001RT\u542B\u3080)",
  "id" : 83512964442886144,
  "created_at" : "2011-06-22 12:33:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83512728861417472",
  "text" : "\u672C\u8CEA\u3001\u69CB\u9020\u3092\u898B\u629C\u304F\u76EE\u2026",
  "id" : 83512728861417472,
  "created_at" : "2011-06-22 12:32:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 11, 21 ],
      "id_str" : "133376125",
      "id" : 133376125
    }, {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 22, 31 ],
      "id_str" : "256321768",
      "id" : 256321768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83512509922938880",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 @blackpiyu @mar1e666 \u307E\u3055\u2026\u4FE1\u3058\u3066\u305F\u306E\u306B\u3002",
  "id" : 83512509922938880,
  "created_at" : "2011-06-22 12:31:48 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "\u8B0E\u306E\u9B54\u5C0E\u5E2BX",
      "screen_name" : "m_wizard",
      "indices" : [ 21, 30 ],
      "id_str" : "80495831",
      "id" : 80495831
    }, {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 32, 39 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 77, 84 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83361372259360769",
  "text" : "RT @NHK_PR: \u307E\u3063\u305F\u304F\u3002 RT @m_wizard: @NHK_PR \u3068\u3053\u308D\u3067\u3001\u305D\u3046\u3044\u3046\u5F53\u306E1\u53F7\u3055\u3093\u3054\u672C\u4EBA\u306F\u671F\u5F85\u3057\u3066\u3044\u308B\u306E\u3067\u3057\u3087\u3046\u304B\uFF57\uFF1F RT @NHK_PR: (\uFF9F\uFF70\uFF9F*)\uFF61oO\uFF08\u3053\u306E\u3042\u3068\u306F\u30012\u53F7\u5148\u8F29\u304C\u8D85\u304A\u3082\u3057\u308D\u30C4\u30A4\u30FC\u30C8\u3092\u3057\u307E\u3059\u30022\u53F7\u5148\u8F29\u306E\u6B21\u56DE\u4F5C\u306B\u3054\u671F\u5F85\u304F\u3060\u3055\u3044\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u8B0E\u306E\u9B54\u5C0E\u5E2BX",
        "screen_name" : "m_wizard",
        "indices" : [ 9, 18 ],
        "id_str" : "80495831",
        "id" : 80495831
      }, {
        "name" : "NHK\u5E83\u5831\u5C40",
        "screen_name" : "NHK_PR",
        "indices" : [ 20, 27 ],
        "id_str" : "93311525",
        "id" : 93311525
      }, {
        "name" : "NHK\u5E83\u5831\u5C40",
        "screen_name" : "NHK_PR",
        "indices" : [ 65, 72 ],
        "id_str" : "93311525",
        "id" : 93311525
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83355555015573504",
    "text" : "\u307E\u3063\u305F\u304F\u3002 RT @m_wizard: @NHK_PR \u3068\u3053\u308D\u3067\u3001\u305D\u3046\u3044\u3046\u5F53\u306E1\u53F7\u3055\u3093\u3054\u672C\u4EBA\u306F\u671F\u5F85\u3057\u3066\u3044\u308B\u306E\u3067\u3057\u3087\u3046\u304B\uFF57\uFF1F RT @NHK_PR: (\uFF9F\uFF70\uFF9F*)\uFF61oO\uFF08\u3053\u306E\u3042\u3068\u306F\u30012\u53F7\u5148\u8F29\u304C\u8D85\u304A\u3082\u3057\u308D\u30C4\u30A4\u30FC\u30C8\u3092\u3057\u307E\u3059\u30022\u53F7\u5148\u8F29\u306E\u6B21\u56DE\u4F5C\u306B\u3054\u671F\u5F85\u304F\u3060\u3055\u3044\uFF09",
    "id" : 83355555015573504,
    "created_at" : "2011-06-22 02:08:07 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 83361372259360769,
  "created_at" : "2011-06-22 02:31:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 3, 13 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83361124258549760",
  "text" : "RT @nisehorrn: \u30B9\u30AB\u30A4\u30D7\u30C6\u30B9\u30C8\u901A\u8A71\u3067\u30B9\u30C8\u30EC\u30B9\u767A\u6563\u3057\u3066\u308B\u30A2\u30DB\u306F\u4FFA\u3067\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83351377518137345",
    "text" : "\u30B9\u30AB\u30A4\u30D7\u30C6\u30B9\u30C8\u901A\u8A71\u3067\u30B9\u30C8\u30EC\u30B9\u767A\u6563\u3057\u3066\u308B\u30A2\u30DB\u306F\u4FFA\u3067\u3059\u3002",
    "id" : 83351377518137345,
    "created_at" : "2011-06-22 01:51:31 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "protected" : false,
      "id_str" : "96560355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009740902\/06-12-24_23-49_kisee_bigger_normal.jpg",
      "id" : 96560355,
      "verified" : false
    }
  },
  "id" : 83361124258549760,
  "created_at" : "2011-06-22 02:30:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83191602583052289",
  "text" : "@np2i \u82F1\u8A9E\u3060\u3068\u30D6\u30E9\u30C3\u30AF\u30C6\u30A3\u30FC\u3067\u3059\u3082\u3093\u306D\u3047",
  "id" : 83191602583052289,
  "created_at" : "2011-06-21 15:16:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83142243959050240",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 83142243959050240,
  "created_at" : "2011-06-21 12:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82971689192931329",
  "text" : "\u6628\u65E5\u306E\u5929\u6C17\u4E88\u5831\u3067\u306F\u96E8\u3060\u3063\u305F\u3093\u3060\u3051\u3069\u2026",
  "id" : 82971689192931329,
  "created_at" : "2011-06-21 00:42:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82971555423981568",
  "text" : "\u6C17\u6E29\u304C\u9AD8\u3044\u306E\u306F\uFF34\uFF2C\u3067\u89E3\u3063\u305F\u304C\u96E8\u306F\u2026\uFF1F",
  "id" : 82971555423981568,
  "created_at" : "2011-06-21 00:42:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82971173956227072",
  "text" : "\u643A\u5E2F\u5145\u96FB\u3057\u640D\u306A\u3063\u3066\u305F\u2026",
  "id" : 82971173956227072,
  "created_at" : "2011-06-21 00:40:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82971066812739584",
  "text" : "\u8D77\u304D\u305F\u3002\u304A\u306F\u3088\u3046\u3002",
  "id" : 82971066812739584,
  "created_at" : "2011-06-21 00:40:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AB (\u975E\u516C\u5F0Fbot)",
      "screen_name" : "miruka_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "118009758",
      "id" : 118009758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82808688754176001",
  "geo" : { },
  "id_str" : "82809008540495872",
  "in_reply_to_user_id" : 118009758,
  "text" : "@miruka_bot \uFF15",
  "id" : 82809008540495872,
  "in_reply_to_status_id" : 82808688754176001,
  "created_at" : "2011-06-20 13:56:20 +0000",
  "in_reply_to_screen_name" : "miruka_bot",
  "in_reply_to_user_id_str" : "118009758",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82808147386966016",
  "text" : "\u660E\u65E5\u3082\u96E8\u306A\u306E\u304B\u306A\u2026",
  "id" : 82808147386966016,
  "created_at" : "2011-06-20 13:52:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "indices" : [ 3, 10 ],
      "id_str" : "89620915",
      "id" : 89620915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82806187355152384",
  "text" : "RT @qusumi: \u6765\u9031\u767A\u58F2\u306ESPA!\u306B\u300C\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u300D\u65B0\u4F5C\u8F09\u308A\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82806044732039168",
    "text" : "\u6765\u9031\u767A\u58F2\u306ESPA!\u306B\u300C\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u300D\u65B0\u4F5C\u8F09\u308A\u307E\u3059\u3002",
    "id" : 82806044732039168,
    "created_at" : "2011-06-20 13:44:34 +0000",
    "user" : {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "protected" : false,
      "id_str" : "89620915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1625008477\/Q_Wqusumi_____normal.jpg",
      "id" : 89620915,
      "verified" : false
    }
  },
  "id" : 82806187355152384,
  "created_at" : "2011-06-20 13:45:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82803512223858689",
  "text" : "\u732B\u3068\u622F\u308C\u305F\u3044\u885D\u52D5\u2026",
  "id" : 82803512223858689,
  "created_at" : "2011-06-20 13:34:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82776899234955264",
  "text" : "\u3057\u3083\u30FC\u3001\u3055\u308F\u30FC\u6D74\u3073\u3066\u304F\u308B\u304B\u306A\u30FC",
  "id" : 82776899234955264,
  "created_at" : "2011-06-20 11:48:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82776763909939201",
  "text" : "\u4F55\u306B\u3057\u3066\u3082\u8CC7\u6E90\u306E\u306A\u3044\u65E5\u672C\u306F\u4EBA\u6750\u3068\u6280\u8853\u3067\u6E21\u3063\u3066\u3044\u304F\u3057\u304B\u306A\u3044\u3060\u308D\u3046\u306A\u30FC\u3068\u3044\u3046\u306E\u306F\u7D4C\u6E08\u3084\u3089\u7523\u696D\u3084\u3089\u4E00\u5207\u308F\u304B\u3089\u306A\u3044\u81EA\u5206\u3067\u3082\u308F\u304B\u308B\u306E\u306B\u2026",
  "id" : 82776763909939201,
  "created_at" : "2011-06-20 11:48:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82776529620307968",
  "text" : "\u304A\u30FC\u30B9\u30D1\u30B3\u30F3\u4E00\u4F4D\u3060\u3063\u305F\u306E\u304B\uFF01\u304A\u3081\u3067\u3068\u3046\u65E5\u672C\u3002\u84EE\u822B\u7206\u767A\u3057\u3066\u304A\uFF4B",
  "id" : 82776529620307968,
  "created_at" : "2011-06-20 11:47:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82757866930454528",
  "text" : "\uFF2D\uFF28\u306E4\u30B3\u30DE\u3068\u30CF\u30D0\u30C3\u30CA\u30BF\u30EB\u30B9\u30C4\u30AD\u306E\u5B9A\u7406\u3068\u5E7E\u4F55\u3078\u306E\u8A98\u3044\u3068\u91CE\u6B66\u58EB\u306E\u30B0\u30EB\u30E1\u306E\u7D44\u307F\u5408\u308F\u305B\u306F\u4ECA\u307E\u3067\u306A\u304B\u3063\u305F\u3060\u308D\u3046\u306A\u3001\u30A2\u30DE\u30BE\u30F3\u3002",
  "id" : 82757866930454528,
  "created_at" : "2011-06-20 10:33:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82757360694726656",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u30B9\u30D1\u30B3\u30F3\u306E\u683C\u4ED8\u3051\u3063\u3066\u3069\u3046\u306A\u3063\u305F\u3093\u3060\u308D\u3046\u30022\u9650\u306E\u30B3\u30F3\u30D7\u30ED\u306E\u6559\u6388\u304C\u30CF\u30A4\u30C6\u30F3\u30B7\u30E7\u30F3\u3060\u3063\u305F\u3051\u3069\u3002",
  "id" : 82757360694726656,
  "created_at" : "2011-06-20 10:31:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82685903209902081",
  "text" : "\u5727\u5012\u7684\u2026\u7720\u6C17\uFF6F\uFF01\uFF01\uFF01",
  "id" : 82685903209902081,
  "created_at" : "2011-06-20 05:47:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 0, 7 ],
      "id_str" : "129796835",
      "id" : 129796835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82553615805456384",
  "geo" : { },
  "id_str" : "82594682831515648",
  "in_reply_to_user_id" : 129796835,
  "text" : "@7M1IHN @mo5nya \u305D\u3093\u306A\u6DF1\u3044(\uFF1F)\u610F\u5473\u304C\u3042\u3063\u3066\u8A00\u3063\u305F\u8A33\u3058\u3083\u306A\u3044\u3093\u3067\u3059\u3051\u3069\u306D\u30FC\uFF57\u56F3\u3089\u305A\u3082\u30CD\u30BF\u306B\u89E6\u308C\u3066\u3044\u305F\u3088\u3046\u3067\u3059\u3002",
  "id" : 82594682831515648,
  "in_reply_to_status_id" : 82553615805456384,
  "created_at" : "2011-06-19 23:44:41 +0000",
  "in_reply_to_screen_name" : "7M1IHN",
  "in_reply_to_user_id_str" : "129796835",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82585470604816384",
  "text" : "\u4F55\u304B\u5207\u306A\u3044\u5922\u3092\u898B\u305F\u6C17\u304C\u3059\u308B\u3002",
  "id" : 82585470604816384,
  "created_at" : "2011-06-19 23:08:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82585335606947840",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 82585335606947840,
  "created_at" : "2011-06-19 23:07:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82585249376239616",
  "text" : "\u3042\u3001\u9045\u3044\u2026\u3002",
  "id" : 82585249376239616,
  "created_at" : "2011-06-19 23:07:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82585164064100353",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 82585164064100353,
  "created_at" : "2011-06-19 23:06:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 8, 15 ],
      "id_str" : "129796835",
      "id" : 129796835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82453206189346816",
  "text" : "@mo5nya @7M1IHN \u3093\u30FC\u53B3\u5BC6\u306B\u30D5\u30E9\u30AF\u30BF\u30EB\u3067\u306F\u306A\u3044\u3051\u308C\u3069\u5145\u586B\u56F3\u5F62\u3063\u307D\u3044\u3068\u3044\u3046\u304B\u76F8\u4F3C\u56F3\u5F62\u306E\u96C6\u307E\u308A\u3063\u307D\u3044\u3063\u3066\u5370\u8C61\u3067\u8A00\u3044\u307E\u3057\u305F\u3002",
  "id" : 82453206189346816,
  "created_at" : "2011-06-19 14:22:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82439056646090752",
  "text" : "\u30D5\u30E9\u30AF\u30BF\u30EB\u3063\u307D\u3044\u306E\u3082\u3042\u3063\u3066\u7DBA\u9E97 RT @mo5nya: \u7F8E\u3057\u3055\u306B\u3046\u3063\u3068\u308A\u3057\u3066\u3057\u307E\u3063\u305F\u79C1\u3063\u3066\u5909\u614B\uFF65\uFF65\uFF65\uFF1Fhttp:\/\/dailynewsagency.com\/2011\/06\/17\/glass-microbiology-deadly-virus-art\/",
  "id" : 82439056646090752,
  "created_at" : "2011-06-19 13:26:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82417440516087808",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 82417440516087808,
  "created_at" : "2011-06-19 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82078129992118272",
  "text" : "@nico_reflexio \u304A\u304B\u3048\u308A\u3002\u660E\u77F3\u713C\u7F8E\u5473\u3057\u304B\u3063\u305F\u3001\u3054\u3061\u305D\u3046\u3055\u307E\u3002",
  "id" : 82078129992118272,
  "created_at" : "2011-06-18 13:32:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 0, 7 ],
      "id_str" : "129796835",
      "id" : 129796835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "82069618449072128",
  "geo" : { },
  "id_str" : "82070064697847808",
  "in_reply_to_user_id" : 129796835,
  "text" : "@7M1IHN \u50D5\u3082\u8FD1\u304F\u306E\u66F8\u5E97\u306B\uFF12\u5DFB\u3057\u304B\u7121\u304F\u3066\u3001\u9060\u51FA\u3057\u305F\u3068\u304D\u306B\u5927\u304D\u3044\u672C\u5C4B\u3055\u3093\u3067\u8CB7\u3063\u3061\u3083\u3044\u307E\u3057\u305F\u3002",
  "id" : 82070064697847808,
  "in_reply_to_status_id" : 82069618449072128,
  "created_at" : "2011-06-18 13:00:02 +0000",
  "in_reply_to_screen_name" : "7M1IHN",
  "in_reply_to_user_id_str" : "129796835",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82069174830120960",
  "text" : "\u30A6\u30A3\u30EB\u30AD\u30F3\u30BD\u30F3\u306E\u30B8\u30F3\u30B8\u30E3\u30FC\u30A8\u30FC\u30EB\u7F8E\u5473\u3057\u3044\u3002",
  "id" : 82069174830120960,
  "created_at" : "2011-06-18 12:56:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82068070201442304",
  "text" : "\u6570\u5B66\u5973\u5B502\u56DE\u307B\u3069\u8AAD\u307F\u307E\u3057\u305F\u3002\u307E\u3063\u305F\u308A\u3002\u3068\u3082\u3068\u4ECA\u7530\u541B\u304C\u304A\u6C17\u306B\u5165\u308A\u3002",
  "id" : 82068070201442304,
  "created_at" : "2011-06-18 12:52:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82056621995474944",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 82056621995474944,
  "created_at" : "2011-06-18 12:06:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82029986525093888",
  "text" : "@koketomi \u30CF\u30CA\u30ADbot\u3092\u2026\u3044\u3084\u3001\u306A\u3093\u3067\u3082\u306A\u3044\u3002",
  "id" : 82029986525093888,
  "created_at" : "2011-06-18 10:20:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81990560369491968",
  "text" : "\u3042\u306E\u82B1\u307F\u305F\u3051\u3069\u3082\u3046\u6CE3\u304D\u305D\u3046\u3002\u30C0\u30E1\u3060\u3002",
  "id" : 81990560369491968,
  "created_at" : "2011-06-18 07:44:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u732A\u702C\u76F4\u6A39\/inosenaoki",
      "screen_name" : "inosenaoki",
      "indices" : [ 3, 14 ],
      "id_str" : "125546634",
      "id" : 125546634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81574213021995009",
  "text" : "RT @inosenaoki: \u300C\u4FFA\u306F\u6614\u3001\u611F\u52D5\u3057\u305F\u3001\u3063\u3066\u8A00\u3063\u305F\u3088\u306A\u3001\u305D\u308C\u3067\u3044\u307E\u3001\u83C5\u3069\u3046\u3057\u305F\u3001\u3060\u3088\u300D\uFF08\u6700\u8FD1\u306E\u5C0F\u6CC9\u6DF3\u4E00\u90CE\u767A\u8A00\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81558603026276352",
    "text" : "\u300C\u4FFA\u306F\u6614\u3001\u611F\u52D5\u3057\u305F\u3001\u3063\u3066\u8A00\u3063\u305F\u3088\u306A\u3001\u305D\u308C\u3067\u3044\u307E\u3001\u83C5\u3069\u3046\u3057\u305F\u3001\u3060\u3088\u300D\uFF08\u6700\u8FD1\u306E\u5C0F\u6CC9\u6DF3\u4E00\u90CE\u767A\u8A00\uFF09",
    "id" : 81558603026276352,
    "created_at" : "2011-06-17 03:07:40 +0000",
    "user" : {
      "name" : "\u732A\u702C\u76F4\u6A39\/inosenaoki",
      "screen_name" : "inosenaoki",
      "protected" : false,
      "id_str" : "125546634",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769550769\/______________normal.jpg",
      "id" : 125546634,
      "verified" : true
    }
  },
  "id" : 81574213021995009,
  "created_at" : "2011-06-17 04:09:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81330983894401024",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 81330983894401024,
  "created_at" : "2011-06-16 12:03:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81223218999996416",
  "text" : "\u3084\u308A\u305F\u3044\u3053\u3068\u305F\u304F\u3055\u3093\u3042\u308B\u3051\u3069\u3001\u3068\u308A\u3042\u3048\u305A\u5FAE\u7A4D\u3068\u7DDA\u5F62\u3060\u3088\u306A\u30FB\u30FB\u30FB\u3002",
  "id" : 81223218999996416,
  "created_at" : "2011-06-16 04:54:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81221162553720833",
  "text" : "\u4E88\u5099\u77E5\u8B58\u5C11\u306A\u3081\u3067\u3059\u3080\u3001\u6574\u6570\u8AD6\u306E\u6559\u79D1\u66F8\u77E5\u3063\u3066\u308B\u4EBA\u3044\u305F\u3089\u6559\u3048\u3066\u304F\u3060\u3055\u3044\u306A\u3002#math",
  "id" : 81221162553720833,
  "created_at" : "2011-06-16 04:46:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81163539561193474",
  "geo" : { },
  "id_str" : "81164994548469760",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \uFF2F\uFF2B \u305F\u3060\u3057\u4E94\u9650\u306F\u4EFB\u305B\u305F",
  "id" : 81164994548469760,
  "in_reply_to_status_id" : 81163539561193474,
  "created_at" : "2011-06-16 01:03:37 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81163163990626304",
  "text" : "\u4E16\u754C\u907A\u7523\u3092\u6B69\u3044\u3066\u901A\u5B66\u2026\u8D05\u6CA2\uFF1F",
  "id" : 81163163990626304,
  "created_at" : "2011-06-16 00:56:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81132576064028672",
  "text" : "\u6700\u8FD1\u76EE\u899A\u307E\u3057\u524D\u306B\u76EE\u899A\u3081\u308B\u3002\u771F\u306B\u6050\u308D\u3057\u3044\u306E\u306F\u4E8C\u5EA6\u5BDD\u3001\u4E09\u5EA6\u5BDD\u3002",
  "id" : 81132576064028672,
  "created_at" : "2011-06-15 22:54:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81132359365300224",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 81132359365300224,
  "created_at" : "2011-06-15 22:53:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81039348891525120",
  "geo" : { },
  "id_str" : "81039789469601792",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6587\u5B66\u90E8\u82F1\u8A9E\u30C9\u30B9\u30C8\u30E9\u30A4\u30AF\u3067\u3059\u3084\u3093",
  "id" : 81039789469601792,
  "in_reply_to_status_id" : 81039348891525120,
  "created_at" : "2011-06-15 16:46:06 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81037729558839296",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 81037729558839296,
  "created_at" : "2011-06-15 16:37:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81037686441385984",
  "text" : "\u5BDD\u3088\u3046\u304B\u306A\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002\u4ECA\u65E5\u306F\u4E8C\u9650\u304B\u3089\u3002\u8D77\u304D\u3089\u308C\u308B\u3068\u3044\u3044\u306A\u3002\u3067\u3082\u6B63\u76F43\u9650\u3060\u3051\u51FA\u308C\u3070\u3044\u3044\u30EC\u30D9\u30EB\u3002",
  "id" : 81037686441385984,
  "created_at" : "2011-06-15 16:37:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81025557516656640",
  "text" : "\u306A\u3067\u3053\u30E1\u30C7\u30E5\u30FC\u30B5\u3002\u51FA\u756A\u5C11\u306A\u3044\u5343\u77F3\u3055\u3093\u3002",
  "id" : 81025557516656640,
  "created_at" : "2011-06-15 15:49:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81025405938700288",
  "text" : "\u9752\u6625\u306F \u3044 \u305F \u307F \u306A\u3057\u3067\u306F\u904E\u3054\u305B\u306A\u3044\u3002\u3068\u3044\u3048\u3070\u56EE\u7269\u8A9E\u3063\u3066\u3082\u3046\u3059\u3050\u306A\u306E\u304B\u306A\uFF1F",
  "id" : 81025405938700288,
  "created_at" : "2011-06-15 15:48:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81025146038652928",
  "text" : "\u6D17\u3044\u7269\u3057\u3066\u3066\u306A\u3093\u304B\u5C0F\u6307\u306B\u9055\u548C\u611F\u304C\u3042\u308B\u306A\u3068\u601D\u3063\u305F\u3089\u306A\u3093\u304B\u50B7\u304C\u2026\u3044\u3064\u7740\u3044\u305F\u306E\u304B\u898B\u5F53\u304C\u3064\u304B\u306A\u3044\u3002\u305D\u3057\u3066\u3053\u306E\u624B\u306E\u50B7\u306F\u304D\u305A\uFF08\u306A\u305C\u304B\u5909\u63DB\u3067\u304D\u306A\u3044\uFF09\u3044\u3066\u304B\u3089\u50B7\u307F\u306F\u3058\u3081\u308B\u3002",
  "id" : 81025146038652928,
  "created_at" : "2011-06-15 15:47:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81014558562598913",
  "text" : "@koketomi \u30EA\u30BA\u30E0\u5D29\u58CA\u3063\u3066\u30EC\u30D9\u30EB\u3058\u3083\u306D\u30FC\u305E\uFF57",
  "id" : 81014558562598913,
  "created_at" : "2011-06-15 15:05:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81008932616798209",
  "geo" : { },
  "id_str" : "81009375694688258",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u4E00\u6587\u76EE\u3001\u82F1\u8A33\u3057\u3066\u307F\u3066\u304F\u308C\u306A\u3044\u304B\u3002\u3061\u3087\u3063\u3068\u89E3\u308A\u96E3\u3044\u3093\u3060\u304C\u2026\u3002",
  "id" : 81009375694688258,
  "in_reply_to_status_id" : 81008932616798209,
  "created_at" : "2011-06-15 14:45:14 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u539F\u2252\u306B\u305B\u7269\u7406\u5B66\u5F92",
      "screen_name" : "hhara_iwate",
      "indices" : [ 30, 42 ],
      "id_str" : "276105342",
      "id" : 276105342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81008990728880129",
  "text" : "\u9762\u7A4D\u3068\u3044\u3046\u8868\u73FE\u306B\u7269\u7406\u5C4B\u306E\u5302\u3044\u304C\u3057\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002RT @hhara_iwate: \u304A\u3084\u3059\u307F\u301C\u3002\n\u7269\u7406\u5B66\u306B\u8208\u5473\u304C\u306A\u3044\u306E\u306BTL\u306E\u9762\u7A4D\u3092\u53D6\u3089\u308C\u3066\u3057\u307E\u3063\u305F\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u306B\u304A\u8A6B\u3073\u3057\u307E\u3059orz",
  "id" : 81008990728880129,
  "created_at" : "2011-06-15 14:43:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81006929836650496",
  "text" : "\u53CB\u4EBA\u304C\u6771\u5317\u5927\u306ET\u30B7\u30E3\u30C4\u3092\u9001\u3063\u3066\u304F\u308C\u305F\u304B\u3089NF\u306E\u6642\u306B\u3067\u3082\u7740\u3088\u3046\u304B\u306A\u300111\u6708\u306B\u534A\u305D\u3067\u3058\u3083\u5BD2\u3044\u304B\u3002",
  "id" : 81006929836650496,
  "created_at" : "2011-06-15 14:35:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81006449861459968",
  "geo" : { },
  "id_str" : "81006746017087488",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3042\u3063\u305F\u6C17\u304C\u3059\u308B\u304C\u8D64\u3063\u307D\u3044\u96F0\u56F2\u6C17\u304C\u3042\u308B\u304B\u3089\u3061\u3083\u3093\u3068\u898B\u305F\u3053\u3068\u306A\u3044\u3002",
  "id" : 81006746017087488,
  "in_reply_to_status_id" : 81006449861459968,
  "created_at" : "2011-06-15 14:34:47 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81004947407249409",
  "geo" : { },
  "id_str" : "81005195777163264",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u65B0\u805E\u304C\u9762\u767D\u3044\u3093\u3060\u304C\uFF57\uFF57\uFF57",
  "id" : 81005195777163264,
  "in_reply_to_status_id" : 81004947407249409,
  "created_at" : "2011-06-15 14:28:38 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80996444445749248",
  "text" : "\u3066\u304B\u76F8\u4F3C\u2026\u3058\u3083\u306A\u304F\u3066\u6383\u9664\u3057\u306A\u3044\u3068\uFF01",
  "id" : 80996444445749248,
  "created_at" : "2011-06-15 13:53:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80996349709004800",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u660E\u671D\u7686\u65E2\u6708\u98DF\u3060\u3063\u305F\u3088\u3046\u306A",
  "id" : 80996349709004800,
  "created_at" : "2011-06-15 13:53:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80995541512761345",
  "geo" : { },
  "id_str" : "80996011656482817",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u79CB\u306B\u306A\u308B\u307E\u3067\u5F85\u3063\u3066\u304B\u3089\uFF14\u8CB7\u3048\u3070\u51FA\u8CBB\u306F\u6291\u3048\u3089\u308C\u308B\u2026\u304B\u306A\uFF1Fiphone\u306B\u3057\u305F\u3044\u306E\u306F\u79C1\u3082\u3067\u3059\u304C\u30FC\u3002",
  "id" : 80996011656482817,
  "in_reply_to_status_id" : 80995541512761345,
  "created_at" : "2011-06-15 13:52:08 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80992642921537538",
  "geo" : { },
  "id_str" : "80993374550753281",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3042\u30FC\u3001\u300C\u30A1\u300D\u306B\u3064\u3044\u3066\u306F\u305D\u3046\u3044\u3046\u53E3\u7656\u306Ebot\u304C\u3042\u3063\u3066\u306D\u2026http:\/\/goo.gl\/AzSz3\u3000\u300C\u30A7\u2026\u300D\u3063\u3066\u306E\u306F\u30CD\u30C3\u30C8\u30B9\u30E9\u30F3\u30B0\u307F\u305F\u3044\u306A\u3082\u3093\u3060\u3051\u3069\u3002\u3055\u3057\u3066\u610F\u5473\u306F\u306A\u3044\u3067\u3059\u2190",
  "id" : 80993374550753281,
  "in_reply_to_status_id" : 80992642921537538,
  "created_at" : "2011-06-15 13:41:39 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80992246773719041",
  "text" : "\u3042\u3001\u5E30\u5B85\u30A1\uFF01",
  "id" : 80992246773719041,
  "created_at" : "2011-06-15 13:37:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 37, 48 ],
      "id_str" : "171457320",
      "id" : 171457320
    }, {
      "name" : "\u3057\u3089\u3059\u4E3C",
      "screen_name" : "hgnzm",
      "indices" : [ 73, 79 ],
      "id_str" : "114731417",
      "id" : 114731417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80992169799847936",
  "text" : "\u3061\u3087\u3063\u3068\u524D\u306B\u62B1\u304B\u308C\u6795\u306A\u308B\u3082\u306E\u3092\u30CD\u30C3\u30C8\u30CB\u30E5\u30FC\u30B9\u304B\u4F55\u304B\u3067\u898B\u305F\u3088\u3046\u306A\u2026\u3002 RT @akiyohmori: \u8AB0\u304B\u3092\u304E\u3085\u3063\u3066\u3057\u305F\u3044\u304B\u3089\u305D\u306E\u5546\u54C1\u306B\u306A\u308A\u305F\u3044\u3002\u201C@hgnzm: \u304E\u3085\u3063\u3066\u3057\u3066\u304F\u308C\u308B\u62B1\u304D\u307E\u304F\u3089\u3063\u3066\u306A\u3044\u306E\u304B\u306A\u201D",
  "id" : 80992169799847936,
  "created_at" : "2011-06-15 13:36:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80987663087321088",
  "geo" : { },
  "id_str" : "80988934737367041",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u4F55\u304C\u3042\u3063\u305F\uFF1F\u2026\u3044\u3084\u3001\u4F55\u304C\u7121\u304B\u3063\u305F\uFF1F",
  "id" : 80988934737367041,
  "in_reply_to_status_id" : 80987663087321088,
  "created_at" : "2011-06-15 13:24:01 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80977596485091328",
  "text" : "\uFF11\u3088\u308A\u5927\u304D\u304F\uFF12\u3088\u308A\u5C0F\u3055\u3044\u6B21\u5143\u2026",
  "id" : 80977596485091328,
  "created_at" : "2011-06-15 12:38:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80811833912602625",
  "text" : "to go or not to go",
  "id" : 80811833912602625,
  "created_at" : "2011-06-15 01:40:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80707978256330754",
  "geo" : { },
  "id_str" : "80710216190132224",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u304A\u75B2\u308C\u69D8\u3067\u3057\u305F\u30FC\u3002\u305D\u3057\u3066\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 80710216190132224,
  "in_reply_to_status_id" : 80707978256330754,
  "created_at" : "2011-06-14 18:56:29 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80706617284362241",
  "text" : "\u304D\u2026\u5E30\u5B85\uFF67\u2026\uFF01",
  "id" : 80706617284362241,
  "created_at" : "2011-06-14 18:42:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80606190626803712",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 80606190626803712,
  "created_at" : "2011-06-14 12:03:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80563810796183552",
  "text" : "\u30B5\u30FC\u30AF\u30EB\u3067\u3054\u98EF\u884C\u304F\u3060\u308D\u3046\u3057\u8EFD\u3081\u306B\u3002\u3068\u3044\u3046\u308F\u3051\u3067\u3044\u3063\u305F\u3093\u96E2\u8131\u3045",
  "id" : 80563810796183552,
  "created_at" : "2011-06-14 09:14:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80563721029689344",
  "text" : "\u304A\u306A\u304B\u6E1B\u3063\u305F\u306A\u3041\u3002\u3088\u3057\u3001\u30B3\u30FC\u30EB\u306E\u524D\u306B\u4F55\u304B\u8179\u306B\u5165\u308C\u3066\u3044\u304F\u304B\u3002",
  "id" : 80563721029689344,
  "created_at" : "2011-06-14 09:14:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u306A\u304B\u3093",
      "screen_name" : "sanakan",
      "indices" : [ 0, 8 ],
      "id_str" : "5452512",
      "id" : 5452512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80464279987421184",
  "geo" : { },
  "id_str" : "80465204361703424",
  "in_reply_to_user_id" : 5452512,
  "text" : "@sanakan \u597D\u304D\u306A\u3093\u3067\u5B09\u3057\u3044\u3067\u3059\u306D\u3002\u3061\u306A\u307F\u306B\u3069\u306E\u30B3\u30F3\u30D3\u30CB\u3067\u8CB7\u3044\u307E\u3057\u305F\uFF1F",
  "id" : 80465204361703424,
  "in_reply_to_status_id" : 80464279987421184,
  "created_at" : "2011-06-14 02:42:54 +0000",
  "in_reply_to_screen_name" : "sanakan",
  "in_reply_to_user_id_str" : "5452512",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u306A\u304B\u3093",
      "screen_name" : "sanakan",
      "indices" : [ 0, 8 ],
      "id_str" : "5452512",
      "id" : 5452512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "80461711714422785",
  "geo" : { },
  "id_str" : "80463973492862976",
  "in_reply_to_user_id" : 5452512,
  "text" : "@sanakan \u30A6\u30A3\u30EB\u30AD\u30F3\u30BD\u30F3\u306B\u30DA\u30C3\u30C8\u30DC\u30C8\u30EB\u3042\u308B\u3093\u3067\u3059\u304B\uFF1F\uFF01",
  "id" : 80463973492862976,
  "in_reply_to_status_id" : 80461711714422785,
  "created_at" : "2011-06-14 02:38:00 +0000",
  "in_reply_to_screen_name" : "sanakan",
  "in_reply_to_user_id_str" : "5452512",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80287546759847936",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 80287546759847936,
  "created_at" : "2011-06-13 14:56:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80279877965709313",
  "text" : "\uFF08\u306A\u3093\u304B\u6700\u8FD1\u81EA\u8EE2\u8ECA\u64CD\u696D\u306A\u306E\u304C\u6C17\u306B\u306A\u308B\u306A\u3041\u2026\u3002\uFF09",
  "id" : 80279877965709313,
  "created_at" : "2011-06-13 14:26:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80279772596404225",
  "text" : "\u305D\u3057\u3066\u3082\u3046\u7720\u3044\u2026\u660E\u65E54\u9650\u306E\u8AB2\u984C\u306F2\uFF0C3\u9650\u3067\u51E6\u7406\u3057\u3088\u3046\u3002",
  "id" : 80279772596404225,
  "created_at" : "2011-06-13 14:26:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80279575946461186",
  "text" : "\u306A\u3093\u3067\u6700\u8FD1Twitter\u96E2\u308C\u3066\u308B\u3063\u3066\u306A\u305C\u304BSAEZURI\u3092\u8D77\u52D5\u3057\u3066\u3044\u306A\u304B\u3063\u305F\u3002",
  "id" : 80279575946461186,
  "created_at" : "2011-06-13 14:25:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80279411970162689",
  "text" : "\u3051\u3044\u304A\u3093!! \u3048\u3044\u3067\u3093 \u53E1\u5C71\u96FB\u9244 \u697D\u5668\u578B\u7279\u5225\u4E57\u8ECA\u5238\u3000\u3082\u3057\u4EEE\u306B\u6B32\u3057\u3044\u4EBA\u3044\u305F\u3089DM\u304B\u30EA\u30D7\u30E9\u30A4\u304F\u308C\u308C\u3070\u5BFE\u5FDC\u3057\u307E\u3059\u30FC\u3002",
  "id" : 80279411970162689,
  "created_at" : "2011-06-13 14:24:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30E4\u30B7",
      "screen_name" : "884x",
      "indices" : [ 3, 8 ],
      "id_str" : "29029783",
      "id" : 29029783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80136083337248768",
  "text" : "RT @884x: \u5B50\u4F9B\u306E\u9803\u300C\u304A\u574A\u3055\u3093\uFF1D\u50E7\u4FB6\u300D\u3060\u3068\u77E5\u308A\u3001\u6CD5\u4E8B\u3067\u304A\u5BFA\u306B\u884C\u3063\u305F\u3068\u304D\u306B\u82E5\u3044\u304A\u574A\u3055\u3093\u306B\u300C\u30D9\u30DB\u30DE\u4F7F\u3048\u307E\u3059\u304B\uFF1F\u300D\u3063\u3066\u805E\u3044\u305F\u3089\u300C\u4F7F\u3048\u308B\u3088\u300D\u3068\u8A00\u308F\u308C\u3001\u300C\u3059\u3063\u3052\u30FC\uFF01\u30D0\u30AE\u30AF\u30ED\u30B9\u306F\uFF01\uFF1F\u300D\u3063\u3066\u805E\u3044\u305F\u3089\u300C\u4F7F\u3048\u308B\u3088\u300D\u3068\u8A00\u308F\u308C\u3001\u300C\u3053\u3048\u30FC\u3063\uFF01\u30E1\u30E9\u30DF\u306F\u30E1\u30E9\u30DF\uFF01\uFF1F\u300D\u3063\u3066\u805E\u3044\u305F\u3089\u300C\u30E1\u30E9\u30DF\u306F\u7121\u7406 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78480762109820928",
    "text" : "\u5B50\u4F9B\u306E\u9803\u300C\u304A\u574A\u3055\u3093\uFF1D\u50E7\u4FB6\u300D\u3060\u3068\u77E5\u308A\u3001\u6CD5\u4E8B\u3067\u304A\u5BFA\u306B\u884C\u3063\u305F\u3068\u304D\u306B\u82E5\u3044\u304A\u574A\u3055\u3093\u306B\u300C\u30D9\u30DB\u30DE\u4F7F\u3048\u307E\u3059\u304B\uFF1F\u300D\u3063\u3066\u805E\u3044\u305F\u3089\u300C\u4F7F\u3048\u308B\u3088\u300D\u3068\u8A00\u308F\u308C\u3001\u300C\u3059\u3063\u3052\u30FC\uFF01\u30D0\u30AE\u30AF\u30ED\u30B9\u306F\uFF01\uFF1F\u300D\u3063\u3066\u805E\u3044\u305F\u3089\u300C\u4F7F\u3048\u308B\u3088\u300D\u3068\u8A00\u308F\u308C\u3001\u300C\u3053\u3048\u30FC\u3063\uFF01\u30E1\u30E9\u30DF\u306F\u30E1\u30E9\u30DF\uFF01\uFF1F\u300D\u3063\u3066\u805E\u3044\u305F\u3089\u300C\u30E1\u30E9\u30DF\u306F\u7121\u7406\u300D\u3068\u8A00\u308F\u308C\u305F\u3053\u3068\u3042\u308A\u307E\u3059\u3002",
    "id" : 78480762109820928,
    "created_at" : "2011-06-08 15:17:26 +0000",
    "user" : {
      "name" : "\u30CF\u30E4\u30B7",
      "screen_name" : "884x",
      "protected" : false,
      "id_str" : "29029783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1576537414\/kuromadoushi_normal.gif",
      "id" : 29029783,
      "verified" : false
    }
  },
  "id" : 80136083337248768,
  "created_at" : "2011-06-13 04:55:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80126872641486848",
  "text" : "\u98DF\u5F8C\u306E\u7720\u6C17\u7206\u767A\u3057\u3066\u304F\u3060\u3055\u3044",
  "id" : 80126872641486848,
  "created_at" : "2011-06-13 04:18:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 9, 19 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 20, 30 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80067209174581248",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 @nisehorrn @kazma0318 \u304A\u3084\u3059\u307F\u3042\u308A\u304C\u3068\u3046\u3067\u3001\u3057\u305F\u3002",
  "id" : 80067209174581248,
  "created_at" : "2011-06-13 00:21:24 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80067034850922496",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 80067034850922496,
  "created_at" : "2011-06-13 00:20:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80066941108228096",
  "text" : "23\u6642\u524D\u306B\u5BDD\u3066\u3082\u306A\u304A\uFF11\u9650\u5BDD\u574A\u3059\u308B\u30EC\u30D9\u30EB",
  "id" : 80066941108228096,
  "created_at" : "2011-06-13 00:20:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79893222444380160",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 79893222444380160,
  "created_at" : "2011-06-12 12:50:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79893104873848832",
  "text" : "\u3057\u3070\u3089\u304F\u30C4\u30A4\u30C3\u30BF\u30FC\u898B\u308C\u3066\u307E\u305B\u3093\u2026\u3002\u65E9\u3044\u3067\u3059\u304C\u305D\u308D\u305D\u308D\u5BDD\u307E\u3059\u2190",
  "id" : 79893104873848832,
  "created_at" : "2011-06-12 12:49:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79884207446437888",
  "geo" : { },
  "id_str" : "79892923591831552",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF67\uFF01",
  "id" : 79892923591831552,
  "in_reply_to_status_id" : 79884207446437888,
  "created_at" : "2011-06-12 12:48:51 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "79850192383393792",
  "geo" : { },
  "id_str" : "79892390307037184",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u8CB7\u3048\u307E\u3057\u305F\u3088\u30FC\u3002\u7C9B\u3005\u3068\u58F2\u308B\u6E96\u5099\u3067\u3059\u3002",
  "id" : 79892390307037184,
  "in_reply_to_status_id" : 79850192383393792,
  "created_at" : "2011-06-12 12:46:44 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79882586599600128",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 79882586599600128,
  "created_at" : "2011-06-12 12:07:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "error403",
      "screen_name" : "error403",
      "indices" : [ 3, 12 ],
      "id_str" : "14258215",
      "id" : 14258215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79730225398808577",
  "text" : "RT @error403: \u5973\u5B50\u3001\u6B7B\u3093\u3060\u7537\u5B50\u6240\u6301\u3002\uFF08\u56DE\u6587\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73052184740241408",
    "text" : "\u5973\u5B50\u3001\u6B7B\u3093\u3060\u7537\u5B50\u6240\u6301\u3002\uFF08\u56DE\u6587\uFF09",
    "id" : 73052184740241408,
    "created_at" : "2011-05-24 15:46:12 +0000",
    "user" : {
      "name" : "error403",
      "screen_name" : "error403",
      "protected" : false,
      "id_str" : "14258215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200815899\/test10_normal.jpg",
      "id" : 14258215,
      "verified" : false
    }
  },
  "id" : 79730225398808577,
  "created_at" : "2011-06-12 02:02:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7AE5\u8C9E\u58EB\u5B98\u5019\u88DC\u751F",
      "screen_name" : "virgincadet",
      "indices" : [ 3, 15 ],
      "id_str" : "140273398",
      "id" : 140273398
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kon_eiden",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79653324462374912",
  "text" : "RT @virgincadet: \u53E1\u5C71\u9244\u9053\u306B\u3042\u308A\u304C\u3068\u3046\n\u4EAC\u90FD\u5E9C\u8B66\u306B\u3054\u3081\u3093\u306A\u3055\u3044\n#kon_eiden",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\" rel=\"nofollow\"\u003ETwitBird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kon_eiden",
        "indices" : [ 23, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79653054063976448",
    "text" : "\u53E1\u5C71\u9244\u9053\u306B\u3042\u308A\u304C\u3068\u3046\n\u4EAC\u90FD\u5E9C\u8B66\u306B\u3054\u3081\u3093\u306A\u3055\u3044\n#kon_eiden",
    "id" : 79653054063976448,
    "created_at" : "2011-06-11 20:55:42 +0000",
    "user" : {
      "name" : "\u7AE5\u8C9E\u58EB\u5B98\u5019\u88DC\u751F",
      "screen_name" : "virgincadet",
      "protected" : false,
      "id_str" : "140273398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874507407\/__1_normal.jpg",
      "id" : 140273398,
      "verified" : false
    }
  },
  "id" : 79653324462374912,
  "created_at" : "2011-06-11 20:56:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u3088\u305F\u304B",
      "screen_name" : "Kiyotaka_neko",
      "indices" : [ 3, 17 ],
      "id_str" : "147917567",
      "id" : 147917567
    }, {
      "name" : "\u53E1\u5C71\u96FB\u9244\u682A\u5F0F\u4F1A\u793E",
      "screen_name" : "eizandensha",
      "indices" : [ 37, 49 ],
      "id_str" : "193181018",
      "id" : 193181018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kon_eiden",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79653061349486592",
  "text" : "RT @Kiyotaka_neko: \u96FB\u8ECA\u4E57\u308B\u3063\u3066\u30EC\u30D9\u30EB\u3058\u3083\u306D\u30FC\u305E\u3000RT @eizandensha: \u884C\u5217\u306F1500\u4EBA\u3092\u3053\u3048\u307E\u3057\u305F\u3002\u6700\u5F8C\u5C3E\u306F\u51FA\u753A\u67F3\u99C5\u3092\u51FA\u3066\u3059\u3050\u306E\u6CB3\u5408\u6A4B\u4E0A\u3067\u3059 #kon_eiden http:\/\/maps.google.com\/maps?q=35.03043 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u53E1\u5C71\u96FB\u9244\u682A\u5F0F\u4F1A\u793E",
        "screen_name" : "eizandensha",
        "indices" : [ 18, 30 ],
        "id_str" : "193181018",
        "id" : 193181018
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kon_eiden",
        "indices" : [ 68, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79652832747335680",
    "text" : "\u96FB\u8ECA\u4E57\u308B\u3063\u3066\u30EC\u30D9\u30EB\u3058\u3083\u306D\u30FC\u305E\u3000RT @eizandensha: \u884C\u5217\u306F1500\u4EBA\u3092\u3053\u3048\u307E\u3057\u305F\u3002\u6700\u5F8C\u5C3E\u306F\u51FA\u753A\u67F3\u99C5\u3092\u51FA\u3066\u3059\u3050\u306E\u6CB3\u5408\u6A4B\u4E0A\u3067\u3059 #kon_eiden http:\/\/maps.google.com\/maps?q=35.030434,135.772233",
    "id" : 79652832747335680,
    "created_at" : "2011-06-11 20:54:49 +0000",
    "user" : {
      "name" : "\u304D\u3088\u305F\u304B",
      "screen_name" : "Kiyotaka_neko",
      "protected" : false,
      "id_str" : "147917567",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_0_normal.png",
      "id" : 147917567,
      "verified" : false
    }
  },
  "id" : 79653061349486592,
  "created_at" : "2011-06-11 20:55:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "No\u00EBl_MIW",
      "screen_name" : "Noel_MIW",
      "indices" : [ 3, 12 ],
      "id_str" : "141560860",
      "id" : 141560860
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kon_eiden",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79647101851676672",
  "text" : "RT @Noel_MIW: \u3068\u601D\u3063\u305F\u3089TL\u898B\u308B\u3068\u65E2\u306B\u5730\u4E0A\u306B\u5EF6\u3073\u3066\u305F\u306E\u304B\u3002\u4ECA\u304B\u3089\u306A\u3089\u4E38\u592A\u753A\u3067\u964D\u308A\u3066\u5317\u4E0A\u3057\u305F\u65B9\u304C\u65E9\u3044\u304B\u3082 #kon_eiden",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitbeam.jp\/\" rel=\"nofollow\"\u003Etwitbeam[\uFF82\uFF72\uFF6F\uFF84\uFF8B\uFF9E\uFF70\uFF91]\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kon_eiden",
        "indices" : [ 45, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79646561574981633",
    "text" : "\u3068\u601D\u3063\u305F\u3089TL\u898B\u308B\u3068\u65E2\u306B\u5730\u4E0A\u306B\u5EF6\u3073\u3066\u305F\u306E\u304B\u3002\u4ECA\u304B\u3089\u306A\u3089\u4E38\u592A\u753A\u3067\u964D\u308A\u3066\u5317\u4E0A\u3057\u305F\u65B9\u304C\u65E9\u3044\u304B\u3082 #kon_eiden",
    "id" : 79646561574981633,
    "created_at" : "2011-06-11 20:29:54 +0000",
    "user" : {
      "name" : "No\u00EBl_MIW",
      "screen_name" : "Noel_MIW",
      "protected" : false,
      "id_str" : "141560860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2893695765\/566fdeeda25e79af77c5f87c09b241f4_normal.jpeg",
      "id" : 141560860,
      "verified" : false
    }
  },
  "id" : 79647101851676672,
  "created_at" : "2011-06-11 20:32:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79634919608958978",
  "text" : "\u51C4\u3044\u4EBA\u2026",
  "id" : 79634919608958978,
  "created_at" : "2011-06-11 19:43:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79618018489012224",
  "text" : "\u51FA\u753A\u67F3 \u75DB\u8ECA\u2026",
  "id" : 79618018489012224,
  "created_at" : "2011-06-11 18:36:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79519945389645824",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 79519945389645824,
  "created_at" : "2011-06-11 12:06:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78845106630836225",
  "geo" : { },
  "id_str" : "78845748493561857",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4ECA\u65E5\u3058\u3083\u306A\u3044\u306E\u304B\uFF1F\uFF57",
  "id" : 78845748493561857,
  "in_reply_to_status_id" : 78845106630836225,
  "created_at" : "2011-06-09 15:27:45 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78828627143307265",
  "text" : "\u5E7E\u4F55\u5B66\u306E\u89E3\u308A\u3084\u3059\u3044\u53C2\u8003\u66F8\u6559\u3048\u3066\u304F\u3060\u3055\u3044\u30FC\u3002\u3067\u304D\u308C\u3070\u666E\u901A\u306E\u5FAE\u5206\u5E7E\u4F55\u306E\u7BC4\u56F2\u3067\u3002\u3000\u66F2\u7DDA\u3068\u66F2\u9762\u306E\u5FAE\u5206\u5E7E\u4F55 [\u5C0F\u6797 \u662D\u4E03] \u3063\u3066\u306E\u304C\u9762\u767D\u305D\u3046\u3063\u3066\u805E\u304D\u307E\u3057\u305F\u304C\u30FC\u3002",
  "id" : 78828627143307265,
  "created_at" : "2011-06-09 14:19:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u307E\u3044\u3061\u840C\u3048\u306A\u3044\u5730\u65B9\u306E\u4F1A\u8A08\u5C4B",
      "screen_name" : "Meisou_AK",
      "indices" : [ 3, 13 ],
      "id_str" : "72700161",
      "id" : 72700161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78815236689371136",
  "text" : "RT @Meisou_AK: \u6B8B\u308A\u306E45\u4EBA\u304C\u6C17\u306B\u306A\u308B\u2026RT @Akinori153: \u3010KGB48\u7DCF\u9078\u6319\u958B\u7968\u901F\u5831\u3011\u3000\n1\u4F4D\u3000V\u30FB\u30D7\u30FC\u30C1\u30F3\uFF08KGB\u7B2C\uFF11\u7DCF\u5C40\u6240\u5C5E\uFF09\u30001208749\u7968\u3000\n2\u4F4D\u3000A\u30FB\u30B3\u30EB\u30B8\u30E3\u30B3\u30D5\uFF08KGB\u7B2C\uFF19\u5C40\u6240\u5C5E\uFF09\u300016532\u7968\u3000\n3\u4F4D\u3000N\u30FB\u30D1\u30C8\u30EB\u30B7\u30A7\u30D5\uFF08KGB\u30EC ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78782268348436480",
    "text" : "\u6B8B\u308A\u306E45\u4EBA\u304C\u6C17\u306B\u306A\u308B\u2026RT @Akinori153: \u3010KGB48\u7DCF\u9078\u6319\u958B\u7968\u901F\u5831\u3011\u3000\n1\u4F4D\u3000V\u30FB\u30D7\u30FC\u30C1\u30F3\uFF08KGB\u7B2C\uFF11\u7DCF\u5C40\u6240\u5C5E\uFF09\u30001208749\u7968\u3000\n2\u4F4D\u3000A\u30FB\u30B3\u30EB\u30B8\u30E3\u30B3\u30D5\uFF08KGB\u7B2C\uFF19\u5C40\u6240\u5C5E\uFF09\u300016532\u7968\u3000\n3\u4F4D\u3000N\u30FB\u30D1\u30C8\u30EB\u30B7\u30A7\u30D5\uFF08KGB\u30EC\u30CB\u30F3\u30B0\u30E9\u30FC\u30C9\u652F\u5C40\u6240\u5C5E\uFF09\u3000",
    "id" : 78782268348436480,
    "created_at" : "2011-06-09 11:15:31 +0000",
    "user" : {
      "name" : "\u3044\u307E\u3044\u3061\u840C\u3048\u306A\u3044\u5730\u65B9\u306E\u4F1A\u8A08\u5C4B",
      "screen_name" : "Meisou_AK",
      "protected" : false,
      "id_str" : "72700161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1155157591\/key_normal.jpg",
      "id" : 72700161,
      "verified" : false
    }
  },
  "id" : 78815236689371136,
  "created_at" : "2011-06-09 13:26:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78796137783508992",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 78796137783508992,
  "created_at" : "2011-06-09 12:10:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 3, 16 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78671802515193857",
  "text" : "RT @galletti_bot: \u30DB\u30E1\u30ED\u30B9\u304C\u5B9F\u5728\u306E\u4EBA\u7269\u3067\u3042\u308B\u306E\u304B\u3069\u3046\u304B\u306F\u4E0D\u660E\u3067\u3042\u308B\u3002\u3060\u304C\u3001\u5F7C\u304C\u76F2\u76EE\u3067\u3042\u3063\u305F\u3068\u3044\u3046\u3053\u3068\u306B\u7591\u554F\u306E\u4F59\u5730\u306F\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78631970803941377",
    "text" : "\u30DB\u30E1\u30ED\u30B9\u304C\u5B9F\u5728\u306E\u4EBA\u7269\u3067\u3042\u308B\u306E\u304B\u3069\u3046\u304B\u306F\u4E0D\u660E\u3067\u3042\u308B\u3002\u3060\u304C\u3001\u5F7C\u304C\u76F2\u76EE\u3067\u3042\u3063\u305F\u3068\u3044\u3046\u3053\u3068\u306B\u7591\u554F\u306E\u4F59\u5730\u306F\u306A\u3044\u3002",
    "id" : 78631970803941377,
    "created_at" : "2011-06-09 01:18:17 +0000",
    "user" : {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "protected" : false,
      "id_str" : "99320050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1835516629\/galletti_128_normal.png",
      "id" : 99320050,
      "verified" : false
    }
  },
  "id" : 78671802515193857,
  "created_at" : "2011-06-09 03:56:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78668717961125888",
  "text" : "RT @JOJO_math: \u3060 \u304B \u3089 \u3053 \u306E \u30C6 \u30B9 \u30C8 \u3067 \u3053 \u306E \u82B1 \u4EAC \u9662 \u5178 \u660E \u306B \u7CBE \u795E \u7684 \u52D5 \u63FA \u306B \u3088 \u308B \u8A08 \u7B97 \u30DF \u30B9 \u306F \u6C7A \u3057 \u3066 \u306A \u3044 \uFF01 \u3068\u601D\u3063\u3066\u3044\u305F\u3060\u3053\u3046\u30C3\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78664630075006976",
    "text" : "\u3060 \u304B \u3089 \u3053 \u306E \u30C6 \u30B9 \u30C8 \u3067 \u3053 \u306E \u82B1 \u4EAC \u9662 \u5178 \u660E \u306B \u7CBE \u795E \u7684 \u52D5 \u63FA \u306B \u3088 \u308B \u8A08 \u7B97 \u30DF \u30B9 \u306F \u6C7A \u3057 \u3066 \u306A \u3044 \uFF01 \u3068\u601D\u3063\u3066\u3044\u305F\u3060\u3053\u3046\u30C3\uFF01",
    "id" : 78664630075006976,
    "created_at" : "2011-06-09 03:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 78668717961125888,
  "created_at" : "2011-06-09 03:44:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78630781823619072",
  "text" : "\u305D\u308D\u305D\u308D\u51FA\u306A\u3044\u3068\u9593\u306B\u5408\u308F\u306C(\u76EE\u767D",
  "id" : 78630781823619072,
  "created_at" : "2011-06-09 01:13:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78479656516452352",
  "text" : "\u591C\u4E2D\u306B\u6383\u9664\u3057\u305F\u304F\u306A\u308B\u30D1\u30BF\u30FC\u30F3\u5165\u308A\u307E\u3057\u305F\u3002",
  "id" : 78479656516452352,
  "created_at" : "2011-06-08 15:13:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78478910005837824",
  "text" : "\u6E7F\u5EA6\u9AD8\u3059\u304E\u308B\u3002\u3002\u3002\u9664\u6E7F\u30C3\uFF01",
  "id" : 78478910005837824,
  "created_at" : "2011-06-08 15:10:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78475854237270016",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u90E8\u5C4B\u3092\u7247\u3065\u3051\u3066\u74B0\u5883\u3092\u6574\u3048\u3088\u3046\u3002",
  "id" : 78475854237270016,
  "created_at" : "2011-06-08 14:57:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78475770305052673",
  "text" : "\u305D\u308C\u3067\u3082\u7A4D\u8AAD\u304C\u3042\u308B\u304B\u3089\u305D\u308C\u3067\u3044\u3044\u306E\u304B\u3002\u5229\u606F\u3057\u304B\u8FD4\u305B\u3066\u3044\u306A\u3044\u501F\u91D1\u306E\u5370\u8C61\u306B\u8FD1\u3044\u3002",
  "id" : 78475770305052673,
  "created_at" : "2011-06-08 14:57:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78475649194524672",
  "text" : "\u5E30\u5B85\u3002\u672C\u3092\u9078\u3073\u8CB7\u3046\u6642\u9593\u3068\u8AAD\u3080\u6642\u9593\u304C\u91E3\u308A\u5408\u308F\u306A\u3044\u3002\u8AAD\u3082\u3046\u3068\u601D\u3063\u3066\u30D0\u30A4\u30C8\u884C\u304D\u304C\u3051\u306B\u8CB7\u3063\u305F\u672C\u304C\u5BB6\u306B\u3064\u304F\u3053\u308D\u306B\u306F\u8AAD\u307F\u7D42\u308F\u3063\u3066\u3044\u308B\u2026\u3002",
  "id" : 78475649194524672,
  "created_at" : "2011-06-08 14:57:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78475359158411266",
  "text" : "RT @_flyingmoomin: \u300C\u6570\u5B66\u3084\u3063\u3066\u308B\uFF1F\u300D \u300C\u3084\u3063\u3066\u308B\uFF01\u300D \u300C\u306A\u306B\u7814\u7A76\u3057\u3066\u308B\u306E\uFF1F\u300D \u300C\u3048\u3063\u300D\u300C\u597D\u304D\u306A\u8AD6\u6587\u306F\uFF1F\u300D\u300C...\u300D\u300C\u4EE3\u6570, \u89E3\u6790\uFF1F\u5177\u4F53\u7684\u306A\u306E\u304C\u597D\u304D\uFF1F\u305D\u308C\u3068\u3082\u62BD\u8C61\u8AD6\uFF1F\u597D\u304D\u306A\u30CE\u30EB\u30E0\u306F\uFF1F\u4F8B\u5916\u578BLie\u7FA4\u306F\u3069\u308C\u597D\u304D\uFF1F\u66F2\u7387\u3067\u3044\u3046\u3068\u3069\u306E\u7B26\u53F7\u304C\u597D\u304D\uFF1F\u300D\u300C......\u300D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78456342620291072",
    "text" : "\u300C\u6570\u5B66\u3084\u3063\u3066\u308B\uFF1F\u300D \u300C\u3084\u3063\u3066\u308B\uFF01\u300D \u300C\u306A\u306B\u7814\u7A76\u3057\u3066\u308B\u306E\uFF1F\u300D \u300C\u3048\u3063\u300D\u300C\u597D\u304D\u306A\u8AD6\u6587\u306F\uFF1F\u300D\u300C...\u300D\u300C\u4EE3\u6570, \u89E3\u6790\uFF1F\u5177\u4F53\u7684\u306A\u306E\u304C\u597D\u304D\uFF1F\u305D\u308C\u3068\u3082\u62BD\u8C61\u8AD6\uFF1F\u597D\u304D\u306A\u30CE\u30EB\u30E0\u306F\uFF1F\u4F8B\u5916\u578BLie\u7FA4\u306F\u3069\u308C\u597D\u304D\uFF1F\u66F2\u7387\u3067\u3044\u3046\u3068\u3069\u306E\u7B26\u53F7\u304C\u597D\u304D\uFF1F\u300D\u300C......\u300D \u300C\u6570\u5B66\u3084\u3063\u3066\u308B\uFF1F\u300D \u300C\u3084\u3063\u3066\u306A\u3044\u3067\u3059...\u300D",
    "id" : 78456342620291072,
    "created_at" : "2011-06-08 13:40:24 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 78475359158411266,
  "created_at" : "2011-06-08 14:55:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78458278044106752",
  "text" : "@nico_reflexio \u3042\u305F\u308A\u307E\u3048\u3084\u308D",
  "id" : 78458278044106752,
  "created_at" : "2011-06-08 13:48:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78394755117088769",
  "text" : "\u78BA\u7387\u3068\u66D6\u6627\u6027\u306E\u54F2\u5B66\u3001\u30D5\u30E9\u30AF\u30BF\u30EB\u5E7E\u4F55\u5B66\u3001\u771F\u590F\u306E\u65B9\u7A0B\u5F0F\u2026\u3069\u308C\u3082\u9AD8\u3044\uFF01\u672C\u5C4B\u3067\uFF15\u4E07\u304F\u3089\u3044\u4F7F\u3063\u3066\uFF13\u5E74\u304F\u3089\u3044\u304B\u3051\u3066\u8AAD\u307F\u89E3\u304D\u305F\u3044\u3002",
  "id" : 78394755117088769,
  "created_at" : "2011-06-08 09:35:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78381394061033473",
  "text" : "\u5FAE\u3076\u3093\u30FB\u7A4D\u3076\u3093\u5B66\u90E8\u306E\u57FA\u790E\u73FE\u4EE3\u6587\"\u5316\u5B66\"\u7CFB\u3060\u3057\u73FE\u4EE3\u6587\u3068\u5316\u5B66\u3082\u3084\u3089\u306A\u304F\u3063\u3061\u3083\u3044\u3051\u306A\u3044\u306A",
  "id" : 78381394061033473,
  "created_at" : "2011-06-08 08:42:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 66, 73 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78364902896582657",
  "text" : "RT @hyuki: \u6570\u7406\u8AD6\u7406\u5B66\u8005\u306F\u305D\u308C\u306B\u5BFE\u3057\u3066\u300C\u305D\u306E\u8A00\u660E\u306Fproved\u3058\u3083\u306A\u3044\u304B\u3089trivial\u3058\u3083\u306A\u3044\u300D\u3068\u3044\u3046\u306E\u304B\u3057\u3089\u3093\u3002RT @tenapi: \u3042\u306E\u30D5\u30A1\u30A4\u30F3\u30DE\u30F3\u5148\u751F\u306F\u300C\u6570\u5B66\u8005\u306B\u3068\u3063\u3066 trivial \u3068\u306F proved \u3063\u3066\u610F\u5473\u306A\u3093\u3060\u306A\u300D\u3063\u3066\u8A00\u3063\u3066\u7B11\u3063\u3066\u3044\u305F\u305D\u3046\u3067\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "api",
        "screen_name" : "TenApi",
        "indices" : [ 55, 62 ],
        "id_str" : "3240677334",
        "id" : 3240677334
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78364602374684672",
    "text" : "\u6570\u7406\u8AD6\u7406\u5B66\u8005\u306F\u305D\u308C\u306B\u5BFE\u3057\u3066\u300C\u305D\u306E\u8A00\u660E\u306Fproved\u3058\u3083\u306A\u3044\u304B\u3089trivial\u3058\u3083\u306A\u3044\u300D\u3068\u3044\u3046\u306E\u304B\u3057\u3089\u3093\u3002RT @tenapi: \u3042\u306E\u30D5\u30A1\u30A4\u30F3\u30DE\u30F3\u5148\u751F\u306F\u300C\u6570\u5B66\u8005\u306B\u3068\u3063\u3066 trivial \u3068\u306F proved \u3063\u3066\u610F\u5473\u306A\u3093\u3060\u306A\u300D\u3063\u3066\u8A00\u3063\u3066\u7B11\u3063\u3066\u3044\u305F\u305D\u3046\u3067\u3059\u3002",
    "id" : 78364602374684672,
    "created_at" : "2011-06-08 07:35:51 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 78364902896582657,
  "created_at" : "2011-06-08 07:37:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78354696317845504",
  "geo" : { },
  "id_str" : "78354830770454529",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4",
  "id" : 78354830770454529,
  "in_reply_to_status_id" : 78354696317845504,
  "created_at" : "2011-06-08 06:57:02 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307F\u3069\u3044\u3055\u3093",
      "screen_name" : "midoisan",
      "indices" : [ 3, 12 ],
      "id_str" : "276342079",
      "id" : 276342079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78300099188494337",
  "text" : "RT @midoisan: \u3010\u6A5F\u68B0\u5B66\u7FD2\u306E\u30E1\u30EA\u30FC\u3011\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002\u4ECA\u3001R^n\u8D85\u7A7A\u9593\u5185\u306A\u306E\u2026\u300D\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002\u4ECA\u3001\u8D85\u5E73\u9762\u4E0A\u306B\u5C45\u308B\u306E\u2026\u300D\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002\u4ECA\u3001\u640D\u5931\u95A2\u6570\u306B\u3088\u308B\u65B9\u5411\u4FEE\u6B63\u3092\u53D7\u3051\u3066\u3044\u308B\u306E\u2026\u300D\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002\u4ECA\u3001\u89E3\u9818\u57DF\u5185\u306A\u306E\u2026\u300D\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www25.atpages.jp\/midoisan\/\" rel=\"nofollow\"\u003E\u307F\u3069\u3044\u3001\u5B9F\u306B\u307F\u3069\u3044\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78273791746260992",
    "text" : "\u3010\u6A5F\u68B0\u5B66\u7FD2\u306E\u30E1\u30EA\u30FC\u3011\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002\u4ECA\u3001R^n\u8D85\u7A7A\u9593\u5185\u306A\u306E\u2026\u300D\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002\u4ECA\u3001\u8D85\u5E73\u9762\u4E0A\u306B\u5C45\u308B\u306E\u2026\u300D\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002\u4ECA\u3001\u640D\u5931\u95A2\u6570\u306B\u3088\u308B\u65B9\u5411\u4FEE\u6B63\u3092\u53D7\u3051\u3066\u3044\u308B\u306E\u2026\u300D\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002\u4ECA\u3001\u89E3\u9818\u57DF\u5185\u306A\u306E\u2026\u300D\n\u300C\u3042\u305F\u3057\u30E1\u30EA\u30FC\u3055\u3093\u3002\u4ECA\u3001\u3042\u306A\u305F\u306E\u8B58\u5225\u95A2\u6570\u5185\u306B\u5C45\u308B\u306E\u2026\u300D",
    "id" : 78273791746260992,
    "created_at" : "2011-06-08 01:35:00 +0000",
    "user" : {
      "name" : "\u307F\u3069\u3044\u3055\u3093",
      "screen_name" : "midoisan",
      "protected" : false,
      "id_str" : "276342079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1297961215\/g_normal.jpg",
      "id" : 276342079,
      "verified" : false
    }
  },
  "id" : 78300099188494337,
  "created_at" : "2011-06-08 03:19:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78299839728848896",
  "text" : "\u30B9\u30FC\u30D1\u30FC\uFF32\uFF34\u30BF\u30A4\u30E0",
  "id" : 78299839728848896,
  "created_at" : "2011-06-08 03:18:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78299642873384960",
  "text" : "RT @JOJO_math: \u300C\u5FAE\u7A4D\u5206\u3060\u3051\u306B\u3000\u5FAE\u5206\u7A4D\u5206\uFF45\u6C17\u5206\u2026\u3058\u3083\u306A\u300D\u300C\u82B1\u4EAC\u9662\u3000\u30AA\u30E1\u30FC\u3053\u3046\u3044\u3046\u30C0\u30B8\u30E3\u30EC\u3044\u3046\u3084\u3064\u3063\u3066\u3088\u30FC\u3063\u3000\u30E0\u30B7\u30E7\u30FC\u306B\u8179\u304C\u7ACB\u3063\u3066\u3053\u306D\u30FC\u304B\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78287140915654657",
    "text" : "\u300C\u5FAE\u7A4D\u5206\u3060\u3051\u306B\u3000\u5FAE\u5206\u7A4D\u5206\uFF45\u6C17\u5206\u2026\u3058\u3083\u306A\u300D\u300C\u82B1\u4EAC\u9662\u3000\u30AA\u30E1\u30FC\u3053\u3046\u3044\u3046\u30C0\u30B8\u30E3\u30EC\u3044\u3046\u3084\u3064\u3063\u3066\u3088\u30FC\u3063\u3000\u30E0\u30B7\u30E7\u30FC\u306B\u8179\u304C\u7ACB\u3063\u3066\u3053\u306D\u30FC\u304B\u300D",
    "id" : 78287140915654657,
    "created_at" : "2011-06-08 02:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 78299642873384960,
  "created_at" : "2011-06-08 03:17:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fromdusktildawn",
      "screen_name" : "fromdusktildawn",
      "indices" : [ 3, 19 ],
      "id_str" : "6536792",
      "id" : 6536792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78299357652336640",
  "text" : "RT @fromdusktildawn: \u3082\u3057\u30C9\u30E9\u3092\u6620\u753B\u5316\u3057\u305F\u4EBA\u305F\u3061\u306F\u3001\u30C9\u30E9\u30C3\u30AB\u30FC\u3092\u77E5\u3089\u306A\u3044\u4EBA\u3005\u306B\u30C9\u30E9\u30C3\u30AB\u30FC\u3092\u77E5\u3063\u3066\u3082\u3089\u304A\u3046\u3068\u3057\u305F\u3002\u9867\u5BA2\u3092\u6E80\u8DB3\u3055\u305B\u308B\u3053\u3068\u3088\u308A\u3082\u9867\u5BA2\u3092\u5909\u3048\u308B\u3053\u3068\u304C\u307E\u305A\u5FF5\u982D\u306B\u3042\u3063\u305F\u3002 \u3053\u308C\u306F\u30C9\u30E9\u30C3\u30AB\u30FC\u304C\u30DE\u30FC\u30B1\u30C6\u30A3\u30F3\u30B0\u306E\u5931\u6557\u30D1\u30BF\u30FC\u30F3\u3068\u3057\u3066\u6307\u6458\u3057\u3066\u3044\u308B\u3053\u3068\u3002 ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78268513118191617",
    "text" : "\u3082\u3057\u30C9\u30E9\u3092\u6620\u753B\u5316\u3057\u305F\u4EBA\u305F\u3061\u306F\u3001\u30C9\u30E9\u30C3\u30AB\u30FC\u3092\u77E5\u3089\u306A\u3044\u4EBA\u3005\u306B\u30C9\u30E9\u30C3\u30AB\u30FC\u3092\u77E5\u3063\u3066\u3082\u3089\u304A\u3046\u3068\u3057\u305F\u3002\u9867\u5BA2\u3092\u6E80\u8DB3\u3055\u305B\u308B\u3053\u3068\u3088\u308A\u3082\u9867\u5BA2\u3092\u5909\u3048\u308B\u3053\u3068\u304C\u307E\u305A\u5FF5\u982D\u306B\u3042\u3063\u305F\u3002 \u3053\u308C\u306F\u30C9\u30E9\u30C3\u30AB\u30FC\u304C\u30DE\u30FC\u30B1\u30C6\u30A3\u30F3\u30B0\u306E\u5931\u6557\u30D1\u30BF\u30FC\u30F3\u3068\u3057\u3066\u6307\u6458\u3057\u3066\u3044\u308B\u3053\u3068\u3002 http:\/\/bit.ly\/jx8Re3",
    "id" : 78268513118191617,
    "created_at" : "2011-06-08 01:14:02 +0000",
    "user" : {
      "name" : "fromdusktildawn",
      "screen_name" : "fromdusktildawn",
      "protected" : false,
      "id_str" : "6536792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470789406836523008\/8OkmrPl5_normal.jpeg",
      "id" : 6536792,
      "verified" : false
    }
  },
  "id" : 78299357652336640,
  "created_at" : "2011-06-08 03:16:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78142510190432257",
  "text" : "\u6709\u7406\u3068\u3044\u3046\u5358\u8A9E\u3067\u53EF\u7B97\u3063\u3066\u8FD4\u3057\u3066\u304F\u308B\u306B\u305B\u307B\u51C4\u3044\u306A\u3002",
  "id" : 78142510190432257,
  "created_at" : "2011-06-07 16:53:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78141269293015040",
  "geo" : { },
  "id_str" : "78141539498475520",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u7121\u9650\u3063\u3066\u4E0D\u601D\u8B70\u3060\u306D\u3002",
  "id" : 78141539498475520,
  "in_reply_to_status_id" : 78141269293015040,
  "created_at" : "2011-06-07 16:49:29 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78140647105769474",
  "geo" : { },
  "id_str" : "78141026262454273",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u6709\u7406\u5316\u3082\u30FB\u30FB\u30FB",
  "id" : 78141026262454273,
  "in_reply_to_status_id" : 78140647105769474,
  "created_at" : "2011-06-07 16:47:27 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78140237662003200",
  "geo" : { },
  "id_str" : "78140356763451393",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u98DF\u3048\u308B\u306E\uFF1F",
  "id" : 78140356763451393,
  "in_reply_to_status_id" : 78140237662003200,
  "created_at" : "2011-06-07 16:44:47 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78140030060732416",
  "text" : "\u7A7A\u8179\u30FB\u30FB\u30FB\u3002",
  "id" : 78140030060732416,
  "created_at" : "2011-06-07 16:43:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skype",
      "screen_name" : "Skype",
      "indices" : [ 3, 9 ],
      "id_str" : "2459371",
      "id" : 2459371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78136126413602817",
  "text" : "RT @Skype: Update: today\u2019s problems stabilised; recovery ongoing http:\/\/bit.ly\/j9QyKs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78135698909175808",
    "text" : "Update: today\u2019s problems stabilised; recovery ongoing http:\/\/bit.ly\/j9QyKs",
    "id" : 78135698909175808,
    "created_at" : "2011-06-07 16:26:16 +0000",
    "user" : {
      "name" : "Skype",
      "screen_name" : "Skype",
      "protected" : false,
      "id_str" : "2459371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607943299983273985\/NBg0dDMn_normal.jpg",
      "id" : 2459371,
      "verified" : true
    }
  },
  "id" : 78136126413602817,
  "created_at" : "2011-06-07 16:27:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78135851351162880",
  "text" : "TL\u304C\u7A4F\u3084\u304B\u306B\u306A\u3063\u3066\u3044\u304F",
  "id" : 78135851351162880,
  "created_at" : "2011-06-07 16:26:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78128697093267456",
  "text" : "\u6B63\u8AD6\u3063\u3066\u5F37\u3044\u3051\u3069\u3001\u5F37\u3059\u304E\u308B\u305B\u3044\u3067\u3069\u3046\u3082\u3044\u3044\u5370\u8C61\u3092\u751F\u307E\u306A\u3044\u3088\u306A\u30FC\u3002",
  "id" : 78128697093267456,
  "created_at" : "2011-06-07 15:58:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78128596140564481",
  "text" : "\u7A81\u3063\u8FBC\u307F\u3068\u5C41\u7406\u5C48\u306E\u5883\u754C\u304C\u672A\u3060\u306B\u6355\u3048\u3089\u308C\u306A\u3044\u3002\u9B31\u9676\u3057\u304B\u3063\u305F\u3089\u30B9\u30EB\u30FC\u3057\u3066\u304F\u3060\u3055\u3044\u3002\uFF08\u30EA\u30D7\u30E9\u30A4\u304F\u308C\u308B\u3068\u5B09\u3057\u304F\u306F\u3042\u308A\u307E\u3059\u304C\u2026\u3002\uFF09",
  "id" : 78128596140564481,
  "created_at" : "2011-06-07 15:58:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 0, 12 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78127692767182848",
  "geo" : { },
  "id_str" : "78128088612995074",
  "in_reply_to_user_id" : 114792585,
  "text" : "@undefined_k \u826F\u304F\u4F3C\u3066\u308B\u3068\u306F\u8A00\u308F\u308C\u308B\u3093\u3067\u3059\u3051\u3069\u306D\u30FC\u3002\u5225\u4EBA\uFF08\uFF1F\uFF09\u3067\u3059\u3002",
  "id" : 78128088612995074,
  "in_reply_to_status_id" : 78127692767182848,
  "created_at" : "2011-06-07 15:56:02 +0000",
  "in_reply_to_screen_name" : "undefined_k",
  "in_reply_to_user_id_str" : "114792585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78127812132880384",
  "text" : "\u8907\u6570\u306E\u82D7\u3092\u307E\u3068\u3081\u3066\u30D7\u30E9\u30F3\u30BF\u30FC\u306B\u690D\u3048\u305F\u305B\u3044\u3067\u3001\u30D7\u30E9\u30F3\u30BF\u30FC\u7A81\u304D\u7834\u3063\u3066\u6839\u304C\u5F35\u3063\u3066\u3001\u89AA\u7236\u304C\u30D7\u30E9\u30F3\u30BF\u30FC\u3054\u3068\u58CA\u3057\u3066\u690D\u3048\u66FF\u3048\u3066\u305F\u8A18\u61B6\u304C\u2026\u3002",
  "id" : 78127812132880384,
  "created_at" : "2011-06-07 15:54:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78127478333374464",
  "text" : "\u3068\u601D\u3063\u305F\u3089\u5B9F\u5BB6\u306E\u7384\u95A2\u524D\u306E\u3054\u3061\u3083\u3054\u3061\u3083\u3057\u305F\u6728\u306E\u5B50\u4F9B\u306F\u4FFA\u304C\u57CB\u3081\u305F\u3093\u3060\u3063\u305F\u3002",
  "id" : 78127478333374464,
  "created_at" : "2011-06-07 15:53:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78127335735435265",
  "text" : "\u4FFA\u306F\u6728\u3092\u690D\u3048\u305F\u8A18\u61B6\u306F\u306A\u3044\u3051\u3069\u306A\u3002",
  "id" : 78127335735435265,
  "created_at" : "2011-06-07 15:53:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny",
      "screen_name" : "s_n_jenny",
      "indices" : [ 3, 13 ],
      "id_str" : "265428579",
      "id" : 265428579
    }, {
      "name" : "\u3068\u3061\u307C\u308A\u5143",
      "screen_name" : "tochibori",
      "indices" : [ 29, 39 ],
      "id_str" : "136389473",
      "id" : 136389473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/uoZqpss",
      "expanded_url" : "http:\/\/yfrog.com\/h48engjj",
      "display_url" : "yfrog.com\/h48engjj"
    } ]
  },
  "geo" : { },
  "id_str" : "78127269335408640",
  "text" : "RT @s_n_jenny: \u6050\u308D\u3057\u304F\u666E\u901A\u904E\u304E\u307E\u3059\u2026\u3002\n\u201C@tochibori: \u30AD\u30E3\u30C3\u30C1\u30D5\u30EC\u30FC\u30BA\u304C\u666E\u901A\u3059\u304E\u308B\u7537 http:\/\/t.co\/uoZqpss\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3068\u3061\u307C\u308A\u5143",
        "screen_name" : "tochibori",
        "indices" : [ 14, 24 ],
        "id_str" : "136389473",
        "id" : 136389473
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 61 ],
        "url" : "http:\/\/t.co\/uoZqpss",
        "expanded_url" : "http:\/\/yfrog.com\/h48engjj",
        "display_url" : "yfrog.com\/h48engjj"
      } ]
    },
    "geo" : { },
    "id_str" : "75926500574101504",
    "text" : "\u6050\u308D\u3057\u304F\u666E\u901A\u904E\u304E\u307E\u3059\u2026\u3002\n\u201C@tochibori: \u30AD\u30E3\u30C3\u30C1\u30D5\u30EC\u30FC\u30BA\u304C\u666E\u901A\u3059\u304E\u308B\u7537 http:\/\/t.co\/uoZqpss\u201D",
    "id" : 75926500574101504,
    "created_at" : "2011-06-01 14:07:43 +0000",
    "user" : {
      "name" : "Jenny",
      "screen_name" : "s_n_jenny",
      "protected" : false,
      "id_str" : "265428579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1373753868\/image_normal.jpg",
      "id" : 265428579,
      "verified" : false
    }
  },
  "id" : 78127269335408640,
  "created_at" : "2011-06-07 15:52:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78126637295734784",
  "text" : "\u2190\u753B\u50CF\u306F\u672C\u4EBA\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u3042\u3057\u304B\u3089\u305A\u3002",
  "id" : 78126637295734784,
  "created_at" : "2011-06-07 15:50:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78125999576985600",
  "text" : "\u6628\u65E5\u306E\u6388\u696D\u3067\u81EA\u7136\u6570\u306E\u6700\u5C0F\u5143\u306E\u8A71\u306B\u306A\u3063\u3066\uFF10\u306F\u81EA\u7136\u6570\u30AF\u30E9\u30B9\u30BF\u3092\u60F3\u3063\u3066\u7B11\u3044\u305D\u3046\u306B\u306A\u3063\u305F\u3002",
  "id" : 78125999576985600,
  "created_at" : "2011-06-07 15:47:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78125133306400768",
  "geo" : { },
  "id_str" : "78125631816220672",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss Skype\u8ABF\u5B50\u60AA\u3044\u307F\u305F\u3044\u306D\u30FC",
  "id" : 78125631816220672,
  "in_reply_to_status_id" : 78125133306400768,
  "created_at" : "2011-06-07 15:46:16 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 0, 12 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78124485529698305",
  "geo" : { },
  "id_str" : "78125150750523392",
  "in_reply_to_user_id" : 114792585,
  "text" : "@undefined_k @mo5nya \u3048\u3001\u305D\u3082\u305D\u3082\u753B\u50CF\u306A\u3093\u3060\u304B\u3089\u4E8C\u6B21\u5143\u3058\u3083\u306A\u3044\u304B\u3068\u601D\u3063\u305F\u79C1\u306F\u304A\u8A31\u3057\u304F\u3060\u3055\u3044\uFF01",
  "id" : 78125150750523392,
  "in_reply_to_status_id" : 78124485529698305,
  "created_at" : "2011-06-07 15:44:22 +0000",
  "in_reply_to_screen_name" : "undefined_k",
  "in_reply_to_user_id_str" : "114792585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78124406777462784",
  "text" : "\u30B9\u30A4\u30DE\u30BB\u30F3\u304C\u30AB\u30BF\u30AB\u30CA\u306A\u6BB5\u968E\u3067\u30D4\u30F3\u3068\u304F\u308B\u4EBA\u304C\u3044\u308B\u6C17\u304C\u3059\u308B\u3002",
  "id" : 78124406777462784,
  "created_at" : "2011-06-07 15:41:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/erFbtoI",
      "expanded_url" : "http:\/\/shindanmaker.com\/127649",
      "display_url" : "shindanmaker.com\/127649"
    } ]
  },
  "geo" : { },
  "id_str" : "78123877049434112",
  "text" : "\u624B\u5143\u306B\u3042\u308B\u30DE\u30F3\u30AC\u306E21p\u306E\u6700\u521D\u306E\u53F0\u8A5E\u3092\u30C4\u30A4\u30FC\u30C8\uFF01\u984C\u540D\u5F53\u3066\u305F\u4EBA\u306B\u306Fend313124\u304B\u3089\u3054\u8912\u7F8E\u306E\u30C1\u30E5\u30A6(*\u00B43`) http:\/\/t.co\/erFbtoI  \u300C\u30B9\u30A4\u30DE\u30BB\u30F3 \u5927\u30C8\u30ED\u3068\u305D\u308C\u3068\u30A2\u30EF\u30D3\u300D\n\u3053\u308C\u89E3\u308B\u3060\u308D\u30FB\u30FB\u30FB\u3002",
  "id" : 78123877049434112,
  "created_at" : "2011-06-07 15:39:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78089823985991680",
  "geo" : { },
  "id_str" : "78090187397275648",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6C34\u9053\u8FBC\u307F\u3067\u516D\u4E07\u884C\u304B\u306A\u3044\u304F\u3089\u3044",
  "id" : 78090187397275648,
  "in_reply_to_status_id" : 78089823985991680,
  "created_at" : "2011-06-07 13:25:26 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "78088685471539200",
  "geo" : { },
  "id_str" : "78089024979476483",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u628A\u63E1\u3057\u305F\u3001\u30B5\u30F3\u30AF\u30B9\u3002",
  "id" : 78089024979476483,
  "in_reply_to_status_id" : 78088685471539200,
  "created_at" : "2011-06-07 13:20:49 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78088629062352897",
  "text" : "SKype\u8ABF\u5B50\u60AA\u3044\uFF1F",
  "id" : 78088629062352897,
  "created_at" : "2011-06-07 13:19:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3067\u5375\uFF08\u9023\u7D9A\uFF09",
      "screen_name" : "takayukib",
      "indices" : [ 3, 13 ],
      "id_str" : "18113162",
      "id" : 18113162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78088533730017280",
  "text" : "RT @takayukib: \u300C\u76F8\u6027\u629C\u7FA4\u3063\u3066\u3069\u3093\u306A\u7FA4\u3067\u3059\u304B\uFF1F\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78084670486618112",
    "text" : "\u300C\u76F8\u6027\u629C\u7FA4\u3063\u3066\u3069\u3093\u306A\u7FA4\u3067\u3059\u304B\uFF1F\u300D",
    "id" : 78084670486618112,
    "created_at" : "2011-06-07 13:03:30 +0000",
    "user" : {
      "name" : "\u3086\u3067\u5375\uFF08\u9023\u7D9A\uFF09",
      "screen_name" : "takayukib",
      "protected" : false,
      "id_str" : "18113162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512086970223169536\/AovD4Xo5_normal.jpeg",
      "id" : 18113162,
      "verified" : false
    }
  },
  "id" : 78088533730017280,
  "created_at" : "2011-06-07 13:18:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78069724440834048",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 78069724440834048,
  "created_at" : "2011-06-07 12:04:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78027130662961153",
  "text" : "\u3042\u30FC\u3001\u65E9\u304F\u7D42\u308F\u3093\u306A\u3044\u304B\u306A\u30FC\u3002\u30B5\u30FC\u30AF\u30EB\u884C\u304D\u305F\u3044\u3093\u3060\u3051\u3069\u306A\u30FC\u3002",
  "id" : 78027130662961153,
  "created_at" : "2011-06-07 09:14:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78025660576178176",
  "text" : "\u3064\u3044\u3063\u305F\u30FC\u3068\u304B\u3084\u3063\u3066\u3093\u306E\u4FFA\u3060\u3051(\u76EE\u767D",
  "id" : 78025660576178176,
  "created_at" : "2011-06-07 09:09:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78025524886257664",
  "text" : "\u307E\u3041\u518D\u5C65\u3060\u3057\u306A\u30FC\u3002",
  "id" : 78025524886257664,
  "created_at" : "2011-06-07 09:08:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78025453989920768",
  "text" : "\u7686\u30C6\u30B9\u30C8\u306E\u4E88\u7FD2\u306B\u5FC5\u6B7B\u307F\u305F\u3044\u3067\u3059\u306D(\u767D\u76EE",
  "id" : 78025453989920768,
  "created_at" : "2011-06-07 09:08:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77994161025978368",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 77994161025978368,
  "created_at" : "2011-06-07 07:03:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77988044099174400",
  "text" : "@nico_reflexio \u30EF\u30BF\u30B7 \u30EF\u30EB\u30A4\u30D2\u30C8 \u30C1\u30AC\u30A6 \u30B7\u30F3\u30B8\u30C6",
  "id" : 77988044099174400,
  "created_at" : "2011-06-07 06:39:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77987302722375680",
  "text" : "@nico_reflexio \u4F59\u5206\u306B\u8CB7\u3063\u3066\u8EE2\u58F2\u2026\u3044\u3084\u3001\u306A\u3093\u3067\u3082\u306A\u3044",
  "id" : 77987302722375680,
  "created_at" : "2011-06-07 06:36:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77961113240735744",
  "text" : "\u6687\u2026\uFF1F",
  "id" : 77961113240735744,
  "created_at" : "2011-06-07 04:52:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77943986567921666",
  "text" : "@nico_reflexio \u307E\u3060\u6C7A\u307E\u3063\u3066\u306A\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u306A\u3002\u3060\u304C\u4F8B\u5E74\u306E\u3092\u898B\u3066\u308B\u3068\u591A\u3044\u306B\u6709\u308A\u5F97\u308B\u3002",
  "id" : 77943986567921666,
  "created_at" : "2011-06-07 03:44:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77913263987363841",
  "text" : "\u305D\u308D\u305D\u308D\u65E9\u3081\u306E\u663C\u3054\u98EF(\u9045\u3081\u306E\u671D\u3054\u306F\u3093\uFF1F)\u98DF\u3079\u3064\u3064\u5B66\u6821\u884C\u304F\u6E96\u5099\u3059\u308B\u304B\u30FC",
  "id" : 77913263987363841,
  "created_at" : "2011-06-07 01:42:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77907135777865728",
  "text" : "\u6C17\u6E29\u306E\u30A2\u30C3\u30D7\u30C0\u30A6\u30F3\u2026",
  "id" : 77907135777865728,
  "created_at" : "2011-06-07 01:18:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77905979982876672",
  "geo" : { },
  "id_str" : "77906548776648705",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u30EC\u30E2\u30F3",
  "id" : 77906548776648705,
  "in_reply_to_status_id" : 77905979982876672,
  "created_at" : "2011-06-07 01:15:43 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77902412031066113",
  "geo" : { },
  "id_str" : "77902824729624577",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u3088\u304F\u63A2\u3057\u305F\uFF1F",
  "id" : 77902824729624577,
  "in_reply_to_status_id" : 77902412031066113,
  "created_at" : "2011-06-07 01:00:55 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77901663502995457",
  "geo" : { },
  "id_str" : "77902200071921664",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u30D5\u30A9\u30ED\u30FC\u3057\u305F\u3088",
  "id" : 77902200071921664,
  "in_reply_to_status_id" : 77901663502995457,
  "created_at" : "2011-06-07 00:58:26 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77901857921581056",
  "text" : "\u6CB3\u539F\u753A\u3068\u65B0\u5BBF\u304C\u6B69\u3044\u3066\u79FB\u52D5\u3067\u304D\u308B\u8DDD\u96E2\u306B\u306A\u308B\u5922\u3092\u898B\u305F\u3002\u7269\u7406\u7684\u8DDD\u96E2\u7121\u8996\u7A0B\u5EA6\u306E\u80FD\u529B\u3002",
  "id" : 77901857921581056,
  "created_at" : "2011-06-07 00:57:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77901506837360641",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3002",
  "id" : 77901506837360641,
  "created_at" : "2011-06-07 00:55:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77746525006073856",
  "text" : "RT @_flyingmoomin: \u6614\u306E\u4EAC\u5927\u6570\u5B66\u6559\u5BA4\u3067\u306F, \u4E00\u5E74\u306E\u8B1B\u7FA9\u3067\u300CLie\u7FA4\u306F\u77E5\u3063\u3066\u308B\u3088\u306D\uFF1F\u300D\u3068\u8A00\u308F\u308C, \u6F14\u7FD2\u3067\u8A70\u307E\u308B\u3068\u300C\u304A\u524D\u4F55\u3057\u306B\u4EAC\u90FD\u6765\u305F\u3093\u3084\u300D\u3068\u8A00\u308F\u308C, \u5ECA\u4E0B\u3067\u3059\u308C\u9055\u3048\u3070\u5148\u751F\u306B\u6559\u79D1\u66F8\u3092\u6E21\u3055\u308C3\u65E5\u5F8C\u300C\u305D\u308D\u305D\u308D\u8AAD\u307F\u7D42\u308F\u3063\u305F\uFF1F\u300D\u3068\u805E\u304B\u308C\u305F\u3089\u3057\u3044\u306E\u3067, \u300C\u6614\u306E\u5B66\u751F\u306F\u512A ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77745996754456576",
    "text" : "\u6614\u306E\u4EAC\u5927\u6570\u5B66\u6559\u5BA4\u3067\u306F, \u4E00\u5E74\u306E\u8B1B\u7FA9\u3067\u300CLie\u7FA4\u306F\u77E5\u3063\u3066\u308B\u3088\u306D\uFF1F\u300D\u3068\u8A00\u308F\u308C, \u6F14\u7FD2\u3067\u8A70\u307E\u308B\u3068\u300C\u304A\u524D\u4F55\u3057\u306B\u4EAC\u90FD\u6765\u305F\u3093\u3084\u300D\u3068\u8A00\u308F\u308C, \u5ECA\u4E0B\u3067\u3059\u308C\u9055\u3048\u3070\u5148\u751F\u306B\u6559\u79D1\u66F8\u3092\u6E21\u3055\u308C3\u65E5\u5F8C\u300C\u305D\u308D\u305D\u308D\u8AAD\u307F\u7D42\u308F\u3063\u305F\uFF1F\u300D\u3068\u805E\u304B\u308C\u305F\u3089\u3057\u3044\u306E\u3067, \u300C\u6614\u306E\u5B66\u751F\u306F\u512A\u79C0\u3060\u3063\u305F\u300D\u7CFB\u306E\u610F\u898B\u306B\u306F\u771F\u646F\u306B\u306A\u3089\u3056\u308B\u3092\u5F97\u306A\u3044.",
    "id" : 77745996754456576,
    "created_at" : "2011-06-06 14:37:44 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 77746525006073856,
  "created_at" : "2011-06-06 14:39:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77688119327072258",
  "text" : "\u5348\u524D\u4E2D\u306B\u8D77\u304D\u3066\u9AEA\u3092\u5207\u308A\u306B\u884C\u304F\u306E\u3082\u3042\u308A\u304B\u3068\u3082\u601D\u3063\u305F\u304C\u518D\u5C65\u306E\u52C9\u5F37\u3068\u7720\u6C17\u3068\u706B\u66DC\u5B9A\u4F11\u306E\u7F8E\u5BB9\u9662\u304C\u591A\u3044\u306E\u3092\u8003\u3048\u308B\u3068\u7121\u3044\u304B\u306A\u30FC\u3002",
  "id" : 77688119327072258,
  "created_at" : "2011-06-06 10:47:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77687916410830848",
  "text" : "\u660E\u65E5\u306F\u56DB\u9650\u59CB\u307E\u308A\u306E\u516D\u9650\u7D42\u308F\u308A\u304B\u3002\u6700\u8FD1\u30B5\u30FC\u30AF\u30EB\u6B32\u6C42\u304C\u4E0D\u5B8C\u5168\u71C3\u713C\u306A\u306E\u306B\u306A\u30FC\u3002\u307E\u3041\u518D\u5C65\u306E\u81EA\u5206\u304C\u60AA\u3044\u3093\u3060\u3051\u3069\u306D\u3002\u6728\u66DC\u304B\u91D1\u66DC\u306B\u8AB0\u304B\u6765\u306A\u3044\u304B\u660E\u65E5\u3042\u305F\u308A\u8A98\u3063\u3066\u307F\u3088\u3046\u3002",
  "id" : 77687916410830848,
  "created_at" : "2011-06-06 10:46:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77687179752644608",
  "text" : "\u305F\u307E\u306B\u306F\u65E5\u4ED8\u304C\u5909\u308F\u308B\u524D\u306B\u5BDD\u3088\u3046\u304B\u3057\u3089\u30FC",
  "id" : 77687179752644608,
  "created_at" : "2011-06-06 10:44:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany wei shing",
      "screen_name" : "shing_t",
      "indices" : [ 3, 11 ],
      "id_str" : "971516882",
      "id" : 971516882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77634821878317056",
  "text" : "RT @Shing_T: \u5B66\u985E\u540D\u306F\u30E6\u30CB\u30FC\u30AF\u3067\u3001\u65B0\u5165\u751F\u304C\u300C\u541B\u3001\u4EBA\u9593\uFF1F\u300D\u300C\u3044\u3084\u3001\u50D5\u306F\u751F\u7269\u300D\u3068\u4F1A\u8A71\u3059\u308B\u69D8\u5B50\u306F\u3001\u5916\u90E8\u306E\u4EBA\u304C\u898B\u308C\u3070\u65E9\u304F\u3082\u5FC3\u3092\u75C5\u3093\u3067\u3057\u307E\u3063\u305F\u304B\u3068\u7591\u3046\u3053\u3068\u3060\u308D\u3046\u3002\u3053\u306E\u307B\u304B\u306B\u3082\u3001\u300C\u5730\u7403\u3063\u3066\u6848\u5916\u5973\u306E\u5B50\u3044\u308B\u3093\u3060\u306A\u300D\u300C\u4EBA\u9593\u8F9E\u3081\u3066\u60C5\u5831\u306B\u306A\u308A\u307E\u3057\u305F\u300D\u306A\u3069\u6570\u591A\u304F\u306E\u540D\u8A00\u3092\u751F\u3093\u3067\u3044\u308B\u3002\u30FC\u7B51\u6CE2\u5927\u5B66",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76873627005493248",
    "text" : "\u5B66\u985E\u540D\u306F\u30E6\u30CB\u30FC\u30AF\u3067\u3001\u65B0\u5165\u751F\u304C\u300C\u541B\u3001\u4EBA\u9593\uFF1F\u300D\u300C\u3044\u3084\u3001\u50D5\u306F\u751F\u7269\u300D\u3068\u4F1A\u8A71\u3059\u308B\u69D8\u5B50\u306F\u3001\u5916\u90E8\u306E\u4EBA\u304C\u898B\u308C\u3070\u65E9\u304F\u3082\u5FC3\u3092\u75C5\u3093\u3067\u3057\u307E\u3063\u305F\u304B\u3068\u7591\u3046\u3053\u3068\u3060\u308D\u3046\u3002\u3053\u306E\u307B\u304B\u306B\u3082\u3001\u300C\u5730\u7403\u3063\u3066\u6848\u5916\u5973\u306E\u5B50\u3044\u308B\u3093\u3060\u306A\u300D\u300C\u4EBA\u9593\u8F9E\u3081\u3066\u60C5\u5831\u306B\u306A\u308A\u307E\u3057\u305F\u300D\u306A\u3069\u6570\u591A\u304F\u306E\u540D\u8A00\u3092\u751F\u3093\u3067\u3044\u308B\u3002\u30FC\u7B51\u6CE2\u5927\u5B66",
    "id" : 76873627005493248,
    "created_at" : "2011-06-04 04:51:15 +0000",
    "user" : {
      "name" : "WCG",
      "screen_name" : "WCGuardian",
      "protected" : false,
      "id_str" : "59092034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2898417298\/d8d238d8fc28105f1e2b3b231c388893_normal.jpeg",
      "id" : 59092034,
      "verified" : false
    }
  },
  "id" : 77634821878317056,
  "created_at" : "2011-06-06 07:15:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77604135742083072",
  "text" : "@nico_reflexio \u3093\u30FC\u51A0\u5A5A\u846C\u796D\u304F\u3089\u3044\u5F62\u5F0F\u4E3B\u7FA9\u304C\u5165\u308A\u8FBC\u3093\u3067\u305F\u3089\u3042\u308C\u3060\u304C\u57FA\u672C\u81EA\u7531\u304C\u3044\u3044\u3088\u306A\u30FC\u3002\u670D\u88C5\u304C\u30BF\u30B9\u30AF\u306E\u80FD\u7387\u843D\u3068\u3055\u306A\u304D\u3083\u306A\u3093\u3060\u3063\u3066\u3044\u3044\u306F\u305A\u3060\u3088\u306A\u3002",
  "id" : 77604135742083072,
  "created_at" : "2011-06-06 05:14:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77586240534360064",
  "text" : "\u3042\u300113\u6642\u56DE\u3063\u3066\u305F\u3002\u534A\u5206\u96E2\u8131\u3002",
  "id" : 77586240534360064,
  "created_at" : "2011-06-06 04:02:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77586123110621184",
  "text" : "\u3069\u3046\u3067\u3082\u3044\u3044\u8A2D\u5B9A\u3067\u30AD\u30E3\u30E9\u304C\u6D3B\u304D\u308B\u2026\u6C17\u304C\u3059\u308B\u3002",
  "id" : 77586123110621184,
  "created_at" : "2011-06-06 04:02:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77585967107682304",
  "text" : "bot\u306B\u3082\u7A81\u3063\u8FBC\u307F\u305F\u3044\u3053\u3068\u304C\u591A\u304F\u3066\u56F0\u308B\u3002\u306B\u305B\u307B\u306F\u3068\u3082\u304B\u304F\u3001\u30C6\u30C8\u30E9\u3061\u3083\u3093\u306E\u304A\u3086\u306F\u3093\u304C\u3044\u3063\u3064\u3082\u79D8\u5BC6\u306A\u306E\u306F\u306A\u305C\u3060\u308D\u3046\u3001\u3068\u304B\u3001\u30DF\u30EB\u30AB\u3055\u3093\u306F\u3069\u3046\u3084\u3063\u3066\u5730\u57DF\u9650\u5B9A\u306E\u30AD\u30C3\u30C8\u30AB\u30C3\u30C8\u3092\u624B\u306B\u5165\u308C\u308B\u3093\u3060\u308D\u3046\u3001\u3068\u304B\u6319\u3052\u308C\u3070\u30AD\u30EA\u304C\u306A\u3044\u3051\u3069\u3002",
  "id" : 77585967107682304,
  "created_at" : "2011-06-06 04:01:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77585116809015296",
  "text" : "\u4E00\u3064\u4E00\u3064\u76EE\u306B\u3064\u3044\u305F\u30C4\u30A4\u30FC\u30C8\u306B\u3064\u3044\u3066\u30EA\u30D7\u30E9\u30A4\u306E\u30D1\u30BF\u30FC\u30F3\u3092\u6570\u7A2E\u985E\u77AC\u6642\u306B\u8003\u3048\u3066\u308B\u6C17\u304C\u3059\u308B\u3002\u771F\u306B\u6C17\u306B\u5165\u3063\u305F\u306E\u304C\u601D\u3044\u3064\u3044\u305F\u3089\u5B9F\u884C\u3002",
  "id" : 77585116809015296,
  "created_at" : "2011-06-06 03:58:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77584661651533826",
  "text" : "\uFF34\uFF2C\u306E\u30CD\u30BF\u306E\u6D88\u8CBB\u671F\u9650\u306F10\u5206\u3060\u3068\u4FE1\u3058\u308B\u30AF\u30E9\u30B9\u30BF",
  "id" : 77584661651533826,
  "created_at" : "2011-06-06 03:56:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77583069057531904",
  "text" : "(\u666E\u6BB5\u3001\u300C\u3046\u3061\u300D\u3063\u3066\u4E00\u4EBA\u79F0\u306F\u4F7F\u308F\u306A\u3044\u3093\u3060\u3088\u306A\u2026)",
  "id" : 77583069057531904,
  "created_at" : "2011-06-06 03:50:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77582795362410496",
  "text" : "\u653B\u3081\u306E\u59FF\u52E2(\uFF77\uFF98\uFF6F",
  "id" : 77582795362410496,
  "created_at" : "2011-06-06 03:49:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 45, 55 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77582616043339776",
  "text" : "\u3046\u3061\u306F\u3001\u305D\u3093\u306A\u30AE\u30E3\u30B0\u304C\uFF9E\u304A\u3046\u304E\uFF9E\u3087\u3046(\u306A\u305C\u304B\u5909\u63DB\u3067\u304D\u306A\u3044)\u3059\u308B\u3068\u306F\u601D\u308F\u306A\u3044\u3051\u3069\u306A\u30FC RT @maru_mtod: \u4ECA\u65E5\u306E\u967D\u6C17\u3060\u3068\u3001\u6247\u5B50\u3068\u30BB\u30F3\u30B9\u3092\u304B\u3051\u305F\u30C0\u30B8\u30E3\u30EC\u304C\u6A2A\u884C\u3059\u308B\u78BA\u738792\uFF05",
  "id" : 77582616043339776,
  "created_at" : "2011-06-06 03:48:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77580558338768897",
  "geo" : { },
  "id_str" : "77580855039635456",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u305D\u306E\u30EC\u30D9\u30EB\u306E\u30AE\u30E3\u30B0\u5ACC\u3044\u3058\u3083\u306A\u3044\u3002",
  "id" : 77580855039635456,
  "in_reply_to_status_id" : 77580558338768897,
  "created_at" : "2011-06-06 03:41:31 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77580599900123136",
  "text" : "\uFF11\uFF13\u6642\u304B\u3089\u672C\u6C17\u3060\u3059\u3002(\u300C\u3060\u3059\u300D\u306F\u8A9E\u5C3E\u3067\u306A\u3044)",
  "id" : 77580599900123136,
  "created_at" : "2011-06-06 03:40:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77580318919499776",
  "geo" : { },
  "id_str" : "77580403732516865",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u5065\u5EB7\u7684\u3058\u3083\u3093",
  "id" : 77580403732516865,
  "in_reply_to_status_id" : 77580318919499776,
  "created_at" : "2011-06-06 03:39:44 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77580039008428032",
  "geo" : { },
  "id_str" : "77580198589112320",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u30B3\u30FC\u30D2\u30FC\u306F\uFF1F",
  "id" : 77580198589112320,
  "in_reply_to_status_id" : 77580039008428032,
  "created_at" : "2011-06-06 03:38:55 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77579600405856256",
  "geo" : { },
  "id_str" : "77579822137753600",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u540C\u611F",
  "id" : 77579822137753600,
  "in_reply_to_status_id" : 77579600405856256,
  "created_at" : "2011-06-06 03:37:25 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77579737807077376",
  "text" : "\u524D\u8005\u306F\u5C0F\u8AAC\u3067\u898B\u305F\u3053\u3068\u3042\u308B\u304C\u5F8C\u8005\u306F\u5185\u8F2A\u30CD\u30BF\u3002\u56E3\u6247\u6B32\u3057\u3044\u306A\u3002\u6691\u3044\u3002",
  "id" : 77579737807077376,
  "created_at" : "2011-06-06 03:37:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77579415860678656",
  "text" : "\u60AA\u9B54\u306E\u6C57\u307F\u305F\u3044\u306B\u6FC3\u3044\u30B3\u30FC\u30D2\u30FC\u304C\u5929\u4F7F\u306E\u643E\u308A\u6ED3\u307F\u305F\u3044\u306B\u51B7\u3048\u3066\u3044\u308B\u3002\u304A\u8179\u75DB\u304F\u306A\u308A\u305D\u3046\u3002(\u8868\u73FE\u306F\u30A4\u30E1\u30FC\u30B8\u3067\u3059\u3002)",
  "id" : 77579415860678656,
  "created_at" : "2011-06-06 03:35:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77579001111134208",
  "text" : "student\u3068\u66F8\u3053\u3046\u3068\u3057\u3066stdio\u3068\u66F8\u3044\u3066\u300C\u3093\uFF1F\u300D",
  "id" : 77579001111134208,
  "created_at" : "2011-06-06 03:34:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77578070663499777",
  "text" : "\u6F22\u5B57\u3067\u304B\u304F\"\u3079\u304D\"(\uFF77\uFF98\uFF6F QT  #mathgirl \u6570\u5B66\u30AC\u30FC\u30EB\u3067\u306F\u300C\u3079\u304D\u7D1A\u6570\u300D\u3068\u306F\u66F8\u304B\u305A\u306B\u300C\u51AA\u7D1A\u6570\u300D\u3068\u66F8\u3044\u3066\u305F\u306F\u305A\u3002\u30C6\u30AF\u30CB\u30AB\u30EB\u30BF\u30FC\u30E0\u3067\u4E0D\u7528\u610F\u306B\u4EA4\u305C\u66F8\u304D\u3059\u308B\u3068\u3001\u8996\u8A8D\u6027\u304C\u3072\u3069\u304F\u60AA\u304F\u306A\u308B\u305F\u3081\u3002\u7279\u306B\u300C\u3079\u304D\u300D\u3092\u304B\u306A\u3067\u66F8\u304B\u308C\u308B\u3068\u3064\u3089\u3044\u3002\u96E3\u8AAD\u8A9E\u306F\u30EB\u30D3\u3067\u30AB\u30D0\u30FC\u3059\u308B\u306E\u304C\u826F\u3044\u3068\u601D\u3063\u3066\u3044\u307E\u3059\u3002",
  "id" : 77578070663499777,
  "created_at" : "2011-06-06 03:30:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77576253112197120",
  "text" : "\u304A\u3044\u3072\u30FC\u30B3\u30FC\u30B7\u30FC",
  "id" : 77576253112197120,
  "created_at" : "2011-06-06 03:23:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77576184833122304",
  "text" : "\u30B3\u30FC\u30A4\u30FC\u304C\u6FC3\u3072",
  "id" : 77576184833122304,
  "created_at" : "2011-06-06 03:22:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 3, 12 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77562984599257088",
  "text" : "RT @nisehorn: \u4EAC\u5927\u751F\u306E\u30CE\u30FC\u30C8\u306F\uFF78\uFF7F\u6C5A\u3044\u3063\u3066\u3044\u3046\u672C\u66F8\u304D\u305F\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77550119469326337",
    "text" : "\u4EAC\u5927\u751F\u306E\u30CE\u30FC\u30C8\u306F\uFF78\uFF7F\u6C5A\u3044\u3063\u3066\u3044\u3046\u672C\u66F8\u304D\u305F\u3044",
    "id" : 77550119469326337,
    "created_at" : "2011-06-06 01:39:23 +0000",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "protected" : false,
      "id_str" : "96348838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009677836\/06-12-24_23-49m_normal.jpg",
      "id" : 96348838,
      "verified" : false
    }
  },
  "id" : 77562984599257088,
  "created_at" : "2011-06-06 02:30:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77513590743121920",
  "text" : "\u6700\u9AD8\u6C17\u6E29\uFF12\uFF19\u2103\u3063\u3066\u2026\u3001\u4E00\u6708\u5F8C\u308D\u306B\u30BA\u30EC\u3066\u3084\u3044\u307E\u3044\u304B\u3002",
  "id" : 77513590743121920,
  "created_at" : "2011-06-05 23:14:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77513091994230784",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u3059\u304D\u3063\u8179\u306B\u73C8\u7432\u3067\u30AB\u30D5\u30A7\u30A4\u30F3\u3002\u80C3\u306B\u60AA\u3044\u306A\u3002",
  "id" : 77513091994230784,
  "created_at" : "2011-06-05 23:12:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77512615269634048",
  "geo" : { },
  "id_str" : "77512893804986369",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u3082\u3046\u300C\u306F\u300D\u3057\u304B\u3042\u3063\u3066\u306A\u3044\u3058\u3083\u3093",
  "id" : 77512893804986369,
  "in_reply_to_status_id" : 77512615269634048,
  "created_at" : "2011-06-05 23:11:28 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77512756424753152",
  "text" : "\u5BDD\u574A\u3059\u308B\u2192\u6642\u9593\u623B\u3059\u2192\u5BDD\u574A\u3059\u308B\u2192\u6642\u9593\u623B\u3059\u2192\u2026\u3063\u3066\u5922\u3092\u898B\u305F\u3002\u3069\u3063\u304B\u3067\u307F\u305F\u3088\u3046\u306A\u2190",
  "id" : 77512756424753152,
  "created_at" : "2011-06-05 23:10:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77512381110042624",
  "text" : "\u8D77\u304D\u305F\u3002",
  "id" : 77512381110042624,
  "created_at" : "2011-06-05 23:09:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77348328370741248",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 77348328370741248,
  "created_at" : "2011-06-05 12:17:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77292554302922752",
  "text" : "\uFF11\uFF18:\uFF10\uFF10\u304B\u3089\u518D\u5EA6\u672C\u6C17\u51FA\u3059\u3002",
  "id" : 77292554302922752,
  "created_at" : "2011-06-05 08:35:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77289767343099904",
  "text" : "\u30DF\u30B9\u30C9\u3068\u50B7\u7269\u8A9E\u30B3\u30E9\u30DC\u3068\u304B\u7121\u3044\u306E\u304B\u306A\u30FB\u30FB\u30FB\u3002",
  "id" : 77289767343099904,
  "created_at" : "2011-06-05 08:24:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77289214844207104",
  "text" : "\u3088\u3057\u3001\u30B3\u30FC\u30D2\u30FC\u3082\u5165\u308C\u305F\u3002\u4F11\u61A9\u3002",
  "id" : 77289214844207104,
  "created_at" : "2011-06-05 08:22:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "indices" : [ 3, 16 ],
      "id_str" : "99320050",
      "id" : 99320050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77274791555510272",
  "text" : "RT @galletti_bot: \u30D0\u30FC\u30DF\u30F3\u30AC\u30E0\u306E\u88FD\u9244\u5DE5\u5834\u306F\u591A\u91CF\u306E\u9244\u3092\u6D88\u8CBB\u3059\u308B\u3002\u30D0\u30FC\u30DF\u30F3\u30AC\u30E0\u306E\u88FD\u9244\u5DE5\u5834\u3067\u751F\u7523\u3055\u308C\u308B\u9244\u3060\u3051\u3067\u306F\u3001\u3068\u3066\u3082\u8DB3\u308A\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77272953456304128",
    "text" : "\u30D0\u30FC\u30DF\u30F3\u30AC\u30E0\u306E\u88FD\u9244\u5DE5\u5834\u306F\u591A\u91CF\u306E\u9244\u3092\u6D88\u8CBB\u3059\u308B\u3002\u30D0\u30FC\u30DF\u30F3\u30AC\u30E0\u306E\u88FD\u9244\u5DE5\u5834\u3067\u751F\u7523\u3055\u308C\u308B\u9244\u3060\u3051\u3067\u306F\u3001\u3068\u3066\u3082\u8DB3\u308A\u306A\u3044\u3002",
    "id" : 77272953456304128,
    "created_at" : "2011-06-05 07:18:02 +0000",
    "user" : {
      "name" : "\u30AC\u30EC\u30C3\u30C6\u30A3\u5148\u751F",
      "screen_name" : "galletti_bot",
      "protected" : false,
      "id_str" : "99320050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1835516629\/galletti_128_normal.png",
      "id" : 99320050,
      "verified" : false
    }
  },
  "id" : 77274791555510272,
  "created_at" : "2011-06-05 07:25:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77274788619493376",
  "text" : "\u7720\u6C17\u7206\u767A\u3057\u308D\u3088\u3002\u3082\u3046\u5341\u5206\u5BDD\u305F\u3058\u3083\u306A\u3044\u304B\u3002",
  "id" : 77274788619493376,
  "created_at" : "2011-06-05 07:25:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77271017650798592",
  "geo" : { },
  "id_str" : "77271679063171072",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u4F55\u304B\u3044\u3044\u3053\u3068\u3067\u3082\u3042\u3063\u305F\u306E\u304B\u3044\uFF1F",
  "id" : 77271679063171072,
  "in_reply_to_status_id" : 77271017650798592,
  "created_at" : "2011-06-05 07:12:58 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 18, 23 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 25, 35 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77266802794700800",
  "text" : "\u7DBA\u9E97\u306A \uFF15 \uFF17 \uFF15 \u3067\u3059\u306D\u3047\u3000RT @np2i: @end313124 \u7D71\u3079\u308B\u306A\u3069\u3001\u8A08\u308A\u77E5\u308C\u306A\u3044\u7D71\u8A08\u5B66\u3002",
  "id" : 77266802794700800,
  "created_at" : "2011-06-05 06:53:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77263433791324160",
  "text" : "@np2i \u5FAE\u304B\u306B\u5206\u304B\u308A\u3001\u7A4D\u3082\u308A\u3067\u306F\u3042\u308B\u304C\u5206\u304B\u3063\u305F\u304B\u3082\u3057\u308C\u306A\u3044\u3002\u5FAE\u5206\u7A4D\u5206\u2026\u3002",
  "id" : 77263433791324160,
  "created_at" : "2011-06-05 06:40:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    }, {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 15, 29 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77260060048375810",
  "text" : "@nico_reflexio @OhgakiRintaro \u304D\u308C\u3044\u3054\u3068\u3058\u3083\u306A\u304F\u3066\u5B9F\u60C5\u3092\u77E5\u308A\u305F\u3044\u306E\u306A\u3089\u3084\u3063\u3066\u3082\u3044\u3044\u3051\u3069\u3001\u30CD\u30BF\u3063\u307D\u304F\u306A\u308A\u305D\u3046\u3067\u30A2\u30EC\u3060\u306A\u3002\u3044\u3084\u3001\u5B9F\u60C5\u304C\u30CD\u30BF\u3063\u307D\u3044\u3093\u3060\u304C\u2026\u3002",
  "id" : 77260060048375810,
  "created_at" : "2011-06-05 06:26:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77255907708370945",
  "geo" : { },
  "id_str" : "77257488931635200",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u3001\u30D5\u30E9\u30F3\u30B9\u8A9E\u30B3\u30FC\u30EB\u4E8C\u56DE\u76EE\u306E\u30C6\u30B9\u30C8\u660E\u5F8C\u65E5\u307F\u305F\u3044\u3002\u3002\u3002\u3044\u308D\u3044\u308D\u5927\u5909\u304B\u3082\u3002\u3002\u3002",
  "id" : 77257488931635200,
  "in_reply_to_status_id" : 77255907708370945,
  "created_at" : "2011-06-05 06:16:35 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77249007159738368",
  "text" : "\u3053\u306E\u8AB2\u984C\u7D42\u308F\u3063\u305F\u3089\u30A2\u30A4\u30B9\u306E\u30B3\u30FC\u30D2\u30FC\u5165\u308C\u3066\u30DF\u30B9\u30BF\u30FC\u30C9\u30FC\u30CA\u30C4\u3067\u304A\u3084\u3064\u306B\u3057\u3088\u3046\u2026",
  "id" : 77249007159738368,
  "created_at" : "2011-06-05 05:42:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77244506084347904",
  "text" : "\u3053\u3046\u6691\u3044\u3068\u524D\u9AEA\u9B31\u9676\u3057\u3044\u306A\u3002",
  "id" : 77244506084347904,
  "created_at" : "2011-06-05 05:25:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    }, {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 15, 29 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77240655532920832",
  "geo" : { },
  "id_str" : "77241053492686848",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro @nico_reflexio \u30ED\u30AF\u306A\u3082\u3093\u3058\u3083\u306A\u3044\u305E\uFF57\uFF57\uFF57\uFF57\u6559\u80B2\u30B7\u30B9\u30C6\u30E0\u304C\u9762\u767D\u3044\u3093\u3058\u3083\u306A\u304F\u3066\u5B66\u751F\u306E\u4E00\u90E8\u304C\uFF08\u982D\u304A\u304B\u3057\u3044\u3068\u3044\u3046\u610F\u5473\u3067\uFF09\u9762\u767D\u3044\u3060\u3051\u3060\u304B\u3089\u306A\u3002",
  "id" : 77241053492686848,
  "in_reply_to_status_id" : 77240655532920832,
  "created_at" : "2011-06-05 05:11:16 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    }, {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 15, 29 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77240453489102848",
  "text" : "@nico_reflexio @OhgakiRintaro \uFF54\uFF4B\u305D\u308C\u3063\u3066\u5177\u4F53\u7684\u306B\u4F55\u3092\u3057\u3083\u3079\u308B\u3093\u3060\uFF1F",
  "id" : 77240453489102848,
  "created_at" : "2011-06-05 05:08:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    }, {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 15, 29 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77227868446408704",
  "text" : "@nico_reflexio @OhgakiRintaro \u305D\u3093\u306A\u3081\u3093\u3069\u304F\u3055\u3044\u3053\u3068\u3084\u3063\u3066\u3082\u30ED\u30AF\u306B\u805E\u304B\u306A\u3044\u751F\u5F92\u304C\u6CA2\u5C71\u3044\u308B\u306E\u3092\u304A\u524D\u306F\u77E5\u3063\u3066\u308B\u3060\u308D\u3046\u3002\u5927\u5B66\u306B\u3088\u3063\u3066\u8208\u5473\u306E\u6709\u7121\u3082\u3042\u308B\u3060\u308D\u3046\u3057\u3002",
  "id" : 77227868446408704,
  "created_at" : "2011-06-05 04:18:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77221991823847424",
  "geo" : { },
  "id_str" : "77224107942477824",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3046\u3061\u306B\u7F6E\u304D\u5834\u7121\u304F\u3066\u4F7F\u3063\u3066\u306A\u3044\u30DD\u30C3\u30C8\u3042\u308B\u3051\u3069\u6B32\u3057\u3044\uFF1F\uFF57",
  "id" : 77224107942477824,
  "in_reply_to_status_id" : 77221991823847424,
  "created_at" : "2011-06-05 04:03:56 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76988975381880835",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 76988975381880835,
  "created_at" : "2011-06-04 12:29:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76937707661688833",
  "text" : "\u30AA\u30FC\u30E9\u30B9\u89AA\u500D\u6E80\u30C4\u30E2\u3063\u3066\uFF14\u4F4D\u2192\u4E00\u4F4D\u306E\u307E\u304F\u308A\u3002\u3053\u308C\u306F\u6C17\u6301\u3061\u3044\u3044\uFF01\n\u724C\u8B5C: http:\/\/tenhou.net\/0\/?log=2011060417gm-0041-0000-a5db8a45&tw=3",
  "id" : 76937707661688833,
  "created_at" : "2011-06-04 09:05:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76680579608870912",
  "text" : "\u5BDD\u308B\u3000\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 76680579608870912,
  "created_at" : "2011-06-03 16:04:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76677748562739200",
  "geo" : { },
  "id_str" : "76678030378012672",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u304A\u524D\u3082\u56F0\u3063\u3066\u308B\u307F\u305F\u3044\u3060\u3057\u306A\u3002",
  "id" : 76678030378012672,
  "in_reply_to_status_id" : 76677748562739200,
  "created_at" : "2011-06-03 15:54:01 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 10, 22 ],
      "id_str" : "229754624",
      "id" : 229754624
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 24, 35 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76664899593441280",
  "text" : "\u306B\u305B\u307B\u9177\u3044\u306A RT @nisehorrrrn: @magokoro84 \u5F85\u6A5F\u3068\u304B\u3057\u3066\u3093\u3058\u3083\u306D\u30FC\u3088\u30D0\u30AB\u30B9ww",
  "id" : 76664899593441280,
  "created_at" : "2011-06-03 15:01:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76663511371100160",
  "text" : "@np2i \u4E8C\u4EBA\u306E\u7DDA\u578B\u7D50\u5408\u3067\u3001\u4E8C\u4EBA\u306E\u7A7A\u9593\u3092\u5F35\u308D\u3046\u3088\u3002",
  "id" : 76663511371100160,
  "created_at" : "2011-06-03 14:56:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 8, 13 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76658452172255232",
  "text" : "@mo5nya @np2i \u3000\u4E8C\u6B21\u95A2\u6570\u306A\u3089\uFF12\u91CD\u89E3\u4EE5\u4E0A\u306F\u306A\u3044\u306E\u3067\u5927\u4E08\u592B\u3067\u3059\u304B\u306D\uFF57\u3000\u305D\u306E\u7D50\u5A5A\u306B\u201D\u7121\u7406\u201D\u304C\u7121\u3044\u308F\u3051\u3067\u3059\u306D\u3002\u6574\u6570\u4FC2\u6570\u306A\u3089\u3067\u3059\u304C\u30FC\u3002",
  "id" : 76658452172255232,
  "created_at" : "2011-06-03 14:36:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76657562589732865",
  "text" : "\u3053\u3063\u3061\u3067\u884C\u304D\u3064\u3051\u306E\u7F8E\u5BB9\u9662\u307F\u305F\u3044\u306E\u7121\u3044\u304B\u3089\u306A\u30FC\u3002\u9069\u5F53\u306B\u521D\u56DE\u5B89\u3044\u3068\u3053\u308D\u884C\u3063\u3066\u307F\u3088\u3046\u304B\u306A\u30FC\u3002",
  "id" : 76657562589732865,
  "created_at" : "2011-06-03 14:32:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76656885893312512",
  "geo" : { },
  "id_str" : "76656992525094912",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002\uFF15\u3002",
  "id" : 76656992525094912,
  "in_reply_to_status_id" : 76656885893312512,
  "created_at" : "2011-06-03 14:30:25 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76656902909603841",
  "text" : "\u96E8\u3058\u3083\u306A\u304B\u3063\u305F\u3089\u3060\u3051\u3069\u30FC",
  "id" : 76656902909603841,
  "created_at" : "2011-06-03 14:30:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76656839932129280",
  "text" : "\u660E\u65E5\u306F\u305F\u307E\u306B\u306F\u56F3\u66F8\u9928\u306B\u884C\u3063\u3066\u307F\u3088\u3046\u304B\u306A\u3002\u4E00\u65E5\u3067\u4E88\u7FD2\u3092\u7247\u4ED8\u3051\u308B\u7CFB\u306E\u8A71\u3082\u3042\u308B\u3002",
  "id" : 76656839932129280,
  "created_at" : "2011-06-03 14:29:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76656179006291968",
  "text" : "\u30D0\u30C3\u30B5\u30EA\u884C\u3053\u3046\u3068\u3044\u3064\u3082\u601D\u3044\u3064\u3064\u5B89\u5B9A\u884C\u52D5\u3092\u3068\u3063\u3066\u3057\u307E\u3046\u3002\u826F\u304F\u3082\u60AA\u304F\u3082\u5B89\u5B9A\u3057\u3059\u304E\u3066\u3044\u308B\u3002",
  "id" : 76656179006291968,
  "created_at" : "2011-06-03 14:27:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76656028715974656",
  "text" : "\u9AEA\u3001\u5207\u308D\u3046\u304B\u306A\u3001\u4E7E\u304B\u306A\u3044\u3057\u6D17\u3046\u306E\u5927\u5909\u3060\u3057\u30C8\u30EA\u30FC\u30C8\u30E1\u30F3\u30C8\u6E1B\u308B\u3057\u3001\u4F55\u3088\u308A\u9B31\u9676\u3057\u3044\u3002",
  "id" : 76656028715974656,
  "created_at" : "2011-06-03 14:26:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76645333580529664",
  "geo" : { },
  "id_str" : "76655716932386817",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u30A2\u30CB\u30E1\u539F\u4F5C\u306E\u306F\u305A",
  "id" : 76655716932386817,
  "in_reply_to_status_id" : 76645333580529664,
  "created_at" : "2011-06-03 14:25:21 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76655603346448384",
  "text" : "RT @_curemoomin: \u300C\u81EA\u5206\u306E\u307B\u3046\u304C\u7D76\u5BFE\u306B\u6570\u5B66\u306E\u3053\u3068\u611B\u3057\u3066\u308B\u306E\u306B, \u306A\u3093\u3067\u3042\u3044\u3064\u306E\u307B\u3046\u304C\u6570\u5B66\u3067\u304D\u308B\u3053\u3068\u306B\u306A\u3063\u3066\u3093\u3060\u308D\u3046\u300D\u307F\u305F\u3044\u306A\u82DB\u7ACB\u3061, \u6570\u5B66\u5F92\u306A\u3089\u307F\u3093\u306A\u7D4C\u9A13\u3059\u308B\u3088\u306D.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76460439676010496",
    "text" : "\u300C\u81EA\u5206\u306E\u307B\u3046\u304C\u7D76\u5BFE\u306B\u6570\u5B66\u306E\u3053\u3068\u611B\u3057\u3066\u308B\u306E\u306B, \u306A\u3093\u3067\u3042\u3044\u3064\u306E\u307B\u3046\u304C\u6570\u5B66\u3067\u304D\u308B\u3053\u3068\u306B\u306A\u3063\u3066\u3093\u3060\u308D\u3046\u300D\u307F\u305F\u3044\u306A\u82DB\u7ACB\u3061, \u6570\u5B66\u5F92\u306A\u3089\u307F\u3093\u306A\u7D4C\u9A13\u3059\u308B\u3088\u306D.",
    "id" : 76460439676010496,
    "created_at" : "2011-06-03 01:29:24 +0000",
    "user" : {
      "name" : "\u3080\u3046\u307F\u3093",
      "screen_name" : "_submoomin",
      "protected" : true,
      "id_str" : "284046922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603530782649397248\/Se0jPYxq_normal.png",
      "id" : 284046922,
      "verified" : false
    }
  },
  "id" : 76655603346448384,
  "created_at" : "2011-06-03 14:24:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76655305068515328",
  "text" : "@np2i \u5168\u5358\u5C04\u3001\u7279\u7570\u70B9\u3001\u5FAE\u5206\u53EF\u80FD\u2026\u3044\u304F\u3089\u3067\u3082\u3046\u307E\u3044\u4E8B\u3092\u8A00\u3048\u305D\u3046\u306A\u7528\u8A9E\u304C\u3042\u308A\u307E\u3059\u306D",
  "id" : 76655305068515328,
  "created_at" : "2011-06-03 14:23:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76654492166266880",
  "text" : "\u76EE\u304C\u30B7\u30E7\u30DC\u30B7\u30E7\u30DC\u3057\u3066\u304D\u305F",
  "id" : 76654492166266880,
  "created_at" : "2011-06-03 14:20:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76635655496675328",
  "text" : "\u30B5\u30AE\u3000\u30B7\u30CA\u30A4\u3000\u30B7\u30F3\u30B8\u30C6\uFF01\u30C7\u30E2\u3000\u30AA\u30AB\u30CD\u3000\u30D2\u30C4\u30E8\u30A6\u30C0\u30AB\u30E9\u3000\u30C1\u30E7\u30C3\u30C8\u30C0\u30B1\u3000\u30D5\u30EA\u30B3\u30F3\u30C7\uFF01\u3000\u30C1\u30AC\u30A6\u3000\u30B5\u30AE\u30B8\u30E3\u30CA\u30A4\u30E8\uFF01",
  "id" : 76635655496675328,
  "created_at" : "2011-06-03 13:05:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/8NGlmfr",
      "expanded_url" : "http:\/\/shindanmaker.com\/126307",
      "display_url" : "shindanmaker.com\/126307"
    } ]
  },
  "geo" : { },
  "id_str" : "76635371789746176",
  "text" : "\u540C\u6027\u304B\u3089end313124\u3078\u306E\u8A55\u4FA1\u306F\u300C\u8A50\u6B3A\u5E2B\u300D\u300C\u30D6\u30B5\u30A4\u30AF\u300D\u300C10\u70B9\u300D\u3067\u3001\u7570\u6027\u304B\u3089\u306E\u8A55\u4FA1\u306F\u300C\u8AA0\u5B9F\u300D\u300C\u52AA\u529B\u5BB6\u300D\u300C90\u70B9\u300D\u3067\u3059\u3002 http:\/\/t.co\/8NGlmfr  \u3042\u308C\uFF1F\u3069\u3061\u3089\u306E\u8A55\u4FA1\u3082\u771F\u3067\u3042\u308B\u305F\u3081\u306B\u306F\u2026\u7570\u6027\u304C\u9A19\u3055\u308C\u3066\u308B\u3063\u3066\u4E8B\u306B\u306A\u308B\u2190",
  "id" : 76635371789746176,
  "created_at" : "2011-06-03 13:04:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76618749695901696",
  "text" : "\u3081\u3093\u307E\u2026",
  "id" : 76618749695901696,
  "created_at" : "2011-06-03 11:58:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76588059914805248",
  "text" : "\u3042\u30FC\u30C9\u30E97\u548C\u4E86\u308A\u305D\u3053\u306A\u3063\u305F",
  "id" : 76588059914805248,
  "created_at" : "2011-06-03 09:56:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76566036736000000",
  "text" : "ku\u30EA\u30B9\u30C8\u898B\u3066\u307F\u305F\u3089\u6C17\u4ED8\u3044\u3066\u306A\u3044\u4EBA\u7D50\u69CB\u3044\u308B\u306E\u306D\u30FC\u3002\u307E\u3041\u4F55\u968E\u306B\u3044\u308B\u304B\u3068\u304B\u3069\u3093\u306A\u5EFA\u7269\u306B\u3044\u308B\u304B\u3067\u611F\u899A\u306F\u9055\u3046\u3068\u601D\u3046\u3051\u3069\u3002",
  "id" : 76566036736000000,
  "created_at" : "2011-06-03 08:29:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76564393697099776",
  "geo" : { },
  "id_str" : "76565554953068544",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u304A\u524D\u2026\u307E\u3055\u304B\u2026",
  "id" : 76565554953068544,
  "in_reply_to_status_id" : 76564393697099776,
  "created_at" : "2011-06-03 08:27:05 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76565461499772928",
  "text" : "\u6B63\u76F4\u4F59\u9707\u306B\u306F\u6163\u308C\u3063\u3053\u3060\u3063\u305F\u304B\u3089\u307E\u305A\u81EA\u5206\u306E\u611F\u899A\u3092\u7591\u3063\u3066\u3057\u307E\u3063\u305F\u3002\u5730\u9707\u304B\u3081\u307E\u3044\u304B\u5224\u65AD\u3067\u304D\u306A\u3044\u30EC\u30D9\u30EB\u3002",
  "id" : 76565461499772928,
  "created_at" : "2011-06-03 08:26:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76564174091722752",
  "text" : "\u3086\u308C\u305F\uFF1F",
  "id" : 76564174091722752,
  "created_at" : "2011-06-03 08:21:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76486944686739456",
  "geo" : { },
  "id_str" : "76493819209719809",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30CA\u30A4\u30B9\u307C\u3063\u3061",
  "id" : 76493819209719809,
  "in_reply_to_status_id" : 76486944686739456,
  "created_at" : "2011-06-03 03:42:02 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u306C\u304E",
      "screen_name" : "kunren",
      "indices" : [ 3, 10 ],
      "id_str" : "16221788",
      "id" : 16221788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76479812109209600",
  "text" : "RT @kunren: \u83C5\u76F4\u4EBA\u300C\u5B87\u5B99\u306E\u5BFF\u547D\u3092\u5EF6\u3070\u3059\u305F\u3081\u306B\u3001\u541B\u305F\u3061\u306E\u5931\u671B\u304C\u5FC5\u8981\u306A\u3093\u3060\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/iphone.natsulion.org\" rel=\"nofollow\"\u003ENatsuLiphone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76433456300703744",
    "text" : "\u83C5\u76F4\u4EBA\u300C\u5B87\u5B99\u306E\u5BFF\u547D\u3092\u5EF6\u3070\u3059\u305F\u3081\u306B\u3001\u541B\u305F\u3061\u306E\u5931\u671B\u304C\u5FC5\u8981\u306A\u3093\u3060\u300D",
    "id" : 76433456300703744,
    "created_at" : "2011-06-02 23:42:10 +0000",
    "user" : {
      "name" : "\u304F\u306C\u304E",
      "screen_name" : "kunren",
      "protected" : false,
      "id_str" : "16221788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464373915209318400\/Xj-CosiO_normal.png",
      "id" : 16221788,
      "verified" : false
    }
  },
  "id" : 76479812109209600,
  "created_at" : "2011-06-03 02:46:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76444489677406209",
  "geo" : { },
  "id_str" : "76445682873024513",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u3044\u3084\u3001\u307E\u305F\u76EE\u899A\u307E\u3057\u524D\u306B\u8D77\u304D\u3066\u6B62\u3081\u305F\u3093\u3060\u3051\u3069\u305D\u308C\u304C\u3044\u3051\u306A\u304B\u3063\u305F\u307F\u305F\u3044\u3002",
  "id" : 76445682873024513,
  "in_reply_to_status_id" : 76444489677406209,
  "created_at" : "2011-06-03 00:30:45 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76444281686069248",
  "text" : "\u305F\u3060\u7A4F\u3084\u304B\u306B\u3001\u9759\u304B\u306B\u3001\u81EA\u7136\u306B\u3001\u4E8C\u5EA6\u5BDD\u3057\u3066\u3044\u305F\u3089\u3057\u3044\u3002\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 76444281686069248,
  "created_at" : "2011-06-03 00:25:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "indices" : [ 32, 46 ],
      "id_str" : "101753216",
      "id" : 101753216
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 71, 81 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76336570139025408",
  "text" : "\u305D\u308C\u56E0\u6570\u5206\u89E3\u3057\u305F\u3089\u79D8\u5BC6\u304C\u3070\u308C\u3061\u3083\u3046\u304B\u3089\u6B62\u3081\u3066\u307B\u3057\u304B\u3063\u305F\u306A RT @factoring_bot: 313124=2*2*7*53*211 RT @end313124: \u6771\uFF13\u5C40\u3000\u81EA\u98A8\u6771\u3001\u30C9\u30E9\u767D\u3002end313124\u306E\u624B\u724C\u306F",
  "id" : 76336570139025408,
  "created_at" : "2011-06-02 17:17:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haipai_tsumo",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76334637705728000",
  "text" : "\u6771\uFF13\u5C40\u3000\u81EA\u98A8\u6771\u3001\u30C9\u30E9\u767D\u3002end313124\u306E\u624B\u724C\u306F\uFF11\uFF12\uFF14\uFF14\uFF15\uFF19\u2461\u4E03\u516D\u4E94\u5317\u5317\u5317\u4E2D\u3002\u3069\u3046\u3057\u307E\u3057\u3087\u3046 http:\/\/shindanmaker.com\/122623 #haipai_tsumo \uFF19\u304B\u306A\u3002",
  "id" : 76334637705728000,
  "created_at" : "2011-06-02 17:09:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76321325957910529",
  "text" : "\u30D5\u30E9\u30F3\u30B9\u8A9E\u306E\u6642\u9593\u306B\u51FA\u3066\u304D\u305F\u300C\u7802\u306E\u672C\u300D\u306F\u5370\u8C61\u7684\u3060\u3063\u305F\u306A\u3002\u7121\u9650\u306E\u30DA\u30FC\u30B8\u304C\u3042\u308B\u672C\u3002\u30C7\u30B9\u30CE\u30FC\u30C8\u307F\u305F\u3044\uFF1F",
  "id" : 76321325957910529,
  "created_at" : "2011-06-02 16:16:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 0, 6 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76303563185340416",
  "geo" : { },
  "id_str" : "76304916506873856",
  "in_reply_to_user_id" : 5335922,
  "text" : "@hyuki \u3044\u3048\u3044\u3048\u3001\u6570\u5B66\u306E\u697D\u3057\u3055\u304C\u5E83\u307E\u3063\u3066\u3044\u304F\u3068\u3044\u3044\u3067\u3059\u306D\uFF01\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 76304916506873856,
  "in_reply_to_status_id" : 76303563185340416,
  "created_at" : "2011-06-02 15:11:24 +0000",
  "in_reply_to_screen_name" : "hyuki",
  "in_reply_to_user_id_str" : "5335922",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76300523472568321",
  "text" : "\u76EE\u899A\u3081\u3066\u76EE\u899A\u3081\u3089\u308C\u306A\u304F\u306A\u308B\u3068\u304B\u7B11\u3048\u306A\u3044",
  "id" : 76300523472568321,
  "created_at" : "2011-06-02 14:53:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76300461187137537",
  "text" : "\u3046\u3061\u306E\u76EE\u899A\u307E\u3057\u97F3\u304C\u3080\u3063\u3061\u3083\u3046\u308B\u3055\u3044\u304B\u3089\u8D77\u304D\u305F\u77AC\u9593\u306F\u5FC3\u81D3\u304C\u6B62\u307E\u308A\u305D\u3046\u306B\u306A\u308B\u3002",
  "id" : 76300461187137537,
  "created_at" : "2011-06-02 14:53:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76299759471706112",
  "geo" : { },
  "id_str" : "76299870444589056",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u304B\u3048\u308A\u30A1\uFF01",
  "id" : 76299870444589056,
  "in_reply_to_status_id" : 76299759471706112,
  "created_at" : "2011-06-02 14:51:21 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76299555964067840",
  "text" : "\u76EE\u899A\u307E\u3057\u306A\u308B\u524D\u306B\u8D77\u304D\u308C\u305F\u3051\u3069\u4E8C\u9650\u9045\u523B\u3057\u305F\u306E\u306F\u5E03\u56E3\u306E\u4E2D\u3067\u5E78\u305B\u306A\u6642\u3092\u904E\u3054\u3057\u3066\u3044\u305F\u304B\u3089\u3067\u3059\uFF08\uFF77\uFF98\uFF6F",
  "id" : 76299555964067840,
  "created_at" : "2011-06-02 14:50:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76298699805958146",
  "text" : "\u3042\u3001\u300C\u4ECA\u65E5\u306F\u300D\u304C\u91CD\u8907\u3057\u305F\u3002\u9577\u6587\u306F\u3053\u308C\u3060\u304B\u3089\u3044\u3051\u306A\u3044\u3002",
  "id" : 76298699805958146,
  "created_at" : "2011-06-02 14:46:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76298563633688576",
  "text" : "\u4ECA\u65E5\u306F\u76EE\u899A\u307E\u3057\u306A\u308B\u524D\u306B\u8D77\u304D\u308C\u305F\u3057\u30012\u9650\u9045\u523B\u3057\u305F\u3051\u3069\u96C6\u5408\u3068\u4F4D\u76F8\u3061\u3087\u3063\u3068\u3065\u3064\u3060\u3051\u3069\u308F\u304B\u3063\u305F\u3057\u3001\u8CB7\u304A\u3046\u3068\u601D\u3063\u3066\u305F\u3082\u306E1\/6\u304F\u3089\u3044\u3067\u624B\u306B\u5165\u3063\u305F\u3057\u3001\u307E\u3069\u30DE\u30AE\u898B\u7D42\u3048\u305F\u3057\u3001\u3055\u3063\u304D\u306E\u8AD6\u6587\u624B\u306B\u5165\u3063\u305F\u3057\u3001\u79C1\u306F\u4ECA\u65E5\u306F\u5E78\u305B\u3067\u3059\u3002",
  "id" : 76298563633688576,
  "created_at" : "2011-06-02 14:46:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76296841494409217",
  "text" : "@nico_reflexio \u3093\u30FC\u3001\u3053\u308C\u306F\u3069\u3063\u3061\u304B\u3063\u3066\u3044\u3046\u3068\u307E\u3069\u30DE\u30AE\u306E\u30BF\u30A4\u30C8\u30EB\u3092\u610F\u8B58\u3057\u305F\u3093\u3060\u3088\u3001\u3063\u3066\u8A00\u308F\u305B\u3093\u306A\u6065\u305A\u304B\u3057\u3044 \u2026\u2026\u3068\u3001\u30DF\u30B5\u30AB\u306F\u306A\u3093\u3060\u304B\u3093\u3060\u8A00\u3063\u3066\u30EA\u30D7\u30E9\u30A4\u3057\u307E\u3059\u3002",
  "id" : 76296841494409217,
  "created_at" : "2011-06-02 14:39:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76295955405746176",
  "text" : "\u81EA\u5206\u304C\u597D\u304D\u306A\u7269\u306B\u8208\u5473\u3092\u6301\u3063\u3066\u3082\u3089\u3048\u308B\u3053\u3068\u306F\u3068\u3063\u3066\u3082\u5B09\u3057\u3044\u306A\u3063\u3066\u3002",
  "id" : 76295955405746176,
  "created_at" : "2011-06-02 14:35:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76295795455963137",
  "text" : "\u3068\u3042\u308B\u58F0\u512A\u3055\u3093\u304C\u6570\u5B66\u3084\u308A\u306A\u304A\u305D\u3046\u304B\u306A\u7684\u306A\u8A71\u3092\u3057\u3066\u305F\u306E\u3067\u601D\u3044\u5207\u3063\u3066\u6570\u5B66\u30AC\u30FC\u30EB\u3092\u304A\u52E7\u3081\u3059\u308BRT\u3092\u3057\u3066\u307F\u305F\u3089\u597D\u611F\u89E6\u3002\u81EA\u5DF1\u6E80\u8DB3\u3060\u3051\u3069\u7D20\u76F4\u306B\u5B09\u3057\u3044\u3002#mathgirl",
  "id" : 76295795455963137,
  "created_at" : "2011-06-02 14:35:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76294858679140352",
  "text" : "\u3053\u3046\u3044\u3046\u306E\u3092\u8AAD\u3093\u3067\uFF08\u601D\u3044\u3064\u3051\u306A\u304F\u3066\u3082\uFF09\u5927\u7B4B\u3060\u3051\u3067\u3082\u7406\u89E3\u3067\u304D\u308B\u3001\u305D\u3046\u3044\u3046\u4EBA\u306B\u79C1\u306F\u306A\u308A\u305F\u3044\u3002",
  "id" : 76294858679140352,
  "created_at" : "2011-06-02 14:31:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76294664247984129",
  "text" : "\u8AAD\u3081\u305F\u7D50\u679C\u3001\u7406\u89E3\u3067\u304D\u308B\u304B\u306F\u307E\u305F\u5225\u306E\u304A\u8A71\u3002",
  "id" : 76294664247984129,
  "created_at" : "2011-06-02 14:30:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76294574888337408",
  "text" : "\u30B3\u30E9\u30C3\u30C4\u306E\u4E88\u60F3\u306E\u8AD6\u6587http:\/\/bit.ly\/kQK8fy \u6848\u5916\u77ED\u3044\u3002\u6642\u9593\u304B\u3051\u308C\u3070\u8AAD\u3081\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3068\u601D\u308F\u305B\u308B\u91CF\u3002\u3080\u3045\u3002\u9031\u672B\u3068\u304B\u4F7F\u3063\u3066\u30DF\u30EB\u30AB\uFF1F",
  "id" : 76294574888337408,
  "created_at" : "2011-06-02 14:30:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76292513861877760",
  "text" : "\u307E\u3069\u30DE\u30AE\u898B\u7D42\u3048\u305F\u3002\u5439\u3063\u98DB\u3093\u3067\u308B\u306A\u3041\u3002\u9762\u767D\u304B\u3063\u305F\u3002\u3044\u3044\u5177\u5408\u306E\u30CF\u30C3\u30D4\u30FC\u30A8\u30F3\u30C9\u3067\u30D0\u30C3\u30C8\u30A8\u30F3\u30C9\u3002\u6700\u7D42\u56DE\u306E\u30B9\u30B1\u30FC\u30EB\u306F\u30B7\u30E3\u30D5\u30C8\u3067\u3088\u304B\u3063\u305F\u3068\u5FC3\u304B\u3089\u601D\u3046\u3002",
  "id" : 76292513861877760,
  "created_at" : "2011-06-02 14:22:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u68EE\u5D8B\u79C0\u592A",
      "screen_name" : "morishimazo",
      "indices" : [ 17, 29 ],
      "id_str" : "133617033",
      "id" : 133617033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76287176761016320",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u3092\u304A\u52E7\u3081\u3057\u307E\u3059\uFF01 RT @morishimazo: \u7A3D\u53E4\u304C\u7D42\u308F\u3063\u3066\u5E30\u5B85\u4E2D\u306A\u3045\u3002\u306F\u3045\u3042\u301C\u3001\u6570\u5B66\u304B\u3041\u301C\u3001\u9AD8\u6821\u306E\u6559\u79D1\u66F8\u3067\u3082\u898B\u76F4\u305D\u3046\u304B\u306A\u3002\u2026\u3042\u3001\u305D\u3046\u3044\u3048\u3070\u6570\u2162\u3068\u6570\uFF23\u306E\u30C6\u30B9\u30C8\u306F\u58CA\u6EC5\u7684\u3060\u3063\u305F\u306E\u3092\u601D\u3044\u51FA\u3057\u305F\u2026(&gt;_&lt;)",
  "id" : 76287176761016320,
  "created_at" : "2011-06-02 14:00:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76262927220486144",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 76262927220486144,
  "created_at" : "2011-06-02 12:24:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76135618660409344",
  "geo" : { },
  "id_str" : "76135924945264640",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4",
  "id" : 76135924945264640,
  "in_reply_to_status_id" : 76135618660409344,
  "created_at" : "2011-06-02 03:59:53 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76117532196618240",
  "text" : "RT @JOJO_math: \u843D\u3061\u7740\u304F\u3093\u3060\u2026\u300E\u30A8\u30EB\u30C7\u30B7\u30E5\u6570\u221E\u306E\u6570\u5B66\u8005\u300F\u3092\u6570\u3048\u3066\u843D\u3061\u7740\u304F\u3093\u3060\uFF65\uFF65\uFF65\u3000\u300E\u30A8\u30EB\u30C7\u30B7\u30E5\u6570\u221E\u306E\u6570\u5B66\u8005\u300F\u306F\u5171\u8457\u8AD6\u6587\u3092\u6E21\u3063\u3066\u3044\u3063\u3066\u3082\u30DD\u30FC\u30EB\u30FB\u30A8\u30EB\u30C7\u30B7\u30E5\u307E\u3067\u8FBF\u308A\u3064\u304B\u306A\u3044\u5B64\u72EC\u306A\u8005\u2026\u2026\u3000\u79C1\u306B\u52C7\u6C17\u3092\u4E0E\u3048\u3066\u304F\u308C\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76112818193170432",
    "text" : "\u843D\u3061\u7740\u304F\u3093\u3060\u2026\u300E\u30A8\u30EB\u30C7\u30B7\u30E5\u6570\u221E\u306E\u6570\u5B66\u8005\u300F\u3092\u6570\u3048\u3066\u843D\u3061\u7740\u304F\u3093\u3060\uFF65\uFF65\uFF65\u3000\u300E\u30A8\u30EB\u30C7\u30B7\u30E5\u6570\u221E\u306E\u6570\u5B66\u8005\u300F\u306F\u5171\u8457\u8AD6\u6587\u3092\u6E21\u3063\u3066\u3044\u3063\u3066\u3082\u30DD\u30FC\u30EB\u30FB\u30A8\u30EB\u30C7\u30B7\u30E5\u307E\u3067\u8FBF\u308A\u3064\u304B\u306A\u3044\u5B64\u72EC\u306A\u8005\u2026\u2026\u3000\u79C1\u306B\u52C7\u6C17\u3092\u4E0E\u3048\u3066\u304F\u308C\u308B",
    "id" : 76112818193170432,
    "created_at" : "2011-06-02 02:28:04 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 76117532196618240,
  "created_at" : "2011-06-02 02:46:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76103845725470720",
  "text" : "\u6307\u6570\u7206\u767A\u3057\u308D",
  "id" : 76103845725470720,
  "created_at" : "2011-06-02 01:52:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76096671855026176",
  "text" : "\u3042\u3001\u9593\u306B\u5408\u308F\u306A\u3044 \u3086\u3063\u304F\u308A\u884C\u304F\u304B",
  "id" : 76096671855026176,
  "created_at" : "2011-06-02 01:23:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76094969668055040",
  "text" : "\uFF11\u6642\u9593\u3082\u5E03\u56E3\u306E\u4E2D\u3067\u3046\u3060\u3046\u3060\u3057\u3066\u3044\u308B\u7CFB\u306E\u8A71\u3082\u3042\u308B\u304C",
  "id" : 76094969668055040,
  "created_at" : "2011-06-02 01:17:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76094412995829760",
  "text" : "\u3042\u3001\u305D\u308D\u305D\u308D\u8D77\u304D\u306A\u3044\u3068\u2026\u4E8C\u9650\u2026",
  "id" : 76094412995829760,
  "created_at" : "2011-06-02 01:14:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76085710989438977",
  "text" : "\u6885\u96E8\u304C\u6765\u305F\u3068\u306F\u3064\u3086\u77E5\u3089\u305A",
  "id" : 76085710989438977,
  "created_at" : "2011-06-02 00:40:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76085525659918336",
  "text" : "\u304A\u306F\u3088\u3046\u3002\u5BD2\u3044\u3002\u7A7A\u8179\u2026\u3002",
  "id" : 76085525659918336,
  "created_at" : "2011-06-02 00:39:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75971254804430848",
  "text" : "\u304A\u3084\u3059\u307F",
  "id" : 75971254804430848,
  "created_at" : "2011-06-01 17:05:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 0, 12 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75959998118756352",
  "geo" : { },
  "id_str" : "75960520972312577",
  "in_reply_to_user_id" : 114792585,
  "text" : "@undefined_k \u3082\u3057\u6771\u4EAC\u3067\u5C31\u8077\u3057\u305F\u308A\u3057\u3066\u307E\u3060\u3084\u308B\u6C17\u304C\u3042\u3063\u305F\u3089\u518D\u52DF\u96C6\u304B\u3051\u308B\u3093\u3067\u305C\u3072\u305C\u3072\u3002",
  "id" : 75960520972312577,
  "in_reply_to_status_id" : 75959998118756352,
  "created_at" : "2011-06-01 16:22:54 +0000",
  "in_reply_to_screen_name" : "undefined_k",
  "in_reply_to_user_id_str" : "114792585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KU",
      "indices" : [ 78, 81 ]
    }, {
      "text" : "math",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75955346765656064",
  "text" : "[\u5B9A\u671F\u30FB\u624B\u52D5\u30FBRT\u5E0C\u671B]\uFF2B\uFF35\u3067\u6587\u7406\u554F\u308F\u305A\u958B\u304B\u308C\u305F\u6570\u5B66\u30B5\u30FC\u30AF\u30EB\u4F5C\u3063\u305F\u3089\uFF08\u7814\u7A76\u4F1A\u307F\u305F\u3044\u306A\u5805\u82E6\u3057\u3044\u306E\u3067\u306A\u304F\uFF09\u5165\u3063\u3066\u304F\u308C\u308B\u4EBA\u52DF\u96C6\u3002\uFF15\u4EBA\u4EE5\u4E0A\u3044\u308B\u3088\u3046\u306A\u3089\u672C\u6C17\u51FA\u3059\u3002 \u3000#KU #math",
  "id" : 75955346765656064,
  "created_at" : "2011-06-01 16:02:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75954676004163584",
  "text" : "\u5BDD\u305F\u3044\u3093\u3060\u3051\u3069\u306A\u30FC\u3002\u5FAE\u5999\u306A\u6642\u9593\u5E2F\u3002",
  "id" : 75954676004163584,
  "created_at" : "2011-06-01 15:59:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75953903040077824",
  "geo" : { },
  "id_str" : "75954287678734336",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u4ECA\u65E5\u306A\u3089\u307E\u306023\u6642\u9593\u4F4D\u3042\u308B\uFF01\u9811\u5F35\u3063\u3066\u304F\u3060\u3055\u3044\u306A\u3002",
  "id" : 75954287678734336,
  "in_reply_to_status_id" : 75953903040077824,
  "created_at" : "2011-06-01 15:58:08 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75947264278929408",
  "text" : "@np2i \u5225\u306B\u5B66\u5185\u30B5\u30FC\u30AF\u30EB\u306B\u3059\u308B\u3064\u3082\u308A\u3082\u306A\u3044\u3093\u3067\u3088\u304B\u3063\u305F\u3089\u3069\u3046\u305E\uFF01\u3084\u308B\u3068\u3057\u305F\u3089\u5F8C\u671F\u304B\u3089\u3067\u3059\u304C\u30FC\u3002",
  "id" : 75947264278929408,
  "created_at" : "2011-06-01 15:30:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75947051069870081",
  "text" : "@mo5nya \u3044\u3084\u3001\u304A\u3068\u3068\u3044\u7406\u5B66\u90E8\u4E8C\u56DE\u306E\u53CB\u9054\u306B\u5E7B\u60F3\u3092\u7815\u304B\u308C\u305F\u3070\u304B\u308A\u3060\u3063\u305F\u306E\u3067\u3001\u3064\u3044\u3002",
  "id" : 75947051069870081,
  "created_at" : "2011-06-01 15:29:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75945759211659264",
  "text" : "@mo5nya \u305D\u3093\u306A\u4EBA\u306B\u306F\u3044\u308D\u3093\u306A\u610F\u5473\u3067\u304A\u8FD1\u3065\u304D\u306B\u306F\u6210\u308C\u306A\u3055\u305D\u3046\u3067\u3059\u306D\u3047\u2026\u3002\u6570\u5B66\u30B5\u30FC\u30AF\u30EB\u306B\u5165\u3063\u3066\u304F\u308C\u306A\u3044\u304B\u306A\u30FC\u2190",
  "id" : 75945759211659264,
  "created_at" : "2011-06-01 15:24:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75944117657546753",
  "text" : "@mo5nya \u305D\u3093\u306A\u3082\u306E\u304C\u5B58\u5728\u3059\u308B\u3093\u3067\u3059\u304B\uFF01\u2026\u6570\u5B66\u7269\u7406\u7CFB\u306B\u9032\u3080\u7406\u5B66\u30AC\u30FC\u30EB\u306F\u5B66\u5E74\u306B3\u4EBA\u3057\u304B\u3044\u306A\u3044\u3068\u805E\u3044\u3066\u7D76\u671B\u3057\u305F\u306E\u3067\u3059\u304C\u3002",
  "id" : 75944117657546753,
  "created_at" : "2011-06-01 15:17:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75942653832855554",
  "text" : "\u4ECA\u5E74\u306ENF\u3067aisuzuki\u306B\u3042\u3084\u304B\u3063\u3066\u30A2\u30A4\u30B9\u5C4B\u3055\u3093\u3092\u3084\u308B\u731B\u8005\u306F\u3044\u306A\u3044\u3082\u306E\u304B\u300211\u6708\u3058\u3083\u5BD2\u3044\u3060\u308D\u3046\u3051\u3069\u3002",
  "id" : 75942653832855554,
  "created_at" : "2011-06-01 15:11:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75940396714303488",
  "text" : "\u4EAC\u90FD\u7248\u3067\u3059\u3042\u3057\u304B\u3089\u305A\u3002\u65E5\u4ED8\u5909\u3063\u305F\u77AC\u9593\u306B\u4ECA\u65E5\u306E\u5929\u6C17\u30672\u65E5\u306E\u5929\u6C17\u3092\u6559\u3048\u3066\u304F\u308C\u308Blivedoor\u30DE\u30B8\u30A4\u30B1\u30E1\u30F3\u3060\u306A\u3002\uFF08\u3061\u306A\u307F\u306Byahoo\u306F\u307E\u30601\u65E5\u306E\u5929\u6C17\u3092\u6559\u3048\u3066\u304F\u308C\u308B\uFF09",
  "id" : 75940396714303488,
  "created_at" : "2011-06-01 15:02:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75940048540925953",
  "text" : "\u4ECA\u65E5\u306E\u5929\u6C17 - 6\u67082\u65E5(\u6728).\n\u66C7\u6642\u3005\u96E8 \u6700\u9AD8\u6C17\u6E29 26\u2103 \n\u524D\u65E5\u5DEE (+7) \n\u6700\u4F4E\u6C17\u6E29 17\u2103 \n\u524D\u65E5\u5DEE (0) \n \u6642\u9593\u5E2F(\u6642) 0-6 6-12 12-18 18-24 \n\u964D\u6C34\u78BA\u7387 50% 10% 40% 40% \n\u98A8 \u6771\u306E\u98A8\u5F8C\u5357\u306E\u98A8",
  "id" : 75940048540925953,
  "created_at" : "2011-06-01 15:01:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75928731776073728",
  "text" : "\u5E30\u5B85\u30A3",
  "id" : 75928731776073728,
  "created_at" : "2011-06-01 14:16:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75928615820337152",
  "text" : "\u30DE\u30C3\u30C4\u306A\u3046\u3063\u3066\u3084\u3064\u3092\u3084\u3063\u3066\u307F\u305F\u3044\u3093\u3060\u3051\u3069\u7279\u5B9A\u3055\u308C\u305D\u3046\u3067\u6016\u3044\u304B\u3089\n\u3064\u300C\u30DE\u30C3\u30C4\u308F\u305A\u300D",
  "id" : 75928615820337152,
  "created_at" : "2011-06-01 14:16:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 19, 30 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u3057\u3044\u3054",
      "screen_name" : "nantoiukane",
      "indices" : [ 40, 52 ],
      "id_str" : "203648689",
      "id" : 203648689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75915141362880513",
  "text" : "\u60AA\u3044\u3053\u3068\u306F\u8A00\u308F\u306A\u3044\u3001\u6B62\u3081\u3066\u304A\u3051 RT @magokoro84: \u6765\u3044\u6765\u3044 RT @nantoiukane: \u4F59\u8A08\u306A\u7269\u3092\u5168\u3066\u6392\u9664\u3057\u3066\u7D14\u7C8B\u306A\u6C17\u6301\u3061\u3067\u8A00\u3046\u3068\u3001\u6587\u5B66\u90E8\u306B\u884C\u304D\u305F\u304B\u3063\u305F\u3002",
  "id" : 75915141362880513,
  "created_at" : "2011-06-01 13:22:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75914368138739713",
  "text" : "\u51FD\u6570\u306E\u51FD\u306E\u5B57\u306F\u6C17\u304C\u3064\u3044\u305F\u3089\u5B9A\u7740\u3057\u3066\u3044\u305F\u3002",
  "id" : 75914368138739713,
  "created_at" : "2011-06-01 13:19:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75914225456918529",
  "text" : "RT @_flyingmoomin: cut-off function \u306E\u3053\u3068\u300C\u30DE\u30DF\u3089\u308C\u51FD\u6570\u300D\u3063\u3066\u547C\u3076\u306E\u3084\u3081\u308D\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75913878764138496",
    "text" : "cut-off function \u306E\u3053\u3068\u300C\u30DE\u30DF\u3089\u308C\u51FD\u6570\u300D\u3063\u3066\u547C\u3076\u306E\u3084\u3081\u308D\uFF01",
    "id" : 75913878764138496,
    "created_at" : "2011-06-01 13:17:33 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 75914225456918529,
  "created_at" : "2011-06-01 13:18:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75914108234514433",
  "text" : "\u3060\u3044\u305F\u3044\u305F\u3060\u30DC\u30FC\u30C3\u3068\u601D\u8003\u3057\u3066\u308B\u3068\u53D6\u308A\u7559\u3081\u306A\u304F\u306A\u308B\u4E8B\u306F\u7A00\u306B\u3088\u304F\u3042\u308B\u3002",
  "id" : 75914108234514433,
  "created_at" : "2011-06-01 13:18:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75913868534226944",
  "text" : "\u4ECA\u306ETL\u306E\u30C6\u30FC\u30DE\u306F\u300C\u4E00\u8CAB\u6027\u306E\u6B20\u5982\u3068\u3044\u3046\u4E00\u8CAB\u6027\u300D",
  "id" : 75913868534226944,
  "created_at" : "2011-06-01 13:17:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75913674010804224",
  "text" : "\u554F\u984C\u3092\u65E9\u304F\u89E3\u3051\u308B\u3088\u3046\u306B\u3059\u308B\u306B\u306F\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u306E\u3060\u308D\u3046\u3002\u6C17\u304C\u3064\u3044\u305F\u3089\u65E9\u304F\u306A\u3063\u3066\u305F\u304B\u3089\u751F\u5F92\u306E\u6307\u5C0E\u304C\u96E3\u3057\u3044\u3002",
  "id" : 75913674010804224,
  "created_at" : "2011-06-01 13:16:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75913192290791424",
  "text" : "\u3042\u3001\u30A2\u30A4\u30B3\u30F3\u306F\u672C\u4EBA\u3058\u3083\u306A\u3044\u306E\u3067\u3054\u4E86\u627F\u4E0B\u3055\u3044\u3002",
  "id" : 75913192290791424,
  "created_at" : "2011-06-01 13:14:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75913025470730240",
  "text" : "\u30B0\u30EE\u30D0\u3068\u30B7\u30FC\u30AF\u30EE\u30FC\u30B5\u30FC\u4EE5\u5916\u3067\u300C\u30EE\u300D\u3092\u4F7F\u3046\u6A5F\u4F1A\u3042\u308B\uFF1F",
  "id" : 75913025470730240,
  "created_at" : "2011-06-01 13:14:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75912830309777408",
  "text" : "\u4E09\u6761\u3067\u6025\u884C\u306B\u6562\u3048\u3066\u4E57\u308A\u63DB\u3048\u306A\u3044\u5FC3\u306E\u4F59\u88D5()",
  "id" : 75912830309777408,
  "created_at" : "2011-06-01 13:13:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 17, 28 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75912598922600448",
  "text" : "\u4E0B\u8ECA\u3082\u30A8\u30AF\u30B9\u30C8\u30EA\u30FC\u30E0\u3067\u983C\u3080 RT @magokoro84: \u30A8\u30AF\u30B9\u30C8\u30EA\u30FC\u30E0\u4E57\u8ECA\u6C7A\u3081\u305F",
  "id" : 75912598922600448,
  "created_at" : "2011-06-01 13:12:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75912393183604736",
  "text" : "\u30AB\u30F3\u30ED\u306E\u679C\u5B9F\u306E\u3069\u98F4\u304C\u6700\u8FD1\u306E\u5B89\u5B9A\u884C\u52D5",
  "id" : 75912393183604736,
  "created_at" : "2011-06-01 13:11:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75912055307239426",
  "text" : "\u8868\u9762\u304C\u6ED1\u3089\u304B\u306A\u98F4\u306E\u304C\u597D\u304D\u3060\u306A\u30FC\u3002\u3053\u306E\u524D\u751F\u5354\u3067\u8CB7\u3063\u305F\u7D05\u8336\u306E\u98F4\u306F\u30D1\u30C3\u30B1\u30FC\u30B8\u306F\u6ED1\u3089\u304B\u3060\u3063\u305F\u306E\u306B\u958B\u3051\u3066\u307F\u305F\u3089\u81F3\u308B\u3068\u3053\u308D\u3067\u5FAE\u5206\u4E0D\u53EF\u3060\u3063\u305F\u3002\u30D1\u30C3\u30B1\u30FC\u30B8\u8A50\u6B3A\u3084\u3081\u3066\u307B\u3057\u3044\u3002",
  "id" : 75912055307239426,
  "created_at" : "2011-06-01 13:10:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75911610828468224",
  "text" : "\u30AC\u30E0\u3088\u308A\u98F4\u304C\u597D\u304D\u3002\u6975\u529B\u565B\u307E\u306A\u3044\u6D3E\u3067\u3059\u3002",
  "id" : 75911610828468224,
  "created_at" : "2011-06-01 13:08:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75911424345505792",
  "text" : "\u4FFA\u304C\u79FB\u52D5\u3057\u3066\u308B\u6642\u3060\u3051\u6B62\u3093\u3067\u304F\u308C\u306A\u3044\u304B\u306A\u30FC\u3002",
  "id" : 75911424345505792,
  "created_at" : "2011-06-01 13:07:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75911226953179136",
  "text" : "\u96E8\u7D9A\u304F\u306E\u306F\u5ACC\u3060\u306A\u3001\u56F0\u308B\u306A\u3002",
  "id" : 75911226953179136,
  "created_at" : "2011-06-01 13:07:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75911073718480897",
  "text" : "\u978D\u99AC\u306E\u5929\u72D7\u306B\u56E3\u6247\u501F\u308A\u3066\u304D\u3066\u96E8\u96F2\u3092\u9000\u304B\u3059\u7C21\u5358\u306A\u304A\u4ED5\u4E8B",
  "id" : 75911073718480897,
  "created_at" : "2011-06-01 13:06:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75906511246856193",
  "text" : "\u30D0\u30A4\u30C8\u7D42\u308F\u308A\u304C\u4E00\u756A\u3064\u3076\u3084\u3044\u3066\u308B\u6C17\u304C\u3059\u308B\u306A\u30FC\u3002",
  "id" : 75906511246856193,
  "created_at" : "2011-06-01 12:48:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 0, 7 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75906055221157889",
  "geo" : { },
  "id_str" : "75906337896267776",
  "in_reply_to_user_id" : 239486216,
  "text" : "@khulud \uFF11\uFF10\u8F9B\u3092\u98DF\u3079\u307E\u3057\u305F\u304C\u8F9B\u3044\u3070\u304B\u308A\u3067\u307E\u308B\u3067\u7F8E\u5473\u3057\u304F\u306A\u3044\u306E\u3067\u304A\u52E7\u3081\u3067\u304D\u307E\u305B\u3093",
  "id" : 75906337896267776,
  "in_reply_to_status_id" : 75906055221157889,
  "created_at" : "2011-06-01 12:47:35 +0000",
  "in_reply_to_screen_name" : "khulud",
  "in_reply_to_user_id_str" : "239486216",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75906077165748224",
  "text" : "23\u6642\u307E\u3067\u304B\u2026\u9593\u306B\u5408\u3046\u304B\u306A\u3002\u3066\u304B\u5E30\u308A\u9053\u3067\u306F\u306A\u3044\u304B\u3089\u96E8\u306A\u3089\u30B9\u30EB\u30FC\u3060\u306A\u3002",
  "id" : 75906077165748224,
  "created_at" : "2011-06-01 12:46:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75903740674183168",
  "geo" : { },
  "id_str" : "75903964230582272",
  "in_reply_to_user_id" : 230889478,
  "text" : "@kouennnoyuugu 5",
  "id" : 75903964230582272,
  "in_reply_to_status_id" : 75903740674183168,
  "created_at" : "2011-06-01 12:38:09 +0000",
  "in_reply_to_screen_name" : "phy_neko",
  "in_reply_to_user_id_str" : "230889478",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75903601494597633",
  "text" : "\u5BB6\u306B\u8CB7\u3044\u7F6E\u304D\u304C\u3042\u3063\u305F\u3088\u3046\u306A\u6C17\u3082\u3057\u306A\u3044\u3067\u3082\u306A\u3044\u3051\u3069\u2026\u305F\u3076\u3093\u3042\u308B\u307E\u3044",
  "id" : 75903601494597633,
  "created_at" : "2011-06-01 12:36:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75902976094519296",
  "geo" : { },
  "id_str" : "75903386582659074",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u5FD9\u3057\u304B\u3063\u305F\u308A\u5E30\u308A\u304C\u9045\u3044\u3068\u304D\u306B\u3057\u304B\u610F\u8B58\u304C\u5411\u304B\u306A\u3044\u65E5\u7528\u54C1\u30B7\u30EA\u30FC\u30BA\u3067\u3059\u3002",
  "id" : 75903386582659074,
  "in_reply_to_status_id" : 75902976094519296,
  "created_at" : "2011-06-01 12:35:52 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75902722821459970",
  "text" : "\u767E\u4E07\u904D\u306E\u30C0\u30A4\u30B3\u30AF\u30C9\u30E9\u30C3\u30AF\u3063\u3066\u4F55\u6642\u307E\u3067\u3084\u3063\u3066\u308B\u306E\u304B\u306A\u3002\u30DC\u30C7\u30A3\u30BD\u30FC\u30D7\u6B8B\u308A\u50C5\u304B\u306A\u306E\u3092\u601D\u3044\u51FA\u3057\u305F\u3002",
  "id" : 75902722821459970,
  "created_at" : "2011-06-01 12:33:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75901075303038976",
  "text" : "@ayu167 \u843D\u3061\u3066\u6765\u308B\u3082\u306E\u3092\u307E\u305F\u6295\u3052\u4E0A\u3052\u3088\u308A\u30BF\u30A4\u30DF\u30F3\u30B0\u3088\u304F\u634C\u3044\u3066\u3070\u304B\u308A\u306A\u3093\u3058\u3083\u2026",
  "id" : 75901075303038976,
  "created_at" : "2011-06-01 12:26:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75848074307706880",
  "text" : "\u307E\u3069\u30DE\u30AE\uFF19\u307E\u3067\u898B\u3066\u304B\u3089\u51FA\u3066\u304D\u305F\u3002\uFF31\uFF22\u5408\u7406\u7684\u3059\u304E\u3066\u9006\u306B\u723D\u3084\u304B\u3002",
  "id" : 75848074307706880,
  "created_at" : "2011-06-01 08:56:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 8, 18 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75847659646234624",
  "text" : "\u306B\u305B\u307B\u2026 RT @nisehorrn: \u884C\u304F\u5148\u3005\u306B\u79C1\u306E\u6B6F\u30D6\u30E9\u30B7\u304C\u2026\u3000\u4E95\u306E\u982D\u7DDA\u6CBF\u3044\u3060\u3068\u4E09\u4EF6\u304B",
  "id" : 75847659646234624,
  "created_at" : "2011-06-01 08:54:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75724421834350593",
  "text" : "\u304A\u306F\u3088\u3046\u3002\u96E8\u2026",
  "id" : 75724421834350593,
  "created_at" : "2011-06-01 00:44:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75588898255945729",
  "text" : "\u305D\u308D\u305D\u308D\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002 \u4ECA\u65E5\u8D77\u304D\u308C\u308B\u304B\u306A\u3002",
  "id" : 75588898255945729,
  "created_at" : "2011-05-31 15:46:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75585635947266048",
  "text" : "RT @JOJO_math: \u300C\u30AA\u30EC\u306E\u540D\u306F\u6570\u5B66\u30BB\u30DF\u30CA\u30FC\u300D\u300C\u6570\u7406\u79D1\u5B66\u300D\u300C\u5927\u5B66\u3078\u306E\u6570\u5B66\u300D\u300C\u7406\u7CFB\u3078\u306E\u6570\u5B66\u300D\u6708 \u520A \u8A8C \u653B \u6483\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75584335482322945",
    "text" : "\u300C\u30AA\u30EC\u306E\u540D\u306F\u6570\u5B66\u30BB\u30DF\u30CA\u30FC\u300D\u300C\u6570\u7406\u79D1\u5B66\u300D\u300C\u5927\u5B66\u3078\u306E\u6570\u5B66\u300D\u300C\u7406\u7CFB\u3078\u306E\u6570\u5B66\u300D\u6708 \u520A \u8A8C \u653B \u6483\uFF01",
    "id" : 75584335482322945,
    "created_at" : "2011-05-31 15:28:04 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 75585635947266048,
  "created_at" : "2011-05-31 15:33:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haipai_tsumo",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/vfvEv8V",
      "expanded_url" : "http:\/\/shindanmaker.com\/122623",
      "display_url" : "shindanmaker.com\/122623"
    } ]
  },
  "geo" : { },
  "id_str" : "75585504648761345",
  "text" : "\u6771\uFF14\u5C40\u3000\u81EA\u98A8\u5317\u3001\u30C9\u30E9\uFF14\u3002end313124\u306E\u624B\u724C\u306F\u4E00\u767C\u767D\u2461\u2464\u2462\u2462\u2467\u2468\uFF19\uFF17\uFF14\uFF13\uFF12\u3002\u3069\u3046\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/vfvEv8V #haipai_tsumo \n\u4E00\u304B\u306A\u30FC\u3002",
  "id" : 75585504648761345,
  "created_at" : "2011-05-31 15:32:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75582555075784704",
  "text" : "\u306A\u3093\u3068\u306A\u304F\u30DF\u30EB\u30AB\u3055\u3093\u306E\u4E2D\u306E\u4EBA\u306F\u658E\u85E4\u5343\u548C\u3055\u3093\u306E\u30A4\u30E1\u30FC\u30B8#mathgirl",
  "id" : 75582555075784704,
  "created_at" : "2011-05-31 15:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75580469416173568",
  "text" : "\u6B63\u88C5\uFF08\u7B11\uFF09\u3067\u3055\u3048\u3082\u3046\uFF13\u5E74\u524D\u304B\u3041\u2026\u4E0B\u3089\u306A\u3044\u898F\u5247\u3060\u3063\u305F\u306A\u3002\u3046\u3093\u3002",
  "id" : 75580469416173568,
  "created_at" : "2011-05-31 15:12:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75580294958284800",
  "text" : "\u3042\u308C\uFF1F\u9AD8\u6821\u306B\u590F\u670D\u3063\u3066\u6982\u5FF5\u3042\u3063\u305F\u3063\u3051\uFF1F\u6B63\u88C5\uFF08\u7B11\uFF09\u304C\u8A18\u61B6\u306B\u3042\u308B\u304B\u3089\u3042\u3063\u305F\u306E\u304B\u306A\u3002",
  "id" : 75580294958284800,
  "created_at" : "2011-05-31 15:12:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75579495419097088",
  "text" : "\u6674\u308C\u306E\u65E5\u306B\u306F\u8003\u3048\u3001\u96E8\u306E\u65E5\u306B\u8AAD\u3080\u3002\u7D20\u6674\u3089\u3057\u3044\u5F15\u304D\u3053\u3082\u308A\u7684\u767A\u60F3\u3002",
  "id" : 75579495419097088,
  "created_at" : "2011-05-31 15:08:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75579324534763521",
  "text" : "\uFF16\u6708\u7D42\u3063\u305F\u3089\u30C6\u30B9\u30C8\u306E\u5302\u3044\u3057\u3066\u6765\u308B\u3057\u3001\uFF16\u6708\u306F\u6674\u8003\u96E8\u8AAD\u306B\u3057\u3088\u3046\u3002\u3042\u308C\uFF1F\u50CD\u3044\u3066\u306A\u3044\uFF1F",
  "id" : 75579324534763521,
  "created_at" : "2011-05-31 15:08:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75579058989174784",
  "text" : "\u96E8\u3067\u3059\u3045\u30FC\u3001\u6885\u96E8\u3067\u3059\u3045\u30FC\u3001\u6E7F\u5EA6\uFF11\uFF10\uFF10\uFF05\u3067\u3059\u3045\u30FC\n\u9664\u6E7F\u6A5F\u6B32\u3057\u3044\u306A\u3002",
  "id" : 75579058989174784,
  "created_at" : "2011-05-31 15:07:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75578789140238336",
  "text" : "\u795D\u65E5\u306A\u3044\u3093\u3060\u3088\u306A\u2026",
  "id" : 75578789140238336,
  "created_at" : "2011-05-31 15:06:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75578681468260352",
  "text" : "\u30AD\u30FC\u30F3\u30B0\u30AA\u30D6\u4F55\u3082\u306A\u3044\u6708 \uFF16\u6708\u6765\u305F\u308B\u3002",
  "id" : 75578681468260352,
  "created_at" : "2011-05-31 15:05:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]