Grailbird.data.tweets_2010_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25868506375",
  "text" : "\u3046\u3081\u306B\u3085\u3046\u3081\u3093\u304C\u3046\u3081\u3047",
  "id" : 25868506375,
  "created_at" : "2010-09-29 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25884032386",
  "text" : "\u96A3\u3060\u304B\u308F\u304B\u3093\u306A\u3044\u3051\u3069\u8FD1\u6240\u304B\u3089\u521D\u97F3\u30DF\u30AF\u306E\u58F0\u304C\u3059\u308B\u3093\u3060\u304C\uFF57\uFF57\uFF57",
  "id" : 25884032386,
  "created_at" : "2010-09-29 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25669532147",
  "text" : "\u51FA\u6C41\u5DFB\u304D\u7389\u5B50\u5C4B\u3055\u3093\u306B\u306A\u308D\u3046\u3068\u601D\u3063\u305F\u3002",
  "id" : 25669532147,
  "created_at" : "2010-09-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25706624292",
  "text" : "\u897F\u5165\u3057\u3066\u306A\u304A\u56DB\u4F4D\u304B\u3089\u306E\u9006\u8EE2\u4E00\u4F4D\u3001\u4E8C\u4F4D\u304B\u3089\u306E\u88CF\u30C9\u30E9\u3064\u304B\u3063\u3066\u304E\u308A\u304E\u308A\u307E\u304F\u308A\u3067\u4E00\u4F4D\u3001\u8AB0\u304B\u306B\u632F\u308A\u8FBC\u3093\u3060\u308A\u4E09\u4F4D\u304C\u548C\u4E86\u3063\u305F\u3089\u4E09\u4F4D\u78BA\u5B9A\u306E\u72B6\u6CC1\u3067\u4E00\u4F4D\u306E\u30C4\u30E2\u3067\u4E8C\u4F4D\u2026\u2026\u306A\u3093\u304B\u30AA\u30AB\u30EB\u30C8\u30C1\u30C3\u30AF\u306A\u534A\u8358\uFF13\u56DE\u3067\u3057\u305F\u3002\u5B9F\u529B\u611F\u304C\u306A\u3044orz",
  "id" : 25706624292,
  "created_at" : "2010-09-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25709114796",
  "text" : "Fully cared,cow was to become Ms.Note. \u548C\u8A33\u305B\u3088",
  "id" : 25709114796,
  "created_at" : "2010-09-27 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25492011810",
  "geo" : { },
  "id_str" : "25503604825",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u56DB\u5E74\u5F8C\u306A\u3089\u9003\u3052\u304D\u308C\u308B\u30C3\uFF01",
  "id" : 25503604825,
  "in_reply_to_status_id" : 25492011810,
  "created_at" : "2010-09-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25352626870",
  "text" : "\u671D\u3063\u3071\u3089\u304B\u3089\u8272\u9055\u3044\u3067\u305F\uFF57\uFF57\uFF57\uFF57",
  "id" : 25352626870,
  "created_at" : "2010-09-23 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25198446458",
  "text" : "\u5929\u9CF3\u4E00\u7D1A\uFF4B\uFF54\uFF4B\uFF52",
  "id" : 25198446458,
  "created_at" : "2010-09-22 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25204795315",
  "text" : "\u67FF\u306E\u7A2E\u3092\u690D\u3048\u305F\u3089\u67FF\u306E\u7A2E\u306E\u6728\u304C\u80B2\u3064\u306E\u304B\u3001\u305D\u308C\u3068\u3082\u67FF\u306E\u6728\u304C\u80B2\u3064\u306E\u304B\u30FB\u30FB\u30FB\u8B0E\u306F\u6DF1\u307E\u308B\u3070\u304B\u308A\u3067\u3042\u308B\u3002",
  "id" : 25204795315,
  "created_at" : "2010-09-22 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25205666400",
  "text" : "\u6C37\u304C\u89E3\u3051\u308B\u901F\u5EA6\uFF1E\u98F2\u3080\u901F\u5EA6",
  "id" : 25205666400,
  "created_at" : "2010-09-22 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25206481505",
  "geo" : { },
  "id_str" : "25207843570",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u3093\u30FC\u4FFA\u306F\u3086\u3063\u304F\u308A\u98F2\u3080\u306E\u304C\u597D\u304D\u3060\u304B\u3089\u306A\u3041\uFF57",
  "id" : 25207843570,
  "in_reply_to_status_id" : 25206481505,
  "created_at" : "2010-09-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24888663870",
  "geo" : { },
  "id_str" : "24904817215",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5E30\u3063\u3066\u304Ak\u3000\u4FFA\u3082HANAKI\u3082\u3053\u306E\u6642\u671F\u306E\u30BB\u30F3\u30C8\u30EC\u306F\u884C\u304B\u306A\u304B\u3063\u305F\u3088\u3046\u306A\uFF57\uFF57",
  "id" : 24904817215,
  "in_reply_to_status_id" : 24888663870,
  "created_at" : "2010-09-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24797514460",
  "geo" : { },
  "id_str" : "24806254092",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5411\u304B\u3044\u306E\u30A2\u30D1\u30FC\u30C8\u306E\u5927\u5BB6\u65CF(\u30AA\u30AA\u30E4\u30BE\u30AF)\u3068\u8AAD\u3093\u3060\u79C1\u306F\u75C5\u6C17",
  "id" : 24806254092,
  "in_reply_to_status_id" : 24797514460,
  "created_at" : "2010-09-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24810519787",
  "text" : "\u30D1\u30F3\u8CB7\u3044\u306B\u884C\u304F\u3064\u3044\u3067\u306B\u30DD\u30B1\u30E2\u30F3\u8CB7\u304A\u3046\u304B\u3068\u601D\u3063\u305F\u304C\u5E97\u306E\u524D\u306E\u9577\u86C7\u306E\u5217\u3092\u898B\u3066\u4E88\u7D04\u3057\u306A\u3044\u3068\u8CB7\u3048\u306A\u3044\u3068\u609F\u3063\u305F\u3002\u51FA\u6765\u306A\u3044\u3068\u5206\u304B\u308B\u3068\u3084\u308A\u305F\u304F\u306A\u308B\u306E\u306F\u3053\u308C\u3044\u304B\u306B\u3002",
  "id" : 24810519787,
  "created_at" : "2010-09-18 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24860061638",
  "text" : "\u4E09\u6A0C\u5B50\u548C\u4E86\u3057\u305F\u3002\u5F79\u6E80\u4EE5\u5916\u3067\u548C\u4E86\u3063\u3066\u306A\u3044\u306E\u306F\u4EBA\u548C\uFF08\u30EC\u30F3\u30DB\u30FC\uFF09\u306E\u307F\u304B\u3041\u3002",
  "id" : 24860061638,
  "created_at" : "2010-09-18 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24765879770",
  "text" : "\u6771\u4E09\u5C40\u3000\u4E09\u8272\u540C\u523B\u3068\u30C1\u30E3\u30F3\u30BF\uFF01\u307E\u305F\u307E\u305F\u5999\u306A\u7D44\u307F\u5408\u308F\u305B\u3067\u548C\u4E86\u3063\u305F\u3002\u8A66\u5408\u306B\u306F\u8CA0\u3051\u305F\u304C\u52DD\u8CA0\u306B\u306F\u52DD\u3063\u305F\uFF08\uFF1F\uFF09 http:\/\/tenhou.net\/0\/?log=2010091721gm-0009-5430-8860a9df&tw=0",
  "id" : 24765879770,
  "created_at" : "2010-09-17 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24536515593",
  "geo" : { },
  "id_str" : "24537875184",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u304A\u4ED8\u304D\u5408\u3044\u3092\u524D\u63D0\u306B\u7D50\u5A5A\u3057\u3066\u3082\u3089\u3046\u308F\u3051\u3060\u306A\uFF57",
  "id" : 24537875184,
  "in_reply_to_status_id" : 24536515593,
  "created_at" : "2010-09-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24557020876",
  "text" : "\u6771\uFF14\u5C40\u3001\u5DBA\u5C71\u958B\u82B1\u3068\u4E09\u8272\u540C\u523B\u306E\u8907\u5408\u3068\u304B\u30AA\u30AB\u30EB\u30C8\u3060\u308D\u3046\u3002\u5357\uFF12\u5C40\u3067\u3082\u5DBA\u5C71\u3067\u624B\u304C\u9032\u3080\u3057\nhttp:\/\/tenhou.net\/0\/?log=2010091518gm-0009-0000-5b019e38&tw=2",
  "id" : 24557020876,
  "created_at" : "2010-09-15 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24557249003",
  "text" : "\u5357\uFF11\u3067\u3057\u305F\u30B5\u30FC\u30BB\u30F3",
  "id" : 24557249003,
  "created_at" : "2010-09-15 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24462799541",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F\u308A\u3001\u6E1B\u3089\u306A\u304B\u3063\u305F\u308A\u3002\u305D\u3046\u3044\u3048\u3070\u5B9F\u5BB6\u306B\u3044\u308B\u9593\u306B\u304A\u5BFF\u53F8\u98DF\u3079\u306B\u9023\u308C\u3066\u3063\u3066\u3082\u3089\u3048\u3070\u826F\u304B\u3063\u305F\u306A\u3041\u3001\u3068\u5F8C\u6094\u3057\u305F\u308A\u3057\u306A\u304B\u3063\u305F\u308A\u3002",
  "id" : 24462799541,
  "created_at" : "2010-09-14 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24343312986",
  "text" : "\u7A7A\u6C17\u304C\u6E7F\u3063\u3066\u308B\u3068\u601D\u3063\u3066\u305F\u3089\u3001\u3084\u3063\u3071\u308A\u4E00\u96E8\u304D\u307E\u3057\u305F\u3002\u306A\u3093\u304B\u732B\u307F\u305F\u3044\u3060\u306A\u2190",
  "id" : 24343312986,
  "created_at" : "2010-09-13 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24164714136",
  "geo" : { },
  "id_str" : "24165184684",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u5929\u4E0B\u308A\u3068\u306D\u3058\u308C\u56FD\u4F1A\u306E\u8B70\u8AD6\u304C\"\u306D\u3058\u308C\"\u306A\u3044\u3088\u3046\u306B\u3057\u3066\u3082\u3089\u3044\u306A\u3055\u3044",
  "id" : 24165184684,
  "in_reply_to_status_id" : 24164714136,
  "created_at" : "2010-09-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24180452146",
  "geo" : { },
  "id_str" : "24184245439",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5404\u6841\u306E\u548C\u306F9\u306E\u500D\u6570\u3058\u3083\u306D\uFF1F",
  "id" : 24184245439,
  "in_reply_to_status_id" : 24180452146,
  "created_at" : "2010-09-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24186862439",
  "geo" : { },
  "id_str" : "24187503866",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u305D\u306E\u767A\u8A00\u306B\u3059\u3067\u306B\u8AAC\u5F97\u529B\u304C\u306A\u3044\u3068\u3057\u305F\u3089\uFF1F",
  "id" : 24187503866,
  "in_reply_to_status_id" : 24186862439,
  "created_at" : "2010-09-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "24089847629",
  "geo" : { },
  "id_str" : "24092508692",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3042\u308B\u3042\u308B\uFF01",
  "id" : 24092508692,
  "in_reply_to_status_id" : 24089847629,
  "created_at" : "2010-09-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23970633704",
  "text" : "@koketomi \uFF17\u679A\u306A\u3089\u5341\u5206\u5C04\u7A0B\u570F\u5185\u3060\u305E",
  "id" : 23970633704,
  "created_at" : "2010-09-09 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23887046865",
  "text" : "\u96E8\u7537\u306E\u672C\u9818\u767A\u63EE\uFF01\u884C\u304D\u3082\u5E30\u308A\u3082\u53F0\u98A8\u3068\u4E00\u7DD2\u306B\uFF57\uFF57",
  "id" : 23887046865,
  "created_at" : "2010-09-08 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23887386936",
  "geo" : { },
  "id_str" : "23887670145",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u4E00\u5B57\u9055\u3044\uFF57\uFF57\u96FB\u8ECA\u306E\u4E2D\u3067\u30CB\u30E4\u30CB\u30E4\u3057\u3066\u3057\u307E\u3063\u305F\uFF57",
  "id" : 23887670145,
  "in_reply_to_status_id" : 23887386936,
  "created_at" : "2010-09-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23887584820",
  "geo" : { },
  "id_str" : "23887696791",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30A4\u30A4\u30CD\uFF01",
  "id" : 23887696791,
  "in_reply_to_status_id" : 23887584820,
  "created_at" : "2010-09-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23889063597",
  "geo" : { },
  "id_str" : "23891650702",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u65B0\u5E79\u7DDA\u3067\u53F0\u98A8\u56DE\u907F\u4F59\u88D5\u3067\u3057\u305F\uFF3E\uFF3E",
  "id" : 23891650702,
  "in_reply_to_status_id" : 23889063597,
  "created_at" : "2010-09-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23893816169",
  "text" : "\u53F0\u98A8\u306E\u3042\u3068\u306E\u96F2\u306E\u9699\u9593\u304B\u3089\u306E\u65E5\u5DEE\u3057\u306F\u3001\u610F\u5916\u306B\u3082\u7F8E\u3057\u3044\u3002",
  "id" : 23893816169,
  "created_at" : "2010-09-08 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23894448381",
  "text" : "\u540D\u53E4\u5C4B\u306A\u3046",
  "id" : 23894448381,
  "created_at" : "2010-09-08 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23894844069",
  "geo" : { },
  "id_str" : "23895845893",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30DE\u30B8\u304B\uFF57\uFF11\uFF12\uFF10\u79D2\u30A7\u2026\u3002",
  "id" : 23895845893,
  "in_reply_to_status_id" : 23894844069,
  "created_at" : "2010-09-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23027818132",
  "text" : "\u5F85\u3061\u5408\u308F\u305B\u306B\uFF12\u6642\u9593\u534A\u3082\u65E9\u304F\u7740\u3044\u3066\u3057\u307E\u3063\u305F\u2190",
  "id" : 23027818132,
  "created_at" : "2010-09-05 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22977919150",
  "text" : "\u306E\u3053\u304E\u308A\u6B32\u3057\u3044\uFF01\u8AB0\u304B\u8CB7\u3063\u3066\u304F\u308C\u306A\u3044\u304B\u306A\u3041",
  "id" : 22977919150,
  "created_at" : "2010-09-04 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22996498252",
  "text" : "\u643A\u5E2F\u3092\u643A\u5E2F\u3057\u306A\u304F\u3066\u3088\u3044\u7A0B\u5EA6\u306E\u9023\u7D61\u6570",
  "id" : 22996498252,
  "created_at" : "2010-09-04 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22793145824",
  "text" : "@chisa10404 \u30D5\u30EC\u30F3\u30C1\u30C8\u30FC\u30B9\u30C8\uFF1F\uFF57",
  "id" : 22793145824,
  "created_at" : "2010-09-02 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22805586251",
  "text" : "\u304B\u3048\u308B\u3053\u3074\u3087\u3053\u3074\u3087\u307F\u3074\u3087\u3053\u3074\u3087\u3053\u3001\u3042\u308F\u305B\u3066\u3053\u3074\u3087\u3053\u3074\u3087\u3080\u3053\u3074\u3087\u3053\u3074\u3087",
  "id" : 22805586251,
  "created_at" : "2010-09-02 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22694587369",
  "text" : "\u30AB\u30B7\u30B9\u30EA\u30AD\u30E5\u30FC\u30EB\u8003\u3048\u305F\u5974\u5929\u624D\u3060",
  "id" : 22694587369,
  "created_at" : "2010-09-01 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]