Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362586088352649216",
  "text" : "\u3053\u306E\u96D1\u306A\u611F\u3058\u2026\u5ACC\u3044\u3058\u3083\u306A\u3044\u305C\uFF01",
  "id" : 362586088352649216,
  "created_at" : "2013-07-31 14:50:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dars",
      "screen_name" : "daarrs",
      "indices" : [ 0, 7 ],
      "id_str" : "2575799821",
      "id" : 2575799821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362585879514054658",
  "text" : "@daarrs \u3059\u307F\u307E\u305B\u3093\u6B21\u3042\u3063\u305F\u6642\u306B\u8FD4\u3057\u307E\u3059\u8A31\u3057\u3066\u304F\u3060\u3055\u3044",
  "id" : 362585879514054658,
  "created_at" : "2013-07-31 14:49:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dars",
      "screen_name" : "daarrs",
      "indices" : [ 0, 7 ],
      "id_str" : "2575799821",
      "id" : 2575799821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362585460758945792",
  "text" : "@daarrs \u3053\u3053\u4E00\u5E2F\u4F55\u30D8\u30A4\u30E8\u30A6\u3088\uFF1F",
  "id" : 362585460758945792,
  "created_at" : "2013-07-31 14:48:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dars",
      "screen_name" : "daarrs",
      "indices" : [ 0, 7 ],
      "id_str" : "2575799821",
      "id" : 2575799821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362585093845422081",
  "text" : "@daarrs \u671D\u306F\u5F31\u3044",
  "id" : 362585093845422081,
  "created_at" : "2013-07-31 14:46:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dars",
      "screen_name" : "daarrs",
      "indices" : [ 0, 7 ],
      "id_str" : "2575799821",
      "id" : 2575799821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362583855233900545",
  "text" : "@daarrs \u3084\u3063\u3066\u6765\u305F\u6050\u7ADC\u304C\u753A\u3092\u7834\u58CA\u3059\u308B\u3084\u3064\u3067\u3059\u306D\uFF01[\u307B\u3068\u3093\u3069\u77E5\u3089\u306A\u3044\u3051\u3069\u597D\u304D\u3067\u3059]",
  "id" : 362583855233900545,
  "created_at" : "2013-07-31 14:41:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/362583472830836736\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/tGxRHnbkFi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQgnv1vCcAEQrXB.jpg",
      "id_str" : "362583472835031041",
      "id" : 362583472835031041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQgnv1vCcAEQrXB.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/tGxRHnbkFi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362583472830836736",
  "text" : "\u7126\u308B\u4EBA\u66F8\u3044\u305F\u3088\uFF01 http:\/\/t.co\/tGxRHnbkFi",
  "id" : 362583472830836736,
  "created_at" : "2013-07-31 14:40:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362583298553290752",
  "text" : "\u3053\u308C\u3042\u3052\u3089\u308C\u3066\u306A\u3044\u306A\uFF1F",
  "id" : 362583298553290752,
  "created_at" : "2013-07-31 14:39:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362576214717775874",
  "text" : "\u81EA\u5DF1\u4EA4\u5DEE\u306B\u5BFE\u3057\u3066\u4ED6\u8005\u4EA4\u5DEE\u306A",
  "id" : 362576214717775874,
  "created_at" : "2013-07-31 14:11:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362576129674055680",
  "text" : "\u30BF\u30B7\u30E3\u30B3\u30FC\u30B5\u3063\u3066\u30A4\u30F3\u30C9\u306E\u795E\u69D8\u307F\u305F\u3044\u306A\u96F0\u56F2\u6C17\u3042\u308B",
  "id" : 362576129674055680,
  "created_at" : "2013-07-31 14:11:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362570698616619008",
  "text" : "\u6C38\u7D9A\u9B54\u6CD5\u30AB\u30FC\u30C9\u300C\u6B63\u4E09\u89D2\u5F62\u91CF\u7523\u6A5F\u68B0\u300D\n\u81EA\u5206\u306E\u30B9\u30BF\u30F3\u30D0\u30A4\u30D5\u30A7\u30A4\u30BA\u6BCE\u306B\u6B63\u4E09\u89D2\u5F62\u30C8\u30FC\u30AF\u30F3\u30921\u4F53\u5834\u306B\u7279\u6B8A\u53EC\u559A\u3059\u308B.",
  "id" : 362570698616619008,
  "created_at" : "2013-07-31 13:49:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362570215436988418",
  "text" : "\u3069\u3063\u3061\u3082\u904A\u622F\u738B\u30AB\u30FC\u30C9\u3063\u307D\u3044",
  "id" : 362570215436988418,
  "created_at" : "2013-07-31 13:47:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362570134243647488",
  "text" : "\u4ECA\u65E5\u306E\u307E\u3068\u3081:\u30B8\u30A7\u30CB\u30D5\u30A1\u30FC\u5C71\u7530\u8ECD\u66F9,\u6B63\u4E09\u89D2\u5F62\u91CF\u7523\u6A5F\u68B0",
  "id" : 362570134243647488,
  "created_at" : "2013-07-31 13:47:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362557954005798914",
  "text" : "\u5B9F\u969B\u5965\u3086\u304B\u3057\u3044\u30E6\u30A6\u30B8\u30E7\u30A6\u3081\u3044\u305F\u3084\u308A\u3068\u308A\uFF01\u30DD\u30A8\u30C3\u30C8\uFF01",
  "id" : 362557954005798914,
  "created_at" : "2013-07-31 12:58:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362557793565294592",
  "geo" : { },
  "id_str" : "362557848779112448",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u30E6\u30A6\u30B8\u30E7\u30A6\uFF01",
  "id" : 362557848779112448,
  "in_reply_to_status_id" : 362557793565294592,
  "created_at" : "2013-07-31 12:58:21 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362554242449420291",
  "geo" : { },
  "id_str" : "362557610387456000",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u307E\u3044\u3064\u304D\u3058\u3085\u3046\u306A\u306A\u306B\u3061\u306F\u3055\u3064\u3070\u3064\uFF01\u306B\u7A7A\u76EE",
  "id" : 362557610387456000,
  "in_reply_to_status_id" : 362554242449420291,
  "created_at" : "2013-07-31 12:57:24 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362534880304824320",
  "text" : "\u4EBA\u306E\u5510\u63DA\u3052\u3068\u304B\u8A00\u3046\u5DE7\u5999\u306A\u30AB\u30CB\u30D0\u30E9\u30A4\u30BC\u30FC\u30B7\u30E7\u30F3",
  "id" : 362534880304824320,
  "created_at" : "2013-07-31 11:27:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362534768602132480",
  "text" : "\u4EBA\u306E\u5510\u63DA\u3052\u306B\u30EC\u30E2\u30F3\u304B\u3051\u308B\u304B\u3051\u306A\u4E91\u3005\u3044\u3046\u5974\u306F\u4EBA\u306E\u5510\u63DA\u3052\u3092\u98DF\u3079\u3088\u3046\u3068\u3057\u3066\u3044\u308B\u3053\u3068\u3078\u306E\u7570\u5E38\u3055\u306B\u6C17\u3065\u304F\u3079\u304D.",
  "id" : 362534768602132480,
  "created_at" : "2013-07-31 11:26:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 0, 8 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362365474396323843",
  "geo" : { },
  "id_str" : "362430019852713984",
  "in_reply_to_user_id" : 16929336,
  "text" : "@shigmax \u307E\u304B\u305B\u307E\u3057\u305F\uFF01",
  "id" : 362430019852713984,
  "in_reply_to_status_id" : 362365474396323843,
  "created_at" : "2013-07-31 04:30:25 +0000",
  "in_reply_to_screen_name" : "shigmax",
  "in_reply_to_user_id_str" : "16929336",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362413912676777984",
  "text" : "\u306D\u3059\u304E\u305F",
  "id" : 362413912676777984,
  "created_at" : "2013-07-31 03:26:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362376923537604608",
  "text" : "\u3082\u3046\u5C11\u3057\u3060\u3051\u2026",
  "id" : 362376923537604608,
  "created_at" : "2013-07-31 00:59:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362375309061931009",
  "text" : "\u9AD8\u3044\u3068\u3053\u308D\u304B\u3089\u843D\u3061\u308B\u3068\u304B\u305D\u3046\u3044\u3046\u306E\u3067\u304A\u9858\u3044\u3057\u307E\u3059\u3002",
  "id" : 362375309061931009,
  "created_at" : "2013-07-31 00:53:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362375211099750401",
  "text" : "\u306A\u3093\u304B\u3053\u3046\u3001\u3053\u308C\u3058\u3083\u306A\u3044\u611F",
  "id" : 362375211099750401,
  "created_at" : "2013-07-31 00:52:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362375123480756225",
  "text" : "\u6016\u3044\u5922\u307F\u3066\u76EE\u304C\u899A\u3081\u305F.\u5927\u5B66\u53D7\u9A13\u306E\u6642\u306B\u3001\u5B9F\u306F\u30AB\u30F3\u30CB\u30F3\u30B0\u3057\u3066\u3066\u3069\u3046\u3044\u3046\u8A33\u304B\u3053\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u3070\u308C\u3066\u793E\u4F1A\u7684\u306B\u6B7B\u306C\u5922.\u6016\u3044\u5922\u3063\u3066\u3053\u3046\u3058\u3083\u306A\u3044\u3084\u308D\u2026",
  "id" : 362375123480756225,
  "created_at" : "2013-07-31 00:52:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362248811319541761",
  "text" : "\u30B3\u30F3\u30C9\u30EB\u304C\u5730\u9762\u306B\u3081\u308A\u8FBC\u3093\u3069\u308B\u7D75\u3068\u304B\u305D\u3046\u3044\u3046\u30EC\u30D9\u30EB\u306A\u3093\u3060\u304C",
  "id" : 362248811319541761,
  "created_at" : "2013-07-30 16:30:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362248731472572417",
  "text" : "\u524D\u304B\u3089\u8A00\u3063\u3066\u308B\u304C\"\u7F8E\u5C11\u5973\u306A\u3093\u305E\u307E\u308B\u3067\u66F8\u3051\u306A\u304F\u3066\u3044\u3044\u304B\u3089\u601D\u3044\u3064\u3044\u305F\u30CD\u30BF\u3092\u53EF\u8996\u5316\u3059\u308B\u7A0B\u5EA6\u306E\"\u753B\u529B\u304C\u307B\u3057\u3044",
  "id" : 362248731472572417,
  "created_at" : "2013-07-30 16:30:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362248431235903490",
  "text" : "\u3044\u3084\u307E\u3041\u666E\u901A\u306B\u767B\u9332\u3059\u308B\u3060\u3051\u3060\u3063\u305F\u3089Facebook\u3067\u3082\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u3068\u306F\u601D\u3046\u3051\u3069\uFF1F",
  "id" : 362248431235903490,
  "created_at" : "2013-07-30 16:28:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362248216521084928",
  "text" : "TL\u3067\u3075\u3068\u30AF\u30EA\u30C3\u30AF\u3057\u305FURL\u304Cpixiv\u306ER18\u6295\u7A3F\u3060\u3063\u305F\u3093\u3060\u3051\u3069\u3001\u898B\u308B\u305F\u3081\u306B\u30A2\u30AB\u30A6\u30F3\u30C8\u304C\u3044\u308B\u3089\u3057\u304F\u3001\"\u30A2\u30AB\u30A6\u30F3\u30C8\u3092Facebook\u3067\u4F5C\u6210\uFF01\"\u30DC\u30BF\u30F3\u304C\u3042\u3063\u3066\u3001R18\u6295\u7A3F\u3092\u898B\u308B\u305F\u3081\u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u767B\u9332\u3092Facebook\u7D4C\u7531\u3067\u884C\u3046\u754C\u9688\u4F55\u8005\u3060\u3088\u3001\u3063\u3066",
  "id" : 362248216521084928,
  "created_at" : "2013-07-30 16:27:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362241479755837440",
  "text" : "\u3042\u30FC\u30A2\u30AB\u30A6\u30F3\u30C8\u9593\u9055\u3048\u307E\u3057\u305F\uFF1F",
  "id" : 362241479755837440,
  "created_at" : "2013-07-30 16:01:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362240679964983296",
  "text" : "\"(\u53CD\u5909\/\u5171\u5909)\u95A2\u624B\u306E\u6027\u8CEA\u3088\u308A\u81EA\u660E\"\u306B\u898B\u3048\u308B",
  "id" : 362240679964983296,
  "created_at" : "2013-07-30 15:58:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362180796242608128",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 362180796242608128,
  "created_at" : "2013-07-30 12:00:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362169299038769153",
  "text" : "\u3059\u3070\u3089",
  "id" : 362169299038769153,
  "created_at" : "2013-07-30 11:14:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362167990491430912",
  "text" : "\u4E2D\u8EAB\u3092\u8003\u3048\u305A\u306B\u558B\u308B\u80FD\u529B\u3067\u8ECD\u968A\u3068\u6E21\u308A\u5408\u3048\u308B\u3063\u3066\u8003\u3048\u308B\u3068\u30E4\u30D0\u3044",
  "id" : 362167990491430912,
  "created_at" : "2013-07-30 11:09:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362167861101334528",
  "text" : "\u5B66\u5712\u90FD\u5E02\u306B7\u4EBA\u3057\u304B\u3044\u306A\u3044Level5\u306E\u4E00\u4EBA\n\"\u306A\u3093\u306B\u3082\u8003\u3048\u306A\u3044\u3067\u558B\u308B\u4EBA\"",
  "id" : 362167861101334528,
  "created_at" : "2013-07-30 11:08:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362167680653983745",
  "text" : "\"\u4E2D\u8EAB\u3092\u8003\u3048\u306A\u3044\u3067\u558B\u308B\u80FD\u529B\"",
  "id" : 362167680653983745,
  "created_at" : "2013-07-30 11:07:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362167390777245699",
  "text" : "\u3057\u304B\u3057\u4E00\u5EA6\u8A71\u3057\u59CB\u3081\u308B\u3068\u5830\u3092\u5207\u3063\u305F\u3088\u3046\u306B\u8A71\u3057\u59CB\u3081\u308B\u4EBA\u3001\u3068\u3044\u3046\u610F\u5473\u3067\u30E4\u30DE\u30B2\u30F3\u3055\u3093\u3068\u4F3C\u3066\u308B\u306E\u304B\u3082\uFF1F",
  "id" : 362167390777245699,
  "created_at" : "2013-07-30 11:06:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 3, 15 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362167208014643200",
  "text" : "RT @hymathlogic: \u79C1\u3082\u4EBA\u898B\u77E5\u308A\u3067\u3059\u306D\u3002\n\u521D\u5BFE\u9762\u3068\u304B\u8D85\u7121\u7406\uFF5E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362167095947046913",
    "text" : "\u79C1\u3082\u4EBA\u898B\u77E5\u308A\u3067\u3059\u306D\u3002\n\u521D\u5BFE\u9762\u3068\u304B\u8D85\u7121\u7406\uFF5E",
    "id" : 362167095947046913,
    "created_at" : "2013-07-30 11:05:39 +0000",
    "user" : {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "protected" : false,
      "id_str" : "295467216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439420014165106688\/B9GEeIe7_normal.jpeg",
      "id" : 295467216,
      "verified" : false
    }
  },
  "id" : 362167208014643200,
  "created_at" : "2013-07-30 11:06:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362166729331322880",
  "text" : "\u3044\u3084\u30FC\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u306F\u597D\u304D\u3060\u3057\u3080\u3057\u308D\u304A\u558B\u308A\u306A\u3093\u3060\u3051\u3069\u3001\u521D\u5BFE\u9762\u306F\u672C\u5F53\u30C0\u30E1\u3002\u5F37\u8981\u3055\u308C\u308B\u3068\u306A\u304A\u3002",
  "id" : 362166729331322880,
  "created_at" : "2013-07-30 11:04:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jellyman5009",
      "screen_name" : "jellyman5009",
      "indices" : [ 0, 13 ],
      "id_str" : "2595829088",
      "id" : 2595829088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362166196839256065",
  "geo" : { },
  "id_str" : "362166587748384768",
  "in_reply_to_user_id" : 118355311,
  "text" : "@jellyman5009 \u904B\u60AA\u304F\u4E00\u4EBA\u639B\u3051\u3057\u3066\u305F\u308A\u3059\u308B\u3068\u3082\u3046\u306D\u2026",
  "id" : 362166587748384768,
  "in_reply_to_status_id" : 362166196839256065,
  "created_at" : "2013-07-30 11:03:37 +0000",
  "in_reply_to_screen_name" : "_ca76",
  "in_reply_to_user_id_str" : "118355311",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306D\u3080\u308ABABEL",
      "screen_name" : "CKPOMHOCTb",
      "indices" : [ 0, 11 ],
      "id_str" : "190136474",
      "id" : 190136474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362165564837330944",
  "geo" : { },
  "id_str" : "362166281039904768",
  "in_reply_to_user_id" : 190136474,
  "text" : "@CKPOMHOCTb \u3044\u3084\u50D5\u3068\u3066\u6839\u3063\u304B\u3089\u306E\u307C\u3063\u3061\u3068\u3044\u3046\u308F\u3051\u3067\u306F\u306A\u3044\u306E\u3067\u3059[\u3080\u3057\u308D\u304A\u558B\u308A\u306F\u597D\u304D\u3067\u3059]\u304C,\u6388\u696D\u4E2D\u306B\u8A00\u308F\u308C\u3066\u3061\u3087\u3063\u3068\u60B2\u3057\u304B\u3063\u305F\u3053\u3068\u304C\u3042\u3063\u305F\u308A\u3059\u308B\u306E\u3067\u3059.",
  "id" : 362166281039904768,
  "in_reply_to_status_id" : 362165564837330944,
  "created_at" : "2013-07-30 11:02:24 +0000",
  "in_reply_to_screen_name" : "CKPOMHOCTb",
  "in_reply_to_user_id_str" : "190136474",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jellyman5009",
      "screen_name" : "jellyman5009",
      "indices" : [ 0, 13 ],
      "id_str" : "2595829088",
      "id" : 2595829088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362165342123999234",
  "geo" : { },
  "id_str" : "362165676175147009",
  "in_reply_to_user_id" : 118355311,
  "text" : "@jellyman5009 \u50D5\u306F\u77E5\u308A\u5408\u3044\u304C\u3044\u306A\u3044\u8B1B\u7FA9\u3067\u3053\u3046\u8A00\u3046\u3053\u3068\u8A00\u308F\u308C\u308B\u3068\u8F9B\u304B\u3063\u305F\u3051\u3069\u306A\u3041\u2026[\u53CB\u4EBA\u306F\u3082\u3061\u308D\u3093\u3044\u307E\u3059\u304C]",
  "id" : 362165676175147009,
  "in_reply_to_status_id" : 362165342123999234,
  "created_at" : "2013-07-30 11:00:00 +0000",
  "in_reply_to_screen_name" : "_ca76",
  "in_reply_to_user_id_str" : "118355311",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362165113941262337",
  "text" : "\u5B9F\u969B\u30E0\u30B9\u30AB\u306F\u4E8C\u4EBA\u7D44\u304C\u4F5C\u308C\u306A\u304F\u3066\u7206\u767A\u56DB\u6563\u3057\u305F\u308F\u3051\u3060\u3057",
  "id" : 362165113941262337,
  "created_at" : "2013-07-30 10:57:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362165003576545280",
  "text" : "\u300C2\u4EBA\u7D44\u4F5C\u3063\u3066\u30FC\u300D\u3068\u304B\u6EC5\u3073\u306E\u546A\u6587",
  "id" : 362165003576545280,
  "created_at" : "2013-07-30 10:57:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jellyman5009",
      "screen_name" : "jellyman5009",
      "indices" : [ 0, 13 ],
      "id_str" : "2595829088",
      "id" : 2595829088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362164611971166210",
  "geo" : { },
  "id_str" : "362164857228890112",
  "in_reply_to_user_id" : 118355311,
  "text" : "@jellyman5009 \u6559\u5BA4\u306E8\u5272\u306E\u751F\u5F92\u304C\u30A2\u30A4\u30A8\u30A8\u30A8\uFF01\uFF01\u3068\u53EB\u3093\u3067\u5931\u795E\u3059\u308B\u898B\u8FBC\u307F",
  "id" : 362164857228890112,
  "in_reply_to_status_id" : 362164611971166210,
  "created_at" : "2013-07-30 10:56:45 +0000",
  "in_reply_to_screen_name" : "_ca76",
  "in_reply_to_user_id_str" : "118355311",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362164094016569344",
  "text" : "\u304A\u4E92\u3044\u306B\"\u30B3\u30A4\u30C4\u53CB\u9054\u306E\u4F5C\u308A\u65B9\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u5974\u306A\u3093\u3060\u3088\u306A\u30FC\"\u3068\u304B\u601D\u3044\u3042\u3046\u306E\u6BBA\u4F10",
  "id" : 362164094016569344,
  "created_at" : "2013-07-30 10:53:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jellyman5009",
      "screen_name" : "jellyman5009",
      "indices" : [ 0, 13 ],
      "id_str" : "2595829088",
      "id" : 2595829088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362163710023827456",
  "geo" : { },
  "id_str" : "362163935836778496",
  "in_reply_to_user_id" : 118355311,
  "text" : "@jellyman5009 \u53CB\u9054\u306E\u4F5C\u308A\u65B9\u5165\u9580\u3001\u3068\u8A00\u3046\u8B1B\u7FA9\u306E\u6BBA\u4F10\u5177\u5408\u9762\u767D\u305D\u3046",
  "id" : 362163935836778496,
  "in_reply_to_status_id" : 362163710023827456,
  "created_at" : "2013-07-30 10:53:05 +0000",
  "in_reply_to_screen_name" : "_ca76",
  "in_reply_to_user_id_str" : "118355311",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362163369924493312",
  "text" : "\u54C1\u683C\u306F\u8150\u308B\u7A0B\u3042\u3063\u305F\u305F\u3081\u306B\u8150\u3063\u3066\u3057\u307E\u3063\u305F\u4EBA\u306E\u8A71",
  "id" : 362163369924493312,
  "created_at" : "2013-07-30 10:50:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362163058761674754",
  "text" : "\u3053\u3093\u306B\u3061\u308F,\u70CF\u9F8D\u8336\u30E4\u30AF\u30B6\u3067\u3059.",
  "id" : 362163058761674754,
  "created_at" : "2013-07-30 10:49:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362144818958307328",
  "text" : "\u3042\u30FC\u3057\u30FC\u305F\u3092\u30FC\u306E\u307C\u30FC\u3063\u3066\u305D\u30FC\u3089\u30FC\u306B\u3061\u3083\u3061\u3083\u3061\u3083\u3061\u3083\u3061\u3083\u30FC",
  "id" : 362144818958307328,
  "created_at" : "2013-07-30 09:37:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362130038201647104",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u3068\u30C9\u30FC\u30CA\u30C4\u3067\u80C3\u3082\u305F\u308C\u3048\u3048\u3047\u3047\u3047",
  "id" : 362130038201647104,
  "created_at" : "2013-07-30 08:38:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362123771978588160",
  "text" : "\u3075\u3089\u3063\u3068\u672C\u5C4B\u306B\u5BC4\u3063\u305F\u3089\u60B2\u60E8\u4F1D\u51FA\u3066\u308B\u3058\u3083\u3093\uFF1F\u8CB7\u3046\u3058\u3083\u3093\uFF1F\u8AAD\u3080\u3058\u3083\u3093\uFF1F17\u6642\u307E\u308F\u3063\u3066\u308B\u3058\u3083\u3093\uFF1F",
  "id" : 362123771978588160,
  "created_at" : "2013-07-30 08:13:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361825478014803970",
  "geo" : { },
  "id_str" : "361825638375620610",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u305F\u3057\u304B\u306B",
  "id" : 361825638375620610,
  "in_reply_to_status_id" : 361825478014803970,
  "created_at" : "2013-07-29 12:28:49 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361824216674353154",
  "text" : "\u306E\u3057",
  "id" : 361824216674353154,
  "created_at" : "2013-07-29 12:23:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361824117323857923",
  "text" : "\u3093\u30FC\u3001\u8A66\u9A13\u524D\u306ETL\u306F\u72EC\u7279\u306E\u96F0\u56F2\u6C17\u304C\u3042\u308B",
  "id" : 361824117323857923,
  "created_at" : "2013-07-29 12:22:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361817038911586304",
  "geo" : { },
  "id_str" : "361819409548972032",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u305D\u306E\u767A\u60F3\"\"\"\u30E4\u30D0\u3044\"\"\"",
  "id" : 361819409548972032,
  "in_reply_to_status_id" : 361817038911586304,
  "created_at" : "2013-07-29 12:04:04 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361817431783641089",
  "text" : "\u982D\u304A\u304B\u3057\u3044\u2026",
  "id" : 361817431783641089,
  "created_at" : "2013-07-29 11:56:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 3, 12 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 14, 24 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361817407049830400",
  "text" : "RT @d_adagio: @end313124 \u4E00\u77AC\u300C\u3055\u3044\u300D\u3068\u300C\u3046\u3061\u308F\u300D\u304C\u7D50\u5A5A\u3057\u305F\u306E\u304B\u3068",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "361806418875129856",
    "geo" : { },
    "id_str" : "361817038911586304",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u4E00\u77AC\u300C\u3055\u3044\u300D\u3068\u300C\u3046\u3061\u308F\u300D\u304C\u7D50\u5A5A\u3057\u305F\u306E\u304B\u3068",
    "id" : 361817038911586304,
    "in_reply_to_status_id" : 361806418875129856,
    "created_at" : "2013-07-29 11:54:38 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "protected" : false,
      "id_str" : "1290456272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3416914088\/63eeb5ef4882f75f0de18db51d8205d0_normal.jpeg",
      "id" : 1290456272,
      "verified" : false
    }
  },
  "id" : 361817407049830400,
  "created_at" : "2013-07-29 11:56:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361811135290277888",
  "text" : "\u9806\u5E8F\u306F\u9006\u3060\u3063\u305F\u304C\u307E\u3064\u3089\u3044\u3055\u3093\u306E\u3053\u3068\u3092\u8003\u3048\u305A\u306B\u306F\u3044\u3089\u308C\u306A\u304B\u3063\u305F\u306A\uFF1F",
  "id" : 361811135290277888,
  "created_at" : "2013-07-29 11:31:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8056\u4E0AP",
      "screen_name" : "seijoup",
      "indices" : [ 3, 11 ],
      "id_str" : "175069714",
      "id" : 175069714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361810993703157760",
  "text" : "RT @seijoup: \u658E\u85E4\u5343\u548C\u3055\u3093\u304C\u7D50\u5A5A\u3068\u3044\u3046\u30CB\u30E5\u30FC\u30B9\u3092\u77E5\u3063\u3066\u3001\u795D\u798F\u3088\u308A\u5148\u306B\u677E\u6765\u672A\u7950\u3055\u3093\u306E\u3053\u3068\u3092\u8003\u3048\u305F\u5974\u3001\u6B63\u5EA7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361806621841690624",
    "text" : "\u658E\u85E4\u5343\u548C\u3055\u3093\u304C\u7D50\u5A5A\u3068\u3044\u3046\u30CB\u30E5\u30FC\u30B9\u3092\u77E5\u3063\u3066\u3001\u795D\u798F\u3088\u308A\u5148\u306B\u677E\u6765\u672A\u7950\u3055\u3093\u306E\u3053\u3068\u3092\u8003\u3048\u305F\u5974\u3001\u6B63\u5EA7",
    "id" : 361806621841690624,
    "created_at" : "2013-07-29 11:13:15 +0000",
    "user" : {
      "name" : "\u8056\u4E0AP",
      "screen_name" : "seijoup",
      "protected" : false,
      "id_str" : "175069714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451374078251638784\/Oy1icxE4_normal.jpeg",
      "id" : 175069714,
      "verified" : false
    }
  },
  "id" : 361810993703157760,
  "created_at" : "2013-07-29 11:30:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361809327088087040",
  "text" : "\u3057\u3093\u305F\u3059\u306F\u4E00\u4EBA\u3067\u5E78\u305B\u305D\u3046\u306A\u5370\u8C61\u3042\u308B[\u5931\u793C]",
  "id" : 361809327088087040,
  "created_at" : "2013-07-29 11:24:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361808675100303360",
  "text" : "\u8584\u3044\u306E\u3092\u7126\u3052\u308B\u624B\u524D\u307E\u3067\u30AB\u30EA\u30AB\u30EA\u306B\u3059\u308B\u306E\u304C\u597D\u304D",
  "id" : 361808675100303360,
  "created_at" : "2013-07-29 11:21:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361808586118135809",
  "text" : "\u98DF\u30D1\u30F3\u3092\u30AB\u30EA\u30AB\u30EA\u306B\u713C\u3044\u3066\u308B.\u30AB\u30EA\u30AB\u30EA.",
  "id" : 361808586118135809,
  "created_at" : "2013-07-29 11:21:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 3, 15 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361808402701221888",
  "text" : "RT @hymathlogic: \u30A6\u30A4\u30EB\u30B9\u3092\u30F4\u30A1\u30A4\u30E9\u30B9\u3068\u3044\u3046\u306E\u5358\u306A\u308B\u82F1\u8A9E\u304B\u3076\u308C\u3060\u3057\n\u3082\u3068\u3082\u3068\u30E9\u30C6\u30F3\u8A9E\u306A\u308F\u3051\u3067\n\u30A6\u30A4\u30EB\u30B9\u3068\u3044\u3046\u65B9\u304C\u539F\u8A9E\u306B\u8FD1\u3044\u3057\n\u3069\u3063\u3061\u306B\u3057\u308D\u767A\u97F3\u305F\u3044\u3057\u3066\u4F3C\u3066\u306A\u3044\u306E\u3067\u30A2\u30EC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361807838437322753",
    "text" : "\u30A6\u30A4\u30EB\u30B9\u3092\u30F4\u30A1\u30A4\u30E9\u30B9\u3068\u3044\u3046\u306E\u5358\u306A\u308B\u82F1\u8A9E\u304B\u3076\u308C\u3060\u3057\n\u3082\u3068\u3082\u3068\u30E9\u30C6\u30F3\u8A9E\u306A\u308F\u3051\u3067\n\u30A6\u30A4\u30EB\u30B9\u3068\u3044\u3046\u65B9\u304C\u539F\u8A9E\u306B\u8FD1\u3044\u3057\n\u3069\u3063\u3061\u306B\u3057\u308D\u767A\u97F3\u305F\u3044\u3057\u3066\u4F3C\u3066\u306A\u3044\u306E\u3067\u30A2\u30EC",
    "id" : 361807838437322753,
    "created_at" : "2013-07-29 11:18:05 +0000",
    "user" : {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "protected" : false,
      "id_str" : "295467216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439420014165106688\/B9GEeIe7_normal.jpeg",
      "id" : 295467216,
      "verified" : false
    }
  },
  "id" : 361808402701221888,
  "created_at" : "2013-07-29 11:20:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u306C\u3069\u308C\u3044.dmng",
      "screen_name" : "inudorei4869",
      "indices" : [ 3, 16 ],
      "id_str" : "401255433",
      "id" : 401255433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361806883222331392",
  "text" : "RT @inudorei4869: \u30A6\u30A4\u30EB\u30B9\u2190\u4E00\u822C\u4EBA\n\u30A6\u30A3\u30EB\u30B9\u2190\u304A\u3057\u3044\n\u30F4\u30A1\u30A4\u30E9\u30B9\u2190\u30DE\u30B8\u308F\u304B\u3063\u3066\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361806828612485120",
    "text" : "\u30A6\u30A4\u30EB\u30B9\u2190\u4E00\u822C\u4EBA\n\u30A6\u30A3\u30EB\u30B9\u2190\u304A\u3057\u3044\n\u30F4\u30A1\u30A4\u30E9\u30B9\u2190\u30DE\u30B8\u308F\u304B\u3063\u3066\u308B",
    "id" : 361806828612485120,
    "created_at" : "2013-07-29 11:14:04 +0000",
    "user" : {
      "name" : "\u3044\u306C\u3069\u308C\u3044.dmng",
      "screen_name" : "inudorei4869",
      "protected" : false,
      "id_str" : "401255433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2414355171\/YA0PAOl6_normal",
      "id" : 401255433,
      "verified" : false
    }
  },
  "id" : 361806883222331392,
  "created_at" : "2013-07-29 11:14:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361806560596475904",
  "text" : "\u4E00\u65B9\u3060\u3061\u3083\u30FC\u3093\u306F\u3053\u3093\u306A\u3093\u2026",
  "id" : 361806560596475904,
  "created_at" : "2013-07-29 11:13:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u539F\u7530\u3072\u3068\u307F\uFF20\uFF14\uFF0F\uFF12\uFF16\u30A2\u30B3\u30E9\u30A4\u30A2\u30EB\u30D0\u30E0\u767A\u58F2",
      "screen_name" : "vhitomin",
      "indices" : [ 3, 12 ],
      "id_str" : "111942305",
      "id" : 111942305
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vhitomin\/status\/361806441184653312\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/0sSSfJofp6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQVlCpSCcAAsOpo.jpg",
      "id_str" : "361806441188847616",
      "id" : 361806441188847616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQVlCpSCcAAsOpo.jpg",
      "sizes" : [ {
        "h" : 427,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/0sSSfJofp6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361806515495116800",
  "text" : "RT @vhitomin: \u5225\u30AB\u30C3\u30C8\u3092\u3002\u73CD\u3057\u304F\u81EA\u4E3B\u898F\u5236\u3092\u5165\u308C\u3066\u307F\u305F\uFF08\u7B11\uFF09\u3002 http:\/\/t.co\/0sSSfJofp6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vhitomin\/status\/361806441184653312\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/0sSSfJofp6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQVlCpSCcAAsOpo.jpg",
        "id_str" : "361806441188847616",
        "id" : 361806441188847616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQVlCpSCcAAsOpo.jpg",
        "sizes" : [ {
          "h" : 427,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/0sSSfJofp6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361806441184653312",
    "text" : "\u5225\u30AB\u30C3\u30C8\u3092\u3002\u73CD\u3057\u304F\u81EA\u4E3B\u898F\u5236\u3092\u5165\u308C\u3066\u307F\u305F\uFF08\u7B11\uFF09\u3002 http:\/\/t.co\/0sSSfJofp6",
    "id" : 361806441184653312,
    "created_at" : "2013-07-29 11:12:32 +0000",
    "user" : {
      "name" : "\u539F\u7530\u3072\u3068\u307F\uFF20\uFF14\uFF0F\uFF12\uFF16\u30A2\u30B3\u30E9\u30A4\u30A2\u30EB\u30D0\u30E0\u767A\u58F2",
      "screen_name" : "vhitomin",
      "protected" : false,
      "id_str" : "111942305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681753316\/Image385_normal.jpg",
      "id" : 111942305,
      "verified" : true
    }
  },
  "id" : 361806515495116800,
  "created_at" : "2013-07-29 11:12:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361806418875129856",
  "text" : "\u3055\u3044\u3068\u3046\u3061\u308F\u7D50\u5A5A\u3057\u305F\u306E\u304B\u30FC",
  "id" : 361806418875129856,
  "created_at" : "2013-07-29 11:12:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u306C\u3069\u308C\u3044.dmng",
      "screen_name" : "inudorei4869",
      "indices" : [ 3, 16 ],
      "id_str" : "401255433",
      "id" : 401255433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361806091622952961",
  "text" : "RT @inudorei4869: \u30F4\u30A1\u30A4\u30E9\u30B9\u3063\u3066\u3044\u3046\u4EBA\u306F\u306F\u3088\u304F\u308F\u304B\u3063\u3066\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361806001621573634",
    "text" : "\u30F4\u30A1\u30A4\u30E9\u30B9\u3063\u3066\u3044\u3046\u4EBA\u306F\u306F\u3088\u304F\u308F\u304B\u3063\u3066\u308B",
    "id" : 361806001621573634,
    "created_at" : "2013-07-29 11:10:47 +0000",
    "user" : {
      "name" : "\u3044\u306C\u3069\u308C\u3044.dmng",
      "screen_name" : "inudorei4869",
      "protected" : false,
      "id_str" : "401255433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2414355171\/YA0PAOl6_normal",
      "id" : 401255433,
      "verified" : false
    }
  },
  "id" : 361806091622952961,
  "created_at" : "2013-07-29 11:11:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361805349747040257",
  "text" : "\u767A\u97F3\u3088\u308A\u30A2\u30AF\u30BB\u30F3\u30C8\u304C\u5927\u4E8B\u306A\u3093\u3060\u3088\uFF01\uFF01\uFF01\uFF01\u3044\u3044\u304B\u3052\u3093\u306B\u3057\u308D\uFF01\uFF01\uFF01\uFF01",
  "id" : 361805349747040257,
  "created_at" : "2013-07-29 11:08:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361805223523647489",
  "text" : "\u767A\u97F3\u306B\u3053\u3060\u308F\u3089\u306A\u3044\u3072\u3068\u300C\u3044\u3093\u3075\u308B\u3048\u3093\u3056\u3046\u3044\u308B\u3059\u300D",
  "id" : 361805223523647489,
  "created_at" : "2013-07-29 11:07:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361804994095222784",
  "text" : "\u4E0D\u826F\u3060\u304B\u3089\u30F4\u30A1\u30A4\u30BF\u30DF\u30F3\u5264\u3092\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u3067\u98F2\u3093\u3060",
  "id" : 361804994095222784,
  "created_at" : "2013-07-29 11:06:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361804627886350336",
  "text" : "\u767A\u97F3\u306B\u62D8\u308B\u4EBA\u300C\u30A4\u30F3\u30D5\u30EB\u30A8\u30F3\u30B6\u30F4\u30A1\u30A4\u30E9\u30B9\u300D",
  "id" : 361804627886350336,
  "created_at" : "2013-07-29 11:05:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361804484453732353",
  "text" : "\u30F4\u30A1\u30A4\u30BF\u30DF\u30F3\u5264\u98F2\u3080\u304B",
  "id" : 361804484453732353,
  "created_at" : "2013-07-29 11:04:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361803408568619009",
  "text" : "\u30B3\u30FC\u30D2\u30FC\u30921L\u8FD1\u304F\u51B7\u3084\u3057\u3066\u308B\u3051\u3069\u3053\u308C\u3069\u3046\u3059\u308B\u3064\u3082\u308A\u306A\u3093\u3060\u308D\u3046",
  "id" : 361803408568619009,
  "created_at" : "2013-07-29 11:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361799685121384449",
  "text" : "\u4ED5\u65B9\u306A\u3044\u306D\u30FC",
  "id" : 361799685121384449,
  "created_at" : "2013-07-29 10:45:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361799665487847424",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\uFF01\uFF01\u30AB\u30BA\u30D5\u30A7\u30B9\u884C\u3051\u306A\u3044\u30A8\u30A8\u30A8\uFF01",
  "id" : 361799665487847424,
  "created_at" : "2013-07-29 10:45:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361761509703041024",
  "text" : "\u8840\u3047\u3047",
  "id" : 361761509703041024,
  "created_at" : "2013-07-29 08:13:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361761350826987521",
  "text" : "\u306A\u305C\u304B\u51B7\u51CD\u5EAB\u306E\u971C\uFF0C\u3068\u3044\u3046\u304B\u6C37\u3092\u7815\u3044\u3066\u3044\u305F\u3089\uFF0C\u3051\u304C\u3057\u3066\u3057\u307E\u3063\u305F\uFF0E\u75DB\u3044\uFF0E",
  "id" : 361761350826987521,
  "created_at" : "2013-07-29 08:13:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361696033115344896",
  "text" : "\u534A\u89D2\u3060\u3068\u306A\u304A\u826F\u3044",
  "id" : 361696033115344896,
  "created_at" : "2013-07-29 03:53:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361695968460156929",
  "text" : "\u30C0\u30A4\u30BF\u30A4wwwwwww\u30AF\u30B5\u30CF\u30E4\u30B7\u30C6wwwwwww\u30AB\u30BF\u30AB\u30CA\u30CB\u30B7\u30C8\u30B1\u30D0wwwww\u30BD\u30EC\u30C3\u30DD\u30A4wwwwww",
  "id" : 361695968460156929,
  "created_at" : "2013-07-29 03:53:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361694038375673856",
  "text" : "\u6700\u8FD1\u306E\u30C8\u30EC\u30F3\u30C9\u306F\u30AA\u30C9\u30B7\u30B7",
  "id" : 361694038375673856,
  "created_at" : "2013-07-29 03:45:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361693930925998081",
  "text" : "\u30DA\u30F3\u306F\u5263\u3088\u308A\u5F37\u3044\u3068\u304B\u30D7\u30EC\u30A4\u30E4\u30FC\u30B9\u30AD\u30EB\u3092\u8003\u616E\u3057\u3066\u306A\u3044\u3088\u306A",
  "id" : 361693930925998081,
  "created_at" : "2013-07-29 03:45:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361693785664663554",
  "text" : "\u30DA\u30F3\u306F\u5263\u3088\u308A\u5F37\u3044\u3089\u3057\u3044\u3057\u79C1\u304C\u5263\u4F7F\u3046\u3057\u30DA\u30F3\u4F7F\u3063\u3066\u3044\u3044\u3088",
  "id" : 361693785664663554,
  "created_at" : "2013-07-29 03:44:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361692719715848193",
  "text" : "\u30A2\u30FC\u30FC\u30FC\u30DE\u30C3\u30BF\u30AF\uFF01\uFF01\uFF01\uFF01\u30A4\u30A4\u30C6\u30F3\u30AD\u30C7\u30B9\u30CD\u30FC\u30FC\u30FC\uFF01\uFF01\uFF01\uFF01",
  "id" : 361692719715848193,
  "created_at" : "2013-07-29 03:40:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 14, 30 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361666295248330753",
  "geo" : { },
  "id_str" : "361666524244742146",
  "in_reply_to_user_id" : 427714784,
  "text" : "@miattermeyer @Jelly_in_a_tank \u304A\u76C6\u3044\u3063\u3071\u3044\u306E\u3072\u3058\u304D\u3092\u30BF\u30C3\u30D1\u30FC\u306B\u8A70\u3081\u66FF\u3048\u3066\u307E\u3057\u305F\u3002\u3053\u308C\u306F\u30DE\u30B8\u3067\u3084\u3070\u3044\u306A\u3001\u3063\u3066\u601D\u3044\u307E\u3057\u305F\u3002",
  "id" : 361666524244742146,
  "in_reply_to_status_id" : 361666295248330753,
  "created_at" : "2013-07-29 01:56:33 +0000",
  "in_reply_to_screen_name" : "miantomori",
  "in_reply_to_user_id_str" : "427714784",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361666128218570754",
  "text" : "\u3042\u308C\u306F\u7570\u69D8\u306A\u5149\u666F\u3067\u3042\u3063\u305F",
  "id" : 361666128218570754,
  "created_at" : "2013-07-29 01:54:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361456060550230018",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 361456060550230018,
  "created_at" : "2013-07-28 12:00:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361406686231142400",
  "text" : "\u30DC\u30AB\u30ED(\u7279\u306B\u30AB\u30B2\u30D7\u30ED)\u3001\u6771\u65B9\u3042\u305F\u308A\u306F\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u4E2D\u6838\u3067\u306A\u3044\u90E8\u5206\u3067\u6B8B\u5FF5\u306A\u5370\u8C61\u304C\u5F37\u3044",
  "id" : 361406686231142400,
  "created_at" : "2013-07-28 08:44:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361247131568312320",
  "text" : "\u8A08\u7B97\u7528\u7D19\u306E\u4F7F\u3044\u65B9\u304C\u96D1\u306A\u306E\u306F\u3042\u308B\u3051\u3069A4\u306E\u7247\u976250\u679A\u8FD1\u304F\u4F7F\u3046\u3063\u3066\u3069\u3046\u3088(\u7121\u99C4\u7D19\u3067\u3059\u304C)",
  "id" : 361247131568312320,
  "created_at" : "2013-07-27 22:10:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361246449524154372",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u7D42\u308F\u3063\u3066\u304B\u3089\u306E\u65B9\u304C\u52C9\u5F37\u3057\u3066\u308B\u306A\uFF1F\uFF1F",
  "id" : 361246449524154372,
  "created_at" : "2013-07-27 22:07:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361246238416441344",
  "text" : "\u307E\u3068\u3081\uFF01\u30B8\u30E7\u30EB\u30C0\u30F3\u6A19\u6E96\u5F62\u306F\u3068\u3066\u3082\u74B0\u5883\u306B\u60AA\u3044\uFF01",
  "id" : 361246238416441344,
  "created_at" : "2013-07-27 22:06:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361238957289246721",
  "text" : "@kotorin_phoenix \u305D\u3053\u306E\u30B3\u30F3\u30D3\u30CB\u3067\u30DD\u30C6\u30C8\u304C\u534A\u984D\u3060\u3063\u305F\u306E\u3067\u884C\u304D\u307E\u3057\u3087\u3046\uFF01\uFF01",
  "id" : 361238957289246721,
  "created_at" : "2013-07-27 21:37:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361238498583388162",
  "text" : "\u3067\u3082\u3001\u3053\u306E\u30BB\u30DF\u3001\u3060\u3044\u3076\u9CF4\u3044\u3066\u3044\u307E\u3059",
  "id" : 361238498583388162,
  "created_at" : "2013-07-27 21:35:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361238413543866368",
  "text" : "\u4ECA\u65E5\u306F\u2026\u8749\u304C\u9A12\u304C\u3057\u3044\u306A\u2026",
  "id" : 361238413543866368,
  "created_at" : "2013-07-27 21:35:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361226394048544769",
  "text" : "\u5973\u306E\u5B50\u3068\u306F\u306A\u3093\u306A\u306E\u304B\u8003\u3048\u3055\u305B\u3089\u308C\u308B\u8CAC\u3081\u82E6\u306B\u906D\u3063\u3066\u308B\u754C\u9688",
  "id" : 361226394048544769,
  "created_at" : "2013-07-27 20:47:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361222370058440704",
  "text" : "\u30B8\u30E7\u30EB\u30C0\u30F3\u6A19\u6E96\u5F62\u306F\u74B0\u5883\u306B\u826F\u304F\u306A\u3044\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 361222370058440704,
  "created_at" : "2013-07-27 20:31:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361222317357015043",
  "text" : "\u5168\u4EBA\u985E\u304C\u4E00\u6589\u306B\u30B8\u30E7\u30EB\u30C0\u30F3\u6A19\u6E96\u5F62\u3092\u6C42\u3081\u305F\u3089\u3001\u51C4\u3044\u65E9\u3055\u3067\u5730\u7403\u304B\u3089\u7D19\u8CC7\u6E90\u304C\u67AF\u6E07\u3059\u308B\u3001\u6C17\u304C\u3059\u308B",
  "id" : 361222317357015043,
  "created_at" : "2013-07-27 20:31:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361201144187469825",
  "text" : "\u3082\u30464\u3058\u307E\u308F\u3063\u3066\u3093\u306E\u304B\u3088\u3046",
  "id" : 361201144187469825,
  "created_at" : "2013-07-27 19:07:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361200323408302080",
  "text" : "\u30BB\u30F3\u30C8\u30D3\u30F3\u30BB\u30F3\u30C8\u53CA\u3073\u30B0\u30EC\u30CA\u30C7\u30A3\u30FC\u30F3\u8AF8\u5CF6",
  "id" : 361200323408302080,
  "created_at" : "2013-07-27 19:04:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361093689281478656",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 361093689281478656,
  "created_at" : "2013-07-27 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361075471489839104",
  "geo" : { },
  "id_str" : "361090864564551680",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u3093\u30FC\u3001\u95A2\u308F\u3063\u3066\u305D\u3046\u306A\u53CB\u4EBA\u306A\u3089\u4E00\u4EBA",
  "id" : 361090864564551680,
  "in_reply_to_status_id" : 361075471489839104,
  "created_at" : "2013-07-27 11:49:05 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361065795356340224",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 361065795356340224,
  "created_at" : "2013-07-27 10:09:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361063787975024640",
  "text" : "\u4E16\u754C\u306A\u3093\u3068\u304B\u30DD\u30A8\u306A\u3093\u3068\u304B\u6C0F\u3001\u9999\u3070\u3057\u3055\u3092\u307E\u3060\u4FDD\u3063\u3066\u3066\u606F\u304C\u9577\u3044",
  "id" : 361063787975024640,
  "created_at" : "2013-07-27 10:01:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/360833862990970881\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/eGJKHGJBVN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQHwfJLCQAEVHfw.jpg",
      "id_str" : "360833862995165185",
      "id" : 360833862995165185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQHwfJLCQAEVHfw.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/eGJKHGJBVN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360833862990970881",
  "text" : "\u3082\u3046\u306D\u3088\u3046\uFF01 http:\/\/t.co\/eGJKHGJBVN",
  "id" : 360833862990970881,
  "created_at" : "2013-07-26 18:47:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/360812934601003008\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/iFethBg768",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQHdc83CUAAPsrK.jpg",
      "id_str" : "360812934609391616",
      "id" : 360812934609391616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQHdc83CUAAPsrK.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/iFethBg768"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360784756390117378",
  "geo" : { },
  "id_str" : "360812934601003008",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u3064 http:\/\/t.co\/iFethBg768",
  "id" : 360812934601003008,
  "in_reply_to_status_id" : 360784756390117378,
  "created_at" : "2013-07-26 17:24:41 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360694435069177856",
  "text" : "\u3086\u308B\u3075\u308F\u306A\u5973\u306E\u5B50\u307F\u305F\u3044\u3068\u8A00\u308F\u308C\u305F\u304C\u305D\u3046\u898B\u3048\u308B\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 360694435069177856,
  "created_at" : "2013-07-26 09:33:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7vOYRNIpGD",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360549420103778306",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/7vOYRNIpGD",
  "id" : 360549420103778306,
  "created_at" : "2013-07-25 23:57:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360467887049277440",
  "text" : "\u9811\u5F35\u3063\u3066\u5BDD\u308B\u304A\u3084\u3059\u307F",
  "id" : 360467887049277440,
  "created_at" : "2013-07-25 18:33:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360466790826000385",
  "text" : "\uFF1F",
  "id" : 360466790826000385,
  "created_at" : "2013-07-25 18:29:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360466772975026176",
  "text" : "\u51FA\u308B\u676D\u3082\u9CF4\u304B\u305A\u3070\u3046\u305F\u308C\u307E\u3044",
  "id" : 360466772975026176,
  "created_at" : "2013-07-25 18:29:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360466364886024192",
  "text" : "\u53D6\u308A\u6191\u304F\u5CF6:\u30DB\u30E9\u30FC\u6620\u753B",
  "id" : 360466364886024192,
  "created_at" : "2013-07-25 18:27:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360466253703421952",
  "text" : "\u30BB\u30DF\u3060\u3082\u3093\u306D\u3001\u4ED5\u65B9\u306A\u3044\u306D",
  "id" : 360466253703421952,
  "created_at" : "2013-07-25 18:27:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360466199139729409",
  "text" : "\u30C4\u30AF\u30C4\u30AF\u30DC\u30A6\u30B7\u3064\u304F\u3065\u304F\u5E3D\u5B50\u4F3C\u5408\u308F\u306A\u3044\u306A(^^)(^^)(^^)",
  "id" : 360466199139729409,
  "created_at" : "2013-07-25 18:26:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360465589761871872",
  "text" : "\u610F\u5473\u4E0D\u660E\u3067\u3042\u308B\u3053\u3068\u3068\u304B\u7406\u4E0D\u5C3D\u3067\u3042\u308B\u3053\u3068\u306F\u9762\u767D\u3044\u306A\u3041\u3041\u3049\u3041\u3041\u3041\u304A",
  "id" : 360465589761871872,
  "created_at" : "2013-07-25 18:24:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360464790801481728",
  "text" : "\u62B1\u304D\u6795\u6C0F\u6BCE\u6669\u62B1\u3044\u3066\u308B\u306E\u306B\u62B1\u304D\u8FD4\u3057\u3066\u3053\u306A\u3044[\u62B1\u304B\u308C\u307E\u304F\u3089\u306A\u308B\u3082\u306E\u3082\u5B58\u5728\u3059\u308B\u3089\u3057\u3044\u3067\u3059\u304C]",
  "id" : 360464790801481728,
  "created_at" : "2013-07-25 18:21:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360464386218926081",
  "text" : "\u30E9\u30A4\u30D5\u30EF\u30FC\u30AF\u3068\u3057\u3066\u3042\u307E\u308A\u306B\u30A2\u30EC\u3060\u306A",
  "id" : 360464386218926081,
  "created_at" : "2013-07-25 18:19:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360464302471266306",
  "text" : "\u30C1\u30CD\u30E9\u30B9\u30AB\u5DDE\u307F\u305F\u3044\u306A\u30CE\u30EA\u3067\u4E16\u754C\u5730\u56F3\u306B\u305D\u308C\u3063\u307D\u3044\u30C7\u30BF\u30E9\u30E1\u306A\u5730\u540D\u3064\u3051\u308B\u904A\u3073\u751F\u6DAF\u304B\u3051\u3066\u3084\u308A\u305F\u3044",
  "id" : 360464302471266306,
  "created_at" : "2013-07-25 18:19:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360463799083483136",
  "text" : "\u30C4\u30AF\u30B7\u30C4\u30AF\u30B9:\u53E4\u4EE3\u30AE\u30EA\u30B7\u30E3\u306E\u90FD\u5E02\u3001\u6587\u732E\u306B\u306F\u6B8B\u3063\u3066\u3044\u308B\u304C\u6240\u5728\u5730\u306F\u73FE\u5728\u3082\u4E0D\u660E",
  "id" : 360463799083483136,
  "created_at" : "2013-07-25 18:17:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360463561560031232",
  "text" : "\u5C3D\u304F\u3057\u5C3D\u304F\u3059-\u30C4\u30AF\u30B7\u30C4\u30AF\u30B9-",
  "id" : 360463561560031232,
  "created_at" : "2013-07-25 18:16:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360463427552022528",
  "text" : "hogehoge\u3057\u5C3D\u304F\u3059\u3063\u3066\u3084\u305F\u3089\u4F7F\u3046\u3068\u9762\u767D\u3044\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 360463427552022528,
  "created_at" : "2013-07-25 18:15:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360462731909926912",
  "text" : "\u6614\u307B\u3069\u8AAD\u66F8\u3057\u306A\u304F\u306A\u3063\u305F\u306A[\u5C0F\u8AAC]",
  "id" : 360462731909926912,
  "created_at" : "2013-07-25 18:13:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360462498404642816",
  "geo" : { },
  "id_str" : "360462628738433024",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 fmfm \u8AB0\u304B\u306E\u304A\u5BB6\u306E\u672C\u68DA\u3067\u898B\u305F\u3089\u8AAD\u3093\u3067\u307F\u307E\u3059[\u8CB7\u3046\u6C17\u306F\u306A\u3057]",
  "id" : 360462628738433024,
  "in_reply_to_status_id" : 360462498404642816,
  "created_at" : "2013-07-25 18:12:42 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360462454767095809",
  "text" : "\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u98F2\u3093\u3060\u306E\u306F\u5931\u6557\u3060\u3063\u305F\u306A\uFF1F\u7720\u304F\u306A\u3044\u306A\uFF1F",
  "id" : 360462454767095809,
  "created_at" : "2013-07-25 18:12:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360462113279447041",
  "text" : "\u86C7\u8DB3\u3092\u3064\u3051\u5C3D\u304F\u3059\u3068\u86C7\u767E\u8DB3\u306B\u306A\u3063\u3066\u6C17\u6301\u3061\u60AA\u3044",
  "id" : 360462113279447041,
  "created_at" : "2013-07-25 18:10:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360461568791683073",
  "geo" : { },
  "id_str" : "360461942009237505",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u306A\u308B\u307B\u3069\u3001\u305F\u3057\u304B\u306B\u82E5\u3044\u4EBA\u304C\u66F8\u304D\u305D\u3046\u306A\u611F\u3058\u3067\u3059\u306D\u3047[\u306A\u304A\u30D7\u30E9\u30B9\u3067\u3082\u30DE\u30A4\u30CA\u30B9\u3067\u3082\u306A\u3044\u8A55\u4FA1\u3067\u3059]",
  "id" : 360461942009237505,
  "in_reply_to_status_id" : 360461568791683073,
  "created_at" : "2013-07-25 18:09:58 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360461572113575938",
  "text" : "\u86C7\u767E\u8DB3",
  "id" : 360461572113575938,
  "created_at" : "2013-07-25 18:08:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 14, 30 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360461490945392640",
  "text" : "\u3042\u3068\u30B0\u30FC\u5168\u632F\u308A\u3067\u6709\u540D RT @Jelly_in_a_tank: \u5973\u306E\u5B50\u304C\u597D\u304D\u3067\u53EF\u611B\u3044\u5973\u306E\u5B50\u306B\u306F\u3068\u3053\u3068\u3093\u7518\u304F\u3066\u512A\u3057\u3044\u3053\u3068\u3067\u6709\u540D\u306A\u30BC\u30EA\u30FC\u3055\u3093\u306F\u7D76\u8CDB\u604B\u4EBA\u52DF\u96C6\u4E2D\u3067\u3059",
  "id" : 360461490945392640,
  "created_at" : "2013-07-25 18:08:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360461274330566656",
  "text" : "\u5973\u5B50\u5927\u751F\u304C\u56DE\u3057\u8E74\u308A\u3059\u308B\u8A71\u304B\u3089\u30B7\u30FC\u30E0\u30EC\u30B9\u306B\u8E74\u308A\u305F\u3044\u80CC\u4E2D\u306E\u8A71\u306B\u79FB\u884C\u3059\u308B\u754C\u9688",
  "id" : 360461274330566656,
  "created_at" : "2013-07-25 18:07:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360460824348856320",
  "geo" : { },
  "id_str" : "360461009066008576",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3069\u3093\u306A\u8A71\u306A\u3093\u3067\u3059\uFF1F[\u3042\u3089\u3059\u3058]",
  "id" : 360461009066008576,
  "in_reply_to_status_id" : 360460824348856320,
  "created_at" : "2013-07-25 18:06:16 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JinS",
      "screen_name" : "Jin0172",
      "indices" : [ 0, 8 ],
      "id_str" : "95801744",
      "id" : 95801744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360460404838760449",
  "geo" : { },
  "id_str" : "360460905982595072",
  "in_reply_to_user_id" : 95801744,
  "text" : "@Jin0172 \u305D\u3046\u304B\u3082\u3057\u308C\u306A\u3044\u304D\u3063\u3068\u305D\u3046\u3060",
  "id" : 360460905982595072,
  "in_reply_to_status_id" : 360460404838760449,
  "created_at" : "2013-07-25 18:05:51 +0000",
  "in_reply_to_screen_name" : "Jin0172",
  "in_reply_to_user_id_str" : "95801744",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360460143164538880",
  "text" : "\u8E74\u308B\u306E\u3082\u8E74\u3089\u308C\u308B\u306E\u3082\u3044\u3084\u3067\u3059\u3088\u3046",
  "id" : 360460143164538880,
  "created_at" : "2013-07-25 18:02:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360459792428441600",
  "text" : "\u305D\u3093\u306A\u306E\u4EBA\u306E\u304B\u3063\u3066",
  "id" : 360459792428441600,
  "created_at" : "2013-07-25 18:01:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360459766360834050",
  "text" : "\u8E74\u308A\u305F\u304F\u306A\u3044\u80CC\u4E2D",
  "id" : 360459766360834050,
  "created_at" : "2013-07-25 18:01:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360459717081956353",
  "text" : "\u8E74\u308A\u305F\u3044\u80CC\u4E2D",
  "id" : 360459717081956353,
  "created_at" : "2013-07-25 18:01:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360459566951055361",
  "geo" : { },
  "id_str" : "360459636786204674",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows @umichoco11 \u3069\u3046\u305E(\u771F\u9854)",
  "id" : 360459636786204674,
  "in_reply_to_status_id" : 360459566951055361,
  "created_at" : "2013-07-25 18:00:49 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360459493148069888",
  "geo" : { },
  "id_str" : "360459549146230784",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3044\u3044\u305F\u3044\u3060\u3051\u3058\u3083\u3093\u304B\uFF1F",
  "id" : 360459549146230784,
  "in_reply_to_status_id" : 360459493148069888,
  "created_at" : "2013-07-25 18:00:28 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360459306052755456",
  "text" : "TL\u3067\u5973\u5B50\u5927\u5B66\u751F\u304C\u56DE\u3057\u8E74\u308A\u3092\u3059\u308B\u4E88\u7D04\u3092\u53D6\u3089\u308C\u3066\u3044\u3066\u30E4\u30D0\u3044\u4E16\u754C\u3060",
  "id" : 360459306052755456,
  "created_at" : "2013-07-25 17:59:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360458492382953472",
  "geo" : { },
  "id_str" : "360459044143632384",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u4E00\u4E07(\u3082\u3089\u3063\u3066)\u304F\u308C\u30FC\u3060\u306A\u3093\u3066\u305D\u3093\u306A\u60AA\u3044\u3067\u3059\u3088\u306E\u3046\u3053\u3055\u3093",
  "id" : 360459044143632384,
  "in_reply_to_status_id" : 360458492382953472,
  "created_at" : "2013-07-25 17:58:27 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keigo Ishida",
      "screen_name" : "shombory",
      "indices" : [ 0, 9 ],
      "id_str" : "211441184",
      "id" : 211441184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360458065616703489",
  "geo" : { },
  "id_str" : "360458835472822273",
  "in_reply_to_user_id" : 211441184,
  "text" : "@shombory \u4EBA\u6570\u306B\u3082\u4F9D\u308B\u3093\u3060\u308D\u3046\u3051\u3069\u3042\u308B\u7A0B\u5EA6\u51FA\u6765\u30EC\u30FC\u30B9\u306A\u3068\u3053\u3042\u308B\u3089\u3057\u3044\u3051\u3069\u306A\u30FC[\u5185\u90E8\u3067\u6587\u5B66\u90E8\u3067\u4EBA\u5C11\u306A\u3044\u3068\u306A]",
  "id" : 360458835472822273,
  "in_reply_to_status_id" : 360458065616703489,
  "created_at" : "2013-07-25 17:57:38 +0000",
  "in_reply_to_screen_name" : "shombory",
  "in_reply_to_user_id_str" : "211441184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360458163356581889",
  "geo" : { },
  "id_str" : "360458392491401216",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u3044\u305A\u308C\u306B\u3057\u3066\u3082\u5927\u4E08\u592B\u3067\u3059\u3088\u30FC\u30FC\u304A\u6C17\u306B\u306A\u3055\u3089\u305A\u30FC\u30FC\u30FC",
  "id" : 360458392491401216,
  "in_reply_to_status_id" : 360458163356581889,
  "created_at" : "2013-07-25 17:55:52 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360458246508654594",
  "text" : "\u30BC\u30EA\u30FC\u3055\u3093\u30B0\u30FC\u5168\u632F\u308A\u3060\u304B\u3089\u3058\u3083\u3093\u3051\u3093\u3067\u52DD\u8CA0\u3067\u304D\u306A\u304F\u3066\u4E0D\u4FBF\u3060\u3057\u3084\u3081\u3066\u307B\u3057\u3044",
  "id" : 360458246508654594,
  "created_at" : "2013-07-25 17:55:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360457420247547905",
  "geo" : { },
  "id_str" : "360458012500045824",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u55AB\u8336\u5E97\u306E\u4F1A\u8A08\u306E\u6642\u306B\u307E\u3068\u3081\u305F\u3088\u306A\u8A18\u61B6\u3082",
  "id" : 360458012500045824,
  "in_reply_to_status_id" : 360457420247547905,
  "created_at" : "2013-07-25 17:54:21 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360457136171515905",
  "geo" : { },
  "id_str" : "360457334222368769",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \uFF1F\uFF1F\uFF1F\uFF1F\u8FD4\u3057\u3066\u3082\u3089\u3063\u305F\u3088\u3046\u306A\u8A18\u61B6\u304C\u3042\u308A\u307E\u3059\u3051\u3069\u3042\u308C\uFF1F",
  "id" : 360457334222368769,
  "in_reply_to_status_id" : 360457136171515905,
  "created_at" : "2013-07-25 17:51:40 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keigo Ishida",
      "screen_name" : "shombory",
      "indices" : [ 0, 9 ],
      "id_str" : "211441184",
      "id" : 211441184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360456989396041730",
  "geo" : { },
  "id_str" : "360457210519748608",
  "in_reply_to_user_id" : 211441184,
  "text" : "@shombory \u4E8C\u6708\u524D\u5F8C\u3060\u3068\u601D\u3046\u3088\u30FC[\u6587\u5B66\u90E8\u3068\u306F\u8A00\u3063\u3066\u306A\u3044]",
  "id" : 360457210519748608,
  "in_reply_to_status_id" : 360456989396041730,
  "created_at" : "2013-07-25 17:51:10 +0000",
  "in_reply_to_screen_name" : "shombory",
  "in_reply_to_user_id_str" : "211441184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360456959314505728",
  "text" : "\u54C1\u683C\u306EH",
  "id" : 360456959314505728,
  "created_at" : "2013-07-25 17:50:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360456598008774656",
  "text" : "\u304A\u3086\u306F\u309317\uFF1A57\u5206\u306B\u98DF\u3079\u7D42\u3048\u305F\u306E\u3067\u304A\u8179\u6E1B\u3063\u3066\u304D\u305F",
  "id" : 360456598008774656,
  "created_at" : "2013-07-25 17:48:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keigo Ishida",
      "screen_name" : "shombory",
      "indices" : [ 0, 9 ],
      "id_str" : "211441184",
      "id" : 211441184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360456166901420034",
  "geo" : { },
  "id_str" : "360456367842144256",
  "in_reply_to_user_id" : 211441184,
  "text" : "@shombory \u3046\u3061\u3068\u5317\u6D77\u9053\u3068\u53D7\u3051\u308B",
  "id" : 360456367842144256,
  "in_reply_to_status_id" : 360456166901420034,
  "created_at" : "2013-07-25 17:47:49 +0000",
  "in_reply_to_screen_name" : "shombory",
  "in_reply_to_user_id_str" : "211441184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360456009736667137",
  "text" : "@desole_mi \u30AB\u30C6\u30C4\u306E\u9662\u8A66\u306F2\u6708\u3068\u304B\u306E\u306F\u305A\u3067\u3059\u3088\u3046",
  "id" : 360456009736667137,
  "created_at" : "2013-07-25 17:46:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360454145297223683",
  "text" : "\u3053\u308C\u3067\u5B89\u5FC3\u3057\u3066\u6B7B\u3092\u8FCE\u3048\u3089\u308C\u308B[\u9662\u6B7B]",
  "id" : 360454145297223683,
  "created_at" : "2013-07-25 17:38:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360454018906066946",
  "text" : "\u3061\u306A\u307F\u306B\u8A66\u9A13\u306F\u306A\u3044",
  "id" : 360454018906066946,
  "created_at" : "2013-07-25 17:38:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360453948072673282",
  "text" : "\u4ECA\u671F\u30EC\u30DD\u30FC\u30C8\u5168\u90E8\u7247\u4ED8\u3051\u305F\uFF01\uFF01\uFF01\uFF01[\u5B8C]",
  "id" : 360453948072673282,
  "created_at" : "2013-07-25 17:38:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360392902070910977",
  "geo" : { },
  "id_str" : "360392968198303744",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u305F\u3057\u304B\u306B",
  "id" : 360392968198303744,
  "in_reply_to_status_id" : 360392902070910977,
  "created_at" : "2013-07-25 13:35:54 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360390959017635840",
  "geo" : { },
  "id_str" : "360392039604559872",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u306A\u3093\u304B\u3053\u306E\u3084\u308A\u3068\u308A\u4E45\u3005\u3060\u306A",
  "id" : 360392039604559872,
  "in_reply_to_status_id" : 360390959017635840,
  "created_at" : "2013-07-25 13:32:12 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360390448310784000",
  "text" : "\u3042\u3077\u3068\u3052\u3063\u3068\u3042\u3063\u3077\u3067\u30FC\u3068\n\u3042\u3077\u3068\u3052\u3063\u3068\u3042\u3063\u3077\u3050\u308C\u30FC\u3069",
  "id" : 360390448310784000,
  "created_at" : "2013-07-25 13:25:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360390021360001025",
  "geo" : { },
  "id_str" : "360390164813582337",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio \u3055\u3059\u304C\u70CF\u9AA8\u9D8F\u306E\u6709\u7CBE\u5375\u305F\u3079\u3066\u308B\u4EBA\u306E\u8A00\u3046\u3053\u3068\u306F\u9055\u3044\u307E\u3059\u306D\u30FC\u30FC\u30FC\u30FC\u30FC",
  "id" : 360390164813582337,
  "in_reply_to_status_id" : 360390021360001025,
  "created_at" : "2013-07-25 13:24:45 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/8KT486ufXJ",
      "expanded_url" : "http:\/\/youpouch.com\/2011\/04\/26\/162331\/",
      "display_url" : "youpouch.com\/2011\/04\/26\/162\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360387826212282369",
  "text" : "http:\/\/t.co\/8KT486ufXJ \u4E45\u3005\u306B\u773A\u3081\u3066\u308B\u3051\u3069\u3084\u3063\u3071\u308A\u3084\u3063\u3070\u3044",
  "id" : 360387826212282369,
  "created_at" : "2013-07-25 13:15:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adagio@dMcm",
      "screen_name" : "d_adagio",
      "indices" : [ 0, 9 ],
      "id_str" : "1290456272",
      "id" : 1290456272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/8KT486ufXJ",
      "expanded_url" : "http:\/\/youpouch.com\/2011\/04\/26\/162331\/",
      "display_url" : "youpouch.com\/2011\/04\/26\/162\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "360386937523146752",
  "geo" : { },
  "id_str" : "360387303602003968",
  "in_reply_to_user_id" : 1290456272,
  "text" : "@d_adagio http:\/\/t.co\/8KT486ufXJ",
  "id" : 360387303602003968,
  "in_reply_to_status_id" : 360386937523146752,
  "created_at" : "2013-07-25 13:13:23 +0000",
  "in_reply_to_screen_name" : "d_adagio",
  "in_reply_to_user_id_str" : "1290456272",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360386288253280257",
  "geo" : { },
  "id_str" : "360386474526515201",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u60C5\u5831\u793E\u4F1A\u306F\u6016\u3044\u30FC",
  "id" : 360386474526515201,
  "in_reply_to_status_id" : 360386288253280257,
  "created_at" : "2013-07-25 13:10:05 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360385858215485442",
  "text" : "\u3042\u308B\u3044\u306F\u8840\u306F\u3084\u308B\u304B\u3089\u75D2\u304F\u3057\u306A\u3044\u3067\u6B32\u3057\u3044",
  "id" : 360385858215485442,
  "created_at" : "2013-07-25 13:07:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360385790909489154",
  "text" : "\u868A\u306B\u523A\u3055\u308C\u3066\u308B\u6642\u306B\u6355\u307E\u3048\u3066\u300C\u6BD2\u3092\u629C\u3044\u3066\u304F\u308C\u305F\u3089\u6BBA\u3055\u305A\u306B\u5E30\u3059\u300D\u53D6\u5F15\u3092\u3057\u305F\u3044",
  "id" : 360385790909489154,
  "created_at" : "2013-07-25 13:07:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360385238427373569",
  "text" : "\u2220(\uFF9F\u0414\uFF9F)\/\u30A2\u30A4\u30A3\u30A3\u30A3\u30A3\u30B9!!!!!!!!\u2220(\uFF9F\u0414\uFF9F)\/\u30AD\u30E3\u30D5\u30A3\u30A3\u30A3\u30A3\u30A3\u30A3\u30A3!!!!!!!",
  "id" : 360385238427373569,
  "created_at" : "2013-07-25 13:05:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360384026185449472",
  "geo" : { },
  "id_str" : "360384411209965570",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u3042\u30FC\u3001\u305D\u306E\u5370\u8C61\u308F\u304B\u308B\u304B\u3082\u3057\u308C\u306A\u3044 \u50D5\u304C\u8A71\u3092\u805E\u304D\u306B\u3044\u3063\u305F\u4EBA\u306F\u89AA\u5207\u3060\u3063\u305F\u3051\u3069\u3001\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u306E\u6388\u696D\u3068\u3063\u3066\u305F\u4EBA\u306F\u7406\u4E0D\u5C3D\u3067\u6A2A\u66B4\u3067\u30A2\u30EC\u306A\u611F\u3058\u3060\u3063\u305F[Twitter\u3067\u30CD\u30BF\u306B\u3055\u308C\u3066\u3066\u9762\u767D\u304B\u3063\u305F\u3051\u3069]",
  "id" : 360384411209965570,
  "in_reply_to_status_id" : 360384026185449472,
  "created_at" : "2013-07-25 13:01:53 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360383241657659392",
  "geo" : { },
  "id_str" : "360383568687529985",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u3069\u306E\u6559\u6388\u3082\u5B66\u307C\u3046\u3068\u3059\u308B\u4EBA\u306B\u306F\u512A\u3057\u304F\u3042\u308B\u3079\u304D\u3067\u3059\u3088\u30FC[\u5B66\u3070\u305B\u308B\u305F\u3081\u306B\u53B3\u3057\u3044\u614B\u5EA6\u306F\u3068\u308B\u304B\u3082\u3060\u3051\u308C\u3069]",
  "id" : 360383568687529985,
  "in_reply_to_status_id" : 360383241657659392,
  "created_at" : "2013-07-25 12:58:33 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360382934580076544",
  "text" : "\u65E9\u3068\u3061\u308A\u3057\u3066\u6065\u305A\u304B\u3057\u3044",
  "id" : 360382934580076544,
  "created_at" : "2013-07-25 12:56:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360382642832687104",
  "geo" : { },
  "id_str" : "360382861557248001",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u305D\u308C\u306F\u6050\u3089\u304F\u30A2\u30BF\u30EA\u306A\u4EBA\u306A\u3093\u3060\u306A\u30FC[\u9ED2\u3044\u5642\u304C\u3042\u3063\u305F\u308A\u306A\u304B\u3063\u305F\u308A]",
  "id" : 360382861557248001,
  "in_reply_to_status_id" : 360382642832687104,
  "created_at" : "2013-07-25 12:55:44 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360382718091079680",
  "text" : "\u4EBA\u9593\u529B\uFF01\u305D\u3046\u8A00\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 360382718091079680,
  "created_at" : "2013-07-25 12:55:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360382415727894529",
  "text" : "\u5927\u304D\u3044\u6C37\u306F\u5E78\u305B\u306E\u3082\u3068",
  "id" : 360382415727894529,
  "created_at" : "2013-07-25 12:53:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360382182067408897",
  "geo" : { },
  "id_str" : "360382246961692673",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u30EC\u30DD\u30FC\u30C8\u3068\u304B\u7B54\u6848\u3068\u304B\uFF1F",
  "id" : 360382246961692673,
  "in_reply_to_status_id" : 360382182067408897,
  "created_at" : "2013-07-25 12:53:17 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u3075\u304B",
      "screen_name" : "carotene4035",
      "indices" : [ 0, 13 ],
      "id_str" : "264005011",
      "id" : 264005011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360381758606290944",
  "geo" : { },
  "id_str" : "360381982783447041",
  "in_reply_to_user_id" : 264005011,
  "text" : "@carotene4035 \u305F\u3076\u3093\u4EBA\u304C\u591A\u3044\u6388\u696D\u3068\u304B\u307B\u3068\u3093\u3069\u8AAD\u3093\u3067\u7121\u3044",
  "id" : 360381982783447041,
  "in_reply_to_status_id" : 360381758606290944,
  "created_at" : "2013-07-25 12:52:14 +0000",
  "in_reply_to_screen_name" : "carotene4035",
  "in_reply_to_user_id_str" : "264005011",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360381229981372416",
  "text" : "\u30BF\u30C3\u30D1\u30FC\u3067\u6C37\u4F5C\u3063\u3066\u3066\u8868\u9762\u306B\u89E6\u308C\u305F\u3089\u4E00\u77AC\u51C4\u3044\u75DB\u304B\u3063\u305F\u3057\u30D2\u30E3\u30C9\u3063\u3066\u3053\u3093\u306A\u611F\u3058\u306A\u306E\u304B\u306A\u3041\u3063\u3066\u601D\u3063\u305F\u306A\u3041",
  "id" : 360381229981372416,
  "created_at" : "2013-07-25 12:49:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360377649522163714",
  "text" : "\u65B0\u5BBF\u9AD8\u91CE\u306E\u30D5\u30EB\u30FC\u30C4\u30D1\u30FC\u30E9\u30FC\u307B\u3045\u2026",
  "id" : 360377649522163714,
  "created_at" : "2013-07-25 12:35:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360376943088107520",
  "text" : "\u30D5\u30EB\u30FC\u30C4\u306E\u30D0\u30A4\u30AD\u30F3\u30B0\u3068\u304B\u7121\u3044\u306E\u304B\u306A\u3001\u9AD8\u305D\u3046\u3060\u3051\u3069",
  "id" : 360376943088107520,
  "created_at" : "2013-07-25 12:32:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360376220191428608",
  "text" : "\u30AC\u30A4\u30A2\u304C\u4FFA\u306B\u6C34\u3092\u98F2\u3081\u3068\u56C1\u3044\u3066\u3044\u305F",
  "id" : 360376220191428608,
  "created_at" : "2013-07-25 12:29:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360376155779506177",
  "text" : "\u6C34\u5206\u6301\u305F\u305A\u306B\u9577\u98A8\u5442\u3057\u305F\u3089\u6B7B\u306B\u304B\u3051\u305F(\u3075\u3089\u3075\u3089\u3057\u3066\u5410\u304D\u6C17\u304C)",
  "id" : 360376155779506177,
  "created_at" : "2013-07-25 12:29:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360368920881930240",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 360368920881930240,
  "created_at" : "2013-07-25 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360362191414755328",
  "geo" : { },
  "id_str" : "360366345143066624",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u7559\u5E74\u306E\u6E9C\u307E\u3063\u305F\u843D\u3068\u3057\u7A74",
  "id" : 360366345143066624,
  "in_reply_to_status_id" : 360362191414755328,
  "created_at" : "2013-07-25 11:50:06 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360359393633648643",
  "text" : "\u904A\u622F\u738B\u30AB\u30FC\u30C9\u307F\u305F\u3044\u300C\u6DF1\u6D77\u30AE\u30E7\u30C9\u30F3\u300D",
  "id" : 360359393633648643,
  "created_at" : "2013-07-25 11:22:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360359319616749569",
  "text" : "\u98DF\u3079\u305F\u3044\uFF01\uFF01\u6DF1\u6D77\u30AE\u30E7\u30C9\u30F3\uFF01\uFF01",
  "id" : 360359319616749569,
  "created_at" : "2013-07-25 11:22:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360319635465310208",
  "text" : "18:00\u307E\u3067\u306B\u7D42\u3048\u308B\u4E88\u5B9A\u306E\u30EC\u30DD\u30FC\u30C8\u4E00\u6BB5\u843D\u3057\u305F\u3041\u3041\u3041\u3042",
  "id" : 360319635465310208,
  "created_at" : "2013-07-25 08:44:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360300407999836161",
  "text" : "16:30\u304B\u3089\u6B8B\u308A\u3092\u4ED5\u4E0A\u3050\uFF01\uFF01\uFF01",
  "id" : 360300407999836161,
  "created_at" : "2013-07-25 07:28:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360299294852530176",
  "geo" : { },
  "id_str" : "360299374976307200",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 360299374976307200,
  "in_reply_to_status_id" : 360299294852530176,
  "created_at" : "2013-07-25 07:23:59 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360298920636710914",
  "text" : "\u30DE\u30C9\u30EC\u30FC\u30CA\u30FC",
  "id" : 360298920636710914,
  "created_at" : "2013-07-25 07:22:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360298295681228800",
  "text" : "\u3077\u3063\u3064\u3093\u529B\u304C\u96C6\u4E2D\u3057\u3066\u3057\u307E\u3063\u305F",
  "id" : 360298295681228800,
  "created_at" : "2013-07-25 07:19:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360298185140342784",
  "text" : "\"\u7559\u5E74\u3057\u306A\u3044\u3060\u304B\u3089\"\u306B\u5FC5\u6B7B\u3055\u3092\u611F\u3058\u308B",
  "id" : 360298185140342784,
  "created_at" : "2013-07-25 07:19:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 3, 17 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360298103414337538",
  "text" : "RT @coscos2coscos: \u3084\u3081\u3066\uFF01\u6D41\u4F53\u529B\u5B66\u307E\u3067\u53D6\u308C\u306A\u304B\u3063\u305F\u3089\u7CBE\u795E\u307E\u3067\u71C3\u3048\u5C3D\u304D\u3061\u3083\u3046\uFF01\u304A\u9858\u3044\u3001\u6B7B\u306A\u306A\u3044\u3067\uFF01\u3042\u3093\u305F\u304C\u4ECA\u3053\u3053\u3067\u5012\u308C\u305F\u3089\u3001\u9032\u7D1A\u3084\u9662\u8A66\u306F\u3069\u3046\u306A\u3063\u3061\u3083\u3046\u306E\uFF1F\n\u5358\u4F4D\u306F\u307E\u3060\u6B8B\u3063\u3066\u308B\u3002\u3053\u308C\u3092\u8010\u3048\u308C\u3070\u3001\u7559\u5E74\u3057\u306A\u3044\u3060\u304B\u3089\uFF01\n\n\u6B21\u56DE\u3001\u300C\u6D41\u4F53\u529B\u5B66\u6B7B\u3059\u300D\u3002\u30C7\u30E5\u30A8\u30EB\u30B9\u30BF\u30F3\u30D0\u30A4\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360256880079151104",
    "text" : "\u3084\u3081\u3066\uFF01\u6D41\u4F53\u529B\u5B66\u307E\u3067\u53D6\u308C\u306A\u304B\u3063\u305F\u3089\u7CBE\u795E\u307E\u3067\u71C3\u3048\u5C3D\u304D\u3061\u3083\u3046\uFF01\u304A\u9858\u3044\u3001\u6B7B\u306A\u306A\u3044\u3067\uFF01\u3042\u3093\u305F\u304C\u4ECA\u3053\u3053\u3067\u5012\u308C\u305F\u3089\u3001\u9032\u7D1A\u3084\u9662\u8A66\u306F\u3069\u3046\u306A\u3063\u3061\u3083\u3046\u306E\uFF1F\n\u5358\u4F4D\u306F\u307E\u3060\u6B8B\u3063\u3066\u308B\u3002\u3053\u308C\u3092\u8010\u3048\u308C\u3070\u3001\u7559\u5E74\u3057\u306A\u3044\u3060\u304B\u3089\uFF01\n\n\u6B21\u56DE\u3001\u300C\u6D41\u4F53\u529B\u5B66\u6B7B\u3059\u300D\u3002\u30C7\u30E5\u30A8\u30EB\u30B9\u30BF\u30F3\u30D0\u30A4\uFF01",
    "id" : 360256880079151104,
    "created_at" : "2013-07-25 04:35:08 +0000",
    "user" : {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "protected" : true,
      "id_str" : "470868127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3630089731\/733f844995c833c5a2d51e6ebc83bc52_normal.png",
      "id" : 470868127,
      "verified" : false
    }
  },
  "id" : 360298103414337538,
  "created_at" : "2013-07-25 07:18:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360233377808388100",
  "text" : "\u30CF\u30F3\u30D0\u30FC\u30B0\u3068\u70CF\u9F8D\u8336\u306E\u89AA\u548C\u6027\u304C\u30DE\u30C3\u30CF",
  "id" : 360233377808388100,
  "created_at" : "2013-07-25 03:01:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 3, 11 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360036932765499393",
  "text" : "RT @shigmax: \u4FFA\u306E\u65E5\u672C\u8A9E\u304C\u3053\u3093\u306A\u4E0D\u81EA\u7531\u306A\u308F\u3051\u304C\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360034622060503041",
    "text" : "\u4FFA\u306E\u65E5\u672C\u8A9E\u304C\u3053\u3093\u306A\u4E0D\u81EA\u7531\u306A\u308F\u3051\u304C\u306A\u3044",
    "id" : 360034622060503041,
    "created_at" : "2013-07-24 13:51:57 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "protected" : false,
      "id_str" : "16929336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000769383065\/518d97375643a4198486ed81dfb2439e_normal.png",
      "id" : 16929336,
      "verified" : false
    }
  },
  "id" : 360036932765499393,
  "created_at" : "2013-07-24 14:01:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360032425776128002",
  "text" : "@Kyo_Hiiragi \u672C\u5F53\u306B\u805E\u304D\u305F\u304B\u3063\u305F\u3089\u5F8C\u671F\u306B\u4F8B\u4F1A\u8B1B\u7FA9\u3084\u308B\uFF1F",
  "id" : 360032425776128002,
  "created_at" : "2013-07-24 13:43:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360032121693278211",
  "text" : "\u3057\u3083\u30FC\u3057\u3083\u30FC\u3056\u308F\u30FC\u3056\u308F\u30FC",
  "id" : 360032121693278211,
  "created_at" : "2013-07-24 13:42:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360031654850461696",
  "text" : "\u306A\u308A\u305F\u3044\u30AD\u30E3\u30E9\u306B\u306F\u306A\u308C\u306A\u3044\u3051\u3069\u306A\u3063\u3066\u6B32\u3057\u3044\u3068\u601D\u308F\u308C\u308B\u30AD\u30E3\u30E9\u306B\u306F\u306A\u308C\u308B\u30E1\u30BD\u30C3\u30C9",
  "id" : 360031654850461696,
  "created_at" : "2013-07-24 13:40:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360031403456479235",
  "text" : "\u8A00\u308F\u308C\u3066\u81EA\u899A\u3059\u308B\u30BF\u30A4\u30D7\u306E\uFF1F",
  "id" : 360031403456479235,
  "created_at" : "2013-07-24 13:39:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360031360552943616",
  "text" : "\uFF1F",
  "id" : 360031360552943616,
  "created_at" : "2013-07-24 13:39:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u307E",
      "screen_name" : "shigmax",
      "indices" : [ 62, 70 ],
      "id_str" : "16929336",
      "id" : 16929336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360031343037521920",
  "text" : "\u5C0F\u6CC9\u3055\u3093\u306F\u5B97\u6559\u3063\u307D\u3044\u3063\u3066\u8A00\u308F\u308C\u3066\u304B\u3089\u9014\u7AEF\u306B\u5B97\u6559\u3063\u307D\u3044\u30AD\u30E3\u30E9\u306B\u306A\u3063\u305F\u3057\u3001\u65E5\u672C\u8A9E\u4E0D\u81EA\u7531\u3063\u3066\u8A00\u308F\u308C\u3066\u304B\u3089\u65E5\u672C\u8A9E\u4E0D\u81EA\u7531\u306B\u306A\u3063\u305F\u5148\u8F29(@shigmax )\u3082\u3044\u308B\u3057\u307F\u3093\u306A\u81EA\u5DF1\u6D17\u8133\u304C\u4E0A\u624B\u3060\u306A\u3041",
  "id" : 360031343037521920,
  "created_at" : "2013-07-24 13:38:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360030398547365892",
  "geo" : { },
  "id_str" : "360030816195190786",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u5B9F\u969B\u4E8C\u671F\u306F\u308F\u308A\u3068\u5FA1\u5742\u512A\u9047\u3055\u308C\u3066\u305F\u3088\u3046\u306A\u6C17\u3082\u3059\u308B\u306E\u3067\u9577\u3044\u76EE\u3067\u898B\u308B\u3068\u826F\u3044\u304B\u3082",
  "id" : 360030816195190786,
  "in_reply_to_status_id" : 360030398547365892,
  "created_at" : "2013-07-24 13:36:50 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360030350891696128",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u8AAC\u6559\u30D1\u30FC\u30C8\u3044\u3089\u306A\u3044\u304B\u3089\u958B\u5E55\u9854\u6BB4\u3063\u3066\u7D42\u308F\u308C\u3070\u826F\u3044\u306E\u306B\u3063\u3066\u601D\u3046",
  "id" : 360030350891696128,
  "created_at" : "2013-07-24 13:34:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360030207870119936",
  "text" : "\u7981\u66F8\u76EE\u9332\u3001\u4E0A\u6761\u3055\u3093\u304C\u300C\u3046\u308B\u305B\u3047\uFF01\uFF01\uFF01\u300D\u3063\u3066\u8A00\u3063\u3066\u6575\u306E\u9854\u3092\u6BB4\u308B\u4F5C\u54C1",
  "id" : 360030207870119936,
  "created_at" : "2013-07-24 13:34:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u306F\u3044",
      "indices" : [ 11, 14 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360029789668646913",
  "geo" : { },
  "id_str" : "360030047203110912",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba #\u306F\u3044 [\u306A\u3093\u3060\u304B\u3093\u3060\u30BF\u30A4\u30C8\u30EB\u30D2\u30ED\u30A4\u30F3\u306E\u306F\u305A\u306E\u30A4\u30F3\u30C7\u30C3\u30AF\u30B9\u306E\u5F71\u306E\u8584\u3055\u306F\u3084\u3070\u3044\u3068\u601D\u3046\u304C\u30AD\u30E3\u30E9\u591A\u3059\u304E\u3066\u5168\u4F53\u7684\u306B\u8584\u3044]",
  "id" : 360030047203110912,
  "in_reply_to_status_id" : 360029789668646913,
  "created_at" : "2013-07-24 13:33:46 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360029482922418177",
  "geo" : { },
  "id_str" : "360029607824596992",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba 2\u4E07\u4EBA\u4EE5\u4E0A\u51FA\u3066\u304F\u308B\u304B\u3089\u6700\u591A\u51FA\u6F14\u306E\u30D2\u30ED\u30A4\u30F3\u3067\u306F",
  "id" : 360029607824596992,
  "in_reply_to_status_id" : 360029482922418177,
  "created_at" : "2013-07-24 13:32:02 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360028918310371331",
  "geo" : { },
  "id_str" : "360029204517101571",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u8868\u9762\u3057\u304B\u898B\u3066\u3044\u306A\u304B\u3063\u305F\u3053\u3068\u3092\u53CD\u7701\u3057\u307E\u3059",
  "id" : 360029204517101571,
  "in_reply_to_status_id" : 360028918310371331,
  "created_at" : "2013-07-24 13:30:26 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360028567125504000",
  "text" : "S2S\u306EWiki\u306B\u3044\u308D\u3044\u308D\u304B\u3044\u305F\u3000",
  "id" : 360028567125504000,
  "created_at" : "2013-07-24 13:27:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C0F\u6CC9\u3075\u3085\u30FC\u308A\u30FC",
      "screen_name" : "koizumi_fifty",
      "indices" : [ 0, 14 ],
      "id_str" : "243012018",
      "id" : 243012018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360028279312351234",
  "geo" : { },
  "id_str" : "360028501274935296",
  "in_reply_to_user_id" : 243012018,
  "text" : "@koizumi_fifty \u305D\u3046\u3044\u3048\u3070,\u306A\u3093\u304B\u5149\u3063\u3066\u308B\u30B7\u30FC\u30F3\u3042\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u3063\u3051.\u3042\u308C\u306F\u4EE3\u6570\u30C8\u30DD\u30ED\u30B8\u30FC\u306E\u305D\u308C\u3060\u3063\u305F\u306E\u3067\u3059\u304B.",
  "id" : 360028501274935296,
  "in_reply_to_status_id" : 360028279312351234,
  "created_at" : "2013-07-24 13:27:38 +0000",
  "in_reply_to_screen_name" : "koizumi_fifty",
  "in_reply_to_user_id_str" : "243012018",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5CA1\u672C\u6681\u5E83\u3004\u7CBE\u795E\u3068\u6642\u306E\u9AEA",
      "screen_name" : "henkma",
      "indices" : [ 3, 10 ],
      "id_str" : "45520875",
      "id" : 45520875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359984298511704065",
  "text" : "RT @henkma: \u8A3C\u660E\u30B5\u30FC\u30AD\u30E5\u30EC\u30FC\u30B7\u30E7\u30F3\u3066\u5FAA\u74B0\u8AD6\u6CD5\u304B\u3002\u305D\u308A\u3083\u305D\u3093\u306A\u3093\u3058\u3083\u3060\u3081\u3060\u308D\u3046\u306A\u3042\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359984253485842432",
    "text" : "\u8A3C\u660E\u30B5\u30FC\u30AD\u30E5\u30EC\u30FC\u30B7\u30E7\u30F3\u3066\u5FAA\u74B0\u8AD6\u6CD5\u304B\u3002\u305D\u308A\u3083\u305D\u3093\u306A\u3093\u3058\u3083\u3060\u3081\u3060\u308D\u3046\u306A\u3042\u3002",
    "id" : 359984253485842432,
    "created_at" : "2013-07-24 10:31:48 +0000",
    "user" : {
      "name" : "\u5CA1\u672C\u6681\u5E83\u3004\u7CBE\u795E\u3068\u6642\u306E\u9AEA",
      "screen_name" : "henkma",
      "protected" : false,
      "id_str" : "45520875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3213753488\/c693aa532154076f8bc8fd61f31e3cfb_normal.png",
      "id" : 45520875,
      "verified" : false
    }
  },
  "id" : 359984298511704065,
  "created_at" : "2013-07-24 10:31:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359984152294068224",
  "text" : "\u3067\u3082\u305D\u3093\u306A\u3093\u3058\u3083\u3060\u3081",
  "id" : 359984152294068224,
  "created_at" : "2013-07-24 10:31:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359984113182187521",
  "text" : "\u8A3C\u660E\u30B5\u30FC\u30AD\u30E5\u30EC\u30FC\u30B7\u30E7\u30F3",
  "id" : 359984113182187521,
  "created_at" : "2013-07-24 10:31:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/359982690969219072\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/8uJyb2jnp9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP7qWaTCcAEotx3.jpg",
      "id_str" : "359982690973413377",
      "id" : 359982690973413377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP7qWaTCcAEotx3.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/8uJyb2jnp9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359982690969219072",
  "text" : "\u5B9F\u969B\u3084\u3070\u3044 http:\/\/t.co\/8uJyb2jnp9",
  "id" : 359982690969219072,
  "created_at" : "2013-07-24 10:25:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/359981670482448386\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/tbkXiPzGTC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP7pbAsCEAAgMQf.jpg",
      "id_str" : "359981670486642688",
      "id" : 359981670486642688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP7pbAsCEAAgMQf.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/tbkXiPzGTC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359981670482448386",
  "text" : "\u30D2\u30C8\u30AB\u30B2 http:\/\/t.co\/tbkXiPzGTC",
  "id" : 359981670482448386,
  "created_at" : "2013-07-24 10:21:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359981120755990528",
  "text" : "\u754F\u308C\u591A\u3044",
  "id" : 359981120755990528,
  "created_at" : "2013-07-24 10:19:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/359980886160199680\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/i7pwQg4Baf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP7otW4CUAAmAau.jpg",
      "id_str" : "359980886168588288",
      "id" : 359980886168588288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP7otW4CUAAmAau.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/i7pwQg4Baf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359980886160199680",
  "text" : "\u3046\u3064\u3069\u3093\u306A\u3089\u4E0A\u624B\u306B\u304B\u3051\u308B http:\/\/t.co\/i7pwQg4Baf",
  "id" : 359980886160199680,
  "created_at" : "2013-07-24 10:18:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359980391467204609",
  "text" : "\u30EA\u30AF\u30A8\u30B9\u30C8\u304F\u308C\u305F\u3089\u306A\u3093\u3067\u3082\u66F8\u304D\u307E\u3059\u304C\u306A\u3093\u3067\u3082\u306A\u3044\u3082\u306E\u304C\u51FA\u6765\u4E0A\u304C\u308A\u307E\u3059",
  "id" : 359980391467204609,
  "created_at" : "2013-07-24 10:16:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/359980195924566016\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/uoPSK3HF56",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP7oFLjCYAASQ2v.jpg",
      "id_str" : "359980195932954624",
      "id" : 359980195932954624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP7oFLjCYAASQ2v.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/uoPSK3HF56"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359980195924566016",
  "text" : "\u753B\u50CF\u307F\u306A\u304C\u3089\u66F8\u304D\u76F4\u3057\u305F\u3089\u3053\u308C\u3060\u3088\uFF01\uFF01 http:\/\/t.co\/uoPSK3HF56",
  "id" : 359980195924566016,
  "created_at" : "2013-07-24 10:15:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/359979676648763392\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/0nnxR2GVRa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP7nm9FCcAAT2Js.jpg",
      "id_str" : "359979676652957696",
      "id" : 359979676652957696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP7nm9FCcAAT2Js.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/0nnxR2GVRa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359979676648763392",
  "text" : "\u30AD\u30CE\u30AC\u30C3\u30B5 http:\/\/t.co\/0nnxR2GVRa",
  "id" : 359979676648763392,
  "created_at" : "2013-07-24 10:13:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359978034499026944",
  "text" : "\u7F8E\u5C11\u5973\u3068\u304B\u4E00\u5207\u66F8\u3051\u306A\u304F\u3066\u3044\u3044\u304B\u3089\u601D\u3044\u3064\u3044\u305F\u3057\u3087\u3046\u3082\u306A\u3044\u30CD\u30BF\u3092\u7D75\u306B\u3059\u308B\u7A0B\u5EA6\u306E\u753B\u529B\u3060\u3051\u6B32\u3057\u3044",
  "id" : 359978034499026944,
  "created_at" : "2013-07-24 10:07:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/359971314414522368\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/tGHMS8xXHE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP7gANVCEAAHK_m.jpg",
      "id_str" : "359971314418716672",
      "id" : 359971314418716672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP7gANVCEAAHK_m.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/tGHMS8xXHE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359971314414522368",
  "text" : "\u300C\u30C9\u30FC\u30E2,\u79C1\u304C\u98DF\u5802\u30C6\u30EC\u30D3\u3067\u3059.\u300D http:\/\/t.co\/tGHMS8xXHE",
  "id" : 359971314414522368,
  "created_at" : "2013-07-24 09:40:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359969490932482049",
  "text" : "\u7720\u3044\u30FC\u7720\u3044\u30FC\u30FC\u30FCof the nemui\u301C\uFF01",
  "id" : 359969490932482049,
  "created_at" : "2013-07-24 09:33:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359965245130813440",
  "geo" : { },
  "id_str" : "359965887954034689",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u72C2\u4EBA\u306E\u3075\u308A\u3092\u3057\u305F\u3089\u5B9F\u969B\u72C2\u4EBA",
  "id" : 359965887954034689,
  "in_reply_to_status_id" : 359965245130813440,
  "created_at" : "2013-07-24 09:18:50 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/359963633817620480\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/qEALpN0eri",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP7ZBI4CEAAGF0N.jpg",
      "id_str" : "359963633821814784",
      "id" : 359963633821814784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP7ZBI4CEAAGF0N.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/qEALpN0eri"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359963633817620480",
  "text" : "\u99AC\u306E\u5B9A\u7406\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01 http:\/\/t.co\/qEALpN0eri",
  "id" : 359963633817620480,
  "created_at" : "2013-07-24 09:09:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359961014957129730",
  "text" : "\u4EAC\u90FD\u305D\u3070\u306B\u7533\u3057\u8A33 of the world",
  "id" : 359961014957129730,
  "created_at" : "2013-07-24 08:59:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359960964638056449",
  "text" : "\u4EAC\u90FD\u306B\u3044\u3066\u6C96\u7E04\u305D\u3070\u3092\u98DF\u3079\u305F\u3053\u3068\u3092\u53CD\u7701\u3059\u308B\u305D\u3093\u306A\u6C34\u66DC\u65E5\u306E\u5348\u5F8C",
  "id" : 359960964638056449,
  "created_at" : "2013-07-24 08:59:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359924944794165249",
  "text" : "\u304B\u3093\u304C\u3089\u304C\u3089",
  "id" : 359924944794165249,
  "created_at" : "2013-07-24 06:36:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359924891606204417",
  "text" : "\u3053\u3093\u304C\u3089\u304C\u3063\u3066\u308B\u3063\u3066\u8A00\u3044\u306B\u304F\u304F\u3066\u3053\u3093\u304C\u3089\u304C\u3089\u3063\u305F\u3063\u305F\uFF1F",
  "id" : 359924891606204417,
  "created_at" : "2013-07-24 06:35:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359922135063474176",
  "text" : "\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u4EE5\u5916\u306F\u98DF\u3079\u305F\u3044\u3068\u306F\u9650\u3089\u306A\u3044",
  "id" : 359922135063474176,
  "created_at" : "2013-07-24 06:24:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359922072635453440",
  "text" : "\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u98DF\u3079\u305F\u3044.",
  "id" : 359922072635453440,
  "created_at" : "2013-07-24 06:24:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359921276107767808",
  "text" : "\"\u30DF\u30EB\u30AD\u30FC\u306F\u30DE\u30DE\u306E\u5473\"\u3068\u304B\u3044\u3046\u30AB\u30CB\u30D0\u30E9\u30A4\u30BC\u30FC\u30B7\u30E7\u30F3",
  "id" : 359921276107767808,
  "created_at" : "2013-07-24 06:21:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/KFwF856JsP",
      "expanded_url" : "http:\/\/via.me\/-dcvj68e",
      "display_url" : "via.me\/-dcvj68e"
    } ]
  },
  "geo" : { },
  "id_str" : "359657400325767170",
  "text" : "RT @kagakuma: \u81EA\u8CA9\u6A5F\u3067150\u5186\u306EDAKARA\u8CB7\u3046\u306E\u306B550\u5186\u5165\u308C\u305F\u3089\u5168\u90E850\u5186\u7389\u30678\u679A\u51FA\u3066\u304D\u305F\uFF57\uFF57\uFF57 http:\/\/t.co\/KFwF856JsP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/KFwF856JsP",
        "expanded_url" : "http:\/\/via.me\/-dcvj68e",
        "display_url" : "via.me\/-dcvj68e"
      } ]
    },
    "geo" : { },
    "id_str" : "359657158796787713",
    "text" : "\u81EA\u8CA9\u6A5F\u3067150\u5186\u306EDAKARA\u8CB7\u3046\u306E\u306B550\u5186\u5165\u308C\u305F\u3089\u5168\u90E850\u5186\u7389\u30678\u679A\u51FA\u3066\u304D\u305F\uFF57\uFF57\uFF57 http:\/\/t.co\/KFwF856JsP",
    "id" : 359657158796787713,
    "created_at" : "2013-07-23 12:52:03 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 359657400325767170,
  "created_at" : "2013-07-23 12:53:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359643997976801282",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 359643997976801282,
  "created_at" : "2013-07-23 11:59:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359596932991160321",
  "geo" : { },
  "id_str" : "359640663710646272",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma 21\u6642\u306B\u3064\u304F\u3088\u3046\u8ABF\u6574\u3057\u307E\u3059",
  "id" : 359640663710646272,
  "in_reply_to_status_id" : 359596932991160321,
  "created_at" : "2013-07-23 11:46:30 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359596798748278784",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u306A\u3093\u304B\u4ECA\u304B\u3089\u3068\u3044\u3046\u8AAC\u3082\u51FA\u3066\u308B\u306E\u3067\u5145\u96FB\u56DE\u5FA9\u3057\u6B21\u7B2C\u308C\u3093\u3089\u304F\u304F\u3060\u3057\u3042",
  "id" : 359596798748278784,
  "created_at" : "2013-07-23 08:52:12 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359594970098827265",
  "text" : "n\u30FC\u3053\u308C\u3069\u3046\u306A\u308B\u3093\u3060\u308D",
  "id" : 359594970098827265,
  "created_at" : "2013-07-23 08:44:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 25, 41 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359588874147737600",
  "geo" : { },
  "id_str" : "359589040321867776",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ @miattermeyer @Jelly_in_a_tank \u30D4\u30ED\u30C6\u30A3\u306B\u3044\u307E\u3059\u3001\u304B\u304C\u304F\u307E\u3055\u3093\u304C\u6765\u305F\u304C\u3063\u3066\u307E\u3059\u3051\u3069\u3044\u3044\u3067\u3059\u304B\uFF1F",
  "id" : 359589040321867776,
  "in_reply_to_status_id" : 359588874147737600,
  "created_at" : "2013-07-23 08:21:22 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    }, {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 17, 27 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359582625695928320",
  "geo" : { },
  "id_str" : "359584836232560640",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank @wa_ta_si_ @miattermeyer \u30AC\u30BF\u30C3",
  "id" : 359584836232560640,
  "in_reply_to_status_id" : 359582625695928320,
  "created_at" : "2013-07-23 08:04:40 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359584701188550656",
  "text" : "\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u304C\u5B9F\u969B\u306E\u30E9\u30A4\u30D6\u30D0\u30C8\u30EB\u3092\u898B\u305B\u3066\u304F\u308C\u3066\u975E\u5E38\u306B\u7406\u89E3\u304C\u6DF1\u307E\u3063\u305F(\u3068\u3042\u308B\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u6BB4\u3089\u308C\u305F\u6A21\u69D8)",
  "id" : 359584701188550656,
  "created_at" : "2013-07-23 08:04:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359575509442637825",
  "text" : "@reflexio \u5BFE\u6226\u306E\u30B7\u30B9\u30C6\u30E0\u304C\u3088\u304F\u308F\u304B\u3089\u3093\u306E\u3060\u304C\u3001\u3053\u308C\u306F\u6C17\u3065\u304F\u3068\u6BB4\u3089\u308C\u3066\u308B\u3082\u306E\u306A\u306E\uFF1F",
  "id" : 359575509442637825,
  "created_at" : "2013-07-23 07:27:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/4u65m7JJxw",
      "expanded_url" : "http:\/\/www.kotaku.jp\/2013\/06\/love_mobamasu.html",
      "display_url" : "kotaku.jp\/2013\/06\/love_m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "359575190902013952",
  "text" : "\u307E\u30FC\u305F\u95C7\u6DF1\u3044\u3082\u306E\u304C\u2026\u300C\u753B\u9762\u3092\u898B\u308B\u3068\u4EC1\u5948\u304C\u3044\u308B\u300D\u30E2\u30D0\u30DE\u30B9\u91CD\u8AB2\u91D1\u30D7\u30EC\u30A4\u30E4\u30FC\u3078\u306E\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u3092\u53CE\u9332\u3057\u305F\u66F8\u7C4D\u304C\u767A\u58F2 : Kotaku JAPAN http:\/\/t.co\/4u65m7JJxw",
  "id" : 359575190902013952,
  "created_at" : "2013-07-23 07:26:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359558678677962754",
  "text" : "\u300C\u30E2\u30D0\u30DE\u30B9 \u4ED5\u8FD4\u3057\u300D\u3067\u30B0\u30B0\u3063\u3066\u898B\u308B\u3068\u533F\u540D\u793E\u4F1A\u306E\u95C7\u3092\u3072\u3057\u3072\u3057\u3068\u611F\u3058\u305F",
  "id" : 359558678677962754,
  "created_at" : "2013-07-23 06:20:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359556797096407040",
  "text" : "\u3053\u308C\u30E2\u30D0\u30DE\u30B9\u306E\u30A2\u30A4\u30C9\u30EB\u3063\u3066\u4F55\u7A2E\u985E\u3042\u308B\u306E\u2026",
  "id" : 359556797096407040,
  "created_at" : "2013-07-23 06:13:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359556620646236161",
  "text" : "\u30AB\u30EA\u30F3\u306E\u30D5\u30ED\u30FC\u30BA\u30F3\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 359556620646236161,
  "created_at" : "2013-07-23 06:12:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E0B\u9D28\u795E\u793E",
      "screen_name" : "kamomioyajinja",
      "indices" : [ 3, 18 ],
      "id_str" : "279812014",
      "id" : 279812014
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kamomioyajinja\/status\/359556314638192640\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/7zLHncT4zS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP1mkCsCEAInACm.jpg",
      "id_str" : "359556314642386946",
      "id" : 359556314642386946,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP1mkCsCEAInACm.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/7zLHncT4zS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359556563565953025",
  "text" : "RT @kamomioyajinja: \u84B8\u3057\u6691\u3044\u65E5\u304C\u7D9A\u304D\u307E\u3059\u306D\u3002\n\u3053\u3093\u306A\u65E5\u306F\u3001\u30AB\u30EA\u30F3\u306E\u30D5\u30ED\u30FC\u30BA\u30F3\u306A\u3069\u3044\u304B\u304C\u3067\u3057\u3087\u3046\u304B\u3002\u3055\u3063\u3071\u308A\u3068\u51B7\u305F\u304F\u3001\u5973\u6027\u306B\u306F\u5B09\u3057\u3044\u7F8E\u808C\u52B9\u679C\u3082\u3042\u308B\u3068\u304B\u3002\u4E0B\u9D28\u795E\u793E\u306E\u6442\u793E\u3001\u6CB3\u5408\u795E\u793E\u4F11\u61A9\u6240\u3078\u305C\u3072\u304A\u7ACB\u3061\u5BC4\u308A\u304F\u3060\u3055\u3044\u3002 http:\/\/t.co\/7zLHncT4zS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kamomioyajinja\/status\/359556314638192640\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/7zLHncT4zS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BP1mkCsCEAInACm.jpg",
        "id_str" : "359556314642386946",
        "id" : 359556314642386946,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP1mkCsCEAInACm.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/7zLHncT4zS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359556314638192640",
    "text" : "\u84B8\u3057\u6691\u3044\u65E5\u304C\u7D9A\u304D\u307E\u3059\u306D\u3002\n\u3053\u3093\u306A\u65E5\u306F\u3001\u30AB\u30EA\u30F3\u306E\u30D5\u30ED\u30FC\u30BA\u30F3\u306A\u3069\u3044\u304B\u304C\u3067\u3057\u3087\u3046\u304B\u3002\u3055\u3063\u3071\u308A\u3068\u51B7\u305F\u304F\u3001\u5973\u6027\u306B\u306F\u5B09\u3057\u3044\u7F8E\u808C\u52B9\u679C\u3082\u3042\u308B\u3068\u304B\u3002\u4E0B\u9D28\u795E\u793E\u306E\u6442\u793E\u3001\u6CB3\u5408\u795E\u793E\u4F11\u61A9\u6240\u3078\u305C\u3072\u304A\u7ACB\u3061\u5BC4\u308A\u304F\u3060\u3055\u3044\u3002 http:\/\/t.co\/7zLHncT4zS",
    "id" : 359556314638192640,
    "created_at" : "2013-07-23 06:11:20 +0000",
    "user" : {
      "name" : "\u4E0B\u9D28\u795E\u793E",
      "screen_name" : "kamomioyajinja",
      "protected" : false,
      "id_str" : "279812014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1306177522\/web00126_normal.jpg",
      "id" : 279812014,
      "verified" : false
    }
  },
  "id" : 359556563565953025,
  "created_at" : "2013-07-23 06:12:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359551029467037696",
  "text" : "@reflexio \u30E2\u30D0\u30DE\u30B9\u3084\u3063\u3066\u308B\uFF1F",
  "id" : 359551029467037696,
  "created_at" : "2013-07-23 05:50:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359542444775325696",
  "text" : "@Kyo_Hiiragi \u30E2\u30D0\u30DE\u30B9\u3084\u3063\u3066\u308B\u52E2\u306B\u8A71\u3092\u805E\u304D\u305F\u304B\u3063\u305F\u3060\u3051",
  "id" : 359542444775325696,
  "created_at" : "2013-07-23 05:16:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359541990746099712",
  "text" : "\u3042\u30FC\u6628\u65E5S2S\u306E\u4F8B\u4F1A\u3044\u304F\u3079\u304D\u3060\u3063\u305F\u306A\u2026",
  "id" : 359541990746099712,
  "created_at" : "2013-07-23 05:14:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359540822850547712",
  "text" : "\u30E2\u30D0\u30DE\u30B9\u3084\u3063\u3066\u308B\u4EBA\u3067\u6687\u306A\u4EBA\u3044\u305F\u3089\u304A\u3057\u3083\u3079\u308A\u3057\u3066\u304F\u308C\u307E\u305B\u3093\u304B(\u30B8\u30E5\u30FC\u30B9\u304F\u3089\u3044\u304A\u3054\u308A\u307E\u3059)",
  "id" : 359540822850547712,
  "created_at" : "2013-07-23 05:09:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359536530806681605",
  "text" : "\u3061\u3087\u3063\u3068\u8CEA\u554F\u306A\u306E\u3067\u3059\u304C\u3001\u8AB2\u91D1\u306E\u95C7\u304C\u6700\u3082\u6DF1\u3044\u3067\u3042\u308D\u3046\u30BD\u30B7\u30E3\u30B2\u3063\u3066\u30E2\u30D0\u30DE\u30B9\u3068\u3044\u3046\u7406\u89E3\u3067\u3042\u3063\u3066\u307E\u3059\u304B\u306D\uFF1F",
  "id" : 359536530806681605,
  "created_at" : "2013-07-23 04:52:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359528629849423873",
  "text" : "\u6182\u3046(\u56DE\u6587)",
  "id" : 359528629849423873,
  "created_at" : "2013-07-23 04:21:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359528229134020610",
  "text" : "\u985E\u306F\u53CB\u3092\u547C\u3076\u3051\u3069\u5FC5\u305A\u6765\u308B\u3068\u306F\u9650\u3089\u306A\u3044",
  "id" : 359528229134020610,
  "created_at" : "2013-07-23 04:19:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359526005834137601",
  "text" : "\u30B3\u30FC\u30E9\u98F2\u3082\u3046\u3068\u3057\u3066\u3081\u3093\u3064\u3086\u98F2\u3080\u4EBA\u306F\u3044\u308B\u306E\u306B\u3081\u3093\u3064\u3086\u98F2\u3082\u3046\u3068\u3057\u3066\u30B3\u30FC\u30E9\u98F2\u3080\u4EBA\u306F\u5C11\u306A\u3044\u3057\u3081\u3093\u3064\u3086\u304C\u793E\u4F1A\u7684\u306B\u8FEB\u5BB3\u3055\u308C\u3066\u3044\u308B\u53EF\u80FD\u6027\u304C",
  "id" : 359526005834137601,
  "created_at" : "2013-07-23 04:10:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359523830269620224",
  "text" : "\u6587\u7CFB\u306F\u6955\u5186\u3068\u304B\u77E5\u3089\u3093\u3068\u304B\u8A00\u3063\u3066\u3066\u95C7\u3092",
  "id" : 359523830269620224,
  "created_at" : "2013-07-23 04:02:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359523643396591616",
  "text" : "\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 359523643396591616,
  "created_at" : "2013-07-23 04:01:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359523558902349824",
  "text" : "\u79D1\u5B66\u53F2\u52E2\u3081\u3044\u305F\u4EBA\u305F\u3061\u304C\u5999\u306A\u4F1A\u8A71\u3057\u3066\u3066( \u00B4_\u309D\uFF40)\u3063\u3066\u306A\u3063\u3066\u308B",
  "id" : 359523558902349824,
  "created_at" : "2013-07-23 04:01:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359522831870070784",
  "text" : "\u30DF\u30EB\u30C1\u6C0F\/\u3044\u305F\u308A\u3042\u6C0F\u3068\u3059\u308C\u9055\u3046\u306A\u3069",
  "id" : 359522831870070784,
  "created_at" : "2013-07-23 03:58:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359521491353739264",
  "text" : "\u56F3\u66F8\u9928\u51FA\u308B\u6642\u306B\u30BB\u30F3\u30B5\u30FC\u304C\u9CF4\u3063\u3066\u5BFE\u5FDC\u3057\u3066\u3082\u3089\u3063\u305F\u3093\u3060\u3051\u3069\u304A\u3070\u3055\u3093\u306B\u300C\u304A\u3070\u3055\u3093\u79D1\u5B66\u8005\u3067\u3059\u304B\uFF1F\u300D\u3063\u3066\u805E\u304D\u305F\u304F\u306A\u3063\u305F",
  "id" : 359521491353739264,
  "created_at" : "2013-07-23 03:52:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359503411936374786",
  "geo" : { },
  "id_str" : "359504367725985792",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u306A\u306B\u304B\u304C\u304F\u307E\u3055\u3093\uFF1F\u30EC\u30C3\u30C9\u30D6\u30EB\u304C\u5168\u304F\u5229\u304B\u306A\u3044\uFF1F \u304B\u304C\u304F\u307E\u3055\u3093\u3001\u305D\u308C\u306F\u7121\u7406\u77E2\u7406\u8D77\u304D\u3066\u3044\u3088\u3046\u3068\u3059\u308B\u304B\u3089\u3060\u3088 \u9006\u306B\u8003\u3048\u308B\u3093\u3060\u3001\u300C\u5BDD\u3061\u3083\u3063\u3066\u3082\u3044\u3044\u3055\u300D\u3068\u8003\u3048\u308B\u3093\u3060\uFF0E",
  "id" : 359504367725985792,
  "in_reply_to_status_id" : 359503411936374786,
  "created_at" : "2013-07-23 02:44:55 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359286857068056576",
  "text" : "\u308A\u3060\u3064\u3045\u3045\u3045\u3045\u3045\u3045\u3045\u3045\u3046",
  "id" : 359286857068056576,
  "created_at" : "2013-07-22 12:20:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359285971780505600",
  "geo" : { },
  "id_str" : "359286349024608256",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u300C\u6B86\u3069\u306E\u30DD\u30B1\u30E2\u30F3\u306F\u602A\u7269\u300D\u3068\u3044\u3046\u4E3B\u5F35\u306B\u300C\u4EBA\u9593\u306F\u602A\u7269\u3058\u3083\u306A\u3044\u300D\u306F\u542B\u610F\u3055\u308C\u306A\u3044\u306E\u3067\u306F",
  "id" : 359286349024608256,
  "in_reply_to_status_id" : 359285971780505600,
  "created_at" : "2013-07-22 12:18:35 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359285299131592704",
  "text" : "\u7A81\u7136\u306E\u30DE\u30B8\u30EC\u30B9",
  "id" : 359285299131592704,
  "created_at" : "2013-07-22 12:14:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359285188364210176",
  "geo" : { },
  "id_str" : "359285275089838081",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u3042\u306E\uFF0C\u307B\u3068\u3093\u3069\u306E\u30DD\u30B1\u30E2\u30F3\u306F\u602A\u7269\u3060\u3068\u601D\u3046\u306E\u3067\u3059\u304C...",
  "id" : 359285275089838081,
  "in_reply_to_status_id" : 359285188364210176,
  "created_at" : "2013-07-22 12:14:19 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359284384974643201",
  "geo" : { },
  "id_str" : "359284646736957443",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u3042\u3046\u3042\u3046\u3042\uFF08\u56DE\u6587\uFF09",
  "id" : 359284646736957443,
  "in_reply_to_status_id" : 359284384974643201,
  "created_at" : "2013-07-22 12:11:49 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359284153352589312",
  "text" : "\u983C\u3080\u304B\u3089\u300C\u3046\u306A\u304E\u306A\u3046\uFF08\u56DE\u6587\uFF09\u300D\u3068\u304B\u8A00\u308F\u306A\u3044\u3067\u304F\u308C\u3088",
  "id" : 359284153352589312,
  "created_at" : "2013-07-22 12:09:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359284040748109824",
  "text" : "\u52E2\u3044\u3060\u3051\u3067\u4F1A\u8A71\u3059\u308B\u306E\u306B\u3082\u305A\u3044\u3076\u3093\u6163\u308C\u305F\u3082\u306E\u3060\u306A\uFF0E\u305D\u3057\u3066\u4E45\u3005\u306BTween\u958B\u304F\u3068\u30C0\u30E1\u3060\u306A\uFF0E",
  "id" : 359284040748109824,
  "created_at" : "2013-07-22 12:09:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359283755002769410",
  "geo" : { },
  "id_str" : "359283897533595648",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u30E6\u30FC\u30C6\uFF0C\u30EF\u30F3\u30C1\u30E3\u30F3,\u30A2\u30EB\u30C3\u30B7\u30E7\uFF1F \uFF08\uFF76\uFF80\uFF7A\uFF84\uFF09",
  "id" : 359283897533595648,
  "in_reply_to_status_id" : 359283755002769410,
  "created_at" : "2013-07-22 12:08:51 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359283551574835200",
  "geo" : { },
  "id_str" : "359283631124000769",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u30B5\u30A6\u30B6\u30F3\u30C9\u30A2\u30A4\u30BA\u30B5\u30AF\u30EA\u30D5\u30A1\u30A4\u30B9",
  "id" : 359283631124000769,
  "in_reply_to_status_id" : 359283551574835200,
  "created_at" : "2013-07-22 12:07:47 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359282928359981056",
  "geo" : { },
  "id_str" : "359283042864472064",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows \u78BA\u304B\u306B\u4ED8\u304B\u306A\u3044\uFF0E\u571F\u7528\u306E\u4E11\u306E\u65E5\u306B\u98DF\u3079\u3089\u308C\u3066\u3057\u307E\u3046\u4EBA\u751F\u3060\u3063\u305F\uFF0E",
  "id" : 359283042864472064,
  "in_reply_to_status_id" : 359282928359981056,
  "created_at" : "2013-07-22 12:05:27 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u304B\u306A\u3044\u306F\u307E\u304B\u306A\u3044\u541B\u3092\u5FDC\u63F4\u3057\u307E\u3059",
      "screen_name" : "MaryMimiary",
      "indices" : [ 0, 12 ],
      "id_str" : "131048355",
      "id" : 131048355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359282854250819585",
  "geo" : { },
  "id_str" : "359282934093594624",
  "in_reply_to_user_id" : 131048355,
  "text" : "@MaryMimiary \u30DF\u30CB\u30EA\u30E5\u30A6",
  "id" : 359282934093594624,
  "in_reply_to_status_id" : 359282854250819585,
  "created_at" : "2013-07-22 12:05:01 +0000",
  "in_reply_to_screen_name" : "MaryMimiary",
  "in_reply_to_user_id_str" : "131048355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359282817185751040",
  "text" : "\u597D\u304D\u5ACC\u3044\u306F\u3088\u304F\u306A\u3044\u304B\u3089\u201D\u3046\u201D\u306E\u4ED8\u304B\u306A\u3044\u3082\u306E\uFF08\u4F8B\uFF1A\u30C1\u30E7\u30B3\u30EC\u30FC\u30C8\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\uFF09\u3068\u304B\u3082\u98DF\u3079\u3088\u3046\uFF0E",
  "id" : 359282817185751040,
  "created_at" : "2013-07-22 12:04:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359282524557557762",
  "text" : "\u201D\u3046\u201D\u306E\u4ED8\u304F\u7269\u3055\u3063\u304D\u304B\u3089\u8003\u3048\u3066\u308B\u3051\u3069\u30A6\u30C4\u30C9\u30F3\u3057\u304B\u601D\u3044\u6D6E\u304B\u3070\u306A\u304F\u3066",
  "id" : 359282524557557762,
  "created_at" : "2013-07-22 12:03:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359282023380172800",
  "text" : "\u826F\u3044\u3058\u3083\u3093\uFF01\u30C1\u30E7\u30B3\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u7F8E\u5473\u3057\u3044\u3082\u3093\uFF01\u30C1\u30E7\u30B3\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u306B\u7F6A\u306F\u306A\u3044\u3058\u3083\u306A\u3044\u304B\uFF01",
  "id" : 359282023380172800,
  "created_at" : "2013-07-22 12:01:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359281934901317634",
  "text" : "\u201D\u3046\u201D\u306E\u7740\u304F\u7269\u306D\u3047\uFF0E\uFF0E\uFF0E\u30C1\u30E7\u30B3\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u3057\u304B\u601D\u3044\u3064\u304B\u306A\u3044\u3057\u624B\u5143\u306B\u30C1\u30E7\u30B3\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u3057\u304B\u306A\u3044\u304B\u3089\u30C1\u30E7\u30B3\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u98DF\u3079\u307E\u3059\u306D\uFF0E",
  "id" : 359281934901317634,
  "created_at" : "2013-07-22 12:01:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6625\u6765",
      "screen_name" : "haruhalcyoncat",
      "indices" : [ 0, 15 ],
      "id_str" : "97121312",
      "id" : 97121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359226845331324928",
  "geo" : { },
  "id_str" : "359280868306591745",
  "in_reply_to_user_id" : 97121312,
  "text" : "@haruhalcyoncat \u306F\u3044\uFF0E\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F\uFF0E[\u5F8C\u59FF\u3067\u6625\u6765\u304F\u3093\u3060\u3068\u6C17\u4ED8\u3044\u305F\u6642\u306B\u306F\u9045\u304B\u3063\u305F]",
  "id" : 359280868306591745,
  "in_reply_to_status_id" : 359226845331324928,
  "created_at" : "2013-07-22 11:56:48 +0000",
  "in_reply_to_screen_name" : "haruhalcyoncat",
  "in_reply_to_user_id_str" : "97121312",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359264765148803072",
  "text" : "\u5145\u96FB\u5207\u308C\u30FC",
  "id" : 359264765148803072,
  "created_at" : "2013-07-22 10:52:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359263970441428992",
  "text" : "\u300C\u5C45\u9152\u5C4B\u304A\u63A2\u3057\u3058\u3083\u306A\u3044\u3067\u3059\u304B\uFF1F\uFF1F\u300D\n\u300C\u5C45\u9152\u5C4B\u4EE5\u5916\u306F\u5927\u62B5\u63A2\u3057\u3066\u308B\u3093\u3067\u3059\u3051\u3069\u306D\u30FC\u3001\u5C45\u9152\u5C4B\u3060\u3051\u306F\u9593\u306B\u5408\u3063\u3066\u307E\u3059\u30FC\u300D",
  "id" : 359263970441428992,
  "created_at" : "2013-07-22 10:49:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359257741618970624",
  "text" : "\u30A2\u30A4\u30D1\u30A4\u30E8\u3082\u6301\u3063\u3066\u304F\u308B\u3079\u304D\u3060\u3063\u305F\u30CA\u30FC",
  "id" : 359257741618970624,
  "created_at" : "2013-07-22 10:24:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359256870264909825",
  "text" : "\u5145\u96FB\u304C\u307F\u308B\u307F\u308B\u6E1B\u3063\u3066\u304F\u5348\u5F8C7\u6642",
  "id" : 359256870264909825,
  "created_at" : "2013-07-22 10:21:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359256328935444480",
  "text" : "\u30B7\u30E3\u30F3\u30D7\u30FC\u3068\u304B\u306E\u6642\u306B\u7720\u305F\u307F\u306B\u8972\u308F\u308C\u308B\u73FE\u8C61\u306B\u540D\u524D\u3092\u3064\u3051\u305F\u3044[\u7F8E\u5BB9\u9662\u306A\u30FC]",
  "id" : 359256328935444480,
  "created_at" : "2013-07-22 10:19:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359217688968572928",
  "text" : "\u79C1\u306A\u3093\u3066\u6D88\u3048\u3061\u3083\u3048\u3070\u3044\u3044\u3093\u3060\u3063\u3066\u601D\u3063\u3066\u305F\u30E1\u30F3\u30D8\u30E9\u304C\u6700\u5F8C\u306B\u8AB0\u306B\u3082\u8A00\u308F\u305A\u306B\u6EB6\u9271\u7089\u306B\u6C88\u3093\u3067\u884C\u304F\u6620\u753B\u307E\u3060\uFF1F",
  "id" : 359217688968572928,
  "created_at" : "2013-07-22 07:45:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359217428347105280",
  "text" : "\u30A2\u30E9\u30E9\u30AE\u3055\u3093\u306F\u6D88\u3048\u308B\u3053\u3068\u3082\u3067\u304D\u306A\u3044\u3093\u3067\u3059\u304B\u301C\uFF1F\uFF1F",
  "id" : 359217428347105280,
  "created_at" : "2013-07-22 07:44:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359217347136987137",
  "text" : "\u30E1\u30F3\u30D8\u30E9\u300C\u79C1\u306A\u3093\u3066\u6D88\u3048\u3061\u3083\u3048\u3070\u3044\u3044\u3093\u3060\u300D\n\u2026\n\u3048\u3093\u3069\u300C\u3042\u308C\u3001\u6D88\u3048\u3061\u3083\u3048\u3070\u3044\u3044\u306E\u306B\u307E\u3060\u3044\u305F\u306E\uFF1F\u300D",
  "id" : 359217347136987137,
  "created_at" : "2013-07-22 07:44:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359216206730895360",
  "text" : "\u4E0B\u99C4\u5C65\u3044\u3066\u304D\u305F\u30896\u6B73\u304F\u3089\u3044\u306E\u5973\u306E\u5B50\u306B\u30AC\u30F3\u898B\u3055\u308C\u305F\u65B9\u306E\u3048\u3093\u3069\u3067\u3059",
  "id" : 359216206730895360,
  "created_at" : "2013-07-22 07:39:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359215537554862082",
  "geo" : { },
  "id_str" : "359215833362333698",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u305D\u308C\u306A\u2026",
  "id" : 359215833362333698,
  "in_reply_to_status_id" : 359215537554862082,
  "created_at" : "2013-07-22 07:38:23 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359215170251272192",
  "text" : "\u79C1\u304C\u6D88\u3048\u308B\u304B\u79C1\u4EE5\u5916\u304C\u307F\u3093\u306A\u6D88\u3048\u308B\u304B\u3060\u3063\u305F\u3089\u5B9F\u969B\u524D\u8005\u3068\u308B",
  "id" : 359215170251272192,
  "created_at" : "2013-07-22 07:35:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359212792051531776",
  "geo" : { },
  "id_str" : "359213350351147009",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u3046\u3075\u3075\u3075[\u6C34\u66DC\u30B7\u30E1\u306E\u30EC\u30DD\u30FC\u30C8(\u30B4\u30B4\u30B4]",
  "id" : 359213350351147009,
  "in_reply_to_status_id" : 359212792051531776,
  "created_at" : "2013-07-22 07:28:31 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u970A\u5B88",
      "screen_name" : "fffw2",
      "indices" : [ 0, 6 ],
      "id_str" : "107939609",
      "id" : 107939609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359212608668180480",
  "geo" : { },
  "id_str" : "359212813664788480",
  "in_reply_to_user_id" : 107939609,
  "text" : "@fffw2 \u5B9F\u306F\u4E00\u56DE\u306E\u6642\u306B\u6765\u3066\u305F\u308A\u3059\u308B\u306E\u3067\u3059\u3002\u697D\u3057\u3044\u3067\u3059\u3088\u306D\uFF01",
  "id" : 359212813664788480,
  "in_reply_to_status_id" : 359212608668180480,
  "created_at" : "2013-07-22 07:26:23 +0000",
  "in_reply_to_screen_name" : "fffw2",
  "in_reply_to_user_id_str" : "107939609",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E0B\u9D28\u795E\u793E",
      "screen_name" : "kamomioyajinja",
      "indices" : [ 41, 56 ],
      "id_str" : "279812014",
      "id" : 279812014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/iAc8FsTaRa",
      "expanded_url" : "http:\/\/4sq.com\/15aDZAR",
      "display_url" : "4sq.com\/15aDZAR"
    } ]
  },
  "geo" : { },
  "id_str" : "359212614963822592",
  "text" : "I'm at \u4E0B\u9D28\u795E\u793E (\u8CC0\u8302\u5FA1\u7956\u795E\u793E \/ Shimogamo-jinja) - @kamomioyajinja (\u4EAC\u90FD\u5E02, \u4EAC\u90FD\u5E9C) w\/ 2 others http:\/\/t.co\/iAc8FsTaRa",
  "id" : 359212614963822592,
  "created_at" : "2013-07-22 07:25:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359212279834755072",
  "text" : "\u3046\u3075\u3075\u3075",
  "id" : 359212279834755072,
  "created_at" : "2013-07-22 07:24:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u970A\u5B88",
      "screen_name" : "fffw2",
      "indices" : [ 0, 6 ],
      "id_str" : "107939609",
      "id" : 107939609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359211669576093696",
  "geo" : { },
  "id_str" : "359212061139546112",
  "in_reply_to_user_id" : 107939609,
  "text" : "@fffw2 \u884C\u304D\u307E\u3059\uFF01[\u3068\u8A00\u3046\u304B\u7740\u304D\u307E\u3057\u305F]",
  "id" : 359212061139546112,
  "in_reply_to_status_id" : 359211669576093696,
  "created_at" : "2013-07-22 07:23:23 +0000",
  "in_reply_to_screen_name" : "fffw2",
  "in_reply_to_user_id_str" : "107939609",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359211458564861952",
  "text" : "\u3059\u3050\u305D\u3070\u3060\u3057\u4E0B\u9D28\u795E\u793E\u6765\u305F",
  "id" : 359211458564861952,
  "created_at" : "2013-07-22 07:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359209079190720513",
  "text" : "\u5DDD\u306B\u798A\u306B\u884C\u304F\u304B\uFF1F",
  "id" : 359209079190720513,
  "created_at" : "2013-07-22 07:11:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u98A8\u970A\u5B88",
      "screen_name" : "fffw2",
      "indices" : [ 0, 6 ],
      "id_str" : "107939609",
      "id" : 107939609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359208722452586496",
  "geo" : { },
  "id_str" : "359208994230898688",
  "in_reply_to_user_id" : 107939609,
  "text" : "@fffw2 \u4ECA\u3084\u3063\u3066\u308B\u3093\u3067\u3059\u304B\uFF1F",
  "id" : 359208994230898688,
  "in_reply_to_status_id" : 359208722452586496,
  "created_at" : "2013-07-22 07:11:12 +0000",
  "in_reply_to_screen_name" : "fffw2",
  "in_reply_to_user_id_str" : "107939609",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359206942394155009",
  "text" : "\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u3068GCD\u3067\u5E78\u305B",
  "id" : 359206942394155009,
  "created_at" : "2013-07-22 07:03:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359204227710599168",
  "text" : "\u9AD8\u5EA6\u306B\u767A\u9054\u3057\u305F\u30A8\u30F3\u30C9\u3055\u3093\u306F\u96E8\u304C\u6B62\u3080(\u3068\u601D\u308F\u308C\u308B)\u6642\u9593\u306B\u7F8E\u5BB9\u9662\u3092\u4E88\u7D04\u3059\u308B",
  "id" : 359204227710599168,
  "created_at" : "2013-07-22 06:52:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u308F\u305A",
      "screen_name" : "kawazu1147",
      "indices" : [ 0, 11 ],
      "id_str" : "111624231",
      "id" : 111624231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359203418893586432",
  "geo" : { },
  "id_str" : "359203982725488641",
  "in_reply_to_user_id" : 111624231,
  "text" : "@kawazu1147 \u5BCC\u826F\u91CE\uFF01\uFF01\uFF01\u305D\u3053\u3067\u3057\u304B\u58F2\u3063\u3066\u306A\u3044\u3076\u3069\u3046\u30B8\u30E5\u30FC\u30B9\u304C\u7F8E\u5473\u3057\u3044\u3067\u3059\uFF01\uFF01",
  "id" : 359203982725488641,
  "in_reply_to_status_id" : 359203418893586432,
  "created_at" : "2013-07-22 06:51:17 +0000",
  "in_reply_to_screen_name" : "kawazu1147",
  "in_reply_to_user_id_str" : "111624231",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359203793193279489",
  "text" : "\u52E2\u3044\u3067\u7F8E\u5BB9\u9662\u306E\u4E88\u7D04\u30AD\u30E1\u305F[\u4ECA\u65E5]",
  "id" : 359203793193279489,
  "created_at" : "2013-07-22 06:50:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359191011366404096",
  "text" : "\u96E8\u964D\u308A\u305D\u3046\u76F4\u611F\u304C\u50CD\u3044\u305F",
  "id" : 359191011366404096,
  "created_at" : "2013-07-22 05:59:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359190893955260419",
  "text" : "\u30DF \u30B9 \u30BF \u30FC \u30C9 \u30FC \u30CA \u30C3 \u30C4 \u3092 \u8CB7 \u3063 \u3066 \u6765 \u305F",
  "id" : 359190893955260419,
  "created_at" : "2013-07-22 05:59:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359133394413694978",
  "text" : "\u30DE\u30EA\u30AA\u30D1\u30FC\u30C6\u30A3\u306F\u653F\u6CBB\u30B2\u30FC\u3060\u3063\u305F\u306E\u304B\u3082\u3057\u308C\u306A\u3044(\u30DE\u30EA\u30AA\u515A)",
  "id" : 359133394413694978,
  "created_at" : "2013-07-22 02:10:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359110419635388416",
  "text" : "@kotorin_phoenix \u3068\u308A\u3042\u3048\u305A\u306F\u9662\u6B7B\u30AD\u30E1\u3066\u304B\u3089\u3067\u3059\u306D\u30FC(\u767D\u76EE",
  "id" : 359110419635388416,
  "created_at" : "2013-07-22 00:39:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358991820216221696",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8",
  "id" : 358991820216221696,
  "created_at" : "2013-07-21 16:48:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358991763530203136",
  "text" : "\u4E16\u754C\u306B\u306F\u7559\u5E74\u3057\u305F\u304F\u306A\u3044\u3051\u3069\u7559\u5E74\u3057\u3061\u3083\u3046\u4EBA\u3082\u3044\u308B\u3068\u3044\u3046\u306E\u306B\u2026",
  "id" : 358991763530203136,
  "created_at" : "2013-07-21 16:48:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358991561314410499",
  "text" : "\u3058\u308F\u3058\u308F\u3068\u9019\u3044\u5BC4\u308B\u7559\u5E74\u6B32",
  "id" : 358991561314410499,
  "created_at" : "2013-07-21 16:47:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358991441223090176",
  "text" : "\u3053\u308C\u305F\u3076\u3093\u5E73\u65E5\u306F\u8AA4\u9B54\u5316\u3055\u308C\u3066\u308B\u3060\u3051\u306E\u30A2\u30EC",
  "id" : 358991441223090176,
  "created_at" : "2013-07-21 16:46:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358991375687106560",
  "text" : "\u9031\u672B\u306E\u81EA\u5DF1\u5ACC\u60AA\u30E4\u30D0\u3044\u306A\u2026",
  "id" : 358991375687106560,
  "created_at" : "2013-07-21 16:46:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358919315292033024",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 358919315292033024,
  "created_at" : "2013-07-21 12:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358898253120540672",
  "text" : "\u3042\u305A\u304D\u30D0\u30FC\u304B\u305F\u3044",
  "id" : 358898253120540672,
  "created_at" : "2013-07-21 10:36:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/ODtsOm25LL",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/14?prefill=tarooh",
      "display_url" : "gohantabeyo.com\/nani\/14?prefil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358883533860773888",
  "text" : "\u3042\u3044\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/ODtsOm25LL",
  "id" : 358883533860773888,
  "created_at" : "2013-07-21 09:37:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358556905540554752",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 358556905540554752,
  "created_at" : "2013-07-20 12:00:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358273887995314176",
  "text" : "9\u6642\u524D\u306B\u8D77\u304D\u308B\u307E\u3059\u304A\u3084\u3059\u307F[\u5207\u7FBD\u8A70\u307E\u308B]",
  "id" : 358273887995314176,
  "created_at" : "2013-07-19 17:15:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358248815846891521",
  "text" : "\u666E\u6BB5\u50B7\u3068\u304B\u4F5C\u3089\u306A\u3044\u751F\u6D3B\u3057\u3066\u308B\u304B\u3089\u306A\u2026",
  "id" : 358248815846891521,
  "created_at" : "2013-07-19 15:35:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358248739921596417",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u308B\u6642\u307E\u3060\u56FA\u307E\u3063\u3066\u306A\u3044\u304B\u3055\u3076\u305F\u306E\u5B58\u5728\u3092\u5FD8\u308C\u3066\u3066\u601D\u3044\u3063\u304D\u308A\u64E6\u3063\u3066\u3057\u307E\u3063\u3066\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u3063\u3066\u306A\u3063\u305F",
  "id" : 358248739921596417,
  "created_at" : "2013-07-19 15:35:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358240072123944962",
  "text" : "2\u6642\u307E\u3067\u9811\u5F35\u308B",
  "id" : 358240072123944962,
  "created_at" : "2013-07-19 15:01:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358185457810542592",
  "geo" : { },
  "id_str" : "358189825322532864",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u30E6\u30FC\u30C6\u30D5\u30A1\u30FC\u30B9\u30C8\u30D5\u30FC\u30C9\u30C8\u30AB\u30A2\u30EB\u30C3\u30B7\u30E7",
  "id" : 358189825322532864,
  "in_reply_to_status_id" : 358185457810542592,
  "created_at" : "2013-07-19 11:41:23 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358181026306072576",
  "text" : "\u6D41\u77F3\u306B\u96D1\u3060\u3063\u305F",
  "id" : 358181026306072576,
  "created_at" : "2013-07-19 11:06:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358180570137772032",
  "geo" : { },
  "id_str" : "358180971805286401",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u98E2\u3048\u30FC\u30FC\u30FC\u30FC\u3044\uFF01\uFF01\uFF01\uFF01",
  "id" : 358180971805286401,
  "in_reply_to_status_id" : 358180570137772032,
  "created_at" : "2013-07-19 11:06:13 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358081355831185408",
  "text" : "\u9B31\u30C9\u30F3\u2026",
  "id" : 358081355831185408,
  "created_at" : "2013-07-19 04:30:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "indices" : [ 3, 12 ],
      "id_str" : "532309831",
      "id" : 532309831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358081317931454464",
  "text" : "RT @usiusi02: \u6B7B\u306B\u305F\u3044\u30C9\u30FC\u30FC\u30FC\u30FC\u30FC\u30F3\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "358081175606136832",
    "text" : "\u6B7B\u306B\u305F\u3044\u30C9\u30FC\u30FC\u30FC\u30FC\u30FC\u30F3\uFF01",
    "id" : 358081175606136832,
    "created_at" : "2013-07-19 04:29:39 +0000",
    "user" : {
      "name" : "\u30A6\u30B7\u30DC\u30ED\u30B9",
      "screen_name" : "usiusi02",
      "protected" : false,
      "id_str" : "532309831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532426317476540416\/HerFGzpd_normal.jpeg",
      "id" : 532309831,
      "verified" : false
    }
  },
  "id" : 358081317931454464,
  "created_at" : "2013-07-19 04:30:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358074346608132097",
  "text" : "\u3057\u304B\u3057\u3066\u304A\u663C\u3054\u98EF\u98DF\u3079\u640D\u306A\u3063\u305F\u306A(\u98DF\u3079\u3088\u3046\u3068\u3059\u308C\u3070\u98DF\u3079\u3089\u308C\u3066\u3044\u305F\u6C17\u3082)",
  "id" : 358074346608132097,
  "created_at" : "2013-07-19 04:02:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358073996350210048",
  "text" : "\u304B\u304C\u307F\u306D\u308B\u304B\u3055\u3093",
  "id" : 358073996350210048,
  "created_at" : "2013-07-19 04:01:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3075\u3047\u3044\u3093\u304C\u305F\u308A\u306A\u3044\u3002",
      "screen_name" : "KishidaKus",
      "indices" : [ 3, 14 ],
      "id_str" : "1521726091",
      "id" : 1521726091
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/KishidaKus\/status\/358035072902897664\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/RJhYWYk88r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPf_AHnCIAQt3J0.jpg",
      "id_str" : "358035072907091972",
      "id" : 358035072907091972,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPf_AHnCIAQt3J0.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1821,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 3920,
        "resize" : "fit",
        "w" : 2204
      } ],
      "display_url" : "pic.twitter.com\/RJhYWYk88r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358073979988230147",
  "text" : "RT @KishidaKus: \u3053\u308C\u305E\u4EAC\u5927\u304F\u304A\u308A\u3066\u3090@\u4EBA\u74B0\u7DCF\u4EBA\u56F3\u66F8\u9928 http:\/\/t.co\/RJhYWYk88r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/KishidaKus\/status\/358035072902897664\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/RJhYWYk88r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPf_AHnCIAQt3J0.jpg",
        "id_str" : "358035072907091972",
        "id" : 358035072907091972,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPf_AHnCIAQt3J0.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1821,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3920,
          "resize" : "fit",
          "w" : 2204
        } ],
        "display_url" : "pic.twitter.com\/RJhYWYk88r"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "358035072902897664",
    "text" : "\u3053\u308C\u305E\u4EAC\u5927\u304F\u304A\u308A\u3066\u3090@\u4EBA\u74B0\u7DCF\u4EBA\u56F3\u66F8\u9928 http:\/\/t.co\/RJhYWYk88r",
    "id" : 358035072902897664,
    "created_at" : "2013-07-19 01:26:28 +0000",
    "user" : {
      "name" : "\u304B\u3075\u3047\u3044\u3093\u304C\u305F\u308A\u306A\u3044\u3002",
      "screen_name" : "KishidaKus",
      "protected" : true,
      "id_str" : "1521726091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577578647868993536\/NJfL2Pun_normal.jpeg",
      "id" : 1521726091,
      "verified" : false
    }
  },
  "id" : 358073979988230147,
  "created_at" : "2013-07-19 04:01:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3079\u306B\u3070\u306A\uFF201\u56DE\u751F",
      "screen_name" : "CcreticusL",
      "indices" : [ 0, 11 ],
      "id_str" : "407066804",
      "id" : 407066804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358026590816440322",
  "geo" : { },
  "id_str" : "358026675268751362",
  "in_reply_to_user_id" : 407066804,
  "text" : "@CcreticusL \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 358026675268751362,
  "in_reply_to_status_id" : 358026590816440322,
  "created_at" : "2013-07-19 00:53:05 +0000",
  "in_reply_to_screen_name" : "CcreticusL",
  "in_reply_to_user_id_str" : "407066804",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358019286222123009",
  "text" : "\u643A\u5E2F\u5FD8\u308C\u3066iPad\u5974",
  "id" : 358019286222123009,
  "created_at" : "2013-07-19 00:23:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358018966905565184",
  "text" : "@reflexio \u308A\u304B\u3044\u3057\u305F",
  "id" : 358018966905565184,
  "created_at" : "2013-07-19 00:22:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358017035093016576",
  "text" : "@reflexio \u3093\u30FC\u3001\u8FD1\u3005\u3061\u3087\u3063\u3068\u9023\u7D61\u3059\u308B\u304B\u3082www",
  "id" : 358017035093016576,
  "created_at" : "2013-07-19 00:14:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358016240591192065",
  "text" : "\u30DC\u30AB\u30ED\u306B\u3055\u3093\u4ED8\u3051\u3059\u308B\u306E\u3044\u3044\u611F\u3058\u306E\u9055\u548C\u611F\u304C\u3042\u308B",
  "id" : 358016240591192065,
  "created_at" : "2013-07-19 00:11:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u5927\u4EBA\u74B0\u30FB\u7DCF\u4EBA\u56F3\u66F8\u9928",
      "screen_name" : "jinkansoujinlib",
      "indices" : [ 3, 19 ],
      "id_str" : "2360348826",
      "id" : 2360348826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6ANfKXbkil",
      "expanded_url" : "http:\/\/www.kulib.kyoto-u.ac.jp\/modules\/piCal\/index.php?smode=&op=&cid=9",
      "display_url" : "kulib.kyoto-u.ac.jp\/modules\/piCal\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358016164204523520",
  "text" : "RT @jinkansoujinlib: \u30107\/19(\u91D1)\u3011\u6628\u65E5\u306B\u7D9A\u304D\u3001\u82F1\u8A9E\u3082\u6B4C\u3048\u308B\u30DC\u30AB\u30ED\u300C\u5DE1\u97F3\uFF08\u3081\u3050\u308A\u306D\uFF09\u30EB\u30AB\u300D\u3055\u3093\u9ED2\u677F\u304C\u3054\u6765\u9928\u3092\u304A\u5F85\u3061\u3057\u3066\u304A\u308A\u307E\u3059\u266A \n\u25CF\u4EAC\u5927\u4EBA\u74B0\u30FB\u7DCF\u4EBA\u56F3\u66F8\u9928\uFF1A9-20\u6642\u958B\u9928 \n\u25CF\u8A71\u305B\u308B\u56F3\u66F8\u9928\u300E\u74B0on\uFF08\u308F\u304A\u3093\uFF09\u300F\uFF1A9-17\u6642\u958B\u5BA4 \n\u25CF\u5B66\u5185\u5168\u9928\u306E\u958B\u9928\u6642\u9593\u2192 h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/6ANfKXbkil",
        "expanded_url" : "http:\/\/www.kulib.kyoto-u.ac.jp\/modules\/piCal\/index.php?smode=&op=&cid=9",
        "display_url" : "kulib.kyoto-u.ac.jp\/modules\/piCal\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "358014319717396480",
    "text" : "\u30107\/19(\u91D1)\u3011\u6628\u65E5\u306B\u7D9A\u304D\u3001\u82F1\u8A9E\u3082\u6B4C\u3048\u308B\u30DC\u30AB\u30ED\u300C\u5DE1\u97F3\uFF08\u3081\u3050\u308A\u306D\uFF09\u30EB\u30AB\u300D\u3055\u3093\u9ED2\u677F\u304C\u3054\u6765\u9928\u3092\u304A\u5F85\u3061\u3057\u3066\u304A\u308A\u307E\u3059\u266A \n\u25CF\u4EAC\u5927\u4EBA\u74B0\u30FB\u7DCF\u4EBA\u56F3\u66F8\u9928\uFF1A9-20\u6642\u958B\u9928 \n\u25CF\u8A71\u305B\u308B\u56F3\u66F8\u9928\u300E\u74B0on\uFF08\u308F\u304A\u3093\uFF09\u300F\uFF1A9-17\u6642\u958B\u5BA4 \n\u25CF\u5B66\u5185\u5168\u9928\u306E\u958B\u9928\u6642\u9593\u2192 http:\/\/t.co\/6ANfKXbkil",
    "id" : 358014319717396480,
    "created_at" : "2013-07-19 00:04:00 +0000",
    "user" : {
      "name" : "\u4EAC\u5927\u5409\u7530\u5357\u7DCF\u5408\u56F3\u66F8\u9928(\u900D\u9065\u9928)",
      "screen_name" : "yoshidasouthlib",
      "protected" : false,
      "id_str" : "786227288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554891191548776448\/N8Tf4Uvt_normal.jpeg",
      "id" : 786227288,
      "verified" : false
    }
  },
  "id" : 358016164204523520,
  "created_at" : "2013-07-19 00:11:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358015835429810176",
  "text" : "\u5EC3\u8AB2\u91D1\u306B\u3064\u3044\u3066\u30EC\u30DD\u30FC\u30C8\u66F8\u304F\u4E88\u5B9A\u3060\u3057\u751F\u306E\u58F0\u3092\u671F\u5F85\u3057\u3066\u307E\u3059\u3088\u307F\u306A\u3055\u3093",
  "id" : 358015835429810176,
  "created_at" : "2013-07-19 00:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358015285183262721",
  "text" : "\uFF1F",
  "id" : 358015285183262721,
  "created_at" : "2013-07-19 00:07:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358015269597233153",
  "text" : "\u5144\u5F1F\u3078\u306E\u614B\u5EA6\u306F\u96D1.\u4EBA\u985E\u7686\u5144\u5F1F.\u3060\u304B\u3089\u4EBA\u985E\u3078\u306E\u614B\u5EA6\u306F\u96D1\u3067\u3044\u3044.",
  "id" : 358015269597233153,
  "created_at" : "2013-07-19 00:07:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357882149216595968",
  "text" : "\u304A\u3084\u3059\u307F\u305B\u304B\u3044",
  "id" : 357882149216595968,
  "created_at" : "2013-07-18 15:18:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357882096053796866",
  "text" : "\u5730\u56F3\u8A18\u53F7\u30A2\u30A4\u30B3\u30F3\u304B\u3089\u6EF2\u307F\u51FA\u308B\u72C2\u6C17\u3044\u3044\u306D",
  "id" : 357882096053796866,
  "created_at" : "2013-07-18 15:18:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357879971240361984",
  "text" : "\u8A00\u3044\u305F\u3044\u3053\u3068\u3092\u8A00\u3046\u3060\u3051\u306E\u4EBA\u751F",
  "id" : 357879971240361984,
  "created_at" : "2013-07-18 15:10:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357879619455692802",
  "text" : "(\u3082\u3063\u3068\u524D\u304B\u3089\u306A\u304B\u3063\u305F)",
  "id" : 357879619455692802,
  "created_at" : "2013-07-18 15:08:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357879559405846528",
  "text" : "4\u56DE\u751F\u306B\u306A\u308B\u524D\u306E\u6625\u4F11\u307F\u3001\u4E00\u5339\u306E\u87F9\u306B\u884C\u304D\u906D\u3063\u3066\"\u8108\u7D61\"\u3092\u6839\u3053\u305D\u304E\u3082\u3063\u3066\u3044\u304B\u308C\u305F",
  "id" : 357879559405846528,
  "created_at" : "2013-07-18 15:08:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357877288357986305",
  "text" : "\u6700\u8FD1\u3054\u304F\u81EA\u7136\u306Bhogehoge\u3081\u3044\u305F\u3063\u3066\u4F7F\u3046\u304B\u3089\uFF71\uFF72\uFF74\uFF74\uFF74\uFF74\uFF74",
  "id" : 357877288357986305,
  "created_at" : "2013-07-18 14:59:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357875541300363267",
  "text" : "\u3050\u308B\u3050\u308B\u9663\u5F62\u3058\u3083\uFF01\uFF01\uFF01",
  "id" : 357875541300363267,
  "created_at" : "2013-07-18 14:52:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357875493388824576",
  "text" : "\u3053\u306E\u30A2\u30A4\u30B3\u30F3\u306F\u300C\u3050\u308B\u3050\u308B\u300D\u3068\u3044\u3046\u5730\u56F3\u8A18\u53F7\u2026\u3058\u3083\u306A\u3044\uFF01",
  "id" : 357875493388824576,
  "created_at" : "2013-07-18 14:52:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357874326298558464",
  "text" : "\u3068\u308A\u304B\u3076\u3068\uFF0C\u306B\u306F\uFF0C\u6BD2\u304C\u3042\u308B\u266A\uFF08\u30D4\u30AF\u30DF\u30F3\u306E\u6B4C\u306E\u30EA\u30BA\u30E0\u3067\uFF09",
  "id" : 357874326298558464,
  "created_at" : "2013-07-18 14:47:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357874026317758465",
  "text" : "@reflexio \u652F\u96E2\u6EC5\u88C2\u306E\u201D\u652F\u96E2\u201D\u306B\u30C8\u30EA\u30AB\u30D6\u30C8\u306E\u201D\u30C8\u30EA\u201D\u3067\u201D\u3057\u308A\u3068\u308A\u201D",
  "id" : 357874026317758465,
  "created_at" : "2013-07-18 14:46:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357873081462697984",
  "text" : "\u300C\u811A\u529B\u300D\u3068\u304B\u3053\u306E\u4E00\u8A00\u3067\u5C0F\u3055\u306A\u8ECD\u968A\u306A\u3089\u6F70\u305B\u308B\u30EC\u30D9\u30EB\u306E\u9762\u767D\u30EF\u30FC\u30C9\u3060\u3068\u601D\u3046",
  "id" : 357873081462697984,
  "created_at" : "2013-07-18 14:42:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357872912176381952",
  "text" : "\u3061\u3087\u3063\u3068\u524D\u306B\u5F8C\u8F29\u304C\u3057\u308A\u3068\u308A\u3067\u8A00\u3063\u3066\u305F\u300C\u811A\u529B\u300D\u3068\u3044\u3046\u3053\u3068\u3070\u304C\u30C4\u30DC\u306B\u5165\u308A\u3059\u304E\u3066\u30C4\u30DC\u30C4\u30DC",
  "id" : 357872912176381952,
  "created_at" : "2013-07-18 14:42:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357872575453466624",
  "text" : "\u6700\u8FD1\u306F\u30AA\u30C9\u30B7\u30B7\u3082\u30A2\u30C4\u3044\u306A\u3063\u3066\u601D\u3063\u3066\u308B",
  "id" : 357872575453466624,
  "created_at" : "2013-07-18 14:40:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357872459338362880",
  "text" : "\u30A6\u30C4\u30C9\u30F3\u306F\u30AA\u30EF\u30B3\u30F3\u304B\u3082\u3057\u308C\u306A\u3044\u306A\uFF0E\u3053\u308C\u304B\u3089\u306F\u30C4\u30DC\u30C4\u30DC\u306E\u6642\u4EE3\u304B\uFF0E",
  "id" : 357872459338362880,
  "created_at" : "2013-07-18 14:40:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/LjX4cveurh",
      "expanded_url" : "http:\/\/kentei.cc\/k\/1037495\/",
      "display_url" : "kentei.cc\/k\/1037495\/"
    } ]
  },
  "geo" : { },
  "id_str" : "357872317436674048",
  "text" : "\u3069\u3046\u3057\u3066\u3053\u3093\u306A\u3082\u306E\u3092\u898B\u3066\u3044\u308B\u306E\u304B\u7686\u76EE\u898B\u5F53\u3082\u3064\u304B\u306A\u3044\uFF1A\u30C4\u30DC\u30C4\u30DC\u691C\u5B9A \u65E5\u672C\u6700\u5927\u7D1A\u306E\u30BD\u30FC\u30B7\u30E3\u30EB\u691C\u5B9A\uFF08\u30AF\u30A4\u30BA\uFF09\u30B5\u30A4\u30C8\u300C\u3051\u3093\u3066\u30FC\u3054\u3063\u3053\u300D http:\/\/t.co\/LjX4cveurh",
  "id" : 357872317436674048,
  "created_at" : "2013-07-18 14:39:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357832230762053632",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 357832230762053632,
  "created_at" : "2013-07-18 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aqusesu",
      "screen_name" : "aqusesu",
      "indices" : [ 0, 8 ],
      "id_str" : "220413789",
      "id" : 220413789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357778319032328192",
  "geo" : { },
  "id_str" : "357778745739841536",
  "in_reply_to_user_id" : 220413789,
  "text" : "@aqusesu (45\u5186\u306E\u5C0F\u5207\u624B\u898B\u305F\u3055\u306B\u9023\u7D61\u3059\u308B\u306E\u3082\u3044\u3044\u3067\u3059\u304C)\u3068\u306F\u3044\u3048\u5B9F\u969B\u4E07\u672D\u3068\u304B\u3060\u3068\u81EA\u8CA9\u6A5F\u4F7F\u308F\u306A\u3044\u9078\u629E\u80A2\u3092\u9078\u3073\u307E\u3059\u3088\u306D\u3047",
  "id" : 357778745739841536,
  "in_reply_to_status_id" : 357778319032328192,
  "created_at" : "2013-07-18 08:27:54 +0000",
  "in_reply_to_screen_name" : "aqusesu",
  "in_reply_to_user_id_str" : "220413789",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aqusesu",
      "screen_name" : "aqusesu",
      "indices" : [ 3, 11 ],
      "id_str" : "220413789",
      "id" : 220413789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "railgun",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357778080107986944",
  "text" : "RT @aqusesu: \u8D85\u96FB\u78C1\u7832\u898B\u3066\u3066\u300C\u81EA\u52D5\u8CA9\u58F2\u6A5F\u3067\u304A\u91D1\u98F2\u307E\u308C\u3066\u308B\uFF57\uFF57\uFF57\u306A\u3044\u308F\uFF57\uFF57\u308F\u308D\uFF57\uFF57\uFF57\u300D\u3068\u304B\u601D\u3063\u3066\u305F\u3051\u3069\u3001\u305D\u3046\u3044\u3084\u6700\u8FD1\u50D5\u3082\u81EA\u8CA9\u306B\u91D1\u98F2\u307E\u308C\u3066\u305F\u308F\uFF57\uFF57\uFF57\uFF57\u308F\u308D\uFF57\uFF57\uFF57\u3000#railgun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "railgun",
        "indices" : [ 72, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357777813211844608",
    "text" : "\u8D85\u96FB\u78C1\u7832\u898B\u3066\u3066\u300C\u81EA\u52D5\u8CA9\u58F2\u6A5F\u3067\u304A\u91D1\u98F2\u307E\u308C\u3066\u308B\uFF57\uFF57\uFF57\u306A\u3044\u308F\uFF57\uFF57\u308F\u308D\uFF57\uFF57\uFF57\u300D\u3068\u304B\u601D\u3063\u3066\u305F\u3051\u3069\u3001\u305D\u3046\u3044\u3084\u6700\u8FD1\u50D5\u3082\u81EA\u8CA9\u306B\u91D1\u98F2\u307E\u308C\u3066\u305F\u308F\uFF57\uFF57\uFF57\uFF57\u308F\u308D\uFF57\uFF57\uFF57\u3000#railgun",
    "id" : 357777813211844608,
    "created_at" : "2013-07-18 08:24:12 +0000",
    "user" : {
      "name" : "aqusesu",
      "screen_name" : "aqusesu",
      "protected" : false,
      "id_str" : "220413789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/584713560040706049\/4tBD0L9p_normal.png",
      "id" : 220413789,
      "verified" : false
    }
  },
  "id" : 357778080107986944,
  "created_at" : "2013-07-18 08:25:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357778035610624000",
  "text" : "150\u5186\u306E\u5C0F\u5207\u624B\u304C\u9001\u3089\u308C\u3066\u6765\u308B",
  "id" : 357778035610624000,
  "created_at" : "2013-07-18 08:25:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aqusesu",
      "screen_name" : "aqusesu",
      "indices" : [ 0, 8 ],
      "id_str" : "220413789",
      "id" : 220413789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357777813211844608",
  "geo" : { },
  "id_str" : "357777958892613632",
  "in_reply_to_user_id" : 220413789,
  "text" : "@aqusesu \u81EA\u8CA9\u6A5F\u306B\u66F8\u3044\u3066\u3042\u308B\u756A\u53F7\u306B\u96FB\u8A71\u3059\u308B\u3068\u8FD4\u3057\u3066\u3082\u3089\u3048\u307E\u3059\u3088\u30FC\u30FC",
  "id" : 357777958892613632,
  "in_reply_to_status_id" : 357777813211844608,
  "created_at" : "2013-07-18 08:24:47 +0000",
  "in_reply_to_screen_name" : "aqusesu",
  "in_reply_to_user_id_str" : "220413789",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3075\u308B\u30FC\u306B\u3083\u3093\u3068\u304B",
      "screen_name" : "phulud",
      "indices" : [ 0, 7 ],
      "id_str" : "413256531",
      "id" : 413256531
    }, {
      "name" : "\u0CED\u0A67(\u275B\u25BF\u275B\u273F)\u0A6D\u0CE8",
      "screen_name" : "cacapa_i",
      "indices" : [ 8, 17 ],
      "id_str" : "951767838",
      "id" : 951767838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357735026391134209",
  "geo" : { },
  "id_str" : "357777270984806400",
  "in_reply_to_user_id" : 413256531,
  "text" : "@phulud @cacapa_i \u30A2\u30A4\u30A8\u30A8\u30A8\u2026\u50D5\u306F\u9662\u8A66\u7D42\u308F\u308B\u307E\u3067\u51FA\u5E2D\u3057\u306A\u3044\u65B9\u91DD\u306A\u306E\u3067\u2026",
  "id" : 357777270984806400,
  "in_reply_to_status_id" : 357735026391134209,
  "created_at" : "2013-07-18 08:22:03 +0000",
  "in_reply_to_screen_name" : "phulud",
  "in_reply_to_user_id_str" : "413256531",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357710405289787392",
  "text" : "\u304B\u307C\u3061\u3083\u306E\u30AF\u30EA\u30FC\u30E0\u30D1\u30F3\u304C\u7F8E\u5473\u3057\u304F\u3066\u60B6\u7D76\u3057\u3066\u308B",
  "id" : 357710405289787392,
  "created_at" : "2013-07-18 03:56:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357699560996478976",
  "text" : "\u304A\u8179\u6E1B\u3063\u305F\u306A\u3041",
  "id" : 357699560996478976,
  "created_at" : "2013-07-18 03:13:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357690585223671811",
  "text" : "\u307E\u3041\u683C\u30B2\u30FC(?)\u306F\u306C\u308B\u30FC\u304F\u3057\u304B\u3084\u3063\u305F\u3053\u3068\u306A\u3044\u3051\u3069",
  "id" : 357690585223671811,
  "created_at" : "2013-07-18 02:37:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357690401118887936",
  "text" : "\u30D7\u30E9\u30AF\u30C6\u30A3\u30B9\u3067\u30B3\u30F3\u30DC\u7DF4\u7FD2\u3057\u3066\u30B3\u30F3\u30DC\u304C\u51FA\u308B\u3088\u3046\u306B\u306A\u3063\u3066\u304B\u3089\u5B9F\u6226\u3067\u5B89\u5B9A\u3059\u308B\u307E\u3067\u306E\u904E\u7A0B\u306B\u697D\u3057\u307F\u3092\u898B\u51FA\u3059\u754C\u9688",
  "id" : 357690401118887936,
  "created_at" : "2013-07-18 02:36:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357687307618357249",
  "text" : "\u8A08\u7B97\u7528\u7D19\u3092\u4E0A\u624B\u306B\u4F7F\u3048\u306A\u3044\u754C\u9688",
  "id" : 357687307618357249,
  "created_at" : "2013-07-18 02:24:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357686503649968132",
  "text" : "\u4E2D\u70B9\u9023\u7D50\u5B9A\u7406(\u30DC\u30BD\u30C3",
  "id" : 357686503649968132,
  "created_at" : "2013-07-18 02:21:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dars",
      "screen_name" : "daarrs",
      "indices" : [ 0, 7 ],
      "id_str" : "2575799821",
      "id" : 2575799821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357686060408516609",
  "text" : "@daarrs \u3053\u3063\u3061\u306F\u4F4F\u3093\u3067\u308B\u3068\u3053\u308D\u304C\u8FD1\u3044\u306E\u3067\u5076\u7136(?)\u3042\u3063\u305F\u308A\u3057\u307E\u3059\u3051\u308C\u3069\u6771\u4EAC\u3060\u3068\u6D41\u77F3\u306B\u306D\u3047\u2026",
  "id" : 357686060408516609,
  "created_at" : "2013-07-18 02:19:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u308D\u3058\u30FC",
      "screen_name" : "_logy",
      "indices" : [ 0, 6 ],
      "id_str" : "295560673",
      "id" : 295560673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357679564522143747",
  "geo" : { },
  "id_str" : "357679685817221120",
  "in_reply_to_user_id" : 295560673,
  "text" : "@_logy \u306A\u3093\u3060\u304B\u4E0D\u601D\u8B70\u306A\u611F\u3058is\u3059\u308B",
  "id" : 357679685817221120,
  "in_reply_to_status_id" : 357679564522143747,
  "created_at" : "2013-07-18 01:54:17 +0000",
  "in_reply_to_screen_name" : "_logy",
  "in_reply_to_user_id_str" : "295560673",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357679508347822081",
  "text" : "\u5999\u306A\u7E01\u3060\u306A\u30A1\u30A1",
  "id" : 357679508347822081,
  "created_at" : "2013-07-18 01:53:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357679455537336320",
  "text" : "\u308D\u3058\u30FC\u6C0F\u306B\u3082\u3060\u30FC\u3059\u6C0F\u306B\u3082\u3042\u3063\u305F\u3053\u3068\u3042\u308B\u306E\u79C1\u3060\u3051\u306A\u306E\u3067\u306F",
  "id" : 357679455537336320,
  "created_at" : "2013-07-18 01:53:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357676016040292352",
  "text" : "\u3066\u3066\u3066\u30FC\u3066\u308C\u3063\u3066\u30FC\u3066\u3066\u3066\u30FC\u3066\u308C\u3063\u3066\u30FC",
  "id" : 357676016040292352,
  "created_at" : "2013-07-18 01:39:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357656616948084736",
  "text" : "\u3089\uFF1F",
  "id" : 357656616948084736,
  "created_at" : "2013-07-18 00:22:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357656595716505600",
  "text" : "\u5348\u524D\u3068\u306F\u304B\u304F\u3082\u9577\u304D\u3082\u306E\u3060\u3063\u305F\u306E\u3060\u306A\u3041\u2026\u3068\u3089",
  "id" : 357656595716505600,
  "created_at" : "2013-07-18 00:22:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357479168809762816",
  "text" : "\u3082\u3046\u5BDD\u3088\u3046\u2026\u304A\u3084\u3059\u307F\uFF01",
  "id" : 357479168809762816,
  "created_at" : "2013-07-17 12:37:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357309577731121153",
  "text" : "\u958B\u3051\u305F\u3089\u9589\u3081\u308D",
  "id" : 357309577731121153,
  "created_at" : "2013-07-17 01:23:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357308199692541953",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 357308199692541953,
  "created_at" : "2013-07-17 01:18:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357298581360738304",
  "text" : "\u539F\u56E0:\u4E8C\u5EA6\u5BDD",
  "id" : 357298581360738304,
  "created_at" : "2013-07-17 00:39:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357298509164183553",
  "text" : "\u2026\u304A\u304B\u3057\u3044\u3001\u4E88\u5B9A\u3068\u9055\u3046",
  "id" : 357298509164183553,
  "created_at" : "2013-07-17 00:39:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357205346693021696",
  "text" : "\u307E\u305F\u3042\u3068\u3067\u3001\u304A\u3084\u3059\u307F",
  "id" : 357205346693021696,
  "created_at" : "2013-07-16 18:29:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357204608298397696",
  "text" : "\u5C0F1\u306E\u51AC\u306B\u6C17\u3065\u3044\u3066\u6B21\u306E\u5E74\u304B\u3089\u56DE\u907F\u3057\u3066\u305F\u3057\u5B9F\u969B\u9806\u5FDC\u306F\u3084\u3044",
  "id" : 357204608298397696,
  "created_at" : "2013-07-16 18:26:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357204478497263616",
  "text" : "\u3046\u3061\u306E\u89AA(\u7279\u306B\u7236\u89AA)\u306F\u7FD2\u5B57\u306F\u7FD2\u3063\u3066\u305F\u3093\u3060\u304B\u306A\u3093\u3060\u304C\u77E5\u3089\u3093\u3051\u3069\u975E\u5E38\u306B\u3046\u308B\u3055\u304B\u3063\u305F\u306E\u3067\u3001\u51AC\u4F11\u307F\u306E\u7FD2\u5B57\u306E\u5BBF\u984C\u306F\u7236\u89AA\u304C\u3044\u306A\u3044\u6642\u306B\u3084\u308B\u3088\u3046\u306B\u306A\u3063\u3066\u305F",
  "id" : 357204478497263616,
  "created_at" : "2013-07-16 18:25:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357200206330208259",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\uFF1F\uFF01\uFF1F\uFF01\u30D2\u30C9\u30A4=\u30EA\u30BA\u30E0\uFF1F\uFF01\uFF1F\uFF01",
  "id" : 357200206330208259,
  "created_at" : "2013-07-16 18:09:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357200090370289666",
  "text" : "3\u6642\u9593\u307B\u3069\u7720\u3063\u3066\u81EA\u7FD2\u5BA4\u884C\u304F\u304B\u2026[2,3,5\u9650\u304C\u69CB\u3048\u3066\u308B]",
  "id" : 357200090370289666,
  "created_at" : "2013-07-16 18:08:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357193129868275713",
  "text" : "\u540C\u6642\u671F\u306B\u3084\u3063\u3066\u305F\u300CC\u300DYouTube\u3067\u898B\u308C\u308B\u3057\u30AA\u30B9\u30B9\u30E1\u3057\u3066\u304A\u304D\u307E\u3059(\u30DC\u30BD\u30C3",
  "id" : 357193129868275713,
  "created_at" : "2013-07-16 17:40:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357193015187603458",
  "text" : "\u3042\u306E\u82B1\u3084\u3063\u3066\u308B\u306E\u304B",
  "id" : 357193015187603458,
  "created_at" : "2013-07-16 17:40:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357184849913720835",
  "text" : "\u725B\u4E73\u30C0\u30E1\u306B\u3057\u305F",
  "id" : 357184849913720835,
  "created_at" : "2013-07-16 17:07:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357184794544717824",
  "text" : "\u3069\u3046\u3082\u51B7\u8535\u5EAB\u304C\u6A5F\u80FD\u3057\u3066\u3044\u306A\u3044\u3063\u307D\u3044(\u51B7\u51CD\u5EAB\u306F\u52D5\u3044\u3066\u308B)",
  "id" : 357184794544717824,
  "created_at" : "2013-07-16 17:07:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357172846205734913",
  "text" : "\u30C6\u30FC\u30DE\u306F\u3001\u4E0B\u3089\u306A\u3051\u308C\u3070\u4E0B\u3089\u306A\u3044\u307B\u3069\u3044\u3044\u306A",
  "id" : 357172846205734913,
  "created_at" : "2013-07-16 16:20:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357172646472990722",
  "text" : "\u7D20\u4EBA\u304C\u30C6\u30FC\u30DE\u3092\u6C7A\u3081\u306A\u3044\u3067\u3084\u308Bgdgd\u3057\u305F\u30A2\u30EC\u306E\u76EE\u306E\u5F53\u3066\u3089\u308C\u306A\u3055\u306F\u30A2\u30EC\u3060\u304B\u3089\u306A",
  "id" : 357172646472990722,
  "created_at" : "2013-07-16 16:19:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357172543511216128",
  "text" : "\u3057\u3083\u3079\u308B\u30C6\u30FC\u30DE\u304F\u3089\u3044\u6C7A\u3081\u3066\u30C4\u30A4\u30AD\u30E3\u30B9\u3057\u305F\u3044\u306A\u30FC",
  "id" : 357172543511216128,
  "created_at" : "2013-07-16 16:19:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/FKCYfcqHTs",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=coxff2006",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357167536887963648",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/FKCYfcqHTs",
  "id" : 357167536887963648,
  "created_at" : "2013-07-16 15:59:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357140100917903361",
  "text" : "\u3053\u306E\u4E7E\u3044\u305F\u73FE\u72B6\u3067\u3082\u306A\u304A\u4E0D\u5473\u3044\"\u306C\u308B\u3044\u30B3\u30F3\u30C8\u30EC\u30C3\u30AF\u30B9\"\u306F\u4EBA\u985E\u304C\u751F\u307F\u51FA\u3057\u305F\u77E5\u6075\u306E\u4E00\u3064\u3060\u3068\u601D\u3046",
  "id" : 357140100917903361,
  "created_at" : "2013-07-16 14:10:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357139516701679617",
  "text" : "\u5589\u304C\u4E7E\u3044\u3066",
  "id" : 357139516701679617,
  "created_at" : "2013-07-16 14:07:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357139472133013505",
  "text" : "\u7D50\u5C4030\u5206\u3082\u5165\u3063\u3066\u3044\u305F\u306E\u304B\u2026",
  "id" : 357139472133013505,
  "created_at" : "2013-07-16 14:07:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357137645639446529",
  "text" : "\u3042\u304C\u308B\u3002",
  "id" : 357137645639446529,
  "created_at" : "2013-07-16 14:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357136658946207745",
  "text" : "\u52AA\u529B\u3092\u3057\u3066\u3044\u306A\u3044\u4EBA\u9593\u306F\u5606\u3044\u3066\u306F\u3044\u3051\u306A\u3044\uFF1F",
  "id" : 357136658946207745,
  "created_at" : "2013-07-16 13:56:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357136161132642304",
  "text" : "\u6C57\u304C\u6EF4\u308B\u306E\u306F\u3001\u697D\u3057\u3044",
  "id" : 357136161132642304,
  "created_at" : "2013-07-16 13:54:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357134371402170369",
  "text" : "\u5317\u6D77\u9053\u306F\u5B9F\u969B\u8D70\u308A\u3084\u3059\u3044",
  "id" : 357134371402170369,
  "created_at" : "2013-07-16 13:47:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357134287637721090",
  "text" : "@coxff2006 \u305D\u308C\u306F\u5FAE\u5999\u304B\u3082\u306A\u2026[\u305F\u3060\u30EC\u30F3\u30BF\u30AB\u30FC\u3082\u9AD8\u3044\u304B\u3089\u306A]",
  "id" : 357134287637721090,
  "created_at" : "2013-07-16 13:47:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357134049275424769",
  "text" : "\u4E16\u306E\u4E2D\u306B\u306F\u5927\u4E08\u592B\u3058\u3083\u306A\u3044\u3082\u306E\u304C\u6E80\u3061\u3066\u3044\u308B\u3053\u3068\u3060\u306A\u3041(\u8A60\u5606)",
  "id" : 357134049275424769,
  "created_at" : "2013-07-16 13:46:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357133728545382404",
  "text" : "@coxff2006 \u5317\u6D77\u9053\u306E\u8D70\u308A\u3084\u3059\u3055\u306F\u72AF\u7F6A\u7684\u3060\u304B\u3089\u5927\u4E08\u592B",
  "id" : 357133728545382404,
  "created_at" : "2013-07-16 13:44:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357133490048864257",
  "text" : "@mathile314 \u3044\u304F\u3068\u3057\u305F\u3089\u660E\u3051\u65B9\u306A\u306E\u3067\u591A\u5206\u5927\u4E08\u592B\u3067\u3059\u30FC[\u50D5\u306E\u751F\u6D3B\u30EA\u30BA\u30E0\u306F\u591A\u5206\u5927\u4E08\u592B\u3058\u3083\u306A\u3044\u3067\u3059\u30FC]",
  "id" : 357133490048864257,
  "created_at" : "2013-07-16 13:43:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357133069137879041",
  "text" : "\u305D\u3046\u304B\u2026\u5B66\u7FD2\u5BA424\u306F\u3042\u3044\u3066\u308B\u306E\u304B\u2026",
  "id" : 357133069137879041,
  "created_at" : "2013-07-16 13:42:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357132462255652864",
  "text" : "\u3075\u305F\u308A\u306F\u30DF\u30EB\u30AD\u30A3\u306A\u3093\u3061\u3083\u3089\u307F\u305F\u3051\u3069\u3042\u308C\u306F\u2026",
  "id" : 357132462255652864,
  "created_at" : "2013-07-16 13:39:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357131952870014977",
  "text" : "23\u6642\u307E\u3067\u9811\u5F35\u308D\u3046",
  "id" : 357131952870014977,
  "created_at" : "2013-07-16 13:37:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357131815095500801",
  "text" : "\u4E0D\u6442\u751F\u3092\u304A\u98A8\u5442\u3067\u8AA4\u9B54\u5316\u3057\u3066\u3044\u308B\u611F\u3058",
  "id" : 357131815095500801,
  "created_at" : "2013-07-16 13:37:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357131359283707904",
  "text" : "\u5FEB\u9069\u306A\u304A\u98A8\u5442\u3064\u3044\u3063\u305F\u30FC\u3089\u3044\u3075",
  "id" : 357131359283707904,
  "created_at" : "2013-07-16 13:35:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357131184607735808",
  "text" : "\u9577\u98A8\u5442",
  "id" : 357131184607735808,
  "created_at" : "2013-07-16 13:34:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357127369045196802",
  "text" : "\u9006\u3082\u306A",
  "id" : 357127369045196802,
  "created_at" : "2013-07-16 13:19:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 3, 12 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357127349176778752",
  "text" : "RT @kagakuma: \u9AEA\u3092\u5207\u3063\u305F\u4EBA\u306B\u300C\u30E1\u30AC\u30CD\u5909\u3048\u305F\uFF1F\u300D\u3063\u3066\u8A0A\u304F\u306E\u6D41\u884C\u3089\u305B\u3088\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357123917644705795",
    "text" : "\u9AEA\u3092\u5207\u3063\u305F\u4EBA\u306B\u300C\u30E1\u30AC\u30CD\u5909\u3048\u305F\uFF1F\u300D\u3063\u3066\u8A0A\u304F\u306E\u6D41\u884C\u3089\u305B\u3088\u3046",
    "id" : 357123917644705795,
    "created_at" : "2013-07-16 13:05:51 +0000",
    "user" : {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "protected" : false,
      "id_str" : "139989698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572354353332101120\/k1Z0v1cG_normal.jpeg",
      "id" : 139989698,
      "verified" : false
    }
  },
  "id" : 357127349176778752,
  "created_at" : "2013-07-16 13:19:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357112932464730114",
  "text" : "\u3069\u306E\u30C1\u30E7\u30B3\u30DF\u30F3\u30C8\u3082\u30DF\u30F3\u30C8\u304C\u5F31\u3044\u3068\u611F\u3058\u3066\u3057\u307E\u3046",
  "id" : 357112932464730114,
  "created_at" : "2013-07-16 12:22:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357112837547634690",
  "text" : "\u723D\u306E\u30C1\u30E7\u30B3\u30DF\u30F3\u30C8\u98DF\u3079\u3066\u308B",
  "id" : 357112837547634690,
  "created_at" : "2013-07-16 12:21:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357107328786501635",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 357107328786501635,
  "created_at" : "2013-07-16 11:59:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356864968584466435",
  "text" : "\u3069\u3046\u8EE2\u3093\u3067\u3082\u6B7B",
  "id" : 356864968584466435,
  "created_at" : "2013-07-15 19:56:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356864921759260672",
  "text" : "\u6B7B\u3093\u3060\u76EE\u3067\u8D77\u304D\u3066\u3066\u6B7B\u3093\u3060\u4E00\u65E5\u3092\u904E\u3054\u3059\u304B\u3001\u6B7B\u3093\u3060\u3088\u3046\u306B\u7720\u3063\u3066\u706B\u66DC\u65E5\u3092\u6B7B\u306A\u305B\u308B\u304B",
  "id" : 356864921759260672,
  "created_at" : "2013-07-15 19:56:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356863082288517120",
  "text" : "\u3053\u308A\u3083\u5BDD\u308B\u3079\u304D\u306A\u306E\u304B\u7121\u7406\u77E2\u7406\u76F4\u3059\u3079\u304D\u306A\u306E\u304B\u2026",
  "id" : 356863082288517120,
  "created_at" : "2013-07-15 19:49:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356862736610754560",
  "text" : "\u9854\u307E\u308F\u308A\u306F\u305D\u3046\u3067\u3082\u306A\u3044\u304C\u80CC\u4E2D\u304B\u3089\u9996\u306B\u304B\u3051\u3066\u3067\u304D\u3082\u306E\u306E\u6C17\u914D\u304C\u2026",
  "id" : 356862736610754560,
  "created_at" : "2013-07-15 19:48:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356862610647416832",
  "text" : "\u3053\u306E\u751F\u6D3B\u30EA\u30BA\u30E0\u3068\u98DF\u751F\u6D3B\u306E\u4E71\u308C\u306F\u826F\u304F\u306A\u3044\u306A\u2026",
  "id" : 356862610647416832,
  "created_at" : "2013-07-15 19:47:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356861048004952065",
  "text" : "\u3051\u3044\u3055\u3093\u3042\u308F\u306D\u30FC\u3068\u601D\u3044\u7D9A\u3051\u3066\u3053\u3093\u306A\u3058\u304B\u3093\u306B",
  "id" : 356861048004952065,
  "created_at" : "2013-07-15 19:41:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3046\u3093\u3053\u3051\u3068\u307F",
      "screen_name" : "_Mosstomi",
      "indices" : [ 0, 10 ],
      "id_str" : "1436955463",
      "id" : 1436955463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356624598999121922",
  "geo" : { },
  "id_str" : "356624820596781057",
  "in_reply_to_user_id" : 1436955463,
  "text" : "@_Mosstomi \u305D\u3082\u305D\u3082\u6708\u66DC\u6388\u696D\u306A\u3044\u4FFA\u306B\u306F\u6B7B\u89D2\u3060\u3063\u305F",
  "id" : 356624820596781057,
  "in_reply_to_status_id" : 356624598999121922,
  "created_at" : "2013-07-15 04:02:37 +0000",
  "in_reply_to_screen_name" : "_Mosstomi",
  "in_reply_to_user_id_str" : "1436955463",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "410natsuki529",
      "screen_name" : "tatyusa419",
      "indices" : [ 0, 11 ],
      "id_str" : "2531832002",
      "id" : 2531832002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356624674559496193",
  "text" : "@tatyusa419 \u304D\u304D\u304D\u3001\u6C17\u3065\u3044\u3066\u3044\u307E\u3057\u305F\u3068\u3082\u3055\uFF1F\uFF01",
  "id" : 356624674559496193,
  "created_at" : "2013-07-15 04:02:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356624375803424768",
  "text" : "\u6D77\u306E\u65E5\u2026\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\u2026",
  "id" : 356624375803424768,
  "created_at" : "2013-07-15 04:00:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356382601759559680",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 356382601759559680,
  "created_at" : "2013-07-14 12:00:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356020231581343745",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 356020231581343745,
  "created_at" : "2013-07-13 12:00:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355998613819764737",
  "text" : "\u92AD\u6E6F\u3068\u4E00\u7DD2\u3067410\u5186\u306A\u3089\u8FF7\u308F\u305A\u884C\u3063\u3066\u305F\u304C22:00\u307E\u3067\u3060\u3057\u3084\u3081\u3088\u3046",
  "id" : 355998613819764737,
  "created_at" : "2013-07-13 10:34:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355998209161703424",
  "text" : "\u30E9\u30B8\u30A6\u30E0\u6E29\u6CC9\u8ABF\u3079\u305F\u3089\u5165\u6D74\u3060\u3051\u3067\uFF11\uFF15\uFF10\uFF10\u5186\u304B\u2026\u3075\u3089\u3063\u3068\u306F\u884C\u304D\u306B\u304F\u3044\u306A\u2026",
  "id" : 355998209161703424,
  "created_at" : "2013-07-13 10:32:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355983205687496704",
  "text" : "\u305D\u3093\u306A\u3001\u9577\u3044\u546A\u6587\u805E\u304D\u305F\u304F\u306A\u3044\u305C\u30FC",
  "id" : 355983205687496704,
  "created_at" : "2013-07-13 09:33:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355983142563217408",
  "text" : "\u4EFB\u610F\u306Ehogehoge\u304C5\u3064\u7D9A\u3044\u3066,\u5B58\u5728\u3059\u308B\u3053\u3068\u306Ehugahuga\u304C3\u3064\u7D9A\u3044\u3066,\u3088\u3046\u3084\u304Fs.t",
  "id" : 355983142563217408,
  "created_at" : "2013-07-13 09:32:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355981044001939456",
  "text" : "\u300C\u653E\u5C04\u80FD\u306E\u305B\u3044\u3067hogehoge\u300D\u3063\u3066\u30C4\u30A4\u30FC\u30C8\u3057\u305F\u3044\u304C\u305F\u3081\u3060\u3051\u306B\u30E9\u30B8\u30A6\u30E0\u6E29\u6CC9\u884C\u3053\u3046\u304B\u8FF7\u3063\u3066\u3044\u308B",
  "id" : 355981044001939456,
  "created_at" : "2013-07-13 09:24:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355976703895552000",
  "text" : "\u3070\u306A\u306A\u3082\u3050\u3082\u3050",
  "id" : 355976703895552000,
  "created_at" : "2013-07-13 09:07:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355959230458642433",
  "text" : "\u4E00\u6708\u4EE5\u4E0A\u9023\u7D61\u3092\u8E8A\u8E87\u3059\u308B\u30E9\u30A4\u30D5\u30B9\u30BF\u30A4\u30EB\u3084\u3081\u305F\u3044",
  "id" : 355959230458642433,
  "created_at" : "2013-07-13 07:57:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355959139408683009",
  "text" : "\u304B\u307F\u306A\u304C\u3044\u3051\u3069\u304A\u91D1\u3042\u3093\u307E\u306A\u3044\u3057\u30EC\u30C3\u30B9\u30F3\u30AB\u30C3\u30C8\u30E2\u30C7\u30EB\u306E\u7533\u3057\u8FBC\u307F\u3057\u3066\u307F\u305F",
  "id" : 355959139408683009,
  "created_at" : "2013-07-13 07:57:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355923726648344578",
  "text" : "\u3055\u3066\u3001\u308A\u3060\u3064\u3046\u30FC",
  "id" : 355923726648344578,
  "created_at" : "2013-07-13 05:36:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355923052682420225",
  "text" : "\uFF1F",
  "id" : 355923052682420225,
  "created_at" : "2013-07-13 05:34:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355923041496207360",
  "text" : "\u300C\u4FFA\u81EA\u8EAB\u304C\u96F7\u306B\u306A\u308B\u3053\u3068\u3060.\u300D",
  "id" : 355923041496207360,
  "created_at" : "2013-07-13 05:34:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 8, 24 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355922745227350017",
  "geo" : { },
  "id_str" : "355922892011225088",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 @Jelly_in_a_tank \u9006\u306B\u5973\u306E\u5B50\u306B\u64AB\u3067\u3066\u3082\u3089\u3048\u3070\u89E3\u6C7A\u3059\u308B\u306E\u3067\u306F",
  "id" : 355922892011225088,
  "in_reply_to_status_id" : 355922745227350017,
  "created_at" : "2013-07-13 05:33:24 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355922725790945281",
  "text" : "\u901F\u3055\u3092\u5927\u5207\u306B\u306D\uFF01",
  "id" : 355922725790945281,
  "created_at" : "2013-07-13 05:32:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355922254288261121",
  "text" : "\"\u306A\u306B\u3082\u306A\u3044\"\u3082\u306A\u3044",
  "id" : 355922254288261121,
  "created_at" : "2013-07-13 05:30:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u54C1\u683C\u306E\u584A(\u6539)",
      "screen_name" : "noukoknows",
      "indices" : [ 0, 11 ],
      "id_str" : "348990022",
      "id" : 348990022
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 12, 28 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355921881280425984",
  "geo" : { },
  "id_str" : "355921951010729984",
  "in_reply_to_user_id" : 348990022,
  "text" : "@noukoknows @Jelly_in_a_tank \u5929\u4E95\u3082\u306A\u3044\u306E\u3067\u306F\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 355921951010729984,
  "in_reply_to_status_id" : 355921881280425984,
  "created_at" : "2013-07-13 05:29:40 +0000",
  "in_reply_to_screen_name" : "noukoknows",
  "in_reply_to_user_id_str" : "348990022",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 0, 14 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355921536907091968",
  "geo" : { },
  "id_str" : "355921672966123520",
  "in_reply_to_user_id" : 470868127,
  "text" : "@coscos2coscos \u304B\u307F\u306A\u308A\u300C\u305D\u306E\u4E00\u8A00\u3067\u843D\u3061\u307E\u3057\u305F\u300D",
  "id" : 355921672966123520,
  "in_reply_to_status_id" : 355921536907091968,
  "created_at" : "2013-07-13 05:28:34 +0000",
  "in_reply_to_screen_name" : "coscos2coscos",
  "in_reply_to_user_id_str" : "470868127",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355921510730440706",
  "text" : "\u96FB\u6C17\u306B\u4F9D\u5B58\u3057\u5207\u3063\u305F\u751F\u6D3B\u3057\u3066\u308B",
  "id" : 355921510730440706,
  "created_at" : "2013-07-13 05:27:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355921052565647360",
  "text" : "\u3057\u3066\u306A\u3044\u3051\u3069",
  "id" : 355921052565647360,
  "created_at" : "2013-07-13 05:26:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355921028817489920",
  "text" : "\u505C\u96FB\u3068\u304B\u3084\u3081\u3066\u6B32\u3057\u3044\u306D\u30FC",
  "id" : 355921028817489920,
  "created_at" : "2013-07-13 05:26:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355920321502650370",
  "text" : "\u96E8\u3082\u30AB\u30DF\u30CA\u30EA\u3082\u597D\u304D\u306B\u964D\u308A\u6CE8\u3044\u3067\u304F\u308C\u3066\u69CB\u308F\u306A\u3044\u305C\u30FC(\u5BB6\u304B\u3089\u51FA\u306A\u3044\u69CB\u3048)",
  "id" : 355920321502650370,
  "created_at" : "2013-07-13 05:23:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355916391481741313",
  "text" : "\u9D28\u5DDD\u306E\u3088\u3046\u3059\u3092\u307F\u306B\u884C\u304D\u305F\u304F\u306A\u308B\u306E\u3092\u582A\u3048\u3066\u308B.\u30B3\u30FC\u30D2\u30FC\u5165\u308C\u308B\u304B.",
  "id" : 355916391481741313,
  "created_at" : "2013-07-13 05:07:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355914567064367105",
  "text" : "\u30AA\u30C3\u30AB\u30E0\u306E\u30AB\u30DF\u30CA\u30EA",
  "id" : 355914567064367105,
  "created_at" : "2013-07-13 05:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355914485774548993",
  "text" : "\u5358\u4F4D\u3092\u843D\u3068\u3057\u305F\u4EBA\u304C100\u5E74\u5F8C\u306B\u6B7B\u3093\u3067\u3044\u308B\u78BA\u7387\u306F100%\u8FD1\u3044",
  "id" : 355914485774548993,
  "created_at" : "2013-07-13 05:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355913737758191617",
  "geo" : { },
  "id_str" : "355913932260655105",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 355913932260655105,
  "in_reply_to_status_id" : 355913737758191617,
  "created_at" : "2013-07-13 04:57:48 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355913815780638720",
  "text" : "\u3072\u3069\u304F\u3072\u3069\u304F\u3072\u3069\u3044\u96E8\u3060\u306A\u3041",
  "id" : 355913815780638720,
  "created_at" : "2013-07-13 04:57:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355907518838484992",
  "text" : "\u5BA4\u5185\u306B\u3044\u3066\u3082\u97FF\u304F\u96E8\u97F3\u3001\u3084\u3070",
  "id" : 355907518838484992,
  "created_at" : "2013-07-13 04:32:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355907297790275585",
  "text" : "\u3072\u3069\u3044\u96E8\u306E\u6A21\u69D8",
  "id" : 355907297790275585,
  "created_at" : "2013-07-13 04:31:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355888956598009858",
  "text" : "\u3046\u3081\u3072\u3084\u3057\u305D\u3046\u3081\u3093",
  "id" : 355888956598009858,
  "created_at" : "2013-07-13 03:18:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355698838918533120",
  "text" : "\u3057\u3083\u3063\u304F\u308A\u304C\u3068\u307E\u3089\u3093\u307D\u3093",
  "id" : 355698838918533120,
  "created_at" : "2013-07-12 14:43:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355688222740856833",
  "text" : "\u98A8\u5442\u4E0A\u308A\u6691\u304F\u3066\u6B7B\u306C",
  "id" : 355688222740856833,
  "created_at" : "2013-07-12 14:00:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355676858077032449",
  "text" : "\u65E5\u5E38\u30C4\u30A4\u30FC\u30C8\u3068\u304F\u3060\u3089\u306A\u3044\u30CD\u30BF\u30C4\u30A4\u30FC\u30C8\u3057\u304B\u3057\u3066\u306A\u304B\u3063\u305F\u4EBA\u9593\u304C\u65E5\u5E38\u30C4\u30A4\u30FC\u30C8\u3057\u306A\u304F\u306A\u3063\u305F\u3089\u3069\u3046\u306A\u308B\u304B.",
  "id" : 355676858077032449,
  "created_at" : "2013-07-12 13:15:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF2F\u5C71",
      "screen_name" : "oldham_10",
      "indices" : [ 0, 10 ],
      "id_str" : "559501096",
      "id" : 559501096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355676319444504577",
  "geo" : { },
  "id_str" : "355676689445031940",
  "in_reply_to_user_id" : 559501096,
  "text" : "@oldham_10 \u307E\u3041\u7279\u306B\u6700\u8FD1\u306F\u65E5\u5E38\u30C4\u30A4\u30FC\u30C8\u3082\u5C11\u306A\u3081\u3060\u3057\u306A\u30FC\u3002\u78BA\u304B\u306B\u5FD9\u3057\u3044\u632F\u308A\u3057\u3066\u308B\u306A\u30FC\u3002\u3044\u3084\u5B9F\u969B\u5FD9\u3057\u3044\u3051\u3069\u3002",
  "id" : 355676689445031940,
  "in_reply_to_status_id" : 355676319444504577,
  "created_at" : "2013-07-12 13:15:05 +0000",
  "in_reply_to_screen_name" : "oldham_10",
  "in_reply_to_user_id_str" : "559501096",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355676039038509056",
  "text" : "\u4ECA\u65E5\u3082\u4ECA\u65E5\u3068\u3066\u53CD\u5247\u52DD\u3061\u3092\u7A4D\u307F\u91CD\u306D\u3066\u3044\u308B\u6A21\u69D8",
  "id" : 355676039038509056,
  "created_at" : "2013-07-12 13:12:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF2F\u5C71",
      "screen_name" : "oldham_10",
      "indices" : [ 0, 10 ],
      "id_str" : "559501096",
      "id" : 559501096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355668386501500928",
  "geo" : { },
  "id_str" : "355675918473236480",
  "in_reply_to_user_id" : 559501096,
  "text" : "@oldham_10 \u305D\u3046\u3044\u3046\u30CD\u30BF\u3092\u5F97\u610F\u306B\u3057\u3066\u308B(\u3064\u3082\u308A)",
  "id" : 355675918473236480,
  "in_reply_to_status_id" : 355668386501500928,
  "created_at" : "2013-07-12 13:12:01 +0000",
  "in_reply_to_screen_name" : "oldham_10",
  "in_reply_to_user_id_str" : "559501096",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355663077984829440",
  "text" : "\u30B3\u30DD\u30F3\u30DD\u30B3 \u9006\u304B\u3089\u8AAD\u3093\u3067\u3082 \u30B3\u30DB\u30F3\u30DD\u30B3",
  "id" : 355663077984829440,
  "created_at" : "2013-07-12 12:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355662915677855744",
  "text" : "\u30B3\u30DD\u30F3\u30DD\u30B3 (\u30DD\u30F3\u30DD\u30B3\u306E\u53CC\u5BFE)",
  "id" : 355662915677855744,
  "created_at" : "2013-07-12 12:20:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 1, 11 ],
      "id_str" : "158645894",
      "id" : 158645894
    }, {
      "name" : "\u304D\u3063\u3053@\u3073\u3058\u3093\u306B\u306A\u308A\u305F\u3044",
      "screen_name" : "kikko_34a",
      "indices" : [ 12, 22 ],
      "id_str" : "1008547748",
      "id" : 1008547748
    }, {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 23, 31 ],
      "id_str" : "145536184",
      "id" : 145536184
    }, {
      "name" : "\u30A2\u30FC\u30B1",
      "screen_name" : "next_summer32",
      "indices" : [ 32, 46 ],
      "id_str" : "280403648",
      "id" : 280403648
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 48, 57 ],
      "id_str" : "96348838",
      "id" : 96348838
    }, {
      "name" : "\u3060\u30FC\u3059\u306A",
      "screen_name" : "DarknessCatX",
      "indices" : [ 59, 72 ],
      "id_str" : "258868251",
      "id" : 258868251
    }, {
      "name" : "\u516C\u5171\u4EA4\u901A\u6A5F\u95A2\u3092\u4F7F\u304A\u3046",
      "screen_name" : "yasuand",
      "indices" : [ 73, 81 ],
      "id_str" : "351349087",
      "id" : 351349087
    }, {
      "name" : "\u30C6\u30A4\u30EB\u30BA\u30FB\u30AA\u30D6\u30FB\u6F22\u30AA\u30BB\u30C1\u30A2@\u3075\u3093\u3059\uFF01",
      "screen_name" : "osetia_kaguya",
      "indices" : [ 82, 96 ],
      "id_str" : "56097393",
      "id" : 56097393
    }, {
      "name" : "\u304B\u3075\u3047\u3044\u3093\u304C\u305F\u308A\u306A\u3044\u3002",
      "screen_name" : "KishidaKus",
      "indices" : [ 97, 108 ],
      "id_str" : "1521726091",
      "id" : 1521726091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355498119665950720",
  "geo" : { },
  "id_str" : "355584227376508929",
  "in_reply_to_user_id" : 158645894,
  "text" : ".@eclair_15 @kikko_34a @chr1233 @next_summer32  @nisehorn  @DarknessCatX @yasuand @osetia_kaguya @KishidaKus \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 355584227376508929,
  "in_reply_to_status_id" : 355498119665950720,
  "created_at" : "2013-07-12 07:07:40 +0000",
  "in_reply_to_screen_name" : "eclair_15",
  "in_reply_to_user_id_str" : "158645894",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355582319471493121",
  "text" : "\u4E95\u6751\u5C4B\u3042\u305A\u304D\u30D0\u30FC\u3068\u30B5\u30F3\u30C8\u30EA\u30FC\u70CF\u9F8D\u8336\u3067\u6E80\u305F\u3055\u308C\u308B\u4EBA\u751F\u3060\u3063\u305F",
  "id" : 355582319471493121,
  "created_at" : "2013-07-12 07:00:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355498576920580096",
  "text" : "\u3060\u308C\u304C\u3068\u304F\u3059\u308B\u3093\u3060\u3053\u308C",
  "id" : 355498576920580096,
  "created_at" : "2013-07-12 01:27:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355498524852486144",
  "text" : "\u30D7\u30EB\u30BF\u30D6\u958B\u3051\u3089\u3093\u306A\u304B\u3063\u305F\u304B\u3089\u300C\u958B\u3051\u3089\u3093\u306A\u3044\u30FC\u300D\u3063\u3066\u8A00\u3063\u3066\u53CB\u4EBA\u306B\u958B\u3051\u3066\u3082\u3089\u3046\u3053\u3068\u3067\u304B\u5F31\u3044\u81EA\u5206\u3092\u6F14\u51FA\u3057\u305F",
  "id" : 355498524852486144,
  "created_at" : "2013-07-12 01:27:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355498082684772353",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 355498082684772353,
  "created_at" : "2013-07-12 01:25:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355466734062403584",
  "text" : "\u3042\u30FC\u3001\u3053\u308C\u982D\u75DB\u3067\u3059\u306D\u3047\u3001\u80A9\u3053\u308A\u3046\u3046\u3046",
  "id" : 355466734062403584,
  "created_at" : "2013-07-11 23:20:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355302719071854592",
  "text" : "\u300C\u3048\u3093\u3069\u3055\u3093\u5F7C\u5973\u5143\u6C17\uFF1F\u300D\n\u300C\u534A\u5206\u304F\u3089\u3044\u300D\n\u300C\u3048\u3093\u3069\u3055\u3093\u5F7C\u5973\u3044\u305F\u306E\uFF1F\u300D\n\u300C\u534A\u5206\u304F\u3089\u3044\u300D",
  "id" : 355302719071854592,
  "created_at" : "2013-07-11 12:29:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355295482702073856",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 355295482702073856,
  "created_at" : "2013-07-11 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355154612887629825",
  "text" : "\u30B5\u30F3\u30C0\u30FC\u30D5\u30A3\u30B9\u30C8\u306F\u306A\u304C\u30FC\u30FC\u30FC\u30FC\u30FC\u3044\u76EE\u3067\u5F85\u3064\u3053\u3068\u306B\u3057\u305F",
  "id" : 355154612887629825,
  "created_at" : "2013-07-11 02:40:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355154386982408192",
  "text" : "\u9577\u8896\u30DE\u30F3\u306F\u9577\u8896\u3092\u7740\u308B",
  "id" : 355154386982408192,
  "created_at" : "2013-07-11 02:39:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355154223761068033",
  "text" : "\u539A\u624B\u306E\u9577\u8896\u7740\u3066\u5BDD\u3066\u3082\u3001\u8584\u624B\u306E\u534A\u8896\u7740\u3066\u5BDD\u3066\u3082\u6C57\u3060\u304F\u3067\u8D77\u304D\u308B\u3057\u670D\u306F\u95A2\u4FC2\u306A\u3044\u306E\u3067\u306F(?)",
  "id" : 355154223761068033,
  "created_at" : "2013-07-11 02:39:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355152525294440448",
  "text" : "\uFF1F",
  "id" : 355152525294440448,
  "created_at" : "2013-07-11 02:32:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355152487763812355",
  "text" : "\u30B3\u30DF\u30E5\u529B\u3042\u308B\u304B\u3089\u9593\u9055\u3044\u96FB\u8A71\u306B\u300C\u9593\u9055\u3048\u3089\u308C\u3066\u307E\u3059\u3088\u300D\u3063\u3066\u8A00\u3048\u308B",
  "id" : 355152487763812355,
  "created_at" : "2013-07-11 02:32:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355151957264044034",
  "text" : "\u30AD\u30C3\u30AF\u30DC\u30FC\u30C9\u3067\u4E00\u822C\u9053\u3092\u99C6\u3051\u56DE\u308B\u5922\u3092\u898B\u305F",
  "id" : 355151957264044034,
  "created_at" : "2013-07-11 02:29:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355022406588444672",
  "text" : "\u30AB\u30C3\u30D7\u9EBA\u306E\u5BB9\u5668\u306E\u8ABF\u9054\u304C\u3059\u3067\u306B\u3081\u3093\u3069\u3046\u306A\u3042\u308C",
  "id" : 355022406588444672,
  "created_at" : "2013-07-10 17:55:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355022013590536192",
  "text" : "\u4E00\u6642\u9593\u76F4\u611F\u3068\u30BA\u30EC\u3066\u308B(\u3082\u30463\u6642\u30A2\u30A4\u30A8\u30A8\u30A8)",
  "id" : 355022013590536192,
  "created_at" : "2013-07-10 17:53:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    }, {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 10, 20 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/JFDNpAu4FK",
      "expanded_url" : "http:\/\/www.sakumc.com\/lite\/archives\/50054564.html",
      "display_url" : "sakumc.com\/lite\/archives\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "355021803313315841",
  "geo" : { },
  "id_str" : "355021891758592000",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco @wa_ta_si_ http:\/\/t.co\/JFDNpAu4FK \u3053\u306E\u3078\u3093\u9069\u5F53\u306B\u53C2\u8003\u306B\u30FC",
  "id" : 355021891758592000,
  "in_reply_to_status_id" : 355021803313315841,
  "created_at" : "2013-07-10 17:53:09 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    }, {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 10, 20 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355021377763418112",
  "geo" : { },
  "id_str" : "355021625764233217",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco @wa_ta_si_ \u30AB\u30C3\u30D7\u9EBA\u306E\u5BB9\u5668\u3068\u3063\u3066\u7F6E\u3044\u3066\u304A\u6E6F\u3068\u5375\u3044\u308C\u306610\u3060\u304B15\u5206\u3060\u304B\u653E\u7F6E\u3059\u308B\u3068\u6E29\u6CC9\u7389\u5B50\u306B\u306A\u308B",
  "id" : 355021625764233217,
  "in_reply_to_status_id" : 355021377763418112,
  "created_at" : "2013-07-10 17:52:06 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355017036876886016",
  "text" : "\u3072\u3069\u304F\u6CE5\u81ED\u3044\u30B4\u30EA\u62BC\u3057",
  "id" : 355017036876886016,
  "created_at" : "2013-07-10 17:33:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354970122059911169",
  "text" : "\u3082\u3057\u304B\u3057\u305F\u3089\u6211\u3005\u3082\u6F14\u5287\u3057\u3066\u308B\u306E\u304B\u3082\u3057\u308C\u306A\u3044:\u6DF7\u4E71",
  "id" : 354970122059911169,
  "created_at" : "2013-07-10 14:27:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354969877745897474",
  "text" : "(\u300D\u30FB\u03C9\u30FB)\u300D\u308F\u304B\u3089\u3093\uFF01(\uFF0F\u30FB\u03C9\u30FB)\uFF0F\u307D\u3049\u3049\u3049\u3049\u3049\u3093\u30FC\uFF01",
  "id" : 354969877745897474,
  "created_at" : "2013-07-10 14:26:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354969580323606528",
  "text" : "\u96A3\u306E\u30C6\u30FC\u30D6\u30EB\u306E\u5BA2\u3001\u4E00\u4F53\u306A\u3093\u306E\u96C6\u307E\u308A\u306A\u306E\u304B\u308F\u304B\u3089\u3093\u307D\u3093\u3060\u304C\u793E\u4F1A\u3092\u611F\u3058\u308B\u4F1A\u8A71\u3067\u3042\u308B",
  "id" : 354969580323606528,
  "created_at" : "2013-07-10 14:25:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354969286718132224",
  "text" : "\u82B3\u3057\u304F\u9999\u3070\u3057\u3044",
  "id" : 354969286718132224,
  "created_at" : "2013-07-10 14:24:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354969209941401600",
  "text" : "\u3046\u3075\u3075\u3075\u3075",
  "id" : 354969209941401600,
  "created_at" : "2013-07-10 14:23:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/o5HtbBcnG7",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=mayu_schwarz",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354960816371535876",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/o5HtbBcnG7",
  "id" : 354960816371535876,
  "created_at" : "2013-07-10 13:50:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354953976829054976",
  "text" : "\u89E3\u6790\u6599\u7406\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 354953976829054976,
  "created_at" : "2013-07-10 13:23:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354840896979746816",
  "text" : "\u30A2\u30A4\u30B9\u304C\u964D\u3063\u3066\u6765\u306A\u3044\uFF01\u8A34\u8A1F\uFF01",
  "id" : 354840896979746816,
  "created_at" : "2013-07-10 05:53:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354654289630740480",
  "text" : "\u306D\u308B\u306D\u308B\u306D\u308B\u30FC\u30AA\u30E4\u30B9\u30DF\uFF01",
  "id" : 354654289630740480,
  "created_at" : "2013-07-09 17:32:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354654227450167297",
  "text" : "\u5C71\u7F8A\u306F\u30E4\u30AE\u306B\u901A\u3058\u3061\u3083\u3046\u3068\u3053\u308D\u304C\u3042\u308B\u304B\u3089\u306A\u3041\u2026",
  "id" : 354654227450167297,
  "created_at" : "2013-07-09 17:32:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354653860167565312",
  "text" : "\u5C71\u7F8A\u3063\u3066\u98DF\u3079\u308C\u308B\u306E\uFF1F",
  "id" : 354653860167565312,
  "created_at" : "2013-07-09 17:30:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354653043624640512",
  "text" : "\u52A0\u901F\u3059\u308B\u96D1\u3055",
  "id" : 354653043624640512,
  "created_at" : "2013-07-09 17:27:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354652603684093957",
  "geo" : { },
  "id_str" : "354653001106989057",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u57CB\u3081\u3089\u308C\u305F\u5C71\u7F8A\u300C\u30A6\u30E1\u30FC\u300D",
  "id" : 354653001106989057,
  "in_reply_to_status_id" : 354652603684093957,
  "created_at" : "2013-07-09 17:27:19 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354652246950166529",
  "text" : "that's \u96D1",
  "id" : 354652246950166529,
  "created_at" : "2013-07-09 17:24:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354651764592611328",
  "geo" : { },
  "id_str" : "354652170886451202",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u6885\u306E\u304A\u8336\u6F2C\u3051\u306F\u3046\u3081\u30FC",
  "id" : 354652170886451202,
  "in_reply_to_status_id" : 354651764592611328,
  "created_at" : "2013-07-09 17:24:01 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354650059008262145",
  "text" : "\u504F\u3063\u305F\u98DF\u3001\u3064\u307E\u308A\u504F\u98DF\u3067\u3042\u308B\u3002",
  "id" : 354650059008262145,
  "created_at" : "2013-07-09 17:15:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354649976585990146",
  "text" : "\u30D5\u30EB\u30FC\u30C4\u3060\u3051\u98DF\u3079\u3066\u751F\u304D\u3066\u3044\u305F\u3044\u4EBA\u751F\u3060\u3063\u305F.\u5869\u5206\u306F\u30AA\u30EA\u30FC\u30D6\u3068\u304B\u9F67\u308A\u305F\u3044.",
  "id" : 354649976585990146,
  "created_at" : "2013-07-09 17:15:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354648737487925250",
  "text" : "\u30B9\u30A4\u30AB\u3088\u308A\u30E1\u30ED\u30F3\u306E\u65B9\u304C\u597D\u304D\u3060\u3068\u78BA\u4FE1\u3057\u305F",
  "id" : 354648737487925250,
  "created_at" : "2013-07-09 17:10:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354648657259270144",
  "text" : "\u30E1\u30ED\u30F330\u500B\u3082\u98DF\u3079\u308B\u30E8\u30C3\u30B7\u30FC\u306F\u3042\u306E\u52AA\u529B\u3092\u3057\u3066\u3057\u304B\u308B\u3079\u304D\u3060\u306A\u3041\u3068",
  "id" : 354648657259270144,
  "created_at" : "2013-07-09 17:10:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354648343248502787",
  "text" : "\u5931\u793C\u3057\u307E\u3057\u305F",
  "id" : 354648343248502787,
  "created_at" : "2013-07-09 17:08:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354648322172125185",
  "text" : "\u9BDB\u306Ewww\u91DC\u3081\u3057\u3092www\u98DF\u3079\u305F\u3044wwwwwww",
  "id" : 354648322172125185,
  "created_at" : "2013-07-09 17:08:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354648038062555136",
  "geo" : { },
  "id_str" : "354648153594671104",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u91DC\u3081\u3057\u98DF\u3079\u305F\u3044\u3001\u304A\u8336\u6F2C\u3051\u3067\u3082\u3044\u3044",
  "id" : 354648153594671104,
  "in_reply_to_status_id" : 354648038062555136,
  "created_at" : "2013-07-09 17:08:03 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354648019322417153",
  "text" : "tex\u306F\u6163\u308C\u3068\u74B0\u5883\u8A2D\u5B9A (\uFF1F)",
  "id" : 354648019322417153,
  "created_at" : "2013-07-09 17:07:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354647611782873088",
  "geo" : { },
  "id_str" : "354647835087605762",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u79C1\u306F\u30D5\u30EB\u30FC\u30C4\u304C\u597D\u304D\u3067\u3059\n\u3044\u3048\u3001\u4ED6\u610F\u306F\u3042\u308A\u307E\u305B\u3093",
  "id" : 354647835087605762,
  "in_reply_to_status_id" : 354647611782873088,
  "created_at" : "2013-07-09 17:06:47 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354647310631837696",
  "text" : "\u3088\u304F\u51B7\u3048\u305F\u3042\u3093\u307F\u3064\u3068\u3088\u304F\u51B7\u3048\u305F\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u306E\u932C\u91D1\u8853\u5E2B\u3092\u547C\u3073\u305F\u3044",
  "id" : 354647310631837696,
  "created_at" : "2013-07-09 17:04:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354647186929238016",
  "text" : "\u3088\u304F\u51B7\u3048\u305F\u3042\u3093\u307F\u3064\u3068\u3088\u304F\u51B7\u3048\u305F\u30A2\u30A4\u30B9\u30B3\u30FC\u30D2\u30FC\u304C\u6B32\u3057\u3044",
  "id" : 354647186929238016,
  "created_at" : "2013-07-09 17:04:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354646447435677697",
  "text" : "\u96C6\u4E2D\u529B\u30B9\u30A4\u30C3\u30C1\u3068\u7720\u6C17\u30B9\u30A4\u30C3\u30C1\u304C\u6B32\u3057\u3044\u3002\u30AA\u30F3\u3068\u30AA\u30D5\u304C\u306F\u3063\u304D\u308A\u3057\u306A\u3044\u3002",
  "id" : 354646447435677697,
  "created_at" : "2013-07-09 17:01:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354645841815932928",
  "text" : "\u30D5\u30EB\u30FC\u30C6\u30A3\u306A\u30D5\u30EB\u30FC\u30C4\u3060\u3063\u305F\u3002",
  "id" : 354645841815932928,
  "created_at" : "2013-07-09 16:58:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6628\u65E5\u306F\u30D5\u30EB\u30FC\u30C4\u65E5\u548C\u3060\u3063\u305F\u3053\u3068\u3060\u306A\u3041",
      "indices" : [ 4, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354645777311731712",
  "text" : "\u30E1\u30ED\u30F3\uFF01#\u6628\u65E5\u306F\u30D5\u30EB\u30FC\u30C4\u65E5\u548C\u3060\u3063\u305F\u3053\u3068\u3060\u306A\u3041",
  "id" : 354645777311731712,
  "created_at" : "2013-07-09 16:58:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354645380450893827",
  "text" : "\\\u7834\u9B54\u77E2!!\/",
  "id" : 354645380450893827,
  "created_at" : "2013-07-09 16:57:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354645161504022528",
  "text" : "bio\u3061\u3087\u3063\u3068\u5909\u3048\u305F\u3002\u601D\u8003\u505C\u6B62\u3002",
  "id" : 354645161504022528,
  "created_at" : "2013-07-09 16:56:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354642575803686916",
  "text" : "\u6642\u9593\u304C\u8DB3\u308A\u306A\u3044\u306E\u306F\u4E8B\u5B9F\u3060\u304C\u306A\u305C\u6642\u9593\u304C\u8DB3\u308A\u306A\u3044\u306E\u304B\u3068\u8A00\u308F\u308C\u305F\u3089\u52AA\u529B\u304C\u8DB3\u308A\u306A\u3044\u304B\u3089\u3067\u3042\u308B\u306A\uFF1F",
  "id" : 354642575803686916,
  "created_at" : "2013-07-09 16:45:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354614154763579392",
  "text" : "\u3042 \u3064 \u3044",
  "id" : 354614154763579392,
  "created_at" : "2013-07-09 14:52:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354570626826117120",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 354570626826117120,
  "created_at" : "2013-07-09 11:59:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354542135128752128",
  "text" : "\u3072\u3068\u3093\u3061\u3067\u52DD\u624B\u306B\u9B54\u5973\u306E\u5B85\u6025\u4FBF\u3092\u898B\u59CB\u3081\u305F\u4E0A\u306B\u52DD\u624B\u306B\u30B3\u30FC\u30D2\u30FC\u3044\u308C\u306F\u3058\u3081\u305F",
  "id" : 354542135128752128,
  "created_at" : "2013-07-09 10:06:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354482377969500160",
  "text" : "\u3067\u3082300\u4E07\u304C\u964D\u3063\u3066\u6E67\u3044\u3066\u4E91\u3005\u3060\u3063\u305F\u3089\u50D5\u306F1\u5186\u3057\u304B\u3042\u3052\u307E\u305B\u3093\u3074\u3087",
  "id" : 354482377969500160,
  "created_at" : "2013-07-09 06:09:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354482219705839617",
  "text" : "\u3074\u3087\uFF01",
  "id" : 354482219705839617,
  "created_at" : "2013-07-09 06:08:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354480693394415618",
  "text" : "\u30AD\u30E7\u30A6\u30CF\u30C8\u30C6\u30E2\u30A2\u30BF\u30BF\u30AB\u30A4\u30C7\u30B9\u30CD",
  "id" : 354480693394415618,
  "created_at" : "2013-07-09 06:02:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354479352546721792",
  "text" : "\u30BC\u30EA\u30FC\u6C0F\u30FC\u30FC\u30FC\u9023\u7D61\u3057\u3061\u304F\u308A\u30FC\u30FC\u30FC",
  "id" : 354479352546721792,
  "created_at" : "2013-07-09 05:57:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354448463108374529",
  "text" : "\u3044\u3084\u307E\u3041\u793E\u5B85\u306E\u5EAD\u306B\u713C\u5374\u7089\u307F\u305F\u3044\u306E\u304A\u3044\u3066\u3042\u3063\u305F\u3057\u306A\u2026",
  "id" : 354448463108374529,
  "created_at" : "2013-07-09 03:54:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354448317603786754",
  "text" : "\u3042\u306E\u7126\u3052\u305F\u3088\u3046\u306A\u5302\u3044\u3001\u7D50\u69CB\u597D\u304D\u3060\u3063\u305F\u3093\u3060\u3051\u3069",
  "id" : 354448317603786754,
  "created_at" : "2013-07-09 03:53:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354448253468680195",
  "text" : "\u6614\u306F\u7236\u89AA\u304C\u3088\u304F\u30C0\u30F3\u30DC\u30FC\u30EB\u3068\u304B\u71C3\u3048\u308B\u3054\u307F\u3092\u713C\u3044\u3066\u305F\u3051\u3069\u4ECA\u306F\u305D\u3046\u3044\u3046\u3053\u3068\u3084\u308C\u308B\u5834\u6240\u3082\u306A\u3044\u3057\u3084\u3063\u3061\u3083\u30C0\u30E1\u306A\u3093\u3060\u3088\u306A\u3041",
  "id" : 354448253468680195,
  "created_at" : "2013-07-09 03:53:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354419867585232896",
  "text" : "\u30A8\u30B9\u30D7\u30EC\u30C3\u30BD\u306B\u8D85\u786C\u6C34\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 354419867585232896,
  "created_at" : "2013-07-09 02:00:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354418642219302913",
  "text" : "\u307B\u3093\u3068\u3046\u306E\u30A2\u30A4\u30B9\u30AB\u30D5\u30A7\u30E9\u30C6\u3092",
  "id" : 354418642219302913,
  "created_at" : "2013-07-09 01:56:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354414871644872706",
  "text" : "\u30D5\u30EB\u30FC\u30C4\u306FQOL\u3092\u4E0A\u3052\u308B\u3053\u3068\u3060\u306A\u3041",
  "id" : 354414871644872706,
  "created_at" : "2013-07-09 01:41:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354414780578140160",
  "text" : "\u826F\u304F\u719F\u308C\u3066\u826F\u304F\u51B7\u3048\u305F\u7F8E\u5473\u3057\u3044\u30D6\u30C9\u30A6\u3060\u3063\u305F\uFF0E\u3068\u3044\u3046\u304B\u3042\u30681\u9031\u9593\u3082\u3057\u305F\u3089\u98DF\u3079\u3089\u308C\u306A\u304F\u306A\u3063\u3066\u305F\u3060\u308D\u3046\uFF0E",
  "id" : 354414780578140160,
  "created_at" : "2013-07-09 01:40:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354290107752267776",
  "text" : "\u3055\u3041\u3055\u3041\u5BDD\u308B\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 354290107752267776,
  "created_at" : "2013-07-08 17:25:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354290044640567296",
  "text" : "\u3057\u304B\u3057\u307D\u3066\u3056\u304D\u6C0F\u3001\u826F\u3044\u30BB\u30F3\u30B9\u3067\u3042\u308B(\u306A\u306B\u3081\u305B\u3093\uFF1F)",
  "id" : 354290044640567296,
  "created_at" : "2013-07-08 17:25:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354289904135569408",
  "text" : "\u307E\u3055\u304B\u304D\u306E\u80E1\u6563\u81ED\u3055\u3082\u975E\u5E38\u306B\u826F\u3044",
  "id" : 354289904135569408,
  "created_at" : "2013-07-08 17:24:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354289776574201857",
  "text" : "wiki\u3067\u7279\u5178\u306BCD\u3064\u304F\u3068\u304D\u3044\u3066\u3061\u3087\u3063\u3068\u3086\u3089\u3050",
  "id" : 354289776574201857,
  "created_at" : "2013-07-08 17:23:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354289575587356672",
  "text" : "\u3076\u3063\u3061\u3083\u3051\u4F59\u88D5\u3042\u3063\u305F\u3089\u30D6\u30EB\u30FC\u30EC\u30A4\u6B32\u3057\u3044",
  "id" : 354289575587356672,
  "created_at" : "2013-07-08 17:23:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354289420943364100",
  "text" : "@potezaki \u3042\u308C\u3042\u3093\u304C\u3044\u898B\u3066\u308B\u4EBA\u5C11\u306A\u304F\u3066\u60B2\u3057\u3044\u304B\u3089YouTube\u3067\u5E83\u307E\u3063\u3066\u6B32\u3057\u3044\u3068\u601D\u3046",
  "id" : 354289420943364100,
  "created_at" : "2013-07-08 17:22:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354289274482470912",
  "text" : "\u307E\u3041\u3044\u304F\u3064\u304B\u5927\u5207\u305D\u3046\u306A\u30C7\u30A3\u30FC\u30EB\u3092\u5927\u80C6\u306B\u30AB\u30C3\u30C8\u3057\u3066\u305F\u306E\u3068\u540C\u7D1A\u751F\u306E\u5973\u306E\u5B50\u306E\u6271\u3044\u3060\u3051\u7591\u554F\u7B26\u3060\u3051\u3069\u3001\u305D\u308C\u4EE5\u5916\u306F\u6587\u53E5\u306A\u3057\u3089",
  "id" : 354289274482470912,
  "created_at" : "2013-07-08 17:22:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354289047268638720",
  "text" : "OP\u3082ED\u3082\u3044\u3044\u611F\u3058\u3060\u3063\u305F\u3057",
  "id" : 354289047268638720,
  "created_at" : "2013-07-08 17:21:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354288879781675009",
  "text" : "\uFF31\u306E\u30AD\u30E3\u30E9\u306F\u826F\u3044\u5473\u3092\u51FA\u3057\u3066\u3044\u305F\u3068\u601D\u3046\u3057\u3001\u30B5\u30C8\u30A6\u3055\u3093\u306E\u6700\u5F8C\u306E\u30C7\u30A3\u30FC\u30EB\u3082\u63FA\u3055\u3076\u3089\u308C\u308B\u30A2\u30C4\u3055\u304C\u3042\u3063\u305F",
  "id" : 354288879781675009,
  "created_at" : "2013-07-08 17:20:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354288582313246720",
  "text" : "YouTube\u3067\u898B\u308C\u308B\u306E\u3067\u6687\u306A\u3089\u898B\u3066\u6B32\u3057\u3044\u306E\u3067\u3059",
  "id" : 354288582313246720,
  "created_at" : "2013-07-08 17:19:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354288312044888064",
  "text" : "\u3084\u306F\u308Ac\u306F\u826F\u30A2\u30CB\u30E1\u3060\u3063\u305F\u3068\u601D\u3046\u306E\u3067\u3059",
  "id" : 354288312044888064,
  "created_at" : "2013-07-08 17:18:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354287723034591233",
  "text" : "C 11\u8A71\u3001\u6539\u3081\u3066\u6C17\u5408\u5165\u3063\u3066\u308B\u306A\u3041\u3001\u4F5C\u753B\u3068\u304B\u3088\u304F\u306F\u308F\u304B\u3089\u306A\u3044\u3051\u3069",
  "id" : 354287723034591233,
  "created_at" : "2013-07-08 17:15:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354165159704539136",
  "text" : "TL\u3092\u96E2\u308C\u307E\u3059.",
  "id" : 354165159704539136,
  "created_at" : "2013-07-08 09:08:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354164866895986688",
  "text" : "\"\u53CD\u5247\u52DD\u3061\u3092\u7A4D\u307F\u91CD\u306D\u308B\u601D\u8003\u505C\u6B62\u30ED\u30DC\u30C3\u30C8\"\u3068\u3044\u3046\u30A2\u30A4\u30C7\u30F3\u30C6\u30A3\u30C6\u30A3\u3092\u52DD\u3061\u5F97\u3064\u3064\u3042\u308B.",
  "id" : 354164866895986688,
  "created_at" : "2013-07-08 09:07:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354164403668664320",
  "text" : "\u3081\u3093\u3069\u304F\u3055\u3044\u7528\u4E8B\u306F\u3001\u5B9F\u969B\u3081\u3093\u3069\u304F\u3055\u3044.\u306A\u305C\u306A\u3089,\u3081\u3093\u3069\u304F\u3055\u3044\u7528\u4E8B\u306F\u5B9F\u969B\u3081\u3093\u3069\u304F\u3055\u3044\u304B\u3089\u3067\u3042\u308B.",
  "id" : 354164403668664320,
  "created_at" : "2013-07-08 09:05:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354163726766702593",
  "text" : "\u30C9\u30FC\u30E2,\u30D5\u30A9\u30ED\u30EF\u30FC=\u30B5\u30F3,\u601D\u8003\u505C\u6B62\u30ED\u30DC\u30C3\u30C8\u3067\u3059.",
  "id" : 354163726766702593,
  "created_at" : "2013-07-08 09:03:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354163037034397696",
  "text" : "\u307E\u3069\u30DE\u30AE\u53A8\u306B\u300C\u307E\u3069\u6D3E\uFF1F\u30DE\u30AE\u6D3E\uFF1F\u300D\u3063\u3066\u805E\u304F\u3068\u5012\u305B\u308B",
  "id" : 354163037034397696,
  "created_at" : "2013-07-08 09:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354162039700201472",
  "text" : "\u3082\u30466\u6642\u3068\u304B\u8A00\u3046\u30C7\u30DE\u3001\u4ECA\u65E5\u306F\u65E9\u3081\u306B\u5BDD\u3066\u65E9\u304F\u8D77\u304D\u3088\u3046\u2026",
  "id" : 354162039700201472,
  "created_at" : "2013-07-08 08:56:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354161368762548226",
  "text" : "\u30DD\u30B9\u30C8\u30A4\u30C3\u30C8\u3068\u304B",
  "id" : 354161368762548226,
  "created_at" : "2013-07-08 08:53:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3084\u3057",
      "screen_name" : "t_hayashi",
      "indices" : [ 3, 13 ],
      "id_str" : "16704005",
      "id" : 16704005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354161336323805184",
  "text" : "RT @t_hayashi: \u3064\u307E\u308A\u3001\u666E\u901A\u540D\u8A5E\u3068\u56FA\u6709\u540D\u8A5E\u306E\u6DF7\u540C\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354160623447314433",
    "text" : "\u3064\u307E\u308A\u3001\u666E\u901A\u540D\u8A5E\u3068\u56FA\u6709\u540D\u8A5E\u306E\u6DF7\u540C\u3002",
    "id" : 354160623447314433,
    "created_at" : "2013-07-08 08:50:47 +0000",
    "user" : {
      "name" : "\u306F\u3084\u3057",
      "screen_name" : "t_hayashi",
      "protected" : false,
      "id_str" : "16704005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3200773560\/e9c91cd9c8ffb0087e46de8e42554b22_normal.jpeg",
      "id" : 16704005,
      "verified" : false
    }
  },
  "id" : 354161336323805184,
  "created_at" : "2013-07-08 08:53:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354159305383084032",
  "text" : "\u30B0\u30EC\u30D6\/\u30CA\u30FC\u30AD\u30C6\u30A3\u3061\u3083\u3093\u3068\u304B\u3044\u308D\u3044\u308D\u8003\u3048\u3089\u308C\u308B\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 354159305383084032,
  "created_at" : "2013-07-08 08:45:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30C7\u30B6\u30A4\u30F3\u3060\u308C\u304B\u8003\u3048\u3066",
      "indices" : [ 9, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354159162869022720",
  "text" : "\u76F4\u4EA4\u30AD\u30C6\u30A3\u3061\u3083\u3093 #\u30C7\u30B6\u30A4\u30F3\u3060\u308C\u304B\u8003\u3048\u3066",
  "id" : 354159162869022720,
  "created_at" : "2013-07-08 08:44:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354136941572268033",
  "text" : "\u601D\u8003\u505C\u6B62\u30DE\u30B7\u30FC\u30F3\u3068\u304B\u601D\u8003\u505C\u6B62\u30A2\u30F3\u30C9\u30ED\u30A4\u30C9\u3068\u304B\u3044\u308D\u3044\u308D\u51FA\u3066\u6765\u3066\u697D\u3057\u304B\u3063\u305F",
  "id" : 354136941572268033,
  "created_at" : "2013-07-08 07:16:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354136838207832065",
  "text" : "\u30C6\u30F3\u30D7\u30EC\u5ACC\u3044\u306E\u53CB\u4EBA\u304B\u3089\u300C\u304A\u524D\u3001\u601D\u8003\u505C\u6B62\u30ED\u30DC\u30C3\u30C8\u307F\u305F\u3044\u3060\u306A\u300D\u3063\u3066\u8A00\u308F\u308C\u3066\u300C\u5F37\u305D\u3046\uFF01\uFF01\u300D\u3063\u3066\u53CD\u5C04\u3067\u7B54\u3048\u305F\u30A2\u30AB\u30A6\u30F3\u30C8\u304C\u3053\u3061\u3089",
  "id" : 354136838207832065,
  "created_at" : "2013-07-08 07:16:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354136200996601856",
  "text" : "\"\u305B\u3084\u304B\u3066\u99C6\u52D5\"\u306E\u6280\u8853\u304C\u78BA\u7ACB\u3055\u308C\u3066\u304B\u3089\u30E2\u30FC\u30BF\u30FC\u30B9\u30DD\u30FC\u30C4\u754C\u304C\u305A\u3044\u3076\u3093\u5909\u308F\u3063\u305F\u3088\u306D\u30FC\u3001\u307F\u305F\u3044\u306A\u8A71\u3067\u76DB\u308A\u4E0A\u304C\u3063\u305F",
  "id" : 354136200996601856,
  "created_at" : "2013-07-08 07:13:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354082337274859520",
  "text" : "\u3042\u308C\u30FC\u3001\u6628\u65E5\u306E\u671D\u3054\u306F\u3093\u4EE5\u6765\u308D\u304F\u306B\u3054\u306F\u3093\u98DF\u3079\u3066\u306A\u3044\u305E\u30FC\uFF1F\uFF1F",
  "id" : 354082337274859520,
  "created_at" : "2013-07-08 03:39:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353845903423062016",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 353845903423062016,
  "created_at" : "2013-07-07 12:00:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353762857973854209",
  "text" : "@reflexio \u6765\u308B\u307E\u3067\u6765\u306A\u3044\u306E\u306F\u5F53\u305F\u308A\u524D\u3060\u308D(\u307E\u304C\u304A)",
  "id" : 353762857973854209,
  "created_at" : "2013-07-07 06:30:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E8C\u6761\u305B\u3089\u3075@\u3081\u3044\u305D",
      "screen_name" : "seraph_2",
      "indices" : [ 0, 9 ],
      "id_str" : "194178083",
      "id" : 194178083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353751225075904514",
  "geo" : { },
  "id_str" : "353751301663883265",
  "in_reply_to_user_id" : 194178083,
  "text" : "@seraph_2 Amazon\u611F",
  "id" : 353751301663883265,
  "in_reply_to_status_id" : 353751225075904514,
  "created_at" : "2013-07-07 05:44:17 +0000",
  "in_reply_to_screen_name" : "seraph_2",
  "in_reply_to_user_id_str" : "194178083",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353750870409752576",
  "geo" : { },
  "id_str" : "353751043605135360",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u4E86\u89E3\u3057\u307E\u3057\u305F(?)",
  "id" : 353751043605135360,
  "in_reply_to_status_id" : 353750870409752576,
  "created_at" : "2013-07-07 05:43:15 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "indices" : [ 3, 11 ],
      "id_str" : "16331213",
      "id" : 16331213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353750973346365441",
  "text" : "RT @kazoo04: 18\u6642\u306B\u65B0\u5BBF\u306B\u884C\u304D\u307E\u3059\u3002\u624B\u6BB5\u306F\u6559\u3048\u3089\u308C\u307E\u305B\u3093\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "353750818157101057",
    "text" : "18\u6642\u306B\u65B0\u5BBF\u306B\u884C\u304D\u307E\u3059\u3002\u624B\u6BB5\u306F\u6559\u3048\u3089\u308C\u307E\u305B\u3093\u3002",
    "id" : 353750818157101057,
    "created_at" : "2013-07-07 05:42:22 +0000",
    "user" : {
      "name" : "\u304B\u305A\u30FC",
      "screen_name" : "kazoo04",
      "protected" : false,
      "id_str" : "16331213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583129549694640129\/aPkbezAe_normal.png",
      "id" : 16331213,
      "verified" : false
    }
  },
  "id" : 353750973346365441,
  "created_at" : "2013-07-07 05:42:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353750950869082114",
  "text" : "\u30D8\u30EA\u3067\u65B0\u5BBF\u306B\u964D\u308A\u7ACB\u3064\u304B\u305A\u30FC\u6C0F\u3092\u60F3\u50CF\u3057\u305F",
  "id" : 353750950869082114,
  "created_at" : "2013-07-07 05:42:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353750829032943617",
  "text" : "\u9AEA\u4F38\u3073\u904E\u304E\u3066\u3084\u3070\u3044\u3001\u30E9\u30EB\u30C8\u30B9\u307F\u305F\u3044\u306B\u306A\u3063\u3066\u308B",
  "id" : 353750829032943617,
  "created_at" : "2013-07-07 05:42:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353750612845928448",
  "geo" : { },
  "id_str" : "353750746317066242",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u304A\u91D1\u304F\u308C\u308B\u306A\u3089\u884C\u304D\u307E\u3059(",
  "id" : 353750746317066242,
  "in_reply_to_status_id" : 353750612845928448,
  "created_at" : "2013-07-07 05:42:04 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353750472751972353",
  "text" : "\u77ED\u518A\u30C4\u30A4\u30FC\u30C8\u9B31\u9676\u3057\u3044\u3051\u3069\u6642\u3005\u9762\u767D\u3044",
  "id" : 353750472751972353,
  "created_at" : "2013-07-07 05:40:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353742764908879872",
  "text" : "2\/3\u8EAB\u6D74\u306F15\u5206\u304C\u9650\u754C\u3060\u306A\u2026",
  "id" : 353742764908879872,
  "created_at" : "2013-07-07 05:10:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353533870970388482",
  "text" : "\u622F\u8A00\u30B7\u30EA\u30FC\u30BA\u3088\u308A\u5148\u306B\u30BC\u30ED\u30B5\u30AD\u30B7\u30EA\u30FC\u30BA\u3001\u3057\u304B\u3082\u4EBA\u9593\u30B7\u30EA\u30FC\u30BA\u304B\u3089\u8AAD\u3093\u3060\u7570\u7AEF\u306F\u79C1\u3067\u3059",
  "id" : 353533870970388482,
  "created_at" : "2013-07-06 15:20:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3085\u3089",
      "screen_name" : "syura1357",
      "indices" : [ 0, 10 ],
      "id_str" : "336807456",
      "id" : 336807456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353533188922015745",
  "geo" : { },
  "id_str" : "353533290252210176",
  "in_reply_to_user_id" : 336807456,
  "text" : "@syura1357 \u50D5\u306F\u4E16\u754C\u30B7\u30EA\u30FC\u30BA\u304C\u3057\u3063\u304F\u308A\u304D\u307E\u305B\u3093",
  "id" : 353533290252210176,
  "in_reply_to_status_id" : 353533188922015745,
  "created_at" : "2013-07-06 15:17:59 +0000",
  "in_reply_to_screen_name" : "syura1357",
  "in_reply_to_user_id_str" : "336807456",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353532564201422848",
  "text" : "\u3064\u30FC\u304B\u50B7\u7269\u8A9E\u3060\u3088\uFF01\uFF01\uFF01\uFF01\u307E\u3060\u306A\u306E\uFF01\uFF01",
  "id" : 353532564201422848,
  "created_at" : "2013-07-06 15:15:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353532494139764736",
  "text" : "\u82B1\u7269\u8A9E\u304C\u4F55\u3088\u308A\u697D\u3057\u307F",
  "id" : 353532494139764736,
  "created_at" : "2013-07-06 15:14:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353531991246897153",
  "text" : "\u7269\u8A9E\u30B7\u30EA\u30FC\u30BA\u306E\u5B9F\u6CC1\u306F\u65E9\u901F\u30DF\u30E5\u30FC\u30C8",
  "id" : 353531991246897153,
  "created_at" : "2013-07-06 15:12:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353531768265125888",
  "text" : "\u5091\u4F5C\u3060",
  "id" : 353531768265125888,
  "created_at" : "2013-07-06 15:11:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3085\u3089",
      "screen_name" : "syura1357",
      "indices" : [ 3, 13 ],
      "id_str" : "336807456",
      "id" : 336807456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353531753400508417",
  "text" : "RT @syura1357: \u6700\u8FD1\u3001\u7269\u8A9E\u30B7\u30EA\u30FC\u30BA\u306F\u672C\u7269\u306E\u897F\u5C3E\u30D5\u30A1\u30F3\u306B\u622F\u8A00\u30B7\u30EA\u30FC\u30BA\u306E\u8A71\u632F\u3089\u308C\u3066\u7D76\u53E5\u3059\u308B\u306B\u308F\u304B\u3092\u7099\u308A\u51FA\u3059\u305F\u3081\u306E\u6492\u304D\u990C\u3058\u3083\u306A\u3044\u306E\u304B\u3068\u601D\u3046\u3088\u3046\u306B\u306A\u3063\u3066\u304D\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "353531558331809796",
    "text" : "\u6700\u8FD1\u3001\u7269\u8A9E\u30B7\u30EA\u30FC\u30BA\u306F\u672C\u7269\u306E\u897F\u5C3E\u30D5\u30A1\u30F3\u306B\u622F\u8A00\u30B7\u30EA\u30FC\u30BA\u306E\u8A71\u632F\u3089\u308C\u3066\u7D76\u53E5\u3059\u308B\u306B\u308F\u304B\u3092\u7099\u308A\u51FA\u3059\u305F\u3081\u306E\u6492\u304D\u990C\u3058\u3083\u306A\u3044\u306E\u304B\u3068\u601D\u3046\u3088\u3046\u306B\u306A\u3063\u3066\u304D\u305F\u3002",
    "id" : 353531558331809796,
    "created_at" : "2013-07-06 15:11:06 +0000",
    "user" : {
      "name" : "\u3057\u3085\u3089",
      "screen_name" : "syura1357",
      "protected" : false,
      "id_str" : "336807456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1446116025\/cat15_01_normal.jpg",
      "id" : 336807456,
      "verified" : false
    }
  },
  "id" : 353531753400508417,
  "created_at" : "2013-07-06 15:11:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353530853642608640",
  "text" : "\u30AB\u30E9\u30B9\u98FC\u3044\u305F\u3044",
  "id" : 353530853642608640,
  "created_at" : "2013-07-06 15:08:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353529671410921475",
  "text" : "\u3064\u3070\u3055\u30BF\u30A4\u30AC\u30FC\u2026",
  "id" : 353529671410921475,
  "created_at" : "2013-07-06 15:03:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353529118274494466",
  "text" : "\u30D0\u30BF\u3082\u3061\u3001\u30AB\u30ED\u30EA\u30FC\u9AD8\u305D\u3046",
  "id" : 353529118274494466,
  "created_at" : "2013-07-06 15:01:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353529062192455681",
  "text" : "\u68DA\u304B\u3089\u30D0\u30BF\u3082\u3061",
  "id" : 353529062192455681,
  "created_at" : "2013-07-06 15:01:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353527312542732289",
  "text" : "\u3053\u3093\u306A\u3053\u3068\u3082\u3042\u308D\u3046\u304B\u3068\u3001\u30A2\u30A4\u30B9\u3092\u8CB7\u3063\u3066\u3042\u308B",
  "id" : 353527312542732289,
  "created_at" : "2013-07-06 14:54:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353523315610103808",
  "text" : "@DAIKICHIinKUS \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 353523315610103808,
  "created_at" : "2013-07-06 14:38:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353483536180846592",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 353483536180846592,
  "created_at" : "2013-07-06 12:00:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353459499417337858",
  "text" : "\u901F\u5831:\u30BC\u30EA\u30FC\u3055\u3093\u3001\u30B3\u30FC\u30D2\u30FC\u30BC\u30EA\u30FC\u3092\u6CE8\u6587",
  "id" : 353459499417337858,
  "created_at" : "2013-07-06 10:24:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353414201726861314",
  "text" : "\u307E\u3041\u3088\u3044\u3001\u920D\u611F\u306A\u30D5\u30EA\u3092\u3057\u3066\u304A\u3053\u3046",
  "id" : 353414201726861314,
  "created_at" : "2013-07-06 07:24:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353414106600054784",
  "text" : "\u306A\u30FC\u3093\u304B\u614B\u5EA6\u60AA\u3044\u306A\u2026",
  "id" : 353414106600054784,
  "created_at" : "2013-07-06 07:24:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353175693787537408",
  "geo" : { },
  "id_str" : "353264333775581184",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 \u4F1A\u8A71\u306E\u624B\u6CD5\u3084\u3089\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u304C\u975E\u5E38\u306B\u30C7\u30B8\u30E3\u30D6\u3067\u697D\u3057\u3044",
  "id" : 353264333775581184,
  "in_reply_to_status_id" : 353175693787537408,
  "created_at" : "2013-07-05 21:29:15 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353264075897176065",
  "geo" : { },
  "id_str" : "353264144792829952",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 353264144792829952,
  "in_reply_to_status_id" : 353264075897176065,
  "created_at" : "2013-07-05 21:28:30 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353175635289587712",
  "text" : "\u3072\u3068\u3093\u3061\u3067\u3086\u3086\u5F0F\u898B\u3066\u308B\u3051\u3069\u3086\u305A\u3053\u304B\u308F\u3044\u3044",
  "id" : 353175635289587712,
  "created_at" : "2013-07-05 15:36:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353155272539242497",
  "text" : "\u304B\u3093\u3068\u308A\u30FC\u308D\u30FC\u30FC\u30FC",
  "id" : 353155272539242497,
  "created_at" : "2013-07-05 14:15:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30D6\u30AF\u30ED\u306B\u5FC3\u596A\u308F\u308C\u3066\u30018\u5E74",
      "screen_name" : "Ikemeal5296",
      "indices" : [ 0, 12 ],
      "id_str" : "251331667",
      "id" : 251331667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353150443288924162",
  "geo" : { },
  "id_str" : "353153392929030144",
  "in_reply_to_user_id" : 251331667,
  "text" : "@Ikemeal5296 \u7F8E\u5473\u3057\u304B\u3063\u305F\u3067\u3059\u3088\u30FC\u3054\u307E\u6CB9\u306E\u611F\u3058",
  "id" : 353153392929030144,
  "in_reply_to_status_id" : 353150443288924162,
  "created_at" : "2013-07-05 14:08:24 +0000",
  "in_reply_to_screen_name" : "Ikemeal5296",
  "in_reply_to_user_id_str" : "251331667",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u304BC\u30C9\u30A5\u30FC",
      "screen_name" : "hiroskii_mk2",
      "indices" : [ 0, 13 ],
      "id_str" : "247411674",
      "id" : 247411674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u308F\u304B\u308B",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353114297704005632",
  "geo" : { },
  "id_str" : "353114595415691265",
  "in_reply_to_user_id" : 247411674,
  "text" : "@hiroskii_mk2 #\u308F\u304B\u308B",
  "id" : 353114595415691265,
  "in_reply_to_status_id" : 353114297704005632,
  "created_at" : "2013-07-05 11:34:14 +0000",
  "in_reply_to_screen_name" : "hiroskii_mk2",
  "in_reply_to_user_id_str" : "247411674",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u304BC\u30C9\u30A5\u30FC",
      "screen_name" : "hiroskii_mk2",
      "indices" : [ 0, 13 ],
      "id_str" : "247411674",
      "id" : 247411674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353113352911851520",
  "geo" : { },
  "id_str" : "353113589025996802",
  "in_reply_to_user_id" : 247411674,
  "text" : "@hiroskii_mk2 \u7F8E\u5473\u3057\u3044\u3067\u3059\u3088\u306D\uFF01\uFF01",
  "id" : 353113589025996802,
  "in_reply_to_status_id" : 353113352911851520,
  "created_at" : "2013-07-05 11:30:14 +0000",
  "in_reply_to_screen_name" : "hiroskii_mk2",
  "in_reply_to_user_id_str" : "247411674",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u304BC\u30C9\u30A5\u30FC",
      "screen_name" : "hiroskii_mk2",
      "indices" : [ 0, 13 ],
      "id_str" : "247411674",
      "id" : 247411674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353112998740627457",
  "geo" : { },
  "id_str" : "353113209043025920",
  "in_reply_to_user_id" : 247411674,
  "text" : "@hiroskii_mk2 \u3076\u3069\u3046\u30B8\u30E5\u30FC\u30B9\u306F\u3069\u3046\u3067\u3059\u304B\uFF1F",
  "id" : 353113209043025920,
  "in_reply_to_status_id" : 353112998740627457,
  "created_at" : "2013-07-05 11:28:44 +0000",
  "in_reply_to_screen_name" : "hiroskii_mk2",
  "in_reply_to_user_id_str" : "247411674",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353112922748239872",
  "text" : "\u8304\u5B50\u306E\u5B57\u304C\u9055\u3063\u305F",
  "id" : 353112922748239872,
  "created_at" : "2013-07-05 11:27:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353112819228606465",
  "text" : "@reflexio \u4ECA\u306E\u753B\u50CF\u306F\u90A3\u9808\u3067\u3059\u3001\u3063\u3066\u610F\u5473\u3067\u3059\u306D\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 353112819228606465,
  "created_at" : "2013-07-05 11:27:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353109463558930432",
  "text" : "\u3042\u3001\u3044\u307E\u306E\u306A\u3059",
  "id" : 353109463558930432,
  "created_at" : "2013-07-05 11:13:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/353109401713926144\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/DaI15I5KUB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOZ_IUhCYAAmhrv.jpg",
      "id_str" : "353109401718120448",
      "id" : 353109401718120448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOZ_IUhCYAAmhrv.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/DaI15I5KUB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353109401713926144",
  "text" : "\u306A\u3059\u3059\u3079\u3082\u306A\u3044 http:\/\/t.co\/DaI15I5KUB",
  "id" : 353109401713926144,
  "created_at" : "2013-07-05 11:13:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352993006686715904",
  "text" : "\u624B\u6570\u6599840\u5186\u306F\u5B9F\u969B\u9AD8\u3044\u305C\u3043\u2026",
  "id" : 352993006686715904,
  "created_at" : "2013-07-05 03:31:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352992888784822272",
  "text" : "\u3042\u3001\u6700\u901F\u9662\u6B7B\u306F\u56DE\u907F\u3057\u307E\u3057\u305F\u30FC",
  "id" : 352992888784822272,
  "created_at" : "2013-07-05 03:30:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352826803498389505",
  "text" : "\u5348\u524D\u4E2D\u306B\u8D77\u304D\u3066\u632F\u308A\u3053\u307F\u3068\u304B\u3057\u306A\u3044\u3068\u6700\u901F\u9662\u6B7B\u3092\u30AD\u30E1\u308B\u3053\u3068\u306B\u306A\u308B",
  "id" : 352826803498389505,
  "created_at" : "2013-07-04 16:30:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352826616361136130",
  "text" : "\u30A2\u30DE\u30AA\u30C8\u30B5\u30EF\u30AC\u30B7",
  "id" : 352826616361136130,
  "created_at" : "2013-07-04 16:29:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352768832609320961",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 352768832609320961,
  "created_at" : "2013-07-04 12:40:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/r259Dg3pWe",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=ka1lium",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352740801937289216",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/r259Dg3pWe",
  "id" : 352740801937289216,
  "created_at" : "2013-07-04 10:48:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352711030813626368",
  "text" : "\u7518\u3063\uFF01\u3063\u3066\u306A\u308B\u305F\u3081\u306B\u5C0F\u5CA9\u4E95\u306E\u30AB\u30D5\u30A7\u30AA\u30EC\u8CB7\u3063\u305F\u3051\u3069\u7518\u3063\uFF01",
  "id" : 352711030813626368,
  "created_at" : "2013-07-04 08:50:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3075\u308B\u30FC\u306B\u3083\u3093\u3068\u304B",
      "screen_name" : "phulud",
      "indices" : [ 0, 7 ],
      "id_str" : "413256531",
      "id" : 413256531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352664651315679232",
  "geo" : { },
  "id_str" : "352664757293158401",
  "in_reply_to_user_id" : 413256531,
  "text" : "@phulud \u5357\uFF01",
  "id" : 352664757293158401,
  "in_reply_to_status_id" : 352664651315679232,
  "created_at" : "2013-07-04 05:46:44 +0000",
  "in_reply_to_screen_name" : "phulud",
  "in_reply_to_user_id_str" : "413256531",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352618235012718594",
  "text" : "\uFF1F",
  "id" : 352618235012718594,
  "created_at" : "2013-07-04 02:41:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352618221028904961",
  "text" : "\u30A2\u30A4\u30C9\u30EB\u3088\u308A\u30CF\u30FC\u30C9\u30EB\u306E\u65B9\u304C\u9762\u767D\u3044\u306E\u3067\u306F",
  "id" : 352618221028904961,
  "created_at" : "2013-07-04 02:41:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352617937137438722",
  "geo" : { },
  "id_str" : "352618132143226880",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u4F4E\u304F\u3066\u3082\u304F\u3050\u308B\u30EA\u30F3\u30DC\u30FC\u7684\u904A\u3073\u65B9\u3082\u51FA\u6765\u308B\u3057\u30CF\u30FC\u30C9\u30EB\u306F\u4FBF\u5229\u3060\u306A\u301C",
  "id" : 352618132143226880,
  "in_reply_to_status_id" : 352617937137438722,
  "created_at" : "2013-07-04 02:41:28 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352617390560903168",
  "geo" : { },
  "id_str" : "352617657931005953",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u3042\u308A\u3083\u3001\u3058\u3083\u3042\u307E\u3061\u304C\u3063\u3066\u307E\u3059\u306D",
  "id" : 352617657931005953,
  "in_reply_to_status_id" : 352617390560903168,
  "created_at" : "2013-07-04 02:39:35 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352617456411475969",
  "geo" : { },
  "id_str" : "352617589647736832",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u3082\u3063\u3068\u7A81\u62CD\u5B50\u3082\u306A\u3044\u3053\u3068\u3092\u8A00\u308F\u306A\u3044\u3068\u306A\u3093\u3067\u3059\u304B\u30CF\u30FC\u30C9\u30EB\u9AD8\u3044\u9AD8\u3044",
  "id" : 352617589647736832,
  "in_reply_to_status_id" : 352617456411475969,
  "created_at" : "2013-07-04 02:39:19 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352617203201355777",
  "text" : "\u30A2\u30EB\u30AB\u30D1\uFF1F\u30A2\u30EB\u30D1\u30AB\uFF1F",
  "id" : 352617203201355777,
  "created_at" : "2013-07-04 02:37:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352617078584381441",
  "text" : "\u30CE\u30A6\u30A2\u30EB\u30AB\u30D1\u306F\u722A\u3092\u96A0\u3059:\u30CE\u30A6\u30A2\u30EB\u30AB\u30D1\u3068\u8A00\u3046\u7A2E\u985E\u306E\u30A2\u30EB\u30AB\u30D1\u306F\u722A\u3092\u96A0\u3059\u7FD2\u6027\u304C\u3042\u308B\u3002",
  "id" : 352617078584381441,
  "created_at" : "2013-07-04 02:37:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352614432645459969",
  "geo" : { },
  "id_str" : "352614605886988288",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u4F55\u305D\u308C\u7F8E\u5473\u3057\u305D\u3046\u3001\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 352614605886988288,
  "in_reply_to_status_id" : 352614432645459969,
  "created_at" : "2013-07-04 02:27:27 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352614024778752000",
  "text" : "\u6700\u8FD1\u30B5\u30D6\u30A6\u30A7\u30A4\u884C\u3063\u3066\u306A\u3044\u306A\u3041\u2026",
  "id" : 352614024778752000,
  "created_at" : "2013-07-04 02:25:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352613700227694592",
  "geo" : { },
  "id_str" : "352613923838627840",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u304F\u308F\u3057\u304F\uFF01\uFF01",
  "id" : 352613923838627840,
  "in_reply_to_status_id" : 352613700227694592,
  "created_at" : "2013-07-04 02:24:45 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352612891763032066",
  "text" : "\u3042\u3073\u304D\u3087\u3046\u304B\u3093\u3001\u3057\u308A\u3081\u3064\u308C\u3064",
  "id" : 352612891763032066,
  "created_at" : "2013-07-04 02:20:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352612328681914369",
  "text" : "\u5F15\u3063\u8D8A\u3057\u305F\u308A\u5B9F\u5BB6\u306B\u5E30\u3063\u305F\u308A\u3059\u308B\u5922\u898B\u305F",
  "id" : 352612328681914369,
  "created_at" : "2013-07-04 02:18:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352462190814572544",
  "text" : "\u3053\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u6620\u753B\u898B\u306B\u3044\u304F\u306E\u3082\u306A\u3041\u3001\u7269\u8A9E\u7684\u306B\u3082\u3001\u3084\u308B\u3079\u304D\u4E8B\u7684\u306B\u3082\u2026",
  "id" : 352462190814572544,
  "created_at" : "2013-07-03 16:21:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352461899503382528",
  "text" : "\u5148\u8F29\u306B\u8A71\u3092\u632F\u3089\u308C\u3066\u6C17\u4ED8\u3044\u305F\u885D\u6483",
  "id" : 352461899503382528,
  "created_at" : "2013-07-03 16:20:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352461772143329282",
  "text" : "\u8A00\u306E\u8449\u306E\u5EAD\u3001\u6620\u753B\u5316\u3088\u308A\u5148\u306B\u30B3\u30DF\u30AB\u30E9\u30A4\u30BA\u3092\u77E5\u3063\u305F\u5999\u306A\u30B7\u30E7\u30FC\u30D2\u30B7\u30E3\u3067\u3059",
  "id" : 352461772143329282,
  "created_at" : "2013-07-03 16:20:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352426917061869569",
  "text" : "A4\u4E8C\u679A\u5206\u3001\u8CEA\u554F\u3055\u308C\u308B\u4E8B\u307E\u3067\u52A0\u5473\u3057\u3066\u66F8\u3051\u308B\u6642\u9593\u306F\u3042\u308B\u306E\u304B\u2026\uFF1F",
  "id" : 352426917061869569,
  "created_at" : "2013-07-03 14:01:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352426751693045760",
  "text" : "\u3053\u308C\u2026\u3084\u3070\u2026",
  "id" : 352426751693045760,
  "created_at" : "2013-07-03 14:01:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\uFF65\u03C9\uFF65)",
      "screen_name" : "Gal_Jaco",
      "indices" : [ 0, 9 ],
      "id_str" : "1088490829",
      "id" : 1088490829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352423531222544384",
  "geo" : { },
  "id_str" : "352424770375131136",
  "in_reply_to_user_id" : 1088490829,
  "text" : "@Gal_Jaco \u307B\u3093\u3068\u3060\u2026\u4ECA\u66F4\u3060\u3057\u3084\u3081\u3068\u304F\u308F\u301C",
  "id" : 352424770375131136,
  "in_reply_to_status_id" : 352423531222544384,
  "created_at" : "2013-07-03 13:53:07 +0000",
  "in_reply_to_screen_name" : "Gal_Jaco",
  "in_reply_to_user_id_str" : "1088490829",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CompactHausdorff\u5C71\u7530",
      "screen_name" : "NoriMathTp",
      "indices" : [ 0, 11 ],
      "id_str" : "231358679",
      "id" : 231358679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352416400985427968",
  "geo" : { },
  "id_str" : "352416502718275585",
  "in_reply_to_user_id" : 231358679,
  "text" : "@NoriMathTp \u30A2\u30A4\u30A8\u30A8\u30A8\u2026",
  "id" : 352416502718275585,
  "in_reply_to_status_id" : 352416400985427968,
  "created_at" : "2013-07-03 13:20:16 +0000",
  "in_reply_to_screen_name" : "NoriMathTp",
  "in_reply_to_user_id_str" : "231358679",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352416056159109120",
  "text" : "\u9858\u66F8\u66F8\u304B\u306A\u304D\u3083\u2026",
  "id" : 352416056159109120,
  "created_at" : "2013-07-03 13:18:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CompactHausdorff\u5C71\u7530",
      "screen_name" : "NoriMathTp",
      "indices" : [ 0, 11 ],
      "id_str" : "231358679",
      "id" : 231358679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352415937363853312",
  "geo" : { },
  "id_str" : "352415996537085954",
  "in_reply_to_user_id" : 231358679,
  "text" : "@NoriMathTp \u308F\u308A\u3068\u7CBE\u795E\u885B\u751F\u306B\u826F\u304F\u306A\u3044",
  "id" : 352415996537085954,
  "in_reply_to_status_id" : 352415937363853312,
  "created_at" : "2013-07-03 13:18:15 +0000",
  "in_reply_to_screen_name" : "NoriMathTp",
  "in_reply_to_user_id_str" : "231358679",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352415928597741568",
  "text" : "\u7D61\u307F\u65B9\u306E\u96D1\u3055\u306F\u5BFE\u7B49\u3067\u3042\u308B\u3079\u304D\u3068\u306E\u58F0\u660E",
  "id" : 352415928597741568,
  "created_at" : "2013-07-03 13:17:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352415606429069314",
  "geo" : { },
  "id_str" : "352415783961378816",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u203B\u3042\u3093\u307E\u308A\u3046\u307E\u3044\u3053\u3068\u8A00\u3048\u3066\u306A\u3044",
  "id" : 352415783961378816,
  "in_reply_to_status_id" : 352415606429069314,
  "created_at" : "2013-07-03 13:17:25 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352415393031270401",
  "geo" : { },
  "id_str" : "352415540775628800",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ (\u30D5\u3063\u305F\u306E\u306F\u826F\u3044\u3082\u306E\u306E\u601D\u3063\u305F\u3088\u308A\u3046\u305C\u3047\u2026)",
  "id" : 352415540775628800,
  "in_reply_to_status_id" : 352415393031270401,
  "created_at" : "2013-07-03 13:16:27 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352415352229068800",
  "text" : "\u5B9F\u969B\u5965\u3086\u304B\u3057\u3044\u30E4\u30DE\u30C8\u30CA\u30C7\u30B7\u30B3\u3081\u3044\u305F\u7ACB\u3061\u4F4D\u7F6E",
  "id" : 352415352229068800,
  "created_at" : "2013-07-03 13:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352415111828353028",
  "geo" : { },
  "id_str" : "352415277490765826",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u5F8C\u6094\u300C\u4E09\u6B69\u4E0B\u304C\u3063\u3066\u3064\u3044\u3066\u884C\u304D\u307E\u3059\u300D",
  "id" : 352415277490765826,
  "in_reply_to_status_id" : 352415111828353028,
  "created_at" : "2013-07-03 13:15:24 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352411993497546753",
  "text" : "\u2026\u3068\u308A\u3042\u3048\u305A\u4ECA\u65E5\u306F\u5BDD\u308B\u524D\u306B\u30D5\u30E9\u30D5\u30E9\u306B\u306A\u308B\u307E\u3067\u304A\u98A8\u5442\u5165\u3063\u3066\u6C17\u6301\u3061\u3092\u30EA\u30BB\u30C3\u30C8\u3057\u3088\u3046",
  "id" : 352411993497546753,
  "created_at" : "2013-07-03 13:02:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352410990685601793",
  "text" : "\u6B21\u306E\u8A00\u8449\u3092\u4F7F\u3063\u3066140\u6587\u5B57\u4F5C\u6587\u3060\uFF01\uFF01\n\u9858\u66F8 \u30A2\u30A4\u30A8\u30A8\u30A8\u30A8 \u660E\u5F8C\u65E5 \u30B0\u30EF\u30FC\u30C3",
  "id" : 352410990685601793,
  "created_at" : "2013-07-03 12:58:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352319190591475712",
  "text" : "\u304A\u306A\u304B\u3078\u3063\u305F",
  "id" : 352319190591475712,
  "created_at" : "2013-07-03 06:53:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352317582348533760",
  "text" : "\u6975\u307E\u308A\u304C\u7720\u305F\u307E\u308B",
  "id" : 352317582348533760,
  "created_at" : "2013-07-03 06:47:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/yPXgQte7v4",
      "expanded_url" : "http:\/\/sx9.jp\/weather\/kyoto.html",
      "display_url" : "sx9.jp\/weather\/kyoto.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352315096808161281",
  "text" : "\u6765\u308B\u2026(\u78BA\u4FE1) http:\/\/t.co\/yPXgQte7v4",
  "id" : 352315096808161281,
  "created_at" : "2013-07-03 06:37:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352308038276890627",
  "text" : "\u306D\u3080",
  "id" : 352308038276890627,
  "created_at" : "2013-07-03 06:09:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352232988253233152",
  "geo" : { },
  "id_str" : "352271867438055424",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u30AB\u30B7\u30B3\u30A4\uFF01",
  "id" : 352271867438055424,
  "in_reply_to_status_id" : 352232988253233152,
  "created_at" : "2013-07-03 03:45:32 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352232779876024322",
  "text" : "\u610F\u5730\u60AA\u826F\u304F\u306A\u3044",
  "id" : 352232779876024322,
  "created_at" : "2013-07-03 01:10:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352232700507209729",
  "text" : "\u6C34\u66DC\u65E5\u306E\u96E8\u3001\u591A\u304F\u306A\u3044\u3067\u3059\u304B",
  "id" : 352232700507209729,
  "created_at" : "2013-07-03 01:09:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352232630038704129",
  "text" : "\u96E8\u2026\uFF1F\uFF01",
  "id" : 352232630038704129,
  "created_at" : "2013-07-03 01:09:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352103888050069505",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u30A8",
  "id" : 352103888050069505,
  "created_at" : "2013-07-02 16:38:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352103851429597187",
  "text" : "\u5F53\u305F\u308A\u524D\u306E\u4E8B\u304C\u3067\u304D\u308B\u3068\u5F53\u305F\u308A\u524D\u3060\u3057\u5F53\u305F\u308A\u524D\u306E\u4E8B\u304C\u51FA\u6765\u306A\u3044\u3068\u51F9\u3080\u3057\u5F53\u305F\u308A\u524D\u3068\u304B\u8A00\u3046\u6982\u5FF5\u3001\u8AB0\u304C\u5F97\u3059\u308B\u306E",
  "id" : 352103851429597187,
  "created_at" : "2013-07-02 16:37:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352033965286244352",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 352033965286244352,
  "created_at" : "2013-07-02 12:00:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351932832811200513",
  "text" : "ppp",
  "id" : 351932832811200513,
  "created_at" : "2013-07-02 05:18:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351618491847155712",
  "geo" : { },
  "id_str" : "351618715428720640",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u716E\u308B\u306A\u308A\u713C\u304F\u306A\u308A\u597D\u304D\u306B\u3057\u3066\u304F\u3060\u3055\u3044",
  "id" : 351618715428720640,
  "in_reply_to_status_id" : 351618491847155712,
  "created_at" : "2013-07-01 08:30:09 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351618560625352704",
  "text" : "\u4E00\u6761\u306E\u4F4D\u7F6E\u60C5\u5831(boso\u30C3",
  "id" : 351618560625352704,
  "created_at" : "2013-07-01 08:29:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351618275911798784",
  "geo" : { },
  "id_str" : "351618412117635072",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3069\u3046\u305E\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 351618412117635072,
  "in_reply_to_status_id" : 351618275911798784,
  "created_at" : "2013-07-01 08:28:56 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351617013631819776",
  "text" : "\u4ECA\u306E\u4E00\u9023\u306E\u306A\u3057",
  "id" : 351617013631819776,
  "created_at" : "2013-07-01 08:23:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351616931956146177",
  "text" : "\u9AD8\u5EA6\u306A\u65E5\u672C\u8A9E\u30B8\u30E7\u30FC(\u3054\u3058\u3087\u30FC)\u30AF",
  "id" : 351616931956146177,
  "created_at" : "2013-07-01 08:23:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351616782173351936",
  "text" : "\u4E0D\u9069\u5207\u306A\u5834\u9762\u3067\u56DB\u6761\u3092\u631F\u307F\u307E\u3057\u305F",
  "id" : 351616782173351936,
  "created_at" : "2013-07-01 08:22:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351616685549170688",
  "text" : "\u6CB3\u539F\u753A\u3001\u56DB\u6761\u3001\u4E09\u6761\u3001\u4E94\u6761\u2026",
  "id" : 351616685549170688,
  "created_at" : "2013-07-01 08:22:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351616148594372608",
  "text" : "\u7E01\u9060\u3044\u3001\u307F\u305F\u3044\u306A\u30EF\u30FC\u30C9\u306B\u904E\u5270\u672C\u80FD\u3059\u308B\u4EBA\u751F\u3060\u3063\u305F",
  "id" : 351616148594372608,
  "created_at" : "2013-07-01 08:19:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351615824462741505",
  "text" : "\u4E00\u6B21\u5143\u51FD\u578B\u30DD\u30C6\u30F3\u30B7\u30E3\u30EB\u306E\u7C92\u5B50\u3082\u805E\u304D\u305F\u304B\u3063\u305F\u304C\u2026",
  "id" : 351615824462741505,
  "created_at" : "2013-07-01 08:18:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351615705944305665",
  "text" : "\u3072\u3087\u3093\u306A\u6D41\u308C\u3067\u4E09\u6761\u306B\u53C2\u4E0A\u3059\u308B\u3053\u3068\u306B\u306A\u3063\u305F",
  "id" : 351615705944305665,
  "created_at" : "2013-07-01 08:18:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351413896810201089",
  "text" : "\u307E\u3076\u305F\u4EE5\u5916\u304C\u8EFD\u304F\u306A\u3063\u305F",
  "id" : 351413896810201089,
  "created_at" : "2013-06-30 18:56:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351400140327763968",
  "text" : "\u306A\u3093\u3066\u3044\u3063\u3066\u308B\u9593\u306B3\u6642\u3067\u3059\u3088",
  "id" : 351400140327763968,
  "created_at" : "2013-06-30 18:01:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351390074056880128",
  "text" : "\u673A\u306E\u4E0A\u304C\u6D88\u3057\u30B4\u30E0\u306E\u5C51\u3067\u3042\u308C\u3060\u304B\u3089\u4ECA\u5EA6\u30B7\u30E5\u30ED\u7B92\u3092\u8CB7\u3044\u306B\u884C\u3053\u3046",
  "id" : 351390074056880128,
  "created_at" : "2013-06-30 17:21:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351387732788002816",
  "text" : "\u3084\u3046\u3084\u304F\u8A08\u7B97\u304C\u5408\u3063\u305F",
  "id" : 351387732788002816,
  "created_at" : "2013-06-30 17:12:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]