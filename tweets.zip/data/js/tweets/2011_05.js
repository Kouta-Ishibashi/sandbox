Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75576058891612160",
  "text" : "\u5FC3\u5730\u304C\u3044\u3044\u307E\u307E\u5E03\u56E3\u5165\u308A\u3059\u308B\u3068\u3057\u307E\u3059\u3001\u3069\u3046\u305B\u643A\u5E2F\u304B\u3089\u898B\u3066\u308B\u306E\u3067\u3042\u308C\u3067\u3059\u304C\u30FC\u3002",
  "id" : 75576058891612160,
  "created_at" : "2011-05-31 14:55:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 12, 21 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75570443951677440",
  "geo" : { },
  "id_str" : "75570696591392770",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 @nisehorn \u306B\u305B\u307B\u9762\u767D\u308C\u3047\uFF57\uFF57\uFF57\uFF57",
  "id" : 75570696591392770,
  "in_reply_to_status_id" : 75570443951677440,
  "created_at" : "2011-05-31 14:33:52 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 0, 9 ],
      "id_str" : "256321768",
      "id" : 256321768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75568778339037185",
  "geo" : { },
  "id_str" : "75569735567282176",
  "in_reply_to_user_id" : 256321768,
  "text" : "@mar1e666 \u305D\u3093\u306A\u306B\u5F37\u304F\u306A\u3044\u306E\u3067\u6C34\u5272\u308A\u306A\u3093\u3060\u3051\u3069\u306D\u30FC\u3002",
  "id" : 75569735567282176,
  "in_reply_to_status_id" : 75568778339037185,
  "created_at" : "2011-05-31 14:30:03 +0000",
  "in_reply_to_screen_name" : "mar1e666",
  "in_reply_to_user_id_str" : "256321768",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75567880040759297",
  "text" : "\u4E45\u3005\u306B\u30A6\u30A3\u30B9\u30AD\u30FC\u3068\u30C1\u30E7\u30B3\u30EC\u30FC\u30C8",
  "id" : 75567880040759297,
  "created_at" : "2011-05-31 14:22:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75552309383409664",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u30B7\u30E3\u30EF\u30FC",
  "id" : 75552309383409664,
  "created_at" : "2011-05-31 13:20:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75550770451316736",
  "text" : "\u30C6\u30C8\u30E9bot\u306E\u771F\u4F3C\u3057\u3066\u307F\u305F\u308A\u3002\u5E7E\u4F55\u3082\u9762\u767D\u305D\u3046\u306D\u30FC\u3002\u9762\u767D\u305D\u3046\u3069\u307E\u308A\u306B\u306A\u3089\u306A\u3044\u3068\u3044\u3044\u306A\u3002",
  "id" : 75550770451316736,
  "created_at" : "2011-05-31 13:14:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75550578662588416",
  "text" : "\u7406\u5B66\u90E8\u540C\u56DE\u306E\u30B5\u30FC\u30AF\u30EB\u65B0\u5165\u751F\u3068\u53CC\u66F2\u7DDA\u5E7E\u4F55\u5B66\u306B\u3064\u3044\u3066\u8A71\u3057\u307E\u3057\u305F\u3002\u3061\u3087\u3063\u3068\u96E3\u3057\u304B\u3063\u305F\u3067\u3059\u2026\u2026\u3002",
  "id" : 75550578662588416,
  "created_at" : "2011-05-31 13:13:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75549000585064448",
  "text" : "\u5E30\u5B85\u30A1\uFF01",
  "id" : 75549000585064448,
  "created_at" : "2011-05-31 13:07:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75534323926839296",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 75534323926839296,
  "created_at" : "2011-05-31 12:09:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75454077898727424",
  "geo" : { },
  "id_str" : "75456130456891392",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3088\u306E\u306A\u304B\u306D\u3001\u304B\u304A\u304B\u3001\u304A\u304B\u306D\u304B\u3001\u306A\u306E\u3088(\u56DE\u6587)",
  "id" : 75456130456891392,
  "in_reply_to_status_id" : 75454077898727424,
  "created_at" : "2011-05-31 06:58:38 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75433855955378177",
  "text" : "\u3055\u3063\u304D\u306E\u5618\u3002\uFF10\uFF12\u3001\uFF10\uFF14\u3001\uFF10\uFF18\u3001\uFF11\uFF16\u3001\uFF13\uFF12\u3001\uFF16\uFF14\u3001\uFF12\uFF18\u3001\uFF15\uFF16\u3001\uFF11\uFF12\u3001\uFF12\uFF14\u3001\uFF14\uFF18\u3001\uFF19\uFF16\u3001\uFF19\uFF12\u3001\uFF18\uFF14\u3001\uFF16\uFF18\u3001\uFF13\uFF16\u3001\uFF17\uFF12\u3001\uFF14\uFF14\u3001\uFF18\uFF18\u3001\uFF17\uFF16\u3001\uFF15\uFF12\u3001\uFF10\uFF14\u306E\uFF12\uFF10\u304C\u5468\u671F\u306E\u30EB\u30FC\u30D7\u3002\u4F59\u308A\uFF11\u3002\uFF15\uFF12\u304C\u4F59\u308A\u3002 RT 2^1001\u3092100\u3067\u5272\u3063\u305F\u4F59\u308A\u3092\u6C42\u3081\u3066\u304F\u3060\u3055\u3044\u3002(00,\u540D\u53E4\u5C4B)",
  "id" : 75433855955378177,
  "created_at" : "2011-05-31 05:30:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75429437071568896",
  "text" : "\u3066\u304B\u3053\u306E\u6642\u9593\u306A\u3089\u307E\u3069\u30DE\u30AE\u3082\u3046\u4E00\u8A71\u307F\u308C\u305F\u304B\u3082\u306A\u30FC\u3002\u307E\u3041\u304E\u308A\u304E\u308A\u306B\u306A\u3063\u3066\u6025\u3050\u306E\u5ACC\u3044\u3060\u304B\u3089\u826F\u3044\u3093\u3060\u3051\u3069\u3055\u3002",
  "id" : 75429437071568896,
  "created_at" : "2011-05-31 05:12:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75429167725940737",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u4F8B\u793A\u306F\u7406\u89E3\u306E\u8A66\u91D1\u77F3\uFF01\u4F8B\u3092\u4F5C\u3063\u3066\u7406\u89E3\u3059\u308B\u306E\u304C\u8FD1\u9053\u3002\u8A71\u3059\u65B9\u3082\u4F8B\u3092\u793A\u3057\u3066\u3057\u304B\u308B\u3079\u304D\u3002",
  "id" : 75429167725940737,
  "created_at" : "2011-05-31 05:11:29 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zekitter",
      "screen_name" : "zekitter",
      "indices" : [ 3, 12 ],
      "id_str" : "93639986",
      "id" : 93639986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75426587931185154",
  "text" : "RT @zekitter: \u4EAC\u5927\u306E\u5171\u5317\u30B7\u30E7\u30C3\u30D7\u306E\u30A2\u30F3\u30B1\u30FC\u30C8\u306B\u300C\u306A\u3093\u3069\u3084\u3063\u3066\u3082\u307E\u3069\u304B\u3092\u6551\u3048\u307E\u305B\u3093\u3002\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u3067\u3059\u304B\uFF1F\u3000by\u307B\u3080\u3089\u300D\u3063\u3066\u8CEA\u554F\u3057\u305F\u306E\u8AB0\u3060\u3088\u3002\u300C\u305D\u306E\u3088\u3046\u306A\u30B2\u30FC\u30E0\u304C\u3042\u308B\u3093\u3067\u3059\u306D\u3002\u3088\u304F\u77E5\u3089\u306A\u304F\u3066\u3059\u307F\u307E\u305B\u3093\u3002\u300D\u3063\u3066\u30DE\u30B8\u3067\u304A\u3070\u3061\u3083\u3093\u306A\u3093\u306E\u3053\u3068\u304B\u5206\u304B\u3063\u3066\u306A\u304F\u3066\u56F0\u3063\u3066\u308B\u3058 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75406647324966912",
    "text" : "\u4EAC\u5927\u306E\u5171\u5317\u30B7\u30E7\u30C3\u30D7\u306E\u30A2\u30F3\u30B1\u30FC\u30C8\u306B\u300C\u306A\u3093\u3069\u3084\u3063\u3066\u3082\u307E\u3069\u304B\u3092\u6551\u3048\u307E\u305B\u3093\u3002\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u3067\u3059\u304B\uFF1F\u3000by\u307B\u3080\u3089\u300D\u3063\u3066\u8CEA\u554F\u3057\u305F\u306E\u8AB0\u3060\u3088\u3002\u300C\u305D\u306E\u3088\u3046\u306A\u30B2\u30FC\u30E0\u304C\u3042\u308B\u3093\u3067\u3059\u306D\u3002\u3088\u304F\u77E5\u3089\u306A\u304F\u3066\u3059\u307F\u307E\u305B\u3093\u3002\u300D\u3063\u3066\u30DE\u30B8\u3067\u304A\u3070\u3061\u3083\u3093\u306A\u3093\u306E\u3053\u3068\u304B\u5206\u304B\u3063\u3066\u306A\u304F\u3066\u56F0\u3063\u3066\u308B\u3058\u3083\u306D\u30FC\u304B\u3002",
    "id" : 75406647324966912,
    "created_at" : "2011-05-31 03:42:00 +0000",
    "user" : {
      "name" : "zekitter",
      "screen_name" : "zekitter",
      "protected" : false,
      "id_str" : "93639986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2698507943\/85e48a4b1c6dd44be71c82b0d6795242_normal.jpeg",
      "id" : 93639986,
      "verified" : false
    }
  },
  "id" : 75426587931185154,
  "created_at" : "2011-05-31 05:01:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75416964092272640",
  "text" : "\u9B31end\u3057\u304B\u898B\u3048\u306A\u3044\u2026\u305D\u308D\u305D\u308D\u5927\u5B66\u306B\u623B\u308B\u304B\u3002",
  "id" : 75416964092272640,
  "created_at" : "2011-05-31 04:23:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75410402149806080",
  "text" : "\u5E30\u5B85\u3064\u3044\u3067\u306B\u307E\u3069\u30DE\u30AE\u4E94\u8A71\u898B\u7D42\u3048\u305F\u3002\u3084\u3063\u3071\u307B\u3080\u3089\u3082\u4EAC\u5B50\u3082\u3044\u3044\u4EBA\u306A\u3093\u3058\u3083\u2026",
  "id" : 75410402149806080,
  "created_at" : "2011-05-31 03:56:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3061\u306F",
      "screen_name" : "Willway_ER",
      "indices" : [ 3, 14 ],
      "id_str" : "137994509",
      "id" : 137994509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75388605035593728",
  "text" : "RT @Willway_ER: \u4EE5\u524D\u3001\u6BCD\u6821\u306E\u5B66\u53CB\u4F1A\u3068\u540D\u4E57\u308B\u7537\u304B\u3089\u306E\u96FB\u8A71\u3067\u4F4F\u6240\u30FB\u9023\u7D61\u5148\u3092\u805E\u304B\u308C\u3001\u7B54\u3048\u306A\u3044\u3068\u300C\u500B\u4EBA\u60C5\u5831\u306F\u56FA\u304F\u5B88\u308A\u307E\u3059\u300D\u3068\u8A00\u3046\u3002\u3044\u307E\u8AB0\u304C\u5165\u3063\u3066\u3044\u308B\u306E\u304B\u805E\u304F\u3068\u3001\u540C\u671F\u306E\u540D\u524D\u3092\u51FA\u3059\u3002\u7591\u308F\u3057\u3044\u304B\u3089\u8A3C\u62E0\u306B\u5F7C\u306E\u96FB\u8A71\u756A\u53F7\u3092\u8A00\u3048\u308B\u304B\u554F\u3046\u3068\u3001\u3059\u3093\u306A\u308A\u6559\u3048\u3066\u304F\u308C\u305F\u3002\u300C\u500B\u4EBA\u60C5\u5831\u6F0F\u308C\u3066 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75322891603947520",
    "text" : "\u4EE5\u524D\u3001\u6BCD\u6821\u306E\u5B66\u53CB\u4F1A\u3068\u540D\u4E57\u308B\u7537\u304B\u3089\u306E\u96FB\u8A71\u3067\u4F4F\u6240\u30FB\u9023\u7D61\u5148\u3092\u805E\u304B\u308C\u3001\u7B54\u3048\u306A\u3044\u3068\u300C\u500B\u4EBA\u60C5\u5831\u306F\u56FA\u304F\u5B88\u308A\u307E\u3059\u300D\u3068\u8A00\u3046\u3002\u3044\u307E\u8AB0\u304C\u5165\u3063\u3066\u3044\u308B\u306E\u304B\u805E\u304F\u3068\u3001\u540C\u671F\u306E\u540D\u524D\u3092\u51FA\u3059\u3002\u7591\u308F\u3057\u3044\u304B\u3089\u8A3C\u62E0\u306B\u5F7C\u306E\u96FB\u8A71\u756A\u53F7\u3092\u8A00\u3048\u308B\u304B\u554F\u3046\u3068\u3001\u3059\u3093\u306A\u308A\u6559\u3048\u3066\u304F\u308C\u305F\u3002\u300C\u500B\u4EBA\u60C5\u5831\u6F0F\u308C\u3066\u307E\u3059\u3084\u3093\u300D\u3068\u8A00\u3063\u3066\u96FB\u8A71\u3092\u5207\u3063\u305F\u3002",
    "id" : 75322891603947520,
    "created_at" : "2011-05-30 22:09:11 +0000",
    "user" : {
      "name" : "\u3044\u3061\u306F",
      "screen_name" : "Willway_ER",
      "protected" : false,
      "id_str" : "137994509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494788508578357249\/oaqNsoSG_normal.jpeg",
      "id" : 137994509,
      "verified" : false
    }
  },
  "id" : 75388605035593728,
  "created_at" : "2011-05-31 02:30:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haipai_tsumo",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/vfvEv8V",
      "expanded_url" : "http:\/\/shindanmaker.com\/122623",
      "display_url" : "shindanmaker.com\/122623"
    } ]
  },
  "geo" : { },
  "id_str" : "75372768279011328",
  "text" : "\u5357\uFF11\u5C40\u3000\u81EA\u98A8\u897F\u3001\u30C9\u30E9\u2467\u3002end313124\u306E\u624B\u724C\u306F\u4E09\u4E94\u4E5D\uFF13\uFF14\uFF16\uFF17\uFF17\uFF18\u2465\u2466\u2466\u897F\u767D\u3002\u3069\u3046\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/vfvEv8V #haipai_tsumo \u4E5D\u304B\u897F\u304B\u3002\u4ED6\u5BB6\u304C\u897F\u51FA\u3057\u3066\u305F\u3089\u897F\u5207\u308B\u3051\u3069\u3002",
  "id" : 75372768279011328,
  "created_at" : "2011-05-31 01:27:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75371370560765952",
  "text" : "\u307E\u3041\u6388\u696D\u4E2D\u8AAD\u3080\u304B\u3089\u4E0D\u5FC5\u8981\u3067\u3082\u306A\u3044\u304B\u2190",
  "id" : 75371370560765952,
  "created_at" : "2011-05-31 01:21:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75371207486226432",
  "text" : "\u3066\u304B\u7DDA\u578B\u3068\u304B\u96C6\u5408\u3068\u304B\u30BF\u30EB\u30B9\u30AD\u306E\u9006\u8AAC\u3068\u304B\u6388\u696D\u306B\u4E0D\u5FC5\u8981\u306A\u66F8\u7C4D\u6301\u3063\u3066\u304D\u3066\u6388\u696D\u306B\u5FC5\u8981\u306A\u3082\u306E\u5FD8\u308C\u3066\u308B\u3057\u2026\u5EA6\u3057\u96E3\u3044\u306A\u3002",
  "id" : 75371207486226432,
  "created_at" : "2011-05-31 01:21:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75369831888728064",
  "text" : "\u307E\u3041\uFF13\u9650\u306A\u3044\u304B\u3089\u554F\u984C\u306F\u306A\u3044\u304C\u2026\u9762\u5012\u3060\u3088\u306A\u3041\u2026",
  "id" : 75369831888728064,
  "created_at" : "2011-05-31 01:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75369680000389120",
  "text" : "\uFF14\u9650\u63D0\u51FA\u306E\u30EC\u30DD\u30FC\u30C8\u5FD8\u308C\u305F\u304B\u3082\u3002\n\u3068\u601D\u3063\u305F\u3089\u30D5\u30E9\u8A9E\u306E\u8F9E\u66F8\u3082\u306A\u3044\u3002\n\n\u4E00\u6642\u5E30\u5B85\u78BA\u5B9A\uFF6A\u2026",
  "id" : 75369680000389120,
  "created_at" : "2011-05-31 01:15:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75360147664404480",
  "geo" : { },
  "id_str" : "75360376178487296",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u8179\u9ED2\u3044\u306A\u3002\u5ACC\u3044\u3058\u3083\u306A\u3044\u3051\u3069\u3002",
  "id" : 75360376178487296,
  "in_reply_to_status_id" : 75360147664404480,
  "created_at" : "2011-05-31 00:38:08 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75360190786052096",
  "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u4E00\u4EBA\u6E1B\u3063\u3066\u308B\u2026\u307E\u3041\u3044\u3044\u3051\u3069\u3002",
  "id" : 75360190786052096,
  "created_at" : "2011-05-31 00:37:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75357908258406401",
  "geo" : { },
  "id_str" : "75359878910193664",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u304A\u524D\u2026\u666E\u901A\u306E\u6328\u62F6\u306B\u306F\u53CD\u5FDC\u3057\u306A\u3044\u304F\u305B\u306B\uFF57\uFF57",
  "id" : 75359878910193664,
  "in_reply_to_status_id" : 75357908258406401,
  "created_at" : "2011-05-31 00:36:09 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75358116170051584",
  "text" : "\u3082\u3046\u76EE\u899A\u3081\u3066\uFF11\uFF10\u5206\u306B\u306A\u308B\u3093\u3067\u306D\u3002\u4ECA\u66F4\u304A\u306F\u3088\u3046\u306E\u6328\u62F6\u3082\u3069\u3046\u304B\u3068\u601D\u3044\u307E\u3057\u3066\u3002",
  "id" : 75358116170051584,
  "created_at" : "2011-05-31 00:29:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75357823411826689",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
  "id" : 75357823411826689,
  "created_at" : "2011-05-31 00:27:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75226840649830400",
  "text" : "(\u7720\u308A\u305F\u3044\u306E\u306BTL\u8997\u3044\u3066\u3057\u307E\u3046\u2026)",
  "id" : 75226840649830400,
  "created_at" : "2011-05-30 15:47:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75225941357494272",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u3042\u3001\u3054\u3081\u3093\u3088\u3002\u30DC\u30B1\u3001\u30C4\u30C3\u30B3\u30DF\u3067\u4E00\u9023\u306E\u6D41\u308C\u306F\u7D42\u308F\u3063\u305F\u7269\u3068\u89E3\u91C8\u3057\u3066\u305F\u3002\u3067\u3082\u6B21\u306F\u3082\u3063\u3068\u8FC5\u901F\u306B\u7A81\u3063\u8FBC\u3093\u3067\u307F\u3066\u306D\u2190",
  "id" : 75225941357494272,
  "created_at" : "2011-05-30 15:43:56 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75219933197369346",
  "text" : "\u5BDD\u307E\u3059\u3002\u304C\u643A\u5E2F\u304B\u3089\u3072\u3063\u305D\u308A\u8997\u3044\u3066\u308B\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u2190\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 75219933197369346,
  "created_at" : "2011-05-30 15:20:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75219381336023040",
  "text" : "\u4E00\u4EBA\u4E00\u4EBA\u306ETL\u306B\u3088\u308B\u3051\u308C\u3069\u7A81\u3063\u8FBC\u307F\u3063\u306610\u5206\u6765\u306A\u304B\u3063\u305F\u3089\u6765\u306A\u3044\u3082\u306E\u3068\u601D\u3063\u3066\u308B\u3093\u3060\u3051\u3069\u2026\u3042\u3063\u3066\u308B\u304B\u306A\uFF1F\u4E00\u4EBA\u30CE\u30EA\u7A81\u8FBC\u307F\u306F\u5207\u306A\u3044\u3002\uFF08\u305F\u3044\u3066\u3044\u305F\u3060\u306E\u30DF\u30B9\u304B\u3089\u751F\u3058\u3066\u308B\u306A\u3093\u3066\u8A00\u3048\u306A\u3044\uFF09",
  "id" : 75219381336023040,
  "created_at" : "2011-05-30 15:17:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 32, 42 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75216978675118080",
  "text" : "\u8003\u3048\u3066\u307F\u308C\u3070\u5F53\u305F\u308A\u524D\u306A\u3093\u3060\u3051\u3069\u8AB0\u3082\u7A81\u3063\u8FBC\u3093\u3067\u304F\u308C\u306A\u3044\u2026\u3002 RT @end313124: \u3055\u3041\u65E5\u4ED8\u304C\u5909\u308F\u308B\u304B\u3089\u4E88\u7FD2\u306E\u6B8B\u308A\u306F\u660E\u65E5\u306B\u3057\u3088\u3046",
  "id" : 75216978675118080,
  "created_at" : "2011-05-30 15:08:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anohana",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75215247597768705",
  "text" : "\u3042\u306E\u82B1\u30E9\u30B8\u30AA\u805E\u304D\u7D42\u308F\u3063\u305F\u3089\u5BDD\u3088\u3046\u3002\u8305\u91CE\u3055\u3093\u4E00\u8A00\u3067\u8FD4\u3059\u30B7\u30EA\u30FC\u30BA\u3002\n\nQ.\u30E9\u30FC\u30E1\u30F3\u306E\u5177\u3067\u597D\u304D\u306A\u306E\u306F\u306A\u3093\u3067\u3059\u304B\uFF1F\u30E1\u30F3\u30DE\u4EE5\u5916\u3067\u3002\nA.\u30CD\u30AE\u3002\u6B21\u884C\u304D\u307E\u3059\u3002\n\n\u30B7\u30E5\u30FC\u30EB\u3060\u3063\u305F\u3002#anohana",
  "id" : 75215247597768705,
  "created_at" : "2011-05-30 15:01:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75214783439319040",
  "text" : "\u3055\u3041\u65E5\u4ED8\u304C\u5909\u308F\u308B\u304B\u3089\u4E88\u7FD2\u306E\u6B8B\u308A\u306F\u660E\u65E5\u306B\u3057\u3088\u3046",
  "id" : 75214783439319040,
  "created_at" : "2011-05-30 14:59:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75214159901503488",
  "geo" : { },
  "id_str" : "75214605407895552",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u3053\u306F\u8D85\u96FB\u78C1\u7832\u3067\uFF57\uFF57\uFF57\uFF57",
  "id" : 75214605407895552,
  "in_reply_to_status_id" : 75214159901503488,
  "created_at" : "2011-05-30 14:58:54 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082\u3063\u304F\u3059\uFF20\u6771\u4EAC\u4EBA\u306B\u306A\u308A\u307E\u3057\u305F",
      "screen_name" : "o_tomox",
      "indices" : [ 0, 8 ],
      "id_str" : "145247946",
      "id" : 145247946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75211132155076608",
  "geo" : { },
  "id_str" : "75211541045186561",
  "in_reply_to_user_id" : 145247946,
  "text" : "@o_tomox \u307E\u3041\u5B8C\u5168\u306B\u5922\u7269\u8A9E\u3067\u3059\u304B\u3089\u306D\u3047\uFF57\uFF57",
  "id" : 75211541045186561,
  "in_reply_to_status_id" : 75211132155076608,
  "created_at" : "2011-05-30 14:46:43 +0000",
  "in_reply_to_screen_name" : "o_tomox",
  "in_reply_to_user_id_str" : "145247946",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 7, 14 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75208088352858112",
  "text" : "\u53C2\u52A0\u5E0C\u671BRT @khulud: \u4E00\u7DD2\u306B\u300CKU \u30AF\u30E9\u30B9\u30BF\u306A\u306E\u304B\u5FAE\u5999\u30AF\u30E9\u30B9\u30BF\u300D\u3092\u7ACB\u3061\u4E0A\u3052\u307E\u3057\u3087\u3046\uFF0ERT @_mo2c: \u308F\u305F\u3057\u306FKU\u30AF\u30E9\u30B9\u30BF\u306A\u306E\u304B\u3069\u3046\u304B\u5FAE\u5999\u306A\u3068\u3053\u308D\u3067\u3059",
  "id" : 75208088352858112,
  "created_at" : "2011-05-30 14:33:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u062E\u0644\u0648\u062F",
      "screen_name" : "khulud",
      "indices" : [ 28, 35 ],
      "id_str" : "239486216",
      "id" : 239486216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75207688853798912",
  "text" : "\u305D\u3082\u305D\u3082\u30AF\u30E9\u30B9\u30BF\u3063\u3066\u6982\u5FF5\u304C\u66D6\u6627\u3067\u3086\u308B\u3086\u308B\u3067\u3059\u3057\u306D\u3047RT @khulud: \u3042\u3068\u5225\u306B\u4EAC\u5927\u3058\u3083\u306A\u304F\u3066\u3082 KU \u30AF\u30E9\u30B9\u30BF\u3042\u308A\u3048\u308B\u3057 KU \u30AF\u30E9\u30B9\u30BF\u306E\u6761\u4EF6\u306F\u3088\u304F\u308F\u304B\u3089\u3093\uFF0E",
  "id" : 75207688853798912,
  "created_at" : "2011-05-30 14:31:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 9, 20 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75207483081228289",
  "text" : "\u30A4\u30AB\u4EAC\u306A\u3089\u2026RT @akiyohmori: RT @omg0203: \u30CD\u30BF\u306E\u3088\u3046\u3060\u3051\u3069\u305D\u3093\u306A\u7A2E\u65CF\u304C\u3044\u308B\u306E\u7ACB\u6559\u306B\u306F\uFF1F\u5225\u4E16\u754C\u2026 RT @buyobuyonce: \u300E\u30AD\u30B3\u5145\u300F\u3063\u3066\u8A00\u8449\u3001\u77E5\u3063\u3066\u308B\uFF1F\u7ACB\u6559\u7528\u8A9E\u3089\u3057\u3044\u3088\u3002\u30AD\u30B3\u5145\u306F\u30EA\u30A2\u5145\u306E\u4E0A\u306A\u3093\u3060\u3063\u3066\u3002\u30AD\u30B3\u30EA\u307F\u305F\u3044\u306A\u683C\u597D(\u30C8\u30EC\u30C3\u30AD\u30F3\u30B0\u30B7\u30E5\u30FC\u30BA\u306B\u30B7",
  "id" : 75207483081228289,
  "created_at" : "2011-05-30 14:30:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75204713833971712",
  "geo" : { },
  "id_str" : "75207212053704706",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u6642\u3005RT\u3055\u308C\u308Bbot\u306B\u6BCE\u56DE\u30AF\u30B9\u3063\u3066\u3057\u3066\u3057\u307E\u3046\u3088\uFF57",
  "id" : 75207212053704706,
  "in_reply_to_status_id" : 75204713833971712,
  "created_at" : "2011-05-30 14:29:31 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082\u3063\u304F\u3059\uFF20\u6771\u4EAC\u4EBA\u306B\u306A\u308A\u307E\u3057\u305F",
      "screen_name" : "o_tomox",
      "indices" : [ 0, 8 ],
      "id_str" : "145247946",
      "id" : 145247946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75206332935974912",
  "geo" : { },
  "id_str" : "75206981023043586",
  "in_reply_to_user_id" : 145247946,
  "text" : "@o_tomox \u5F85\u3061\u3082\u4F55\u3082\u63C3\u3063\u3061\u3083\u3063\u3066\u307E\u3059\u304B\u3089\u306D\u3047\u2026\u305D\u306E\u307E\u307E4\u56DE\u30AB\u30F3\u3057\u305F\u3089\u5929\u548C\u56DB\u69D3\u5B50\u306B\u306A\u308B\u306E\u304B\u3069\u3046\u304B\u3082\u6C17\u306B\u306A\u308A\u307E\u3059\u306D\u2190",
  "id" : 75206981023043586,
  "in_reply_to_status_id" : 75206332935974912,
  "created_at" : "2011-05-30 14:28:36 +0000",
  "in_reply_to_screen_name" : "o_tomox",
  "in_reply_to_user_id_str" : "145247946",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082\u3063\u304F\u3059\uFF20\u6771\u4EAC\u4EBA\u306B\u306A\u308A\u307E\u3057\u305F",
      "screen_name" : "o_tomox",
      "indices" : [ 0, 8 ],
      "id_str" : "145247946",
      "id" : 145247946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75203579446706177",
  "geo" : { },
  "id_str" : "75204109782888448",
  "in_reply_to_user_id" : 145247946,
  "text" : "@o_tomox \u3059\u308B\u3068\u601D\u3044\u307E\u3059\u3088\u30FC\u3002\u5929\u548C\u3001\u56DB\u6697\u523B\u3001\u5B57\u4E00\u8272\u3001\u5927\u56DB\u559C\u30675\u500D\u5F79\u6E80\u304C\u6700\u9AD8\u3067\u3057\u3087\u3046\u304B\uFF1F240000\u70B9\u3067\u3059\u306D\uFF57\uFF57\uFF57",
  "id" : 75204109782888448,
  "in_reply_to_status_id" : 75203579446706177,
  "created_at" : "2011-05-30 14:17:11 +0000",
  "in_reply_to_screen_name" : "o_tomox",
  "in_reply_to_user_id_str" : "145247946",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cluster_hantei",
      "indices" : [ 61, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/sBv7DXS",
      "expanded_url" : "http:\/\/ducky199999.appspot.com\/jsp\/cluster.jsp",
      "display_url" : "ducky199999.appspot.com\/jsp\/cluster.jsp"
    } ]
  },
  "geo" : { },
  "id_str" : "75202897373179905",
  "text" : "end313124\u3055\u3093\u306E\u5C5E\u3059\u308B\u30AF\u30E9\u30B9\u30BF\u306F\u3001\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u3001\u6587\u5B66\u30AF\u30E9\u30B9\u30BF\u3001\u82F1\u8A9E\u30AF\u30E9\u30B9\u30BF\u3001\u6570\u5B66\u597D\u30AF\u30E9\u30B9\u30BF\u3001\u6587\u5B66\u90E8\u30AF\u30E9\u30B9\u30BF\u3067\u3059\u3002 #cluster_hantei http:\/\/t.co\/sBv7DXS \u82F1\u8A9E\u4E91\u3005\u3063\u3066\u3044\u3084\u3044\u3084\u3084\u3063\u3066\u308B\u8AB2\u984C\u304B\u3089\u62FE\u3063\u3066\u308B\u3053\u3068\u3092\u8003\u3048\u308B\u3068\u2026",
  "id" : 75202897373179905,
  "created_at" : "2011-05-30 14:12:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75200999115075584",
  "geo" : { },
  "id_str" : "75201439546359808",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u304B\u3048\u308A\u306A\u3057\u3042\uFF01",
  "id" : 75201439546359808,
  "in_reply_to_status_id" : 75200999115075584,
  "created_at" : "2011-05-30 14:06:35 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75200587368640512",
  "text" : "\u3072\u3060\u307E\u308A\u3068\u30DF\u30EB\u30AD\u30A3\u306B\u306F\u9762\u767D\u3051\u308C\u3070\u3044\u3044\u3063\u3066\u3044\u3046\u610F\u5473\u3067\u304A\u3093\u306A\u3058\u5302\u3044\u304C\u3059\u308B\u6C17\u304C\u3059\u308B\u3002",
  "id" : 75200587368640512,
  "created_at" : "2011-05-30 14:03:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75192630895575040",
  "text" : "\u30D5\u30E9\u30F3\u30B9\u8A9E\u306E\u6559\u6750\u304C\u3061\u3087\u3063\u3068\u524D\u306EFMI\u5C40\u9577\u306E\u30B9\u30AD\u30E3\u30F3\u30C0\u30EB\u306A\u3093\u3060\u304C\uFF57\uFF57\uFF57\u5F37\u59E6\u3092\u4F01\u3066\u305F\u3068\u304B\u6027\u7684\u306A\u653B\u6483\u3068\u304B\u30D5\u30E9\u30F3\u30B9\u8A9E\u3067\u2026\u9762\u767D\u3044\u3051\u3069\uFF57\uFF57\uFF57",
  "id" : 75192630895575040,
  "created_at" : "2011-05-30 13:31:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79D1\u5B66\u306B\u4F47\u3080\u4E00\u884C\u8AAD\u66F8\u5FC3",
      "screen_name" : "endBooks",
      "indices" : [ 32, 41 ],
      "id_str" : "160921673",
      "id" : 160921673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75189807386599424",
  "text" : "\u30E1\u30E2\uFF1BISBN-13: 978-4166600137 \n\u3000RT @endBooks:  http:\/\/is.gd\/etJOi \u300E\u79D1\u5B66\u9451\u5B9A\u3000\u3072\u304D\u9003\u3052\u8ECA\u7A2E\u304B\u3089DNA\u307E\u3067\u300F\u77F3\u5C71\u3044\u304F\u592B\u8457",
  "id" : 75189807386599424,
  "created_at" : "2011-05-30 13:20:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B89\u7530 \u6D0B\u7950",
      "screen_name" : "yagena",
      "indices" : [ 3, 10 ],
      "id_str" : "43542937",
      "id" : 43542937
    }, {
      "name" : "\u677E\u4E95\u5F70\u5F66",
      "screen_name" : "akihikomatsui",
      "indices" : [ 29, 43 ],
      "id_str" : "254331124",
      "id" : 254331124
    }, {
      "name" : "\u3042\u3082\u308A\u30FC",
      "screen_name" : "sabatora285",
      "indices" : [ 55, 67 ],
      "id_str" : "115688900",
      "id" : 115688900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75179199320698880",
  "text" : "RT @yagena: \u3050\u3063\uFF0CShe saw \u6B7B\u76F8\u2026RT @akihikomatsui: \u3059\u3054\u30FC\u3044\uFF01\uFF08\u656C\u3000RT@sabatora285 \u3010\u5927\u962A\u5E9C30\u4EE3\u5973\u6027\u304B\u3089\u306E\u304A\u60A9\u307F\u76F8\u8AC7\u3011\u79C1\u306E8\u624D\u306B\u306A\u308B\u5A18\u306E\u6F22\u5B57\u30C9\u30EA\u30EB\u306E\u5BBF\u984C\u306E\u5275\u4F5C\u4F8B\u6587\u304C\u3048\u3089\u3044\u3053\u3068\u306B\u306A\u3063\u3066\u307E\u3059\u3002 http:\/\/lockerz ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u677E\u4E95\u5F70\u5F66",
        "screen_name" : "akihikomatsui",
        "indices" : [ 17, 31 ],
        "id_str" : "254331124",
        "id" : 254331124
      }, {
        "name" : "\u3042\u3082\u308A\u30FC",
        "screen_name" : "sabatora285",
        "indices" : [ 43, 55 ],
        "id_str" : "115688900",
        "id" : 115688900
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75177843503546368",
    "text" : "\u3050\u3063\uFF0CShe saw \u6B7B\u76F8\u2026RT @akihikomatsui: \u3059\u3054\u30FC\u3044\uFF01\uFF08\u656C\u3000RT@sabatora285 \u3010\u5927\u962A\u5E9C30\u4EE3\u5973\u6027\u304B\u3089\u306E\u304A\u60A9\u307F\u76F8\u8AC7\u3011\u79C1\u306E8\u624D\u306B\u306A\u308B\u5A18\u306E\u6F22\u5B57\u30C9\u30EA\u30EB\u306E\u5BBF\u984C\u306E\u5275\u4F5C\u4F8B\u6587\u304C\u3048\u3089\u3044\u3053\u3068\u306B\u306A\u3063\u3066\u307E\u3059\u3002 http:\/\/lockerz.com\/s\/106145737",
    "id" : 75177843503546368,
    "created_at" : "2011-05-30 12:32:49 +0000",
    "user" : {
      "name" : "\u5B89\u7530 \u6D0B\u7950",
      "screen_name" : "yagena",
      "protected" : false,
      "id_str" : "43542937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475993851161636865\/s7M5P2Kh_normal.jpeg",
      "id" : 43542937,
      "verified" : false
    }
  },
  "id" : 75179199320698880,
  "created_at" : "2011-05-30 12:38:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ldnews",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http:\/\/t.co\/59ZwoLe",
      "expanded_url" : "http:\/\/news.livedoor.com\/article\/detail\/5596730\/",
      "display_url" : "news.livedoor.com\/article\/detail\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "75178382593228800",
  "text" : "\u300C\u304A\u3082\u3089\u3057\u5973\u5B50\u300D\u300C\u30AA\u30E0\u30E9\u30A4\u30B9\u98DF\u3079\u3089\u308C\u306A\u3044\u5973\u300D\u3000\u904E\u6FC0\u30B3\u30E9\u30E0\u300C\u30A8\u30D3\u30AA\u30B9\u5B22\u300D\u306E\u6B63\u4F53 #ldnews http:\/\/t.co\/59ZwoLe",
  "id" : 75178382593228800,
  "created_at" : "2011-05-30 12:34:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75169189756801024",
  "geo" : { },
  "id_str" : "75169479218307072",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4FFA\u3082\u4E00\u9650\u306F\u306A\u304B\u3063\u305F\u3053\u3068\u306B\u306A\u3063\u305F\u3002",
  "id" : 75169479218307072,
  "in_reply_to_status_id" : 75169189756801024,
  "created_at" : "2011-05-30 11:59:35 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75161177033945089",
  "text" : "\u3042\u3001\uFF15\u8A71\u3080\u3063\u3061\u3083\u826F\u3044\u3068\u3053\u308D\u3067\u2026\u3002",
  "id" : 75161177033945089,
  "created_at" : "2011-05-30 11:26:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75159640308056064",
  "text" : "QB\u8A98\u5C0E\u3046\u307E\u3044\u306A\u2026",
  "id" : 75159640308056064,
  "created_at" : "2011-05-30 11:20:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75154434212110336",
  "text" : "@mo5nya \u30B7\u30E3\u30D5\u30C8\u3063\u307D\u304F\u3066\u826F\u3044\u611F\u3058\u3067\u3059\u306D\u3002\u8868\u73FE\u306E\u7DE9\u6025\uFF1F",
  "id" : 75154434212110336,
  "created_at" : "2011-05-30 10:59:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "75151925242372096",
  "geo" : { },
  "id_str" : "75153109399248896",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u91CD\u305F\u3044\u3002\u3067\u3082\u30B7\u30E3\u30D5\u30C8\u306E\u30CF\u30C3\u30AD\u30EA\u3068\u3054\u3061\u3083\u3054\u3061\u3083\u8868\u73FE\u306E\u7DE9\u6025\u304C\u826F\u3044\u5473\u3060\u3057\u3066\u308B\u3002",
  "id" : 75153109399248896,
  "in_reply_to_status_id" : 75151925242372096,
  "created_at" : "2011-05-30 10:54:32 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75152390092881920",
  "text" : "@mo5nya \u4ECA\u65E5\u306F\uFF15\u8A71\u307E\u3067\u898B\u3088\u3046\u304B\u306A\u3001\u3068\u3002",
  "id" : 75152390092881920,
  "created_at" : "2011-05-30 10:51:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75151205524979712",
  "text" : "\u4ECA\u66F4\u3060\u304C\u3001\u307E\u3069\u30DE\u30AE\u898B\u3066\u308B\u3002\u78BA\u304B\u306B\u3053\u308C\u306F\u6B1D\u5C55\u958B\u3060\u3002",
  "id" : 75151205524979712,
  "created_at" : "2011-05-30 10:46:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75134864793411584",
  "text" : "RT @hyuki: #mathgirl \u5C0F\u5B66\u4E94\u5E74\u751F\u306E\u8AAD\u8005\u3055\u3093\u304B\u3089\u30E1\u30FC\u30EB\u3092\u3044\u305F\u3060\u3044\u305F\u3002\u300C\u6570\u5B66\u30AC\u30FC\u30EB\u300D\u30B7\u30EA\u30FC\u30BA\u539F\u4F5C\u3092\u56DB\u518A\u3068\u3082\u8AAD\u3093\u3067\u9762\u767D\u304B\u3063\u305F\u3068\u306E\u3053\u3068\u3002\u304D\u3061\u3093\u3068\u7406\u89E3\u3057\u3066\u3044\u308B\u6A21\u69D8\u3002\u3059\u3054\u3044\u5B50\u3082\u3044\u307E\u3059\u306D\u3002\u5B66\u6821\u306E\u7B97\u6570\u306F\u7C21\u5358\u3059\u304E\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3051\u308C\u3069\u3001\u6C7A\u3057\u3066\u3070\u304B\u306B\u305B\u305A\u3001\u3066\u3044\u306D\u3044\u306B\u5B66\u3093\u3067\u304F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mathgirl",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75134120908431360",
    "text" : "#mathgirl \u5C0F\u5B66\u4E94\u5E74\u751F\u306E\u8AAD\u8005\u3055\u3093\u304B\u3089\u30E1\u30FC\u30EB\u3092\u3044\u305F\u3060\u3044\u305F\u3002\u300C\u6570\u5B66\u30AC\u30FC\u30EB\u300D\u30B7\u30EA\u30FC\u30BA\u539F\u4F5C\u3092\u56DB\u518A\u3068\u3082\u8AAD\u3093\u3067\u9762\u767D\u304B\u3063\u305F\u3068\u306E\u3053\u3068\u3002\u304D\u3061\u3093\u3068\u7406\u89E3\u3057\u3066\u3044\u308B\u6A21\u69D8\u3002\u3059\u3054\u3044\u5B50\u3082\u3044\u307E\u3059\u306D\u3002\u5B66\u6821\u306E\u7B97\u6570\u306F\u7C21\u5358\u3059\u304E\u308B\u304B\u3082\u3057\u308C\u306A\u3044\u3051\u308C\u3069\u3001\u6C7A\u3057\u3066\u3070\u304B\u306B\u305B\u305A\u3001\u3066\u3044\u306D\u3044\u306B\u5B66\u3093\u3067\u304F\u3060\u3055\u3044\u306D\u3001\u3068\u8FD4\u4FE1\u3057\u307E\u3057\u305F\u3002",
    "id" : 75134120908431360,
    "created_at" : "2011-05-30 09:39:05 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 75134864793411584,
  "created_at" : "2011-05-30 09:42:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75054690852806656",
  "text" : "\u7530\u820E\u3088\u308A\u90FD\u4F1A\u306E\u304C\u826F\u3044\u307F\u305F\u3044\u306E\u3082\u5E7B\u60F3\u3060\u3068\u601D\u3046\u3093\u3060\u3051\u3069\u2026\u90FD\u4F1A\u51FA\u8EAB\u3060\u3068\u8996\u70B9\u304C\u30BA\u30EC\u308B\u306E\u304B\u306A\u3041\u3002\u4F55\u306B\u3064\u3044\u3066\u3082\u5E38\u306B\u30CB\u30E5\u30FC\u30C8\u30E9\u30EB\u3067\u3042\u308A\u305F\u3044\u306E\u3060\u3051\u308C\u3069\u3002",
  "id" : 75054690852806656,
  "created_at" : "2011-05-30 04:23:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75054259992920066",
  "text" : "\u3044\u305A\u308C\u306B\u3057\u3066\u3082\u30E9\u30A6\u30F3\u30B8\u307F\u305F\u3044\u306A\u30D1\u30D6\u30EA\u30C3\u30AF\u30B9\u30DA\u30FC\u30B9\u305D\u3053\u51FA\u8EAB\u306E\u4EBA\u9593\u304C\u3044\u308B\u53EF\u80FD\u6027\u3068\u304B\u8003\u3048\u306A\u3044\u306E\u304B\u306A\u3041\u3002\u307E\u3041\u5225\u306B\u3053\u308C\u3068\u3044\u3063\u3066\u6771\u4EAC\u51FA\u8EAB\u306E\u512A\u8D8A\u611F\u3068\u304B\u306A\u3044\u3064\u3082\u308A\u3060\u3051\u3069\u3001\u3084\u3063\u3071\u308A\u4F55\u51E6\u304B\u3067\u3042\u308B\u306E\u304B\u306A\u3002",
  "id" : 75054259992920066,
  "created_at" : "2011-05-30 04:21:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75053449758257152",
  "text" : "\u65B9\u8A00\u306E\u9055\u3044\u3082\u6C17\u6301\u3061\u60AA\u3044\u3063\u3066\u8A00\u3063\u3066\u305F\u3051\u3069\u2026\u9055\u548C\u611F\u2192\u6C17\u6301\u3061\u60AA\u3044\u3063\u3066\u306E\u3082\u3069\u3046\u306A\u3093\u3060\u308D\u3046\u304B\u3002",
  "id" : 75053449758257152,
  "created_at" : "2011-05-30 04:18:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75053230517796864",
  "text" : "\u30E9\u30A6\u30F3\u30B8\u3002\u5973\u306E\u4EBA\u304C\u300C\u6771\u4EAC\u3068\u304B\u3042\u3093\u306A\u30B3\u30F3\u30AF\u30EA\u30FC\u30C8\u30B8\u30E3\u30F3\u30B0\u30EB\u306B\u4F4F\u3093\u3069\u3063\u305F\u3089\u5FC3\u3082\u8352\u3080\u3084\u308D\u30FC\u3002\u300D\u3063\u3066\u3001\u305D\u306E\u6392\u4ED6\u7684\u306A\u767A\u60F3\u306F\u8352\u3093\u3067\u306A\u3044\u304B\u3002\u3068\u601D\u3046\u306E\u306F\u81EA\u5206\u304C\u6771\u4EAC\u51FA\u8EAB\u3060\u304B\u3089\u304B\u306A\u3002",
  "id" : 75053230517796864,
  "created_at" : "2011-05-30 04:17:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75041699793076224",
  "text" : "\u5408\u7406\u7684\u3068\u3044\u3046\u4E0D\u6761\u7406",
  "id" : 75041699793076224,
  "created_at" : "2011-05-30 03:31:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75001062800621568",
  "text" : "\u96E8\u304C\u3001\u5BD2\u3055\u304C\u3001\u7A7A\u8179\u304C\u3001\u305F\u3060\u3067\u3055\u3048\u8CB4\u91CD\u306A\u3084\u308B\u6C17\u3092\u596A\u3063\u3066\u3044\u304F\u2026\u2026",
  "id" : 75001062800621568,
  "created_at" : "2011-05-30 00:50:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74997932281176064",
  "text" : "\u4E00\u9650\u3092\u898B\u4E8B\u306B\u30D0\u30B9\u30BF\u30FC\u3057\u3061\u307E\u3063\u305F\u3002\u304A\u306F\u3088\u3046\u3002",
  "id" : 74997932281176064,
  "created_at" : "2011-05-30 00:37:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74869846587875328",
  "text" : "\u5BDD\u308B\u3088\uFF01\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 74869846587875328,
  "created_at" : "2011-05-29 16:08:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "indices" : [ 3, 15 ],
      "id_str" : "258721812",
      "id" : 258721812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74868337716375552",
  "text" : "RT @MyMathCloud: Don't think of it as a newspaper, think of it as a retro blog.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74867897415110656",
    "text" : "Don't think of it as a newspaper, think of it as a retro blog.",
    "id" : 74867897415110656,
    "created_at" : "2011-05-29 16:01:12 +0000",
    "user" : {
      "name" : "My Mathematics Cloud",
      "screen_name" : "MyMathCloud",
      "protected" : false,
      "id_str" : "258721812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2965777663\/5bb5d3206072ca9112470f291e368645_normal.png",
      "id" : 258721812,
      "verified" : false
    }
  },
  "id" : 74868337716375552,
  "created_at" : "2011-05-29 16:02:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74860773117136896",
  "geo" : { },
  "id_str" : "74861683956396032",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u3053\u306E\u524D\u307E\u3067\u30D7\u30ED\u96C0\u58EB\u3060\u3063\u305F\u307F\u305F\u3044\u3088\u3002\u3061\u3087\u3046\u3069\u4E00\u5E74\u304F\u3089\u3044\u524D\u306B\u898B\u3064\u3051\u305F\u3093\u3060\u3051\u3069\uFF57",
  "id" : 74861683956396032,
  "in_reply_to_status_id" : 74860773117136896,
  "created_at" : "2011-05-29 15:36:30 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74858881192443904",
  "geo" : { },
  "id_str" : "74859635496058880",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u5730\u7406\u306F\u5927\u4F53\u306F\u899A\u3048\u305F\u304B\u306A\u30FC\u3002\u305D\u308C\u306F\u305D\u3046\u3068\u3053\u3093\u306A\u30CD\u30BF\u306F\u3044\u304B\u304C\uFF1F\u643A\u5E2F\u304B\u3089\u898B\u308C\u308B\u304B\u306A http:\/\/goo.gl\/S77kQ",
  "id" : 74859635496058880,
  "in_reply_to_status_id" : 74858881192443904,
  "created_at" : "2011-05-29 15:28:22 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74855640819970048",
  "geo" : { },
  "id_str" : "74856374529560576",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u9020\u5F62\u5927\u307E\u3067\u81EA\u8EE2\u8ECA\u306715\u5206\u304F\u3089\u3044\u306E\u8DDD\u96E2\u2026\u3042\u305D\u3053\u305D\u3093\u306A\u3053\u3068\u307E\u3067\u3084\u3063\u3066\u3093\u306E\u304B\u30FC",
  "id" : 74856374529560576,
  "in_reply_to_status_id" : 74855640819970048,
  "created_at" : "2011-05-29 15:15:25 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74829096500211712",
  "text" : "\u3042\u3001\u4EAC\u90FD\u7248\u306A\u306E\u3067\u3042\u3057\u304B\u3089\u305A",
  "id" : 74829096500211712,
  "created_at" : "2011-05-29 13:27:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74829003877388288",
  "text" : "\u96E8\u304B\u3041\u2026",
  "id" : 74829003877388288,
  "created_at" : "2011-05-29 13:26:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74828960239845376",
  "text" : "\u660E\u65E5\u306E\u5929\u6C17 - 5\u670830\u65E5(\u6708).\n\u96E8\u306E\u3061\u66C7\n\u6700\u9AD8\u6C17\u6E29 25\u2103 \n\u524D\u65E5\u5DEE (-1) \n\u6700\u4F4E\u6C17\u6E29 15\u2103 \n\u524D\u65E5\u5DEE (-1) \n\u6642\u9593\u5E2F(\u6642) 0-6 6-12 12-18 18-24 \n\u964D\u6C34\u78BA\u7387 \u300080% \u300050% \u300020% \u300020% \n\u98A8 \u5317\u306E\u98A8\u3084\u3084\u5F37\u304F\u5F8C\u5317\u897F\u306E\u98A8",
  "id" : 74828960239845376,
  "created_at" : "2011-05-29 13:26:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74825536697942016",
  "geo" : { },
  "id_str" : "74825826809561088",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u30E8\u30FC\u30B0\u30EB\u30C8\u3068\u8FF7\u3063\u305F\u3093\u3060\u3051\u3069\u30BC\u30EA\u30FC\u306B\u3057\u307E\u3057\u305F\u30FC",
  "id" : 74825826809561088,
  "in_reply_to_status_id" : 74825536697942016,
  "created_at" : "2011-05-29 13:14:01 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74824361047109634",
  "text" : "\u30BC\u30EA\u30FC\u98DF\u3079\u308B\uFF01",
  "id" : 74824361047109634,
  "created_at" : "2011-05-29 13:08:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s_tr",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74820374021406720",
  "text" : "\u3010end313124\u3055\u3093\u3078\u7D20\u6734\u306A\u7591\u554F\u3011\u51FA\u8EAB\u5730\u30FB\u4F4F\u307F\u305F\u3044\u56FD\u30FB100\u4E07\u5186\u30FB\u30DA\u30C3\u30C8\u3044\u308B\uFF1F\u30FB\u30B9\u30AB\u30FC\u30C8\u597D\u304D\uFF1F http:\/\/shindanmaker.com\/82826 #s_tr \n\u6771\u4EAC\u30FB\u30AE\u30EA\u30B7\u30E3\u30FB\u6B32\u3057\u3044\u30FB\u8981\u308B\u3051\u3069\u5C45\u306A\u3044\u30FB\u9577\u3044",
  "id" : 74820374021406720,
  "created_at" : "2011-05-29 12:52:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74812920239890432",
  "geo" : { },
  "id_str" : "74813360226566144",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u5C0F\u8033\u306B\u306F\u3055\u3093\u3060\u9650\u308A\u975E\u5E38\u306B\u9762\u767D\u305D\u3046\u3060\u306D\u3047\uFF57\uFF57\u8DB3\u8DE1\u3064\u3044\u3066\u3066\u3061\u3087\u3063\u3068\u6016\u3044\u3093\u3060\u3051\u3069\uFF57\uFF57",
  "id" : 74813360226566144,
  "in_reply_to_status_id" : 74812920239890432,
  "created_at" : "2011-05-29 12:24:29 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74808084333211649",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 74808084333211649,
  "created_at" : "2011-05-29 12:03:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74803924569296896",
  "text" : "\u6771\u4E8C\u5C40\u3067100\u70B9\u307E\u3067\u843D\u3061\u8FBC\u3093\u3060\u3051\u3069\u30AA\u30FC\u30E9\u30B9\u306713200\u307E\u3067\u76DB\u308A\u8FD4\u3057\u30663\u4F4D\u3002\u30AE\u30EA\u30AE\u30EA\u3063\u3066\u30EC\u30D9\u30EB\u3058\u3083\u306A\u3044\u3002http:\/\/goo.gl\/sv4K7",
  "id" : 74803924569296896,
  "created_at" : "2011-05-29 11:47:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "indices" : [ 15, 29 ],
      "id_str" : "101753216",
      "id" : 101753216
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 50, 60 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74766454750326784",
  "text" : "\u7D20\u56E0\u6570\u5206\u89E3\u3055\u308C\u305F\uFF57\uFF57\uFF57\u3000RT @factoring_bot: 600=2*2*2*3*5*5 RT @end313124: 600\u5B57\u5236\u9650\u306E\u30EC\u30DD\u30FC\u30C8\u3068\u308A\u3042\u3048\u305A\u66F8\u304D\u4E0A\u3052\u305F\u3089850\u5B57\u304F\u3089\u3044\u3042\u308B\u2026\u3069\u3046\u3084\u3063\u3066\u524A\u3063\u305F\u3082\u306E\u304B\u30FC\u3002",
  "id" : 74766454750326784,
  "created_at" : "2011-05-29 09:18:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74765153069056000",
  "geo" : { },
  "id_str" : "74765802091446272",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3048\u3063",
  "id" : 74765802091446272,
  "in_reply_to_status_id" : 74765153069056000,
  "created_at" : "2011-05-29 09:15:30 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74765625414778880",
  "text" : "600\u5B57\u5236\u9650\u306E\u30EC\u30DD\u30FC\u30C8\u3068\u308A\u3042\u3048\u305A\u66F8\u304D\u4E0A\u3052\u305F\u3089850\u5B57\u304F\u3089\u3044\u3042\u308B\u2026\u3069\u3046\u3084\u3063\u3066\u524A\u3063\u305F\u3082\u306E\u304B\u30FC\u3002",
  "id" : 74765625414778880,
  "created_at" : "2011-05-29 09:14:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74764774092709888",
  "geo" : { },
  "id_str" : "74765146886647808",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math AB?",
  "id" : 74765146886647808,
  "in_reply_to_status_id" : 74764774092709888,
  "created_at" : "2011-05-29 09:12:54 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74764647307280384",
  "geo" : { },
  "id_str" : "74765067463303168",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u305D\u308C\u306F\u89E3\u308B\u304B\u3082\u2026\u306A\u3093\u304B\u8584\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u3002",
  "id" : 74765067463303168,
  "in_reply_to_status_id" : 74764647307280384,
  "created_at" : "2011-05-29 09:12:35 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74710157250134016",
  "text" : "\u305D\u3046\u3044\u3048\u3070DVD\u8FD4\u3057\u306B\u884C\u304B\u306A\u304F\u3063\u3061\u3083\u3044\u3051\u306A\u3044\u306A\u3002\u3002\u3002\u3053\u306E\u96E8\u306E\u4E2D\u3002\u3002\u3002\u91D1\u66DC\u3068\u304B\u306B\u884C\u3063\u3066\u304A\u304F\u3079\u304D\u3060\u3063\u305Forz",
  "id" : 74710157250134016,
  "created_at" : "2011-05-29 05:34:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 0, 7 ],
      "id_str" : "129796835",
      "id" : 129796835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74708182970277888",
  "geo" : { },
  "id_str" : "74708587242467328",
  "in_reply_to_user_id" : 129796835,
  "text" : "@7M1IHN \u305D\u3046\u3058\u3083\u306A\u304F\u3066\u30824\u30B1\u30BF\u304F\u3089\u3044\u306E\u6570\u306A\u3089\u81EA\u5206\u3067\u6C17\u304C\u4ED8\u304F\u3068\u7D20\u56E0\u6570\u5206\u89E3\u3057\u3061\u3083\u3046\u3093\u3067\u3059\u3051\u3069\u306D\u3002\u6570\u5B66\u75C5\uFF1F",
  "id" : 74708587242467328,
  "in_reply_to_status_id" : 74708182970277888,
  "created_at" : "2011-05-29 05:28:09 +0000",
  "in_reply_to_screen_name" : "7M1IHN",
  "in_reply_to_user_id_str" : "129796835",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74707433871773696",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u5C11\u3057\u524D\u306B\u56E0\u6570\u5206\u89E3bot\u306A\u308B\u3082\u306E\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u305F\u306A\u3002\u3068\u3044\u3046\u306E\u306F2177\u30C4\u30A4\u30FC\u30C8\u76EE\u3002",
  "id" : 74707433871773696,
  "created_at" : "2011-05-29 05:23:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74482118557831168",
  "geo" : { },
  "id_str" : "74482426864336896",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 74482426864336896,
  "in_reply_to_status_id" : 74482118557831168,
  "created_at" : "2011-05-28 14:29:29 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74460784889053184",
  "geo" : { },
  "id_str" : "74461367695982592",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u30D2\u30C8\u30AB\u30E9\u4E00\u7DD2\u306B\u884C\u304F\u3068\u3044\u3046\u77DB\u76FE\u3002\u305D\u3057\u305F\u3089\u305D\u306E\u3042\u3068\u4E8C\u4EBA\u3067\u4E00\u4EBA\u934B\u306E\u304A\u5E97\u306B\u884C\u304D\u307E\u3057\u3087\u3046\u3002",
  "id" : 74461367695982592,
  "in_reply_to_status_id" : 74460784889053184,
  "created_at" : "2011-05-28 13:05:48 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74460894771429376",
  "text" : "\u30C8\u30A4\u30EC\u3068\u304B\u98F2\u307F\u7269\u3068\u304B\u30BF\u30A4\u30DF\u30F3\u30B0\u96E3\u3057\u304B\u3063\u305F\u306A\u3041\u3002",
  "id" : 74460894771429376,
  "created_at" : "2011-05-28 13:03:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74460496736174080",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u6628\u65E5\u30D2\u30C8\u30AB\u30E9\u3068\u3044\u3046\u3084\u3064\u306B\u30C1\u30E3\u30EC\u30F3\u30B8\u3057\u3066\u307F\u305F\u3002\u697D\u3057\u304B\u3063\u305F\u3051\u3069\u306A\u3093\u304B\u5FD9\u3057\u306A\u304B\u3063\u305F\u3002\u6771\u65B9\u30A2\u30EC\u30F3\u30B8\u5165\u3063\u3066\u7121\u304B\u3063\u305F\u306E\u304C\u30A2\u30EC\u3060\u3063\u305F\u3051\u3069\u5341\u5206\u3002",
  "id" : 74460496736174080,
  "created_at" : "2011-05-28 13:02:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74459597942951937",
  "text" : "\u3082\u3057\u30C4\u30A4\u30C3\u30BF\u30FC\u306E\u5168\u30E6\u30FC\u30B6\u30FC\u304C\uFF12\u4EBA\u3060\u3063\u305F\u3089\uFF1F\uFF13\u306B\u3093\u3060\u3063\u305F\uFF1F\u2026\uFF4E\u4EBA\u3060\u3063\u305F\uFF1F",
  "id" : 74459597942951937,
  "created_at" : "2011-05-28 12:58:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u6A4B \u76F4\u5927(chokudai)",
      "screen_name" : "chokudai",
      "indices" : [ 3, 12 ],
      "id_str" : "15312900",
      "id" : 15312900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74459456775266304",
  "text" : "RT @chokudai: \u554F\u984C\uFF1ATwitter\u306E\u5168\u30E6\u30FC\u30B6\u30FC\u306E\u30D5\u30A9\u30ED\u30EF\u30FC\u6570\u3068\u30D5\u30A9\u30ED\u30FC\u6570\u306E\u5E73\u5747\u3092\u305D\u308C\u305E\u308C\u53D6\u3063\u305F\u6642\u3001\u3069\u3061\u3089\u306E\u65B9\u304C\u591A\u3044\u3067\u3057\u3087\u3046\u304B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/peraperaprv\/Home\" rel=\"nofollow\"\u003EP3:PeraPeraPrv\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74453496904167424",
    "text" : "\u554F\u984C\uFF1ATwitter\u306E\u5168\u30E6\u30FC\u30B6\u30FC\u306E\u30D5\u30A9\u30ED\u30EF\u30FC\u6570\u3068\u30D5\u30A9\u30ED\u30FC\u6570\u306E\u5E73\u5747\u3092\u305D\u308C\u305E\u308C\u53D6\u3063\u305F\u6642\u3001\u3069\u3061\u3089\u306E\u65B9\u304C\u591A\u3044\u3067\u3057\u3087\u3046\u304B",
    "id" : 74453496904167424,
    "created_at" : "2011-05-28 12:34:31 +0000",
    "user" : {
      "name" : "\u9AD8\u6A4B \u76F4\u5927(chokudai)",
      "screen_name" : "chokudai",
      "protected" : false,
      "id_str" : "15312900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553945510789136385\/B8Ejq8-j_normal.jpeg",
      "id" : 15312900,
      "verified" : false
    }
  },
  "id" : 74459456775266304,
  "created_at" : "2011-05-28 12:58:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74458820264476672",
  "text" : "\u305D\u3046\u3081\u3093\u306B\u7D0D\u8C46\u3092\u5165\u308C\u308B\u6587\u5316\u3063\u3066\u7279\u6B8A\u306A\u306E\uFF1F\u95A2\u897F\u570F\u3067\u306F\u7D0D\u8C46\u305D\u306E\u3082\u306E\u304C\u30C0\u30E1\u3063\u3066\u4EBA\u591A\u3044\u304B\u3089\u3042\u308C\u306A\u3093\u3060\u3051\u3069\u30FB\u30FB\u30FB\u3002",
  "id" : 74458820264476672,
  "created_at" : "2011-05-28 12:55:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74451450293522432",
  "text" : "\u307E\u3041\u8D77\u304D\u305F\u306E\u3082\u9045\u304B\u3063\u305F\u3051\u3069\u3002",
  "id" : 74451450293522432,
  "created_at" : "2011-05-28 12:26:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74451376503144448",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u304A\u5915\u98EF\uFF08\u305D\u3046\u3081\u3093\uFF09\u3092\u4F5C\u308D\u3046\u3068\u601D\u3046\u3002",
  "id" : 74451376503144448,
  "created_at" : "2011-05-28 12:26:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74451300309405697",
  "text" : "\u4ECA\u65E5\u306A\u30FC\u3093\u306B\u3082\u3057\u3066\u306A\u3044\u3002\u3046\u3093\u3002\u65E5\u304C\u306A\u4E00\u65E5\u975E\u751F\u7523\u7684\u306B\u30CD\u30C3\u30C8\u30B5\u30FC\u30D5\u30A3\u30F3\u3057\u3066\u305F\u3060\u3051\u3002\u3046\u3093\u3002\u53CD\u7701\u306F\u3057\u3066\u3044\u306A\u3044\u3051\u3069\u4ECA\u304B\u3089\u5C11\u3057\u306F\u751F\u7523\u7684\u306A\u6D3B\u52D5\u3092\u3057\u3088\u3046\u3068\u601D\u3046\u3002",
  "id" : 74451300309405697,
  "created_at" : "2011-05-28 12:25:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74445714075299840",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 74445714075299840,
  "created_at" : "2011-05-28 12:03:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74342958152945664",
  "text" : "RT @JOJO_math: \u3042\u2026\u3042\u308A\u306E\u307E\u307E\u3000\u4ECA\u8D77\u3053\u3063\u305F\u4E8B\u3092\u8A71\u3059\u305C\uFF01\u300E\u304A\u308C\u306F\u6575\u56FD\u306E\u5175\u58EB\u306E\u524D\u3067\u300C\u5186\u3092\u8E0F\u307F\u8352\u3089\u3059\u306A\u300D\u3068\u6012\u9CF4\u3063\u305F\u3068\u601D\u3063\u305F\u3089\u3044\u3064\u306E\u307E\u306B\u304B\u5929\u306B\u53EC\u3055\u308C\u3066\u3044\u305F\u300F\u306A\u2026\u4F55\u3092\u8A00\u3063\u3066\u3044\u308B\u306E\u304B\uFF08\u7565\uFF09\u50AC\u7720\u8853\u3060\u3068\u304B\u8D85\u30B9\u30D4\u30FC\u30C9\u3060\u3068\u304B\u305D\u3093\u306A\u30C1\u30E3\u30C1\u306A\u3082\u3093\u3058\u3083\u3042\u65AD\u3058\u3066\u306D\u3048\u3000\u3082\u3063\u3068\u6050\u308D\u3057\u3044\u5B66\u554F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74337321801089024",
    "text" : "\u3042\u2026\u3042\u308A\u306E\u307E\u307E\u3000\u4ECA\u8D77\u3053\u3063\u305F\u4E8B\u3092\u8A71\u3059\u305C\uFF01\u300E\u304A\u308C\u306F\u6575\u56FD\u306E\u5175\u58EB\u306E\u524D\u3067\u300C\u5186\u3092\u8E0F\u307F\u8352\u3089\u3059\u306A\u300D\u3068\u6012\u9CF4\u3063\u305F\u3068\u601D\u3063\u305F\u3089\u3044\u3064\u306E\u307E\u306B\u304B\u5929\u306B\u53EC\u3055\u308C\u3066\u3044\u305F\u300F\u306A\u2026\u4F55\u3092\u8A00\u3063\u3066\u3044\u308B\u306E\u304B\uFF08\u7565\uFF09\u50AC\u7720\u8853\u3060\u3068\u304B\u8D85\u30B9\u30D4\u30FC\u30C9\u3060\u3068\u304B\u305D\u3093\u306A\u30C1\u30E3\u30C1\u306A\u3082\u3093\u3058\u3083\u3042\u65AD\u3058\u3066\u306D\u3048\u3000\u3082\u3063\u3068\u6050\u308D\u3057\u3044\u5B66\u554F\u3078\u306E\u7121\u7406\u89E3\u306E\u7247\u9C57\u3092\u5473\u308F\u3063\u305F\u305C\u2026",
    "id" : 74337321801089024,
    "created_at" : "2011-05-28 04:52:53 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 74342958152945664,
  "created_at" : "2011-05-28 05:15:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B5\u30B6\u30A8Bot",
      "screen_name" : "sazae_f",
      "indices" : [ 3, 11 ],
      "id_str" : "171360306",
      "id" : 171360306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74118879865090050",
  "text" : "RT @sazae_f: \u30BF\u30E9\u3061\u3083\u3093\uFF1F\u7406\u60F3\u3068\u306F\u6F38\u8FD1\u7DDA\u306E\u4E0A\u306B\u3042\u308B\u3082\u306E\u3088\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74112942349615104",
    "text" : "\u30BF\u30E9\u3061\u3083\u3093\uFF1F\u7406\u60F3\u3068\u306F\u6F38\u8FD1\u7DDA\u306E\u4E0A\u306B\u3042\u308B\u3082\u306E\u3088\u3002",
    "id" : 74112942349615104,
    "created_at" : "2011-05-27 14:01:17 +0000",
    "user" : {
      "name" : "\u30B5\u30B6\u30A8Bot",
      "screen_name" : "sazae_f",
      "protected" : false,
      "id_str" : "171360306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602437951910379521\/W3g5s4Hi_normal.jpg",
      "id" : 171360306,
      "verified" : false
    }
  },
  "id" : 74118879865090050,
  "created_at" : "2011-05-27 14:24:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74068788202586112",
  "text" : "\u3057\u304B\u3082\u672C\u6587\u3058\u3083\u306A\u304F\u3066\u4EF6\u540D\u3068\u3044\u3046\u3002\u306A\u3093\u306E\u6697\u53F7\u3060\u3002",
  "id" : 74068788202586112,
  "created_at" : "2011-05-27 11:05:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74068639900385280",
  "text" : "\u53CB\u9054\u3068\u306E\u30E1\u30FC\u30EB\n\u4FFA\u300Csi\u300D\uFF08\u30B9\u30AB\u30A4\u30D7\u306BI\u541B\u304C\u3044\u308B\u305C\uFF09\n\u53CB\u9054\u300C\uFF54\uFF4D\u300D\uFF08\u3061\u3087\u3063\u3068\u307E\u3063\u3066\u3066\uFF09\n\u3053\u308C\u306F\u9177\u3044\u3002",
  "id" : 74068639900385280,
  "created_at" : "2011-05-27 11:05:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74058660418043904",
  "text" : "\u898B\u7D42\u3048\u305F\u30FC\u3002C\u306F\u8A71\u9032\u307E\u306A\u304B\u3063\u305F\u3051\u3069\u9762\u767D\u304B\u3063\u305F\u3002",
  "id" : 74058660418043904,
  "created_at" : "2011-05-27 10:25:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74047144314671104",
  "text" : "\u3042\u306E\u82B1\uFF17\u8A71\u307F\u308B\u3002C\u3082\u3002",
  "id" : 74047144314671104,
  "created_at" : "2011-05-27 09:39:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73905121980981249",
  "text" : "\u7121\u9650\u3057\u3087\u3046\u304B\u3044\u305B\u304D \u6570\u5B66\u304B\u6B74\u53F2\u304B",
  "id" : 73905121980981249,
  "created_at" : "2011-05-27 00:15:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73890966632796160",
  "text" : "\uFF49\u3068\u7D50\u57CE(\u5148\u751F)\u3060\u3051\u304C\u53CB\u9054\u3055\u3001\u3068\u8A00\u3046\u3068\u9014\u7AEF\u306B\u6570\u5B66\u30AC\u30FC\u30EB\u3081\u3044\u3066\u304F\u308B\u3002",
  "id" : 73890966632796160,
  "created_at" : "2011-05-26 23:19:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    }, {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 9, 24 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73879774019330048",
  "geo" : { },
  "id_str" : "73885216653049856",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 @G4_Hirano_chan \u304A\u306F\u3088\u3046\u3042\u308A\u304C\u3068\u3046\u3067\u3057\u305F\u30FC",
  "id" : 73885216653049856,
  "in_reply_to_status_id" : 73879774019330048,
  "created_at" : "2011-05-26 22:56:23 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73879518892404736",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046",
  "id" : 73879518892404736,
  "created_at" : "2011-05-26 22:33:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73879451749974016",
  "text" : "\u3061\u3087\u3063\u3068\u5BD2\u3044\u306A\u2026",
  "id" : 73879451749974016,
  "created_at" : "2011-05-26 22:33:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73781268248133632",
  "text" : "\u5BDD\u308B\u304B\u306A\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u30021\u30001\u30002\u30003",
  "id" : 73781268248133632,
  "created_at" : "2011-05-26 16:03:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73780946381438976",
  "text" : "\u77BC\u4EE5\u5916\u304C\u8EFD\u304F\u306A\u3063\u3066\u304D\u305F\u306A\u3041\u3002",
  "id" : 73780946381438976,
  "created_at" : "2011-05-26 16:02:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73780655816835072",
  "text" : "\u5BB6\u306B\u3044\u308B\u3068\u304D\u6642\u3005\u548C\u88C5\u3060\u304C\u30B3\u30F3\u30D3\u30CB\u306B\u884C\u304F\u52C7\u6C17\u3055\u3048\u51FA\u306A\u3044\u3002\u54C0\u308C\u306A\u4FFA\u306E\u30DE\u30C8\u30EA\u30E7\u30FC\u30B7\u30AB\u3002",
  "id" : 73780655816835072,
  "created_at" : "2011-05-26 16:00:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73780229159649280",
  "text" : "\u4ECA\u65E5\u306E\u4E00\u9650\u8D77\u304D\u308C\u308B\u306E\u304B\u306A\u3002\u306A\u3093\u304B\uFF15\u6708\u5165\u3063\u3066\u304B\u3089\u884C\u3051\u3066\u306A\u3044\u3088\u3046\u306A\u6C17\u3082\u3059\u308B\u306E\u3060\u304C\u2190",
  "id" : 73780229159649280,
  "created_at" : "2011-05-26 15:59:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73779088359309312",
  "text" : "\u5E73\u5747\u3057\u3066\uFF13\uFF16\uFF0E\uFF16\u6587\u5B57\u3060\u304B\u3089\u5236\u9650\u304B\u3089\u8003\u3048\u308B\u3068\uFF12\uFF15\uFF05\u304F\u3089\u3044\u304B\u3002\u305D\u3093\u306A\u306B\u9577\u304F\u3082\u306A\u3044\u6C17\u3082\u3057\u3066\u304D\u305F\u3002",
  "id" : 73779088359309312,
  "created_at" : "2011-05-26 15:54:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73778813930176512",
  "text" : "\u3084\u3063\u3071\u308A\u4E00\u56DE\u4E00\u56DE\u306E\u3064\u3076\u3084\u304D\u304C\u5E73\u5747\u3057\u3066\u9577\u3044\u3088\u306A\u30FC\u3002\u3068\u304F\u306B\u9762\u767D\u3044\u3053\u3068\u3082\u8A00\u3063\u3066\u306A\u3044\u306E\u306B\u7121\u99C4\u306B\u9577\u3044\u3088\u306A\u30FC\u3002",
  "id" : 73778813930176512,
  "created_at" : "2011-05-26 15:53:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73778535742967808",
  "text" : "Twilog Stats\u306F\u5730\u5473\u3060\u3051\u308C\u3069\u81EA\u5DF1\u5206\u6790\u7684\u306A\u610F\u5473\u3067\u975E\u5E38\u306B\u9762\u767D\u3044\u3002",
  "id" : 73778535742967808,
  "created_at" : "2011-05-26 15:52:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73778310563373057",
  "text" : "\u4ECA\u9031\u306E\u65E5\u66DC\u65E5\u306B\u904E\u53BB\u6700\u9AD8\u30C4\u30A4\u30FC\u30C8\u6570\u3092\u8A18\u9332\u3057\u3066\u3044\u305F\u3089\u3057\u3044\u300261\u3063\u3066\u307B\u304B\u306E\u3078\u30F4\u30A3\u30FC\u30E6\u30FC\u30B6\u304B\u3089\u3057\u305F\u3089\uFF10\u306B\u8FD1\u4F3C\u3067\u304D\u308B\u30EC\u30D9\u30EB\u3067\u3059\u304C\u30FC\u3002",
  "id" : 73778310563373057,
  "created_at" : "2011-05-26 15:51:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73775492016259072",
  "text" : "\u6C17\u306B\u98DF\u308F\u306A\u3044\u3068\u3044\u3046\u304B\u3001\u6C17\u306B\u306A\u3063\u305F\u3068\u3044\u3046\u304B\u3002\u3046\u3093\u3002\u30CB\u30DB\u30F3\u30B4\u30E0\u30BA\u30AB\u30B7\u30A4\u30C7\u30B9\u3002",
  "id" : 73775492016259072,
  "created_at" : "2011-05-26 15:40:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73775369836175360",
  "text" : "\u81EA\u5206\u306E\u985E\u4F3C\u30E6\u30FC\u30B6\u30FC\u306B\u306B\u305B\u307B\u304C\u3044\u308B\u306E\u304C\u6C17\u306B\u98DF\u308F\u306A\u3044\u3002\u985E\u4F3C\u2026\uFF1F",
  "id" : 73775369836175360,
  "created_at" : "2011-05-26 15:39:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73771819559161856",
  "text" : "\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306B\u3082\u3089\u3063\u305F\u9854\u3092\u98DF\u3079\u305F\u3089\u4E2D\u6BD2\u304C\u51FA\u305F\u3002\u307F\u305F\u3044\u306A\u30B9\u30C8\u30FC\u30EA\u30FC\u306A\u3044\u304B\u306A\u3001\u3068\u304B\u30C0\u30FC\u30AF\u306A\u3053\u3068\u3092\u8003\u3048\u308B\uFF10\u6642\u904E\u304E\u3002",
  "id" : 73771819559161856,
  "created_at" : "2011-05-26 15:25:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73771118560940034",
  "geo" : { },
  "id_str" : "73771385784246273",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5E30\u5B85\u90E8\u306E\u5F8C\u8F29\u3044\u306A\u304B\u3063\u305F\u306E\u304B\u3002",
  "id" : 73771385784246273,
  "in_reply_to_status_id" : 73771118560940034,
  "created_at" : "2011-05-26 15:24:03 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73770021322637312",
  "geo" : { },
  "id_str" : "73770583321616385",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u306A\u3044\u308F\u30FC\u306A\u3093\u3066\u3044\u3063\u3061\u3083\u3046\u3088\u3046\u306A\u4EBA\u3092\u8CB4\u65B9\u306F\u304D\u3063\u3068\u9078\u3070\u306A\u3044\u3001\u306F\u305A\u3002",
  "id" : 73770583321616385,
  "in_reply_to_status_id" : 73770021322637312,
  "created_at" : "2011-05-26 15:20:52 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73767984031735808",
  "text" : "\u81EA\u5206\u306E\u540D\u524D\u3092\u4E00\u4EBA\u79F0\u306B\u3059\u308B\u306E\u306F\u306A\u3044\u306A\u3002\u3046\u3093\u3002",
  "id" : 73767984031735808,
  "created_at" : "2011-05-26 15:10:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73767903144583168",
  "text" : "\u9EBB\u96C0\u308F\u304B\u3093\u306A\u3044\u4EBA\u306B\u306F\u3055\u3063\u3071\u308A\u306ATL\u3067\u3059\u306D\u3001\u81EA\u91CD\u3057\u307E\u3059\u3002\u2026\u3068end\u306F\u81EA\u5632\u3057\u307E\u3059\u3002",
  "id" : 73767903144583168,
  "created_at" : "2011-05-26 15:10:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haipai_tsumo",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/vfvEv8V",
      "expanded_url" : "http:\/\/shindanmaker.com\/122623",
      "display_url" : "shindanmaker.com\/122623"
    } ]
  },
  "geo" : { },
  "id_str" : "73767429171449857",
  "text" : "\u6771\uFF12\u5C40\u3000\u81EA\u98A8\u5357\u3001\u30C9\u30E9\uFF12\u3002end313124\u306E\u624B\u724C\u306F\uFF13\uFF14\uFF16\uFF17\uFF19\u4E94\u4E94\u4E94\u4E03\u516B\u2463\u2466\u5317\u4E2D\u3002\u3069\u3046\u3057\u307E\u3057\u3087\u3046 http:\/\/t.co\/vfvEv8V #haipai_tsumo \n\u5317\u304B\uFF19\u304B\u30FB\u30FB\u30FB\uFF19\u304B\u306A\u3002",
  "id" : 73767429171449857,
  "created_at" : "2011-05-26 15:08:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/sChYy4v",
      "expanded_url" : "http:\/\/shindanmaker.com\/123458",
      "display_url" : "shindanmaker.com\/123458"
    } ]
  },
  "geo" : { },
  "id_str" : "73766330750337024",
  "text" : "end313124\u304C\u597D\u304D\u306A\u4EBA\u306B\u300C\u4ED8\u304D\u5408\u304A\u3046\u304B\uFF1F\u300D\u3068\u8A00\u3063\u305F\u3089\u2026\u76F8\u624B\u306F\u5C11\u3057\u9A5A\u3044\u305F\u9854\u3092\u3057\u3066\u300C\u672C\u6C17\u306B\u3059\u308B\u3088\uFF1F\u300D\u3068\u8A00\u3044\u307E\u3059\u3002 http:\/\/t.co\/sChYy4v  \n\u3048\u3063",
  "id" : 73766330750337024,
  "created_at" : "2011-05-26 15:03:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/g3djU1H",
      "expanded_url" : "http:\/\/news.livedoor.com\/article\/detail\/5586684\/",
      "display_url" : "news.livedoor.com\/article\/detail\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "73765382283984897",
  "text" : "\u4E2D\u8EAB\u306F\u6B63\u76F4\u3069\u3046\u3067\u3082\u3044\u3044\u3002\u4E00\u884C\u76EE\u306B\u60AA\u610F\u3057\u304B\u611F\u3058\u306A\u3044\u3002\n\u3042\u306A\u305F\u306F\u8AB0\u304B\u3092\u5E78\u305B\u306B\u3057\u305F\u3044\u3068\u9858\u3063\u305F\u3053\u3068\u306F\u3042\u308A\u307E\u3059\u304B\uFF1F http:\/\/t.co\/g3djU1H",
  "id" : 73765382283984897,
  "created_at" : "2011-05-26 15:00:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73765029001953280",
  "text" : "\u500B\u4EBA\u7684\u306B\u306F\u3082\u3046\u3061\u3087\u3063\u3068\u65E9\u304F\u5207\u3063\u3066\u307B\u3057\u3044\u3093\u3060\u3051\u3069\u30FB\u30FB\u30FB\u307E\u3041\u5F90\u3005\u306B\u65E9\u304F\u306A\u3063\u3066\u3044\u304F\u3067\u3057\u3087\u3046\u3002",
  "id" : 73765029001953280,
  "created_at" : "2011-05-26 14:58:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73764911771160576",
  "text" : "\uFF54\uFF4B\u7FCC\u65E5\u304C\u5E73\u65E5\u306E\u524D\u591C\u3067\u3082\u5E73\u6C17\u3067\u96C6\u307E\u308B\u30E1\u30F3\u30D0\u30FC\u3067\u3088\u304B\u3063\u305F\u3002\u305D\u3057\u3066\u65E9\u3005\u3068\u89E3\u6563\u3057\u3066\u304F\u308C\u308B\u30E1\u30F3\u30D0\u30FC\u3067\u3088\u304B\u3063\u305F\uFF57",
  "id" : 73764911771160576,
  "created_at" : "2011-05-26 14:58:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73764735224520704",
  "text" : "\u7D2F\u8A08\uFF0B27\uFF08\u713C\u304D\u9CE5\u306F\uFF15\u30AA\u30FC\u30EB\u3001\u30A6\u30DE\u30AA\u30AB\u306A\u3057\uFF09\u3000\u4E00\u4F4D\u304C\uFF0B\uFF14\uFF19\u3060\u304B\u3089\u4F55\u304B\u5FAE\u5999\u3060\u304C\u307E\u3041\u826F\u3057\u3068\u3057\u3088\u3046\u3002",
  "id" : 73764735224520704,
  "created_at" : "2011-05-26 14:57:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73764320386891776",
  "text" : "\u9EBB\u96C0\u304A\u3057\u307E\u3044\u3002\u30D0\u30AB\u30C5\u30AD\u3057\u3066\u305F\u53CB\u4EBA\u306B\u4E8C\u56DE\u76EE\u306E\u534A\u8358\u3067\u307E\u304F\u3089\u308C\u3061\u3083\u3044\u307E\u3057\u305F\u304C\u30011\u4F4D\u30013\u4F4D\u3067\u3057\u305F\u3002",
  "id" : 73764320386891776,
  "created_at" : "2011-05-26 14:55:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5E7C\u5973\u304A\u3055\u306A\u3044\u3093",
      "screen_name" : "osa9",
      "indices" : [ 3, 8 ],
      "id_str" : "81867478",
      "id" : 81867478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73724844927229952",
  "text" : "RT @osa9: \u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u304C\u4E00\u822C\u306B\u5E83\u304F\u666E\u53CA\u3059\u308B\u3068\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u51FA\u6765\u306A\u3044\u4EBA\u304B\u3089\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u8133\u306A\u3093\u3066\u8A00\u8449\u304C\u5E83\u307E\u308A\u3060\u3057\u3066\u3001\u300C\u6BBA\u3057\u3066\u3082new\u3059\u308C\u3070\u307E\u305F\u751F\u6210\u51FA\u6765\u308B\u3068\u601D\u3063\u305F\u300D\u300C\u72AF\u884C\u52D5\u6A5F\u306F\u982D\u306E\u4E2D\u306Bkill\u3057\u308D\u3063\u3066signal\u304C\u9001\u3089\u308C\u3066\u304D\u305F\u304B\u3089\u300D\u306A\u3093\u3066\u8A00\u3044\u51FA\u3059\u4EBA\u304C\u767A\u751F\u3059\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73714898164654082",
    "text" : "\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u304C\u4E00\u822C\u306B\u5E83\u304F\u666E\u53CA\u3059\u308B\u3068\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u51FA\u6765\u306A\u3044\u4EBA\u304B\u3089\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u8133\u306A\u3093\u3066\u8A00\u8449\u304C\u5E83\u307E\u308A\u3060\u3057\u3066\u3001\u300C\u6BBA\u3057\u3066\u3082new\u3059\u308C\u3070\u307E\u305F\u751F\u6210\u51FA\u6765\u308B\u3068\u601D\u3063\u305F\u300D\u300C\u72AF\u884C\u52D5\u6A5F\u306F\u982D\u306E\u4E2D\u306Bkill\u3057\u308D\u3063\u3066signal\u304C\u9001\u3089\u308C\u3066\u304D\u305F\u304B\u3089\u300D\u306A\u3093\u3066\u8A00\u3044\u51FA\u3059\u4EBA\u304C\u767A\u751F\u3059\u308B",
    "id" : 73714898164654082,
    "created_at" : "2011-05-26 11:39:35 +0000",
    "user" : {
      "name" : "\u5E7C\u5973\u304A\u3055\u306A\u3044\u3093",
      "screen_name" : "osa9",
      "protected" : false,
      "id_str" : "81867478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3276575341\/c0151bf58e8aa97864451de231640d88_normal.jpeg",
      "id" : 81867478,
      "verified" : false
    }
  },
  "id" : 73724844927229952,
  "created_at" : "2011-05-26 12:19:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73721473008795648",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 73721473008795648,
  "created_at" : "2011-05-26 12:05:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73705225390792704",
  "text" : "KU\u30EA\u30B9\u30C8\u3092\u305F\u307E\u306B\u8997\u3044\u3066\u3044\u308B\u304C\u9762\u767D\u3044\u3002\u3055\u3059\u304C\u3002",
  "id" : 73705225390792704,
  "created_at" : "2011-05-26 11:01:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73576694702809088",
  "text" : "RT @JOJO_math: \u300C\u82B1\u4EAC\u9662\u3000\u304D\u3055\u307E\u3053\u306E\u516C\u7406\u7CFB\u4F7F\u3044\u8FBC\u3093\u3067\u3044\u308B\u306A\u30C3\uFF01\u300D\u300C\u7B54\u3048\u308B\u5FC5\u8981\u306F\u306A\u3044\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73576111161880576",
    "text" : "\u300C\u82B1\u4EAC\u9662\u3000\u304D\u3055\u307E\u3053\u306E\u516C\u7406\u7CFB\u4F7F\u3044\u8FBC\u3093\u3067\u3044\u308B\u306A\u30C3\uFF01\u300D\u300C\u7B54\u3048\u308B\u5FC5\u8981\u306F\u306A\u3044\u300D",
    "id" : 73576111161880576,
    "created_at" : "2011-05-26 02:28:06 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 73576694702809088,
  "created_at" : "2011-05-26 02:30:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73570821234364416",
  "text" : "\u3042\u30FC\u3001\u30BF\u30EB\u30B9\u30AD\u306E\u9006\u8AAC\u6301\u3063\u3066\u304F\u308C\u3070\u826F\u304B\u3063\u305F\u3002\u6301\u3063\u3066\u304F\u308B\u3064\u3082\u308A\u3060\u3063\u305F\u306E\u306B\u2026\u3002",
  "id" : 73570821234364416,
  "created_at" : "2011-05-26 02:07:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73547187262459904",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046",
  "id" : 73547187262459904,
  "created_at" : "2011-05-26 00:33:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73547155754848256",
  "text" : "\u3061\u3087\u3063\u3068\u305A\u3064\u30D5\u30A9\u30ED\u30FC\u6570\u304C\u5897\u3048\u3066\u3044\u308B\u2026\u3042\u308A\u304C\u305F\u3044\u3060\u3002\u3055\u3057\u305F\u308B\u3053\u3068\u3082\u3064\u3076\u3084\u304D\u307E\u305B\u3093\u304C\u3002",
  "id" : 73547155754848256,
  "created_at" : "2011-05-26 00:33:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30F4\u30A3\u30F3\u30FB\u30E9\u30C6\u30A3\u30A8",
      "screen_name" : "evinlatie",
      "indices" : [ 3, 13 ],
      "id_str" : "112195383",
      "id" : 112195383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73385182496964608",
  "text" : "RT @evinlatie: \u6DBC\u5BAE\u30CF\uFF08\u30DF\u30EB\u30C8\u30F3\uFF09\u30EB\uFF08\u30D9\u30FC\u30B0\uFF09\u30D2\uFF08\u30EB\u30D9\u30EB\u30C8\uFF09\u306E\u6182\u9B31",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73384021526183936",
    "text" : "\u6DBC\u5BAE\u30CF\uFF08\u30DF\u30EB\u30C8\u30F3\uFF09\u30EB\uFF08\u30D9\u30FC\u30B0\uFF09\u30D2\uFF08\u30EB\u30D9\u30EB\u30C8\uFF09\u306E\u6182\u9B31",
    "id" : 73384021526183936,
    "created_at" : "2011-05-25 13:44:48 +0000",
    "user" : {
      "name" : "\u30A8\u30F4\u30A3\u30F3\u30FB\u30E9\u30C6\u30A3\u30A8",
      "screen_name" : "evinlatie",
      "protected" : false,
      "id_str" : "112195383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1685204356\/tw_icon_normal.jpg",
      "id" : 112195383,
      "verified" : false
    }
  },
  "id" : 73385182496964608,
  "created_at" : "2011-05-25 13:49:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73361456057421824",
  "geo" : { },
  "id_str" : "73362398400094208",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u662F\u975E\u611F\u60F3\u3092\u30C4\u30A4\u30FC\u30C8\u3057\u3066\u304F\u3060\u3055\u3044\u306A\u3002\u4E0B\u5BBF\u306E\u5B66\u751F\u306B\u306F\u3061\u3087\u3063\u3068\u9AD8\u3059\u304E\u308B\u2026\u3002",
  "id" : 73362398400094208,
  "in_reply_to_status_id" : 73361456057421824,
  "created_at" : "2011-05-25 12:18:53 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73360960747868160",
  "geo" : { },
  "id_str" : "73361943624286208",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u7406\u7CFB\u5973\u5B50\u306F\u533B\u2267\u8FB2\uFF1E\uFF1E\uFF1E\u7406\u3001\u5DE5\u2252\uFF10 \u5B66\u79D1\u306B\u3082\u56E0\u308B\u3051\u3069\u305D\u3093\u306A\u30A4\u30E1\u30FC\u30B8\u3060\u306A\u30FC",
  "id" : 73361943624286208,
  "in_reply_to_status_id" : 73360960747868160,
  "created_at" : "2011-05-25 12:17:05 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73361146043834368",
  "text" : "@np2i @mo5nya \u53CB\u9054\u3044\u3089\u306A\u3044\u306A\u3093\u3066\u8A00\u3044\u307E\u305B\u3093\u304C\u3001\u53CB\u9054\u3044\u306A\u3044\u3068\u884C\u52D5\u3067\u304D\u306A\u3044\u4EBA\u9593\u306F\u3069\u3046\u304B\u3068\u601D\u3044\u307E\u3059\u3088\u306D\u3047\u3002\u6709\u9650\u5B9F\u884C\u3063\u3066\u3053\u3068\u3067\u30D2\u30C8\u30AB\u30E9\u4ECA\u5EA6\u3084\u308A\u307E\u3059\uFF01",
  "id" : 73361146043834368,
  "created_at" : "2011-05-25 12:13:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73359578552737792",
  "geo" : { },
  "id_str" : "73360063829512192",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4E01\u5BE7\u306A\u5927\u5B66\u8077\u54E1\u3068\u304B\u5E0C\u5C11\u7A2E\u3060\u305E\u3002\u78BA\u304B\u306B\u56F3\u66F8\u9928\u3068\u304B\u306F\u304B\u306A\u308A\u307E\u3068\u3082\u3060\u304C\u3001\u5927\u62B5\u4E0D\u6A5F\u5ACC\u305D\u3046\u306B\u51C4\u304F\u9069\u5F53\u306B\u3042\u3057\u3089\u308F\u308C\u308B\u3002",
  "id" : 73360063829512192,
  "in_reply_to_status_id" : 73359578552737792,
  "created_at" : "2011-05-25 12:09:36 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 8, 13 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73355538464907264",
  "text" : "@mo5nya @np2i \u300C\u3048\u3001\u4ECA\u5165\u3063\u3066\u3053\u306A\u3044\u3067\u6B32\u3057\u304B\u3063\u305F\u2026\u300D\u306E\u30D1\u30BF\u30FC\u30F3\u3082\u3042\u308A\u305D\u3046\u3067\u3059\u306D\u3047\u3002\u7D50\u5C40\u30D2\u30C8\u30AB\u30E9\u306F\u4E00\u4EBA\u3067\u3084\u3063\u305F\u65B9\u304C\u826F\u3055\u305D\u3046\u3067\u3059\u306D\uFF57",
  "id" : 73355538464907264,
  "created_at" : "2011-05-25 11:51:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73353186022391808",
  "text" : "\u30EC\u30C8\u30ED\u30B9\u30DA\u30AF\u30C6\u30A3\u30D6\u5DEE\u3057\u5F15\u3044\u3066\u3082\u4EAC\u90FD\u3084\u3089\u5948\u826F\u306F\u597D\u304D\u3060\u3051\u3069\u306D\u30FC\u3002",
  "id" : 73353186022391808,
  "created_at" : "2011-05-25 11:42:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73352881549492224",
  "text" : "@np2i \u50D5\u306F\u307E\u3060\u307E\u3060\u99C6\u3051\u51FA\u3057\u3067\u3059\u304C\u305D\u306E\u77AC\u9593\u304C\u4F55\u3088\u308A\u5B09\u3057\u3044\u3067\u3059\u3088\u306D\u3047\u3002\u304A\u75B2\u308C\u69D8\u3067\u3059\u3002",
  "id" : 73352881549492224,
  "created_at" : "2011-05-25 11:41:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73352636514050048",
  "text" : "\u4E00\u3064\u96A3\u306E\u99C5\u3068\u306F\u8A00\u3048\u3001\u30D0\u30A4\u30C8\u5148\u3068\u9AD81\u3067\u8A2A\u308C\u305F\u5B87\u6CBB\u304C\u540C\u3058\u4F4D\u7F6E\u3060\u3063\u3066\u5B9F\u611F\u304C\u307E\u308B\u3067\u6E67\u304B\u306A\u3044\u3002\u61D0\u304B\u3057\u304D\u4EAC\u90FD\u5948\u826F\u306E\u65C5\u884C\u3002\u30EC\u30C8\u30ED\u30B9\u30DA\u30AF\u30C6\u30A3\u30D6\u306A\u3093\u3060\u308D\u3046\u306A\u3002",
  "id" : 73352636514050048,
  "created_at" : "2011-05-25 11:40:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 0, 11 ],
      "id_str" : "229752118",
      "id" : 229752118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "73351239383003136",
  "geo" : { },
  "id_str" : "73351980508119040",
  "in_reply_to_user_id" : 229752118,
  "text" : "@nisehorrrn \u304A\u524D\u306F\u4F55\u6B4C\u3046\u306E\u3055",
  "id" : 73351980508119040,
  "in_reply_to_status_id" : 73351239383003136,
  "created_at" : "2011-05-25 11:37:29 +0000",
  "in_reply_to_screen_name" : "nisehorrrn",
  "in_reply_to_user_id_str" : "229752118",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73351876044787713",
  "text" : "@mo5nya \u50D5\u30D2\u30C8\u30AB\u30E9\u3084\u3063\u305F\u3053\u3068\u306A\u3044\u3093\u3067\u4E00\u7DD2\u306B\u30D2\u30C8\u30AB\u30E9\u884C\u304D\u307E\u3057\u3087\u3046\u304B\uFF01\n\u2026\u3042\u308C\uFF1F",
  "id" : 73351876044787713,
  "created_at" : "2011-05-25 11:37:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73351028992520192",
  "text" : "\u30AB\u30E9\u30AA\u30B1\u884C\u304D\u305F\u3044\u306A\u2026",
  "id" : 73351028992520192,
  "created_at" : "2011-05-25 11:33:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73296029386158080",
  "text" : "\u3042\u3001\u7B46\u7BB1\u5FD8\u308C\u305F\u2026orz",
  "id" : 73296029386158080,
  "created_at" : "2011-05-25 07:55:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73290386684116992",
  "text" : "\u663C\u5BDD\u304B\u3089\u76EE\u899A\u3081\u305F\u3089\u504F\u982D\u75DB\u3002\u504F\u5FAE\u5206\u3002\u982D\u304C\u91CD\u305F\u3044\u3051\u3069\u30D0\u30A4\u30C8\u8A00\u3063\u3066\u304D\u307E\u3059\u3002",
  "id" : 73290386684116992,
  "created_at" : "2011-05-25 07:32:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73289701741694976",
  "text" : "RT @JOJO_math: \u300CTeX\u306E\u4F5C\u8005\u3067\u3042\u308BKnuth\u5148\u751F\u304C\u81EA\u8EAB\u306E\u8457\u66F8\u306E\u8AA4\u308A\u306B\u61F8\u3051\u305F\u61F8\u8CDE\u91D1\u306E\u984D\u306F\uFF1F\u300D\u300C256\u30DA\u30CB\u30FC\u300D\u300C\u52A0\u85E4\u548C\u4E5F\u5148\u751F\u304C\u4EAC\u90FD\u5927\u5B66\u3067\u306E\u8B1B\u7FA9\u3067\u914D\u5E03\u3057\u305F\u697D\u8B5C\u306B\u8A18\u8F09\u3055\u308C\u3066\u3044\u308B\u300E\u7D20\u6570\u306E\u6B4C\u300F\u306E\u4F5C\u66F2\u8005\u540D\u306F\uFF1F\u300D\u300C\u68EE\u5DDD\u548C\u7537\u300D\u300C\u2026\u2026\u3084\u308C\u3084\u308C\u3000\u672C\u7269\u306E\u3088\u3046\u3060\u306A\u3000\u305D\u3093\u306A\u304F\u3060\u3089\u306D\u3048 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73289208629964800",
    "text" : "\u300CTeX\u306E\u4F5C\u8005\u3067\u3042\u308BKnuth\u5148\u751F\u304C\u81EA\u8EAB\u306E\u8457\u66F8\u306E\u8AA4\u308A\u306B\u61F8\u3051\u305F\u61F8\u8CDE\u91D1\u306E\u984D\u306F\uFF1F\u300D\u300C256\u30DA\u30CB\u30FC\u300D\u300C\u52A0\u85E4\u548C\u4E5F\u5148\u751F\u304C\u4EAC\u90FD\u5927\u5B66\u3067\u306E\u8B1B\u7FA9\u3067\u914D\u5E03\u3057\u305F\u697D\u8B5C\u306B\u8A18\u8F09\u3055\u308C\u3066\u3044\u308B\u300E\u7D20\u6570\u306E\u6B4C\u300F\u306E\u4F5C\u66F2\u8005\u540D\u306F\uFF1F\u300D\u300C\u68EE\u5DDD\u548C\u7537\u300D\u300C\u2026\u2026\u3084\u308C\u3084\u308C\u3000\u672C\u7269\u306E\u3088\u3046\u3060\u306A\u3000\u305D\u3093\u306A\u304F\u3060\u3089\u306D\u3048\u3053\u3068\u3057\u3063\u3066\u3093\u306E\u306F\u2026\u300D",
    "id" : 73289208629964800,
    "created_at" : "2011-05-25 07:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 73289701741694976,
  "created_at" : "2011-05-25 07:30:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73212973233094656",
  "text" : "\u30D7\u30EC\u30BC\u30F3\u7D42\u308F\u3063\u305F\u30B0\u30EB\u30FC\u30D7\u306E\u4EBA\u307F\u3093\u306A\u643A\u5E2F\u3044\u3058\u3063\u3066\u308B\u3057",
  "id" : 73212973233094656,
  "created_at" : "2011-05-25 02:25:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73212141930422272",
  "text" : "\u30C1\u30FC\u30D7\u306A\u30D7\u30EC\u30BC\u30F3\u7D42\u308F\u3063\u3066\u6687\u306A\u308A",
  "id" : 73212141930422272,
  "created_at" : "2011-05-25 02:21:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73210216237383680",
  "text" : "RT @JOJO_math: \u307C\u304F\u306F\u541B\u3092\u3084\u308A\u3053\u3081\u305F\u304F\u3063\u3066\u9593\u9055\u3044\u3092\u6307\u6458\u3057\u305F\u3093\u3058\u3083\u3042\u306A\u3044\u305E\u30C3\uFF01\u307C\u304F\u3089\u306F\u672C\u5F53\u306E\u6570\u5B66\u8005\u3092\u3081\u3056\u3057\u3066\u3044\u308B\u304B\u3089\u3060\uFF01\u541B\u306E\u8A3C\u660E\u304C\u8AA4\u3063\u3066\u3044\u305F\u304B\u3089\u3060\uFF01\u76F8\u624B\u304C\u4EF2\u306E\u3044\u3044\u30E4\u30C4\u3060\u304B\u3089\u3063\u3066\u3000\u30BB\u30DF\u30CA\u30FC\u304C\u5EF6\u3073\u3066\u7D42\u96FB\u3092\u9003\u3059\u3068\u308F\u304B\u3063\u3066\u308B\u304B\u3089\u3063\u3066\u3000\u6570\u5B66\u8005\u306F\u52C7\u6C17\u3092\u6301\u3063\u3066\u3000\u8AA4\u308A\u3092\u6307\u6458\u3057 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73198619154591744",
    "text" : "\u307C\u304F\u306F\u541B\u3092\u3084\u308A\u3053\u3081\u305F\u304F\u3063\u3066\u9593\u9055\u3044\u3092\u6307\u6458\u3057\u305F\u3093\u3058\u3083\u3042\u306A\u3044\u305E\u30C3\uFF01\u307C\u304F\u3089\u306F\u672C\u5F53\u306E\u6570\u5B66\u8005\u3092\u3081\u3056\u3057\u3066\u3044\u308B\u304B\u3089\u3060\uFF01\u541B\u306E\u8A3C\u660E\u304C\u8AA4\u3063\u3066\u3044\u305F\u304B\u3089\u3060\uFF01\u76F8\u624B\u304C\u4EF2\u306E\u3044\u3044\u30E4\u30C4\u3060\u304B\u3089\u3063\u3066\u3000\u30BB\u30DF\u30CA\u30FC\u304C\u5EF6\u3073\u3066\u7D42\u96FB\u3092\u9003\u3059\u3068\u308F\u304B\u3063\u3066\u308B\u304B\u3089\u3063\u3066\u3000\u6570\u5B66\u8005\u306F\u52C7\u6C17\u3092\u6301\u3063\u3066\u3000\u8AA4\u308A\u3092\u6307\u6458\u3057\u306A\u304F\u3066\u306F\u306A\u3089\u306A\u3044\u6642\u304C\u3042\u308B\u304B\u3089\u3060\u305E\u30C3\uFF01\uFF01",
    "id" : 73198619154591744,
    "created_at" : "2011-05-25 01:28:05 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 73210216237383680,
  "created_at" : "2011-05-25 02:14:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73078102842019841",
  "text" : "TL\u304A\u3068\u306A\u3057\u3044\u3068\u304A\u3082\u3063\u305F\u3089\u6642\u9593\u306E\u305B\u3044\u304B\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 73078102842019841,
  "created_at" : "2011-05-24 17:29:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73076673695846400",
  "text" : "\u6700\u5F8C\u306E\u306F\u6C17\u3092\u4ED8\u3051\u306A\u304F\u3066\u306F\u30FB\u30FB\u30FB",
  "id" : 73076673695846400,
  "created_at" : "2011-05-24 17:23:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73076581953835008",
  "text" : "\u81EA\u5206\u306B\u3064\u3044\u3066\u826F\u304F\u306A\u3044\u6240\u307E\u3068\u3081\n\u8CA0\u3051\u305A\u5ACC\u3044\n\u5B88\u308A\u306E\u4F53\u5236\n\u53E3\u8ABF\u304C\u6642\u6298\u4E0A\u304B\u3089\u76EE\u7DDA",
  "id" : 73076581953835008,
  "created_at" : "2011-05-24 17:23:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73075709953843200",
  "text" : "\u6B63\u78BA\u306A\u8A00\u8A9E\u5316\u3063\u3066\u96E3\u3057\u3044\u3057\u8A9E\u5F0A\u3092\u751F\u3080\u3057\u805E\u3053\u3048\u65B9\u3067\u9F5F\u9F6C\u3092\u304D\u305F\u3059\u3051\u308C\u3069\u3001\u305D\u308C\u3067\u3082\u8A00\u8449\u306B\u51FA\u3059\u306E\u3063\u3066\u5927\u4E8B\u3060\u3088\u306A\u30FC\u3002",
  "id" : 73075709953843200,
  "created_at" : "2011-05-24 17:19:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73074992778182656",
  "text" : "\u611A\u75F4\u304B\u3089\u30CE\u30ED\u30B1\u304B\u3089\u5225\u308C\u8A71\u304B\u3089\u8A71\u306A\u3089\u306A\u3093\u3067\u3082\u805E\u304F\u306E\u304C\u597D\u304D\u3060\u3002\u9ED2\u3044\u8A71\u3082\u9752\u3044\u8A71\u3082\u597D\u304D\u3060\u3002",
  "id" : 73074992778182656,
  "created_at" : "2011-05-24 17:16:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73074758853459968",
  "text" : "\u30B5\u30FC\u30AF\u30EB\u306E\u4EBA\u3005\u3068\u558B\u3063\u3066\u305F\u3089\u3053\u3093\u306A\u6642\u9593\u306B\u5E30\u5B85\u30A1\uFF01\u3084\u3063\u3071\u558B\u308B\u306E\u597D\u304D\u3060\u3002\u8A71\u805E\u304F\u306E\u3082\u597D\u304D\u3060\u3002",
  "id" : 73074758853459968,
  "created_at" : "2011-05-24 17:15:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73074464287498241",
  "text" : "@np2i \u30D1\u30E9\u30C9\u30AF\u30B9\u306E\u65B9\u306F\u50D5\u3082\u56F3\u66F8\u9928\u3067\u501F\u308A\u3066\u307F\u307E\u3057\u305F\u3002\u3080\u3063\u3061\u3083\u9762\u767D\u3044\u4E0A\u306B\u6388\u696D\u306E\u53C2\u8003\u66F8\u306B\u3082\u306A\u308B\u306E\u3067\u8CB7\u3063\u3066\u3057\u307E\u304A\u3046\u304B\u3068\u601D\u3063\u3066\u307E\u3059\u3002",
  "id" : 73074464287498241,
  "created_at" : "2011-05-24 17:14:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72996278841257984",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 72996278841257984,
  "created_at" : "2011-05-24 12:04:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "indices" : [ 3, 17 ],
      "id_str" : "199329343",
      "id" : 199329343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72895534419034112",
  "text" : "RT @Satomii_Opera: \u3010\u3082\u3057\u3001\u30D5\u30A7\u30EB\u30DE\u30FC\u304CTwitter\u3092\u3084\u3063\u3066\u3044\u305F\u3089\u3011\u81EA\u7136\u6570n\u304C3\u4EE5\u4E0A\u306E\u6642\u3001\u81EA\u7136\u6570\u306En\u4E57\u30922\u3064\u306E\u81EA\u7136\u6570\u306En\u4E57\u306E\u548C\u306B\u5206\u3051\u308B\u3053\u3068\u304C\u3067\u304D\u306A\u3044\u3063\u3066\u5B9A\u7406\u3001\u4ECA\u8A3C\u660E\u304C\u601D\u3044\u3064\u3044\u305F\u3093\u3060\u3051\u3069\u306A\u30FC\uFF01 \u304B\u30FC\u3063\uFF01 \u3055\u3059\u304C\u306B140\u6587\u5B57\u3058\u3083\u66F8\u304D\u304D\u308C\u306A\u3044\u304B\u3089\u306A\u30FC\uFF01 \u304B\u30FC ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72623420654882816",
    "text" : "\u3010\u3082\u3057\u3001\u30D5\u30A7\u30EB\u30DE\u30FC\u304CTwitter\u3092\u3084\u3063\u3066\u3044\u305F\u3089\u3011\u81EA\u7136\u6570n\u304C3\u4EE5\u4E0A\u306E\u6642\u3001\u81EA\u7136\u6570\u306En\u4E57\u30922\u3064\u306E\u81EA\u7136\u6570\u306En\u4E57\u306E\u548C\u306B\u5206\u3051\u308B\u3053\u3068\u304C\u3067\u304D\u306A\u3044\u3063\u3066\u5B9A\u7406\u3001\u4ECA\u8A3C\u660E\u304C\u601D\u3044\u3064\u3044\u305F\u3093\u3060\u3051\u3069\u306A\u30FC\uFF01 \u304B\u30FC\u3063\uFF01 \u3055\u3059\u304C\u306B140\u6587\u5B57\u3058\u3083\u66F8\u304D\u304D\u308C\u306A\u3044\u304B\u3089\u306A\u30FC\uFF01 \u304B\u30FC\u3063\uFF01 \u30DE\u30B8\u3067\u7686\u30D3\u30C3\u30AF\u30EA\u3059\u308B\u8A3C\u660E\u306A\u3093\u3060\u3051\u3069\u306A\u30FC\uFF01",
    "id" : 72623420654882816,
    "created_at" : "2011-05-23 11:22:27 +0000",
    "user" : {
      "name" : "\u91CC\u898B",
      "screen_name" : "Satomii_Opera",
      "protected" : false,
      "id_str" : "199329343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212059931\/satomii_opera_normal.jpg",
      "id" : 199329343,
      "verified" : false
    }
  },
  "id" : 72895534419034112,
  "created_at" : "2011-05-24 05:23:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72856775963054080",
  "text" : "\u8981\u51FA\u5178\uFF57\uFF57\uFF57\uFF57",
  "id" : 72856775963054080,
  "created_at" : "2011-05-24 02:49:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 3, 13 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72856571939524608",
  "text" : "RT @Lisa_math: \u3048\u3053\u30FC\u3075\u3049\u3093\u3067\u975E\u516C\u5F0FRT\u3092\u3069\u3046\u3084\u3063\u305F\u3089\u3044\u3044\u306E\u304B\u308F\u304B\u3089\u306A\u304F\u306A\u308B\u304B\u3089\u3060\u3068\u5BB6\u306E\u8FD1\u304F\u306B\u5168\u56FD\u7684\u306B\u6709\u540D\u306A\u5EC3\u589F\u30B9\u30DD\u30C3\u30C8\u304C\u3042\u308B\u306E\u3067\u3059\u304C\u3001\u671D\u3063\u3071\u3089\u304B\u3089\u3064\u3044\u3063\u3077\u308B\u304B\u3089\u7DE0\u3081\u51FA\u3055\u308C\u3066\u3057\u307E\u3044\u307E\u3057\u305F\u3002[\u8981\u51FA\u5178]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/botis.org\/wiki\/PySocialBot\" rel=\"nofollow\"\u003EPySocialBot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72855905443659776",
    "text" : "\u3048\u3053\u30FC\u3075\u3049\u3093\u3067\u975E\u516C\u5F0FRT\u3092\u3069\u3046\u3084\u3063\u305F\u3089\u3044\u3044\u306E\u304B\u308F\u304B\u3089\u306A\u304F\u306A\u308B\u304B\u3089\u3060\u3068\u5BB6\u306E\u8FD1\u304F\u306B\u5168\u56FD\u7684\u306B\u6709\u540D\u306A\u5EC3\u589F\u30B9\u30DD\u30C3\u30C8\u304C\u3042\u308B\u306E\u3067\u3059\u304C\u3001\u671D\u3063\u3071\u3089\u304B\u3089\u3064\u3044\u3063\u3077\u308B\u304B\u3089\u7DE0\u3081\u51FA\u3055\u308C\u3066\u3057\u307E\u3044\u307E\u3057\u305F\u3002[\u8981\u51FA\u5178]",
    "id" : 72855905443659776,
    "created_at" : "2011-05-24 02:46:16 +0000",
    "user" : {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "protected" : false,
      "id_str" : "254452685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1875685697\/Lisa_n1_normal.png",
      "id" : 254452685,
      "verified" : false
    }
  },
  "id" : 72856571939524608,
  "created_at" : "2011-05-24 02:48:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72844388652421120",
  "text" : "\u96E8\u306E\u5F8C\u306F\u3061\u3087\u3063\u3068\u808C\u5BD2\u3044\u306D\u2026",
  "id" : 72844388652421120,
  "created_at" : "2011-05-24 02:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72833484053430272",
  "geo" : { },
  "id_str" : "72833930402861056",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u6570\u5B66\u3082\u6DF1\u523B\u306B\u305D\u306E\u554F\u984C\u3092\u62B1\u3048\u3066\u3044\u308B",
  "id" : 72833930402861056,
  "in_reply_to_status_id" : 72833484053430272,
  "created_at" : "2011-05-24 01:18:56 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72821066170499072",
  "text" : "\u9AEA\u4E7E\u304D\u5207\u308B\u524D\u306B\u5BDD\u305F\u305B\u3044\u3067\u5BDD\u7656\u304C\u2026",
  "id" : 72821066170499072,
  "created_at" : "2011-05-24 00:27:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72820452585783296",
  "text" : "\u3042\u3001\u8AAD\u3081\u305F\u3002\u306A\u3093\u3060\u3063\u305F\u3093\u3060\u308D\u3002",
  "id" : 72820452585783296,
  "created_at" : "2011-05-24 00:25:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72819527355871233",
  "text" : "\u30EA\u30B9\u30C8\u3082\u898B\u308C\u308B\u3002\u304B\u306E\u3069\u3070\u306B\u3083\u3093\u6C0F\u3082\u4E0D\u5177\u5408\u5831\u544A\u3057\u3066\u308B\u304B\u3089\u81EA\u5206\u3060\u3051\u3058\u3083\u306A\u3044\u3089\u3057\u3044\u3002",
  "id" : 72819527355871233,
  "created_at" : "2011-05-24 00:21:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72818950089605120",
  "text" : "\u643A\u5E2F\u3067\u3082\u30B8\u30AF\u30C4\u30A4\u3067\u3082iPod touch\u3067\u3082\u53D6\u5F97\u3067\u304D\u306A\u3044\u3068\u304B\u6B64\u5982\u4F55\u306B\u3002\u30EA\u30D7\u30E9\u30A4\u3068\u304B\u4ED6\u4EBA\u306E\uFF34\uFF2C\u306F\u898B\u3048\u308B\u4E0D\u601D\u8B70\u3002",
  "id" : 72818950089605120,
  "created_at" : "2011-05-24 00:19:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72818132435218432",
  "text" : "\uFF34\uFF2C\u53D6\u5F97\u3067\u304D\u306A\u3044\u2026",
  "id" : 72818132435218432,
  "created_at" : "2011-05-24 00:16:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72817801101975552",
  "text" : "\u304A\u306F\u3088\u3046\u3002",
  "id" : 72817801101975552,
  "created_at" : "2011-05-24 00:14:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72701664284520448",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4F0A\u52E2\u7530\u3055\u3093\u3000\u6587\u7CFB\u56DB\u5B66\u90E8\u5171\u540C\u68DF503\u3000\u5C0F\u91CE\u6CA2\u3055\u3093\u306F\u3061\u3087\u3063\u3068\u691C\u7D22\u306B\u306F\u639B\u304B\u3089\u306A\u304B\u3063\u305F\u308F\u3002\u307E\u305F\u3002",
  "id" : 72701664284520448,
  "created_at" : "2011-05-23 16:33:22 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72700435923877888",
  "geo" : { },
  "id_str" : "72700796575285249",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u77E5\u3089\u306A\u3044\u2026\uFF54\uFF4B\u4F0A\u52E2\u7530\u3055\u3093\u306E\u306B\u62C5\u5F53\u5206\u306E\u7D19\u51FA\u3057\u3066\u304A\u3053\u3046\u3068\u601D\u3063\u305F\u3089\u305D\u308C\u3082\u767A\u898B\u3067\u304D\u306A\u304B\u3063\u305F\u3002\u30AF\u30E9\u30B7\u30B9\u898B\u3066\u304B\u3089\u9589\u3058\u308B\u3053\u3068\u306B\u3059\u308B\u3002\u3061\u3087\u3063\u3068\u307E\u3063\u3066\u306D\u3002",
  "id" : 72700796575285249,
  "in_reply_to_status_id" : 72700435923877888,
  "created_at" : "2011-05-23 16:29:55 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72700545546199041",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u30C7\u30B9\u30AF\u30C8\u30C3\u30D7PC\u306B\u306F\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u30CE\u30B7",
  "id" : 72700545546199041,
  "created_at" : "2011-05-23 16:28:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72699991495421952",
  "geo" : { },
  "id_str" : "72700327341723648",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3044\u3084\u3001\u6559\u6388\u306E\u90E8\u5C4B\u306E\u524D\u306B\u8CB8\u3057\u51FA\u3057\u3067\u30B3\u30D4\u30FC\u306E\u675F\u304C\u3042\u308B\u304B\u3089\u305D\u308C\u3092\u5404\u81EA\u304C\u30B3\u30D4\u30FC\u3057\u308D\u3063\u3066\u3055\u3002\u539F\u66F8\u306F\u9AD8\u3059\u304E\u308B\u3060\u308D\u3046\u3057\u3002",
  "id" : 72700327341723648,
  "in_reply_to_status_id" : 72699991495421952,
  "created_at" : "2011-05-23 16:28:03 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72700177156284418",
  "text" : "\u4E00\u65E5\u4E88\u5099\u6821\u6642\u4EE3\u3068\u540C\u7B49\u306E\u91CD\u3055\u306E\u30AB\u30D0\u30F3\u3092\u80CC\u8CA0\u3063\u3066\u305F\u3063\u3066\u306E\u3082\u3042\u308B\u304B\u3082\u3002\u307E\u3041ipod\u304B\u3089TL\u306F\u9664\u3044\u3066\u307F\u308B\u3051\u3069\u306D\u30FC",
  "id" : 72700177156284418,
  "created_at" : "2011-05-23 16:27:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72699435997609984",
  "geo" : { },
  "id_str" : "72699791288700928",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4ECA\u65E5\uFF13\u30DA\u30FC\u30B8\u8FD1\u304F\u9032\u3093\u3060\u3051\u3069\u914D\u3089\u308C\u305F\u5206\u5168\u90E8\u3084\u3063\u3068\u3051\u3070\u5927\u4E08\u592B\u306A\u306F\u305A\u2026\u3061\u3087\u3063\u3068\u8DB3\u308A\u306A\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u304B\u3089\u3042\u308C\u306A\u3089\u30B3\u30D4\u30FC\u3057\u306B\u884C\u304F\u3079\u304D\u305D\u3046\u3059\u3079\u304D\u3002",
  "id" : 72699791288700928,
  "in_reply_to_status_id" : 72699435997609984,
  "created_at" : "2011-05-23 16:25:55 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72699469304561664",
  "text" : "\u3067\u3082\u706B\u66DC\u5206\u306E\u4E88\u7FD2\u306F\u6E08\u307E\u305B\u3066\u3042\u308B\u304B\u3089\u5927\u4E08\u592B\u3060\u306A",
  "id" : 72699469304561664,
  "created_at" : "2011-05-23 16:24:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72699302266417153",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u624B\u52A0\u6E1B\u306F\u3057\u306A\u3044\u3067\u5BDD\u308B\u3088\uFF01\u6628\u65E5\u306F\uFF11\u9650\u304B\u3089\uFF15\u9650\u307E\u3067\uFF08\uFF13\u9650\u9664\u304F\uFF09\u6388\u696D\u666E\u901A\u306B\u51FA\u305F\u4E0A\u3067\u30D0\u30A4\u30C8\u3060\u3063\u305F\u304B\u3089\u3061\u3087\u3063\u3068\u75B2\u308C\u305F\u3002\u96E8\u306B\u3082\u6253\u305F\u308C\u305F\u3002\u9031\u306E\u521D\u3081\u306B\u3057\u3066\u6E80\u8EAB\u5275\u75CD\u3060\u3002",
  "id" : 72699302266417153,
  "created_at" : "2011-05-23 16:23:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72698818164043777",
  "text" : "\u305D\u308C\u4EE5\u964D\u306F\uFF10\uFF05\u3063\u3066\u306A\u3063\u3066\u308B\u3051\u3069\u6674\u308C\u308B\u306E\u3060\u308D\u3046\u304B\u30FB\u30FB\u30FB\u3002\u3068\u308A\u3042\u3048\u305A\u4E8C\u9650\u306F\u5148\u9031\u5BDD\u904E\u3054\u3057\u305F\u3057\u51FA\u3066\u304A\u304D\u305F\u3044\u3051\u3069\u96E8\u3060\u3063\u305F\u3089\u3061\u3087\u3063\u3068\u51FA\u308B\u6642\u9593\u8003\u3048\u3088\u3046\u304B\u306A\u30FB\u30FB\u30FB\u3002",
  "id" : 72698818164043777,
  "created_at" : "2011-05-23 16:22:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72698558096211968",
  "text" : "\u4EAC\u90FD\u5357\u90E8\u306E\u4ECA\u65E5\u306E\u5929\u6C17\u3067\u3059\u3002\uFF10\u6642\u304B\u3089\uFF16\u6642\u306F\u6982\u306D\u96E8\u3001\uFF19\uFF10%\u306E\uFF08\u7D71\u8A08\u7684\uFF09\u78BA\u7387\u3067\u96E8\u3067\u3057\u3087\u3046\u3002\uFF16\u6642\u304B\u3089\uFF11\uFF12\u6642\u306F\uFF15\uFF10%\u306E\uFF08\u7D71\u8A08\u7684\uFF09\u78BA\u7387\u3067\u96E8\u3067\u6771\u306E\u98A8\u304C\u89B3\u6E2C\u3055\u308C\u308B\u3067\u3057\u3087\u3046\u3002",
  "id" : 72698558096211968,
  "created_at" : "2011-05-23 16:21:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72684846387965953",
  "geo" : { },
  "id_str" : "72688209368326144",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3044\u3084\u3001\u30D0\u30A4\u30C8\u3067\u3059",
  "id" : 72688209368326144,
  "in_reply_to_status_id" : 72684846387965953,
  "created_at" : "2011-05-23 15:39:54 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72684515226693633",
  "text" : "\u5E30\u5B85\u30A1\uFF01\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u306A\u3070\u3001\u306C\u308C\u306D\u305A\u307F\u3002",
  "id" : 72684515226693633,
  "created_at" : "2011-05-23 15:25:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72674550374080512",
  "text" : "\u3067\u307E\u3061 \u307E\u3067 \u3067\u3093\u3061 \u6301\u305F\u306A\u3044",
  "id" : 72674550374080512,
  "created_at" : "2011-05-23 14:45:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72674384778764289",
  "text" : "\u51FA\u753A\u7740\u306E\u6BB5\u968E\u3067\u65E5\u4ED8\u5909\u308F\u308A\u305D\u3046\u2026",
  "id" : 72674384778764289,
  "created_at" : "2011-05-23 14:44:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72674258521817088",
  "text" : "\u30AD\u30EC\u3044\u306B\u30AA\u30C1\u3066\u308B\u306A\u3001\u3053\u308C",
  "id" : 72674258521817088,
  "created_at" : "2011-05-23 14:44:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "indices" : [ 3, 11 ],
      "id_str" : "115380002",
      "id" : 115380002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72674179283038208",
  "text" : "RT @nedikes: \u96FB\u7403\u300E\u4FFA\u30AD\u30EC\u308B\u3068\u5468\u308A\u304C\u898B\u3048\u306A\u304F\u306A\u308B\u6027\u683C\u3067\u3055\u3041\u300F\u3000\u30DE\u30A4\u30AF\u300E\u3042\u3041\u50D5\u306F\u4F55\u3082\u8A00\u308F\u306A\u304F\u306A\u308B\u30BF\u30A4\u30D7\u3060\u306D\u300F\u3000\u606F\u300E\u5FD9\u3057\u3044\u6642\u306F\u7279\u306B\u30AD\u30EC\u6613\u3044\u3088\u4FFA\u300F\u3000\u30AB\u30C3\u30BF\u30FC\u300E\u79C1\u306F\u3042\u307E\u308A\u30AD\u30EC\u306A\u304F\u306A\u3063\u305F\u306A\u3041\u5E74\u304B\u3082\u300F\u3000\u7D46\u300E\u3093\u3093\u50D5\u30AD\u30EC\u6613\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u300F\u3000\u7E01\u300E\u4FFA\u3082\u3060\u2026\u307E\u3041\u3053\u3044\u3064\u7A0B\u3058\u3083\u306A\u3044\u3051\u308C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72667226565640193",
    "text" : "\u96FB\u7403\u300E\u4FFA\u30AD\u30EC\u308B\u3068\u5468\u308A\u304C\u898B\u3048\u306A\u304F\u306A\u308B\u6027\u683C\u3067\u3055\u3041\u300F\u3000\u30DE\u30A4\u30AF\u300E\u3042\u3041\u50D5\u306F\u4F55\u3082\u8A00\u308F\u306A\u304F\u306A\u308B\u30BF\u30A4\u30D7\u3060\u306D\u300F\u3000\u606F\u300E\u5FD9\u3057\u3044\u6642\u306F\u7279\u306B\u30AD\u30EC\u6613\u3044\u3088\u4FFA\u300F\u3000\u30AB\u30C3\u30BF\u30FC\u300E\u79C1\u306F\u3042\u307E\u308A\u30AD\u30EC\u306A\u304F\u306A\u3063\u305F\u306A\u3041\u5E74\u304B\u3082\u300F\u3000\u7D46\u300E\u3093\u3093\u50D5\u30AD\u30EC\u6613\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u300F\u3000\u7E01\u300E\u4FFA\u3082\u3060\u2026\u307E\u3041\u3053\u3044\u3064\u7A0B\u3058\u3083\u306A\u3044\u3051\u308C\u3069\u3082\u300F\u3000\u30D7\u30EA\u30F3\u300E\u2026\u2026\u30D7\u30C3\u30C1\u30F3\u300F",
    "id" : 72667226565640193,
    "created_at" : "2011-05-23 14:16:31 +0000",
    "user" : {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "protected" : false,
      "id_str" : "115380002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009659425\/___normal.png",
      "id" : 115380002,
      "verified" : false
    }
  },
  "id" : 72674179283038208,
  "created_at" : "2011-05-23 14:44:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72673461968969728",
  "text" : "\u5DE5\u3001\u304A\u524D\u304C\u3044\u3046\u306A\u3088\u30FC",
  "id" : 72673461968969728,
  "created_at" : "2011-05-23 14:41:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "indices" : [ 3, 11 ],
      "id_str" : "115380002",
      "id" : 115380002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72673367676813312",
  "text" : "RT @nedikes: \u30A2\u30A4\u30A6\u5DE5\u624D\u3000\u3000\u30A2\u300E\u304A\u524D\u300C\u30A8\u300D\u3058\u3083\u306A\u3044\u306A\u300F\u3000\u5DE5\u300E\u3042\u3063\u30D0\u30EC\u3061\u3083\u3063\u305F\u300F\u3000\u30A2\u300E\u300C\u30AA\u300D\u3082\u9055\u3046\u3060\u308D\u300F\u3000\u624D\u300E\u30B9\u30DF\u30DE\u30BB\u30F3\u5C45\u5FC3\u5730\u826F\u304F\u3066\u3064\u3044\u300F\u3000\u30A2\u300E\u3063\u305F\u304F\u2026\u2026\u3044\u3044\u3051\u308C\u3069\u3082\u5C11\u3057\u3057\u305F\u3089\u3059\u3050\u5E30\u308C\u3088\u3049\u2026\u300F\u3000\u5DE5\u300E\u307F\u3093\u306A\u307E\u3060\u3044\u3066\u826F\u3044\u3063\u3066!!\u300F\u3000\u4E5C\u5915\u535C\u4E8C\u4E3F\u516B\u5315\u6729\u53B6\u3405\u4E47\u5F50\u53E3\u300E\u300E\u300E\u30DE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72645052979085312",
    "text" : "\u30A2\u30A4\u30A6\u5DE5\u624D\u3000\u3000\u30A2\u300E\u304A\u524D\u300C\u30A8\u300D\u3058\u3083\u306A\u3044\u306A\u300F\u3000\u5DE5\u300E\u3042\u3063\u30D0\u30EC\u3061\u3083\u3063\u305F\u300F\u3000\u30A2\u300E\u300C\u30AA\u300D\u3082\u9055\u3046\u3060\u308D\u300F\u3000\u624D\u300E\u30B9\u30DF\u30DE\u30BB\u30F3\u5C45\u5FC3\u5730\u826F\u304F\u3066\u3064\u3044\u300F\u3000\u30A2\u300E\u3063\u305F\u304F\u2026\u2026\u3044\u3044\u3051\u308C\u3069\u3082\u5C11\u3057\u3057\u305F\u3089\u3059\u3050\u5E30\u308C\u3088\u3049\u2026\u300F\u3000\u5DE5\u300E\u307F\u3093\u306A\u307E\u3060\u3044\u3066\u826F\u3044\u3063\u3066!!\u300F\u3000\u4E5C\u5915\u535C\u4E8C\u4E3F\u516B\u5315\u6729\u53B6\u3405\u4E47\u5F50\u53E3\u300E\u300E\u300E\u30DE\u30B8\u3067!?\u300F\u300F\u300F\u3000\u30A2\u300E\u591A\u3059\u304E\u306D!?\u300F",
    "id" : 72645052979085312,
    "created_at" : "2011-05-23 12:48:24 +0000",
    "user" : {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "protected" : false,
      "id_str" : "115380002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009659425\/___normal.png",
      "id" : 115380002,
      "verified" : false
    }
  },
  "id" : 72673367676813312,
  "created_at" : "2011-05-23 14:40:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 6, 16 ],
      "id_str" : "131534834",
      "id" : 131534834
    }, {
      "name" : "Ronove\uFF08\u308D\u306E\uFF093.5G\u7D99\u7D9A\u52E2",
      "screen_name" : "svs_rono",
      "indices" : [ 24, 33 ],
      "id_str" : "131561880",
      "id" : 131561880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72672598957359105",
  "text" : "\uFF27\uFF2A RT @maru_mtod: \u304A\u3064 RT @svs_rono: \u3067\u3051\u305F\uFF57\uFF57 N(1.1861655, 0.001897619^2)\u306E\u6B63\u898F\u5206\u5E03\u66F2\u7DDA  http:\/\/twitpic.com\/51iun1",
  "id" : 72672598957359105,
  "created_at" : "2011-05-23 14:37:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72671741691953153",
  "text" : "\u6A5F\u8EE2\u306E\u5229\u3044\u305F\u3053\u3068\u3092\u8A00\u3048\u306A\u3044\u306A\u3041",
  "id" : 72671741691953153,
  "created_at" : "2011-05-23 14:34:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72671635819331584",
  "text" : "\u5929\u6C17\u306E\u8EE2\u6A5F",
  "id" : 72671635819331584,
  "created_at" : "2011-05-23 14:34:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72671416834719744",
  "text" : "\u6674\u308C\u3061\u3083\u3046\u3068\u6691\u3044\u304B\u3089\u306D\u3001\u66C7\u308A\u304F\u3089\u3044\u304C\u3044\u3044\u306A\u3041",
  "id" : 72671416834719744,
  "created_at" : "2011-05-23 14:33:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72671272823296000",
  "text" : "\u660E\u65E5\u306F\u305B\u3081\u3066\u66C7\u308A\u304C\u3044\u3044\u306A\u30FC",
  "id" : 72671272823296000,
  "created_at" : "2011-05-23 14:32:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72670520377741312",
  "geo" : { },
  "id_str" : "72670831339257857",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305D\u308C\u30EA\u30A2\u5145\u3061\u3083\u3046\u2026\u30CD\u30C8\u5145\u3084\u2026\u3002(\u30CD\u30C3\u30C8\u4E0A\u306E\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u5145\u5B9F\u7684\u306A\u610F\u5473\u3067)",
  "id" : 72670831339257857,
  "in_reply_to_status_id" : 72670520377741312,
  "created_at" : "2011-05-23 14:30:51 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 32, 43 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72670238428241920",
  "text" : "\u5929\u6587\u5206\u91CE\u306E\u30AF\u30E9\u30B9\u30BF\u304B\u3068\u601D\u3063\u305F\u306A\u3093\u3066\u53E3\u304C\u88C2\u3051\u3066\u3082\u8A00\u3048\u306A\u3044\u306A RT @magokoro84: \u305D\u308A\u3083\u30FC\u661F\u5149\u5352\u306E\u4EAC\u5927\u751F\u3067Twitter\u3084\u3063\u3066\u308B\u3072\u3068\u7D50\u69CB\u591A\u3044\u3060\u308D\u3046\u306A\u3042",
  "id" : 72670238428241920,
  "created_at" : "2011-05-23 14:28:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72669964577947649",
  "text" : "\u96FB\u6C60\u5C11\u306A\u3044\u3051\u3069\u3053\u306E\u6642\u9593\u3060\u3057\u9006\u306B\u4F7F\u3044\u304D\u3063\u3066\u3084\u308D\u3046\u304B",
  "id" : 72669964577947649,
  "created_at" : "2011-05-23 14:27:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72669691478421504",
  "text" : "\u73CD\u3057\u304F\u9023\u7D9A\u7684\u306A\u30C4\u30A4\u30FC\u30C8\u3002\uFF34\uFF2C\u6C5A\u3057\u3066\u7533\u3057\u8A33\u306A\u3044\u3051\u3069\u3059\u3050\u6D17\u3044\u6D41\u3055\u308C\u308B\u3053\u3068\u3067\u3057\u3087\u3046\u3002",
  "id" : 72669691478421504,
  "created_at" : "2011-05-23 14:26:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72669302985207809",
  "text" : "\u6570\uFF11\u307E\u3067\u3057\u304B\u5C65\u4FEE\u3057\u3066\u306A\u3044\u3068\u8A00\u3044\u5F35\u308B\u5927\u5B66\u751F\u2026\u304A\u524D\u306E\u30AB\u30EA\u30AD\u30E5\u30E9\u30E0\u306F\u304A\u304B\u3057\u3044\u3002",
  "id" : 72669302985207809,
  "created_at" : "2011-05-23 14:24:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72669142708264961",
  "text" : "\u58F2\u8CB7\u3057\u306A\u304C\u3089\u30D0\u30A4\u30D0\u30A4\u3067\u3059\u304B\u306D(\u96FB\u6C60\u7684\u306B)",
  "id" : 72669142708264961,
  "created_at" : "2011-05-23 14:24:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72668982456496128",
  "text" : "\u98DF\u3079\u7269\u3067\u904A\u3093\u3058\u3083\u3044\u3051\u307E\u305B\u3093\u3066\u8A00\u308F\u308C\u308B\u3051\u3069\u3001\u304B\u306B\u30D1\u30F3\u3068\u304B\u30B1\u30F3\u30AB\u58F2\u3063\u3066\u308B\u3088\u306D\u3002\u8A00\u8449\u3067\u904A\u3093\u3058\u3083\u3044\u3051\u307E\u305B\u3093\u3066\u8A00\u308F\u308C\u306A\u3044\u3051\u3069\u9870\u8E59\u3068\u304B\u8CB7\u3046\u3088\u306D\u3002",
  "id" : 72668982456496128,
  "created_at" : "2011-05-23 14:23:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72668594797953024",
  "text" : "\u8A00\u8449\u306E\u5217\u3067\u306F\u53CE\u675F\u3057\u306A\u3044\u3002\u5C31\u8077\u3082\u3057\u306A\u3044\u3002\u3044\u3084\u3001\u51FA\u6765\u306A\u3044\u3002",
  "id" : 72668594797953024,
  "created_at" : "2011-05-23 14:21:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72668354422390784",
  "text" : "\u72EC\u308A\u3088\u304C\u308A\u3001\u30D2\u30C8\u30EA\u30CE\u30E8\u30EB\u3001\u4E00\u4EBA\u904A\u3073\u3001\u8A00\u8449\u904A\u3073\u3002",
  "id" : 72668354422390784,
  "created_at" : "2011-05-23 14:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72668072363827200",
  "text" : "\u3042\u306E\u65E5\u610F\u3092\u6C7A\u3057\u3066\u30D5\u30A9\u30ED\u30FC\u3057\u305F\u77E5\u308A\u5408\u3044\u304B\u3089\u5E30\u3063\u3066\u3053\u306A\u3044\u30D5\u30A9\u30ED\u30FC\u3092\u50D5\u306F\u307E\u3060\u77E5\u3089\u306A\u3044",
  "id" : 72668072363827200,
  "created_at" : "2011-05-23 14:19:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72667566061010945",
  "text" : "\u305D\u3093\u306A\u3053\u3093\u306A\u3067\u96FB\u6C60\u304C\uFF11\uFF17\uFF05\niPod touch\u6301\u3063\u3066\u304D\u305F\u3051\u3069\u30A4\u30E4\u30DB\u30F3\u306A\u3044\u3042\u308B\u963F\u4FDD\u306E\u4E00\u8E74",
  "id" : 72667566061010945,
  "created_at" : "2011-05-23 14:17:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72667287898963969",
  "text" : "\u82A5\u5DDD\u9F8D\u4E4B\u4ECB\u306E\u039A",
  "id" : 72667287898963969,
  "created_at" : "2011-05-23 14:16:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72667099859914752",
  "text" : "\u5BDD\u3066\u306A\u3044\u306E\u306B\u964D\u308A\u904E\u3054\u3059\u3068\u3044\u3046\u3042\u308B\u963F\u4FDD\u306E\u4E00\u77AC",
  "id" : 72667099859914752,
  "created_at" : "2011-05-23 14:16:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72666891012947968",
  "text" : "\u3042\u3001\u6298\u308A\u8FD4\u305B\u308B\u3002\u52A9\u304B\u3063\u305F\u3002\u307E\u305F\u30BF\u30AF\u30B7\u30FC\u30D1\u30BF\u30FC\u30F3\u304B\u3068\u601D\u3063\u305F\u2026\u3002",
  "id" : 72666891012947968,
  "created_at" : "2011-05-23 14:15:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72666174034411520",
  "text" : "\u3042\u3001\u3084\u3070\u2026",
  "id" : 72666174034411520,
  "created_at" : "2011-05-23 14:12:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72661780538736640",
  "geo" : { },
  "id_str" : "72665133930913792",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod \u81EA\u5206\u306F\u7B2C\u96F6\u8A00\u8A9E \u6570\u5B66\u3001\u7B2C\u4E00\u8A00\u8A9E \u65E5\u672C\u8A9E\u3001\u7B2C\u4E8C\u8A00\u8A9E \u82F1\u8A9E\u3001\u7B2C\u4E09\u8A00\u8A9E \uFF23\u3001\u7B2C\u56DB\u8A00\u8A9E \u30D5\u30E9\u30F3\u30B9\u8A9E\u3068\u3044\u3046\u611F\u3058\u3067\u3059\u306D",
  "id" : 72665133930913792,
  "in_reply_to_status_id" : 72661780538736640,
  "created_at" : "2011-05-23 14:08:12 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72657020666392576",
  "geo" : { },
  "id_str" : "72659902438457344",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5426\u3063\uFF01\u3066\u304B\u305D\u306E\u8AD6\u7406\u3060\u3068\u5A2F\u697D\u5168\u822C\u5F97\u306F\u306A\u3044\u305C\u2026\u3002",
  "id" : 72659902438457344,
  "in_reply_to_status_id" : 72657020666392576,
  "created_at" : "2011-05-23 13:47:25 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72607140606517248",
  "text" : "\u307E\u3001\u6307\u6458\u3057\u305F\u306E\u4FFA\u306A\u3093\u3060\u3051\u3069\u2190",
  "id" : 72607140606517248,
  "created_at" : "2011-05-23 10:17:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72607052173807617",
  "text" : "\u4E88\u5099\u6821\u8B1B\u5E2B\u304C\u8A08\u7B97\u30DF\u30B9\u3092\u6307\u6458\u3055\u308C\u3066\u300C\u6570\u5B66\u8005\u306F\u7B97\u6570\u306F\u82E6\u624B\u306A\u3093\u3060\u300D\u3063\u3066\u82E6\u3057\u7D1B\u308C\u306B\u8A00\u3063\u3066\u305F\u3051\u3069\u6700\u8FD1\u6B63\u3057\u3044\u3068\u601D\u3046\u3088\u3046\u306B\u306A\u3063\u305F\u306A\u3002",
  "id" : 72607052173807617,
  "created_at" : "2011-05-23 10:17:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B7\u30FC\u30BF",
      "screen_name" : "Perfect_Insider",
      "indices" : [ 3, 19 ],
      "id_str" : "108894387",
      "id" : 108894387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72606716285566976",
  "text" : "RT @Perfect_Insider: \u3068\u304D\u3069\u304D\u300C\u6570\u5B66\u5F97\u610F\u306A\u3089\u8A08\u7B97\u3067\u304D\u307E\u3059\u3088\u306D\uFF1F\u300D\u3068\u8A00\u308F\u308C\u308B\u3053\u3068\u304C\u3042\u308B\u304C\u3001\u5168\u304F\u9006\u3002\u6570\u5B66\u304C\u5F97\u610F\u306A\u4EBA\u306F\u300C\u3044\u304B\u306B\u3057\u305F\u3089\u8907\u96D1\u306A\u8A08\u7B97\u3092\u697D\u306B\u3067\u304D\u308B\u304B\u3002\u305D\u3046\u3044\u3046\u65B9\u6CD5\u306F\u306A\u3044\u304B\u300D\u3068\u8003\u3048\u308B\u3088\u3046\u306A\u601D\u8003\u56DE\u8DEF\u306A\u306E\u3067\u3001\u611A\u76F4\u306A\u8A08\u7B97\u306F\u975E\u5E38\u306B\u82E6\u624B\u306A\u3053\u3068\u304C\u591A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71964797373128704",
    "text" : "\u3068\u304D\u3069\u304D\u300C\u6570\u5B66\u5F97\u610F\u306A\u3089\u8A08\u7B97\u3067\u304D\u307E\u3059\u3088\u306D\uFF1F\u300D\u3068\u8A00\u308F\u308C\u308B\u3053\u3068\u304C\u3042\u308B\u304C\u3001\u5168\u304F\u9006\u3002\u6570\u5B66\u304C\u5F97\u610F\u306A\u4EBA\u306F\u300C\u3044\u304B\u306B\u3057\u305F\u3089\u8907\u96D1\u306A\u8A08\u7B97\u3092\u697D\u306B\u3067\u304D\u308B\u304B\u3002\u305D\u3046\u3044\u3046\u65B9\u6CD5\u306F\u306A\u3044\u304B\u300D\u3068\u8003\u3048\u308B\u3088\u3046\u306A\u601D\u8003\u56DE\u8DEF\u306A\u306E\u3067\u3001\u611A\u76F4\u306A\u8A08\u7B97\u306F\u975E\u5E38\u306B\u82E6\u624B\u306A\u3053\u3068\u304C\u591A\u3044\u3002",
    "id" : 71964797373128704,
    "created_at" : "2011-05-21 15:45:19 +0000",
    "user" : {
      "name" : "\u30B7\u30FC\u30BF",
      "screen_name" : "Perfect_Insider",
      "protected" : false,
      "id_str" : "108894387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595611044661198848\/Q28LODTo_normal.jpg",
      "id" : 108894387,
      "verified" : false
    }
  },
  "id" : 72606716285566976,
  "created_at" : "2011-05-23 10:16:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 0, 12 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72297867192180738",
  "geo" : { },
  "id_str" : "72530124825833472",
  "in_reply_to_user_id" : 114792585,
  "text" : "@undefined_k \u5076\u7136\u3067\u3057\u3087\u3046\u304C\u4ECA\u65E5\u306E\u6388\u696D\u3067\u30D0\u30CA\u30C3\u30CF\uFF65\u30BF\u30EB\u30B9\u30AD\u30FC\u306E\u30D1\u30E9\u30C9\u30C3\u30AF\u30B9\u51FA\u3066\u304D\u3066\u8B0E\u306E\u611F\u52D5\u3067\u3057\u305F\u30FC",
  "id" : 72530124825833472,
  "in_reply_to_status_id" : 72297867192180738,
  "created_at" : "2011-05-23 05:11:43 +0000",
  "in_reply_to_screen_name" : "undefined_k",
  "in_reply_to_user_id_str" : "114792585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72524626869239808",
  "text" : "\u4E00\u90E8\u306E\u4EBA\u6587\u5B66\u306F\u5C3D\u6587\u5B66\u90E8\u306B\u306A\u308A\u304B\u3051\u3066\u306F\u3044\u307E\u3044\u304B\u3002",
  "id" : 72524626869239808,
  "created_at" : "2011-05-23 04:49:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72524274111488000",
  "text" : "\u5929\u3092\u6271\u3046\u306E\u306F\u7406\u3092\u5B66\u3076\u7406\u5B66\u90E8\u3060\u3051\u3069\u3001\u6587\u5B66\u90E8\u304B\u6271\u3048\u308B\u306E\u306F\u5730(\u3058)\u6587\u5B66\u3001\u5730\u306B\u6709\u308B\u4EBA\u3092\u6271\u3046\u4EBA(\u3058\u3093)\u6587\u5B66\u3060\u3051\u306A\u306E\u304B\u306A\u3041\u3002\u534A\u5206\u306F\u8A00\u8449\u904A\u3073\u3060\u3051\u308C\u3069\u3002",
  "id" : 72524274111488000,
  "created_at" : "2011-05-23 04:48:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72522797485785088",
  "text" : "\u5BB6\u304C\u77F3\u3067\u4F5C\u3089\u308C\u308B\u3088\u3046\u306B\u3001\u79D1\u5B66\u306F\u4E8B\u5B9F\u3092\u7528\u3044\u3066\u4F5C\u3089\u308C\u308B\u3002\u3057\u304B\u3057\u77F3\u306E\u96C6\u7A4D\u304C\u5BB6\u3067\u306F\u306A\u3044\u3088\u3046\u306B\u3001\u4E8B\u5B9F\u306E\u96C6\u7A4D\u306F\u79D1\u5B66\u3067\u306F\u306A\u3044\u2501\u2501\u30A2\u30F3\u30EA\u30FB\u30DD\u30EF\u30F3\u30AB\u30EC",
  "id" : 72522797485785088,
  "created_at" : "2011-05-23 04:42:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72521633260253184",
  "text" : "\u3042\u308F\u308F\u308F\u3001\u7D50\u57CE\u5148\u751F\u306B\u76F4\u63A5\u30EA\u30D7\u30E9\u30A4\u3092\u9802\u3051\u308B\u3068\u306F\u2026\u3001\u5E78\u305B\u306A\u3053\u3068\u3067\u3059\u306D\u3002",
  "id" : 72521633260253184,
  "created_at" : "2011-05-23 04:37:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72520304999677952",
  "text" : "\u53CC\u5009\u56F3\u66F8\u9928\u306B\u30E2\u30C7\u30EB\u3068\u304B\u3042\u308B\u306E\u304B\u306A\u3041#mathgirl",
  "id" : 72520304999677952,
  "created_at" : "2011-05-23 04:32:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72520138318020608",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u306B\u51FA\u3066\u304F\u308B\u53CC\u5009\u56F3\u66F8\u9928\u307F\u305F\u3044\u306A\u6240\u306B\u4F4F\u307F\u305F\u3044\u306A\u2026\u66F8\u67B6\u3001\u30C6\u30FC\u30D6\u30EB\u3001\u30AB\u30F3\u30D5\u30A1\u30EC\u30F3\u30B9\u3002\u5C31\u8077\u3067\u3082\u3044\u3044\u3051\u3069\u3001\u53F8\u66F8\u8CC7\u683C\u3063\u3066\u9762\u5012\u306A\u3093\u3060\u3088\u306A\u30FC\u3002#mathgirl",
  "id" : 72520138318020608,
  "created_at" : "2011-05-23 04:32:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72517743978614784",
  "geo" : { },
  "id_str" : "72518183101280256",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4",
  "id" : 72518183101280256,
  "in_reply_to_status_id" : 72517743978614784,
  "created_at" : "2011-05-23 04:24:16 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72517985872515072",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u9762\u5012\u306A\u95A2\u6570\u306E\u30B0\u30E9\u30D5\u3092\u30D1\u30BD\u30B3\u30F3\u3067\u63CF\u304D\u307E\u3057\u305F\u3001\u306A\u3089\u89E3\u308A\u3084\u3059\u3044\u304B\u306A\u3002\uFF12\u9650\u306F\u30D7\u30ED\u30B0\u30E9\u30E0\u306E\u6388\u696D\u3060\u3063\u305F\u3093\u3060\u3002",
  "id" : 72517985872515072,
  "created_at" : "2011-05-23 04:23:29 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72508532985040896",
  "text" : "\u4FFA\u3001\u4F55\u3084\u3063\u3066\u3093\u3060\u308D\u3002\u3068\u601D\u308F\u306A\u3044\u3067\u306F\u306A\u3044\u3002",
  "id" : 72508532985040896,
  "created_at" : "2011-05-23 03:45:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72508397496438784",
  "text" : "\u300C\u541B\u3001\u6587\u7CFB\u3060\u3088\u306D\uFF1F\u300D\u3068\u8A00\u308F\u308C\u308B\u3068\u5B09\u3057\u3044\u534A\u9762\u8907\u96D1\u3002\u3042\u3044\u3067\u3093\u3066\u3043\u3066\u3043\u304F\u3089\u3044\u3059\u3068\u3044\u3046\u307B\u3069\u3058\u3083\u306A\u3044\u3051\u3069\u3002",
  "id" : 72508397496438784,
  "created_at" : "2011-05-23 03:45:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72508030893293568",
  "text" : "\u4E8C\u968E\u306E\u5E38\u5FAE\u5206\u65B9\u7A0B\u5F0F\u3092\u30D7\u30ED\u30B0\u30E9\u30E0\u3057\u3066\u30D7\u30ED\u30C3\u30C8\u3059\u308B\u7A0B\u5EA6\u306E\u6587\u5B66\u90E8\uFF08\u7B11\uFF09",
  "id" : 72508030893293568,
  "created_at" : "2011-05-23 03:43:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    }, {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 11, 18 ],
      "id_str" : "129796835",
      "id" : 129796835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72504318330273792",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 @7M1IHN \u304A\u306F\u3088\u3046\u3042\u308A\u304C\u3068\u3046\u3067\u3057\u305F\u30FC",
  "id" : 72504318330273792,
  "created_at" : "2011-05-23 03:29:11 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72441426025267203",
  "geo" : { },
  "id_str" : "72442489042239488",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u3067\u3001\u4F55\u304B\u3044\u3046\u4E8B\u306F\uFF1F",
  "id" : 72442489042239488,
  "in_reply_to_status_id" : 72441426025267203,
  "created_at" : "2011-05-22 23:23:29 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72440667653152768",
  "geo" : { },
  "id_str" : "72441275231637505",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u843D\u3061\u7740\u3051\u3088",
  "id" : 72441275231637505,
  "in_reply_to_status_id" : 72440667653152768,
  "created_at" : "2011-05-22 23:18:40 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72439895485976576",
  "geo" : { },
  "id_str" : "72440468708921344",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u3042\u3046\u3042\u3046",
  "id" : 72440468708921344,
  "in_reply_to_status_id" : 72439895485976576,
  "created_at" : "2011-05-22 23:15:28 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72439665013178369",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046",
  "id" : 72439665013178369,
  "created_at" : "2011-05-22 23:12:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72439544783446016",
  "text" : "\u8D77\u304D\u305F\u3051\u3069\u2026\u96E8\u3001\u9784\u3069\u3046\u3057\u3088\u3046",
  "id" : 72439544783446016,
  "created_at" : "2011-05-22 23:11:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72339715696754689",
  "text" : "\u4ECA\u65E5\u4E00\u9650\u2026\u3001\u4E00\u898B\u69D8\u304A\u65AD\u308A\u3057\u306A\u3044\u3088\u3046\u306B\u305D\u308D\u305D\u308D\u5BDD\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 72339715696754689,
  "created_at" : "2011-05-22 16:35:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30F3\u30B5\u30A4\u30AF\u30ED\u30DA\u30C7\u30A3\u30A2BOT\u65E5\u672C\u8A9E\u7248",
      "screen_name" : "AnsaiBot",
      "indices" : [ 28, 37 ],
      "id_str" : "72766956",
      "id" : 72766956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72339287257006080",
  "text" : "\u3057\u3087\u3046\u3082\u306A\u3044\u3063\u3066\u308F\u304B\u3063\u3066\u308B\u3051\u3069\u53CD\u5FDC\u3057\u3061\u3083\u3063\u305F\u3088\uFF01 RT @AnsaiBot: \u77F3\u6A4B\u6E5B\u5C71 http:\/\/bit.ly\/l5lHix \u53F3\u306E\u5199\u771F\u304C\u3001\u653F\u6CBB\u5BB6\u6642\u4EE3\u306E\u3044\u3057\u3070\u3057\u30BF\u30F3\u306E\u59FF\u3067\u3042\u308B\u3002\u8A18\u8005\u6642\u4EE3\u306E\u7686\u304B\u3089\u611B\u3055\u308C\u305F\u53EF\u6190\u306A\u59FF\u304B\u3089\u306F\u8003\u3048\u3089\u308C\u306A\u3044\u3001\u898B\u308B\u304B\u3089\u306B\u3080\u304F\u3064\u3051\u304D\u304A\u3063\u3055\u3093\u3067\u3042\u308B\u3002",
  "id" : 72339287257006080,
  "created_at" : "2011-05-22 16:33:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308A\u304F\u305D",
      "screen_name" : "mar1e666",
      "indices" : [ 0, 9 ],
      "id_str" : "256321768",
      "id" : 256321768
    }, {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 10, 20 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72327072768462848",
  "in_reply_to_user_id" : 256321768,
  "text" : "@mar1e666 @blackpiyu \u307E\u3068\u3081\u3066\u3067\u7533\u3057\u8A33\u306A\u3044\u3093\u3060\u3051\u3069\u5927\u68EE\u3055\u3093\u306B\u5506\u3055\u308C\u3066\uFF08\uFF1F\uFF09\u30D5\u30A9\u30ED\u30FC\u3057\u307E\u3057\u305F\u30FC\u3002\u7279\u306B\u9762\u767D\u3044\u3053\u3068\u545F\u304B\u306A\u3044\u3093\u3067\u6050\u7E2E\u3067\u3059\u304C\u826F\u3051\u308C\u3070\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u4E0B\u3055\u3044\u306A\u30FC\u3002",
  "id" : 72327072768462848,
  "created_at" : "2011-05-22 15:44:52 +0000",
  "in_reply_to_screen_name" : "mar1e666",
  "in_reply_to_user_id_str" : "256321768",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72323541101584384",
  "text" : "@ayu167 \u305D\u308C\u30CD\u30C3\u30C8\u4E0A\u306B\u3042\u308B\u30C4\u30A4\u30C3\u30BF\uFF0D\u3067\u8A00\u3046\u306E\u306F\u3069\u3046\u306A\u3093\u3060\u308D\u3046\u306D\uFF57",
  "id" : 72323541101584384,
  "created_at" : "2011-05-22 15:30:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72319408860696576",
  "text" : "\u4ECA\u591C\u96E8\u304B\u3088\u3045\u3002\u30EA\u30E5\u30C3\u30AF\u4F7F\u3048\u306A\u3044\u306E\u306F\u75DB\u3044\u30FB\u30FB\u30FB\u3002",
  "id" : 72319408860696576,
  "created_at" : "2011-05-22 15:14:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 9, 20 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72317806925971456",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002 @magokoro84",
  "id" : 72317806925971456,
  "created_at" : "2011-05-22 15:08:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72316985517678592",
  "text" : "\u4ECA\u65E5\u306F\u8377\u7269\u304C\u5927\u91CF\u306A\u3053\u3068\u306B\u306A\u308A\u305D\u3046\u3002",
  "id" : 72316985517678592,
  "created_at" : "2011-05-22 15:04:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72305930301214720",
  "geo" : { },
  "id_str" : "72306237630447617",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5712\u82B8\u5BB6\u3092\u76EE\u6307\u3059\u6587\u5B66\u90E8\u30FB\u30FB\u30FB\u982D\u306E\u4E2D\u304C\u304A\u82B1\u7551\u3067\u3059\u306D\uFF57",
  "id" : 72306237630447617,
  "in_reply_to_status_id" : 72305930301214720,
  "created_at" : "2011-05-22 14:22:05 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 0, 12 ],
      "id_str" : "114792585",
      "id" : 114792585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72302298445000704",
  "geo" : { },
  "id_str" : "72302779418419201",
  "in_reply_to_user_id" : 114792585,
  "text" : "@undefined_k \u5927\u5B66\u306E\u7406\u5B66\u90E8\u56F3\u66F8\u9928\u306B\u3042\u308B\u3088\u3046\u306A\u306E\u3067\u660E\u65E5\u3042\u305F\u308A\u501F\u308A\u3066\u304D\u3066\u307F\u307E\u3059\u3002",
  "id" : 72302779418419201,
  "in_reply_to_status_id" : 72302298445000704,
  "created_at" : "2011-05-22 14:08:20 +0000",
  "in_reply_to_screen_name" : "undefined_k",
  "in_reply_to_user_id_str" : "114792585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72299030507565056",
  "text" : "\u5B87\u5B99\u5275\u6210\u3082\u8AAD\u307F\u76F4\u305D\u3046\uFF08\u5B9F\u306F\u6700\u5F8C\u307E\u3067\u8AAD\u307F\u901A\u3057\u305F\u3053\u3068\u306A\u3044\uFF09\n\u304B\u306A\u308A\u79D1\u5B66\u54F2\u5B66\u7684\u8003\u5BDF\u306E\u52A9\u3051\u306B\u306A\u308B\u306F\u305A\u3002\u3067\u3082\u307E\u3041\u96FB\u8ECA\u3068\u304B\u3067\u5730\u9053\u306B\u3002",
  "id" : 72299030507565056,
  "created_at" : "2011-05-22 13:53:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DukeK",
      "screen_name" : "undefined_k",
      "indices" : [ 0, 12 ],
      "id_str" : "114792585",
      "id" : 114792585
    }, {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 13, 18 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72297204240494592",
  "geo" : { },
  "id_str" : "72297661432205312",
  "in_reply_to_user_id" : 114792585,
  "text" : "@undefined_k @np2i \u6A2A\u304B\u3089\u3067\u3042\u308C\u3067\u3059\u304C\u53C2\u8003\u306B\u3055\u305B\u3066\u3082\u3089\u3044\u307E\u3059\u306D\u30FC",
  "id" : 72297661432205312,
  "in_reply_to_status_id" : 72297204240494592,
  "created_at" : "2011-05-22 13:48:00 +0000",
  "in_reply_to_screen_name" : "undefined_k",
  "in_reply_to_user_id_str" : "114792585",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72296670284619779",
  "text" : "23\u6642\u307E\u3067\u306F\u306C\u308B\u306C\u308B\u3057\u3088\u3046\u3002\u305D\u3057\u3066\u3057\u304B\u308B\u306E\u3061\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u3092\u5F04\u3063\u3066\u5BDD\u308B\u3053\u3068\u306B\u3057\u3088\u3046\u3002",
  "id" : 72296670284619779,
  "created_at" : "2011-05-22 13:44:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72295820514435074",
  "text" : "\u30D5\u30E9\u30F3\u30B9\u8A9E\u7D42\u308F\u3063\u305F\u3002\u3042\u3068\u306F\u6B8B\u3063\u3066\u308B\u306E\u306F\u79D1\u5B66\u54F2\u5B66\u306E\u30EC\u30DD\u30FC\u30C8\u3068\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u4E00\u90E8\u2026\u5F8C\u8005\u3060\u3051\u89E6\u3063\u3066\u5BDD\u308B\u3053\u3068\u306B\u3057\u3088\u3046\u3002",
  "id" : 72295820514435074,
  "created_at" : "2011-05-22 13:40:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "indices" : [ 3, 11 ],
      "id_str" : "115380002",
      "id" : 115380002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72294781987983360",
  "text" : "RT @nedikes: \u300E\u6D88\u53BB\u6CD5\u300F\u306E\u3000\u300C\uFF7C\u300D\u3068\u300C\u53BB\u300D\u306B\u631F\u307E\u308C\u308B\u3000\u300C\u8096\u300D\u306E\u30DC\u30C3\u30C1\u611F\u304C\u3000\u51C4\u3044\u3051\u308C\u3069\u3082\u3000\u300E\u660E\u65E5\u6708\u66DC\u65E5\u300F\u306E\u3000\u300C\u65E5\u300D\u3068\u300C\u6708\u300D\u306B\u56F2\u307E\u308C\u308B\u3000\u300C\u7FDF\u300D\u306E\u30DC\u30C3\u30C1\u611F\u3082\u3000\u534A\u7AEF\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72293738176712704",
    "text" : "\u300E\u6D88\u53BB\u6CD5\u300F\u306E\u3000\u300C\uFF7C\u300D\u3068\u300C\u53BB\u300D\u306B\u631F\u307E\u308C\u308B\u3000\u300C\u8096\u300D\u306E\u30DC\u30C3\u30C1\u611F\u304C\u3000\u51C4\u3044\u3051\u308C\u3069\u3082\u3000\u300E\u660E\u65E5\u6708\u66DC\u65E5\u300F\u306E\u3000\u300C\u65E5\u300D\u3068\u300C\u6708\u300D\u306B\u56F2\u307E\u308C\u308B\u3000\u300C\u7FDF\u300D\u306E\u30DC\u30C3\u30C1\u611F\u3082\u3000\u534A\u7AEF\u306A\u3044",
    "id" : 72293738176712704,
    "created_at" : "2011-05-22 13:32:24 +0000",
    "user" : {
      "name" : "\u306B\u3045\u307E",
      "screen_name" : "nedikes",
      "protected" : false,
      "id_str" : "115380002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2009659425\/___normal.png",
      "id" : 115380002,
      "verified" : false
    }
  },
  "id" : 72294781987983360,
  "created_at" : "2011-05-22 13:36:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "7M1IHN",
      "screen_name" : "7M1IHN",
      "indices" : [ 0, 7 ],
      "id_str" : "129796835",
      "id" : 129796835
    }, {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 8, 13 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72291981405061120",
  "geo" : { },
  "id_str" : "72293293010071552",
  "in_reply_to_user_id" : 129796835,
  "text" : "@7M1IHN @np2i @mo5nya \u30A2\u30EC\u3067\u3057\u3087\u3046\u304B\uFF1F",
  "id" : 72293293010071552,
  "in_reply_to_status_id" : 72291981405061120,
  "created_at" : "2011-05-22 13:30:38 +0000",
  "in_reply_to_screen_name" : "7M1IHN",
  "in_reply_to_user_id_str" : "129796835",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72290396801212416",
  "text" : "\u30D5\u30E9\u30F3\u30B9\u8A9E\u306E\u8AAD\u3093\u3067\u5358\u8A9E\u3055\u3089\u3063\u3066\u3044\u304F\u3060\u3051\u306E\u8AB2\u984C\u307F\u308B\u3068\u30D5\u30E9\u30F3\u30B9\u8A9E\u306E\u6587\u306E\u4E0A\u4E0B\u306B\u30A2\u30EB\u30D5\u30A1\u30D9\u30C3\u30C8\u3068\u30AB\u30BF\u30AB\u30CA\u3068\u3072\u3089\u304C\u306A\u3068\u6F22\u5B57\u304C\u5165\u308A\u4E71\u308C\u3066\u3044\u308B\u3002\u51B7\u9759\u306B\u8003\u3048\u308B\u3068\u30AB\u30AA\u30B9\u3002\u3068\u3044\u3046\u304B\u81EA\u5206\u4EE5\u5916\u306B\u8AAD\u3081\u306A\u3044\u4ED5\u69D8\u306B\u306A\u3063\u3066\u3044\u308B\u3002",
  "id" : 72290396801212416,
  "created_at" : "2011-05-22 13:19:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 35, 42 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72289264850837504",
  "text" : "\u6559\u6388\u3060\u3063\u3066\u5171\u8457\u3068\u304B\u3067\u6559\u79D1\u66F8\u66F8\u304F\u3057\u30EC\u30DD\u30FC\u30C8\u3082\u5171\u8457\u3067\u3044\u3044\u3058\u3083\u3093\u306D\u3002\u3000RT @ayu167: \u30EC\u30DD\u30FC\u30C8\u4E00\u4EBA\u3067\u66F8\u304F\u306E\u3055\u307F\u3057\u3044",
  "id" : 72289264850837504,
  "created_at" : "2011-05-22 13:14:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72286144976523264",
  "text" : "\u306A\u3093\u304B\u3053\u3053\u4E8C\u65E5\u3063\u3066\u4E00\u5207\u5A2F\u697D\u306A\u304B\u3063\u305F\u3088\u3046\u306A\u2026\u305A\u3063\u3068\u8F9E\u66F8\u7E70\u3063\u3066\u305F\u3088\u3046\u306A\u3002",
  "id" : 72286144976523264,
  "created_at" : "2011-05-22 13:02:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72283554977038336",
  "geo" : { },
  "id_str" : "72284932222881793",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u96E8\u30A7\u30FB\u30FB\u30FB\u884C\u304D\u305F\u304F\u306A\u3044\u3002\u3002\u3002",
  "id" : 72284932222881793,
  "in_reply_to_status_id" : 72283554977038336,
  "created_at" : "2011-05-22 12:57:25 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72280131430916096",
  "text" : "RT @rittun1023: \u3082\u3057\u68EE\u30AC\u30FC\u30EB\u304C\u3086\u308B\u3086\u308B\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u3067\u5B9F\u969B\u306B\u300E\u68EE\u300F\u3078\u5165\u3063\u305F\u3089\u3000http:\/\/d.hatena.ne.jp\/Asay\/20100719\/1279541329\u3000\u7B11\u3044\u3059\u304E\u3066\u6D99\u304C\u67AF\u308C\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70850316056272896",
    "text" : "\u3082\u3057\u68EE\u30AC\u30FC\u30EB\u304C\u3086\u308B\u3086\u308B\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u3067\u5B9F\u969B\u306B\u300E\u68EE\u300F\u3078\u5165\u3063\u305F\u3089\u3000http:\/\/d.hatena.ne.jp\/Asay\/20100719\/1279541329\u3000\u7B11\u3044\u3059\u304E\u3066\u6D99\u304C\u67AF\u308C\u305F",
    "id" : 70850316056272896,
    "created_at" : "2011-05-18 13:56:46 +0000",
    "user" : {
      "name" : "\u308A\u3064\u029A\u2764\uFE0F\u025E\u30D7\u30EA\u30D1\u30E9\u30E4\u30AF\u30B6",
      "screen_name" : "ri2xx",
      "protected" : false,
      "id_str" : "106682598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591171557940011008\/mX-WMBzp_normal.jpg",
      "id" : 106682598,
      "verified" : false
    }
  },
  "id" : 72280131430916096,
  "created_at" : "2011-05-22 12:38:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72277915508817920",
  "text" : "@ayu167 \u8AB0\u3082\u8A00\u308F\u306A\u3055\u305D\u3046\u3060\u304B\u3089\u4FFA\u304C\u8A00\u304A\u3046\u3001\u30EC\u30DD\u30FC\u30C8\u3084\u308C\u3088\u3045\u3002",
  "id" : 72277915508817920,
  "created_at" : "2011-05-22 12:29:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72274390624112640",
  "text" : "@ayu167 \u30E2\u30C7\u30E0\u30EB\u30FC\u30BF\u306E\u518D\u8D77\u52D5\u306F\uFF1F",
  "id" : 72274390624112640,
  "created_at" : "2011-05-22 12:15:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72272903013535745",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 72272903013535745,
  "created_at" : "2011-05-22 12:09:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72270940632920064",
  "geo" : { },
  "id_str" : "72271649260576768",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30AB\u30A4\u30B8\u300C\u3053\u308C\u3001\u30C0\u30A4\u30B9\u3067\u3059\u304B\u3089\u300D\n\u3000\u3000\u3000\u3000\u3000\u3000\u3000\u3000\u3000\u3000\u2015\u2015\u30C1\u30F3\u30C1\u30ED\u306E\u7279\u6B8A\u8CFD\u306B\u3064\u3044\u3066\u5C0B\u306D\u3089\u308C\u3066",
  "id" : 72271649260576768,
  "in_reply_to_status_id" : 72270940632920064,
  "created_at" : "2011-05-22 12:04:38 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72270381955809280",
  "text" : "@ayu167 \u30B3\u30B9\u30D1\u60AA\u3044\u306A",
  "id" : 72270381955809280,
  "created_at" : "2011-05-22 11:59:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 60 ],
      "url" : "http:\/\/t.co\/A5lXiB0",
      "expanded_url" : "http:\/\/anond.hatelabo.jp\/20110508205059",
      "display_url" : "anond.hatelabo.jp\/20110508205059"
    } ]
  },
  "geo" : { },
  "id_str" : "72270157334061056",
  "text" : "\u3053\u306E\u30CD\u30BF\u2026\u3068\u3069\u307E\u308B\u3068\u3053\u308D\u3092\u77E5\u3089\u306C\u30FB\u30FB\u30FB\uFF01\u30E2\u30C6\u308B\u73FE\u4EE3\u601D\u60F3\u7CFB\u5973\u5B50\u529B\u3092\u78E8\u304F\u305F\u3081\u306E4.. http:\/\/t.co\/A5lXiB0",
  "id" : 72270157334061056,
  "created_at" : "2011-05-22 11:58:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72269090085015552",
  "text" : "@ayu167 \u3048\uFF1F\u306A\u3093\u3067\uFF1F\u5ACC\u3044\u306A\u306E\uFF1F",
  "id" : 72269090085015552,
  "created_at" : "2011-05-22 11:54:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72261479839170560",
  "text" : "\u3055\u3041\u8AB2\u984C\u306B\u623B\u3089\u306A\u304F\u3061\u3083\u3002\u3002\u3002",
  "id" : 72261479839170560,
  "created_at" : "2011-05-22 11:24:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72261399350480896",
  "text" : "\u6388\u696D\u30B7\u30FC\u30F3\u3067\u30B3\u30FC\u30B7\u30FC\u306E\u5217\u306E\u53CE\u675F\u3068\u304B\u80F8\u71B1\u3002",
  "id" : 72261399350480896,
  "created_at" : "2011-05-22 11:23:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72261257188741120",
  "text" : "\u4E45\u3057\u3076\u308A\u306B\u6620\u753B\u898B\u3066\u305F\u3002\u300C\u30E9\u30B9\u30D9\u30AC\u30B9\u3092\u3076\u3063\u3064\u3076\u305B\u300D\u3063\u3066\u3084\u3064\u3002\u30BF\u30A4\u30C8\u30EB\u3053\u305D\u9673\u8150\u3060\u3051\u3069MIT\u306E\u5B66\u751F\u304C\u6570\u5B66\u7684\u306A\u30C6\u30AF\u30CB\u30C3\u30AF\u3067\u30AB\u30B8\u30CE\u3067\u5927\u5132\u3051\u3059\u308B\u3063\u3066\u8A71\u3060\u3063\u305F\u3002\u6570\u5B66\u7684\u306A\u3068\u3053\u308D\u306E\u8868\u73FE\u304C\u7518\u3044\u306E\u306F\u4ED5\u65B9\u306A\u3044\u3051\u3069\u3044\u3044\u30AA\u30C1\u3060\u3063\u305F\u3002",
  "id" : 72261257188741120,
  "created_at" : "2011-05-22 11:23:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72224227738136576",
  "text" : "\u5E30\u5B85\u30A1\uFF01",
  "id" : 72224227738136576,
  "created_at" : "2011-05-22 08:56:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72217482462638080",
  "text" : "\u3063\u3066\u308F\u3051\u3067\u8CB7\u3044\u7269\u4E91\u3005\u8A00\u3063\u3066\u6765\u307E\u30FC\u3059",
  "id" : 72217482462638080,
  "created_at" : "2011-05-22 08:29:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72213755127271424",
  "text" : "\u3053\u3063\u3061\u306E\u304C\u6587\u7AE0\u306F\u5E73\u6613\u3060\u3063\u305F\u306A\u30FC\u3002\u9577\u304F\u3066\u30824\u884C\u306B\u306F\u306A\u3089\u306A\u3044\u6587\u3070\u3063\u304B\u308A\u3060\u3063\u305F\u3057\u3002",
  "id" : 72213755127271424,
  "created_at" : "2011-05-22 08:14:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72213554845065216",
  "text" : "\u82F1\u8A9E\u3082\u3046\u4E00\u4ED5\u4E8B\u304A\u3057\u307E\u3044\u3002",
  "id" : 72213554845065216,
  "created_at" : "2011-05-22 08:13:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72188023143530496",
  "text" : "\u306A\u3093\u304B\u30EA\u30B5bot\u304C\u66B4\u8D70\u3057\u3066\u3044\u308B\u3088\u3046\u306B\u3057\u304B\u898B\u3048\u306A\u3044\u2026\u3002\u300C\u3061\u3083\u3093\u306F\u4E0D\u8981\u300D\u3068\u30AF\u30FC\u30EB\u306B\u30EA\u30D7\u30E9\u30A4\u3057\u3066\u3044\u3066\u5F7C\u5973\u306F\u4F55\u51E6\u306B\u3002\u3053\u308C\u306F\u3053\u308C\u3067\u9762\u767D\u3044\u3051\u3069\u3055\uFF57",
  "id" : 72188023143530496,
  "created_at" : "2011-05-22 06:32:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72187426629627905",
  "text" : "\u81EA\u5DF1\u7D39\u4ECB\u3092\u30DE\u30A4\u30CA\u30FC\u30C1\u30A7\u30F3\u30B8\u3002",
  "id" : 72187426629627905,
  "created_at" : "2011-05-22 06:29:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 3, 10 ],
      "id_str" : "443191476",
      "id" : 443191476
    }, {
      "name" : "KATER",
      "screen_name" : "boldcat21",
      "indices" : [ 33, 43 ],
      "id_str" : "94277728",
      "id" : 94277728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72185986972532737",
  "text" : "RT @ac_key: \u30C7\u30E2\u3084\u3081\u308D\uFF01\u3063\u3066\u3044\u3046\u30C7\u30E2\u3057\u3088\u3046\u305C\uFF57 RT @boldcat21: \u30C7\u30E2\u3046\u305C\uFF0D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "KATER",
        "screen_name" : "boldcat21",
        "indices" : [ 21, 31 ],
        "id_str" : "94277728",
        "id" : 94277728
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72184674868412416",
    "text" : "\u30C7\u30E2\u3084\u3081\u308D\uFF01\u3063\u3066\u3044\u3046\u30C7\u30E2\u3057\u3088\u3046\u305C\uFF57 RT @boldcat21: \u30C7\u30E2\u3046\u305C\uFF0D",
    "id" : 72184674868412416,
    "created_at" : "2011-05-22 06:19:02 +0000",
    "user" : {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "protected" : false,
      "id_str" : "106036912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600553053863817216\/2TsFpIn8_normal.png",
      "id" : 106036912,
      "verified" : false
    }
  },
  "id" : 72185986972532737,
  "created_at" : "2011-05-22 06:24:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72185397530202112",
  "text" : "\u3060\u3044\u3076\uFF47\uFF44\u3063\u305F\u304C\u82F1\u8A9E\u306E\u8AB2\u984C\u4E00\u3064\u76EE\u304A\u4ED5\u821E\u3002\u307E\u3041\u6B21\u3082\u82F1\u8A9E\u306A\u3093\u3060\u3051\u3069\u306D\u3047\u3002",
  "id" : 72185397530202112,
  "created_at" : "2011-05-22 06:21:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72182295108386816",
  "text" : "RT\u3068\u304B\u30EA\u30D7\u30E9\u30A4\u3059\u308B\u304F\u3089\u3044\u306E\u6C17\u8EFD\u3055\u3067\u4ED6\u4EBA\u306B\u8A71\u3057\u304B\u3051\u3066\u307F\u305F\u3044\u306A\u30FC\u3002\u30CD\u30C3\u30C8\u5F01\u6176\u3063\u3066\u3093\u3058\u3083\u306A\u3044\u3064\u3082\u308A\u3060\u3051\u3069\u30EA\u30A2\u30EB\u3067\u306F\u3082\u3046\u3061\u3087\u3044\u5927\u4EBA\u3057\u3044\u632F\u308A\u3092\u3057\u3066\u3057\u307E\u3046\u3002\u3044\u3084\u3001\u3082\u3068\u3082\u3068\u5927\u4EBA\u3057\u3044\u3051\u3069\u3002",
  "id" : 72182295108386816,
  "created_at" : "2011-05-22 06:09:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72181321165836288",
  "text" : "TL\u306ERT\u3092\u5272\u3068\u8EFD\u3044\u6C17\u6301\u3061\u3067\u975E\u516C\u5F0F\u30B3\u30E1\u30F3\u30C8\u4ED8\u304D\u3067RT\u3057\u3066\u3057\u307E\u3046\u3093\u3060\u304C\u826F\u3044\u306E\u304B\u306A\u30FC\u3002\u307E\u3041\u5225\u306B\u60AA\u610F\u306F\u306A\u3044\u3057\u5BB3\u3082\u306A\u3044\uFF08\u306F\u305A\u3060\uFF09\u3051\u3069\u3002\u77E5\u3089\u306A\u3044\u4EBA\u304B\u3089\u6025\u306B\u975E\u516C\u5F0F\u306ERT\u3055\u308C\u305F\u3089\u5403\u9A5A\u3059\u308B\u304B\u306A\uFF1F\u307E\u3041\u3084\u3081\u306A\u3044\u3051\u3069\u2190",
  "id" : 72181321165836288,
  "created_at" : "2011-05-22 06:05:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 30, 35 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72178601352626176",
  "text" : "\u300C\u305D\u308C\u306F\u7B97\u6570\u3067\u3042\u3063\u3066\u6570\u5B66\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u300D\u3068\u8A00\u3048\u305F\u3089\u2026 RT @np2i: RT @np_dif: \u3010\u672C\u5F53\u306B\u3042\u3063\u305F\u6016\u3044\u8A71\u3011\u3000\u9762\u63A5\u5B98\u300C\u6570\u5B66\u5F97\u610F\u306A\u3093\u3060\u3063\u3066\uFF1F\u3000\u3061\u3087\u3063\u3068\u3053\u306E\u8A08\u7B97\u3057\u3066\u307F\u3066\u3088\u30023+4\u00D75+2\u00D7...\u300D\u3000",
  "id" : 72178601352626176,
  "created_at" : "2011-05-22 05:54:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72160854472265729",
  "geo" : { },
  "id_str" : "72161080075497472",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u6109\u3057\u3044\u591C\u306B\u306A\u308A\u305D\u3046\u306D\u3002",
  "id" : 72161080075497472,
  "in_reply_to_status_id" : 72160854472265729,
  "created_at" : "2011-05-22 04:45:16 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72159944035667968",
  "text" : "aftermath\u306B\u6570\u5B66\u7684\u306A\u610F\u5473\u3092\u671F\u5F85\u3057\u305F\u4FFA\u304C\u611A\u304B\u3067\u3042\u3063\u305F\u4F59\u6CE2\u3068\u304B\u7D50\u679C\u3063\u3066\u610F\u5473\u3060\u3063\u305F\u3002",
  "id" : 72159944035667968,
  "created_at" : "2011-05-22 04:40:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicovideo",
      "indices" : [ 56, 66 ]
    }, {
      "text" : "sm14501433",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 98 ],
      "url" : "http:\/\/t.co\/hgcmBmO",
      "expanded_url" : "http:\/\/nico.ms\/sm14501433",
      "display_url" : "nico.ms\/sm14501433"
    } ]
  },
  "geo" : { },
  "id_str" : "72134184587624448",
  "text" : "\u3053\u3046\u3044\u3046\u3057\u3087\u3046\u3082\u306A\u3044\u3053\u3068\u3059\u308B\u80FD\u529B\u3063\u3066\u2026 \u30D5\u30A1\u30A4\u30EB\u3092\u6368\u3066\u3088\u3046\u3068\u3059\u308B\u3068\u731B\u70C8\u306B\u9003\u3052\u51FA\u3059\u3054\u307F\u7BB1\u4F5C\u3063\u3066\u307F\u305F (4:32) #nicovideo #sm14501433 http:\/\/t.co\/hgcmBmO",
  "id" : 72134184587624448,
  "created_at" : "2011-05-22 02:58:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71993422847819776",
  "text" : "\u30C0\u30E1\u3060\u3001\u76EE\u304C\u3057\u3087\u307C\u3057\u3087\u307C\u3057\u3066\u304D\u305F\u3002\u5BDD\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002\u30EA\u30D7\u30E9\u30A4\u3042\u3063\u305F\u3089\u3057\u3066\u304A\u3044\u3066\u304F\u308C\u308C\u3070\u8D77\u304D\u3066\u304B\u3089\u898B\u3066\u8FD4\u3057\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 71993422847819776,
  "created_at" : "2011-05-21 17:39:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71991424433926144",
  "geo" : { },
  "id_str" : "71991564779536384",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u3060\u3063\u3066\u8CB4\u5973\u5927\u5B66\u751F\u3067\u3057\u3087\uFF1F\uFF57",
  "id" : 71991564779536384,
  "in_reply_to_status_id" : 71991424433926144,
  "created_at" : "2011-05-21 17:31:41 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71989666332684288",
  "text" : "@np2i \u4E00\u822C\u6559\u990A\u3067\u7406\u7CFB\u79D1\u76EE\u3082\u4E00\u5B9A\u4EE5\u4E0A\u53D6\u3089\u306A\u304F\u3061\u3083\u3044\u3051\u306A\u304F\u3066\u3001\u305D\u308C\u3067\u7406\u5B66\u90E8\u304C\u63D0\u4F9B\u3057\u3066\u3044\u308B\u4E00\u822C\u6559\u990A\u79D1\u76EE\u3067\u6570\u5B66\u7CFB\u306E\u3092\u53D6\u3063\u305F\u3093\u3067\u3059\u3002\u8AD6\u7406\u5B66\u306F\u6587\u5B66\u90E8\u306E\u79D1\u76EE\u3067\u3059\u3002\u6570\u5B66\u30AC\u30FC\u30EB\u3067\u51FA\u3066\u304D\u305F\u5F62\u5F0F\u7684\u4F53\u7CFB\u306B\u304B\u306A\u308A\u8FD1\u3044\u3067\u3059\u306D\u3002\u6570\u7406\u8AD6\u7406\u5B66\u3068\u3069\u3046\u9055\u3046\u306E\u304B\u306F\u3061\u3087\u3063\u3068\u3088\u304F\u308F\u304B\u308A\u307E\u305B\u3093\u304C\u3002",
  "id" : 71989666332684288,
  "created_at" : "2011-05-21 17:24:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71986001966403585",
  "text" : "@np2i \u660E\u78BA\u306B\u95A2\u6570\u89E3\u6790\u3063\u3066\u540D\u524D\u306E\u6388\u696D\u3067\u306F\u306A\u304B\u3063\u305F\u306E\u3067\u3059\u304C\u3001\u305F\u3076\u3093\u95A2\u6570\u89E3\u6790\u306E\u57FA\u790E\u7684\u306A\u90E8\u5206\u3058\u3083\u306A\u3044\u304B\u3068\u306F\u601D\u3044\u307E\u3059\u3002\u4E00\u5FDC\u5177\u4F53\u7684\u4E2D\u8EAB\u3068\u3057\u3066\u300C\u4E8C\u9805\u5B9A\u7406\u306E\u62E1\u5F35\u3001\u30CB\u30E5\u30FC\u30C8\u30F3\u6CD5\u306B\u3088\u308B\u8FD1\u4F3C\u3001\u9023\u5206\u6570\u8868\u8A18\u3001\u30AC\u30F3\u30DE\u95A2\u6570\u3001\u30B9\u30BF\u30FC\u30EA\u30F3\u30B0\u306E\u516C\u5F0F\u300D\u306A\u3093\u304B\u3092\u3084\u308A\u307E\u3057\u305F\u3002",
  "id" : 71986001966403585,
  "created_at" : "2011-05-21 17:09:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71983599875923969",
  "text" : "\u4EBA\u985E\u306F\uFF11\uFF10\u9032\u6CD5\u3092\u63A1\u7528\u3057\u307E\u3057\u305F\u30FC\u3002",
  "id" : 71983599875923969,
  "created_at" : "2011-05-21 17:00:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71983522352611328",
  "text" : "\u5148\u8F29\u300C\u30A2\u30C9\u30EC\u30B9\u5E33\u306B\u4E21\u624B\u3067\u6570\u3048\u3089\u308C\u308B\u304F\u3089\u3044\u3057\u304B\u5973\u306E\u5B50\u306E\u30A2\u30C9\u30EC\u30B9\u304C\u306A\u3044\u300D\n\u81EA\u5206\u300C\u4E21\u624B\u6709\u308C\u3070\uFF11\uFF10\uFF10\uFF10\u4EBA\u4EE5\u4E0A\u6570\u3048\u3089\u308C\u308B\u3058\u3083\u306A\u3044\u3067\u3059\u304B\uFF01\u300D\n\u5148\u8F29\u300C\u2026\u300D",
  "id" : 71983522352611328,
  "created_at" : "2011-05-21 16:59:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71982494911696896",
  "text" : "\u3061\u3087\u3063\u3068\u65E9\u3081\u306B\u8D77\u304D\u3066\u7761\u7720\u6642\u9593\u77ED\u3081\u306B\u8ABF\u6574\u3057\u3066\u4ECA\u591C\u306F\u65E9\u3081\u306B\u5BDD\u3066\u660E\u65E5\u306E\u4E00\u9650\u306B\u5099\u3048\u308B\u3002\u3053\u308C\u304C\u7406\u60F3\u306A\u306E\u3060\u3051\u308C\u3069\u2026\u6642\u9593\u7684\u5236\u7D04\u306E\u306A\u3044\u65E9\u8D77\u304D\u306F\u307E\u305A\u6210\u529F\u3057\u306A\u3044\u3002",
  "id" : 71982494911696896,
  "created_at" : "2011-05-21 16:55:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71982196801536001",
  "text" : "\uFF12~\uFF13\u3063\u3066\uFF12\uFF3E\uFF13\u306B\u898B\u3048\u308B\u306A\u3002\uFF12\uFF5E\uFF13\u6BB5\u843D\u3067\u3059\u3002\u8A02\u6B63\u3057\u307E\u3059\u304C\u304A\u8A6B\u3073\u306F\u7533\u3057\u4E0A\u3052\u307E\u305B\u3093\u3002\u8AB0\u306B\u3082\u8FF7\u60D1\u304B\u3051\u3066\u306A\u3044\u3057\u306D\u3001\u5225\u306B\u8A6B\u3073\u308B\u5FC5\u8981\u306F\u306A\u3044\uFF08\uFF77\uFF98\uFF6F",
  "id" : 71982196801536001,
  "created_at" : "2011-05-21 16:54:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71981872590229504",
  "text" : "\u82F1\u8A9E\u2026\u3042\u3068\uFF15\u6BB5\u843D\u3082\u3042\u308B\u3002\uFF47\uFF44\uFF47\uFF44\u3084\u3063\u3066\u308B\u3068\u306F\u3044\u3048\u6642\u9593\u304B\u304B\u308A\u904E\u304E\u3060\u306A\u3002\u8AB2\u984C\u306E\u7D76\u5BFE\u91CF\u3082\u591A\u3044\u3051\u3069\u3002\u307E\u3041\u3042\u3068\u306F\u8D77\u304D\u3066\u304B\u3089\u306B\u3057\u3088\u3046\u304B\u306A\u3002\u5225\u306E\u8AB2\u984C\u3067\uFF12~\uFF13\u6BB5\u843D\u8A33\u3055\u306A\u304D\u3083\u3044\u3051\u306A\u3044\u82F1\u8A9E\u3082\u6709\u3063\u305F\u308A\u3059\u308B\u3093\u3060\u3051\u3069\u3002",
  "id" : 71981872590229504,
  "created_at" : "2011-05-21 16:53:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71981400848465921",
  "text" : "\u3068\u3044\u3046\u304B\u3046\u3061\u306E\u9AD8\u6821\u6587\u7CFB\u306B\u5FAE\u5206\u307E\u3067\u3057\u304B\u6559\u3048\u3066\u306A\u3044\u3002\u7A4D\u5206\u307E\u3067\u5FC5\u4FEE\u306E\u306F\u305A\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 71981400848465921,
  "created_at" : "2011-05-21 16:51:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71979825866346496",
  "text" : "\u66F8\u3044\u3066\u307F\u308B\u3068\u6848\u5916\u81EA\u5206\u6570\u5B66\u597D\u304D\u3092\u81EA\u79F0\u3059\u308B\u5272\u306B\u300C\u3084\u3063\u305F\u306E\u306B\u89E3\u3063\u3066\u7121\u3044\u5206\u91CE\u300D\u304C\u591A\u3044\u2026\u3002\u597D\u304D\u3067\u3084\u3063\u3066\u308B\u3093\u3060\u304B\u3089\u308F\u304B\u308B\u307E\u3067\u3084\u308C\u3088\u3001\u3068\u3002",
  "id" : 71979825866346496,
  "created_at" : "2011-05-21 16:45:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71979472450105344",
  "text" : "@np2i @mo5nya \u5C65\u4FEE\u306F2B\u307E\u3067\u3067\u3059\u304C\u72EC\u5B66\u3067\uFF13C\u307E\u3067\uFF08\u53D7\u9A13\u30EC\u30D9\u30EB\u307E\u3067\u306F\u7121\u7406\u304B\u3082\uFF09\u3001\u7DDA\u5F62\u3068\u5FAE\u7A4D\u306F\u4E00\u901A\u308A\u3001\u89E3\u6790\u306F\u4E00\u90E8\u5206\u3060\u3051\u201D\u672C\u5F53\u306B\u306F\u89E3\u3063\u3066\u7121\u3044\u611F\u3058\u201D\u3067\u3059\u3002\u7D71\u8A08\u3068\u8907\u7D20\u89E3\u6790\u3001\u96C6\u5408\u3068\u4F4D\u76F8\uFF08\u4ECA\u671F\u5C65\u4FEE\uFF09\u306F\u201D\u89E6\u3063\u305F\u3053\u3068\u304C\u3042\u308B\u201D\u30EC\u30D9\u30EB\u3067\u3059\u3002\u7DDA\u5F62\u5FAE\u7A4D\u4EE5\u5916\u306F\u5168\u304F\u89E3\u3089\u306A\u3044\u3082\u306E\u3068\u601D\u3063\u3066\u304F\u3060\u3055\u3044\u3002",
  "id" : 71979472450105344,
  "created_at" : "2011-05-21 16:43:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 8, 13 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71975025577705473",
  "text" : "@mo5nya @np2i \u3000\uFF08\u78BA\u304B\u306B\u8DA3\u65E8\u3068\u306F\u30BA\u30EC\u308B\u3051\u308C\u3069\u7D20\u76F4\u306B\u53CD\u8AD6\u3067\u304D\u306A\u3044\u9B45\u529B\u7684\u306A\u63D0\u6848\u2026\uFF01\uFF09",
  "id" : 71975025577705473,
  "created_at" : "2011-05-21 16:25:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71973555524481025",
  "text" : "@np2i @mo5nya \u306A\u3093\u3068\u3044\u3046\u304B\u2026\u50D5\u306E\u4F5C\u308A\u305F\u3044\u6570\u5B66\u30B5\u30FC\u30AF\u30EB\u306E\u539F\u578B\u306B\u306A\u308A\u305D\u3046\u3067\u3059\uFF57\u305D\u3046\u3044\u3046\u610F\u5473\u3067\u3082\u53C2\u8003\u306B\u3057\u305F\u3044\u3067\u3059\u2190\u3000\u8DB3\u3092\u5F15\u3063\u5F35\u3089\u306A\u3044\u3088\u3046\u306B\u3001\u6559\u308F\u308B\u3060\u3051\u306E\u4EBA\u306B\u306A\u3089\u306A\u3044\u3088\u3046\u306B\u5354\u529B\u306F\u3057\u307E\u3059\u3088\uFF01",
  "id" : 71973555524481025,
  "created_at" : "2011-05-21 16:20:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71970865511804928",
  "text" : "integral\u3063\u3066\u5358\u8A9E\u306B\u4E0D\u53EF\u6B20\u3063\u3066\u610F\u5473\u304C\u3042\u308B\u306E\u3092\u3059\u3063\u304B\u308A\u5FD8\u308C\u3066\u305F\u3001\u3068\u3044\u3046\u3088\u308A\u7A4D\u5206\u3068\u6574\u6570\u306E\u610F\u5473\u3067\u5B8C\u5168\u306B\u601D\u8003\u505C\u6B62orz\u3000\u6614\u306F\u3082\u3063\u3068\u5358\u8A9E\u306B\u5BFE\u3057\u3066\u92ED\u3044\u611F\u899A\u304C\u3042\u3063\u305F\u3051\u3069\u306A\u3041\u30FB\u30FB\u30FB\u3002",
  "id" : 71970865511804928,
  "created_at" : "2011-05-21 16:09:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71969299417399296",
  "text" : "\u534A\u5206\u3063\u3066\u66F8\u3053\u3046\u3068\u3057\u305F\u3089\u534A\u5F84\u3063\u3066\u66F8\u3044\u3066\u305F\u3002\u6570\u5B66\u75C5\uFF1F",
  "id" : 71969299417399296,
  "created_at" : "2011-05-21 16:03:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71968494228471810",
  "text" : "\u30DF\u30EB\u30AD\u30A3\u306E\u4EBA\u305F\u3061\u4EF2\u597D\u3055\u305D\u3046\u3067\u5B9F\u306B\u548C\u307F\u308B\u304D\u3043\u3002",
  "id" : 71968494228471810,
  "created_at" : "2011-05-21 16:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71967656462401536",
  "text" : "@np2i @mo5nya \u4E00\u4EBA\u3060\u3068\u306A\u304B\u306A\u304B\u9032\u307E\u306A\u304B\u3063\u305F\u308A\u308F\u304B\u3063\u305F\u3075\u308A\u3092\u3057\u3066\u3057\u307E\u305F\u308A\u3059\u308B\u306E\u3067\u6559\u308F\u3063\u3066\u6559\u3048\u3066\u3063\u3066\u3084\u3063\u3066\u308B\u3046\u3061\u306B\u3061\u3083\u3093\u3068\u6DF1\u307E\u308B\u7406\u89E3\u304C\u6B32\u3057\u3044\u3067\u3059\u306D\u3047\u3002\u4EBA\u306B\u308F\u304B\u308B\u3088\u3046\u306B\u8AAC\u660E\u3067\u304D\u306A\u3044\u3046\u3061\u306F\u7406\u89E3\u3057\u305F\u3068\u306F\u8A00\u3048\u306A\u3044\u3068\u3044\u3044\u307E\u3059\u3057\u3002",
  "id" : 71967656462401536,
  "created_at" : "2011-05-21 15:56:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 8, 13 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71965638079422464",
  "text" : "@mo5nya @np2i \u4F55\u304B\u524D\u63D0\u77E5\u8B58\u304C\u3042\u3093\u307E\u308A\u3044\u3089\u306A\u3044\u5206\u91CE\u304C\u3042\u308C\u3070\u3044\u3044\u306E\u3067\u3059\u304C\u30FB\u30FB\u30FB",
  "id" : 71965638079422464,
  "created_at" : "2011-05-21 15:48:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71964614086230016",
  "text" : "@np2i @mo5nya \u305D\u3046\u3067\u3059\u306D\u3001\u305D\u3053\u306F\u7D71\u4E00\u3057\u306A\u3044\u3068\u52B9\u7387\u60AA\u3044\u3067\u3059\u306D\u3002",
  "id" : 71964614086230016,
  "created_at" : "2011-05-21 15:44:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71961489996656641",
  "text" : "@np2i @mo5nya \u5F8C\u8005\u306E\u65B9\u304C\u6C17\u697D\u3067\u306F\u3042\u308A\u307E\u3059\u304C\u2026\u9032\u3081\u65B9\u306F\u82E5\u5E72\u96E3\u3057\u3044\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u306D\u3002",
  "id" : 71961489996656641,
  "created_at" : "2011-05-21 15:32:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 8, 13 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71959525019762688",
  "text" : "@mo5nya @np2i \u81EA\u5206\u3082\u53C2\u52A0\u3059\u308B\u306A\u3089\u78BA\u5B9F\u306B\u300C\u30C6\u30C8\u30E9\u3061\u3083\u3093\u300D\u30DD\u30B8\u30B7\u30E7\u30F3\u3067\u3059\uFF57\u3000\u3067\u3082\u9762\u767D\u305D\u3046\u3002\u6708\u4E00\u304F\u3089\u3044\u3067\u5B9A\u671F\u7684\u306B\u3067\u304D\u305F\u3089\u3059\u3054\u304F\u697D\u3057\u305D\u3046\u3002",
  "id" : 71959525019762688,
  "created_at" : "2011-05-21 15:24:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71955508474552320",
  "text" : "@np2i @mo5nya \u3084\u308A\u305F\u3044\u3067\u3059\u306D\u3001\u305C\u3072\u3002",
  "id" : 71955508474552320,
  "created_at" : "2011-05-21 15:08:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 26, 36 ],
      "id_str" : "181342377",
      "id" : 181342377
    }, {
      "name" : "Sho\u263B",
      "screen_name" : "ocean_field",
      "indices" : [ 74, 86 ],
      "id_str" : "275482197",
      "id" : 275482197
    }, {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 111, 121 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71955048103559169",
  "text" : "\u521D\u671F\u5024\u3092\u8003\u3048\u306A\u3044\u3067\u7A4D\u5206\u3059\u308B\u304B\u3089\u3001\u5B9A\u6570\u90E8\u5206\u304C\u2026 RT @kazma0318: \u6614\u30C9\u30E9\u30B4\u30F3\u30DC\u30FC\u30EB\u306E\u5B9F\u5199\u7248\u6620\u753B\u3092\u898B\u306B\u884C\u3063\u305F\u6642\u671F\u304C\u50D5\u306B\u3082\u3042\u308A\u307E\u3057\u305FwwRT @ocean_field: \u4E8C\u6B21\u5143\u3092\u4E09\u6B21\u5143\u306B\u3059\u308B\u306A\u3093\u3066\u99AC\u9E7F\u3052\u3066\u308Bw RT @kazma0318: \u5B9F\u5199\u5316\u3063\u3066\u5927\u62B5\u6ED1\u308B\u3088\u306Aww",
  "id" : 71955048103559169,
  "created_at" : "2011-05-21 15:06:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71951179340447745",
  "text" : "@np2i \u79C1\u3082\u5B9A\u5E74\u5F8C\u306B\u7406\u5B66\u90E8\u306B\u884C\u304D\u306A\u304A\u3059\u306E\u304C\u5922\u3067\u3059\uFF57",
  "id" : 71951179340447745,
  "created_at" : "2011-05-21 14:51:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71925051330543616",
  "geo" : { },
  "id_str" : "71925337763758081",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u304A\u304B\u3048\u308A\u30A1\uFF01",
  "id" : 71925337763758081,
  "in_reply_to_status_id" : 71925051330543616,
  "created_at" : "2011-05-21 13:08:31 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 0, 15 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71923391115952128",
  "geo" : { },
  "id_str" : "71923675758211073",
  "in_reply_to_user_id" : 227502200,
  "text" : "@G4_Hirano_chan \u307E\u3060\u5BDD\u306A\u3044\u3088\uFF01",
  "id" : 71923675758211073,
  "in_reply_to_status_id" : 71923391115952128,
  "created_at" : "2011-05-21 13:01:55 +0000",
  "in_reply_to_screen_name" : "G4_Hirano_chan",
  "in_reply_to_user_id_str" : "227502200",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71923602349498368",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u4FFA\u3089\u4E16\u4EE3\u30DB\u30A4\u30DB\u30A4\u30FB\u30FB\u30FB",
  "id" : 71923602349498368,
  "created_at" : "2011-05-21 13:01:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71923320240603137",
  "text" : "\u5BDD\u308B\u307E\u3067\u306B\u82F1\u8A9E\u306E\u8AB2\u984C\u306F\u7D42\u308F\u3089\u305B\u3088\u3046\u3002",
  "id" : 71923320240603137,
  "created_at" : "2011-05-21 13:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71923064698445824",
  "text" : "\u3066\u304BCD\u53D6\u308A\u8FBC\u3080\u3060\u3051\u3067\u3069\u308C\u3060\u3051\u6642\u9593\u304B\u304B\u3063\u3066\u308B\u306E\u3060\u308D\u3046\u304B\u30FB\u30FB\u30FB\u3002",
  "id" : 71923064698445824,
  "created_at" : "2011-05-21 12:59:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71922521234092032",
  "text" : "709sec\u306E\u5B89\u5B9A\u611F\u2026",
  "id" : 71922521234092032,
  "created_at" : "2011-05-21 12:57:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u540D\u8A00\u96C6",
      "screen_name" : "Einstein_ja",
      "indices" : [ 3, 15 ],
      "id_str" : "76905775",
      "id" : 76905775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71919287828357120",
  "text" : "RT @Einstein_ja: \u6012\u308A\u306F\u3001\u611A\u304B\u8005\u306E\u80F8\u306B\u3057\u304B\u4F4F\u307F\u7740\u304B\u306A\u3044\u3082\u306E\u3060\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/Einstein_ja\" rel=\"nofollow\"\u003E\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71918033563693056",
    "text" : "\u6012\u308A\u306F\u3001\u611A\u304B\u8005\u306E\u80F8\u306B\u3057\u304B\u4F4F\u307F\u7740\u304B\u306A\u3044\u3082\u306E\u3060\u3002",
    "id" : 71918033563693056,
    "created_at" : "2011-05-21 12:39:30 +0000",
    "user" : {
      "name" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u540D\u8A00\u96C6",
      "screen_name" : "Einstein_ja",
      "protected" : false,
      "id_str" : "76905775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433263313\/einstein_normal.jpg",
      "id" : 76905775,
      "verified" : false
    }
  },
  "id" : 71919287828357120,
  "created_at" : "2011-05-21 12:44:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71909733518417920",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 71909733518417920,
  "created_at" : "2011-05-21 12:06:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71894226266365952",
  "text" : "\u3042\u304B\u3089\u3055\u307E\u306B\u30DE\u30A4\u30CA\u30FC\u306A\u540C\u4EBA\u4F5C\u54C1\u306ECD\u3068\u304B\u66F2\u540D\u3068\u304B\u3063\u3066\u5165\u529B\u3057\u306A\u3044\u3068\u3044\u3051\u306A\u3044\u306E\u304B\u306A\u2026\u9762\u5012\u3060\u306A\u3002",
  "id" : 71894226266365952,
  "created_at" : "2011-05-21 11:04:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71893264978034688",
  "text" : "SonicStage\u3068iTunes\u306B\u540C\u6642\u306B\u53D6\u308A\u8FBC\u3080\u975E\u52B9\u7387\u2026",
  "id" : 71893264978034688,
  "created_at" : "2011-05-21 11:01:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71890614484078592",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u672A\u958B\u5C01\u306ECD\u304C\uFF17\u679A\u3082\u3042\u3063\u305F\u2026\u53D6\u308A\u8FBC\u3080\u306E\u3063\u3066\u7D50\u69CB\u9762\u5012\u3088\u306D\u3002",
  "id" : 71890614484078592,
  "created_at" : "2011-05-21 10:50:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71889733403418624",
  "text" : "\u4ECA\u304B\u3089\u30B9\u30FC\u30D1\u30FCCD\u3092PC\u306B\u53D6\u308A\u8FBC\u3080\u30BF\u30A4\u30E0\u306B\u3057\u3088\u3046\u3001\u305D\u3046\u3057\u3088\u3046\u3002\u305D\u308C\u3092\u805E\u304D\u306A\u304C\u3089\u8AB2\u984C\u3092\u3084\u308C\u3070\u5B8C\u74A7\u3058\u3083\u306A\u3044\u304B\u3001\u3046\u3093\u3002\uFF08\u73FE\u5B9F\u9003\u907F\uFF09",
  "id" : 71889733403418624,
  "created_at" : "2011-05-21 10:47:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71889412392366080",
  "text" : "\u5916\u51FA\u3057\u3066\u6C17\u304C\u4ED8\u3044\u305F\u3002\u6691\u3044\u306E\u306F\u90E8\u5C4B\u306E\u4E2D\u3060\u3002",
  "id" : 71889412392366080,
  "created_at" : "2011-05-21 10:45:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "3rd_error403",
      "screen_name" : "3rd_error403",
      "indices" : [ 3, 16 ],
      "id_str" : "73885095",
      "id" : 73885095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71853275539972096",
  "text" : "RT @3rd_error403: \u30C1\u30B2\u934B\u306E\u30C1\u30B2\u306F\u934B\u3068\u3044\u3046\u610F\u5473\u3002\u30D5\u30E9\u30C0\u30F3\u30B9\u306E\u30D5\u30E9\u306F\u30C0\u30F3\u30B9\u3068\u3044\u3046\u610F\u5473\u3002\u30B5\u30EB\u30B5\u30BD\u30FC\u30B9\u306E\u30B5\u30EB\u30B5\u306F\u30BD\u30FC\u30B9\u3068\u3044\u3046\u610F\u5473\u3002\u30AF\u30FC\u30DD\u30F3\u5238\u306E\u30AF\u30FC\u30DD\u30F3\u306F\u5238\u3068\u3044\u3046\u610F\u5473\u3002\u30B5\u30CF\u30E9\u7802\u6F20\u306E\u30B5\u30CF\u30E9\u306F\u7802\u6F20\u3068\u3044\u3046\u610F\u5473\u3002\u30CA\u30A4\u30EB\u3082\u30A4\u30F3\u30C0\u30B9\u3082\u30AC\u30F3\u30B8\u30B9\u3082\u5DDD\u3068\u3044\u3046\u610F\u5473\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71587197630951424",
    "text" : "\u30C1\u30B2\u934B\u306E\u30C1\u30B2\u306F\u934B\u3068\u3044\u3046\u610F\u5473\u3002\u30D5\u30E9\u30C0\u30F3\u30B9\u306E\u30D5\u30E9\u306F\u30C0\u30F3\u30B9\u3068\u3044\u3046\u610F\u5473\u3002\u30B5\u30EB\u30B5\u30BD\u30FC\u30B9\u306E\u30B5\u30EB\u30B5\u306F\u30BD\u30FC\u30B9\u3068\u3044\u3046\u610F\u5473\u3002\u30AF\u30FC\u30DD\u30F3\u5238\u306E\u30AF\u30FC\u30DD\u30F3\u306F\u5238\u3068\u3044\u3046\u610F\u5473\u3002\u30B5\u30CF\u30E9\u7802\u6F20\u306E\u30B5\u30CF\u30E9\u306F\u7802\u6F20\u3068\u3044\u3046\u610F\u5473\u3002\u30CA\u30A4\u30EB\u3082\u30A4\u30F3\u30C0\u30B9\u3082\u30AC\u30F3\u30B8\u30B9\u3082\u5DDD\u3068\u3044\u3046\u610F\u5473\u3002",
    "id" : 71587197630951424,
    "created_at" : "2011-05-20 14:44:52 +0000",
    "user" : {
      "name" : "3rd_error403",
      "screen_name" : "3rd_error403",
      "protected" : false,
      "id_str" : "73885095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1657082770\/3rd_error403_normal.jpg",
      "id" : 73885095,
      "verified" : false
    }
  },
  "id" : 71853275539972096,
  "created_at" : "2011-05-21 08:22:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71852756784259073",
  "text" : "\u6247\u98A8\u6A5F\u6B32\u3057\u3044\u306A\u30FC\u3002\u305D\u308D\u305D\u308D\u98A8\u304C\u306A\u3044\u65E5\u306F\u7A93\u958B\u3051\u3066\u3082\u3061\u3087\u3063\u3068\u6691\u304F\u306A\u3063\u3066\u304D\u305F\u306A\u30FC\u3002",
  "id" : 71852756784259073,
  "created_at" : "2011-05-21 08:20:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71851345371598848",
  "text" : "\u82F1\u8A9E\u306E\u4E88\u7FD2\u3060\u3051\u3067\u7D50\u69CB\u91CF\u304C\u3042\u308B\u2026\u6691\u3055\u3067\u6C57\u3070\u3080\u3057\u82E6\u75DB\u3060\u30FC\u3002\u3067\u3082\u30AF\u30FC\u30E9\u30FC\u4ED8\u3051\u305F\u3089\u8CA0\u3051\u306A\u6C17\u304C\u3059\u308B\u3002\u65E9\u304F\u65E5\u304C\u843D\u3061\u3066\u3053\u306A\u3044\u304B\u306A\u3002\u591C\u306E\u65B9\u304C\u80FD\u7387\u4E0A\u304C\u308B\u306E\u306F\u53D7\u9A13\u52C9\u5F37\u306E\u305B\u3044\u304B\u306A\u3002\u3002",
  "id" : 71851345371598848,
  "created_at" : "2011-05-21 08:14:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71844246407217152",
  "text" : "\u3082\u3046\u3061\u3087\u3063\u3068\u6DBC\u3057\u304F\u306A\u3063\u305F\u3089\u305F\u307E\u306B\u306FCD\u3067\u3082\u501F\u308A\u306B\u884C\u3053\u3046\u304B\u306A\u30FC\u3002\u306A\u3093\u304B\u304A\u52E7\u3081\u306E\u30A2\u30FC\u30C6\u30A3\u30B9\u30C8\u3068\u304B\u30A2\u30EB\u30D0\u30E0\u3068\u304B\u3042\u3063\u305F\u3089\u6559\u3048\u3066\u304F\u3060\u3055\u3044\u306A\u3002\u30ED\u30C3\u30AF\u30E1\u30A4\u30F3\u3060\u3051\u3069\u305D\u308C\u4EE5\u5916\u3067\u3082\u3002\u9069\u5F53\u306B\u501F\u308A\u3066\u304F\u308B\u3002",
  "id" : 71844246407217152,
  "created_at" : "2011-05-21 07:46:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 17, 26 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71838229501980672",
  "text" : "\u4E00\u4EBA\u3067\u8A00\u8449\u306E\u30B8\u30E3\u30B0\u30EA\u30F3\u30B0\u2026 RT @koketomi: \u8A00\u8449\u306E\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\u30AD\u30E3\u30C3\u30C1\u30DC\u30FC\u30EB\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\u3063\u3046\u3047\uFF57\uFF57\uFF57\u3063\u3046\u3047\uFF57\uFF57\uFF57",
  "id" : 71838229501980672,
  "created_at" : "2011-05-21 07:22:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71836753564151808",
  "text" : "@koketomi \u7532\u4E59\u4ED8\u3051\u304C\u305F\u3044\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3\u3067\u7533\u3057\u8A33\u306A\u3044",
  "id" : 71836753564151808,
  "created_at" : "2011-05-21 07:16:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71833333641908224",
  "text" : "@koketomi \u4E59",
  "id" : 71833333641908224,
  "created_at" : "2011-05-21 07:02:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/KAc5aua",
      "expanded_url" : "http:\/\/shindanmaker.com\/121332",
      "display_url" : "shindanmaker.com\/121332"
    } ]
  },
  "geo" : { },
  "id_str" : "71829677999796224",
  "text" : "end313124\u306B\u4ED8\u3051\u3089\u308C\u305F\u30BF\u30B0\u306F\u300E\u5439\u3044\u305F\u3089\u8CA0\u3051\u300F\u300E\u5438\u5F15\u529B\u306E\u5909\u308F\u3089\u306A\u3044\u305F\u3060\u3072\u3068\u3064\u306E\u30B5\u30E0\u30CD\u300F\u300E\u3082\u3063\u3068\u8A55\u4FA1\u3055\u308C\u308B\u3079\u304D\u300F\u3068\u306A\u308A\u307E\u3057\u305F\u3002 http:\/\/t.co\/KAc5aua #121332",
  "id" : 71829677999796224,
  "created_at" : "2011-05-21 06:48:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71800315808194560",
  "text" : "\u3061\u3087\u3063\u3068\u98DF\u3079\u3059\u304E\u305F\u304B\u306A\u2026\u3002",
  "id" : 71800315808194560,
  "created_at" : "2011-05-21 04:51:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71788191815974912",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u306A\u3093\u304B\u30D5\u30A1\u30F3\u30AD\u30FC\u306B\u306A\u3063\u3066\u308B\uFF1F\u4EBA\u53E3\u7121\u80FD\uFF1F\u306B\u305B\u307B\u3068\u540C\u3058\u5302\u3044\u304C\u3059\u308B\u2026\u3002",
  "id" : 71788191815974912,
  "created_at" : "2011-05-21 04:03:33 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71785881215844352",
  "text" : "\u3056\u3063\u3068\uFF11\uFF11\u6642\u9593\u304F\u3089\u3044\u306F\u5BDD\u305F\u306A\u3001\u7761\u7720\u5341\u5206\uFF01",
  "id" : 71785881215844352,
  "created_at" : "2011-05-21 03:54:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71785217639198720",
  "text" : "@ayu167 \u3044\u3084\u3001\u4FFA\u306E\u65B9\u304C\u3059\u308C\u9055\u3063\u3066\u308B\u3057\uFF08\uFF77\uFF98\uFF6F",
  "id" : 71785217639198720,
  "created_at" : "2011-05-21 03:51:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 27, 36 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71781520746090496",
  "text" : "\u30AE\u30E3\u30B0\u304C\u30CF\u30A4\u30BB\u30F3\u30B9\u3059\u304E\u3066\u3064\u3044\u3066\u3044\u3051\u306A\u3044\u3067\u3059\u3045\u2026 RT @koketomi: \u82F1\u8A9E\u306EMen\u3092\u5E73\u6C17\u3067\u7DBF\u3068\u8A33\u3059\u5974\u304C\u30B4\u30ED\u30B4\u30ED\u3044\u308B\u82F1\u8A9E\u306E\u30AF\u30E9\u30B9\u30FB\u30FB\u30FB",
  "id" : 71781520746090496,
  "created_at" : "2011-05-21 03:37:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71609138735611904",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 71609138735611904,
  "created_at" : "2011-05-20 16:12:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71595474087460864",
  "geo" : { },
  "id_str" : "71597328364089344",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 71597328364089344,
  "in_reply_to_status_id" : 71595474087460864,
  "created_at" : "2011-05-20 15:25:07 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71593279958949889",
  "geo" : { },
  "id_str" : "71593701218070528",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84\u3000\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 71593701218070528,
  "in_reply_to_status_id" : 71593279958949889,
  "created_at" : "2011-05-20 15:10:43 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71593279958949889",
  "geo" : { },
  "id_str" : "71593539800276992",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84\u3000\u5165\u308C\u3089\u308C\u3066\u308B\u30EA\u30B9\u30C8\u304C\u591A\u304F\u306B\u4EBA\u306B\u30D5\u30A9\u30ED\u30FC\u3055\u308C\u3066\u308B\u3068\u304B\uFF1F",
  "id" : 71593539800276992,
  "in_reply_to_status_id" : 71593279958949889,
  "created_at" : "2011-05-20 15:10:04 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71591376697036800",
  "text" : "RT @tameninaru: \u77E5\u3089\u306A\u3044\u4EBA\u3092\u901A\u305B\u3093\u307C\u3059\u308B\u3068\u300C\u8EFD\u72AF\u7F6A\u6CD5\u300D\u304C\u9069\u7528\u3055\u308C\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71591023805087744",
    "text" : "\u77E5\u3089\u306A\u3044\u4EBA\u3092\u901A\u305B\u3093\u307C\u3059\u308B\u3068\u300C\u8EFD\u72AF\u7F6A\u6CD5\u300D\u304C\u9069\u7528\u3055\u308C\u308B",
    "id" : 71591023805087744,
    "created_at" : "2011-05-20 15:00:04 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 71591376697036800,
  "created_at" : "2011-05-20 15:01:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 53, 64 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u3086\u30FC\u3059\u3051",
      "screen_name" : "clementia1960",
      "indices" : [ 69, 83 ],
      "id_str" : "118708025",
      "id" : 118708025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71590232369283072",
  "text" : "\u50D5\u3082\u9ED2\u9AEA\u306E\u4E59\u5973\u3068\u4F55\u304B\u306E\u5B9A\u7406\u306E\u8A3C\u660E\u3092\u3064\u307E\u307F\u306B\u6570\u5B66\u8AC7\u7FA9\u306B\u82B1\u3092\u54B2\u304B\u305B\u308B\u3088\u3046\u306A\u5927\u5B66\u751F\u6D3B\u3092\u9001\u3063\u3066\u307F\u305F\u304B\u3063\u305F\u3002 RT @magokoro84: RT @clementia1960: \u5148\u751F\u3001\u50D5\u3082\u9ED2\u9AEA\u306E\u4E59\u5973\u3068\u30DA\u30EC\u30FC\u30F4\u30A3\u30F3\u3092\u3064\u307E\u307F\u306B\u6587\u5B66\u8AC7\u7FA9\u306B\u82B1\u3092\u54B2\u304B\u305B\u308B\u3088\u3046\u306A\u5927\u5B66\u751F\u6D3B\u3092\u9001\u3063\u3066\u307F\u305F\u304B\u3063\u305F\u3067\u3059\u3002",
  "id" : 71590232369283072,
  "created_at" : "2011-05-20 14:56:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71584220375547904",
  "geo" : { },
  "id_str" : "71585586883997697",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math 00101\u3000\u3082\u3057\u3083\u3082\u3057\u3083",
  "id" : 71585586883997697,
  "in_reply_to_status_id" : 71584220375547904,
  "created_at" : "2011-05-20 14:38:28 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 25, 36 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 50, 60 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 79, 90 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71584611230158848",
  "text" : "\u89E3\u3063\u3066\u305F\u3051\u3069\u30DC\u30B1\u3066\u307F\u305F\u3002\u89E3\u308A\u306B\u304F\u304B\u3063\u305F\u304B\u3002 RT @magokoro84: \u65B9\u4F4D\u78C1\u91DD\u306E\u65B9\u3060\u3088\uFF57RT @end313124: \u305D\u3093\u306A\u306B\u5186\u3092\u63CF\u304D\u305F\u3044\u306E\u304B\u3002\u3000RT @magokoro84: \u3067\u3001\u30DE\u30B8\u3067\u30B3\u30F3\u30D1\u30B9\u304C\u306A\u3044\u306E\u3060\u304C",
  "id" : 71584611230158848,
  "created_at" : "2011-05-20 14:34:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 17, 28 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71583660700205056",
  "text" : "\u305D\u3093\u306A\u306B\u5186\u3092\u63CF\u304D\u305F\u3044\u306E\u304B\u3002\u3000RT @magokoro84: \u3067\u3001\u30DE\u30B8\u3067\u30B3\u30F3\u30D1\u30B9\u304C\u306A\u3044\u306E\u3060\u304C",
  "id" : 71583660700205056,
  "created_at" : "2011-05-20 14:30:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71580861295898624",
  "geo" : { },
  "id_str" : "71581444362878976",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u9752\u3068\u304B\u7D2B\u3068\u304B\u597D\u304D\u3060\u3051\u3069\u306A\u30FC\u3002\u5973\u5B50\u529B\u306A\u3044\u306E\u304B\u30FC\u3002",
  "id" : 71581444362878976,
  "in_reply_to_status_id" : 71580861295898624,
  "created_at" : "2011-05-20 14:22:00 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71580402648748033",
  "text" : "\u3057\u3070\u3089\u304F\u307E\u3068\u3082\u306B\u50CD\u304B\u306A\u304B\u3063\u305F\u30D7\u30ED\u30B0\u30E9\u30E0\u304C\u3061\u3087\u3063\u3068\u3057\u305F\u30DF\u30B9\u306B\u6C17\u304C\u4ED8\u3044\u305F\u3089\u3059\u3093\u306A\u308A\u52D5\u3044\u305F\u3002\u8868\u793A\u3059\u308B\u5909\u6570\u306E\u578B\u306E\u30DF\u30B9\u3068\u304B\u521D\u6B69\u7684\u3060\u3002",
  "id" : 71580402648748033,
  "created_at" : "2011-05-20 14:17:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71571983694970880",
  "text" : "@np2i \u306A\u308B\u307B\u3069\u3001\u7A81\u7136\u51FA\u3066\u304D\u305F\u304B\u3089\u3073\u3063\u304F\u308A\u3057\u307E\u3057\u305F\u3002",
  "id" : 71571983694970880,
  "created_at" : "2011-05-20 13:44:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71568051107143680",
  "text" : "RT @JOJO_math: \u30D0\u30FC\u30C8\u30E9\u30F3\u30C9\u2026\u3000\u3055\u3063\u304D\u304B\u3089\u30D1\u30E9\u30C9\u30C3\u30AF\u30B9\u3000\u30D1\u30E9\u30C9\u30C3\u30AF\u30B9\u3068\u3055\u304B\u3093\u306B\u8A00\u3063\u3066\u307E\u3059\u304C\u3000\u81EA\u5206\u81EA\u8EAB\u3092\u8981\u7D20\u306B\u6301\u305F\u306A\u3044\u96C6\u5408\u5168\u3066\u306E\u96C6\u5408\u306A\u3093\u3066\u3042\u308A\u307E\u305B\u3093\u3088\u2026\u3000\u30D5\u30A1\u30F3\u30BF\u30B8\u30FC\u3084\u30E1\u30EB\u30D8\u30F3\u3058\u3083\u3042\u306A\u3044\u3093\u3067\u3059\u304B\u3089",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71567867136589824",
    "text" : "\u30D0\u30FC\u30C8\u30E9\u30F3\u30C9\u2026\u3000\u3055\u3063\u304D\u304B\u3089\u30D1\u30E9\u30C9\u30C3\u30AF\u30B9\u3000\u30D1\u30E9\u30C9\u30C3\u30AF\u30B9\u3068\u3055\u304B\u3093\u306B\u8A00\u3063\u3066\u307E\u3059\u304C\u3000\u81EA\u5206\u81EA\u8EAB\u3092\u8981\u7D20\u306B\u6301\u305F\u306A\u3044\u96C6\u5408\u5168\u3066\u306E\u96C6\u5408\u306A\u3093\u3066\u3042\u308A\u307E\u305B\u3093\u3088\u2026\u3000\u30D5\u30A1\u30F3\u30BF\u30B8\u30FC\u3084\u30E1\u30EB\u30D8\u30F3\u3058\u3083\u3042\u306A\u3044\u3093\u3067\u3059\u304B\u3089",
    "id" : 71567867136589824,
    "created_at" : "2011-05-20 13:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 71568051107143680,
  "created_at" : "2011-05-20 13:28:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71567831346585600",
  "text" : "\u221E\u3092\u639B\u3051\u308C\u3070\u3001\u3068\u308A\u3042\u3048\u305A\u4E0D\u5B9A\u5F62\u2026\u3002RT @guratasotaso: \u5F7C\u5973\u304C\u3067\u304D\u308B\u53EF\u80FD\u6027\u3088\u308A\u25CB\u500D\u3063\u3066\u8A00\u308F\u308C\u305F\u77AC\u9593\u6B7B\u306C \u306A\u305C\u306A\u3089\uFF10\u306B\u4F55\u3092\u8CED\u3051\u3066\u3082\uFF10\u3060\u304B\u3089",
  "id" : 71567831346585600,
  "created_at" : "2011-05-20 13:27:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71566678986731520",
  "geo" : { },
  "id_str" : "71567310321754112",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u6614\u3001\u587E\u306E\u5148\u751F\u306B\u300C\u98F2\u307F\u5207\u308C\u306A\u304B\u3063\u305F\u98F2\u307F\u7269\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u3067\u3059\u304B\u300D\u3063\u3066\u805E\u3044\u305F\u3089\u6D41\u3057\u3068\u9593\u9055\u3048\u3066\u300C\u86C7\u53E3\u306B\u6368\u3066\u3066\u304D\u306A\u3055\u3044\u300D\u3063\u3066\u8A00\u308F\u308C\u3066\u5999\u306B\u30C4\u30DC\u3063\u305F\u3053\u3068\u3092\u601D\u3044\u51FA\u3057\u305F\u3002\u6B21\u306B\u86C7\u53E3\u3072\u306D\u3063\u305F\u4EBA\u3053\u307E\u308B\u3088\u306D\u3001\u3046\u3093\u3002",
  "id" : 71567310321754112,
  "in_reply_to_status_id" : 71566678986731520,
  "created_at" : "2011-05-20 13:25:51 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71566512024072192",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u3001ZOON\u306E\u4E00\u6642\u7684\u306A\u5FA9\u6D3B\u3068\u3042\u306E\u82B1\u306EED\u306E\u30AB\u30F4\u30A1\u30FC\u3063\u3066\u306A\u3093\u304B\u95A2\u9023\u3059\u308B\u306E\u304B\u306A\u3001\u30AF\u30E9\u30A4\u30DE\u30C3\u30AF\u30B9\u3067\u5225\u306E\u66F2\u6D41\u308C\u305F\u308A\u3057\u305F\u3089\u71B1\u3044\u306A\u30FC",
  "id" : 71566512024072192,
  "created_at" : "2011-05-20 13:22:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71566089678630912",
  "text" : "C\u306EOP\u306E\u30DE\u30C8\u30EA\u30E7\u30FC\u30B7\u30AB\u304C\u982D\u304B\u3089\u96E2\u308C\u306A\u3044\u2026\u3002",
  "id" : 71566089678630912,
  "created_at" : "2011-05-20 13:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71565929502355456",
  "text" : "\u3042\u308C\u3063\uFF1F\u81EA\u5206\u306E\u516C\u5F0FRT\u3063\u3066TL\u306B\u8868\u793A\u3055\u308C\u308B\u306E\uFF1F",
  "id" : 71565929502355456,
  "created_at" : "2011-05-20 13:20:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71565140948041728",
  "geo" : { },
  "id_str" : "71565705060954112",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u81EA\u4FE1\u6E80\u3005\u306B\u7B54\u3048\u3089\u308C\u308B\u3068\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044\u7A7A\u6C17\u304C\u3042\u308B\u3088\u306D\u30FC\u3002",
  "id" : 71565705060954112,
  "in_reply_to_status_id" : 71565140948041728,
  "created_at" : "2011-05-20 13:19:28 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marumaru2012",
      "screen_name" : "marumaru1981",
      "indices" : [ 3, 16 ],
      "id_str" : "226764295",
      "id" : 226764295
    }, {
      "name" : "ZAKZAK",
      "screen_name" : "zakdesk",
      "indices" : [ 108, 116 ],
      "id_str" : "68643433",
      "id" : 68643433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/yAIU33n",
      "expanded_url" : "http:\/\/www.zakzak.co.jp\/society\/domestic\/news\/20110517\/dms1105171535015-n1.htm",
      "display_url" : "zakzak.co.jp\/society\/domest\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "71564994046734336",
  "text" : "RT @marumaru1981: \u3053\u308C\u306F\uFF01\uFF01\u5B8C\u5168\u306B\u3069\u3046\u304B\u3057\u3066\u3044\u308B\u306E\u3067\u306F\uFF1F\uFF1F\u2192\u30CD\u30C3\u30C8\u3067\u52DF\u96C6\u306E\u300C\u6210\u4EBA\u5408\u5BBF\u300D\u3000\u521D\u4F53\u9A13\u306E\u304A\u76F8\u624B\u306F\u62BD\u9078\u3067\u6C7A\u5B9A - \u653F\u6CBB\u30FB\u793E\u4F1A - ZAKZAK http:\/\/t.co\/yAIU33n via @zakdesk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ZAKZAK",
        "screen_name" : "zakdesk",
        "indices" : [ 90, 98 ],
        "id_str" : "68643433",
        "id" : 68643433
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 85 ],
        "url" : "http:\/\/t.co\/yAIU33n",
        "expanded_url" : "http:\/\/www.zakzak.co.jp\/society\/domestic\/news\/20110517\/dms1105171535015-n1.htm",
        "display_url" : "zakzak.co.jp\/society\/domest\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "71537065019453440",
    "text" : "\u3053\u308C\u306F\uFF01\uFF01\u5B8C\u5168\u306B\u3069\u3046\u304B\u3057\u3066\u3044\u308B\u306E\u3067\u306F\uFF1F\uFF1F\u2192\u30CD\u30C3\u30C8\u3067\u52DF\u96C6\u306E\u300C\u6210\u4EBA\u5408\u5BBF\u300D\u3000\u521D\u4F53\u9A13\u306E\u304A\u76F8\u624B\u306F\u62BD\u9078\u3067\u6C7A\u5B9A - \u653F\u6CBB\u30FB\u793E\u4F1A - ZAKZAK http:\/\/t.co\/yAIU33n via @zakdesk",
    "id" : 71537065019453440,
    "created_at" : "2011-05-20 11:25:40 +0000",
    "user" : {
      "name" : "marumaru2012",
      "screen_name" : "marumaru1981",
      "protected" : false,
      "id_str" : "226764295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1229631045\/01_normal.jpg",
      "id" : 226764295,
      "verified" : false
    }
  },
  "id" : 71564994046734336,
  "created_at" : "2011-05-20 13:16:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71562254256062466",
  "geo" : { },
  "id_str" : "71563886670778368",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u306A\u3093\u304B\u9762\u767D\u3044\u4F8B\u3042\u308A\u307E\u3059\u304B\u30FC\uFF1F",
  "id" : 71563886670778368,
  "in_reply_to_status_id" : 71562254256062466,
  "created_at" : "2011-05-20 13:12:14 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/N9YFEgI",
      "expanded_url" : "http:\/\/shindanmaker.com\/121406",
      "display_url" : "shindanmaker.com\/121406"
    } ]
  },
  "geo" : { },
  "id_str" : "71563583577800704",
  "text" : "end313124\u3055\u3093\u306E\u5965\u3055\u3093\u306F\u8EAB\u9577159cm\u3002\u9AEA\u578B\u306F\u30BB\u30DF\u30ED\u30F3\u30B0\u3001\u9854\u7ACB\u3061\u306F\u6E05\u695A\u7F8E\u4EBA\u30BF\u30A4\u30D7\u3067\u3001\u30D0\u30B9\u30C890cm\u3002\u7269\u9759\u304B\u3067\u30AF\u30FC\u30EB\u306A\u6027\u683C\u3067\u3001\u6383\u9664\u304C\u5F97\u610F\u3002\u9154\u3046\u3068\u30AD\u30B9\u9B54\u306B\u306A\u308A\u307E\u3059\u3002 http:\/\/t.co\/N9YFEgI  \u7269\u9759\u304B\u3063\u3066\u5927\u4E8B\u306A\u8981\u7D20\u3088\u306D\u3002",
  "id" : 71563583577800704,
  "created_at" : "2011-05-20 13:11:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71561378711863296",
  "text" : "\u529B\u3044\u3063\u3071\u3044\u529B\u3092\u629C\u304F\u3053\u3068\u306F\u9AD8\u6821\u3067\u6559\u308F\u3063\u305F\uFF08\uFF77\uFF98\uFF6F",
  "id" : 71561378711863296,
  "created_at" : "2011-05-20 13:02:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71561280917487617",
  "text" : "\u3067\u3082\u4ECA\u591C\u306F\u3044\u3064\u3082\u306E\u3088\u3046\u306B\uFF47\uFF44\uFF47\uFF44\u3059\u308B\u306E\u3067\u306F\u306A\u304F\u3001\u5168\u529B\u3067\uFF47\uFF44\uFF47\uFF44\u3057\u3088\u3046\u3068\u601D\u3046\u3002",
  "id" : 71561280917487617,
  "created_at" : "2011-05-20 13:01:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71560883662372864",
  "text" : "\u8AB2\u984C\u3084\u3093\u306A\u304D\u3083\u306A\u30FC\u3068\u601D\u3044\u306A\u304C\u3089\uFF47\uFF44\uFF47\uFF44\u3059\u308B\u306E\u304C\u91D1\u66DC\u306E\u591C\u3002",
  "id" : 71560883662372864,
  "created_at" : "2011-05-20 13:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u306A\u304B\u3093",
      "screen_name" : "sanakan",
      "indices" : [ 3, 11 ],
      "id_str" : "5452512",
      "id" : 5452512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71559601522352129",
  "text" : "RT @sanakan: \u30C1\u30E3\u30FC\u30EA\u30FC\u3068\u3061\u3087\uFF57\uFF57\uFF57\u3053\u308C\uFF57\uFF57\u51B7\u51CD\u5DE5\u5834\uFF57\uFF57\uFF57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/cheebow.info\/chemt\/archives\/2007\/04\/twitterwindowst.html\" rel=\"nofollow\"\u003ETwit for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71558824011644928",
    "text" : "\u30C1\u30E3\u30FC\u30EA\u30FC\u3068\u3061\u3087\uFF57\uFF57\uFF57\u3053\u308C\uFF57\uFF57\u51B7\u51CD\u5DE5\u5834\uFF57\uFF57\uFF57",
    "id" : 71558824011644928,
    "created_at" : "2011-05-20 12:52:07 +0000",
    "user" : {
      "name" : "\u3055\u306A\u304B\u3093",
      "screen_name" : "sanakan",
      "protected" : false,
      "id_str" : "5452512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443764967045464064\/qjI5wq51_normal.jpeg",
      "id" : 5452512,
      "verified" : false
    }
  },
  "id" : 71559601522352129,
  "created_at" : "2011-05-20 12:55:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KU",
      "indices" : [ 78, 81 ]
    }, {
      "text" : "math",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71556795906277376",
  "text" : "\u3010\u5B9A\u671F\u30FB\u624B\u52D5\u30FB\u62E1\u6563\u5E0C\u671B\u3011\uFF2B\uFF35\u3067\u6587\u7406\u554F\u308F\u305A\u958B\u304B\u308C\u305F\u6570\u5B66\u30B5\u30FC\u30AF\u30EB\u4F5C\u3063\u305F\u3089\uFF08\u7814\u7A76\u4F1A\u307F\u305F\u3044\u306A\u5805\u82E6\u3057\u3044\u306E\u3067\u306A\u304F\uFF09\u5165\u3063\u3066\u304F\u308C\u308B\u4EBA\u52DF\u96C6\u3002\uFF15\u4EBA\u4EE5\u4E0A\u3044\u308B\u3088\u3046\u306A\u3089\u672C\u6C17\u51FA\u3059\u3002 \u3000#KU #math",
  "id" : 71556795906277376,
  "created_at" : "2011-05-20 12:44:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71556661168443392",
  "text" : "\u3010\u624B\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 71556661168443392,
  "created_at" : "2011-05-20 12:43:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71496371202560000",
  "text" : "C\u3082\u3042\u306E\u82B1\u3082\u898B\u3061\u3083\u3063\u305F\u3002\u3069\u3063\u3061\u3082\u3044\u3044\u611F\u3058\u3002",
  "id" : 71496371202560000,
  "created_at" : "2011-05-20 08:43:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71488401513259009",
  "text" : "@nico_reflexio \u3075\u3045\u3093\u3002\u307E\u3041\u8A73\u3057\u304F\u6C7A\u307E\u3063\u305F\u3089\u9023\u7D61\u3057\u3066\u306D\u30FC",
  "id" : 71488401513259009,
  "created_at" : "2011-05-20 08:12:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71485805662715904",
  "text" : "@nico_reflexio \u3067\u3044\u3064\u304B\u3089\u3053\u3063\u3061\u306B\u6765\u308B\u306E\uFF1F",
  "id" : 71485805662715904,
  "created_at" : "2011-05-20 08:01:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "indices" : [ 3, 9 ],
      "id_str" : "127940910",
      "id" : 127940910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71483325914681344",
  "text" : "RT @alg_d: p\u9032\u5C55\u958B \u03B1 = \u03A3a_mp^m \u306E\u30B3\u30F3\u30D3\u30CB\u611Fww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71448709497495552",
    "text" : "p\u9032\u5C55\u958B \u03B1 = \u03A3a_mp^m \u306E\u30B3\u30F3\u30D3\u30CB\u611Fww",
    "id" : 71448709497495552,
    "created_at" : "2011-05-20 05:34:34 +0000",
    "user" : {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "protected" : false,
      "id_str" : "127940910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579632693668773888\/0Susg2n0_normal.jpg",
      "id" : 127940910,
      "verified" : false
    }
  },
  "id" : 71483325914681344,
  "created_at" : "2011-05-20 07:52:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 3, 12 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71425494553333761",
  "text" : "RT @mesaya31: \u5352\u691C\u5408\u683C\u306A\u3046\u3046\u3046\u3046\u3046\u3002\n\n\u3055\u3042\u3001\u307F\u3093\u306A\u30EA\u30C4\u30A4\u30FC\u30C8\u3060\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71419814383583232",
    "text" : "\u5352\u691C\u5408\u683C\u306A\u3046\u3046\u3046\u3046\u3046\u3002\n\n\u3055\u3042\u3001\u307F\u3093\u306A\u30EA\u30C4\u30A4\u30FC\u30C8\u3060\uFF01",
    "id" : 71419814383583232,
    "created_at" : "2011-05-20 03:39:45 +0000",
    "user" : {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "protected" : false,
      "id_str" : "174262858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1854605073\/image_normal.jpg",
      "id" : 174262858,
      "verified" : false
    }
  },
  "id" : 71425494553333761,
  "created_at" : "2011-05-20 04:02:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u306A\u304B\u3093",
      "screen_name" : "sanakan",
      "indices" : [ 0, 8 ],
      "id_str" : "5452512",
      "id" : 5452512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71406056512823296",
  "geo" : { },
  "id_str" : "71407207517925376",
  "in_reply_to_user_id" : 5452512,
  "text" : "@sanakan \u50D5\u306F\u597D\u304D\u3067\u3059\u3051\u3069\u306D\u3001\u305F\u3060\u306E\u70AD\u9178\u6C34",
  "id" : 71407207517925376,
  "in_reply_to_status_id" : 71406056512823296,
  "created_at" : "2011-05-20 02:49:39 +0000",
  "in_reply_to_screen_name" : "sanakan",
  "in_reply_to_user_id_str" : "5452512",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B97\u6570\u554F\u984C\u30DC\u30C3\u30C8",
      "screen_name" : "arithmetic_bot",
      "indices" : [ 17, 32 ],
      "id_str" : "221364927",
      "id" : 221364927
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arithmetic",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71399387275866112",
  "text" : "16 24 48 \u3060\u3051\u304B\u306A RT @arithmetic_bot: 973\u3092\u5272\u308B\u306813\u4F59\u308A\u3001539\u3092\u5272\u308B\u306811\u4F59\u308B\u6574\u6570\u3092\u5168\u3066\u6C42\u3081\u3088\u3002\uFF08\uFF10\uFF16\u30E9\u30FB\u30B5\u30FC\u30EB\u4E2D\uFF09 #arithmetic",
  "id" : 71399387275866112,
  "created_at" : "2011-05-20 02:18:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71358561829138432",
  "text" : "\u6642\u9593\u3060\u30A1\u2026\u307E\u3041\u3044\u30FC\u3084\u3001\u9045\u523B\u3059\u308B\u306E\u5ACC\u3044\u3060\u3051\u3069\u7126\u308B\u65B9\u304C\u5ACC\u3044\u3060\u304B\u3089\u3086\u3063\u304F\u308A\u884C\u304F\u3053\u3068\u306B\u3057\u3088\u3046",
  "id" : 71358561829138432,
  "created_at" : "2011-05-19 23:36:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71357664537493504",
  "text" : "\u3042\u3068\uFF13\u5206\u3067\u51FA\u308C\u3070\u9593\u306B\u5408\u3046\u304B\u2026\u4E09\u5206\u9593\u5F85\u3063\u3066\u3084\u308B\uFF01",
  "id" : 71357664537493504,
  "created_at" : "2011-05-19 23:32:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71357362920898560",
  "text" : "\u4E00\u9650\u5E7B\u60F3",
  "id" : 71357362920898560,
  "created_at" : "2011-05-19 23:31:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71239026312622080",
  "geo" : { },
  "id_str" : "71239360460230656",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u306E\u65E5\u898B\u305F\u82B1\u306E\u301C\u3063\u3066\u30A2\u30CB\u30E1\u306E\uFF25\uFF24\u306B\u30EA\u30E1\u30A4\u30AF\u3055\u308C\u3066\u305F\u3088\u3093",
  "id" : 71239360460230656,
  "in_reply_to_status_id" : 71239026312622080,
  "created_at" : "2011-05-19 15:42:41 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u3079\u308A\u30FC\u305A\u3073\u3085\u30FC\u3066\u3043\u30FC",
      "screen_name" : "TKS_lakoon",
      "indices" : [ 12, 23 ],
      "id_str" : "159903756",
      "id" : 159903756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71233766403735555",
  "geo" : { },
  "id_str" : "71234890212966400",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 @TKS_lakoon \u7269\u7406\u5316\u5B66\u306A\u3089\u53BB\u5E74\u5EA6\u5F8C\u671F\u306B\u53D7\u3051\u3066\u305F\u300261\u3067\u30AE\u30EA\u30AE\u30EA\u901A\u3057\u305F\u30C3\uFF01\u662F\u975E\u91CF\u5B50\u529B\u5B66\u306E\u3084\u3064\u53D6\u308D\u3046\u3002",
  "id" : 71234890212966400,
  "in_reply_to_status_id" : 71233766403735555,
  "created_at" : "2011-05-19 15:24:55 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71229560892563456",
  "geo" : { },
  "id_str" : "71230171293827072",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u305D\u3093\u306A\u52E4\u52C9\u306A\u90E8\u9577\u3058\u3083\u306A\u3044\u3067\u3059\u3088\u3002\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u3067\u3059\u3002",
  "id" : 71230171293827072,
  "in_reply_to_status_id" : 71229560892563456,
  "created_at" : "2011-05-19 15:06:10 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71229546409627649",
  "text" : "\u305D\u3046\u8A00\u3048\u3070\u5B9A\u671Fpost\u3063\u3066\u5B9F\u884C\u3055\u308C\u305F\u306E\u304B\u306A\u3001\u898B\u305F\u8A18\u61B6\u304C\u306A\u3044\u3093\u3060\u3051\u3069\u3001\u898B\u305F\u4EBA\u3044\u3066\u307E\u3059\u304B\u30FC\uFF1F",
  "id" : 71229546409627649,
  "created_at" : "2011-05-19 15:03:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71224923573587968",
  "text" : "\u4E45\u3005\u306B\u65C5\u884C\u96D1\u8A8C\u773A\u3081\u3066\u305F\u3089\u304A\u8179\u6E1B\u3063\u305F\u306A\u3041\u2026\u3042\u3068\u3082\u3046\u3061\u3087\u3044\u3061\u3087\u304F\u3061\u3087\u304F\u8ECA\u904B\u8EE2\u3057\u305F\u3044\u306A",
  "id" : 71224923573587968,
  "created_at" : "2011-05-19 14:45:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71219960164253697",
  "geo" : { },
  "id_str" : "71220315988037632",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4ECA\u5EA6\u884C\u3063\u3066\u307F\u307E\u3059\u304B\u30FC",
  "id" : 71220315988037632,
  "in_reply_to_status_id" : 71219960164253697,
  "created_at" : "2011-05-19 14:27:01 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71219595125604352",
  "text" : "\u65E9\u3044\u3051\u3069\u5E03\u56E3\u306B\u5165\u308D\u3046\u304B\u306A\u3001\u8AB2\u984C\u9032\u307E\u306A\u3044\u3002\u7720\u3044\u3002\u660E\u65E5\u306E\u6E96\u5099\u3060\u3051\u3057\u3066\u304A\u304B\u306A\u304F\u3061\u3083\u3002",
  "id" : 71219595125604352,
  "created_at" : "2011-05-19 14:24:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 23, 34 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71201973617168384",
  "text" : "http:\/\/goo.gl\/0swer\u3000RT @magokoro84: \u305D\u3046\u3044\u3048\u3070\u6614\u632F\u52D5\u30D1\u30C3\u30AF\u307F\u305F\u3044\u306A\u306E\u4F1A\u3063\u305F\u3088\u3046\u306A\u6C17\u304C\u3059\u308B",
  "id" : 71201973617168384,
  "created_at" : "2011-05-19 13:14:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71143504511893504",
  "text" : "\u305D\u3093\u306A\u7406\u7CFB\u306E\u304A\u53CB\u9054\u304C\u6B32\u3057\u3044\u3002",
  "id" : 71143504511893504,
  "created_at" : "2011-05-19 09:21:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71112760506843136",
  "text" : "MH5\u5DFB\u306F5\uFF0F27\u304B\u30FC \u51FA\u8CBB\u304C\u5D69\u3080",
  "id" : 71112760506843136,
  "created_at" : "2011-05-19 07:19:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71024699622174720",
  "text" : "\u5999\u306A\u751F\u6D3B\u30EA\u30BA\u30E0\u30A1\u2026\u6388\u696D\u306B\u3083\u9045\u523B\u3057\u306A\u304B\u3063\u305F\u304C\u59CB\u307E\u3063\u305F\u3089\u610F\u8B58\u3092\u4FDD\u3064\u81EA\u4FE1\u306F\u306A\u3044\u30C3\uFF01(\uFF77\uFF98\uFF6F",
  "id" : 71024699622174720,
  "created_at" : "2011-05-19 01:29:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71023444598337536",
  "text" : "@np2i \u539F\u3055\u3093\u306E\u51A5\u798F\u3092\u304A\u7948\u308A\u3044\u305F\u3057\u307E\u3059\u3002",
  "id" : 71023444598337536,
  "created_at" : "2011-05-19 01:24:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    }, {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 13, 20 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71020092124696576",
  "geo" : { },
  "id_str" : "71021072434208768",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku @ayu167 \u3053\u3046\u6691\u3044\u3068\u3001\u3080\u3057\u3087\u3046\u306B\u30A2\u30A4\u30B9\u3068\u304B\u98DF\u3079\u305F\u304F\u306A\u308B\u3088\u306D\u3002",
  "id" : 71021072434208768,
  "in_reply_to_status_id" : 71020092124696576,
  "created_at" : "2011-05-19 01:15:17 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70935829538803714",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 70935829538803714,
  "created_at" : "2011-05-18 19:36:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70935798014414848",
  "text" : "\uFF13\u6642\u9593\u304F\u3089\u3044\u5BDD\u308B\u304B\u306A\u3001\u5999\u306A\u751F\u6D3B\u30EA\u30BA\u30E0\u3060\u3002",
  "id" : 70935798014414848,
  "created_at" : "2011-05-18 19:36:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70935511853834240",
  "text" : "\u3053\u3093\u306A\u6642\u9593\u306B\u3064\u3076\u3084\u3044\u3066\u3082\u8AB0\u3082\u898B\u3066\u304F\u308C\u306A\u3044\u3060\u308D\u3046\u3051\u3069\u3001\u4E00\u5FDC\u3002",
  "id" : 70935511853834240,
  "created_at" : "2011-05-18 19:35:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70935399308079104",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u5B9A\u671F\u30DD\u30B9\u30C8\u8A2D\u5B9A\u3057\u305F\u304B\u3089\u82E5\u5E72\u9B31\u9676\u3057\u3044\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u3001\u3042\u3057\u304B\u3089\u305A\u3002\u3067\u3082\u307E\u3041\u4E00\u65E5\u4E00\u56DE\u3082\u306A\u3044\u3057\u52D8\u5F01\u3057\u3066\u307B\u3057\u3044\u3001\u3046\u3093\u3002",
  "id" : 70935399308079104,
  "created_at" : "2011-05-18 19:34:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70935084328423424",
  "text" : "\u3042\u30FC\u660E\u308B\u304F\u306A\u3063\u3066\u304D\u305F\u306A\u3041\u3002",
  "id" : 70935084328423424,
  "created_at" : "2011-05-18 19:33:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70930100887105536",
  "text" : "RT @JOJO_math: \u300C\u3053\u306E\u8A3C\u660E\u306E\u50B7\u3092\u76F4\u305B\u3070\u67FB\u8AAD\u8005\u306E\u30E4\u30C4\u306B\u3064\u3051\u3089\u308C\u305F\u30B3\u30E1\u30F3\u30C8\u3067\u306E\u63A1\u9332\u6761\u4EF6\u306F\u5B8C\u6210\u3059\u308B\uFF01\u3053\u3044\u546A\u3044\u5E2B\uFF01\u8CB4\u69D8\u306E\u88DC\u984C\u3067\u3053\u306E\u50B7\u3092\u89E3\u6D88\u3057\u3066\u3084\u308D\u3046\uFF01\u300D\u300C\u304D\u3055\u307E\u30FC\u3000\u3044\u3063\u305F\u3044\u4F55\u56DE\u306E\u9078\u629E\u516C\u7406\u3092\u305D\u306E\u4E3B\u5F35\u306E\u305F\u3081\u306B\u4F7F\u7528\u3057\u305F\uFF01\uFF1F\u300D\u300C\u304A\u524D\u306F\u4ECA\u307E\u3067\u4F7F\u3063\u305F\u6392\u4E2D\u5F8B\u306E\u56DE\u6570\u3092\u899A\u3048\u3066\u3044\u308B\u306E\u304B\uFF1F\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70918588344705024",
    "text" : "\u300C\u3053\u306E\u8A3C\u660E\u306E\u50B7\u3092\u76F4\u305B\u3070\u67FB\u8AAD\u8005\u306E\u30E4\u30C4\u306B\u3064\u3051\u3089\u308C\u305F\u30B3\u30E1\u30F3\u30C8\u3067\u306E\u63A1\u9332\u6761\u4EF6\u306F\u5B8C\u6210\u3059\u308B\uFF01\u3053\u3044\u546A\u3044\u5E2B\uFF01\u8CB4\u69D8\u306E\u88DC\u984C\u3067\u3053\u306E\u50B7\u3092\u89E3\u6D88\u3057\u3066\u3084\u308D\u3046\uFF01\u300D\u300C\u304D\u3055\u307E\u30FC\u3000\u3044\u3063\u305F\u3044\u4F55\u56DE\u306E\u9078\u629E\u516C\u7406\u3092\u305D\u306E\u4E3B\u5F35\u306E\u305F\u3081\u306B\u4F7F\u7528\u3057\u305F\uFF01\uFF1F\u300D\u300C\u304A\u524D\u306F\u4ECA\u307E\u3067\u4F7F\u3063\u305F\u6392\u4E2D\u5F8B\u306E\u56DE\u6570\u3092\u899A\u3048\u3066\u3044\u308B\u306E\u304B\uFF1F\u300D",
    "id" : 70918588344705024,
    "created_at" : "2011-05-18 18:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 70930100887105536,
  "created_at" : "2011-05-18 19:13:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70904621673099265",
  "geo" : { },
  "id_str" : "70904921913954304",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u3084\u3059\u307F",
  "id" : 70904921913954304,
  "in_reply_to_status_id" : 70904621673099265,
  "created_at" : "2011-05-18 17:33:45 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3058\u3087\u30FC\u306D\u3064",
      "screen_name" : "johnetsu",
      "indices" : [ 3, 12 ],
      "id_str" : "68391561",
      "id" : 68391561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70900681992716288",
  "text" : "RT @johnetsu: \u300C\u306D\u3048\u308F\u304F\u308F\u304F\u3055\u3093\uFF01\u4ECA\u65E5\u306F\u4F55\u3092\u4F5C\u308B\u306E\uFF1F\u300D\n\u300C\u4ECA\u65E5\u306F\u30D9\u30F3\u30C1\u30E3\u30FC\u4F01\u696D\u3092\u3064\u304F\u308B\u3088\uFF01\u300D\n\u300C\u3048\u3063\uFF01\uFF1F \u65B0\u5352\u306E\u5B66\u751F\u304C\u3044\u304D\u306A\u308A\u8D77\u696D\u3059\u308B\u306E\u306F\u30EA\u30B9\u30AF\u304C\u5927\u304D\u3059\u304E\u308B\u304B\u3089\u3001\u307E\u305A\u306F\u5927\u4F01\u696D\u306B\u5C31\u8077\u3057\u305F\u307B\u3046\u304C\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u306E\uFF1F\u300D\n\u300C\u50D5\u306F\u306D\u3001\u5185\u5B9A\u3092\u596A\u3046\u4EBA\u3058\u3083\u306A\u304F\u3066\u3001\u5185\u5B9A\u3092\u300E\u3064\u304F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70871705941315584",
    "text" : "\u300C\u306D\u3048\u308F\u304F\u308F\u304F\u3055\u3093\uFF01\u4ECA\u65E5\u306F\u4F55\u3092\u4F5C\u308B\u306E\uFF1F\u300D\n\u300C\u4ECA\u65E5\u306F\u30D9\u30F3\u30C1\u30E3\u30FC\u4F01\u696D\u3092\u3064\u304F\u308B\u3088\uFF01\u300D\n\u300C\u3048\u3063\uFF01\uFF1F \u65B0\u5352\u306E\u5B66\u751F\u304C\u3044\u304D\u306A\u308A\u8D77\u696D\u3059\u308B\u306E\u306F\u30EA\u30B9\u30AF\u304C\u5927\u304D\u3059\u304E\u308B\u304B\u3089\u3001\u307E\u305A\u306F\u5927\u4F01\u696D\u306B\u5C31\u8077\u3057\u305F\u307B\u3046\u304C\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u306E\uFF1F\u300D\n\u300C\u50D5\u306F\u306D\u3001\u5185\u5B9A\u3092\u596A\u3046\u4EBA\u3058\u3083\u306A\u304F\u3066\u3001\u5185\u5B9A\u3092\u300E\u3064\u304F\u308B\u300F\u4EBA\u306B\u306A\u308A\u305F\u3044\u3093\u3060\u3088\u3001\u30B4\u30ED\u30EA\u2026\u2026\u300D",
    "id" : 70871705941315584,
    "created_at" : "2011-05-18 15:21:46 +0000",
    "user" : {
      "name" : "\u3058\u3087\u30FC\u306D\u3064",
      "screen_name" : "johnetsu",
      "protected" : false,
      "id_str" : "68391561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450286661574729728\/JpuIV8g__normal.png",
      "id" : 68391561,
      "verified" : false
    }
  },
  "id" : 70900681992716288,
  "created_at" : "2011-05-18 17:16:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u84BC\u3061\u3085\u3093\u306F\u6559\u63A1\u306B\u5FC5\u6B7B",
      "screen_name" : "siraai",
      "indices" : [ 3, 10 ],
      "id_str" : "42441091",
      "id" : 42441091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70900656940126209",
  "text" : "RT @siraai: \u00D7\u300C\u30AB\u30EF\u30A4\u30A4\u306F\u4F5C\u308C\u308B\u300D\n\u25CB\u300C\u30D6\u30B5\u30A4\u30AF\u306F\u96A0\u305B\u308B\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70866971524206592",
    "text" : "\u00D7\u300C\u30AB\u30EF\u30A4\u30A4\u306F\u4F5C\u308C\u308B\u300D\n\u25CB\u300C\u30D6\u30B5\u30A4\u30AF\u306F\u96A0\u305B\u308B\u300D",
    "id" : 70866971524206592,
    "created_at" : "2011-05-18 15:02:57 +0000",
    "user" : {
      "name" : "\u84BC\u3061\u3085\u3093\u306F\u6559\u63A1\u306B\u5FC5\u6B7B",
      "screen_name" : "siraai",
      "protected" : false,
      "id_str" : "42441091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592666118017445890\/SwX0KckO_normal.jpg",
      "id" : 42441091,
      "verified" : false
    }
  },
  "id" : 70900656940126209,
  "created_at" : "2011-05-18 17:16:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70891603056795648",
  "text" : "@mo5nya \u82E6\u624B\u306A\u304C\u3089\u306B\u9811\u5F35\u3063\u3066\u514B\u670D\u3059\u308B\u3057\u304B\u306A\u3044\u3093\u3067\u3057\u3087\u3046\u306D\u3002\u3080\u3057\u308D\u5F97\u610F\u3068\u601D\u3044\u8FBC\u3093\u3067\u308B\u65B9\u304C\u6210\u9577\u3057\u306B\u304F\u3044\u3088\u3046\u306A\u6C17\u3082\u3057\u307E\u3059\u3002",
  "id" : 70891603056795648,
  "created_at" : "2011-05-18 16:40:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70890373446250496",
  "text" : "TL\u5927\u4EBA\u3057\u304F\u306A\u3063\u305F\u3002",
  "id" : 70890373446250496,
  "created_at" : "2011-05-18 16:35:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70889215902236673",
  "text" : "\u305D\u308C\u3067\u90E8\u5C4B\u304B\u3089\u51FA\u308B\u3053\u3068\u3063\u3066\u6B86\u3069\u7121\u3044\u3093\u3060\u3051\u3069\u306D",
  "id" : 70889215902236673,
  "created_at" : "2011-05-18 16:31:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70889083370618880",
  "text" : "\u7740\u7269\u3082\u305D\u3046\u3060\u3051\u308C\u3069\u4E00\u679A\u3067\u7740\u308C\u308B\u3082\u306E\u597D\u304D\u3068\u6C17\u4ED8\u3044\u305F\u3002\u6D74\u8863\u7136\u308A\u30D0\u30B9\u30ED\u30FC\u30D6\u7136\u308A\u3002\u6C7A\u3057\u3066\u52D5\u304D\u3084\u3059\u304F\u306F\u306A\u3044\u3051\u308C\u3069\u3002",
  "id" : 70889083370618880,
  "created_at" : "2011-05-18 16:30:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70887817508700160",
  "geo" : { },
  "id_str" : "70888382976368641",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6587\u5B66\u90E8\u82F1\u8A9E\u306E\u7BC4\u56F2\u3063\u3066\u3069\u3053\uFF4D\uFF08\uFF52\uFF59",
  "id" : 70888382976368641,
  "in_reply_to_status_id" : 70887817508700160,
  "created_at" : "2011-05-18 16:28:02 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70888023792955392",
  "text" : "\u3088\u3057\u8A18\u53F7\u8AD6\u7406\u7247\u4ED8\u3044\u305F\u3002\u4F8B\u984C\u306B\u3082\u89E6\u308C\u3066\u3060\u3044\u3076\u201D\u304A\u53CB\u9054\u201D\u306B\u306A\u3063\u3066\u304D\u305F\u3002",
  "id" : 70888023792955392,
  "created_at" : "2011-05-18 16:26:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70887614512758784",
  "geo" : { },
  "id_str" : "70887765440593921",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4ECA\u9031\u767A\u8868\u3063\u3066\u30E1\u30E2\u304C\u624B\u5E33\u306B\u3042\u308B\u3002",
  "id" : 70887765440593921,
  "in_reply_to_status_id" : 70887614512758784,
  "created_at" : "2011-05-18 16:25:34 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70887386875310080",
  "geo" : { },
  "id_str" : "70887683802664960",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8A9E\u5B66\u3068\u3082\u6559\u8077\u3068\u3082\u304B\u3076\u3063\u3066\u3044\u308B\u3002",
  "id" : 70887683802664960,
  "in_reply_to_status_id" : 70887386875310080,
  "created_at" : "2011-05-18 16:25:15 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70877078190432256",
  "text" : "\u9000\u5E2D\u4E2D\u3092\u4F53\u7A4D\u4E2D\u3068\u4E00\u767A\u5909\u63DB\u3059\u308B\u4FFA\u306EPC\u2026",
  "id" : 70877078190432256,
  "created_at" : "2011-05-18 15:43:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70871094717972480",
  "geo" : { },
  "id_str" : "70871626685755392",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4FFA\u3082\u5BDD\u308B\u304B\u5BDD\u306A\u3044\u304B\u8FF7\u3063\u3066\u308B\u3002\uFF11\uFF13\u304B\u3089\uFF11\uFF17:\uFF13\uFF10\u306F\u5BDD\u904E\u304E\u3060\u3063\u305F\u3002",
  "id" : 70871626685755392,
  "in_reply_to_status_id" : 70871094717972480,
  "created_at" : "2011-05-18 15:21:27 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70871427548577792",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 70871427548577792,
  "created_at" : "2011-05-18 15:20:39 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70870810528722945",
  "text" : "\u30AB\u30A4\u30B8\u3080\u3063\u3061\u3083\u826F\u3044\u6240\u3067\u5207\u308B\u306A\u3041\u3002\u77E5\u3063\u3066\u3066\u3082\u30C9\u30AD\u30C9\u30AD\u3059\u308B\u30EC\u30D9\u30EB\u3002",
  "id" : 70870810528722945,
  "created_at" : "2011-05-18 15:18:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E9\u30A4\u30D6\u30C9\u30A2\u30CB\u30E5\u30FC\u30B9",
      "screen_name" : "livedoornews",
      "indices" : [ 120, 133 ],
      "id_str" : "17306975",
      "id" : 17306975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/GnDBVlp",
      "expanded_url" : "http:\/\/news.livedoor.com\/article\/detail\/5567751\/",
      "display_url" : "news.livedoor.com\/article\/detail\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "70864874393182208",
  "text" : "\u3053\u308C\u306F\u3046\u308C\u3057\u3044\u3002\u5E30\u7701\u3059\u308B\u305F\u3073\u6301\u3061\u66FF\u3048\u3066\u308B\u304B\u3089\u3081\u3093\u3069\u304F\u3055\u3044\u3063\u305F\u3089\u306A\u3044\u3002\u3057\u304B\u3082\u95A2\u897F\u306E\u79C1\u9244\u306FICOCA\u4F7F\u3048\u306A\u304B\u3063\u305F\u304B\u3089\u305D\u308C\u3082\u6539\u5584\u3055\u308C\u308B\u306A\u3089\u30DE\u30B8GJ \uFF29\uFF23\u4E57\u8ECA\u5238\u3001\uFF11\uFF13\u5E74\u6625\u76F8\u4E92\u5229\u7528\u3078 \uFF2A\uFF32\u3001\u79C1\u9244\u304C\u5408\u610F http:\/\/t.co\/GnDBVlp via @livedoornews",
  "id" : 70864874393182208,
  "created_at" : "2011-05-18 14:54:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70863126798663680",
  "text" : "\u5E30\u5B85\u3002\u3042\u30FC\u663C\u5BDD\u3057\u3059\u304E\u3066\u7720\u304F\u306A\u3044\u2026\u8AB2\u984C\u3092\u3084\u308B\u306E\u306F\u78BA\u5B9A\u3068\u3057\u3066\u9069\u5F53\u306B\u5207\u308A\u4E0A\u3052\u3066\u7121\u7406\u77E2\u7406\u5BDD\u308B\u306E\u304B\u3001\u306F\u305F\u307E\u305F\u5FB9\u591C\u3059\u308B\u306E\u304B\u2026\u3002",
  "id" : 70863126798663680,
  "created_at" : "2011-05-18 14:47:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70776758470848512",
  "text" : "\u30D0\u30A4\u30C8\u524D\u306B\u304A\u5915\u98EF\u98DF\u3079\u308B\u6642\u9593\u3042\u308B\u304B\u306A\u2026\u3002\u3066\u304B\u3054\u98EF\u708A\u304F\u306E\u9593\u306B\u5408\u3046\u304B\u306A\u3002\u3002",
  "id" : 70776758470848512,
  "created_at" : "2011-05-18 09:04:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70771403393204224",
  "text" : "\u3042\u30FC\u5F53\u7136\u306E\u3088\u3046\u306B\u5BDD\u904E\u304E\u305F\u3002\u663C\u5BDD\u2026",
  "id" : 70771403393204224,
  "created_at" : "2011-05-18 08:43:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70652109762199552",
  "text" : "\u304A\u8179\u2026\u6E1B\u3063\u305F\u306A\u3002",
  "id" : 70652109762199552,
  "created_at" : "2011-05-18 00:49:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70637312022822912",
  "geo" : { },
  "id_str" : "70647993996546048",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u7D71\u8A08\u3084\u308B\u306E\uFF1F",
  "id" : 70647993996546048,
  "in_reply_to_status_id" : 70637312022822912,
  "created_at" : "2011-05-18 00:32:49 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70549535566462976",
  "text" : "\u5BDD\u306A\u304F\u3061\u3083\u3002\u4E00\u56DE\u898B\u305F\u56DE\u306A\u306E\u306B\u7D50\u5C40\u3042\u306E\u82B1\u307E\u3067\u898B\u3066\u3057\u307E\u3063\u305F\u3002\u304A\u3084\u3059\u307F\u3002",
  "id" : 70549535566462976,
  "created_at" : "2011-05-17 18:01:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70538805991587840",
  "geo" : { },
  "id_str" : "70539517978877952",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u672C\u306F\u8ABF\u3079\u3066\u81EA\u5206\u3067\u5B9F\u7269\u898B\u3066\u6C7A\u3081\u305F\u65B9\u304C\u3044\u3044\u3068\u601D\u3044\u307E\u3059\u3088\u30FC\u3002\u305D\u3082\u305D\u3082C\u3067\u3042\u308B\u5FC5\u8981\u3082\u306A\u3044\u3067\u3059\u3057\u3002\u7814\u7A76\u5BA4\u3067\u4F7F\u3044\u3084\u3059\u3044\u8A00\u8A9E\u306E\u65B9\u304C\u3044\u3044\u3067\u3059\u3002FORTRAN\u3068\u304B\u3002",
  "id" : 70539517978877952,
  "in_reply_to_status_id" : 70538805991587840,
  "created_at" : "2011-05-17 17:21:46 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70537376564383744",
  "geo" : { },
  "id_str" : "70537775786635265",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u672C\u8CB7\u3063\u3066\u52DD\u624B\u306B\u3084\u3063\u3066\u308B\u306E\u3068\u4E00\u822C\u6559\u990A\u3067\u6388\u696D\u53D6\u3063\u305F\u306E\u3067\u4E26\u884C\u3057\u3066\u3084\u3063\u3066\u308B\u611F\u3058\u3067\u3059\u306D\u30FC\u3002\u52D5\u304F\u3068\u9762\u767D\u3044\u3067\u3059\u3088\u3002\u6570\u5024\u8A08\u7B97\u3082\u7D44\u3081\u308B\u3068\u4FBF\u5229\u3067\u3059\u3088\u3002",
  "id" : 70537775786635265,
  "in_reply_to_status_id" : 70537376564383744,
  "created_at" : "2011-05-17 17:14:50 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70536191090499585",
  "geo" : { },
  "id_str" : "70536817518194689",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3044\u3084\u3001C\u3067\u3059\u306D\u3002HTML\u3068\u304BJava\u3068\u304BPHP\u306FC\u4E00\u901A\u308A\u3084\u3063\u3066\u304B\u3089\u5FC5\u8981\u306A\u3089\u3084\u308D\u3046\u304B\u3068\u3002",
  "id" : 70536817518194689,
  "in_reply_to_status_id" : 70536191090499585,
  "created_at" : "2011-05-17 17:11:02 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70535732837625856",
  "text" : "\u8208\u9192\u3081\u3060\u306A\u30FC\u3001\u6D41\u3057\u3063\u3071\u306B\u3057\u3066\u304A\u304F\u3051\u3069\u3002",
  "id" : 70535732837625856,
  "created_at" : "2011-05-17 17:06:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70535625425698816",
  "text" : "\u3066\u304BC\u306F\u3058\u307E\u3063\u305F\u3051\u3069\u3053\u308C\u898B\u305F\u3053\u3068\u3042\u308B\u3002\u30CD\u30C3\u30C8\u4E0A\u306B\u4E0A\u304C\u3063\u3066\u3093\u306E\u304C\u3053\u3063\u3061\u3067\u306F\u6765\u9031\u5206\u306A\u306E\u304B\u3002",
  "id" : 70535625425698816,
  "created_at" : "2011-05-17 17:06:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70531132495638528",
  "geo" : { },
  "id_str" : "70535493867147266",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u307E\u3060\u305D\u3093\u306A\u30EC\u30D9\u30EB\u3058\u3083\u306A\u3044\u3067\u3059\u3051\u3069\u306D\u30FC\u3002\u4E00\u5FDC\u77E5\u8B58\u3068\u3057\u3066\u3002",
  "id" : 70535493867147266,
  "in_reply_to_status_id" : 70531132495638528,
  "created_at" : "2011-05-17 17:05:46 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70528894683459584",
  "text" : "@mo5nya \u307E\u3041\u4E88\u9632\u7DDA\u3068\u8A00\u3046\u304B\u5FC3\u306E\u9632\u885B\u672C\u80FD\u307F\u305F\u3044\u306A\u3068\u3053\u308D\u304C\u3042\u308B\u3093\u3067\u3057\u3087\u3046\u3051\u3069\u306D\u30FC\u3002\u307E\u3041\u4E00\u7A2E\u306E\u3042\u308B\u3042\u308B\u3067\u3059\u3002",
  "id" : 70528894683459584,
  "created_at" : "2011-05-17 16:39:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70526789209964544",
  "geo" : { },
  "id_str" : "70527356409872384",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u597D\u304D\u306A\u3053\u3068\u3084\u3063\u3066\uFF08\u306A\u305C\u304B\uFF09\u5A01\u5F35\u3063\u3066\u3093\u3060\u3057\u653E\u7F6E\u3057\u3066\u304A\u3051\u3070\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u306A\u3001\u7A0B\u5EA6\u306E\u8A8D\u8B58\u3002",
  "id" : 70527356409872384,
  "in_reply_to_status_id" : 70526789209964544,
  "created_at" : "2011-05-17 16:33:26 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70526374695276544",
  "text" : "\u8AB2\u984C\u3068\u3044\u3044\u3064\u3064\u30D5\u30E9\u30F3\u30B9\u8A9E\u3084\u3089\u82F1\u8A9E\u3084\u3089\u3084\u308C\u3070\u52B9\u7387\u826F\u3044\u306E\u306B\u3042\u3048\u3066\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u3092\u9078\u3076\u2026\u5207\u7FBD\u8A70\u307E\u308C\u3070\u304D\u3063\u3068\u3084\u308B\u3060\u308D\u3046\u3002\u305B\u3063\u304B\u304F\u6642\u9593\u3042\u308B\u3093\u3060\u304B\u3089\u3084\u308B\u3079\u304D\u3053\u3068\u3058\u3083\u306A\u3044\u3053\u3068\u304B\u3089\u3084\u3063\u305F\u65B9\u304C\u7D50\u5C40\u306F\u6642\u9593\u3092\u6709\u52B9\u6D3B\u7528\u3067\u304D\u308B\u2026\u6C17\u304C\u3059\u308B\u3002",
  "id" : 70526374695276544,
  "created_at" : "2011-05-17 16:29:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70525698921603072",
  "text" : "\u6B32\u5F35\u308A\u3068\u3044\u3048\u3070\u6B32\u5F35\u308A\u304B\u2026\u3002",
  "id" : 70525698921603072,
  "created_at" : "2011-05-17 16:26:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70525606869217280",
  "text" : "\u300C\u25CB\u25CB\u3084\u3063\u3066\u308B\u306E\uFF1F\u300D\u300C\u3046\u3093\u3001\u6B63\u76F4\u5F15\u304F\u30EC\u30D9\u30EB\u3060\u3088\uFF08\u3069\u3046\u305B\u304A\u524D\u308F\u304B\u3093\u306A\u3044\u3060\u308D\uFF09\u300D\u300C\u3042\u30FC\u00D7\u00D7\u3068\u304B\u3057\u3061\u3083\u3046\u611F\u3058\uFF1F\u300D\u300C\u305D\u3046\u305D\u3046\uFF01\uFF08\u3053\u306E\u4EBA\u89E3\u308B\uFF01\uFF09\u300D\u307F\u305F\u3044\u306A\u306E\u304C\u7406\u60F3\u3002\u3069\u3093\u306A\u8A71\u306B\u3082\u3064\u3044\u3066\u3044\u304D\u305F\u3044\u3002",
  "id" : 70525606869217280,
  "created_at" : "2011-05-17 16:26:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70525150247919616",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u300C\u3061\u3087\u3063\u3068\u5F15\u304F\u3068\u601D\u3046\u3093\u3060\u3051\u3069\u3055\u30FC\u300D\u304B\u3089\u59CB\u307E\u308B\u8A71\u3067\u5F15\u3044\u305F\u305F\u3081\u3057\u304C\u306A\u3044\u3002",
  "id" : 70525150247919616,
  "created_at" : "2011-05-17 16:24:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70521859694788609",
  "text" : "\u4ECA\u65E5\u306F\uFF12\u9650\u7D42\u308F\u3063\u305F\u5F8C\u5E30\u3063\u3066\u304D\u3066\u30AC\u30C3\u30C4\u30EA\u663C\u5BDD\u3067\u304D\u308B\u3057\uFF01",
  "id" : 70521859694788609,
  "created_at" : "2011-05-17 16:11:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70521739272142849",
  "text" : "\u3084\u3063\u3071\u8AB2\u984C\u3084\u308A\u306A\u304C\u3089C\u59CB\u307E\u308B\u306E\u5F85\u3064\u304B\u306A\u3002",
  "id" : 70521739272142849,
  "created_at" : "2011-05-17 16:11:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70513500845391873",
  "geo" : { },
  "id_str" : "70513755955531778",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji PC\u3060\u3068\u81EA\u7136\u306B\u5F35\u308A\u4ED8\u3044\u3066\u3044\u3089\u308C\u308B\u304B\u3089\u306D\u30FC\u3002\u5373\u30EC\u30B9\u4F59\u88D5\u308C\u3059\u3002",
  "id" : 70513755955531778,
  "in_reply_to_status_id" : 70513500845391873,
  "created_at" : "2011-05-17 15:39:24 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70513015925112832",
  "geo" : { },
  "id_str" : "70513374059954176",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u659C\u3081\u4E03\u5341\u4E03\u5EA6\u306E\u4E26\u3073\u3067\u6CE3\u304F\u6CE3\u304F\u5636\u304F\uFF08\u3044\u306A\u306A\u304F\uFF09\u30CA\u30CA\u30CF\u30F3\u4E03\u53F0\u96E3\u306A\u304F\u4E26\u3079\u3066\u9577\u773A\u3081\u3002\u3068\u3044\u3046\u65E9\u53E3\u8A00\u8449\u304C\u3042\u308B\u3002",
  "id" : 70513374059954176,
  "in_reply_to_status_id" : 70513015925112832,
  "created_at" : "2011-05-17 15:37:53 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70512768704454656",
  "geo" : { },
  "id_str" : "70512937105752065",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u305D\u3053\u306B\u6C17\u4ED8\u304F\u3068\u306F\u2026\u3084\u306F\u308A\u5929\u624D\u304B\u3002",
  "id" : 70512937105752065,
  "in_reply_to_status_id" : 70512768704454656,
  "created_at" : "2011-05-17 15:36:08 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 0, 15 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70510775743160320",
  "geo" : { },
  "id_str" : "70511070950866944",
  "in_reply_to_user_id" : 227502200,
  "text" : "@G4_Hirano_chan \u307E\u3060\u5BDD\u306A\u3044\u3088\uFF01",
  "id" : 70511070950866944,
  "in_reply_to_status_id" : 70510775743160320,
  "created_at" : "2011-05-17 15:28:44 +0000",
  "in_reply_to_screen_name" : "G4_Hirano_chan",
  "in_reply_to_user_id_str" : "227502200",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70510981306007552",
  "text" : "\u4F55\u3057\u308D\u4E8C\u9650\u3057\u304B\u306A\u3044\u304B\u3089\u3001\u4E8C\u9650\u884C\u304D\u640D\u306D\u305F\u3089\u2026",
  "id" : 70510981306007552,
  "created_at" : "2011-05-17 15:28:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70510673272115201",
  "text" : "\u3053\u306E\u307E\u307EC\u3068\u3042\u306E\u82B1\u30EA\u30A2\u30EB\u30BF\u30A4\u30E0\u3067\u898B\u308B\u306E\u3082\u6709\u308A\u306A\u306E\u304B\u306A\u2026\u5BDD\u308B\u306E\u306F\uFF13\u6642\u306B\u306A\u308B\u3051\u3069\u3001\u4ECA\u65E5\u8D77\u304D\u308C\u306A\u304B\u3063\u305F\u3089\u60E8\u4E8B\u3060\u306A\u3002",
  "id" : 70510673272115201,
  "created_at" : "2011-05-17 15:27:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70507984886829058",
  "text" : "\u3082\u3046\u65E5\u4ED8\u5909\u3063\u3066\u3057\u307E\u3063\u3066\u3044\u308B\u2026\u3002",
  "id" : 70507984886829058,
  "created_at" : "2011-05-17 15:16:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70507579704479744",
  "text" : "\u5E30\u5B85\u30A1 \u30B5\u30FC\u30AF\u30EB\u3088\u308A\u558B\u3063\u3066\u308B\u6642\u9593\u306E\u65B9\u304C\u9577\u3044\u3068\u3044\u3046\u3002",
  "id" : 70507579704479744,
  "created_at" : "2011-05-17 15:14:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70366615383969792",
  "text" : "@np2i \uFF30\uFF23\u306F\u4E0A\u4F4D\u4E92\u63DB\u3067\u3059\u3057\u5225\u306B\u826F\u3044\u306E\u3067\u306F\uFF1F\u50D5\u306F\u30D7\u30ED\u30B0\u30E9\u30E0\u306E\u691C\u7B97\u7528\u306B\u6301\u3063\u3066\u308B\u672C\u672B\u8EE2\u5012\u3067\u3059\u304C",
  "id" : 70366615383969792,
  "created_at" : "2011-05-17 05:54:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inu_mof",
      "screen_name" : "inu_mof",
      "indices" : [ 3, 11 ],
      "id_str" : "3179260070",
      "id" : 3179260070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70364039615758336",
  "text" : "RT @inu_mof: \u300C\u3042\uFF5E\u3093\u3001\u79C1\u304A\u5869\u98DF\u3079\u3089\u308C\u306A\u3044\u3093\u3067\u3059\u3088\u3049\u3002\u300D\u300C\u2026\u2026\u3060\u3063\u3066\u3001\u2026\u2026\u3060\u3063\u3066\u3001\u304A\u5869\u98DF\u3079\u305F\u3089\u96FB\u96E2\u3057\u3061\u3083\u3046\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u3041\u3063\uFF01Na\u3068Cl\u304B\u308F\u3044\u305D\u3046\u3067\u3059\u3045\uFF01\u305B\u3063\u304B\u304F\u4EF2\u826F\u304F\u30A4\u30AA\u30F3\u7D50\u5408\u3057\u3066\u308B\u306E\u306B\u3043\u3043\uFF5E\uFF08\u60B2\uFF09\u3002\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70344281264635904",
    "text" : "\u300C\u3042\uFF5E\u3093\u3001\u79C1\u304A\u5869\u98DF\u3079\u3089\u308C\u306A\u3044\u3093\u3067\u3059\u3088\u3049\u3002\u300D\u300C\u2026\u2026\u3060\u3063\u3066\u3001\u2026\u2026\u3060\u3063\u3066\u3001\u304A\u5869\u98DF\u3079\u305F\u3089\u96FB\u96E2\u3057\u3061\u3083\u3046\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u3041\u3063\uFF01Na\u3068Cl\u304B\u308F\u3044\u305D\u3046\u3067\u3059\u3045\uFF01\u305B\u3063\u304B\u304F\u4EF2\u826F\u304F\u30A4\u30AA\u30F3\u7D50\u5408\u3057\u3066\u308B\u306E\u306B\u3043\u3043\uFF5E\uFF08\u60B2\uFF09\u3002\u300D",
    "id" : 70344281264635904,
    "created_at" : "2011-05-17 04:25:58 +0000",
    "user" : {
      "name" : "\u0E05\u055E\u2022\uFECC\u2022\u055E\u0E05\uFF08\u304A\u5BFF\u53F8\u3082\u3075\u5B50\uFF09",
      "screen_name" : "inu_to_gohan",
      "protected" : false,
      "id_str" : "85490527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1552791269\/___________normal.jpg",
      "id" : 85490527,
      "verified" : false
    }
  },
  "id" : 70364039615758336,
  "created_at" : "2011-05-17 05:44:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70363960259526656",
  "text" : "\u3048\u3001\u5927\u5B66\u751F\u3063\u3066\u95A2\u6570\u96FB\u5353\u5E38\u643A\u3059\u308B\u3082\u3093\u3058\u3083\u306A\u3044\u306E\uFF1B\uFF1B",
  "id" : 70363960259526656,
  "created_at" : "2011-05-17 05:44:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70361759973773313",
  "text" : "\u305D\u308D\u305D\u308D\u9589\u3058\u3066\u6388\u696D\u306B\u3080\u304B\u304A\u3046\u304B\u306A\u3001\u958B\u304D\u3063\u3071\u3067\u53D7\u3051\u3066\u3082\u304D\u3063\u3068\u4F55\u3082\u8A00\u308F\u308C\u306A\u3044\u3051\u3069\u5145\u96FB\u98DF\u3046\u3057\u3001\u3042\u3068\u3067\u30EA\u30B9\u30CB\u30F3\u30B0\u3084\u3089\u306A\u304F\u3061\u3083\u3002",
  "id" : 70361759973773313,
  "created_at" : "2011-05-17 05:35:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70361498391814144",
  "text" : "\u826F\u304F\u8A00\u3048\u3070\u77E5\u8B58\u4EBA\u3060\u3051\u3069\u3001\u60AA\u304F\u8A00\u3048\u3070\u5668\u7528\u8CA7\u4E4F\u3060\u3088\u306A\u3041\u3002\u3044\u305A\u308C\u306B\u3057\u3066\u3082\u6587\u7406\u306E\u5883\u754C\u306A\u3093\u3066\u4E00\u5207\u6C17\u306B\u3057\u306A\u3044\u3002\u6B63\u76F4\u5316\u5B66\u3082\u3084\u308A\u305F\u3044\u3002",
  "id" : 70361498391814144,
  "created_at" : "2011-05-17 05:34:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70361160779694080",
  "text" : "\u81EA\u3089\u5668\u7528\u8CA7\u4E4F\u306B\u306A\u308D\u3046\u3068\u3057\u3066\u3044\u308B\u2026\u3082\u3061\u308D\u3093\u5C02\u653B\u306F\u304D\u3061\u3093\u3068\u3084\u308B\u3064\u3082\u308A\u3067\u3044\u308B\u304C\u2026\u3002",
  "id" : 70361160779694080,
  "created_at" : "2011-05-17 05:33:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70360865181937664",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u6700\u8FD1\u3001\u4E00\u756A\u51FA\u6765\u308B\u4EBA\u306B\u306A\u308B\u306E\u306F\u96E3\u3057\u305D\u3046\u3060\u304B\u3089\u3042\u308B\u7A0B\u5EA6\u4EE5\u4E0A\u306E\u30EC\u30D9\u30EB\u3067\u3069\u3093\u306A\u8A71\u3082\u51FA\u6765\u308B\u4EBA\u306B\u306A\u308A\u305F\u3044\u3068\u601D\u3046\u3088\u3046\u306B\u306A\u3063\u305F\u3002",
  "id" : 70360865181937664,
  "created_at" : "2011-05-17 05:31:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70360632188346368",
  "text" : "\u8C61\u5FB4\u7684\u306A\u60C5\u666F\u3002\u672C\u8AAD\u3080\u306E\u3082\u3082\u3061\u308D\u3093\u597D\u304D\u3060\u3051\u308C\u3069\u771F\u306B\u597D\u304D\u306A\u4EBA\u307B\u3069\u3058\u3083\u306A\u3044\u3093\u3060\u308D\u3046\u306A\u3002\u4E0A\u306B\u306F\u4E0A\u304C\u3044\u308B\u3002",
  "id" : 70360632188346368,
  "created_at" : "2011-05-17 05:30:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70360362872082432",
  "text" : "\u4E8C\u968E\u306E\u30BD\u30D5\u30A1\u304C\u3042\u308B\u3068\u3053\u308D\u306B\u3044\u308B\u304C\u3001\u5468\u308A\u306B\u3044\u308B\u4EBA\u306F\u307F\u3093\u306A\u672C\u3092\u8AAD\u3093\u3067\u3044\u3089\u3063\u3057\u3083\u308B\u3002PC\u5F04\u3063\u3066\u308B\u79C1\u306F\u3044\u308D\u3093\u306A\u610F\u5473\u3067\u304A\u4F3C\u5408\u3044\u3067\u3057\u3087\u3046\u3002",
  "id" : 70360362872082432,
  "created_at" : "2011-05-17 05:29:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70359498816106497",
  "text" : "\u3066\u304B\u6587\u5B66\u90E8\u4E8C\u968E\u306F\u96FB\u6CE2\u304C\u3044\u3044\u306A\u3002\u4E00\u56DE\u3082\u3053\u306E\u304F\u3089\u3044\u306B\u306A\u3063\u3066\u307B\u3057\u3044\u306A\u3002",
  "id" : 70359498816106497,
  "created_at" : "2011-05-17 05:26:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70359309254533120",
  "text" : "\u3053\u306E\u6642\u9593\u3060\u304B\u3089\u5F53\u7136\u304B\u306A\u3001TL\u304C\u3059\u3053\u3076\u308B\u304A\u3068\u306A\u3057\u3044\u3002",
  "id" : 70359309254533120,
  "created_at" : "2011-05-17 05:25:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70357757735354368",
  "text" : "\u306A\u305C\u52D5\u3044\u305F\u306E\u304B\u5206\u304B\u3089\u306A\u3044\u3063\u3066\u306E\u304C\u4E0D\u5473\u3044\u3093\u3060\u3051\u3069\u2026",
  "id" : 70357757735354368,
  "created_at" : "2011-05-17 05:19:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70357645026000896",
  "text" : "\u306A\u305C\u52D5\u3044\u305F\u306E\u304B\u89E3\u304B\u3089\u306A\u3044\u3051\u308C\u3069\u30CB\u30E5\u30FC\u30C8\u30F3\u6CD5\u306E\u30D7\u30ED\u30B0\u30E9\u30E0\u304C\u306C\u308B\u306C\u308B\u52D5\u3044\u305F\uFF01\u95A2\u6570\u96FB\u5353\u3067\u691C\u7B97\u3057\u305F\u3051\u3069\u5927\u4F53\u3042\u3063\u3066\u308B\u3002\u3055\u3055\u3084\u304B\u306A\u5E78\u305B\u3002",
  "id" : 70357645026000896,
  "created_at" : "2011-05-17 05:19:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70350112332845056",
  "text" : "\u97F3\u697D\u8074\u304F\u306E\u3084\u3081\u305F\u307F\u305F\u3044\u3002\u643A\u5E2F\u898B\u3066\u306A\u3044\u304B\u3089\u3053\u306E\u3064\u3076\u3084\u304D\u3068\u306F\u7121\u95A2\u4FC2\u306E\u306F\u305A\u3002",
  "id" : 70350112332845056,
  "created_at" : "2011-05-17 04:49:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70349567601815555",
  "text" : "\u306A\u3093\u3067\u4ED6\u4EBA\u306E\u97F3\u6D29\u308C\u5B9F\u6CC1\u3057\u3066\u3093\u3060\u308D\u2026",
  "id" : 70349567601815555,
  "created_at" : "2011-05-17 04:46:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70349395102674944",
  "text" : "\u97F3\u6D29\u308C\u2026\u7A7A\u3082\u98DB\u3079\u308B\u306F\u305A\u3060\u3063\u305F\u306E\u306B\u98DB\u3070\u3055\u308C\u305F\u3002\u7A7A\u3082\u98DB\u3070\u3055\u308C\u308B\u306F\u305A\u3002",
  "id" : 70349395102674944,
  "created_at" : "2011-05-17 04:46:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70349138226716673",
  "text" : "\u30E9\u30A6\u30F3\u30B8\u306E\u97F3\u3001\u30E9\u30A6\u30F3\u30B8\u30CE\u30FC\u30C8\u3002\u4E88\u6E2C\u5909\u63DB\u3067\u30E9\u30A6\u30F3\u30B8\u30EA\u30B6\u30FC\u30C9\u3063\u3066\u3042\u308B\u3051\u3069\u4E00\u4F53\u306A\u3093\u306A\u306E\u3060\u308D\u3046\u3002",
  "id" : 70349138226716673,
  "created_at" : "2011-05-17 04:45:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70348913734983680",
  "text" : "\u3082\u3046\u3061\u3087\u3063\u3068\u3067\u6B4C\u8A5E\u805E\u304D\u53D6\u308C\u308B\u30EC\u30D9\u30EB\u306E\u97F3\u6D29\u308C\u3002\u76F4\u3061\u306B\u4EBA\u4F53\u306B\u5F71\u97FF\u306F\u306A\u3044\u3002",
  "id" : 70348913734983680,
  "created_at" : "2011-05-17 04:44:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70348729810554880",
  "text" : "\u30E9\u30A6\u30F3\u30B8\u30CE\u30FC\u30C8\u6FC0\u3057\u3044\u306A\u3002",
  "id" : 70348729810554880,
  "created_at" : "2011-05-17 04:43:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70348127013576704",
  "text" : "\u6674\u308C\u9593\u304C\u898B\u3048\u3066\u6765\u305F\u3051\u3069\u2026\u30DB\u30F3\u30C8\u306B\u3059\u3050\u6B62\u3093\u3060\u306A\u3041\u3002\u30AB\u30DF\u30CA\u30EA\u306F\u307E\u3060\u3061\u3089\u307B\u3089\u3002",
  "id" : 70348127013576704,
  "created_at" : "2011-05-17 04:41:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I",
      "screen_name" : "mearythindong",
      "indices" : [ 0, 14 ],
      "id_str" : "115541150",
      "id" : 115541150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70347640533037056",
  "geo" : { },
  "id_str" : "70347911338270722",
  "in_reply_to_user_id" : 115541150,
  "text" : "@mearythindong \u306A\u3093\u304B\u3059\u3054\u3044\u964D\u3063\u3066\u307E\u3057\u305F\u306D\u3002\u98A8\u90AA\u3072\u304B\u306A\u3044\u3068\u3044\u3044\u3067\u3059\u304C\u3002",
  "id" : 70347911338270722,
  "in_reply_to_status_id" : 70347640533037056,
  "created_at" : "2011-05-17 04:40:23 +0000",
  "in_reply_to_screen_name" : "mearythindong",
  "in_reply_to_user_id_str" : "115541150",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70347723794157568",
  "text" : "\u30B9\u30C8\u30FC\u30F3\u3063\u3066\u8981\u306F\u77F3\u3060\u3088\u306D\u3002",
  "id" : 70347723794157568,
  "created_at" : "2011-05-17 04:39:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 6, 16 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70346859675262979",
  "text" : "\u6C37\u584A RT @end313124: \u30B9\u30D7\u30FC\u30F3\u3063\u3066\u6C37\u89E3\u7815\u304F\u306E\u306B\u4FBF\u5229\u3088\u306D\u3002\u4F5C\u7528\u70B9\uFF08\uFF1F)\u304C\u5C0F\u3055\u3044\u304B\u3089\u7269\u7406\u7684\u306B\u5411\u3044\u3066\u308B\u3089\u3057\u3044\u3002",
  "id" : 70346859675262979,
  "created_at" : "2011-05-17 04:36:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70346655945326593",
  "text" : "\u30B9\u30D7\u30FC\u30F3\u3063\u3066\u6C37\u89E3\u7815\u304F\u306E\u306B\u4FBF\u5229\u3088\u306D\u3002\u4F5C\u7528\u70B9\uFF08\uFF1F)\u304C\u5C0F\u3055\u3044\u304B\u3089\u7269\u7406\u7684\u306B\u5411\u3044\u3066\u308B\u3089\u3057\u3044\u3002",
  "id" : 70346655945326593,
  "created_at" : "2011-05-17 04:35:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70346406635896832",
  "text" : "\u30B9\u30B3\u30FC\u30F3\u3063\u3066\u7F8E\u5473\u3057\u3044\u3088\u306D",
  "id" : 70346406635896832,
  "created_at" : "2011-05-17 04:34:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70346323429306369",
  "text" : "@ayu167 \u305D\u3063\u3061\u3082\uFF1F\uFF01",
  "id" : 70346323429306369,
  "created_at" : "2011-05-17 04:34:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70346244790304768",
  "text" : "\u30B9\u30B3\u30FC\u30EB\u3059\u3054\u30FC\u3044",
  "id" : 70346244790304768,
  "created_at" : "2011-05-17 04:33:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70346050606604289",
  "text" : "\u5358\u4F4D\u3069\u3053\u308D\u304B\u51FA\u9858\u3067\u304D\u306A\u3044\u30EC\u30D9\u30EB",
  "id" : 70346050606604289,
  "created_at" : "2011-05-17 04:33:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70345700545789953",
  "text" : "\u30B9\u30B3\u30FC\u30EB\uFF01\uFF01",
  "id" : 70345700545789953,
  "created_at" : "2011-05-17 04:31:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70324831765270529",
  "text" : "\u3042\u30FC\u3001\u304B\u3070\u3093\u91CD\u3044\u304B\u3089\u6587\u5B66\u90E8\u304B\u3089\u51FA\u305F\u304F\u306A\u3044\u2026\u3067\u3082\u7A7A\u8179\u3002",
  "id" : 70324831765270529,
  "created_at" : "2011-05-17 03:08:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70300022922682368",
  "text" : "\u4E45\u3005\u306B\u3053\u306E\u6388\u696D\u306B\u51FA\u305F\u6C17\u304C\u3059\u308B\u3002\u5148\u9031\u306E\u5BDD\u574A\u3068Gw\u304B\u3001\u7D0D\u5F97\u3002",
  "id" : 70300022922682368,
  "created_at" : "2011-05-17 01:30:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70299061508521984",
  "text" : "\u79C1\u305F\u3061\u4F55\u304B\u5927\u4E8B\u306A\u3053\u3068\u3092\u5FD8\u308C\u3066\u3044\u308B\u6C17\u304C\u3059\u308B\uFF08\u30D9\u30BF)",
  "id" : 70299061508521984,
  "created_at" : "2011-05-17 01:26:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70297594601021440",
  "text" : "\u306A\u3093\u304B\u5E78\u305B\u306A\u5922\u3092\u898B\u305F\u3088\u3046\u306A\u6C17\u304C\u3059\u308B\u2026\u4F55\u304B\u2026",
  "id" : 70297594601021440,
  "created_at" : "2011-05-17 01:20:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70282346275938304",
  "text" : "\u304A\u306F\u3088\u3046\u3002\u96E8\u964D\u308B\u306A\u3089\u304B\u3070\u3093\u8003\u3048\u306A\u3044\u3068\u306A\u2026\u3002",
  "id" : 70282346275938304,
  "created_at" : "2011-05-17 00:19:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70164083650998273",
  "text" : "\u5BDD\u308B\u304B\u306A\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 70164083650998273,
  "created_at" : "2011-05-16 16:29:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70142462039031808",
  "text" : "\uFF08\u3042\u308C\u3001\u3053\u308C\u6BCE\u9031\u8A00\u3063\u3066\u308B\u6C17\u304C\u3059\u308B\u2026\uFF09",
  "id" : 70142462039031808,
  "created_at" : "2011-05-16 15:04:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70142356493578245",
  "text" : "\u4ECA\u65E5\u3082\u30CE\u30FC\u30C8PC\u3082\u3063\u3066\u3063\u3066call\u306ECD\u805E\u3053\u3046\u3002\uFF17\u9650\u3068\u304B\u9045\u3059\u304E\u2026\u307B\u3068\u3093\u3069\u30B5\u30FC\u30AF\u30EB\u3044\u3051\u306A\u3044\u3057\u2026\u3002\uFF15\u9650\u306E\u30D5\u30E9\u8A9E\u306F\uFF13\u9650\u3068\u663C\u4F11\u307F\u306B\u672C\u6C17\u51FA\u3059\u3002",
  "id" : 70142356493578245,
  "created_at" : "2011-05-16 15:03:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70141966918230016",
  "text" : "\u30CE\u30FC\u30C8PC \u30C7\u30B9\u30AF\u30C8\u30C3\u30D7PC ipod \u643A\u5E2F\u30FB\u30FB\u30FB\u3069\u308C\u3067\u3082\u30C4\u30A4\u30C3\u30BF\u30FC\u898B\u308B\u3051\u3069\u7D76\u5BFE\u96FB\u6C17\u306E\u7121\u99C4\u4F7F\u3044\u3002",
  "id" : 70141966918230016,
  "created_at" : "2011-05-16 15:02:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70138442692034561",
  "text" : "@mo5nya \u62D2\u7D76\u53CD\u5FDC\u304C\u51FA\u306A\u304F\u306A\u3063\u305F\u3089\u697D\u3057\u304F\u306A\u308A\u307E\u3059\uFF01\u304D\u3063\u3068\u3002\u308F\u304B\u3089\u306A\u3044\u4E8B\u304C\u3042\u3063\u305F\u3089\u9060\u616E\u306A\u304F\u3069\u3046\u305E\u30FC\u3002",
  "id" : 70138442692034561,
  "created_at" : "2011-05-16 14:48:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70133619447959552",
  "text" : "\u7720\u3044\u3002\u3002\u3002\u3067\u3082\u4ECA\u304B\u3089\u30EA\u30B9\u30CB\u30F3\u30B0\u3084\u308B\u3002\uFF11\u6642\u306B\u306F\u5BDD\u305F\u3044\u306A\u2026\u3002",
  "id" : 70133619447959552,
  "created_at" : "2011-05-16 14:28:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B5\u30B6\u30A8Bot",
      "screen_name" : "sazae_f",
      "indices" : [ 3, 11 ],
      "id_str" : "171360306",
      "id" : 171360306
    }, {
      "name" : "\u30B5\u30B6\u30A8Bot",
      "screen_name" : "sazae_f",
      "indices" : [ 123, 131 ],
      "id_str" : "171360306",
      "id" : 171360306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70133496013787138",
  "text" : "RT @sazae_f: \u3042\u3089\uFF01\u30E9\u30B8\u30AA\u30CD\u30FC\u30E0\u604B\u3059\u308B\u30A6\u30B5\u30AE\u3061\u3083\u3093\u3058\u3083\u306A\uFF5E\u3044\uFF01\u305D\u308C\u306F\u5FC3\u304C\u3042\u306A\u305F\u306E\u3053\u3068\u3092\u6025\u304B\u3057\u3066\u8E74\u98DB\u3070\u3057\u3066\u3044\u308B\u304B\u3089\u306D\u3002\u30B7\u30F3\u30D7\u30EB\u306A\u982D\u3067\u805E\u3051\u3070\u3044\u3044\u306E\u3088\uFF1FLet's get to your love\u3067\u3054\u3056\u3044\u307E\uFF5E\u3059\uFF01 RT @abbachun @sazae_f\u30B5\u30B6\u30A8\u3055\uFF5E ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u30B5\u30B6\u30A8Bot",
        "screen_name" : "sazae_f",
        "indices" : [ 110, 118 ],
        "id_str" : "171360306",
        "id" : 171360306
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70091799590473728",
    "text" : "\u3042\u3089\uFF01\u30E9\u30B8\u30AA\u30CD\u30FC\u30E0\u604B\u3059\u308B\u30A6\u30B5\u30AE\u3061\u3083\u3093\u3058\u3083\u306A\uFF5E\u3044\uFF01\u305D\u308C\u306F\u5FC3\u304C\u3042\u306A\u305F\u306E\u3053\u3068\u3092\u6025\u304B\u3057\u3066\u8E74\u98DB\u3070\u3057\u3066\u3044\u308B\u304B\u3089\u306D\u3002\u30B7\u30F3\u30D7\u30EB\u306A\u982D\u3067\u805E\u3051\u3070\u3044\u3044\u306E\u3088\uFF1FLet's get to your love\u3067\u3054\u3056\u3044\u307E\uFF5E\u3059\uFF01 RT @abbachun @sazae_f\u30B5\u30B6\u30A8\u3055\uFF5E\u3093\u7247\u601D\u3044\u3063\u3066\u306A\u3093\u3067\u3053\u3093\u306A\u82E6\u3057\u3044\u306E\uFF5E",
    "id" : 70091799590473728,
    "created_at" : "2011-05-16 11:42:41 +0000",
    "user" : {
      "name" : "\u30B5\u30B6\u30A8Bot",
      "screen_name" : "sazae_f",
      "protected" : false,
      "id_str" : "171360306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602437951910379521\/W3g5s4Hi_normal.jpg",
      "id" : 171360306,
      "verified" : false
    }
  },
  "id" : 70133496013787138,
  "created_at" : "2011-05-16 14:28:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nobokko",
      "screen_name" : "nobokkobot",
      "indices" : [ 3, 14 ],
      "id_str" : "146813353",
      "id" : 146813353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bot",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70100208947691520",
  "text" : "RT @nobokkobot: \u3088\u304F\u5B66\u751F\u306F\u52C9\u5F37\u3059\u308B\u306E\u304C\u4ED5\u4E8B\u3063\u3066\u8A00\u3046\u3051\u3069\u3082\u3057\u305D\u308C\u304C\u672C\u5F53\u3060\u3068\u3057\u305F\u3089\u5E73\u5747\u7684\u306A\u53D7\u9A13\u751F\u306F\u307E\u305A\u9AD8\u6821\u30677\u6642\u9593\u307B\u3069\u52E4\u52D9\u3057\u305D\u306E\u5F8C\u587E\u3084\u81EA\u5B85\u30673\u6642\u9593\u4EE5\u4E0A\u306E\u6301\u3061\u5E30\u308A\u6B8B\u696D\u571F\u65E5\u795D\u65E5\u30825\u6642\u9593\u4EE5\u4E0A\u306E\u4F11\u65E5\u52B4\u50CD\u304C\u3042\u308B\u305F\u3081\u5E74\u9593\u52B4\u50CD\u6642\u9593\u306F3000\u6642\u9593\u3092\u512A\u306B\u8D85\u3048\u3001\u3053\u308C\u306F\u904E\u52B4\u6B7B\u8A8D\u5B9A\u57FA ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/nobokko.blog8.fc2.com\/blog-entry-404.html\" rel=\"nofollow\"\u003E\u306E\u307C\u3063\u3068\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bot",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70037849684185088",
    "text" : "\u3088\u304F\u5B66\u751F\u306F\u52C9\u5F37\u3059\u308B\u306E\u304C\u4ED5\u4E8B\u3063\u3066\u8A00\u3046\u3051\u3069\u3082\u3057\u305D\u308C\u304C\u672C\u5F53\u3060\u3068\u3057\u305F\u3089\u5E73\u5747\u7684\u306A\u53D7\u9A13\u751F\u306F\u307E\u305A\u9AD8\u6821\u30677\u6642\u9593\u307B\u3069\u52E4\u52D9\u3057\u305D\u306E\u5F8C\u587E\u3084\u81EA\u5B85\u30673\u6642\u9593\u4EE5\u4E0A\u306E\u6301\u3061\u5E30\u308A\u6B8B\u696D\u571F\u65E5\u795D\u65E5\u30825\u6642\u9593\u4EE5\u4E0A\u306E\u4F11\u65E5\u52B4\u50CD\u304C\u3042\u308B\u305F\u3081\u5E74\u9593\u52B4\u50CD\u6642\u9593\u306F3000\u6642\u9593\u3092\u512A\u306B\u8D85\u3048\u3001\u3053\u308C\u306F\u904E\u52B4\u6B7B\u8A8D\u5B9A\u57FA\u6E96\u3092\u5927\u5E45\u306B\u4E0A\u56DE\u308B\u6570\u5B57\u3068\u306A\u308B\u3002 #bot",
    "id" : 70037849684185088,
    "created_at" : "2011-05-16 08:08:19 +0000",
    "user" : {
      "name" : "nobokko",
      "screen_name" : "nobokkobot",
      "protected" : false,
      "id_str" : "146813353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1289071379\/nobokkobot_normal.jpg",
      "id" : 146813353,
      "verified" : false
    }
  },
  "id" : 70100208947691520,
  "created_at" : "2011-05-16 12:16:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u539F\u2252\u306B\u305B\u7269\u7406\u5B66\u5F92",
      "screen_name" : "hhara_iwate",
      "indices" : [ 0, 12 ],
      "id_str" : "276105342",
      "id" : 276105342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70075132403646464",
  "geo" : { },
  "id_str" : "70100022787706880",
  "in_reply_to_user_id" : 276105342,
  "text" : "@hhara_iwate \u304A\u5927\u4E8B\u306B\u2026\u3002\u76EE\u306E\u75C5\u6C17\u3092\u8EFD\u8996\u3063\u3066\u306A\u3093\u304B\u30E1\u30BF\u3067\u3059\u306D\u3002",
  "id" : 70100022787706880,
  "in_reply_to_status_id" : 70075132403646464,
  "created_at" : "2011-05-16 12:15:22 +0000",
  "in_reply_to_screen_name" : "hhara_iwate",
  "in_reply_to_user_id_str" : "276105342",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9091\u697D",
      "screen_name" : "pult",
      "indices" : [ 3, 8 ],
      "id_str" : "137344047",
      "id" : 137344047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70099791761260544",
  "text" : "RT @pult: \u8089\u98DF\u7CFB\u7537\u5B50\u3068\u304B\u8349\u98DF\u7CFB\u7537\u5B50\u306A\u3089\u307E\u3060\u308F\u304B\u308B\u3051\u3069\u3001\u305D\u306E\u4E2D\u9593\u306B\u5C5E\u3059\u308B\u306A\u3081\u3089\u304B\u7CFB\u7537\u5B50\u3068\u304B\u3001\u300C\u4E00\u898B\u8349\u98DF\u7CFB\u3063\u307D\u3044\u3051\u3069\u5B9F\u306F\u8089\u98DF\u7CFB\u300D\u306E\u30ED\u30FC\u30EB\u30AD\u30E3\u30D9\u30C4\u7CFB\u7537\u5B50\u3068\u304B\u3001\u300C\u5916\u898B\u306F\u7518\u304F\u30AD\u30E3\u30E9\u306F\u30DC\u30B1\u3088\u308A\u3082\u30BD\u30D5\u30C8\u306A\u30C4\u30C3\u30B3\u30DF\u7CFB\u3067\u5973\u6027\u306E\u304C\u3093\u3070\u308A\u3092\u8A8D\u3081\u308B\u300D\u30AF\u30EA\u30FC\u30DF\u30FC\u7CFB\u7537\u5B50\u3068\u304B\u304A\u524D\u3089\u7537\u5B50\u3092\u4F55\u3060 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69732400707538944",
    "text" : "\u8089\u98DF\u7CFB\u7537\u5B50\u3068\u304B\u8349\u98DF\u7CFB\u7537\u5B50\u306A\u3089\u307E\u3060\u308F\u304B\u308B\u3051\u3069\u3001\u305D\u306E\u4E2D\u9593\u306B\u5C5E\u3059\u308B\u306A\u3081\u3089\u304B\u7CFB\u7537\u5B50\u3068\u304B\u3001\u300C\u4E00\u898B\u8349\u98DF\u7CFB\u3063\u307D\u3044\u3051\u3069\u5B9F\u306F\u8089\u98DF\u7CFB\u300D\u306E\u30ED\u30FC\u30EB\u30AD\u30E3\u30D9\u30C4\u7CFB\u7537\u5B50\u3068\u304B\u3001\u300C\u5916\u898B\u306F\u7518\u304F\u30AD\u30E3\u30E9\u306F\u30DC\u30B1\u3088\u308A\u3082\u30BD\u30D5\u30C8\u306A\u30C4\u30C3\u30B3\u30DF\u7CFB\u3067\u5973\u6027\u306E\u304C\u3093\u3070\u308A\u3092\u8A8D\u3081\u308B\u300D\u30AF\u30EA\u30FC\u30DF\u30FC\u7CFB\u7537\u5B50\u3068\u304B\u304A\u524D\u3089\u7537\u5B50\u3092\u4F55\u3060\u3068\u601D\u3063\u3066\u3093\u3060",
    "id" : 69732400707538944,
    "created_at" : "2011-05-15 11:54:34 +0000",
    "user" : {
      "name" : "\u9091\u697D",
      "screen_name" : "pult",
      "protected" : false,
      "id_str" : "137344047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570748442500317185\/pSStUeIL_normal.jpeg",
      "id" : 137344047,
      "verified" : false
    }
  },
  "id" : 70099791761260544,
  "created_at" : "2011-05-16 12:14:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 0, 15 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70068312691834881",
  "geo" : { },
  "id_str" : "70068732130623488",
  "in_reply_to_user_id" : 227502200,
  "text" : "@G4_Hirano_chan \u304A\u8179\u6E1B\u3063\u305F\u3002",
  "id" : 70068732130623488,
  "in_reply_to_status_id" : 70068312691834881,
  "created_at" : "2011-05-16 10:11:02 +0000",
  "in_reply_to_screen_name" : "G4_Hirano_chan",
  "in_reply_to_user_id_str" : "227502200",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70068095011659776",
  "text" : "\u7A7A\u8179\u2026\u3057\u304B\u305721\u6642\u307E\u3067\u306F\u30D0\u30A4\u30C8\u2026\u3002\u4F55\u304B\u3061\u3087\u30FC\u3063\u3068\u3060\u3051\u80C3\u306B\u5165\u308C\u308B\u304B\u306A\u3041\u3002\u304A\u7C73\u708A\u3044\u3066\u51FA\u308B\u3079\u304D\u3084\u3063\u305F\u306A\u3041\u2026\u3002",
  "id" : 70068095011659776,
  "created_at" : "2011-05-16 10:08:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70065990397997056",
  "text" : "@koketomi \u521D\u590F\u304F\u3089\u3044\u307E\u3067\u306F\u934B\u3084\u308B\u3051\u3069\u306A\u30FC",
  "id" : 70065990397997056,
  "created_at" : "2011-05-16 10:00:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70057265775915008",
  "geo" : { },
  "id_str" : "70057470382440448",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30BD\u30FC\u30C8\u3068\u3044\u3046\u8A00\u8449\u3060\u3051\u306B\u53CD\u5FDC\u3057\u3066\u307F\u305F\u308A\u3002\u4F55\u306E\u30BD\u30FC\u30C8\uFF1F",
  "id" : 70057470382440448,
  "in_reply_to_status_id" : 70057265775915008,
  "created_at" : "2011-05-16 09:26:17 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70024205562949632",
  "geo" : { },
  "id_str" : "70024408982487041",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u3082\u3057\u3083\u3082\u3057\u3083",
  "id" : 70024408982487041,
  "in_reply_to_status_id" : 70024205562949632,
  "created_at" : "2011-05-16 07:14:54 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70014342313156609",
  "text" : "\u5145\u96FB\u602A\u3057\u3044\u304B\u3089\uFF30\uFF23\u9589\u3058\u305F\u3002\u30D7\u30ED\u30B0\u30E9\u30E0\u304C\u601D\u3046\u3088\u3046\u306B\u52D5\u304B\u306C\u2026\u7C21\u5358\u306A\u30CB\u30E5\u30FC\u30C8\u30F3\u6CD5\u306E\u8FD1\u4F3C\u304F\u3089\u3044\u51FA\u6765\u306A\u304F\u3066\u3069\u3046\u3057\u307E\u3059\u2026",
  "id" : 70014342313156609,
  "created_at" : "2011-05-16 06:34:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70003158893600768",
  "geo" : { },
  "id_str" : "70003386224885760",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6388\u696D\u4E2DPC\u304B\u3089\u3084\u3063\u3066\u308B\u4FFA\u306F\u304D\u3063\u3068\u2026",
  "id" : 70003386224885760,
  "in_reply_to_status_id" : 70003158893600768,
  "created_at" : "2011-05-16 05:51:22 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70000600754036736",
  "text" : "\u4E09\u98DF\u3068\u3044\u3046\u8A9E\u3092\u4E09\u8272\u3068\u805E\u304D\u9593\u9055\u3048\u308B\u2026\u9EBB\u96C0\u4E2D\u6BD2\u304B\u306A\u3002",
  "id" : 70000600754036736,
  "created_at" : "2011-05-16 05:40:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69998584560496640",
  "text" : "\u3042\u3001\u3080\u3063\u3061\u3083\u3044\u3044\uFF57",
  "id" : 69998584560496640,
  "created_at" : "2011-05-16 05:32:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69998548816633857",
  "text" : "\u3042\u308C\u3001\u65B0\u9928\u306E\u4E8C\u968E\u306F\u96FB\u6CE2\u3044\u3044\u304B\u3082",
  "id" : 69998548816633857,
  "created_at" : "2011-05-16 05:32:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69980790884282368",
  "text" : "\u305F\u3060\u56DE\u7DDA\u304C\u7D30\u3044\u7D30\u3044\u3002\u96FB\u6CE2\u5F31\u3044\u3002\u3002\u3002",
  "id" : 69980790884282368,
  "created_at" : "2011-05-16 04:21:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69979167709593600",
  "text" : "\u6587\u5B66\u90E8\u30E9\u30A6\u30F3\u30B8\u3001\u30CD\u30C3\u30C8\u7E4B\u304C\u3063\u305F\uFF01",
  "id" : 69979167709593600,
  "created_at" : "2011-05-16 04:15:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "indices" : [ 3, 10 ],
      "id_str" : "89620915",
      "id" : 89620915
    }, {
      "name" : "\u639B\u8C37\u62D3\u4E5F",
      "screen_name" : "3FILMS",
      "indices" : [ 19, 26 ],
      "id_str" : "10904582",
      "id" : 10904582
    }, {
      "name" : "\u30AC\u30FC\u30EA\u30A8\u30F3\u30CC",
      "screen_name" : "girliennes",
      "indices" : [ 35, 46 ],
      "id_str" : "105832116",
      "id" : 105832116
    }, {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "indices" : [ 91, 98 ],
      "id_str" : "89620915",
      "id" : 89620915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69968852867485697",
  "text" : "RT @qusumi: \u3075\u306F\u3063\u3002RT @3films: \u78BA\u304B\u306B\u3002RT @girliennes \u300C\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u300D\u306E\u30D1\u30ED\u30C7\u30A3\u3002\u3088\u304F\u3067\u304D\u3066\u3044\u308B\uFF01\u3000http:\/\/bit.ly\/kUhkUe @qusumi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u639B\u8C37\u62D3\u4E5F",
        "screen_name" : "3FILMS",
        "indices" : [ 7, 14 ],
        "id_str" : "10904582",
        "id" : 10904582
      }, {
        "name" : "\u30AC\u30FC\u30EA\u30A8\u30F3\u30CC",
        "screen_name" : "girliennes",
        "indices" : [ 23, 34 ],
        "id_str" : "105832116",
        "id" : 105832116
      }, {
        "name" : "\u4E45\u4F4F\u660C\u4E4B",
        "screen_name" : "qusumi",
        "indices" : [ 79, 86 ],
        "id_str" : "89620915",
        "id" : 89620915
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69967655016218624",
    "text" : "\u3075\u306F\u3063\u3002RT @3films: \u78BA\u304B\u306B\u3002RT @girliennes \u300C\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u300D\u306E\u30D1\u30ED\u30C7\u30A3\u3002\u3088\u304F\u3067\u304D\u3066\u3044\u308B\uFF01\u3000http:\/\/bit.ly\/kUhkUe @qusumi",
    "id" : 69967655016218624,
    "created_at" : "2011-05-16 03:29:23 +0000",
    "user" : {
      "name" : "\u4E45\u4F4F\u660C\u4E4B",
      "screen_name" : "qusumi",
      "protected" : false,
      "id_str" : "89620915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1625008477\/Q_Wqusumi_____normal.jpg",
      "id" : 89620915,
      "verified" : false
    }
  },
  "id" : 69968852867485697,
  "created_at" : "2011-05-16 03:34:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "177139869",
      "id" : 177139869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69965545868509184",
  "text" : "RT @wwwwww_bot: \u5F71\u6B66\u8005\u300C\u30CF\u30CF\u30CF\uFF01\u99AC\u9E7F\u3081\uFF01\u305D\u3063\u3061\u304C\u672C\u7269\u3060\uFF01\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69964820761419776",
    "text" : "\u5F71\u6B66\u8005\u300C\u30CF\u30CF\u30CF\uFF01\u99AC\u9E7F\u3081\uFF01\u305D\u3063\u3061\u304C\u672C\u7269\u3060\uFF01\u300D",
    "id" : 69964820761419776,
    "created_at" : "2011-05-16 03:18:07 +0000",
    "user" : {
      "name" : "\u7B11\u3063\u3066\u306F\u3044\u3051\u306A\u3044",
      "screen_name" : "wwwwww_bot",
      "protected" : false,
      "id_str" : "177139869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603569585434939393\/ptUiuLbP_normal.jpg",
      "id" : 177139869,
      "verified" : false
    }
  },
  "id" : 69965545868509184,
  "created_at" : "2011-05-16 03:21:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6570\u5B66\u554F\u984Cbot",
      "screen_name" : "mathematics_bot",
      "indices" : [ 0, 16 ],
      "id_str" : "96739891",
      "id" : 96739891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69956560801112064",
  "geo" : { },
  "id_str" : "69965393099362305",
  "in_reply_to_user_id" : 96739891,
  "text" : "@mathematics_bot \u4E00\u756A\u826F\u3044\u306E\u3092\u983C\u3080",
  "id" : 69965393099362305,
  "in_reply_to_status_id" : 69956560801112064,
  "created_at" : "2011-05-16 03:20:24 +0000",
  "in_reply_to_screen_name" : "mathematics_bot",
  "in_reply_to_user_id_str" : "96739891",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69954501309771776",
  "text" : "RT @JOJO_math: 808017424794512875886459904961710757005754368000000000 \u2026\u843D\u3061\u7740\u304F\u3093\u3060\u2026\u300E\u6563\u5728\u578B\u6709\u9650\u5358\u7D14\u7FA4\u306E\u4F4D\u6570\u300F\u3092\u6570\u3048\u3066\u843D\u3061\u7740\u304F\u3093\u3060\uFF65\uFF65\uFF65\u3000\u300E\u5358\u7D14\u7FA4\u300F\u306F\u5358\u4F4D\u7FA4\u3068\u81EA\u5206\u3057\u304B\u6B63\u898F\u90E8\u5206\u7FA4\u3092\u6301\u305F\u306A\u3044\u5B64\u72EC\u306A\u7FA4\u2026\u2026\u3000 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69937121485533184",
    "text" : "808017424794512875886459904961710757005754368000000000 \u2026\u843D\u3061\u7740\u304F\u3093\u3060\u2026\u300E\u6563\u5728\u578B\u6709\u9650\u5358\u7D14\u7FA4\u306E\u4F4D\u6570\u300F\u3092\u6570\u3048\u3066\u843D\u3061\u7740\u304F\u3093\u3060\uFF65\uFF65\uFF65\u3000\u300E\u5358\u7D14\u7FA4\u300F\u306F\u5358\u4F4D\u7FA4\u3068\u81EA\u5206\u3057\u304B\u6B63\u898F\u90E8\u5206\u7FA4\u3092\u6301\u305F\u306A\u3044\u5B64\u72EC\u306A\u7FA4\u2026\u2026\u3000\u79C1\u306B\u52C7\u6C17\u3092\u4E0E\u3048\u3066\u304F\u308C\u308B",
    "id" : 69937121485533184,
    "created_at" : "2011-05-16 01:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 69954501309771776,
  "created_at" : "2011-05-16 02:37:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69936870775209984",
  "text" : "@ayu167 \uFF18\u00D7\uFF18\u306E\u30C1\u30A7\u30B9\u76E4\u306B\u30BF\u30C6\u30E8\u30B3\u30CA\u30CA\u30E1\u306B\u52D5\u3051\u308B\u30AF\u30A4\u30FC\u30F3\u3092\u4E92\u3044\u306B\u4E00\u624B\u3067\u306F\u53D6\u3089\u308C\u306A\u3044\u72B6\u614B\u3067\u6700\u5927\u5E7E\u3064\u914D\u7F6E\u51FA\u6765\u308B\u304B\u3063\u3066\u554F\u984C\u3002\uFF4E\u00D7\uFF4E\u3060\u3068\u672A\u89E3\u6C7A\u554F\u984C\u3002",
  "id" : 69936870775209984,
  "created_at" : "2011-05-16 01:27:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69936183752400896",
  "text" : "@ayu167 \uFF18\u00D7\uFF18\u30AF\u30A4\u30FC\u30F3\u554F\u984C",
  "id" : 69936183752400896,
  "created_at" : "2011-05-16 01:24:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69910980108361728",
  "text" : "\u6700\u8FD1\u4E8C\u8A00\u76EE\u306B\u300C\u3042\u3001\u304A\u306F\u3088\u3046\u300D\u306E\u30D1\u30BF\u30F3\u304C\u591A\u3044\u306A",
  "id" : 69910980108361728,
  "created_at" : "2011-05-15 23:44:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69910800877355009",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3002",
  "id" : 69910800877355009,
  "created_at" : "2011-05-15 23:43:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69910740064157697",
  "text" : "\u3057\u3063\u304B\u308A\u4E00\u9650\u9593\u306B\u5408\u3063\u305F\u3051\u3069\u7720\u3044\u306A\u3002\u7D50\u5C40\uFF13\u6642\u307E\u3067\u8D77\u304D\u3066\u305F\u3057\u306A\u3041\u3002",
  "id" : 69910740064157697,
  "created_at" : "2011-05-15 23:43:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69910358164381696",
  "geo" : { },
  "id_str" : "69910536900452352",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3044\u3063\u3066\u3089\u3063\u3057\u3083\u3044\u307E\u305B\u3093\u3068\u304F\u3093",
  "id" : 69910536900452352,
  "in_reply_to_status_id" : 69910358164381696,
  "created_at" : "2011-05-15 23:42:25 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69818256227180544",
  "text" : "RT @sugiyama1990: \u30102\u968E\u304B\u3089\u76EE\u85AC\u3011C^\u221E\u51FD\u6570f\u306E\u6027\u8CEA\u3092\u8ABF\u3079\u305F\u3051\u308C\u3070\u3001\u5FAE\u5206\u305B\u305A\u306B\u305F\u3060\u51FD\u6570\u3092\u773A\u3081\u3066\u3044\u3066\u30821\u968E\u5FAE\u5206\u3060\u3051\u3067\u305F\u3060\u773A\u3081\u3066\u3082\u3044\u3044\u3053\u3068\u306F\u3042\u307E\u308A\u8D77\u3053\u3089\u306A\u3044\u3053\u3068\u304B\u3089\u751F\u307E\u308C\u305F\u3053\u3068\u308F\u3056\u3067\u30012\u968E\u5FAE\u5206\u3057\u3066\u521D\u3081\u3066\u76EE\u306E\u75B2\u52B4\u3082\u5831\u308F\u308C\u308B\u3068\u3044\u3046\u306E\u304C\u8A9E\u6E90\u3067\u3059\u3002\u300CMorse\u7406\u8AD6\u3092 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69817959673106432",
    "text" : "\u30102\u968E\u304B\u3089\u76EE\u85AC\u3011C^\u221E\u51FD\u6570f\u306E\u6027\u8CEA\u3092\u8ABF\u3079\u305F\u3051\u308C\u3070\u3001\u5FAE\u5206\u305B\u305A\u306B\u305F\u3060\u51FD\u6570\u3092\u773A\u3081\u3066\u3044\u3066\u30821\u968E\u5FAE\u5206\u3060\u3051\u3067\u305F\u3060\u773A\u3081\u3066\u3082\u3044\u3044\u3053\u3068\u306F\u3042\u307E\u308A\u8D77\u3053\u3089\u306A\u3044\u3053\u3068\u304B\u3089\u751F\u307E\u308C\u305F\u3053\u3068\u308F\u3056\u3067\u30012\u968E\u5FAE\u5206\u3057\u3066\u521D\u3081\u3066\u76EE\u306E\u75B2\u52B4\u3082\u5831\u308F\u308C\u308B\u3068\u3044\u3046\u306E\u304C\u8A9E\u6E90\u3067\u3059\u3002\u300CMorse\u7406\u8AD6\u3092\u52C9\u5F37\u3057\u305F\u3051\u30692\u968E\u304B\u3089\u76EE\u85AC\u3060\u306A\uFF01\u300D\u3068\u4F7F\u3044\u307E\u3059\u3002",
    "id" : 69817959673106432,
    "created_at" : "2011-05-15 17:34:33 +0000",
    "user" : {
      "name" : "\u3059\u304E\uFF20\u5168\u81EA\u52D5\u8AD6\u6587\u751F\u6210\u30DE\u30B7\u30FC\u30F3",
      "screen_name" : "sugi3_34",
      "protected" : false,
      "id_str" : "239811064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000759083368\/e85c8ef377b223436c38148680eb4e4a_normal.jpeg",
      "id" : 239811064,
      "verified" : false
    }
  },
  "id" : 69818256227180544,
  "created_at" : "2011-05-15 17:35:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69784084137783296",
  "text" : "\u666E\u901A\u306B\u8CA0\u3060\u308D\uFF4A\uFF4B",
  "id" : 69784084137783296,
  "created_at" : "2011-05-15 15:19:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u01DD\u0250\u029En\u026F\u0250\u029E\u0250u",
      "screen_name" : "nakamukae",
      "indices" : [ 3, 13 ],
      "id_str" : "112956578",
      "id" : 112956578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69784033386692609",
  "text" : "RT @nakamukae: \u300C\u6B63\u300D\u306E\u53CD\u5BFE\u306F\u306A\u3093\u3067\u3057\u3087\u3046\u304B\uFF1F \u3000\u6587\u7CFB\u2192\u300C\u8AA4\u300D \u3000\u7406\u7CFB\u2192\u300C\u8CA0\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69742360162074624",
    "text" : "\u300C\u6B63\u300D\u306E\u53CD\u5BFE\u306F\u306A\u3093\u3067\u3057\u3087\u3046\u304B\uFF1F \u3000\u6587\u7CFB\u2192\u300C\u8AA4\u300D \u3000\u7406\u7CFB\u2192\u300C\u8CA0\u300D",
    "id" : 69742360162074624,
    "created_at" : "2011-05-15 12:34:09 +0000",
    "user" : {
      "name" : "\u01DD\u0250\u029En\u026F\u0250\u029E\u0250u",
      "screen_name" : "nakamukae",
      "protected" : false,
      "id_str" : "112956578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481775927408357377\/0jcJIL0e_normal.jpeg",
      "id" : 112956578,
      "verified" : false
    }
  },
  "id" : 69784033386692609,
  "created_at" : "2011-05-15 15:19:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69778377824935936",
  "text" : "\u8A18\u53F7\u8AD6\u7406\u5B66\u306E\u5BBF\u984C\u3084\u308D\u3046\u3001\u305D\u3046\u3057\u3088\u3046\u305D\u3046\u3059\u3079\u304D\u3002",
  "id" : 69778377824935936,
  "created_at" : "2011-05-15 14:57:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69777028223733760",
  "text" : "\u8475\u796D\u3068\u304B\u4EBA\u591A\u3059\u304E\u3066\u884C\u304F\u6C17\u306B\u306A\u3089\u306A\u3044\u3002\u4E0B\u9D28\u795E\u793E\u306F\u307F\u305F\u3089\u3057\u796D\u308A\u306E\u65B9\u304C\u3053\u3058\u3093\u307E\u308A\u3057\u3066\u3066\u826F\u304B\u3063\u305F\u306A\u3041\u3002\u53BB\u5E74\u30C6\u30B9\u30C8\u524D\u3060\u3063\u305F\u3051\u3069\u4ECA\u5E74\u3082\u304B\u306A\uFF1F\u591A\u5206\u884C\u304F\u3051\u3069\u3055\u3002",
  "id" : 69777028223733760,
  "created_at" : "2011-05-15 14:51:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69771156198141952",
  "geo" : { },
  "id_str" : "69771497325076480",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u306830\u5206\u5F31\u2026",
  "id" : 69771497325076480,
  "in_reply_to_status_id" : 69771156198141952,
  "created_at" : "2011-05-15 14:29:55 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69758811069620224",
  "text" : "\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u3063\u3066\u3069\u3046\u3082\u545F\u3044\u305F\u5F8C\u306B\u3064\u3051\u308B\u3053\u3068\u3092\u601D\u3044\u7ACB\u3063\u3066\u3057\u307E\u3046\u3002\u540C\u3058\u3088\u3046\u306A\u767A\u8A00\u3067\u7533\u3057\u8A33\u306A\u3044\u306E\u3060\u3051\u308C\u3069\u3002",
  "id" : 69758811069620224,
  "created_at" : "2011-05-15 13:39:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kimono",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69758636708212736",
  "text" : "\u3060\u308C\u304B\u6D74\u8863\u3068\u304B\u304D\u3082\u306E\u3092\u5B89\u304F\u305F\u304F\u3055\u3093\u58F2\u3063\u3066\u308B\u3068\u3053\u308D\u3042\u3063\u305F\u3089\u6559\u3048\u3066\u307B\u3057\u3044\u3067\u3059#yukata #kimono",
  "id" : 69758636708212736,
  "created_at" : "2011-05-15 13:38:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69757510403375104",
  "text" : "\u3060\u308C\u304B\u6D74\u8863\u3068\u304B\u304D\u3082\u306E\u3092\u5B89\u304F\u305F\u304F\u3055\u3093\u58F2\u3063\u3066\u308B\u3068\u3053\u308D\u3042\u3063\u305F\u3089\u6559\u3048\u3066\u307B\u3057\u3044\u3067\u3059",
  "id" : 69757510403375104,
  "created_at" : "2011-05-15 13:34:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69757320984403968",
  "text" : "\u306A\u3093\u304B\u30D5\u30E9\u30AF\u30BF\u30EB\u307F\u305F\u3044\u306A\u5E7E\u4F55\u5B66\u6A21\u69D8\u306E\u6D74\u8863\u306A\u3044\u304B\u306A\u3002\u5186\u5468\u7387\u3068\u304B\u81EA\u7136\u5BFE\u6570\u306E\u5E95\u3001\u6E0B\u3044\u3068\u3053\u308D\u3067i~i\u306A\u3093\u304B\u306E\u7F85\u5217\u3068\u304B\u3067\u3082\u3044\u3044\u3051\u3069\u2190",
  "id" : 69757320984403968,
  "created_at" : "2011-05-15 13:33:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69757011776114688",
  "text" : "\u7740\u7269\u3082\u305D\u3046\u3060\u3051\u3069\u6D74\u8863\u306F\u5973\u7269\u306E\u65B9\u304C\u67C4\u306E\u7A2E\u985E\u3082\u8C4A\u5BCC\u3067\u8276\u3084\u304B\u3067\u660E\u308B\u304F\u3066\u7FA8\u307E\u3057\u3044\u9650\u308A\u3067\u3059\u3002\u7537\u7269\u3063\u3066\u8272\u9063\u3044\u304C\u304F\u3089\u3044\u3068\u3044\u3046\u304B\u30EF\u30F3\u30D1\u30BF\u30FC\u30F3\u3002",
  "id" : 69757011776114688,
  "created_at" : "2011-05-15 13:32:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69756725858803713",
  "text" : "\u8CB7\u3063\u3066\u304D\u305F\u3070\u304B\u308A\u306E\u548C\u88C5\u3067\u8AB2\u984C\u306A\u3046\u3002\u4ECA\u4E01\u5EA6\u3044\u3044\u3051\u3069\u590F\u306B\u306F\u6691\u3044\u304B\u3082\u306A\u3041\u3002\u6D74\u8863\u3082\u6B32\u3057\u304B\u3063\u305F\u3093\u3060\u3051\u3069\u304A\u8CA1\u5E03\u3068\u67C4\u3068\u76F8\u8AC7\u3057\u3066\u4ECA\u56DE\u306F\u65AD\u5FF5\u3057\u307E\u3057\u305F\u3002",
  "id" : 69756725858803713,
  "created_at" : "2011-05-15 13:31:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69755572530057216",
  "text" : "@mo5nya \u4E2D\u5B66\u306E\u6642\u306B\u8AAD\u3093\u3060\u306E\u3067\u3059\u304C\u8650\u5F85\u306E\u8868\u73FE\u304C\u5ACC\u306B\u7D30\u304B\u304F\u5177\u4F53\u7684\u3060\u3063\u305F\u8A18\u61B6\u3070\u304B\u308A\u304C\u5148\u884C\u3057\u3061\u3083\u3063\u3066\u307E\u3059\u3002\u3044\u308D\u3093\u306A\u610F\u5473\u3067\u304B\u306A\u308A\u8AAD\u307F\u5FDC\u3048\u304C\u3042\u308A\u307E\u3057\u305F\u3002\u5185\u5BB9\u304C\u5185\u5BB9\u306A\u3093\u3067\u9762\u767D\u304B\u3063\u305F\u3063\u3066\u8868\u73FE\u306F\u3067\u304D\u307E\u305B\u3093\u304C\u8208\u5473\u3042\u308B\u306A\u3089\u305C\u3072\u305C\u3072\u3002",
  "id" : 69755572530057216,
  "created_at" : "2011-05-15 13:26:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69752984673857536",
  "text" : "@mo5nya \u30C7\u30A4\u30D3\u30C3\u30C8\u30FB\u30DA\u30EB\u30B6\u30FC\u3063\u3066\u4EBA\u306E\u300C\uFF29\uFF54\u3068\u547C\u3070\u308C\u305F\u5B50\u300D\u3063\u3066\u672C\u3067\u305D\u3093\u306A\u3053\u3068\u3092\u7B46\u8005\u304C\u8A00\u3063\u3066\u3044\u305F\u3088\u3046\u306A\u3044\u306A\u3044\u3088\u3046\u306A\u2026\u3002\u8A18\u61B6\u304C\u3042\u3044\u307E\u3044\u3067\u3059\u304C\u3002",
  "id" : 69752984673857536,
  "created_at" : "2011-05-15 13:16:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69739528365158401",
  "geo" : { },
  "id_str" : "69739799774367744",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3053\u3063\u3061\u3053\u305D\u3057\u3064\u3053\u304F\u805E\u3044\u3066\u3054\u3081\u3093\u306D\u3001\u30E1\u30E2\u3057\u304F\u3079\u304D\u3084\u3063\u305F\u3002",
  "id" : 69739799774367744,
  "in_reply_to_status_id" : 69739528365158401,
  "created_at" : "2011-05-15 12:23:58 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69736777690259456",
  "geo" : { },
  "id_str" : "69737886404190208",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6587\u5B66\u90E8\u82F1\u8A9E\u3063\u3066\u3069\u3053\u307E\u3067\u3060\u3063\u3051\uFF1F\uFF08\u6BCE\u56DE\u805E\u3044\u3066\u308B\u6C17\u304C\u3059\u308B\u2026\uFF09",
  "id" : 69737886404190208,
  "in_reply_to_status_id" : 69736777690259456,
  "created_at" : "2011-05-15 12:16:22 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 9, 21 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69734476397285376",
  "text" : "\u308F\u304B\u308B\u308F\u30FC\u3002RT @nisehorrrrn: \u30D1\u30BD\u30B3\u30F3\u3067\u6570\u5B66\u306E\u8A71\u3068\u304B\u3057\u306B\u304F\u304F\u3066\u3057\u3087\u3046\u304C\u306A\u3044\u3002",
  "id" : 69734476397285376,
  "created_at" : "2011-05-15 12:02:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69733416769302530",
  "text" : "\u548C\u670D\u8CB7\u3063\u3066\u304D\u305F\u306A\u3046\u3002",
  "id" : 69733416769302530,
  "created_at" : "2011-05-15 11:58:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69675336450842624",
  "text" : "@nico_reflexio \u6700\u8FD1\u6539\u88C5\u3057\u3066\u30AA\u30FC\u30D7\u30F3\u3057\u305F\u3068\u304B\u3057\u306A\u3044\u3068\u304B\u3002",
  "id" : 69675336450842624,
  "created_at" : "2011-05-15 08:07:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082\u3063\u304F\u3059\uFF20\u6771\u4EAC\u4EBA\u306B\u306A\u308A\u307E\u3057\u305F",
      "screen_name" : "o_tomox",
      "indices" : [ 0, 8 ],
      "id_str" : "145247946",
      "id" : 145247946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69673936387969024",
  "geo" : { },
  "id_str" : "69674163937345536",
  "in_reply_to_user_id" : 145247946,
  "text" : "@o_tomox \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002\u7BC4\u56F2\u308F\u304B\u3093\u306A\u3044\u3051\u3069\u3001\u9069\u5F53\u306B\u3084\u3063\u3066\u307F\u307E\u3059\u2190",
  "id" : 69674163937345536,
  "in_reply_to_status_id" : 69673936387969024,
  "created_at" : "2011-05-15 08:03:09 +0000",
  "in_reply_to_screen_name" : "o_tomox",
  "in_reply_to_user_id_str" : "145247946",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082\u3063\u304F\u3059\uFF20\u6771\u4EAC\u4EBA\u306B\u306A\u308A\u307E\u3057\u305F",
      "screen_name" : "o_tomox",
      "indices" : [ 0, 8 ],
      "id_str" : "145247946",
      "id" : 145247946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69673205236903936",
  "geo" : { },
  "id_str" : "69673497084968960",
  "in_reply_to_user_id" : 145247946,
  "text" : "@o_tomox \u3064\u307E\u308A\u300C\u30C6\u30B9\u30C8\u51FA\u5E2D\u3057\u3066\u304A\u3051\u3070\u4F55\u3068\u304B\u306A\u308B\u300D\u3063\u3066\u3053\u3068\u3067\u3059\u304B\u306D\uFF57",
  "id" : 69673497084968960,
  "in_reply_to_status_id" : 69673205236903936,
  "created_at" : "2011-05-15 08:00:30 +0000",
  "in_reply_to_screen_name" : "o_tomox",
  "in_reply_to_user_id_str" : "145247946",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69673244386533377",
  "text" : "\u3053\u3046\u3044\u3046\u6642\u3053\u305D\u77E5\u6075\u888B\u304B\uFF01\u2190",
  "id" : 69673244386533377,
  "created_at" : "2011-05-15 07:59:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 0, 15 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69672899816067072",
  "geo" : { },
  "id_str" : "69673126715330560",
  "in_reply_to_user_id" : 227502200,
  "text" : "@G4_Hirano_chan \u75B2\u308C\u3066\u308B\u3068\u3044\u3046\u3088\u308A\u56F0\u3063\u3066\u3044\u308B\u3002",
  "id" : 69673126715330560,
  "in_reply_to_status_id" : 69672899816067072,
  "created_at" : "2011-05-15 07:59:02 +0000",
  "in_reply_to_screen_name" : "G4_Hirano_chan",
  "in_reply_to_user_id_str" : "227502200",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "call_english",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69673025724878848",
  "text" : "\u8AB0\u304B\u82F1\u8A9E\u306E\u30B3\u30FC\u30EB\u4F55\u3084\u308C\u3070\u3044\u3044\u306E\u304B\u77E5\u3063\u3066\u308B\u4EBA\u6559\u3048\u3066\u304F\u3060\u3055\u3044#KU #call_english",
  "id" : 69673025724878848,
  "created_at" : "2011-05-15 07:58:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69672661969670144",
  "text" : "\u306A\u3093\u304B\u63D0\u51FA\u305B\u306B\u3083\u306A\u3089\u3093\u306E\u304B\u306A\uFF1F\u8AAC\u660E\u4F1A\u306B\u884C\u304D\u640D\u306D\u305F\u306E\u306F\u307E\u305A\u304B\u3063\u305F\u306A\u3041\u3002\u30D5\u30E9\u30F3\u30B9\u8A9E\u306F\u53BB\u5E74\u53D6\u3063\u3066\u305F\u304B\u3089\u5927\u4F53\u306E\u30B7\u30B9\u30C6\u30E0\u89E3\u308B\u3051\u3069\u2026\u3002",
  "id" : 69672661969670144,
  "created_at" : "2011-05-15 07:57:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69672495900405760",
  "text" : "\u7D50\u5C40\u30B3\u30FC\u30EB\u3063\u3066\u4F55\u3084\u308C\u3070\u3044\u3044\u3093\u3060\u3088\u30FC\u3002\u6559\u6750\u9069\u5F53\u306B\u805E\u304D\u6D41\u3057\u3066\u307F\u305F\u3051\u3069\u305D\u3093\u306A\u306B\u96E3\u3057\u304F\u306A\u3055\u305D\u3046\u3060\u3051\u3069\u30FB\u30FB\u30FB",
  "id" : 69672495900405760,
  "created_at" : "2011-05-15 07:56:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 3, 13 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MachiTwi",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69656421339365376",
  "text" : "\u73FE\u5728 @end313124 \u306F\u300110\u90FD\u9053\u5E9C\u770C\u300113\u5E02\u533A\u90E1\u3068\u4EA4\u6D41\u4E2D\u3002 #MachiTwi http:\/\/machi.userlocal.jp\/   \u5C40\u6240\u7684\u306D\u3047\u3002\u6771\u4EAC\u4EAC\u90FD\u306B\u96C6\u4E2D\u3059\u308B\u306E\u306F\u5F53\u7136\u304B\u2026\u3002",
  "id" : 69656421339365376,
  "created_at" : "2011-05-15 06:52:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69654108134588416",
  "text" : "@nico_reflexio \u65E9\u8D77\u304D\u306D\u3002\u6628\u65E5\u304B\u3089\u4ECA\u65E5\u306B\u304B\u3051\u3066\u9EBB\u96C0\u3057\u3066\u305F\u304B\u3089\u5BDD\u574A\u3067\u3057\u305F\u3002",
  "id" : 69654108134588416,
  "created_at" : "2011-05-15 06:43:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69653196125110272",
  "text" : "@nico_reflexio \u3082\u3046\u3093\u306A\u3068\u3053\u308D\u307E\u3067\u6765\u3066\u3093\u306E\u304B\uFF57\uFF57\uFF57\uFF57",
  "id" : 69653196125110272,
  "created_at" : "2011-05-15 06:39:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69615818115268608",
  "text" : "\u534A\u8358\u4E8C\u56DE\u3067\uFF12\u4F4D\uFF13\u4F4D\u3002\u4E00\u56DE\u76EE\u306F\u5357\uFF13\u307E\u3067\u713C\u304D\u9CE5\u3060\u3063\u305F\u306E\u3092\uFF14\u9023\u8358\u307B\u3069\u3067\u306A\u3093\u3068\u304B\u30AE\u30EA\u30AE\u30EA\uFF12\u4F4D\u306B\u98DF\u3044\u8FBC\u307F\u3001\uFF12\u56DE\u76EE\u306F\u4E8C\u7740\u3068\u6570\u767E\u70B9\u5DEE\u3060\u3063\u305F\u305F\u3081\u306B\u5927\u304D\u304F\u30D7\u30E9\u30B9\u306B\u306A\u3089\u305A\u2026\u7D50\u5C40\u7DCF\u5408\u3067\uFF12\u4F4D\u3002\uFF11\u4F4D\u3068\u306E\u5DEE\u306F\uFF15\u3060\u3063\u305F\u304B\u3089\uFF15\uFF10\uFF10\uFF10\u70B9\u5206\u3002\u3082\u3046\u30C1\u30E7\u30A4\u2026\u3002",
  "id" : 69615818115268608,
  "created_at" : "2011-05-15 04:11:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69615309455241216",
  "text" : "\u304A\u306F\u3088\u3046\u3002\u6628\u591C\u304B\u3089\u4ECA\u65E5\u306B\u304B\u3051\u3066\u9EBB\u96C0\u3067\u3057\u305F\u3002",
  "id" : 69615309455241216,
  "created_at" : "2011-05-15 04:09:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69307875784265728",
  "text" : "RT @JOJO_math: \u2015\u5927\u5B66\u9662\u751F\u306F\u2015\u3000\uFF12\u5EA6\u3068\u663C\u578B\u751F\u6D3B\u3078\u306F\u623B\u308C\u306A\u304B\u3063\u305F\u2026\u3000\u591C\u66F4\u304B\u3057\u3068\u65E9\u8D77\u304D\u306E\u4E2D\u9593\u306E\u751F\u547D\u4F53\u3068\u306A\u308A\u3000\u6C38\u9060\u306B\u6570\u5B66\u7A7A\u9593\u3092\u3055\u307E\u3088\u3046\u306E\u3060\u3000\u305D\u3057\u3066\u5BDD\u574A\u3057\u306A\u3044\u3068\u601D\u3063\u3066\u3082\u3067\u304D\u306A\u3044\u306E\u3067\u3000\u2015\u305D\u306E\u3046\u3061\u9662\u751F\u306F\u30BB\u30DF\u30CA\u30FC\u524D\u65E5\u306B\u5BDD\u308B\u306E\u3092\u3084\u3081\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69302943400210432",
    "text" : "\u2015\u5927\u5B66\u9662\u751F\u306F\u2015\u3000\uFF12\u5EA6\u3068\u663C\u578B\u751F\u6D3B\u3078\u306F\u623B\u308C\u306A\u304B\u3063\u305F\u2026\u3000\u591C\u66F4\u304B\u3057\u3068\u65E9\u8D77\u304D\u306E\u4E2D\u9593\u306E\u751F\u547D\u4F53\u3068\u306A\u308A\u3000\u6C38\u9060\u306B\u6570\u5B66\u7A7A\u9593\u3092\u3055\u307E\u3088\u3046\u306E\u3060\u3000\u305D\u3057\u3066\u5BDD\u574A\u3057\u306A\u3044\u3068\u601D\u3063\u3066\u3082\u3067\u304D\u306A\u3044\u306E\u3067\u3000\u2015\u305D\u306E\u3046\u3061\u9662\u751F\u306F\u30BB\u30DF\u30CA\u30FC\u524D\u65E5\u306B\u5BDD\u308B\u306E\u3092\u3084\u3081\u305F",
    "id" : 69302943400210432,
    "created_at" : "2011-05-14 07:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 69307875784265728,
  "created_at" : "2011-05-14 07:47:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AF\u30ED\u30AD",
      "screen_name" : "ykuroki",
      "indices" : [ 3, 11 ],
      "id_str" : "121136885",
      "id" : 121136885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/5DLJQYW",
      "expanded_url" : "http:\/\/d.hatena.ne.jp\/AntiBayesian\/20110507\/1304783234",
      "display_url" : "d.hatena.ne.jp\/AntiBayesian\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "69298760190132224",
  "text" : "RT @ykuroki: \u30E2\u30C6\u308B\u81EA\u7136\u8A00\u8A9E\u51E6\u7406\u7CFB\u5973\u5B50\u529B\u3092\u78E8\u304F\u305F\u3081\u306E4\u3064\u306E\u5FC3\u5F97  - \u3042\u3093\u3061\u3079\uFF01  http:\/\/t.co\/5DLJQYW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 54 ],
        "url" : "http:\/\/t.co\/5DLJQYW",
        "expanded_url" : "http:\/\/d.hatena.ne.jp\/AntiBayesian\/20110507\/1304783234",
        "display_url" : "d.hatena.ne.jp\/AntiBayesian\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "68228820578217984",
    "text" : "\u30E2\u30C6\u308B\u81EA\u7136\u8A00\u8A9E\u51E6\u7406\u7CFB\u5973\u5B50\u529B\u3092\u78E8\u304F\u305F\u3081\u306E4\u3064\u306E\u5FC3\u5F97  - \u3042\u3093\u3061\u3079\uFF01  http:\/\/t.co\/5DLJQYW",
    "id" : 68228820578217984,
    "created_at" : "2011-05-11 08:19:53 +0000",
    "user" : {
      "name" : "\u30AF\u30ED\u30AD",
      "screen_name" : "ykuroki",
      "protected" : false,
      "id_str" : "121136885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1223352273\/images_normal.jpeg",
      "id" : 121136885,
      "verified" : false
    }
  },
  "id" : 69298760190132224,
  "created_at" : "2011-05-14 07:11:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69247437067386880",
  "text" : "\u5168\u7136\u3084\u308B\u6C17\u3067\u306A\u3044",
  "id" : 69247437067386880,
  "created_at" : "2011-05-14 03:47:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69228968179539968",
  "text" : "\u3042\u3001\u53F3\u3060\u3063\u305F",
  "id" : 69228968179539968,
  "created_at" : "2011-05-14 02:34:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69228921341739008",
  "text" : "\u8EFD\u304F\u5BDD\u9055\u3048\u305F\u304B\u306A\u30FB\u30FB\u30FB\u5DE6\u5411\u304F\u3068\u920D\u75DB\u304C\u8D70\u308B\u3002",
  "id" : 69228921341739008,
  "created_at" : "2011-05-14 02:33:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69221367588995073",
  "geo" : { },
  "id_str" : "69222987542446080",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u306F\u3088\u3046",
  "id" : 69222987542446080,
  "in_reply_to_status_id" : 69221367588995073,
  "created_at" : "2011-05-14 02:10:20 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69078495757742080",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 69078495757742080,
  "created_at" : "2011-05-13 16:36:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69078429412245504",
  "text" : "\uFF08\u3069\u3063\u3061\u304B\u3068\u3044\u3046\u3068\u30C6\u30C8\u30E9\u3061\u3083\u3093\u6D3E\u306A\u3093\u3060\u3051\u3069\u306A\u3041\u2026\uFF09",
  "id" : 69078429412245504,
  "created_at" : "2011-05-13 16:35:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69078309211877376",
  "text" : "\u304A\u3068\u306A\u3057\u304F\u5BDD\u308B\u3088\u3002\u304A\u3084\u3059\u30DF\u30EB\u30AB\u3055\u3093\u3002",
  "id" : 69078309211877376,
  "created_at" : "2011-05-13 16:35:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69078145432698880",
  "text" : "\u30B3\u30DE\u9001\u308A\u7981\u6B62\u3067\u3059\u3045 \u3063\u3066\u66F8\u3044\u3066\u3042\u308B\u30B3\u30DE\u304C\u3042\u3063\u305F\u305E\uFF57",
  "id" : 69078145432698880,
  "created_at" : "2011-05-13 16:34:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69077968726663168",
  "text" : "\u30DF\u30EB\u30AD\u30FC\u30B3\u30DE\u9001\u308A\u9762\u767D\u308C\u3047\u2026\u3063\u3066\u306A\u306B\u3084\u3063\u3066\u3093\u3060\u308D\u3001\u4FFA\u3002",
  "id" : 69077968726663168,
  "created_at" : "2011-05-13 16:34:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69065892402696192",
  "geo" : { },
  "id_str" : "69066267662888960",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u4E00\u65E5\uFF13\uFF10\uFF10post\u3068\u304B\u3059\u308B\u3072\u3068\u3082\u3044\u308B\u304B\u3089\u9023\u7D9A\u30C4\u30A4\u30FC\u30C8\u4F4D\u6C17\u306B\u3059\u308B\u306A\u30FC",
  "id" : 69066267662888960,
  "in_reply_to_status_id" : 69065892402696192,
  "created_at" : "2011-05-13 15:47:36 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3076\u3089\u304F\u3089\u3076\u3089\u3044\u3068",
      "screen_name" : "bright999",
      "indices" : [ 3, 13 ],
      "id_str" : "83103732",
      "id" : 83103732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69063203597975552",
  "text" : "RT @bright999: \u30CD\u30B3\u306F 99\u4E079999\u56DE\u751F\u304D\u305F\u3002 \u4EBA\u751F\u306F\u5F8C1\u56DE\u3057\u304B\u306A\u3044\u3002 \u4ECA\u56DE\u306F\u6709\u610F\u7FA9\u3060\u3063\u305F\u304B\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69062308852281344",
    "text" : "\u30CD\u30B3\u306F 99\u4E079999\u56DE\u751F\u304D\u305F\u3002 \u4EBA\u751F\u306F\u5F8C1\u56DE\u3057\u304B\u306A\u3044\u3002 \u4ECA\u56DE\u306F\u6709\u610F\u7FA9\u3060\u3063\u305F\u304B\uFF1F",
    "id" : 69062308852281344,
    "created_at" : "2011-05-13 15:31:52 +0000",
    "user" : {
      "name" : "\u3076\u3089\u304F\u3089\u3076\u3089\u3044\u3068",
      "screen_name" : "bright999",
      "protected" : false,
      "id_str" : "83103732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000365022973\/228558f71d1de0542301b42c013e8c47_normal.jpeg",
      "id" : 83103732,
      "verified" : false
    }
  },
  "id" : 69063203597975552,
  "created_at" : "2011-05-13 15:35:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69060286358880256",
  "text" : "\u6C17\u304C\u4ED8\u3044\u305F\u3089\u3082\u3046\u65E5\u4ED8\u304C\u5909\u308F\u3063\u3066\u3044\u308B\u3001\uFF11\uFF13\u65E5\u306E\u91D1\u66DC\u65E5\u3002\u5BDD\u574A\u3057\u305F\u4EE5\u5916\u306F\u7279\u306B\u554F\u984C\u306A\u3057\u3002",
  "id" : 69060286358880256,
  "created_at" : "2011-05-13 15:23:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69060016539312128",
  "text" : "\u3084\u3089\u306A\u3044\u304B\u3089\u3067\u304D\u306A\u3044\u3001\u3063\u3066\u308F\u304B\u308A\u304D\u3063\u3066\u3044\u3066\u51FA\u6765\u306A\u3044\u3063\u3066\u5606\u304F\u306E\u306F\u9593\u9055\u3063\u3066\u3044\u308B\u3082\u306E\u306D\u2026\u3002",
  "id" : 69060016539312128,
  "created_at" : "2011-05-13 15:22:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69059877053542400",
  "text" : "\u306A\u3093\u306B\u3064\u3044\u3066\u3082\u305D\u3046\u3060\u3051\u308C\u3069\u3001\u81EA\u5206\u3001\u3053\u3093\u306A\u8ABF\u5B50\u3067\u300C\u4F55\u304B\u3067\u304D\u308B\u3088\u3046\u306B\u306A\u308B\u300D\u306E\u304B\u306A\u3002\u59CB\u3081\u305F\u3070\u304B\u308A\u306E\u6642\u57FA\u672C\u7684\u306A\u3053\u3068\u304C\u3067\u304D\u306A\u3044\u3068\u5ACC\u6C17\u304C\u3055\u3059\u3002\u51FA\u6765\u306A\u304F\u3066\u5F53\u305F\u308A\u524D\u3060\u3051\u3069\u3002\u3067\u304D\u306A\u3044\u3053\u3068\u304C\u5ACC\u306B\u306A\u3063\u3066\u3084\u3089\u306A\u3044\u306E\u306F\u3082\u3063\u3068\u307E\u305A\u3044\u3002",
  "id" : 69059877053542400,
  "created_at" : "2011-05-13 15:22:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69058240180256768",
  "text" : "\u30EA\u30D7\u30E9\u30A4\u3068RT\u306E\u548C\u304C\u305F\u3060\u306E\u30E1\u30F3\u30B7\u30E7\u30F3\u3068\u307B\u307C\u540C\u6570\u304B",
  "id" : 69058240180256768,
  "created_at" : "2011-05-13 15:15:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69057243521355776",
  "text" : "\u4F1A\u8A71\u3060\u3068\uFF08\uFF18\u5272\u304F\u3060\u3089\u306A\u3044\u3053\u3068\u306B\u305B\u3088\uFF09\u7D50\u69CB\u3057\u3083\u3079\u308B\u65B9\u3060\u3051\u3069\u30C4\u30A4\u30C3\u30BF\u30FC\u3060\u3068\u305D\u3046\u3067\u3082\u306A\u3044\u304B\u306A\u3002twilog stat\u898B\u3066\u306A\u3044\u304B\u3089\u78BA\u5B9F\u3058\u3083\u306A\u3044\u3051\u3069\u305F\u3076\u3093\u4E00\u65E5\uFF16\uFF10pos\u304F\u3089\u3044\u304C\u9650\u754C\u306A\u3093\u3058\u3083\u306A\u3044\u304B\u306A\u3002\u30EA\u30D7\u30E9\u30A4\u3068\u304BRT\u306F\u81C6\u305B\u305A\u3055\u3089\u3063\u3068\u3057\u3061\u3083\u3046\u3051\u3069\u3002",
  "id" : 69057243521355776,
  "created_at" : "2011-05-13 15:11:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69056867988549633",
  "text" : "\u306A\u3093\u304B\u30FB\u3064\u3076\u3084\u304D\u305F\u3044\u65E5\u3068\u305D\u3046\u3067\u306A\u3044\u4EBA\u305A\u3044\u3076\u3093\u6CE2\u304C\u3042\u308B\u3088\u306A\u30FC\u3002",
  "id" : 69056867988549633,
  "created_at" : "2011-05-13 15:10:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69050428918206464",
  "text" : "\uFF12\u5206\u304F\u3089\u3044\u3067\u58F0\u51FA\u3057\u3066\u7B11\u3063\u305F\u3002\u732B\u304B\u308F\u3044\u3044\u3002\u3000http:\/\/goo.gl\/Szzw",
  "id" : 69050428918206464,
  "created_at" : "2011-05-13 14:44:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69048743588151296",
  "text" : "\u7D76\u5BFE\u306B\u732B\u6D3E\u3060\u3051\u3069\u3001\u3053\u306E\u72AC\u304B\u308F\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3048\u3000http:\/\/youtu.be\/q8DiOthAKek",
  "id" : 69048743588151296,
  "created_at" : "2011-05-13 14:37:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69047380548399104",
  "text" : "\u3042\u306E\u65E5\u805E\u3044\u305F\u5F7C\u306E\u540D\u524D\u3092\u50D5\u306F\u3082\u3046\u77E5\u3089\u306A\u3044\u3002",
  "id" : 69047380548399104,
  "created_at" : "2011-05-13 14:32:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3057\u3087\u30FC\u3044\u3061(\u3086\u304D\u3072\u3089)",
      "screen_name" : "shouichi_",
      "indices" : [ 3, 13 ],
      "id_str" : "107291163",
      "id" : 107291163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69047276231856129",
  "text" : "RT @shouichi_: \u3042\u306E\u65E5\u30AF\u30E9\u30B9\u306B\u3044\u305F\u4FFA\u306E\u540D\u524D\u3092\u30AF\u30E9\u30B9\u30E1\u30FC\u30C8\u306F\u8AB0\u3082\u77E5\u3089\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yubitter.com\/\" rel=\"nofollow\"\u003Eyubitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69044501515206656",
    "text" : "\u3042\u306E\u65E5\u30AF\u30E9\u30B9\u306B\u3044\u305F\u4FFA\u306E\u540D\u524D\u3092\u30AF\u30E9\u30B9\u30E1\u30FC\u30C8\u306F\u8AB0\u3082\u77E5\u3089\u306A\u3044",
    "id" : 69044501515206656,
    "created_at" : "2011-05-13 14:21:06 +0000",
    "user" : {
      "name" : "\u3057\u3087\u30FC\u3044\u3061(\u3086\u304D\u3072\u3089)",
      "screen_name" : "shouichi_",
      "protected" : false,
      "id_str" : "107291163",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601015800493834241\/ssI62XBQ_normal.png",
      "id" : 107291163,
      "verified" : false
    }
  },
  "id" : 69047276231856129,
  "created_at" : "2011-05-13 14:32:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69001742670512128",
  "text" : "\u3086\u304D\u3042\u3064\u306F\u516B\u30C3\u6A4B\u304C\u597D\u304D\u306A\u306E\u304B\u3002\u3078\u3047",
  "id" : 69001742670512128,
  "created_at" : "2011-05-13 11:31:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68987652883480578",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u3054\u98EF\u3064\u304F\u3089\u306A\u3070",
  "id" : 68987652883480578,
  "created_at" : "2011-05-13 10:35:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68984593834967040",
  "text" : "\uFF53\uFF51\uFF52\uFF54\u306E\u4E2D\u8EAB\u3061\u3083\u3093\u3068\u6B63\u306A\u306E\u306B\u306A\u3093\u3067\u3060\u308D\u3046\u3002\u3080\u3045\u3002",
  "id" : 68984593834967040,
  "created_at" : "2011-05-13 10:23:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68982540899319808",
  "text" : "\uFF53\uFF51\uFF52\uFF54\uFF1ADOMEIN\u3000error\u304C\u5927\u91CF\u306B\u8868\u308C\u308B\u2026\u3002",
  "id" : 68982540899319808,
  "created_at" : "2011-05-13 10:14:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68978680843599872",
  "geo" : { },
  "id_str" : "68978965792030720",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8ABF\u3079\u3066\u307F\u308B\u3088\u3002\u30B5\u30F3\u30AD\u30E5\u3002",
  "id" : 68978965792030720,
  "in_reply_to_status_id" : 68978680843599872,
  "created_at" : "2011-05-13 10:00:41 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68977560570183680",
  "text" : "\u30D5\u30A9\u30ED\u30A2\u52DF\u96C6\u3068\u30B5\u30FC\u30AF\u30EB\u521D\u671F\u30E1\u30F3\u30D0\u30FC\u52DF\u96C6\u3060\u3051\u5B9A\u671F\u7684\u306BPost\u3057\u3088\u3046\u304B\u306A\u2026\u3002",
  "id" : 68977560570183680,
  "created_at" : "2011-05-13 09:55:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68975362813599744",
  "text" : "\u3042\u306E\u82B1\u3068C\u4E21\u65B9\uFF15\u8A71\u898B\u7D42\u3048\u305F\u3002\u5168\u7136\u9055\u3046\u4E8C\u4F5C\u3060\u3051\u3069\u3001\u3069\u3063\u3061\u3082\u9762\u767D\u3044\u3002",
  "id" : 68975362813599744,
  "created_at" : "2011-05-13 09:46:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68709715470856194",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 68709715470856194,
  "created_at" : "2011-05-12 16:10:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68709667735474176",
  "text" : "\u5BDD\u308B\u3002\u4ECA\u65E5\u4E00\u9650\u3060\u3057\u306A\u3041\u3002\u7D50\u5C40\u30B3\u30F3\u30D7\u30ED\u3082\u4E00\u90E8\u7D42\u308F\u3089\u305A\u2026\u3002",
  "id" : 68709667735474176,
  "created_at" : "2011-05-12 16:10:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68709480770191360",
  "text" : "\u3053\u308C\u306F\u3072\u3069\u3044\u3002\u306A\u3093\u3068\u3044\u3046\u304B\u6587\u7AE0\u306B\u3057\u3066\u898B\u308B\u3068\u306A\u304A\u3072\u3069\u3044\u3002\u7814\u7A76\u30C6\u30FC\u30DE\u3068\u3057\u3066\u306F\u304A\u3082\u3057\u308D\u3044\u306E\u304B\u3082\u3057\u308C\u306A\u3044\u304C\u2026",
  "id" : 68709480770191360,
  "created_at" : "2011-05-12 16:09:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 110, 121 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68709314684133376",
  "text" : "BL\u306F\u7537\u6027\u540C\u58EB\u306E\u76F4\u63A5\u7684\u306A\u30A8\u30ED\u30C6\u30A3\u30B7\u30BA\u30E0\u8868\u73FE\u304C\u542B\u307E\u308C\u307E\u3059\u3002\u305D\u308C\u306B\u3064\u3044\u3066\u306E\u5206\u6790\u3092\u3001\u53E3\u982D\u3067\u767A\u8868\u3057\u3066\u3082\u3089\u3046\u3053\u3068\u3082\u3042\u308A\u307E\u3059\u3002\u305D\u3046\u3044\u3063\u305F\u3082\u306E\u304C\u3001\u82E6\u624B\u3001\u62B5\u6297\u304C\u3042\u308B\u3068\u3044\u3046\u65B9\u3001BL\u3092\u5168\u304F\u672A\u8AAD\u306A\u65B9\u306F\u5145\u5206\u8003\u3048\u3066\u304B\u3089\u5C65\u4FEE\u3092\u9078\u629E\u3057\u3066\u4E0B\u3055\u3044\u3002RT @magokoro84\nhttp:\/\/ht.ly\/1QErA",
  "id" : 68709314684133376,
  "created_at" : "2011-05-12 16:09:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68708009022464000",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 68708009022464000,
  "created_at" : "2011-05-12 16:04:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68707955079520256",
  "text" : "\u305F\u3060\u3001\u591C\u4E2D\u306B\u3053\u306E\u6F2B\u753B\u3092\u8AAD\u3080\u3068\u3080\u3063\u3061\u3083\u304A\u306A\u304B\u304C\u6E1B\u308B\u30FB\u30FB\u30FB\u308F\u304B\u3063\u3066\u3066\u3082\u3075\u3068\u958B\u3044\u3066\u3057\u307E\u3046\u306E\u3060\u3051\u308C\u3069\u3002http:\/\/goo.gl\/pIYlC",
  "id" : 68707955079520256,
  "created_at" : "2011-05-12 16:03:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68707321139834880",
  "text" : "\u305D\u3082\u305D\u3082\u6F2B\u753B\u306F\u300C\u4F55\u304C\u9762\u767D\u3044\u306E\u304B\u8AAC\u660E\u3067\u304D\u306A\u3044\u9762\u767D\u3055\uFF5D\u306A\u308F\u3051\u3060\u304B\u3089\u6620\u50CF\u5316\u306F\u307E\u305A\u7121\u7406\u3060\u308D\u3046\u306A\u3001\u30A2\u30CB\u30E1\u3067\u3082\u7121\u7406\u3060\u3068\u601D\u3046\u30EC\u30D9\u30EB\u3002",
  "id" : 68707321139834880,
  "created_at" : "2011-05-12 16:01:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68707071524208640",
  "text" : "\u6F14\u6280\u304C\u3078\u305F\u3063\u3066\u306E\u306F\u3042\u308B\u3051\u3069\u539F\u4F5C\u901A\u308A\u3067\u3053\u3053\u307E\u3067\u539F\u4F5C\u6BBA\u3057\u306A\u6620\u50CF\u5316\u3082\u306A\u3044\u306A http:\/\/www.youtube.com\/watch?v=XsDmjljbHSU",
  "id" : 68707071524208640,
  "created_at" : "2011-05-12 16:00:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68698909861617664",
  "text" : "PC\u91CD\u3059\u304E\u2026\u5BDD\u308D\u3063\u3066\u4E8B\u304B\u306A",
  "id" : 68698909861617664,
  "created_at" : "2011-05-12 15:27:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68677748029263872",
  "text" : "[Memo]http:\/\/www.kuins.kyoto-u.ac.jp\/KUINS3\/pptp\/macos\/ipod_touch\/",
  "id" : 68677748029263872,
  "created_at" : "2011-05-12 14:03:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082\u3063\u304F\u3059\uFF20\u6771\u4EAC\u4EBA\u306B\u306A\u308A\u307E\u3057\u305F",
      "screen_name" : "o_tomox",
      "indices" : [ 0, 8 ],
      "id_str" : "145247946",
      "id" : 145247946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68659778724966400",
  "geo" : { },
  "id_str" : "68675687283834880",
  "in_reply_to_user_id" : 145247946,
  "text" : "@o_tomox \u307E\u3060\u307E\u3060\u3084\u308A\u59CB\u3081\u305F\u3070\u3063\u304B\u308A\u3067\u3057\u3066\u2026\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059m(_ _)m",
  "id" : 68675687283834880,
  "in_reply_to_status_id" : 68659778724966400,
  "created_at" : "2011-05-12 13:55:34 +0000",
  "in_reply_to_screen_name" : "o_tomox",
  "in_reply_to_user_id_str" : "145247946",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68675421167824896",
  "text" : "@np2i \u8FD4\u4FE1\u9045\u304F\u306A\u3063\u3066\u3059\u307F\u307E\u305B\u3093\u3002\u7406\u89E3\u3057\u3084\u3059\u3044\u305F\u3068\u3048\u3067\u975E\u5E38\u306B\u52A9\u304B\u308A\u307E\u3059\u3001\u307E\u3060\u77ED\u3044\u7C21\u5358\u306A\u30D7\u30ED\u30B0\u30E9\u30DF\u30F3\u30B0\u3070\u304B\u308A\u306A\u306E\u3067gets\u3067\u3082\u554F\u984C\u306A\u3055\u305D\u3046\u3067\u3059\u306D\u3002\u9055\u3044\u3092\u7406\u89E3\u3057\u3064\u3064\u3082\u3046\u3061\u3087\u3063\u3068\u3044\u308D\u3044\u308D\u5F04\u3063\u3066\u307F\u307E\u3059\u3002\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 68675421167824896,
  "created_at" : "2011-05-12 13:54:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68653230040678400",
  "text" : "@np2i \u305D\u3046\u3067\u3059\u3002\u307B\u3093\u306E\u3084\u308A\u59CB\u3081\u3067\u53F3\u3082\u5DE6\u3082\u826F\u304F\u308F\u304B\u308A\u307E\u305B\u3093\u304C\u2026\u3002",
  "id" : 68653230040678400,
  "created_at" : "2011-05-12 12:26:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68653102814855168",
  "text" : "\u6388\u696D\u3067\u51FA\u3066\u304D\u305Fscanf\u3063\u3066\u306E\u304C\u4ECA\u4E00\u3064\u308F\u304B\u3093\u306A\u304F\u3066\u7D50\u5C40gets\u4F7F\u3063\u3061\u3083\u3063\u305F\u3057\u2026\u307E\u3060\u307E\u3060\u8AB2\u984C\u306F\u5C71\u7A4D\u307F\u304B\u3002",
  "id" : 68653102814855168,
  "created_at" : "2011-05-12 12:25:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68652368119607296",
  "text" : "\u221A\u3068\u304B\u3069\u3046\u3084\u3063\u3066\u8868\u793A\u3059\u308B\u3093\u3060\u3088\u2026\u3002\u3059\u3052\u30FC\u96D1\u3063\u3066\u304B\u982D\u306E\u60AA\u305D\u3046\u306A\u30D7\u30ED\u30B0\u30E9\u30E0\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F\u3002if\u6587\u306F\u4F7F\u3048\u308B\u3088\u3046\u306B\u306A\u3063\u305F\u3068\u601D\u3046\u3051\u3069\u3002",
  "id" : 68652368119607296,
  "created_at" : "2011-05-12 12:22:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68651581884727296",
  "text" : "\u8AB2\u984C\u3067\u4E8C\u6B21\u95A2\u6570\u306E\u89E3\u3092\u5F3E\u304D\u51FA\u3059\u30D7\u30ED\u30B0\u30E9\u30E0\u4F5C\u3063\u305F\u3051\u3069\u8272\u3005\u6B8B\u5FF5\u3002\u4E00\u5FDC\u52D5\u304F\u3051\u3069\u2026\u3002",
  "id" : 68651581884727296,
  "created_at" : "2011-05-12 12:19:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68509489812344832",
  "geo" : { },
  "id_str" : "68509618950778880",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u306A\u3093\u3067\u307E\u305F\u2026",
  "id" : 68509618950778880,
  "in_reply_to_status_id" : 68509489812344832,
  "created_at" : "2011-05-12 02:55:40 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68506410664738816",
  "text" : "\u84B8\u3059\u306A\u3041\u2026",
  "id" : 68506410664738816,
  "created_at" : "2011-05-12 02:42:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 9, 20 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68502563674275840",
  "text" : "\u5BDD\u3066\u308B\u3057\uFF57 RT @magokoro84: \u8B1B\u7FA9\u306B\u96C6\u4E2D\u3057\u307E\u3059\u306D",
  "id" : 68502563674275840,
  "created_at" : "2011-05-12 02:27:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68412755945857026",
  "text" : "\u3061\u3083\u3093\u3068\u5BDD\u305F\u6C17\u304C\u3057\u306A\u3044\u306E\u306B\u666E\u6BB5\u3088\u308A\u65E9\u8D77\u304D\u3063\u3066\u306E\u3082\u307E\u305F\u30D1\u30E9\u30C9\u30AD\u30B7\u30AB\u30EB\u304B\u3002\u3082\u3046\u4E00\u7720\u308A\u2026\u3002",
  "id" : 68412755945857026,
  "created_at" : "2011-05-11 20:30:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68412543739240448",
  "text" : "\u7720\u308C\u306A\u3044\u5922\u3063\u3066\u3044\u3046\u30D1\u30E9\u30C9\u30AD\u30B7\u30AB\u30EB\u306A\u5922\u3092\u898B\u305F\u3002\u3084\u3063\u3068\u7720\u308C\u305F\u3068\u601D\u3063\u305F\u3089\u3089\u3001\u3068\u3093\u3067\u3082\u306A\u3044\u30CB\u30E5\u30FC\u30B9\u3067\u305F\u305F\u304D\u8D77\u3053\u3055\u308C\u308B\u3001\u3068\u3044\u3046\u5922\u3060\u3063\u305F\u3002\u3061\u3083\u3093\u3068\u5BDD\u305F\u6C17\u304C\u3057\u306A\u3044\u3002",
  "id" : 68412543739240448,
  "created_at" : "2011-05-11 20:29:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68346200927117312",
  "text" : "\u30CD\u30BF\u305D\u306E\u3082\u306E\u306F\u304A\u3082\u3057\u308D\u3044\u306E\u3060\u3051\u308C\u3069\u3002\u306D\u3002",
  "id" : 68346200927117312,
  "created_at" : "2011-05-11 16:06:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68346107654193152",
  "text" : "\u6563\u3005\u98F2\u307F\u4F1A\u30CD\u30BF\u8AAD\u3093\u3060\u3051\u3069\u3069\u306E\u30AF\u30E9\u30B9\u30BF\u3067\u3082\u4E00\u6C17\u30B3\u30FC\u30EB\u304C\u3042\u308B\u3088\u3046\u306A\u98F2\u307F\u4F1A\u306F\u5ACC\u3044\u3067\u3059\u3002",
  "id" : 68346107654193152,
  "created_at" : "2011-05-11 16:05:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68345089935683584",
  "text" : "RT @magokoro84: RT \u6587\u8C6A\u30A4\u30C3\u30AD\u30B3\u30FC\u30EB-\u307E\u3068\u3081 http:\/\/togetter.com\/li\/134238",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68344509850861568",
    "text" : "RT \u6587\u8C6A\u30A4\u30C3\u30AD\u30B3\u30FC\u30EB-\u307E\u3068\u3081 http:\/\/togetter.com\/li\/134238",
    "id" : 68344509850861568,
    "created_at" : "2011-05-11 15:59:35 +0000",
    "user" : {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "protected" : false,
      "id_str" : "213268728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598083357839265792\/q6CsfIW__normal.jpg",
      "id" : 213268728,
      "verified" : false
    }
  },
  "id" : 68345089935683584,
  "created_at" : "2011-05-11 16:01:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68343613062520832",
  "text" : "\u4ECA\u65E5\u96E8\u3058\u3083\u306A\u3051\u308C\u3070\u30CE\u30FC\u30C8\uFF30\uFF23\u3082\u3063\u3066\u3063\u3066\u6388\u696D\u4E2D\u306B\u5185\u8077\u3067\u304D\u308B\u306E\u306B\u2026",
  "id" : 68343613062520832,
  "created_at" : "2011-05-11 15:56:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 6, 16 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68342251289448448",
  "text" : "\u5FA9\u7FD2\u2026RT @end313124: \u5927\u5B66\u306E\u30B9\u30D1\u30B3\u30F3\u306E\u30A8\u30C7\u30A3\u30BF\u3068\u304B\u30B3\u30F3\u30D1\u30A4\u30E9\u3059\u3054\u304F\u4F7F\u3044\u306B\u304F\u304B\u3063\u305F\u304B\u3089\u5FA9\u8B90\u3057\u306A\u3044\u3068\u30D7\u30ED\u30B0\u30E9\u30E0\u4EE5\u524D\u306E\u554F\u984C\u3067\u8A70\u3080\u3002",
  "id" : 68342251289448448,
  "created_at" : "2011-05-11 15:50:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68342072213643264",
  "text" : "\u5927\u5B66\u306E\u30B9\u30D1\u30B3\u30F3\u306E\u30A8\u30C7\u30A3\u30BF\u3068\u304B\u30B3\u30F3\u30D1\u30A4\u30E9\u3059\u3054\u304F\u4F7F\u3044\u306B\u304F\u304B\u3063\u305F\u304B\u3089\u5FA9\u8B90\u3057\u306A\u3044\u3068\u30D7\u30ED\u30B0\u30E9\u30E0\u4EE5\u524D\u306E\u554F\u984C\u3067\u8A70\u3080\u3002",
  "id" : 68342072213643264,
  "created_at" : "2011-05-11 15:49:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68341824883916800",
  "text" : "\u660E\u65E5\u5317\u306E\u30E1\u30C7\u30A3\u30BB\u30F3\u3067\u6708\u66DC\u5206\u306E\u6388\u696D\u306E\u30C7\u30FC\u30BF\u3092\u3082\u3089\u304A\u3046\u3002",
  "id" : 68341824883916800,
  "created_at" : "2011-05-11 15:48:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68335789997703169",
  "text" : "\u4E0B\u3089\u3093\u3053\u3068\u3057\u3066\u306A\u3044\u3067\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u3061\u3063\u3068\u306F\u751F\u7523\u7684\u306A\u6D3B\u52D5\u3092\u3057\u3088\u3046\u3002",
  "id" : 68335789997703169,
  "created_at" : "2011-05-11 15:24:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/tiHkL8V",
      "expanded_url" : "http:\/\/vipvipblogblog.blog119.fc2.com\/blog-entry-289.html",
      "display_url" : "vipvipblogblog.blog119.fc2.com\/blog-entry-289\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "68335450166800384",
  "text" : "\u30D7\u30ED\u30B0\u30E9\u30DE\u30FC\u3063\u3066\u751F\u304D\u7269\u304C\u826F\u304F\u308F\u304B\u3089\u306A\u304F\u306A\u3063\u305F\u3002\n \u30D9\u30A2\u901F \u3010\u30D7\u30ED\u30B0\u30E9\u30DE\u30FC\u677F\u3011\u5370\u8C61\u306B\u6B8B\u3063\u305F\u30B3\u30E1\u30F3\u30C8\u3092\u6652\u305B http:\/\/t.co\/tiHkL8V",
  "id" : 68335450166800384,
  "created_at" : "2011-05-11 15:23:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68329405704974336",
  "geo" : { },
  "id_str" : "68330509209575424",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u304A\u59C9\u3055\u3093\u9811\u5F35\u308A\u3059\u304E\u308B\u304D\u3089\u3044\u304C\u3042\u308B\u304B\u3089\u4F11\u3080\u6642\u306F\u4F11\u3093\u3067\u306D\u3002\u307B\u3093\u3068\u306B\u3002",
  "id" : 68330509209575424,
  "in_reply_to_status_id" : 68329405704974336,
  "created_at" : "2011-05-11 15:03:57 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68329888339329025",
  "text" : "\u897F\u307E\u3067\u306F\u30C0\u30E1\u304B\u3002 \uFF2A\uFF32\u6771\u3001\uFF11\u4E07\u5186\u3067\u4E00\u65E5\u4E57\u308A\u653E\u984C\u306E\u5207\u7B26\u767A\u58F2\nhttp:\/\/www.news24.jp\/articles\/2011\/05\/11\/07182529.html",
  "id" : 68329888339329025,
  "created_at" : "2011-05-11 15:01:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/news.nicovideo.jp\/\" rel=\"nofollow\"\u003E\u30CB\u30B3\u30CB\u30B3\u30CB\u30E5\u30FC\u30B9\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "niconews",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68329123063410689",
  "text" : "\u3053\u306E\u6388\u696D\u53D6\u3063\u3066\u308C\u3070\u6563\u3005\u30CD\u30BF\u306B\u3067\u304D\u305F\u306E\u306B\u306A\u3041\u2026 &lt;\u300C\u30CB\u30B3\u30DE\u30B9\u306F\u9AD8\u5EA6\u306A\u6559\u80B2\u30B7\u30B9\u30C6\u30E0\u3092\u5099\u3048\u3066\u3044\u308B\u300D\u4EAC\u90FD\u5927\u5B66\u3067\u300C\u30A2\u30A4\u30DE\u30B9\u300D\u8B1B\u7FA9\u3092\u3057\u305F\u5148\u751F\u306B\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC&gt; http:\/\/nico.ms\/nw5416 #niconews",
  "id" : 68329123063410689,
  "created_at" : "2011-05-11 14:58:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68328490746912768",
  "text" : "\u5B9F\u969B\u4F5C\u308B\u304B\u306F\u5FAE\u5999\u3060\u3051\u3069\uFF08\u4EBA\u304C\u96C6\u307E\u3063\u305F\u3089\u8003\u3048\u308B\uFF09\u6570\u5B66\u30B5\u30FC\u30AF\u30EB\u306E\u5275\u7ACB\u8005\u304C\u6587\u5B66\u90E8\u3063\u3066\u4F55\u3068\u3082\u8A00\u3048\u306A\u3044\u3088\u306D\u3002\u3046\u3093\u3002",
  "id" : 68328490746912768,
  "created_at" : "2011-05-11 14:55:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68326320597241856",
  "text" : "\u9664\u6E7F\u6A5F\u6B32\u3057\u3044\u306A\u3002\u9664\u6E7F\u6A5F\u2026\u306A\u3093\u3066\u7D20\u6570\u306A\u97FF\u304D\uFF01",
  "id" : 68326320597241856,
  "created_at" : "2011-05-11 14:47:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68326043492163584",
  "text" : "\u30AD\u30E7\u30ED\u3061\u3083\u3093\u306E\u30B3\u30B9\u30D7\u30EC\u2026\uFF1F",
  "id" : 68326043492163584,
  "created_at" : "2011-05-11 14:46:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68325841695801344",
  "text" : "\u3042\u3001\u305F\u3060\u3044\u307E\u3002",
  "id" : 68325841695801344,
  "created_at" : "2011-05-11 14:45:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "math",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "KU",
      "indices" : [ 61, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68325796162453504",
  "text" : "\uFF2B\uFF35\u3067\u6587\u7406\u306B\u958B\u304B\u308C\u305F\u6570\u5B66\u30B5\u30FC\u30AF\u30EB\u4F5C\u3063\u305F\u3089\uFF08\u7814\u7A76\u4F1A\u307F\u305F\u3044\u306A\u5805\u82E6\u3057\u3044\u306E\u3067\u306A\u304F\uFF09\u5165\u3063\u3066\u304F\u308C\u308B\u4EBA\u306F\u3044\u308B\u306E\u3060\u308D\u3046\u304B\u2026\u3002 #math\u3000#KU",
  "id" : 68325796162453504,
  "created_at" : "2011-05-11 14:45:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68255775121883136",
  "text" : "RT @tameninaru: 1t\u306E\u5EC3\u68C4\u30D1\u30BD\u30B3\u30F3\u304B\u3089\u7D0414g\u3001\u5EC3\u68C4\u30CE\u30FC\u30C8\u30D1\u30BD\u30B3\u30F3\u304B\u3089\u7D0492g\u306E\u91D1\u304C\u3068\u308C\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68254032443092992",
    "text" : "1t\u306E\u5EC3\u68C4\u30D1\u30BD\u30B3\u30F3\u304B\u3089\u7D0414g\u3001\u5EC3\u68C4\u30CE\u30FC\u30C8\u30D1\u30BD\u30B3\u30F3\u304B\u3089\u7D0492g\u306E\u91D1\u304C\u3068\u308C\u308B",
    "id" : 68254032443092992,
    "created_at" : "2011-05-11 10:00:04 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 68255775121883136,
  "created_at" : "2011-05-11 10:06:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68255380358172672",
  "text" : "\u30D2\u30B6\u3068\u80CC\u4E2D\u3060\u3051\u6FE1\u308C\u3066\u6E7F\u3063\u3066\u304D\u3082\u3061\u308F\u308B\u3044\u2026",
  "id" : 68255380358172672,
  "created_at" : "2011-05-11 10:05:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Gounot",
      "screen_name" : "nico_reflexio",
      "indices" : [ 0, 14 ],
      "id_str" : "252811894",
      "id" : 252811894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68254985573515265",
  "text" : "@nico_reflexio \u30B5\u30B6\u30A8\u3055\u3093\u304B\uFF57\uFF57",
  "id" : 68254985573515265,
  "created_at" : "2011-05-11 10:03:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68249623961153537",
  "geo" : { },
  "id_str" : "68254908008243200",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u304A\u5927\u4E8B\u306B\u2026",
  "id" : 68254908008243200,
  "in_reply_to_status_id" : 68249623961153537,
  "created_at" : "2011-05-11 10:03:32 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68246198506627072",
  "text" : "\u96E8\u306E\u4E2D\u30D0\u30A4\u30C8\u304B\u3002\u884C\u3063\u3066\u304D\u307E\u3059\u3002",
  "id" : 68246198506627072,
  "created_at" : "2011-05-11 09:28:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68217887474724864",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046",
  "id" : 68217887474724864,
  "created_at" : "2011-05-11 07:36:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 15, 27 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68217835897356289",
  "text" : "\u3067\u3082\u541B\u30DA\u30F3\u30AE\u30F3\u3060\u3088\u306D\u2026 RT @nisehorrrrn: JR\u897F\u65E5\u672C\u306F\u304A\u72AC\u69D8\u5C02\u7528\u8ECA\u4E21\u3064\u304F\u3063\u305F\u3089\u672C\u6C17\u51FA\u3059",
  "id" : 68217835897356289,
  "created_at" : "2011-05-11 07:36:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68177607404949504",
  "text" : "\u304A\u663C\u5BDD 16\u6642\u307E\u3067\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 68177607404949504,
  "created_at" : "2011-05-11 04:56:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68007253168496640",
  "text" : "\u307E\u30FC\u3044\u30FC\u3084\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 68007253168496640,
  "created_at" : "2011-05-10 17:39:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68007149527248896",
  "text" : "\u4E8C\u9650\u5E30\u3063\u3066\u304D\u305F\u3089\u663C\u5BDD\u3002\u3068\u601D\u3063\u305F\u3051\u3069\u751F\u6D3B\u30EA\u30BA\u30E0\u5D29\u308C\u308B\u304B\u306A\u3041\u30FB\u30FB\u30FB\u3002",
  "id" : 68007149527248896,
  "created_at" : "2011-05-10 17:39:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68007005884915712",
  "text" : "\u5BDD\u308B\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002\u4ECA\u65E5\u306F\u4E8C\u9650\u5BDD\u574A\u3057\u306A\u3044\u2026\u3064\u3082\u308A\u3002",
  "id" : 68007005884915712,
  "created_at" : "2011-05-10 17:38:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 36, 46 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68006409245167616",
  "text" : "\u30C4\u30A4\u30FC\u30C8\u6570\uFF1A1643\u00F7\u30D5\u30A9\u30ED\u30EF\u30FC\u6570\uFF1A63\u00D7\u30D5\u30A9\u30ED\u30FC\u6570\uFF1A104\u00F7100\uFF1D @end313124 \u306E\u30C4\u30A4\u30C3\u30BF\u30FC\u4F9D\u5B58\u5EA6\uFF1A27.1 \uFF05\n\u666E\u901A\u3002",
  "id" : 68006409245167616,
  "created_at" : "2011-05-10 17:36:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67982579927756801",
  "text" : "\u305D\u3057\u305F\u3089\u307B\u3068\u3093\u3069\u8DA3\u5473\u306E\u4E00\u5E74\u304B\u3001\u305D\u308A\u3083\u3042\u697D\u3057\u304B\u3063\u305F\u308F\u3051\u3060\u306A\u3002",
  "id" : 67982579927756801,
  "created_at" : "2011-05-10 16:01:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 19, 30 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67982424457486336",
  "text" : "\u4E8C\u6587\u76EE\u306E\u4E16\u754C\u53F2\u3092\u6570\u5B66\u306B\u3057\u305F\u3089\u4FFA RT @magokoro84: \u6D6A\u4EBA\u6642\u4EE3\u306F\u6570\u5B66\u30E1\u30A4\u30F3\u3060\u3063\u305F\u306A\u3000\u82F1\u8A9E\u306F\u5F97\u610F\u3060\u304B\u3089\u307C\u3061\u307C\u3061\u3057\u304B\u3084\u3063\u3066\u306A\u304B\u3063\u305F\u3057\u3001\u4E16\u754C\u53F2\u306F\u307B\u3068\u3093\u3069\u8DA3\u5473\u3060\u3063\u305F\u3057",
  "id" : 67982424457486336,
  "created_at" : "2011-05-10 16:00:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67981972898709504",
  "text" : "@haru_urah_rah \u9589\u9396\u3058\u3083\u306A\u304F\u3066\u653E\u7F6E\u3058\u3083\u3060\u3081\u3067\u3059\u304B\u306D\uFF1F\u653E\u7F6E\u3060\u3068\u82E5\u5E72\u81EA\u5206\u3068\u306E\u6226\u3044\u306B\u3082\u306A\u308A\u307E\u3059\u304C\u2026\u3002",
  "id" : 67981972898709504,
  "created_at" : "2011-05-10 15:59:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305B\u3089\u307E\u3088\u3074",
      "screen_name" : "seramayo",
      "indices" : [ 17, 26 ],
      "id_str" : "112916269",
      "id" : 112916269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67981536561086464",
  "text" : "RT @Yamasui2914: @seramayo \u98F2\u307E\u305B\u305F\u304C\u3063\u3066\u308B\u4EBA\u300C\u4E7E\u676F\u3063\u3066\u3069\u3046\u3044\u3046\u6F22\u5B57\u304B\u77E5\u3063\u3066\u308B\u3088\u306D\uFF1F\u300D\u6587\u5B66\u90E8\u751F\u300C\u78BA\u304B\u306B\u300E\u4E7E\u676F\u300F\u306E\u8A9E\u6E90\u306F\u676F\u3092\u4E7E\u304B\u3059\u3053\u3068\u3067\u3042\u308A\u3001\u6559\u6761\u4E3B\u7FA9\u7684\u306A\u300C\u4E7E\u676F\u300D\u5B9F\u884C\u8005\u306F\u305D\u306E\u3053\u3068\u306B\u56FA\u57F7\u3059\u308B\u3002\u3057\u304B\u3057\u3001\u305D\u308C\u306F\u30B7\u30F3\u30DC\u30EA\u30C3\u30AF\u306A\u76F8\u4E92\u4F5C\u7528\u3092\u901A\u3057\u3066\u65E5\u3005\u518D\u751F\u7523\u3055\u308C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u305B\u3089\u307E\u3088\u3074",
        "screen_name" : "seramayo",
        "indices" : [ 0, 9 ],
        "id_str" : "112916269",
        "id" : 112916269
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "67964573298343936",
    "geo" : { },
    "id_str" : "67978349762461696",
    "in_reply_to_user_id" : 112916269,
    "text" : "@seramayo \u98F2\u307E\u305B\u305F\u304C\u3063\u3066\u308B\u4EBA\u300C\u4E7E\u676F\u3063\u3066\u3069\u3046\u3044\u3046\u6F22\u5B57\u304B\u77E5\u3063\u3066\u308B\u3088\u306D\uFF1F\u300D\u6587\u5B66\u90E8\u751F\u300C\u78BA\u304B\u306B\u300E\u4E7E\u676F\u300F\u306E\u8A9E\u6E90\u306F\u676F\u3092\u4E7E\u304B\u3059\u3053\u3068\u3067\u3042\u308A\u3001\u6559\u6761\u4E3B\u7FA9\u7684\u306A\u300C\u4E7E\u676F\u300D\u5B9F\u884C\u8005\u306F\u305D\u306E\u3053\u3068\u306B\u56FA\u57F7\u3059\u308B\u3002\u3057\u304B\u3057\u3001\u305D\u308C\u306F\u30B7\u30F3\u30DC\u30EA\u30C3\u30AF\u306A\u76F8\u4E92\u4F5C\u7528\u3092\u901A\u3057\u3066\u65E5\u3005\u518D\u751F\u7523\u3055\u308C\u308B\u610F\u5473\u3067\u306E\u300E\u4E7E\u676F\u300F\u3092\u7121\u8996\u3057\u3057\u3001\u307E\u305F\u76F8\u624B\u65B9\u306E",
    "id" : 67978349762461696,
    "in_reply_to_status_id" : 67964573298343936,
    "created_at" : "2011-05-10 15:44:36 +0000",
    "in_reply_to_screen_name" : "seramayo",
    "in_reply_to_user_id_str" : "112916269",
    "user" : {
      "name" : "\u91CE\u6D32\u6F64\u4E00\u90CE",
      "screen_name" : "Yasu9412",
      "protected" : false,
      "id_str" : "136046006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606516929709391873\/xRrEmoJb_normal.jpg",
      "id" : 136046006,
      "verified" : false
    }
  },
  "id" : 67981536561086464,
  "created_at" : "2011-05-10 15:57:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67978420038021120",
  "geo" : { },
  "id_str" : "67980297026805761",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u3042\u306A\u305F\u3068\u30A2\u30A4\u30B3\u30F3\u304C\u4E00\u7DD2\u306E\u30CD\u30BFbot\u304C\u3042\u308B\u304B\u3089\u305D\u308C\u304B\u3068\u601D\u3063\u305F\u308F",
  "id" : 67980297026805761,
  "in_reply_to_status_id" : 67978420038021120,
  "created_at" : "2011-05-10 15:52:20 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67979682737438720",
  "text" : "\u5E30\u3063\u3066\u304D\u305F\u3002\u98A8\u5442\u4E0A\u308A\u306B\u51B7\u3048\u305F\u30DA\u30EA\u30A8\u3002\u3055\u3055\u3084\u304B\u306A\u5E78\u305B\u3002",
  "id" : 67979682737438720,
  "created_at" : "2011-05-10 15:49:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67974017239359488",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u3044\u3063\u305F\u3093\u96E2\u8131\u3000\u30CE\u30B7",
  "id" : 67974017239359488,
  "created_at" : "2011-05-10 15:27:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67973938692628480",
  "text" : "\u65E9\u3044\u3053\u3068\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u306A\u304D\u3083\u3002",
  "id" : 67973938692628480,
  "created_at" : "2011-05-10 15:27:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67973835978309633",
  "text" : "\u3080\u3045\u3002\u3002\u3002\u30B5\u30FC\u30AF\u30EB\u7D42\u308F\u308B\u306E\u3082\u30A2\u30D5\u30BF\u30FC\u7D42\u308F\u308B\u306E\u3082\u9045\u304B\u3063\u305F\u305B\u3044\u3067\u3082\u3046\u65E5\u4ED8\u5909\u3063\u3066\u308B\u306E\u304B\u3041\u3002\u307E\u3060\uFF12\uFF12\u6642\u304F\u3089\u3044\u306E\u611F\u899A\u306A\u306E\u3060\u3051\u308C\u3069\u3002",
  "id" : 67973835978309633,
  "created_at" : "2011-05-10 15:26:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67972607877722113",
  "geo" : { },
  "id_str" : "67972827608920064",
  "in_reply_to_user_id" : 239811064,
  "text" : "@sugiyama1990 \u30BB\u30F3\u30B9\u3042\u3063\u305F\u3093\u3067\u30D5\u30A9\u30ED\u30FC\u3055\u305B\u3066\u3082\u3089\u3044\u307E\u3057\u305F\u3002\u3088\u308D\u3057\u304F\u30FC\u3002",
  "id" : 67972827608920064,
  "in_reply_to_status_id" : 67972607877722113,
  "created_at" : "2011-05-10 15:22:39 +0000",
  "in_reply_to_screen_name" : "sugi3_34",
  "in_reply_to_user_id_str" : "239811064",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67971740998959104",
  "geo" : { },
  "id_str" : "67972171103862786",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u7D76\u5BFE\u72D9\u3044\u6483\u3061\u3060\u3068\u601D\u3063\u305F\u3088\u3001\u3069\u3046\u307F\u3066\u3082\u8DA3\u5473\u304C\u4FFA\u597D\u307F\u3060\u3082\u306E\u3002\u3044\u3084\u3001\u5225\u306E\u4EBA\u306B\u3075\u3089\u308C\u305F\u304B\u3089\u8003\u3048\u3066\u307F\u305F\u3093\u3060\u3051\u3069\u3055\u3063\u3071\u308A\u30C0\u30E1\u3060\u308F\u3002",
  "id" : 67972171103862786,
  "in_reply_to_status_id" : 67971740998959104,
  "created_at" : "2011-05-10 15:20:03 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67971303956684800",
  "text" : "\u3082\u3046\u3073\u3076\u3093\u30FB\u305B\u304D\u3076\u3093\u5B66\u90E8\u3067\u3044\u3044\u3084\u3002\u3046\u3093\u3002",
  "id" : 67971303956684800,
  "created_at" : "2011-05-10 15:16:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67971137207939072",
  "text" : "\u6587\u5B66\u90E8\u3063\u3066\u5C02\u9580\u306B\u306A\u308B\u7BC4\u56F2\u5E83\u3059\u304E\u3066\u300C\u6587\u5B66\u90E8\u3063\u307D\u3044\u300D\u30D5\u30EC\u30FC\u30BA\u306A\u3044\u3088\u306A\u30FC\u3002\u305D\u3082\u305D\u3082\u4FFA\u81EA\u8EAB\u304C\u6587\u5B66\u90E8\u3063\u307D\u304F\u306A\u3044\u3057\u3002",
  "id" : 67971137207939072,
  "created_at" : "2011-05-10 15:15:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67970792578756608",
  "text" : "\u5927\u4F53\u5927\u4EBA\u6570\u306E\u98F2\u307F\u4F1A\u597D\u304D\u3058\u3083\u306A\u3044\u4E0A\u306B\u6587\u5B66\u90E8\u304C\u6BCD\u4F53\u306B\u306A\u3063\u305F\u98F2\u307F\u4F1A\u306B\u53C2\u52A0\u3057\u305F\u3053\u3068\u306A\u3044\u3058\u3083\u3093\u3002\u601D\u3044\u6D6E\u304B\u3070\u306A\u3044\u3063\u3066orz",
  "id" : 67970792578756608,
  "created_at" : "2011-05-10 15:14:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67970388352700416",
  "text" : "\u3053\u3046\u3044\u3046\u306E\u3063\u3066\u6D41\u308C\u3068\u52E2\u3044\u3067\u51FA\u3066\u304D\u305F\u3084\u3064\u306E\u304C\u9762\u767D\u3044\u3082\u3093\u306A\u30FC\u3002\u982D\u62B1\u3048\u305F\u6BB5\u968E\u3067\u30CD\u30BF\u304C\u6B7B\u3093\u3067\u3044\u304F\u2026\u3002",
  "id" : 67970388352700416,
  "created_at" : "2011-05-10 15:12:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67970219548745728",
  "text" : "\u6587\u5B66\u90E8\u98F2\u307F\u4F1A\u30CD\u30BF\u8003\u3048\u3066\u308B\u3051\u3069\n\u300C\u305D\u308C\u3067\u3082\u9152\u306F\u56DE\u3063\u3066\u3044\u308B\u300D\n\u300C\u79C1\u306F\u3053\u306E\u98F2\u307F\u4F1A\u3092\u76DB\u308A\u4E0A\u3052\u308B\u771F\u306B\u9A5A\u304F\u3079\u304D\u65B9\u6CD5\u3092\u898B\u3064\u3051\u305F\u304C\u79C1\u306E\u8840\u4E2D\u30A2\u30EB\u30B3\u30FC\u30EB\u6FC3\u5EA6\u306F\u4F4E\u3059\u304E\u308B\u300D\n\u300C\u60AA\u9154\u3044\u3082\u307E\u305F\u9154\u3044\u306A\u308A\u300D\n\u79D1\u5B66\u30FB\u54F2\u5B66\u8005\u306E\u6C17\u306E\u5229\u304B\u306A\u3044\u5FAE\u5999\u306A\u30BB\u30EA\u30D5\u3057\u304B\u51FA\u3066\u3053\u306A\u3044orz",
  "id" : 67970219548745728,
  "created_at" : "2011-05-10 15:12:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67967180343476225",
  "text" : "@mo5nya \u304A\u59C9\u3055\u3093\u3060\u3063\u3066\u6587\u5B66\u90E8\u3067\u3057\u3087\u3046\uFF1F\u50D5\u306B\u306F\u6587\u5B66\u90E8\u306E\u30CD\u30BF\u306F\u3059\u3089\u3063\u3068\u51FA\u3066\u304D\u307E\u305B\u3093\u3088\u3045\u30FB\u30FB\u30FB\u3002\u3082\u3046\u3061\u3087\u3063\u3068\u8003\u3048\u307E\u3059\u3002",
  "id" : 67967180343476225,
  "created_at" : "2011-05-10 15:00:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67964948109721600",
  "text" : "\u4ECA\u9031\u305A\u3063\u3068\u96E8\u30A7\u2026\u305F\u3060\u3067\u3055\u3048\u9AD8\u304F\u306A\u3044\u30C6\u30F3\u30B7\u30E7\u30F3\u304C\u5358\u8ABF\u6E1B\u5C11\u2026\u3002",
  "id" : 67964948109721600,
  "created_at" : "2011-05-10 14:51:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 32, 43 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67964636779134977",
  "text" : "\u30A2\u30EB\u30B3\u30FC\u30EB\u5EA6\u6570\u304C\u9AD8\u3044\uFF1F\u5FAE\u5206\u3057\u305F\u3089\uFF10\u3060\u308D\u3063\uFF01\uFF08\u5FAE\u3076\u3093\u5B66\u90E8\uFF09\u3000RT @akiyohmori: RT @sugiyama1990: \u6570\u5B66\u79D1\u300Cn\u676F\u98F2\u3081\u3066\u30FC\u3001(n+1)\u676F\u98F2\u3081\u306A\u3044\u308F\u3051\u304C\u306A\u30FC\u3044\u300D",
  "id" : 67964636779134977,
  "created_at" : "2011-05-10 14:50:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67962705285365760",
  "text" : "\u305F\u3060\u3044\u307E\u3002\u305A\u3044\u3076\u3093\u9045\u304F\u306A\u3063\u305F\u306A\u3002\u3002\u3002",
  "id" : 67962705285365760,
  "created_at" : "2011-05-10 14:42:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67870439925493760",
  "geo" : { },
  "id_str" : "67874540000251904",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \uFF14\u5171\uFF11\uFF11",
  "id" : 67874540000251904,
  "in_reply_to_status_id" : 67870439925493760,
  "created_at" : "2011-05-10 08:52:06 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67869800667418624",
  "geo" : { },
  "id_str" : "67870094738460673",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3069\u306E\u56F3\u66F8\u9928\uFF1F\uFF14\u4F9B\u3068\u8E0F\u3093\u3067\u3044\u308B\u304C",
  "id" : 67870094738460673,
  "in_reply_to_status_id" : 67869800667418624,
  "created_at" : "2011-05-10 08:34:26 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67869387000000512",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3069\u3053\u306B\u3044\u308B\uFF1F",
  "id" : 67869387000000512,
  "created_at" : "2011-05-10 08:31:37 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67848859409317888",
  "text" : "@np2i \u30EA\u30D7\u30E9\u30A4\u3060\u3068\u6570\u6587\u5B57\u6E1B\u3063\u3061\u3083\u3046\u3093\u3067\u30EA\u30B9\u30C8\u3067\uFF01",
  "id" : 67848859409317888,
  "created_at" : "2011-05-10 07:10:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "indices" : [ 3, 14 ],
      "id_str" : "215546677",
      "id" : 215546677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67801280176848896",
  "text" : "RT @tameninaru: \u30AF\u30E2\u306B\u30B3\u30FC\u30D2\u30FC\u3092\u306E\u307E\u305B\u308B\u3068\u3067\u305F\u3089\u3081\u306A\u89D2\u5EA6\u306E\u5DE3\u3092\u4F5C\u308B\u3002\uFF08\u30B3\u30FC\u30D2\u30FC\u306E\u6210\u5206\u30AB\u30D5\u30A7\u30A4\u30F3\u304C\u30AF\u30E2\u306E\u4E2D\u67A2\u795E\u7D4C\u3092\u9EBB\u75FA\u3055\u305B\u3001\u4EBA\u9593\u3067\u8A00\u3046\u9154\u3063\u6255\u3063\u305F\u72B6\u614B\u306B\u306A\u308B\u305F\u3081\u3001\u3067\u305F\u3089\u3081\u306A\u5DE3\u3092\u3064\u304F\u308B\uFF09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67801045081923585",
    "text" : "\u30AF\u30E2\u306B\u30B3\u30FC\u30D2\u30FC\u3092\u306E\u307E\u305B\u308B\u3068\u3067\u305F\u3089\u3081\u306A\u89D2\u5EA6\u306E\u5DE3\u3092\u4F5C\u308B\u3002\uFF08\u30B3\u30FC\u30D2\u30FC\u306E\u6210\u5206\u30AB\u30D5\u30A7\u30A4\u30F3\u304C\u30AF\u30E2\u306E\u4E2D\u67A2\u795E\u7D4C\u3092\u9EBB\u75FA\u3055\u305B\u3001\u4EBA\u9593\u3067\u8A00\u3046\u9154\u3063\u6255\u3063\u305F\u72B6\u614B\u306B\u306A\u308B\u305F\u3081\u3001\u3067\u305F\u3089\u3081\u306A\u5DE3\u3092\u3064\u304F\u308B\uFF09",
    "id" : 67801045081923585,
    "created_at" : "2011-05-10 04:00:03 +0000",
    "user" : {
      "name" : "\u70BA\u306B\u306A\u308B\u8A00\u8449",
      "screen_name" : "tameninaru",
      "protected" : false,
      "id_str" : "215546677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1224546422\/bot_tame_normal.jpg",
      "id" : 215546677,
      "verified" : false
    }
  },
  "id" : 67801280176848896,
  "created_at" : "2011-05-10 04:00:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67800298059608064",
  "text" : "\u30E9\u30A6\u30F3\u30B8\u306A\u3046\u30FC",
  "id" : 67800298059608064,
  "created_at" : "2011-05-10 03:57:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67773342966484992",
  "text" : "\u4ECA\u304B\u3089\u884C\u3063\u305F\u3089\uFF13\uFF10\u5206\u6388\u696D\u53D7\u3051\u3089\u308C\u308B\u3001\u3046\u30FC\u3093",
  "id" : 67773342966484992,
  "created_at" : "2011-05-10 02:09:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67773187806605312",
  "text" : "\u6109\u5FEB\u306B\u7D20\u6575\u306B\u7720\u3063\u3061\u307E\u3063\u305F\u305E\u2026",
  "id" : 67773187806605312,
  "created_at" : "2011-05-10 02:09:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67759339024289792",
  "text" : "\u4E8C\u9650\u9045\u523B\u2026\uFF1F",
  "id" : 67759339024289792,
  "created_at" : "2011-05-10 01:14:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67754848493371392",
  "text" : "\u60F0\u7720\u2026\u96E8\u2026\u7720\u3044\u3088\u3045",
  "id" : 67754848493371392,
  "created_at" : "2011-05-10 00:56:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67617673646837760",
  "geo" : { },
  "id_str" : "67618251127005184",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u65E5\u4ED8\u5909\u308F\u3063\u3066\u308B\u3057\u3001\u307E\u305F\u4ECA\u65E5\u3060\u3088\u3001\u3053\u3053\u308D\u3061\u3083\u3093",
  "id" : 67618251127005184,
  "in_reply_to_status_id" : 67617673646837760,
  "created_at" : "2011-05-09 15:53:42 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67617585474174977",
  "text" : "\u5BDD\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002\u7D20\u6570\u306A\u5922\u3092\u3002",
  "id" : 67617585474174977,
  "created_at" : "2011-05-09 15:51:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67617352237334528",
  "text" : "\u30C6\u30C8\u30E9\u3061\u3083\u3093\u306F\u8272\u3093\u306A\u610F\u5473\u3067\u51C4\u3044\u5B50\u2026",
  "id" : 67617352237334528,
  "created_at" : "2011-05-09 15:50:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67615870926585856",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u3001\u30D5\u30A7\u30EB\u30DE\u30FC\u306E\u5DFB\u3002\u307E\u3060\u8AAD\u307F\u304B\u3051\u3060\u3051\u3069s\u30B7\u30F3\u6C0F\u306E\u3082\u306E\u3088\u308A\u6570\u5B66\u7684\u306A\u5370\u8C61\u3002\u305B\u3063\u304B\u304F\u9762\u767D\u3044\u3057\u3086\u3063\u304F\u308A\u8AAD\u3082\u3046\u3002",
  "id" : 67615870926585856,
  "created_at" : "2011-05-09 15:44:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67607279670800384",
  "text" : "\u4ECA\u65E5\u306F\u4E8C\u9650\u304B\u3089\u3060\u304B\u3089\u6628\u65E5\u3088\u308A\u306F\u3086\u3063\u304F\u308A\u5BDD\u308C\u308B\u3002\u3055\u3055\u3084\u304B\u3060\u3051\u3069\u5927\u4E8B\u306A\u5E78\u305B\u3002",
  "id" : 67607279670800384,
  "created_at" : "2011-05-09 15:10:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67607168538517505",
  "text" : "\u7D50\u5C40\u7D42\u308F\u3089\u306A\u304B\u3063\u305F\u3051\u3069\u4ECA\u65E5\u306E\u304A\u663C\u4F11\u307F\u306B\u4F55\u3068\u304B\u3057\u3066\u898B\u305B\u3088\u3046\u3058\u3083\u3042\u306A\u3044\u304B\u3002\u7720\u3044\u3051\u3069\u3061\u3087\u3063\u3068\u3060\u3051\u6570\u5B66\u30AC\u30FC\u30EB\u8AAD\u3093\u3067\u304B\u3089\u5BDD\u3088\u3046\u3002",
  "id" : 67607168538517505,
  "created_at" : "2011-05-09 15:09:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67600147672084481",
  "text" : "@mo5nya \u4F59\u8A08\u306A\u304A\u4E16\u8A71\u3060\u3063\u305F\u3089\u3059\u307F\u307E\u305B\u3093\uFF4D(_ _)\uFF4D",
  "id" : 67600147672084481,
  "created_at" : "2011-05-09 14:41:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67599086899052544",
  "text" : "@mo5nya \u305C\u3072\u3069\u3046\u305E\u30FC\u3002",
  "id" : 67599086899052544,
  "created_at" : "2011-05-09 14:37:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67597172266381312",
  "text" : "@mo5nya \u305D\u3053\u3067\u6570\u5B66\u3092\u3044\u304B\u304C\u3067\u3057\u3087\u3046\u3002",
  "id" : 67597172266381312,
  "created_at" : "2011-05-09 14:29:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67584846037397504",
  "text" : "\u3053\u3053\u308D\u3068\u3044\u3046\u3088\u308A\u6C17\u5206\u8EE2\u63DB\u3001\u3055\u3063\u3071\u308A\u3057\u305F\u3044\u3093\u3060\u306A\u3002\u8A00\u8449\u306E\u30C1\u30E7\u30A4\u30B9\u30DF\u30B9\u3002\u5225\u306B\u7126\u3063\u3066\u306A\u3044\u3057\u3002\u30B3\u30B3\u30ED\u306F\u3059\u3053\u3076\u308B\u843D\u3061\u7740\u3044\u3066\u3044\u308B\u3002",
  "id" : 67584846037397504,
  "created_at" : "2011-05-09 13:40:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67584679892619264",
  "text" : "\u4ECA\u3084\u308B\u3057\u304B\u306A\u3044\u3058\u3083\u306A\u3044\u304Borz\u307E\u3041\u3044\u3044\u3001\u3068\u308A\u3042\u3048\u305A\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3066\u30B3\u30B3\u30ED\u3092\u843D\u3061\u7740\u3051\u3088\u3046\u3002",
  "id" : 67584679892619264,
  "created_at" : "2011-05-09 13:40:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67584306586984450",
  "text" : "\u660E\u65E5\u306E\uFF13\u9650\u3042\u3044\u3066\u3044\u308B\u304B\u3089\u305D\u3053\u3067\u672C\u6C17\u3092\u51FA\u305D\u3046\u3001\u8FFD\u3044\u8FBC\u307E\u308C\u308C\u3070\u3084\u308B\u6C17\u3082\u51FA\u3066\u304F\u308B\u306F\u305A\u3002\u3068\u304A\u3082\u3063\u305F\u3051\u3069\u305D\u3057\u305F\u3089\uFF16\u9650\u306E\u52C9\u5F37\u3067\u304D\u306A\u3044\u3058\u3083\u3093\u3002\u3080\u3045\u30FB\u30FB\u30FB\u3002",
  "id" : 67584306586984450,
  "created_at" : "2011-05-09 13:38:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 0, 15 ],
      "id_str" : "227502200",
      "id" : 227502200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67583341494411264",
  "geo" : { },
  "id_str" : "67583597737025537",
  "in_reply_to_user_id" : 227502200,
  "text" : "@G4_Hirano_chan \u3044\u305F\u3060\u304D\u307E\u3059\u3002",
  "id" : 67583597737025537,
  "in_reply_to_status_id" : 67583341494411264,
  "created_at" : "2011-05-09 13:35:59 +0000",
  "in_reply_to_screen_name" : "G4_Hirano_chan",
  "in_reply_to_user_id_str" : "227502200",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67583140323012608",
  "text" : "\u7720\u3044\u75B2\u308C\u305F\u7740\u66FF\u3048\u305F\u3044\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u305F\u3044\u30C1\u30E7\u30B3\u98DF\u3079\u305F\u3044\u30D0\u30CA\u30CA\u98DF\u3079\u305F\u3044\u2026\u304A\u306A\u304B\u306F\u3059\u3044\u3066\u306A\u3044\u3051\u308C\u3069\u3002",
  "id" : 67583140323012608,
  "created_at" : "2011-05-09 13:34:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67582578298863616",
  "text" : "\u30C0\u30E1\u3060\u2026\u5B8C\u5168\u306B\u624B\u304C\u6B62\u307E\u3063\u305F\u30FB\u30FB\u30FB\u30D5\u30E9\u30F3\u30B9\u8A9E\u30A7\u30FB\u30FB\u30FB\u30FB",
  "id" : 67582578298863616,
  "created_at" : "2011-05-09 13:31:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67579498941530113",
  "geo" : { },
  "id_str" : "67579690709286912",
  "in_reply_to_user_id" : 230889478,
  "text" : "@kouennnoyuugu 5",
  "id" : 67579690709286912,
  "in_reply_to_status_id" : 67579498941530113,
  "created_at" : "2011-05-09 13:20:28 +0000",
  "in_reply_to_screen_name" : "phy_neko",
  "in_reply_to_user_id_str" : "230889478",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67579294678925312",
  "geo" : { },
  "id_str" : "67579624380579840",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u9EBB\u96C0\u30BD\u30EA\u30C6\u30A3\u30A2\uFF57\uFF57\uFF57\uFF57",
  "id" : 67579624380579840,
  "in_reply_to_status_id" : 67579294678925312,
  "created_at" : "2011-05-09 13:20:12 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67578621090467841",
  "geo" : { },
  "id_str" : "67578967699357696",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30DE\u30A4\u30F3\u30B9\u30A4\u30FC\u30D1\u3000\u30D5\u30EA\u30FC\u30BB\u30EB\u3000\u30BD\u30EA\u30C6\u30A3\u30A2\u306F\u795E\u30B2\u30FC\u3060\u305E\u3002\u4E3B\u306BTA\u3060\u304C\u3002",
  "id" : 67578967699357696,
  "in_reply_to_status_id" : 67578621090467841,
  "created_at" : "2011-05-09 13:17:36 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67569982996889600",
  "text" : "@mo5nya @haru_urah_rah \u6570\u5B66\u30AC\u30FC\u30EB\u306E\u96C6\u5408\u2026\uFF01",
  "id" : 67569982996889600,
  "created_at" : "2011-05-09 12:41:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67564895675224065",
  "text" : "\u4E4B\u5927\u597D\u304D\u3060\u3002http:\/\/togetter.com\/li\/133520",
  "id" : 67564895675224065,
  "created_at" : "2011-05-09 12:21:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67461624491032576",
  "text" : "@koketomi \u3056\u307E\u3041\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 67461624491032576,
  "created_at" : "2011-05-09 05:31:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67459427522973696",
  "text" : "RT @Kaibun_bot: \uFF13\u6B73\u5150\u306E\u4EE3\u6253\u306E\u723A\u3055\u3093\u3088\u308A\uFF14\u6B73\u5150\u306E\u4EE3\u6253\u306E\u723A\u3055\u3093\u3055\u3000\uFF08\u3055\u3093\u3055\u3044\u3058\u306E\u3060\u3044\u3060\u306E\u3058\u3044\u3055\u3093\u3088\u308A\u3088\u3093\u3055\u3044\u3058\u306E\u3060\u3044\u3060\u306E\u3058\u3044\u3055\u3093\u3055\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67457961940893696",
    "text" : "\uFF13\u6B73\u5150\u306E\u4EE3\u6253\u306E\u723A\u3055\u3093\u3088\u308A\uFF14\u6B73\u5150\u306E\u4EE3\u6253\u306E\u723A\u3055\u3093\u3055\u3000\uFF08\u3055\u3093\u3055\u3044\u3058\u306E\u3060\u3044\u3060\u306E\u3058\u3044\u3055\u3093\u3088\u308A\u3088\u3093\u3055\u3044\u3058\u306E\u3060\u3044\u3060\u306E\u3058\u3044\u3055\u3093\u3055\uFF09 #kaibun",
    "id" : 67457961940893696,
    "created_at" : "2011-05-09 05:16:46 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 67459427522973696,
  "created_at" : "2011-05-09 05:22:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "indices" : [ 3, 17 ],
      "id_str" : "91483221",
      "id" : 91483221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67454687493890048",
  "text" : "RT @_flyingmoomin: \u3082\u3057\u3082\u9AD8\u6821\u91CE\u7403\u306E\u5973\u5B50\u30DE\u30CD\u30FC\u30B8\u30E3\u30FC\u304C\u30D6\u30EB\u30D0\u30AD\u306E\u300E\u6570\u5B66\u539F\u8AD6\u300F\u3092\u8AAD\u3093\u3060\u3089: \n\u300C\u3053\u306E\u30B9\u30DD\u30FC\u30C4\u306F, \u539F\u5247\u7684\u306B\u306F\u4E88\u5099\u77E5\u8B58\u3092\u5168\u7136\u5FC5\u8981\u3068\u3057\u307E\u305B\u3093. \u305F\u3060, \u591A\u5C11\u306E\u57FA\u790E\u4F53\u529B\u3068\u53CD\u5C04\u795E\u7D4C\u304C\u5FC5\u8981\u306A\u3060\u3051\u3067\u3059.  \u307E\u305A\u91CE\u7403\u306E\u5B9A\u7FA9\u3092\u3057\u307E\u3059. \u91CE\u7403\u3068\u306F, \u6B21\u306E\u516C\u7406 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66474518968938496",
    "text" : "\u3082\u3057\u3082\u9AD8\u6821\u91CE\u7403\u306E\u5973\u5B50\u30DE\u30CD\u30FC\u30B8\u30E3\u30FC\u304C\u30D6\u30EB\u30D0\u30AD\u306E\u300E\u6570\u5B66\u539F\u8AD6\u300F\u3092\u8AAD\u3093\u3060\u3089: \n\u300C\u3053\u306E\u30B9\u30DD\u30FC\u30C4\u306F, \u539F\u5247\u7684\u306B\u306F\u4E88\u5099\u77E5\u8B58\u3092\u5168\u7136\u5FC5\u8981\u3068\u3057\u307E\u305B\u3093. \u305F\u3060, \u591A\u5C11\u306E\u57FA\u790E\u4F53\u529B\u3068\u53CD\u5C04\u795E\u7D4C\u304C\u5FC5\u8981\u306A\u3060\u3051\u3067\u3059.  \u307E\u305A\u91CE\u7403\u306E\u5B9A\u7FA9\u3092\u3057\u307E\u3059. \u91CE\u7403\u3068\u306F, \u6B21\u306E\u516C\u7406\u3092\u6E80\u305F\u3059\u96C6\u5408\u306E\u7D44(X, \u03C4)\u306E\u3053\u3068\u3067\u3059...\u300D",
    "id" : 66474518968938496,
    "created_at" : "2011-05-06 12:08:55 +0000",
    "user" : {
      "name" : "\u7A7A\u98DB\u3076\u30E0\u2708\u30DF\u30F3",
      "screen_name" : "_flyingmoomin",
      "protected" : false,
      "id_str" : "91483221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000683388389\/f8294a7e03afc79635af2d4a8c074f85_normal.png",
      "id" : 91483221,
      "verified" : false
    }
  },
  "id" : 67454687493890048,
  "created_at" : "2011-05-09 05:03:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67436901845573632",
  "text" : "\u30E1\u30C7\u30A3\u30BB\u30F3\u306E\u30D1\u30BD\u30B3\u30F3\u500B\u4EBA\u8A2D\u5B9A\u8AAD\u307F\u8FBC\u3080\u306E\u306B\u3069\u3093\u3060\u3051\u6642\u9593\u304B\u304B\u3063\u3066\u3093\u3060\u3088",
  "id" : 67436901845573632,
  "created_at" : "2011-05-09 03:53:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67435922735628288",
  "geo" : { },
  "id_str" : "67436686929428480",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u82B8\u9054\u8005\u3060\u306A\u3002",
  "id" : 67436686929428480,
  "in_reply_to_status_id" : 67435922735628288,
  "created_at" : "2011-05-09 03:52:13 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67435639854997504",
  "text" : "\u6691\u3044\u2026",
  "id" : 67435639854997504,
  "created_at" : "2011-05-09 03:48:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67427939209314304",
  "geo" : { },
  "id_str" : "67428710671855618",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3044\u307E\uFF08\u3068\uFF13\u9650)\u3069\u3053\u306B\u3044\u308B\uFF1F",
  "id" : 67428710671855618,
  "in_reply_to_status_id" : 67427939209314304,
  "created_at" : "2011-05-09 03:20:32 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    }, {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 6, 16 ],
      "id_str" : "181342377",
      "id" : 181342377
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 17, 28 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67358744085925888",
  "text" : "@np2i @kazma0318 @magokoro84 \u304A\u3084\u3059\u307F\u3042\u308A\u304C\u3068\u3067\u3057\u305F\u30FC\u3002",
  "id" : 67358744085925888,
  "created_at" : "2011-05-08 22:42:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67358563173007360",
  "text" : "\u304A\u306F\u3088\u3046\u2026\u5B9F\u306B\u65E9\u3044\u3002\u3067\u3082\u4E00\u9650\u4F59\u88D5\u306D\u3002",
  "id" : 67358563173007360,
  "created_at" : "2011-05-08 22:41:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67259879445905408",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\uFF14\u5DFB\u8AAD\u307F\u7D42\u3048\u305F\u3002\u611F\u60F3\u306F\u307E\u305F\u4ECA\u5EA6\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 67259879445905408,
  "created_at" : "2011-05-08 16:09:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67255355964534785",
  "geo" : { },
  "id_str" : "67256481271132161",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4ECA\u65E5\u30E1\u30C7\u30A3\u30BB\u30F3\u306B\u3067\u3082\u3044\u3063\u3066\u5237\u308D\u3046\u304B",
  "id" : 67256481271132161,
  "in_reply_to_status_id" : 67255355964534785,
  "created_at" : "2011-05-08 15:56:09 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67254073509953536",
  "geo" : { },
  "id_str" : "67255082013556736",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u3002\u4FFA\u5225\u306E\u6388\u696D\u3067ID\u3082\u3063\u3066\u308B\u3093\u3060\u308F\u3002",
  "id" : 67255082013556736,
  "in_reply_to_status_id" : 67254073509953536,
  "created_at" : "2011-05-08 15:50:35 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67253767237681154",
  "geo" : { },
  "id_str" : "67253975329673216",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4E00\u6628\u65E5\u6628\u65E5\u3067\u3084\u3063\u3064\u3051\u305F",
  "id" : 67253975329673216,
  "in_reply_to_status_id" : 67253767237681154,
  "created_at" : "2011-05-08 15:46:11 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67253878399311872",
  "text" : "\u8272\u306E\u4E26\u3073\u3068\u5DE6\u53F3\u3069\u3063\u3061\u306B\u5927\u304D\u3044\u6570\u5B57\u7F6E\u304F\u304B\u304C\u81EA\u7531\u3060\u304B\u3089\u82E5\u5E72\u5358\u7D14\u5316\u3057\u306B\u304F\u3044\u304B\u2026\u3002",
  "id" : 67253878399311872,
  "created_at" : "2011-05-08 15:45:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67253598005886976",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u30BD\u30FC\u30C8\u306E\u8A71\u3092\u8AAD\u307F\u306A\u304C\u3089\u9EBB\u96C0\u306E\u7406\u724C\u306E\u6700\u77ED\u624B\u9806\u3063\u3066\u3069\u3046\u306A\u308B\u306E\u304B\u306A\u3063\u3066\u982D\u3092\u904E\u304E\u308B\u2026",
  "id" : 67253598005886976,
  "created_at" : "2011-05-08 15:44:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67251473561563137",
  "text" : "\u306A\u3093\u304B\u304A\u8179\u5909\u306A\u611F\u3058\u3002\u98DF\u6B32\u3082\u3042\u3093\u307E\u306A\u3044\u3002\u4E94\u6708\u75C5\u3063\u3066\u304A\u8179\u306B\u3060\u3051\u6765\u305F\u308A\u3059\u308B\u306E\u304B\u306A\uFF1F\u2190",
  "id" : 67251473561563137,
  "created_at" : "2011-05-08 15:36:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67218992284172288",
  "geo" : { },
  "id_str" : "67227533267042304",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4E00\u5E74\u76EE\u3067\u6559\u8077\u53D6\u308C\u306A\u3044\u3053\u3063\u3061\u306E\u5927\u5B66\u306F\u2026\u304A\u5BDF\u3057\u304F\u3060\u3055\u3044\u3002",
  "id" : 67227533267042304,
  "in_reply_to_status_id" : 67218992284172288,
  "created_at" : "2011-05-08 14:01:07 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67226329967362048",
  "geo" : { },
  "id_str" : "67227060157939712",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod \u6570\u5B66\u597D\u304D\u306A\u3060\u3051\u3067\u3044\u3044\u306E\u306A\u3089\u80F8\u3092\u5F35\u3063\u3066\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u3068\u8A00\u3048\u307E\u3059\u304C\u2026\u5C02\u653B\u3057\u3066\u308B\u4EBA\u3068\u6BD4\u3079\u3061\u3083\u3046\u3068\u2026\u2026orz\u3063\u3066\u306A\u308A\u307E\u3059\u306D\u3047",
  "id" : 67227060157939712,
  "in_reply_to_status_id" : 67226329967362048,
  "created_at" : "2011-05-08 13:59:14 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67226192759099392",
  "text" : "\u4E00\u65E5\u4E2D\u8AB2\u984C\u3084\u3063\u3066\u305F\u3063\u3066\u8A00\u3063\u305F\u3089\u30A6\u30BD\u3060\u3051\u3069\u307B\u3068\u3093\u3069\u305D\u3046\u3060\u3063\u305F\u3001\u3057\u304B\u3082\u660E\u65E5\u306B\u3061\u3087\u3063\u3068\u6B8B\u3063\u3066\u3057\u307E\u3063\u305F\u3068\u3044\u3046\u3002\u660E\u65E5\u4E00\u9650\u304B\u2026",
  "id" : 67226192759099392,
  "created_at" : "2011-05-08 13:55:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67181016908963840",
  "geo" : { },
  "id_str" : "67192908238958592",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u305A\u3044\u3076\u3093\u504F\u308A\u306E\u3042\u308A\u305D\u3046\u306A\u30A2\u30F3\u30B1\u30FC\u30C8\u7D50\u679C\u306B\u306A\u308A\u305D\u3046\u306D\u3002\u3053\u308C\u3060\u304B\u3089\u65E5\u672C\u306E\u30A2\u30F3\u30B1\u30FC\u30C8\u3068\u304B\u7D71\u8A08\u3063\u3066\u7D20\u76F4\u306B\u898B\u308C\u306A\u3044\u3093\u3060\u3088\u306A\u3002\u4E00\u3064\u4E00\u3064\u306E\u5143\u306B\u6BD4\u91CD\u304C\u3042\u308A\u305D\u3046\u3002",
  "id" : 67192908238958592,
  "in_reply_to_status_id" : 67181016908963840,
  "created_at" : "2011-05-08 11:43:32 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67161700335484928",
  "geo" : { },
  "id_str" : "67162211902160896",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \uFF4B\uFF57\uFF53\uFF4B",
  "id" : 67162211902160896,
  "in_reply_to_status_id" : 67161700335484928,
  "created_at" : "2011-05-08 09:41:33 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3075(\u53E4\u5099\u524D\u6D3E)",
      "screen_name" : "mof_mof",
      "indices" : [ 3, 11 ],
      "id_str" : "46916811",
      "id" : 46916811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67134452438024192",
  "text" : "RT @mof_mof: TL\u306B\u6D41\u308C\u3066\u305F\u3093\u3060\u3051\u3069\u306A\u306B\u3053\u308C\u3059\u3054\u3044 \u6CE3\u3044\u305F http:\/\/j.mp\/9t3ErI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/peraperaprv\/Home\" rel=\"nofollow\"\u003EP3:PeraPeraPrv\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "24270087685",
    "text" : "TL\u306B\u6D41\u308C\u3066\u305F\u3093\u3060\u3051\u3069\u306A\u306B\u3053\u308C\u3059\u3054\u3044 \u6CE3\u3044\u305F http:\/\/j.mp\/9t3ErI",
    "id" : 24270087685,
    "created_at" : "2010-09-12 09:14:25 +0000",
    "user" : {
      "name" : "\u3082\u3075(\u53E4\u5099\u524D\u6D3E)",
      "screen_name" : "mof_mof",
      "protected" : false,
      "id_str" : "46916811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604543101403688960\/TKfo3MUH_normal.jpg",
      "id" : 46916811,
      "verified" : false
    }
  },
  "id" : 67134452438024192,
  "created_at" : "2011-05-08 07:51:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira O-ko-chi",
      "screen_name" : "Okouchi",
      "indices" : [ 0, 8 ],
      "id_str" : "96684281",
      "id" : 96684281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67114745756532736",
  "geo" : { },
  "id_str" : "67115434696118272",
  "in_reply_to_user_id" : 96684281,
  "text" : "@Okouchi \u6848\u5916\u8FD1\u304F\u306B\u3044\u3089\u3063\u3057\u3083\u308B\u306E\u3067\u3073\u3063\u304F\u308A\uFF57",
  "id" : 67115434696118272,
  "in_reply_to_status_id" : 67114745756532736,
  "created_at" : "2011-05-08 06:35:41 +0000",
  "in_reply_to_screen_name" : "Okouchi",
  "in_reply_to_user_id_str" : "96684281",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67110531693150208",
  "geo" : { },
  "id_str" : "67110842906320896",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u308A\u304C\u3068\u3046\u3002\u628A\u63E1\u3057\u305F\u3001\u4FE1\u3058\u308B\u305C\u3002",
  "id" : 67110842906320896,
  "in_reply_to_status_id" : 67110531693150208,
  "created_at" : "2011-05-08 06:17:26 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67109698926690304",
  "geo" : { },
  "id_str" : "67110103119167488",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6587\u5B66\u90E8\u82F1\u8A9E\u3063\u3066\u3069\u3053\u307E\u3067\u3060\u3063\u3051\uFF1F",
  "id" : 67110103119167488,
  "in_reply_to_status_id" : 67109698926690304,
  "created_at" : "2011-05-08 06:14:30 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304C\u3076\u308A\u3048\u308B",
      "screen_name" : "oGoGab",
      "indices" : [ 3, 10 ],
      "id_str" : "95771269",
      "id" : 95771269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67103339611045888",
  "text" : "RT @oGoGab: \u8089\u98DF\u7CFB\u5973\u5B50\uFF1A\u30AC\u30C4\u30AC\u30C4\u3057\u3066\u308B\u5973\u5B50\u3000\n\u713C\u8089\u7CFB\u5973\u5B50\uFF1A\u3059\u3050\u713C\u304D\u3082\u3061\u3092\u3084\u304F\u5973\u5B50\u3000\n\u751F\u8089\u7CFB\u5973\u5B50\uFF1A\u3042\u305F\u308B\u3068\u5927\u5909\u306A\u3053\u3068\u306B\u306A\u308B\u5973\u5B50\u3000\n\u8150\u8089\u7CFB\u5973\u5B50\uFF1A\u604B\u611B\u5E02\u5834\u304B\u3089\u5F3E\u304B\u308C\u3066\u3044\u308B\u5973\u5B50\u3000\n\u30E6\u30C3\u7CFB\u5973\u5B50\uFF1A\u305D\u3082\u305D\u3082\u604B\u611B\u5E02\u5834\u306B\u51FA\u3057\u3061\u3083\u3044\u3051\u306A\u304B\u3063\u305F\u5973\u5B50",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66827716359487488",
    "text" : "\u8089\u98DF\u7CFB\u5973\u5B50\uFF1A\u30AC\u30C4\u30AC\u30C4\u3057\u3066\u308B\u5973\u5B50\u3000\n\u713C\u8089\u7CFB\u5973\u5B50\uFF1A\u3059\u3050\u713C\u304D\u3082\u3061\u3092\u3084\u304F\u5973\u5B50\u3000\n\u751F\u8089\u7CFB\u5973\u5B50\uFF1A\u3042\u305F\u308B\u3068\u5927\u5909\u306A\u3053\u3068\u306B\u306A\u308B\u5973\u5B50\u3000\n\u8150\u8089\u7CFB\u5973\u5B50\uFF1A\u604B\u611B\u5E02\u5834\u304B\u3089\u5F3E\u304B\u308C\u3066\u3044\u308B\u5973\u5B50\u3000\n\u30E6\u30C3\u7CFB\u5973\u5B50\uFF1A\u305D\u3082\u305D\u3082\u604B\u611B\u5E02\u5834\u306B\u51FA\u3057\u3061\u3083\u3044\u3051\u306A\u304B\u3063\u305F\u5973\u5B50",
    "id" : 66827716359487488,
    "created_at" : "2011-05-07 11:32:23 +0000",
    "user" : {
      "name" : "\u304C\u3076\u308A\u3048\u308B",
      "screen_name" : "oGoGab",
      "protected" : false,
      "id_str" : "95771269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444407655486873600\/vei7ArIY_normal.jpeg",
      "id" : 95771269,
      "verified" : false
    }
  },
  "id" : 67103339611045888,
  "created_at" : "2011-05-08 05:47:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 11, 22 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67101921596542976",
  "geo" : { },
  "id_str" : "67102342780170240",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 @akiyohmori \uFF08\u305D\u3053\u307E\u3067\u308F\u304B\u3063\u3066\u308B\u306E\u306A\u3089\u3084\u308B\u3053\u3068\u306F\u4E00\u3064\u3057\u304B\u306A\u3044\u3088\u306A\u3041\u2026\u2026\uFF09",
  "id" : 67102342780170240,
  "in_reply_to_status_id" : 67101921596542976,
  "created_at" : "2011-05-08 05:43:39 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67101760518492160",
  "text" : "\u306A\u3093\u3068\u3082\u904E\u3054\u3057\u3084\u3059\u3044\u6C17\u5019\u306B\u306A\u3063\u3066\u304D\u305F\u306A\u3041\u3002\u305D\u3093\u306A\u90FD\u5408\u306F\u3064\u3086\u77E5\u3089\u305A\u3001\u3082\u3046\u5C11\u3057\u3057\u305F\u3089\u6885\u96E8\u3067\u6050\u308D\u3057\u304F\u904E\u3054\u3057\u306B\u304F\u304F\u306A\u3063\u3066\u3057\u307E\u3046\u306E\u3060\u3051\u308C\u3069\u2015\u3002",
  "id" : 67101760518492160,
  "created_at" : "2011-05-08 05:41:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67100053659070464",
  "text" : "PC\u306B\u3082SOICHA\u5165\u308C\u3066\u307F\u305F\u3051\u308C\u3069\u3001SAEZURI\u306E\u65B0\u898F\u3064\u3044\u30FC\u3068\u524D\u9762\u306B\u8868\u793A\u6A5F\u80FD\u306F\u4FBF\u5229\u3060\u3088\u306A\u30FC\u3002\n\u305F\u3060\u4F1A\u8A71\u9061\u3063\u305F\u308A\u306F\u51FA\u6765\u306A\u3044\u3093\u3060\u3088\u306D\u3002\u4E8C\u91CD\u8D77\u52D5\u3063\u3066\u306E\u3082\u30D0\u30AB\u307F\u305F\u3044\u3060\u3057\u306D\u3047\u30FB\u30FB\u30FB\u3002",
  "id" : 67100053659070464,
  "created_at" : "2011-05-08 05:34:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67086003680182272",
  "text" : "\u3042\u30FC\u3001\u8D77\u304D\u305F\u3002\u6848\u306E\u5B9A\u5BDD\u7656\u304C\u3072\u3063\u3069\u3044\u3002\u3042\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 67086003680182272,
  "created_at" : "2011-05-08 04:38:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66919665787600896",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 66919665787600896,
  "created_at" : "2011-05-07 17:37:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66919571650654208",
  "text" : "\u5BDD\u308B\u304B\u306A\u30FC \u9AEA\u4E7E\u304D\u5207\u3063\u3066\u306A\u3044\u3051\u3069\u2026",
  "id" : 66919571650654208,
  "created_at" : "2011-05-07 17:37:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66916440724348928",
  "text" : "\u305D\u3046\u3044\u3084 \u4E2D(\u6697\u30AB\u30F3) \u5DBA\u4E0A\u958B\u82B1 \u30C9\u30E95(\u8D64\u4E00\u3064\u3001\u30AB\u30F3\u30C9\u30E94\u3064)\u3063\u3066\u30CF\u30CD\u30DE\u30F3\u3092\u3042\u304C\u3063\u305F\u3051\u3069\u6211\u306A\u304C\u3089\u7406\u4E0D\u5C3D\u3060\u3063\u305F\u3068\u601D\u3046\u3001\u53CD\u7701\u306F\u3057\u3066\u3044\u306A\u3044\u3002",
  "id" : 66916440724348928,
  "created_at" : "2011-05-07 17:24:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66914856162435073",
  "text" : "\u9EBB\u96C0\u7D42\u4E86 \u534A\u83583\u56DE\u3067\uFF12\u3001\uFF14\u3001\uFF11\u4F4D \u4E00\u56DE\u76EE\u306F\u67712\u5C40\u3067\u30C8\u30D3 3\u4E07\u8D8A\u3048\u3066\u4E8C\u4F4Dorz \u4E8C\u56DE\u76EE\u306F\u713C\u304D\u9CE5 \u307B\u3068\u3093\u3069\u632F\u308A\u8FBC\u307E\u305A\u30C4\u30E2\u3067\u30BA\u30EB\u30BA\u30EB 3\u56DE\u76EE\u306F\u9806\u8ABF\u306B\u548C\u4E86\u3057\u3066\u632F\u3089\u305A\u306B1\u4F4D \u6982\u306D\u6E80\u8DB3 \u3060\u3051\u3069\u4E8C\u56DE\u76EE\u306F\u30A2\u30EC\u3060\u3063\u305F\u306A\u3041\u2026",
  "id" : 66914856162435073,
  "created_at" : "2011-05-07 17:18:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66846187793293312",
  "text" : "\u30EA\u30FC\u30C1\u4E00\u767A\u30C1\u30F3\u30A4\u30C4\u30FC\u76C3\u53E3\u30C9\u30E93 12\u30CF\u30F3\u2026",
  "id" : 66846187793293312,
  "created_at" : "2011-05-07 12:45:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082\u3063\u304F\u3059\uFF20\u6771\u4EAC\u4EBA\u306B\u306A\u308A\u307E\u3057\u305F",
      "screen_name" : "o_tomox",
      "indices" : [ 0, 8 ],
      "id_str" : "145247946",
      "id" : 145247946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66821859303358464",
  "geo" : { },
  "id_str" : "66845522798985216",
  "in_reply_to_user_id" : 145247946,
  "text" : "@o_tomox \u8FD4\u3057\u3066\u304A\u304D\u307E\u3057\u305F\u30FC\u3002",
  "id" : 66845522798985216,
  "in_reply_to_status_id" : 66821859303358464,
  "created_at" : "2011-05-07 12:43:09 +0000",
  "in_reply_to_screen_name" : "o_tomox",
  "in_reply_to_user_id_str" : "145247946",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "utatakiyoshi",
      "screen_name" : "utatakiyoshi",
      "indices" : [ 3, 16 ],
      "id_str" : "17022132",
      "id" : 17022132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66802551894458369",
  "text" : "RT @utatakiyoshi: \u3053\u306E\u767A\u8A00\u304CRT\u3055\u308C\u305F\u968E\u6570\u3060\u3051f(x)=e^x\u3092\u5FAE\u5206\u3059\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14619506591",
    "text" : "\u3053\u306E\u767A\u8A00\u304CRT\u3055\u308C\u305F\u968E\u6570\u3060\u3051f(x)=e^x\u3092\u5FAE\u5206\u3059\u308B",
    "id" : 14619506591,
    "created_at" : "2010-05-24 12:21:38 +0000",
    "user" : {
      "name" : "utatakiyoshi",
      "screen_name" : "utatakiyoshi",
      "protected" : false,
      "id_str" : "17022132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2235262798\/neco_normal.png",
      "id" : 17022132,
      "verified" : false
    }
  },
  "id" : 66802551894458369,
  "created_at" : "2011-05-07 09:52:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66789419142742016",
  "text" : "\u30E2\u30C6\u308B\u79D1\u5B66\u529B\u3092\u78E8\u304F\u305F\u3081\u306E4\u3064\u306E\u5FC3\u5F97\u3000http:\/\/goo.gl\/78d53\u3000\u6D3E\u751F\u30CD\u30BF\u30A7\u2026",
  "id" : 66789419142742016,
  "created_at" : "2011-05-07 09:00:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66786672670552064",
  "text" : "\u4ECA\u66F4\u3060\u304C\u3053\u308C\u2026 http:\/\/goo.gl\/pifjW",
  "id" : 66786672670552064,
  "created_at" : "2011-05-07 08:49:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 3, 17 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66782069187031041",
  "text" : "RT @kokoro_G4_bot: \u660E\u667A\u5C0F\u8863\u306E\u8B0E\u304B\u3051\u3047\uFF01\u3000\u4ECA\u5E74\u306E\u5E72\u652F\u3068\u304B\u3051\u307E\u3057\u3066\u3001\u30EA\u30FC\u30C1\u3001\u30A4\u30C3\u30D1\u30C4\u3001\u30D4\u30F3\u30D5\u3001\u30A4\u30FC\u30DA\u30FC\u30B3\u30FC\u3001\u30C9\u30E9\u30C9\u30E9\u3068\u89E3\u304D\u307E\u3059\u3002\u305D\u306E\u30B3\u30B3\u30ED\u306F\uFF01\uFF08\uFF8B\uFF9F\uFF9B\uFF9D\uFF6F!!\uFF09\u3069\u3061\u3089\u3082\u3001\u30CF\u30CD\u3066\u30C8\u30D3\u307E\u3059\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/kokoro_G4_bot\" rel=\"nofollow\"\u003E\u5BFE\u602A\u76D7\u4E8B\u4EF6\u635C\u67FB\u30C1\u30FC\u30E0\uFF27\uFF14\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66781854098927616",
    "text" : "\u660E\u667A\u5C0F\u8863\u306E\u8B0E\u304B\u3051\u3047\uFF01\u3000\u4ECA\u5E74\u306E\u5E72\u652F\u3068\u304B\u3051\u307E\u3057\u3066\u3001\u30EA\u30FC\u30C1\u3001\u30A4\u30C3\u30D1\u30C4\u3001\u30D4\u30F3\u30D5\u3001\u30A4\u30FC\u30DA\u30FC\u30B3\u30FC\u3001\u30C9\u30E9\u30C9\u30E9\u3068\u89E3\u304D\u307E\u3059\u3002\u305D\u306E\u30B3\u30B3\u30ED\u306F\uFF01\uFF08\uFF8B\uFF9F\uFF9B\uFF9D\uFF6F!!\uFF09\u3069\u3061\u3089\u3082\u3001\u30CF\u30CD\u3066\u30C8\u30D3\u307E\u3059\uFF01",
    "id" : 66781854098927616,
    "created_at" : "2011-05-07 08:30:09 +0000",
    "user" : {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "protected" : false,
      "id_str" : "216818830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462028398336811008\/tEl8sKfb_normal.jpeg",
      "id" : 216818830,
      "verified" : false
    }
  },
  "id" : 66782069187031041,
  "created_at" : "2011-05-07 08:31:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66772011690622976",
  "text" : "@koketomi \u53E3\u306B\u91DD\u306E\u523A\u3055\u3063\u305F\u81EA\u5206\u3092\u91E3\u308A\u4E0A\u3052\u3066\u308Bkoketomi\u306E\u753B\u50CF\u304F\u3060\u3055\u3044",
  "id" : 66772011690622976,
  "created_at" : "2011-05-07 07:51:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66768728544641024",
  "text" : "\uFF08\u3068\u3044\u3044\u3064\u3064\u4ED5\u8FBC\u307F\u306F\u3059\u3067\u306B\u59CB\u307E\u3063\u3066\u3044\u308B\u306E\u3060\uFF01\uFF09",
  "id" : 66768728544641024,
  "created_at" : "2011-05-07 07:38:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66768640732700672",
  "text" : "\uFF11\uFF17\u6642\u306B\u306A\u3063\u305F\u3089\u304A\u5915\u98EF\u4F5C\u308D\u3046\u3002\u304B\u306A\u308A\u65E9\u3044\u3051\u3069\u3002",
  "id" : 66768640732700672,
  "created_at" : "2011-05-07 07:37:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 19, 30 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 36, 45 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66768299689639936",
  "text" : "\u9152\u98F2\u3093\u3067\u597D\u304D\u306A\u52C9\u5F37\u3068\u304B\u81F3\u9AD8\u3060\u308D RT @magokoro84: \u3048RT @nisehorn: \u304A\u9152\u98F2\u3093\u3060\u304B\u3089\u30EC\u30DD\u30FC\u30C8\u66F8\u3053\u3046\uFF01",
  "id" : 66768299689639936,
  "created_at" : "2011-05-07 07:36:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66762015825342465",
  "geo" : { },
  "id_str" : "66762507959808000",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30B5\u30F3\u30D7\u30EB\u6570\u304C\u5C11\u306A\u3059\u304E\u306A\u3044\u304B\uFF1F\uFF57",
  "id" : 66762507959808000,
  "in_reply_to_status_id" : 66762015825342465,
  "created_at" : "2011-05-07 07:13:16 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66759277657849857",
  "text" : "\u4F53\u611F\u7684\u306B\u306F\u307E\u3060\uFF11\uFF16\u6642\u3001\u8AB2\u984C\u7684\u306B\u306F\u3082\u3046\uFF11\uFF16\u6642\u3002\u5BA2\u89B3\u7684\u306B\u306F\u305F\u3060\u306E\uFF11\uFF16\u6642\u3002",
  "id" : 66759277657849857,
  "created_at" : "2011-05-07 07:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u306A\u304B\u3093",
      "screen_name" : "sanakan",
      "indices" : [ 0, 8 ],
      "id_str" : "5452512",
      "id" : 5452512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66750281479761921",
  "geo" : { },
  "id_str" : "66750809530056704",
  "in_reply_to_user_id" : 5452512,
  "text" : "@sanakan \u6C17\u5727\u3068\u304B\u6E7F\u5EA6\u3068\u304B\u3067\u3059\u304B\u306D\uFF1F\u6C17\u5727\u306F\u304B\u306A\u308A\u4F53\u8ABF\u5DE6\u53F3\u3057\u307E\u3059\u304C\u2026",
  "id" : 66750809530056704,
  "in_reply_to_status_id" : 66750281479761921,
  "created_at" : "2011-05-07 06:26:47 +0000",
  "in_reply_to_screen_name" : "sanakan",
  "in_reply_to_user_id_str" : "5452512",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66747366945984512",
  "text" : "@koketomi \u307E\u3041\u5197\u8AC7\u306F\u3068\u3082\u304B\u304F\u6163\u308C\u3066\u3066\u3082\u6C17\u3092\u4ED8\u3051\u3066\u306D\u3002\u5197\u8AC7\u3058\u3083\u306A\u304F\u30D6\u30E9\u30C3\u30AF\u30B8\u30E7\u30FC\u30AF\u304C\u30D6\u30E9\u30C3\u30AF\u306B\u3042\u308B\u3044\u306F\u30D6\u30E9\u30C3\u30C9\u30B8\u30E7\u30FC\u30AF\u306B\u306A\u3063\u3061\u3083\u3046\u304B\u3089\u3002",
  "id" : 66747366945984512,
  "created_at" : "2011-05-07 06:13:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66746979505541121",
  "text" : "@np2i \u53CB\u4EBA\u306B\u30AE\u30EA\u30B7\u30E3\u8A9E\u306E\u6559\u79D1\u66F8\u898B\u305B\u3066\u3082\u3089\u3063\u305F\u6642\u304C\u51C4\u304B\u3063\u305F\u3067\u3059\u3002\u66F8\u3044\u3066\u3042\u308B\u306E\u306F\u5358\u8A9E\u3058\u3083\u306A\u304F\u3066\u3069\u3046\u307F\u3066\u3082\u6587\u5B57\u5F0F\u306E\u7A4D\u2026\u3002",
  "id" : 66746979505541121,
  "created_at" : "2011-05-07 06:11:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66746006158581760",
  "text" : "@koketomi \u305D\u308C\u3063\u3066\u306A\u3093\u306E\u30D5\u30E9\u30B0\uFF1F\uFF57",
  "id" : 66746006158581760,
  "created_at" : "2011-05-07 06:07:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66740838075609088",
  "geo" : { },
  "id_str" : "66741002660098048",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u304A\u524D\u306E\u4ED5\u696D\u306A\u306E\uFF1F",
  "id" : 66741002660098048,
  "in_reply_to_status_id" : 66740838075609088,
  "created_at" : "2011-05-07 05:47:49 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66740657112363008",
  "text" : "\u75C5\u6C17\u2026",
  "id" : 66740657112363008,
  "created_at" : "2011-05-07 05:46:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66740530570211328",
  "text" : "\u30AE\u30EA\u30B7\u30E3\u6587\u5B57\u306F\u7279\u306B\u305D\u3046\u3060\u3051\u308C\u3069\u3001\u6700\u8FD1\u8A9E\u5B66\u3084\u3063\u3066\u308B\u3068\u4E00\u6587\u5B57\u4E00\u6587\u5B57\u304C\u6570\u5B66\u7684\u306A\u610F\u5473\u3092\u6301\u3063\u3066\u8A9E\u308A\u304B\u3051\u3066\u304F\u308B\u3002\u30D5\u30E9\u30F3\u30B9\u8A9E\u306Ey\u3068\u304B\u3069\u3046\u898B\u3066\u3082\u5909\u6570\u3060\u3057a\u3068\u304B\u3069\u3046\u307F\u3066\u3082\u5B9A\u6570\u3067\u3042\u308B\u3002",
  "id" : 66740530570211328,
  "created_at" : "2011-05-07 05:45:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66727524767510530",
  "text" : "\u3066\u304BRT\u306E\u3042\u3068\u306E\u534A\u89D2\u30B9\u30DA\u30FC\u30B9\u6D88\u3057\u3061\u3083\u30C0\u30E1\u306A\u306E\u306D\u3002\u6587\u5B57\u6570\u30AE\u30EA\u30AE\u30EA\u3060\u3063\u305F\u304B\u3089\u3064\u3044\u3002",
  "id" : 66727524767510530,
  "created_at" : "2011-05-07 04:54:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66727343300939776",
  "text" : "\u6C17\u6301\u3061\u306F\u3059\u3054\u304F\u308F\u304B\u308B\u3051\u3069\u306D\u3001\u55AB\u8336\u5E97\u3068\u304B\u30D5\u30A1\u30DF\u30EC\u30B9\u3067\u5468\u308A\u306E\u4EBA\u306E\u8A71\u3001\u4FFA\u3082\u3057\u3063\u304B\u308A\u805E\u3044\u3061\u3083\u3046\u3082\u306E\u3002",
  "id" : 66727343300939776,
  "created_at" : "2011-05-07 04:53:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 54, 68 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66727077138804736",
  "text" : "\u3053\u306E\u4EBA\u3001\u81EA\u5206\u306E\u30C4\u30A4\u30C3\u30BF\u30FC\u306A\u306E\u306B\u6A2A\u306B\u5EA7\u3063\u3066\u308B\u4EBA\u306E\u8A71\u3092\u59CB\u3081\u305F\u3002\u305F\u3076\u3093\u81EA\u5206\u306E\u3053\u3068\u4EE5\u4E0A\u306B\u4ED6\u4EBA\u304C\u6C17\u306B\u306A\u308B\u3093\u3060\u308D\u3046\u3002RT@OhgakiRintaro: \u6A2A\u306B\u5EA7\u3063\u3066\u308B\u4EBA\u3001\u81EA\u5206\u306E\u4FDD\u967A\u91D1\u306E\u76F8\u8AC7\u306A\u306E\u306B\u516C\u52D9\u54E1\u306E\u6279\u5224\u3068\u304B\u4ED6\u4EBA\u306E\u4F1A\u793E\u306E\u5012\u7523\u306E\u8A71\u3092\u3057\u59CB\u3081\u305F\u3002\u305F\u3076\u3093\u4FDD\u967A\u91D1\u306E\u3053\u3068\u4EE5\u4E0A\u306B\u3001\u8A71\u3092\u805E\u3044\u3066\u307B\u3057\u3044\u3093\u3060\u308D\u3046\u3002",
  "id" : 66727077138804736,
  "created_at" : "2011-05-07 04:52:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66723067560329217",
  "text" : "@ayu167 \u4E00\u6CCA\u3060\u3063\u3051\uFF1F",
  "id" : 66723067560329217,
  "created_at" : "2011-05-07 04:36:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66707574401146880",
  "text" : "@np2i \u305D\u3053\u307E\u3067\u3057\u3066\u3044\u305F\u3060\u304B\u306A\u304F\u3066\u3082\u9069\u5F53\u3067\u3088\u304B\u3063\u305F\u3067\u3059\u3088\u30FC\u3002\u306A\u3093\u306B\u3057\u3066\u3082\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059m(_ _)m",
  "id" : 66707574401146880,
  "created_at" : "2011-05-07 03:34:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66706192260542464",
  "text" : "@np2i \u7D19\u8DB3\u308A\u305F\uFF01\uFF08\u3042\u3041\u7A81\u3063\u8FBC\u307F\u3057\u3066\u304F\u308C\u308B\u4EBA\u304C\u3044\u308B\u306A\u3089\u3061\u3083\u3093\u3068\u5F85\u3066\u3070\u3088\u304B\u3063\u305F\u2026\uFF09",
  "id" : 66706192260542464,
  "created_at" : "2011-05-07 03:29:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66704947898621953",
  "text" : "\uFF08\u7D19\u8DB3\u308A\u305F\u2026\uFF01\uFF09",
  "id" : 66704947898621953,
  "created_at" : "2011-05-07 03:24:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66703242427498496",
  "text" : "\u5931\u793C\u3001\u565B\u307F\u307E\u3057\u305F\u2026",
  "id" : 66703242427498496,
  "created_at" : "2011-05-07 03:17:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66703137758646272",
  "text" : "\u3057\u304B\u3082\u8AB2\u984C\u305F\u307E\u3063\u3066\u308B\u306E\u306B\u904A\u3079\u308B\u3068\u3044\u3046\u4E8C\u6BB5\u69CB\u3048\u306B\u306A\u3063\u3066\u3044\u308B\u306E\u3089\uFF01",
  "id" : 66703137758646272,
  "created_at" : "2011-05-07 03:17:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66702627202809857",
  "text" : "\u305F\u3060\u5B9F\u969B\u300C\u591C\u3084\u308C\u3070\u3044\u3044\u3084\u30FC\u300D\u3063\u3064\u3063\u3066\u5F8C\u56DE\u3057\u306B\u3059\u308B\u306E\u306F\u7269\u7406\u7684\u306B\u907F\u3051\u3089\u308C\u308B\u30C3\uFF01",
  "id" : 66702627202809857,
  "created_at" : "2011-05-07 03:15:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66702449423028224",
  "text" : "\u591C\u306B\u308F\u3056\u308F\u3056\u4E88\u5B9A\u3092\u5165\u308C\u3066\u81EA\u5206\u3092\u8FFD\u3044\u8FBC\u3080\u4F5C\u6226\uFF08\u306E\u3075\u308A\u3092\u3057\u3066\u904A\u3076\u4F5C\u6226\uFF09",
  "id" : 66702449423028224,
  "created_at" : "2011-05-07 03:14:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66700269295116288",
  "text" : "@np2i \u60C5\u5831\u3069\u3082\u3067\u3059\u3002\u4E8C\u5EA6\u624B\u9593\u306F\u5ACC\u2026orz\u3000\u8DB3\u308A\u3066\u304F\u308C\u308B\u3053\u3068\u3092\u7948\u308A\u307E\u3059\u3002",
  "id" : 66700269295116288,
  "created_at" : "2011-05-07 03:05:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66699455486898176",
  "text" : "\u3053\u308C\u3067\u7D19\u304C\u8DB3\u308A\u306A\u304B\u3063\u305F\u3089\u6CE3\u304F\u306A\u2026\u30B3\u30D4\u30FC\u7528\u7D19\u3063\u3066\u30B3\u30F3\u30D3\u30CB\u3067\u58F2\u3063\u3066\u305F\u3063\u3051\uFF1F",
  "id" : 66699455486898176,
  "created_at" : "2011-05-07 03:02:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66698048763478016",
  "text" : "\u5317\u533A\u304B\u3089\u5E30\u5B85\u3002\u80C3\u307E\u3060\uFF08\u672A\u3060\uFF09\uFF27\uFF37\u306E\u6C17\u5206\u306A\u306E\u3067\u304A\u663C\u306F\u30C1\u30E7\u30B3\u3063\u3068\u3067\u3044\u3044\u3084\u3002",
  "id" : 66698048763478016,
  "created_at" : "2011-05-07 02:57:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66690438584729602",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u8CB7\u3044\u7269\u884C\u3063\u3066\u304F\u308B\u3002",
  "id" : 66690438584729602,
  "created_at" : "2011-05-07 02:26:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5922\u4E8C",
      "screen_name" : "mesaya31",
      "indices" : [ 0, 9 ],
      "id_str" : "174262858",
      "id" : 174262858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66688217012908032",
  "geo" : { },
  "id_str" : "66689076992032768",
  "in_reply_to_user_id" : 174262858,
  "text" : "@mesaya31 \u938C\u5009\u3001\u96E8\u3063\u3066\u3044\u3046\u3068\u7D2B\u967D\u82B1\u306E\u30A4\u30E1\u30FC\u30B8\u306A\u3093\u3060\u3051\u3069\u2026\u3061\u3087\u3063\u3068\u65E9\u3044\u304B\u3002",
  "id" : 66689076992032768,
  "in_reply_to_status_id" : 66688217012908032,
  "created_at" : "2011-05-07 02:21:29 +0000",
  "in_reply_to_screen_name" : "mesaya31",
  "in_reply_to_user_id_str" : "174262858",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 0, 10 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66686844473057280",
  "geo" : { },
  "id_str" : "66687352206139393",
  "in_reply_to_user_id" : 111007432,
  "text" : "@tadash126 \u3053\u3063\u3061\u306F\u4E00\u5FDC\u6674\u308C\u3066\u308B\u3002\u671D\u306F\u66C7\u3063\u3066\u305F\u3051\u3069\u3002\u65E9\u3044\u3053\u3068\u6B62\u3080\u3068\u3044\u3044\u306D\u3002",
  "id" : 66687352206139393,
  "in_reply_to_status_id" : 66686844473057280,
  "created_at" : "2011-05-07 02:14:38 +0000",
  "in_reply_to_screen_name" : "tadash126",
  "in_reply_to_user_id_str" : "111007432",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66685591974195200",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u9AEA\u304C\u4E7E\u304F\u307E\u3067\u306E\u3093\u3073\u308A\u8AAD\u66F8\u3057\u3066\u304A\u3053\u3046\u3002",
  "id" : 66685591974195200,
  "created_at" : "2011-05-07 02:07:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66685398256070657",
  "text" : "\u7D50\u5C40\u8CB7\u3044\u7269\u884C\u304B\u306A\u3044\u3068\u30C0\u30E1\u306A\u306E\u304B\u2026\u30A4\u30F3\u30AF\u3063\u3066\u7D50\u69CB\u9AD8\u3044\u3093\u3060\u3088\u306D\u3002",
  "id" : 66685398256070657,
  "created_at" : "2011-05-07 02:06:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66684582585573376",
  "text" : "\u7D50\u5C40\u82F1\u8A9E\u306Ecall\u3063\u3066\u3069\u3046\u306A\u3063\u3066\u3093\u306E\u304B\u3055\u3063\u3071\u308A\u308F\u304B\u3093\u306A\u3044orz",
  "id" : 66684582585573376,
  "created_at" : "2011-05-07 02:03:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66683030730842112",
  "text" : "\u3042\u30FC\u3082\u3046\u30A4\u30F3\u30AF\u3082\u8CB7\u3044\u306B\u884C\u304B\u306A\u304D\u3083\u3044\u3051\u306A\u3044\u306E\u304B\u3088\u3002\u3042\u3063\u305F\u304B\u3044\u3046\u3061\u306B\u884C\u304B\u306A\u304D\u3083\u2026\u3002\u307E\u3060\u5348\u524D\u4E2D\u3060\u3051\u3069\u3002",
  "id" : 66683030730842112,
  "created_at" : "2011-05-07 01:57:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66661115790245889",
  "text" : "\u3068\u306F\u3044\u3048\u307E\u3060\u4F53\u8ABF\u306F\u597D\u8ABF\u3068\u306F\u8A00\u3048\u306A\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\u304A\u306A\u304B\u306B\u9055\u548C\u611F\u3002",
  "id" : 66661115790245889,
  "created_at" : "2011-05-07 00:30:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66659437854720000",
  "text" : "\u898B\u5F53\u305F\u3089\u306A\u3044\uFF1B\uFF1B\u5F8C\u3067\u8CB7\u3044\u306B\u884C\u304F\u304B\u306A\u2026",
  "id" : 66659437854720000,
  "created_at" : "2011-05-07 00:23:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66657784397185024",
  "text" : "\u3069\u3053\u304B\u306B\u4ED5\u821E\u3063\u3066\u3042\u308B\u306F\u305A",
  "id" : 66657784397185024,
  "created_at" : "2011-05-07 00:17:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66657595540250624",
  "text" : "\u3042\u3041\u3055\u3063\u304D\u30B3\u30F3\u30D3\u30CB\u884C\u3063\u305F\u3068\u304D\u30D3\u30F3\u30AB\u30F3\u30DA\u30C3\u30C8\u7528\u306E\u888B\u98FC\u3046\u3079\u304D\u3060\u3063\u305F\u3002\u3067\u3082\u3069\u3063\u304B\u306B\u3042\u308B\u6C17\u304C\u3059\u308B\u3093\u3060\u3088\u306A\u30FC",
  "id" : 66657595540250624,
  "created_at" : "2011-05-07 00:16:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66655590339977217",
  "text" : "@ayu167 \u304A\u306F\u3088\u3046",
  "id" : 66655590339977217,
  "created_at" : "2011-05-07 00:08:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66651011586068480",
  "text" : "\uFF08\u8EAB\u8FBA\u6574\u7406\u3063\u3066\u7D76\u5BFE\u8A00\u8449\u306E\u30C1\u30E7\u30A4\u30B9\u9593\u9055\u3048\u3066\u3044\u308B\u3088\u306A\u30FC\uFF09",
  "id" : 66651011586068480,
  "created_at" : "2011-05-06 23:50:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66650491723059200",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u5348\u524D\u4E2D\u306B\u8EAB\u8FBA\u6574\u7406\uFF08\u6383\u9664\u3068\u304B\u6D17\u3044\u7269\u3068\u304B\uFF09\u3092\u3084\u3063\u3064\u3051\u308B\uFF01",
  "id" : 66650491723059200,
  "created_at" : "2011-05-06 23:48:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66648399692316672",
  "text" : "\uFF34\uFF4F\u3000\uFF44\uFF4F\u4F5C\u308B\u3068\u6848\u5916\u65E5\u4ED8\u306B\u4F59\u88D5\u304C\u306A\u3044\u306A\u2026",
  "id" : 66648399692316672,
  "created_at" : "2011-05-06 23:39:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66647205032886272",
  "geo" : { },
  "id_str" : "66647469546680320",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u305D\u3053\u3044\u3044\u3068\u3053\u308D\u306A\u306E\u306B\u306D\u30FC",
  "id" : 66647469546680320,
  "in_reply_to_status_id" : 66647205032886272,
  "created_at" : "2011-05-06 23:36:09 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66643777875492864",
  "text" : "\u3055\u3066todo\u30EA\u30B9\u30C8\u4F5C\u308B\u3068\u3053\u308D\u304B\u3089\u59CB\u3081\u3066\u307F\u3088\u3046\u304B\u30FC",
  "id" : 66643777875492864,
  "created_at" : "2011-05-06 23:21:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66619342028156929",
  "text" : "\u30B3\u30F3\u30D3\u30CB\u306B\u30D1\u30F3\u3092\u8CB7\u3044\u306B\u884C\u304F\u5922\u3092\u898B\u305F\u304B\u3089\u30B3\u30F3\u30D3\u30CB\u306B\u30D1\u30F3\u3092\u8CB7\u3044\u306B\u884C\u3053\u3046\u3002",
  "id" : 66619342028156929,
  "created_at" : "2011-05-06 21:44:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66618624957362176",
  "text" : "\uFF12\uFF11\u6642\u524D\u306B\u5BDD\u308C\u3070\u3053\u3046\u306A\u308B\u308F\u306A\u3002\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 66618624957362176,
  "created_at" : "2011-05-06 21:41:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66460150013235200",
  "text" : "\u660E\u65E5\u304B\u3089\u306F\u307E\u3068\u3082\u306B\u6D3B\u52D5\u3057\u306A\u3044\u3068\u8272\u3005\u9593\u306B\u5408\u308F\u306A\u3044\u306A\u2026",
  "id" : 66460150013235200,
  "created_at" : "2011-05-06 11:11:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66458255903305728",
  "text" : "\u306A\u3093\u304B\u3082\u3046\u7720\u3044\u2026\u306A\u3093\u3067\uFF1F",
  "id" : 66458255903305728,
  "created_at" : "2011-05-06 11:04:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Y.Motohashi",
      "screen_name" : "bukuburi",
      "indices" : [ 0, 9 ],
      "id_str" : "187163335",
      "id" : 187163335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66441595184103424",
  "geo" : { },
  "id_str" : "66442600487456768",
  "in_reply_to_user_id" : 187163335,
  "text" : "@bukuburi \u50D5\u3082\u6298\u308A\u8FD4\u3057\u3066\u639B\u3051\u308B\u3068\uFF08\u3053\u306E\u8868\u73FE\u306F\u308F\u304B\u308A\u306B\u304F\u3044\u3067\u3057\u3087\u3046\u304B\uFF09\u5143\u306E\u6570\u306E\u4E57\u6570\u306B\u306A\u308B\u306A\u30FC\u3068\u601D\u3063\u3066\u8A08\u7B97\u3057\u307E\u3057\u305F\u3002\u9AD8\u300518\u500B\u3060\u3063\u305F\u3093\u3067\u4E00\u5FDC\u6307\u6570\u8868\u8A18\u3067\u66F8\u304D\u4E0B\u3057\u3082\u3084\u3063\u3066\u307F\u307E\u3057\u305F\u3051\u3069\u3002",
  "id" : 66442600487456768,
  "in_reply_to_status_id" : 66441595184103424,
  "created_at" : "2011-05-06 10:02:05 +0000",
  "in_reply_to_screen_name" : "bukuburi",
  "in_reply_to_user_id_str" : "187163335",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66427347393458176",
  "geo" : { },
  "id_str" : "66427714671869952",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5927\u5B66\u306B\uFF30\uFF23\u304C\u3042\u308B\u3068\u305D\u308C\u3067\u3067\u304D\u305F\u308A\u3067\u304D\u306A\u304B\u3063\u305F\u308A\u3002",
  "id" : 66427714671869952,
  "in_reply_to_status_id" : 66427347393458176,
  "created_at" : "2011-05-06 09:02:56 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66427626700546048",
  "text" : "C\u56DB\u8A71\u307E\u3067\u898B\u3066\u307F\u305F\u3002\u306A\u3093\u304B\u4ECA\u5B63\u306E\u30CE\u30A4\u30BF\u30DF\u30CA\u67A0\u826F\u4F5C\u63C3\u3044\u304B\u3082\u3002",
  "id" : 66427626700546048,
  "created_at" : "2011-05-06 09:02:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66164889776963585",
  "text" : "\u3055\u3066\u5BDD\u3088\u3046\u3002\u7D20\u6575\u306A\u5922\u3092\u898B\u308C\u308B\u3068\u3044\u3044\u306A\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 66164889776963585,
  "created_at" : "2011-05-05 15:38:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66161794892308480",
  "text" : "TL\u304C\u97F3\u7121\u3057\u3044",
  "id" : 66161794892308480,
  "created_at" : "2011-05-05 15:26:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cluster_hantei",
      "indices" : [ 91, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/sBv7DXS",
      "expanded_url" : "http:\/\/ducky199999.appspot.com\/jsp\/cluster.jsp",
      "display_url" : "ducky199999.appspot.com\/jsp\/cluster.jsp"
    } ]
  },
  "geo" : { },
  "id_str" : "66149154174418944",
  "text" : "bot\u30AF\u30E9\u30B9\u30BF\u3001\u30D5\u30A9\u30ED\u30A2\u2015\u30AF\u30E9\u30B9\u30BF\u3063\u3066\u4F55\u306A\u306E\u3055\u3002 end313124\u3055\u3093\u306E\u5C5E\u3059\u308B\u30AF\u30E9\u30B9\u30BF\u306F\u3001bot\u30AF\u30E9\u30B9\u30BF\u3001\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u3001\u82F1\u8A9E\u30AF\u30E9\u30B9\u30BF\u3001\u6570\u5B66\u30AC\u30FC\u30EB\u30AF\u30E9\u30B9\u30BF\u3001\u30D5\u30A9\u30ED\u30A2\u30FC\u30AF\u30E9\u30B9\u30BF\u3067\u3059\u3002 #cluster_hantei http:\/\/t.co\/sBv7DXS",
  "id" : 66149154174418944,
  "created_at" : "2011-05-05 14:36:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66148930534125568",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u3044\u308D\u3093\u306A\u610F\u5473\u3067\u30D5\u30A1\u30F3\u306B\u306A\u308A\u304D\u308C\u306A\u3044\u81EA\u4FE1\u304C\u3042\u308B\u3002",
  "id" : 66148930534125568,
  "created_at" : "2011-05-05 14:35:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicovideo",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "sm14319129",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 93 ],
      "url" : "http:\/\/t.co\/L9ZMMzO",
      "expanded_url" : "http:\/\/nico.ms\/sm14319129",
      "display_url" : "nico.ms\/sm14319129"
    } ]
  },
  "geo" : { },
  "id_str" : "66148627462103041",
  "text" : "\u30DF\u30EB\u30AD\u30A3\u597D\u304D\u3060\u3051\u3069\u3001\u3053\u308C\u306F\u2026\u2026\u30005\/1 \u6A2A\u6D5C\u5BFE\u5DE8\u4EBA \u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA\u59CB\u7403\u5F0F\uFF08\u9AD8\u753B\u8CEA\u7248\uFF09 (6:42) #nicovideo #sm14319129 http:\/\/t.co\/L9ZMMzO",
  "id" : 66148627462103041,
  "created_at" : "2011-05-05 14:33:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66145448519405568",
  "geo" : { },
  "id_str" : "66145806125764609",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u6843\u7F36\u30C3\uFF1F\uFF01",
  "id" : 66145806125764609,
  "in_reply_to_status_id" : 66145448519405568,
  "created_at" : "2011-05-05 14:22:43 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66145392181510144",
  "text" : "\u98A8\u90AA\u85AC\u3092\u70AD\u9178\u6C34\u3067\u98F2\u3093\u3067\u308B\u306E\u304C\u3044\u3051\u306A\u3044\u306E\u304B\u306A\u30FC\uFF1F",
  "id" : 66145392181510144,
  "created_at" : "2011-05-05 14:21:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66145082096619520",
  "text" : "\u6570\u5024\u3092\u898B\u308B\u3068\u306A\u305C\u304B\u75C7\u72B6\u304C\u9855\u8457\u306B\u306A\u308B\u304B\u3089\u4F53\u6E29\u306F\u304B\u3093\u306A\u304B\u3063\u305F\u3051\u3069\u4ECA\u56F3\u3063\u305F\u3089\u5FAE\u71B1\u2026\u7BC0\u3005\u304C\u75DB\u3044\u306E\u306F\u534A\u3070\u3044\u3064\u3082\u3060\u3051\u3069\u3002\u5909\u306A\u4F53\u8ABF\u3002",
  "id" : 66145082096619520,
  "created_at" : "2011-05-05 14:19:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66143372506701825",
  "text" : "\u6771\u98A8\u3067\u6CB3\u5E95\u3068\u6D77\u5E95\u4E00\u56DE\u3065\u3064 \u5076\u7136\u3060\u3051\u3069\u2026\u3000http:\/\/goo.gl\/wt9XZ",
  "id" : 66143372506701825,
  "created_at" : "2011-05-05 14:13:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 0, 10 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "66118333887553536",
  "geo" : { },
  "id_str" : "66119764363325440",
  "in_reply_to_user_id" : 131534834,
  "text" : "@maru_mtod \u30D5\u30E9\u30AF\u30BF\u30EB\u306EOP\u9762\u767D\u304B\u3063\u305F\u3067\u3059\u3088\u306D\u30FC\u3002\u4F5C\u54C1\u306E\u4E16\u754C\u89B3\u3082\u597D\u304D\u3067\u3057\u305F\u3002",
  "id" : 66119764363325440,
  "in_reply_to_status_id" : 66118333887553536,
  "created_at" : "2011-05-05 12:39:14 +0000",
  "in_reply_to_screen_name" : "maru_mtod",
  "in_reply_to_user_id_str" : "131534834",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66075224826843136",
  "text" : "ipod\u3067\u4F7F\u3044\u3084\u3059\u3044To do\u30EA\u30B9\u30C8\u30E1\u30E2\u306A\u3093\u304B\u306A\u3044\u304B\u306A\u30FC\u3001\u3069\u308C\u3082\u4F3C\u305F\u308A\u5BC4\u3063\u305F\u308A\u3002\u30EC\u30DD\u30FC\u30C8\u3068\u304B\u8AB2\u984C\u3068\u304B\u30EA\u30B9\u30C8\u4F5C\u3063\u3066\u7BA1\u7406\u3059\u308B\u3068\u5999\u306B\u306F\u304B\u3069\u308B\u3093\u3060\u3051\u3069\u3002",
  "id" : 66075224826843136,
  "created_at" : "2011-05-05 09:42:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 19, 33 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66074487061348352",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u8AAD\u3093\u3067\u304B\u3089\u8003\u3048\u76F4\u305B\uFF01 RT @OhgakiRintaro: \u30AB\u30C3\u30D7\u30EB\u3067\u52C9\u5F37\u306F\u3084\u3081\u305F\u307B\u3046\u304C\u826F\u3044\u3002\uFF12\u4EBA\u3067\u8A71\u3059\u307B\u3046\u304C\u3001\u52C9\u5F37\u3059\u308B\u3088\u308A\u697D\u3057\u3044\u304B\u3089\u3060\u3002\u5B9F\u969B\u3001\u524D\u306B\u3044\u308B\u30AB\u30C3\u30D7\u30EB\u306F\u53C2\u8003\u66F8\u3092\u958B\u3044\u3066\u898B\u3064\u3081\u5408\u3063\u3066\u3044\u308B\u3002",
  "id" : 66074487061348352,
  "created_at" : "2011-05-05 09:39:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66035550670426112",
  "text" : "\u4ECA\u9031\u306E\u554F\u984C\u3084\u3063\u3068\u62FE\u3048\u305F\u3002\u5E03\u56E3\u306E\u4E2D\u3067\u8003\u3048\u3088\u3046\u3063\u3068\u3002",
  "id" : 66035550670426112,
  "created_at" : "2011-05-05 07:04:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66034031980052480",
  "text" : "\u4F55\u3084\u3063\u3066\u3082\u982D\u56DE\u3089\u306A\u3055\u305D\u3046\u306A\u611F\u3058\u3002",
  "id" : 66034031980052480,
  "created_at" : "2011-05-05 06:58:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66033931069304833",
  "text" : "\u4F53\u8ABF\u304C\u5FAE\u5999\u2026\u5B66\u6821\u306F\u3044\u3051\u306A\u3044\u3051\u308C\u3069\u30B2\u30FC\u30E0\u306F\u3067\u304D\u308B\u3002\u6B69\u3051\u308B\u3051\u308C\u3069\u9060\u51FA\u306F\u3067\u304D\u306A\u3044\u3002\u9F3B\u3068\u306E\u3069\u306F\u7D76\u4E0D\u8ABF\u3060\u3051\u308C\u3069\u3001\u982D\u75DB\u306F\u3042\u308B\u306E\u304B\u306A\u3044\u306E\u304B\u5FAE\u5999\u306A\u30E9\u30A4\u30F3\u3002",
  "id" : 66033931069304833,
  "created_at" : "2011-05-05 06:58:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66032495581347842",
  "text" : "\u3042\u306E\u65E5\u898B\u305F\u82B1\u306E\u540D\u524D\u3092\uFF08\uFF52\uFF59 \u30923\u8A71\u307E\u3067\u898B\u305F\u3002\u3068\u3044\u3046\u304B\u307E\u3060\u4E09\u8A71\u307E\u3067\u3057\u304B\u306A\u3044\u306E\u3060\u3051\u308C\u3069\u3002\u3084\u3063\u3071\u61D0\u304B\u3057\u3044\u5207\u306A\u3044\u611F\u3058\u3002",
  "id" : 66032495581347842,
  "created_at" : "2011-05-05 06:52:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65791847519354880",
  "text" : "TL\u5927\u4EBA\u3057\u304F\u97F3\u7121\u304F\u306A\u3063\u305F\u306A",
  "id" : 65791847519354880,
  "created_at" : "2011-05-04 14:56:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65787235873726464",
  "geo" : { },
  "id_str" : "65788608237416449",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa 100\u30DE\u30B9\u8A08\u7B97w",
  "id" : 65788608237416449,
  "in_reply_to_status_id" : 65787235873726464,
  "created_at" : "2011-05-04 14:43:21 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65784270232371200",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u30B3\u30DF\u30C3\u30AF\u7248\u3001\u5E2F\u304C\u30BA\u30EC\u3066\u300C\u6570\u5B66\u30AC\u30FC\u300D\u306B\u306A\u3063\u3066\u308B\u3002\u30AC\u30FC\u3063\u3066\u30A2\u30DE\u30BE\u30F3\u3060\u304B\u306B\u3044\u308B\u3088\u3046\u306A\u5DE8\u5927\u9B5A\u3060\u3063\u305F\u8A18\u61B6\u3057\u3066\u3044\u308B\u3051\u3069\u3001\u6570\u5B66\u3059\u308B\u5DE8\u5927\u9B5A\u3063\u3066\u2026\uFF1F",
  "id" : 65784270232371200,
  "created_at" : "2011-05-04 14:26:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65777475573133312",
  "text" : "\u306A\u3093\u304B\u3084\u3063\u3071\u3060\u308B\u3044\u3002\u3044\u3064\u3082\u3060\u308B\u305D\u3046\u306B\u3057\u3066\u308B\u69D8\u306B\u898B\u3048\u308B\u304B\u3082\u3060\u3051\u3069\u30FC\u3002",
  "id" : 65777475573133312,
  "created_at" : "2011-05-04 13:59:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u308B",
      "screen_name" : "maru_mtod",
      "indices" : [ 23, 33 ],
      "id_str" : "131534834",
      "id" : 131534834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65774311260168192",
  "text" : "\u03C0\u306E\u672C\u5F53\u306E\u59FF\u3092\u4EBA\u985E\u306F\u307E\u3060\u77E5\u3089\u306A\u3044\u30C3\u2026! RT @maru_mtod: \u03C0\u306B\u89E6\u308C\u308B\u3053\u3068\u306F\u3067\u304D\u306A\u3044\u30FB\u30FB\u30FB\uFF01\uFF01\u03C0\u3092\u898B\u308B\u3053\u3068\u3082\u3067\u304D\u306A\u3044\u30C3\u30FB\u30FB\uFF01\uFF01",
  "id" : 65774311260168192,
  "created_at" : "2011-05-04 13:46:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65772748177293313",
  "geo" : { },
  "id_str" : "65773138612453376",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u52DD\u624B\u306B\u4F11\u3080\u3060\u3051",
  "id" : 65773138612453376,
  "in_reply_to_status_id" : 65772748177293313,
  "created_at" : "2011-05-04 13:41:52 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65772578396045312",
  "text" : "\u6708\u66DC\u65E5\u3068\u91D1\u66DC\u65E5\u306F\u631F\u307F\u6483\u3061\u306E\u539F\u7406\u3067\u6388\u696D\u306E\u6570\u306F0\u306B\u53CE\u675F \u52C9\u5F37\u91CF\u306F\u53CE\u675F\u3057\u306A\u3044\u69D8\u306B\u3057\u306A\u3051\u308C\u3070\u2026",
  "id" : 65772578396045312,
  "created_at" : "2011-05-04 13:39:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 22, 32 ],
      "id_str" : "111007432",
      "id" : 111007432
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 34, 44 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65771857802047488",
  "text" : "\u53C2\u8003\u66F8\u306E\u540D\u524D\u5DEE\u3057\u652F\u3048\u306A\u3051\u308C\u3070\u6559\u3048\u3066\u30FC RT @tadash126: @end313124  \u826F\u304B\u3063\u305F\uFF01 \u3084\u3063\u3071\u7FD2\u3063\u3066\u306A\u3044\u3088\u306D\uFF08\u7B11\uFF09 \u307E\u3041\u7FD2\u3063\u3066\u305F\u3068\u3057\u3066\u3082\u3001\u306D \u3061\u306A\u307F\u306Bfew\u3068\u304Blittle\u3092\u8AAC\u660E\u3059\u308B\u306E\u306B\u7528\u3044\u3066\u305F\u3002",
  "id" : 65771857802047488,
  "created_at" : "2011-05-04 13:36:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65766239993208832",
  "text" : "\u300C\u5B64\u72EC\u306E\u30B0\u30EB\u30E1\u300D\u3063\u3066\u6F2B\u753B\u304C\u5927\u597D\u304D\u306A\u306E\u3060\u3051\u308C\u3069\u30D5\u30A9\u30ED\u30EF\u3055\u3093\u306E\u4E2D\u306B\u8AAD\u3093\u3060\u3053\u3068\u3042\u308B\u4EBA\u3044\u308B\u306E\u304B\u306A\uFF1F\u4F55\u304C\u9762\u767D\u3044\u306E\u304B\u8AAC\u660E\u3067\u304D\u306A\u3044\u3063\u3066\u7279\u7570\u306A\u6F2B\u753B\u3002",
  "id" : 65766239993208832,
  "created_at" : "2011-05-04 13:14:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65765770222768129",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u660E\u65E5\u306F\u3057\u3063\u304B\u308A\u4F11\u307F\u3092\u53D6\u308D\u3046\u3002\u5915\u65B9\u304B\u3089\u591C\u3001\u9EBB\u96C0\u3059\u308B\u8A71\u3082\u3042\u308B\u3051\u3069\u3069\u3046\u306A\u3093\u3060\u308D\u3046\u2026\u3002",
  "id" : 65765770222768129,
  "created_at" : "2011-05-04 13:12:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65765101742993408",
  "text" : "\u6A2A\u306B\u306A\u3063\u3066ipod\u3068\u643A\u5E2F\u304B\u3089\u898B\u308B\u304B\u306A\u30FC\u3002Skype\u5165\u308A\u305F\u3044\u304B\u3089\u30CE\u30FC\u30C8\u4ED8\u3051\u3088\u3046\u304B\u2026\u3080\u3045\u3002",
  "id" : 65765101742993408,
  "created_at" : "2011-05-04 13:09:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65763355201253377",
  "text" : "\u4F53\u8ABF\u3059\u3050\u308C\u306A\u3044\u5272\u306B\u9045\u304F\u307E\u3067\u9EBB\u96C0\u3084\u3063\u305F\u308A\u3001\u89B3\u5149\u3057\u3066\u6BCE\u6669\u5451\u3093\u3067\u305F\u306E\u3082\u826F\u304F\u306A\u304B\u3063\u305F\u304B\u3082\u3002\u54B3\u3082\u306E\u3069\u306E\u75DB\u307F\u3082\u3002\u8CA7\u5F31\u306B\u306A\u3063\u305F\u3082\u3093\u3060\u306A\u3002",
  "id" : 65763355201253377,
  "created_at" : "2011-05-04 13:03:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65762982558314497",
  "text" : "\u305F\u3060\u306A\u3093\u304B\u71B1\u3063\u307D\u3044\u3002\u8CA7\u5F31\u306B\u306A\u3063\u305F\u3082\u306E\u3060\u306A\u3002",
  "id" : 65762982558314497,
  "created_at" : "2011-05-04 13:01:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65762813209092096",
  "text" : "\u3042\u306E\u65E5\u898B\u305F\u82B1\u306E\u540D\u524D\u3092\u50D5\u305F\u3061\u306F\u307E\u3060\u77E5\u3089\u306A\u3044\u3002\u4E00\u8A71\u898B\u3066\u307F\u305F\u3002\u306A\u3093\u304B\u61D0\u304B\u3057\u3044\u3088\u3046\u306A\u5207\u306A\u3044\u3088\u3046\u306A\u2026\u30E1\u30F3\u30DE\u3068\u30CD\u30C3\u30B5\u304C\u3061\u3087\u3063\u3068\u88AB\u308B\u3002\u5954\u653E\u306A\u611F\u3058\u3002",
  "id" : 65762813209092096,
  "created_at" : "2011-05-04 13:00:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65760821237657602",
  "geo" : { },
  "id_str" : "65761057754460160",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u305F\u3060\u5358\u306B\u304A\u524D\u306E\u30D5\u30A9\u30ED\u30A2\u30FC\u306B\u30F2\u30BF\u30AF\u3068\u30DE\u30B8\u57FA\u5730\u3057\u304B\u3044\u306A\u3044\u3093\u3058\u3083\u306A\u3044\u304B\uFF1F",
  "id" : 65761057754460160,
  "in_reply_to_status_id" : 65760821237657602,
  "created_at" : "2011-05-04 12:53:52 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65738031189069825",
  "text" : "@koketomi \u3054\u3056\u308B\u30A7\u2026\u2026",
  "id" : 65738031189069825,
  "created_at" : "2011-05-04 11:22:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter-tools.herokuapp.com\" rel=\"nofollow\"\u003E\u5224\u5B9A\u3068\u304B\u30B8\u30A7\u30CD\u30EC\u30FC\u30BF\u3068\u304B\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youyaku_tl",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/wN4fNBX",
      "expanded_url" : "http:\/\/ducky199999.appspot.com\/jsp\/youyaku_tl.jsp",
      "display_url" : "ducky199999.appspot.com\/jsp\/youyaku_tl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "65736531666681856",
  "text" : "TL\u3092\u8981\u7D04\u3002\u300C\u82F1\u8A9E\u306E\u81EA\u6162\u306E\u7ACB\u65B9\u4F53\u304C\u6B63\u6574\u6570\u306E\u51B7\u305F\u3055\u3067\u66F4\u306B\u98A8\u90AA\u304C\u6BD4\u4F8B\u3057\u3066\u306A\u3044\u6570\u5C11\u306A\u3044\u53CD\u4F8B\u3002\u76EE\u6A19\u3060\u3051\u3069\u30B4\u30FC\u30EB\u3058\u3083\u306A\u3044\u9053\u3082\u5206\u304B\u3089\u306A\u3044\u3057\u3001\u8A02\u6B63\u3059\u308B\u30A2\u30EA\u30B9\u30C8\u30C6\u30EC\u30B9\u54F2\u5B66\u3092\u6458\u3080\u304C\u5982\u304F\u52B9\u3044\u3066\u30FCgtlt\u79C1\u306F\u3088\u304F\u3001\u4E45\u300D #youyaku_tl http:\/\/t.co\/wN4fNBX",
  "id" : 65736531666681856,
  "created_at" : "2011-05-04 11:16:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65732433869418496",
  "geo" : { },
  "id_str" : "65733343202906112",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 65733343202906112,
  "in_reply_to_status_id" : 65732433869418496,
  "created_at" : "2011-05-04 11:03:44 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 15, 20 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    }, {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 21, 31 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65697805452324864",
  "geo" : { },
  "id_str" : "65698334542790657",
  "in_reply_to_user_id" : 230889478,
  "text" : "@kouennnoyuugu @np2i @tadash126 \u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u306E\u4EBA\u53CD\u5FDC\u3088\u3059\u304E\u308B\uFF01",
  "id" : 65698334542790657,
  "in_reply_to_status_id" : 65697805452324864,
  "created_at" : "2011-05-04 08:44:38 +0000",
  "in_reply_to_screen_name" : "phy_neko",
  "in_reply_to_user_id_str" : "230889478",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaDaSHi",
      "screen_name" : "tadash126",
      "indices" : [ 24, 34 ],
      "id_str" : "111007432",
      "id" : 111007432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65695668567670784",
  "text" : "\u5B89\u5FC3\u3057\u308D\uFF13c\u306E\u7BC4\u56F2\u3060\u3002\u3057\u304B\u3057\u7D20\u6575\u306A\u8868\u73FE\u3060\u3002RT @tadash126: \u3010\u82F1\u8A9E\u306E\u6587\u6CD5\u66F8\u3011 \uFF08\u4E2D\u7565\uFF09\u306F\u6570\u5B66\u3067\u7FD2\u3046\u300Clim\u300Dx\u21920\u306E\u767A\u60F3\u3067\u3042\u308B\u3002 \u3063\u3066\u308F\u304B\u308A\u3065\u3089\u3044\u3088\uFF08\u7B11\uFF09 \u7FD2\u3063\u3066\u306A\u3044\u3088\uFF01\u7FD2\u3063\u305F\u304B\u3082\u77E5\u308C\u306A\u3044\u3051\u3069\u5FD8\u308C\u305F\u3088\uFF01",
  "id" : 65695668567670784,
  "created_at" : "2011-05-04 08:34:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65458673010479104",
  "text" : "@haru_urah_rah \u3042\u3041\u306A\u3093\u3066\u53B3\u5BC6\u3058\u3083\u306A\u3044\u5947\u5999\u306A\u8868\u73FE\u2026\u6065\u305A\u304B\u3057\u3044\u3002",
  "id" : 65458673010479104,
  "created_at" : "2011-05-03 16:52:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65457799236296704",
  "text" : "@np2i \u304A\u3063\u3057\u3083\u308B\u901A\u308A\u3067\u3059\u3002\u66F8\u304D\u306A\u304C\u3089\u9577\u304F\u3059\u308B\u3053\u3068\u3092\u601D\u3044\u3064\u3044\u305F\u306E\u3067\u3053\u306E\u6709\u69D8\u3067\u3059\u3002\u3084\u3063\u3071\u898B\u3066\u308B\u4EBA\u306F\u898B\u3066\u307E\u3059\u306D\u3047\u3002",
  "id" : 65457799236296704,
  "created_at" : "2011-05-03 16:48:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65457143154868224",
  "text" : "\u5BDD\u305F\u3075\u308A\u3059\u308B\u3068\u3053\u308D\u304B\u3089\u59CB\u3081\u3088\u3046\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 65457143154868224,
  "created_at" : "2011-05-03 16:46:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 32, 43 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65456384816316416",
  "text" : "\u30B5\u30FC\u30AF\u30EB\u3068\u306F\u8A00\u3048\u5186\u3068\u547C\u3079\u306A\u3044\u3088\u3046\u306A\u96E2\u6563\u7684\u306A\u4EBA\u6570\u3060\u3063\u305F\u308A\u306D RT @magokoro84: \u3060\u304C\u305D\u306E\u30B5\u30FC\u30AF\u30EB\u306B\u7537\u3057\u304B\u304A\u3089\u305A\u3001\u5B66\u90E8\u306E\u5973\u306E\u5B50\u3082\u3059\u3050\u30C1\u30E3\u30E9\u3044\u306E\u306B\u5F15\u3063\u304B\u304B\u308B\u3068\u3044\u3046\u7F60",
  "id" : 65456384816316416,
  "created_at" : "2011-05-03 16:43:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65455570374754304",
  "text" : "\u6700\u8FD1\u306E\u30C4\u30A4\u30FC\u30C8\u3067\u306F\uFF57\u3092\u4F7F\u308F\u306A\u304F\u306A\u3063\u305F\u306A\u3041\u3002\u30C1\u30E3\u30C3\u30C8\u4F4D\u3067\u3057\u304B\u4F7F\u3063\u3066\u306A\u3044\u3088\u3046\u306A\u6C17\u3082\u3059\u308B\u3002",
  "id" : 65455570374754304,
  "created_at" : "2011-05-03 16:39:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65453723958259713",
  "text" : "140\u30B8\u30E3\u30B9\u30C8\u8FD1\u304F\u3042\u308B\u30C4\u30A4\u30FC\u30C8\u306B\u30B3\u30E1\u30F3\u30C8\u4ED8\u304D\u3067\u975E\u516C\u5F0FRT\u3057\u3088\u3046\u3068\u3059\u308B\u3068\u5207\u306A\u304F\u306A\u308B\u3002\uFF11\uFF10\uFF10\u304F\u3089\u3044\u306B\u3057\u3066\u307B\u3057\u3044\u3002\u3068\u30B3\u30E1\u30F3\u30C8\u3059\u308B\u5074\u306E\u90FD\u5408\u3057\u304B\u8003\u3048\u306A\u3044\u3067\u307C\u3084\u3044\u3066\u307F\u308B\u3002\u3061\u306A\u307F\u306B\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u304C140\u30AE\u30EA\u30AE\u30EA\u306B\u306A\u3063\u3066\u308B\u306E\u306F\u81EA\u5DF1\u8A00\u53CA\u7684\u306A\u4E8B\u6545\u8A00\u53CA\u306A\u306E\u3067\u30B3\u30E1\u30F3\u30C8\u3068\u304B\u7A81\u3063\u8FBC\u307F\u3068\u304B\u3057\u306A\u3044\u3067\u6B32\u3057\u3044\u306A\u3002",
  "id" : 65453723958259713,
  "created_at" : "2011-05-03 16:32:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65452838721036288",
  "text" : "\u77E5\u308A\u5408\u3044\u306A\u3093\u3060\u304B\u305D\u3046\u3067\u306A\u3044\u3093\u3060\u304B\u5206\u304B\u3089\u306A\u3044\u4EBA\u3068\u76F8\u4E92\u30D5\u30A9\u30ED\u30FC\u306B\u306A\u3063\u305F\u307F\u305F\u3044\u3060\u3051\u3069\u2026\u8907\u96D1\u306A\u5FC3\u5883\u3002\u5225\u306B\u69CB\u308F\u306A\u3044\u304B\u3089\u30EA\u30D5\u30A9\u30ED\u30FC\u3057\u305F\u3093\u3051\u3069\u3055\u3002",
  "id" : 65452838721036288,
  "created_at" : "2011-05-03 16:29:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65451883048869889",
  "text" : "\u81EA\u5206\u306E\u5C5E\u3059\u308B\u30AF\u30E9\u30B9\u30BF\u3063\u3066\u8ABF\u3079\u3088\u3046\u304C\u7121\u3044\u3088\u3046\u306A\u6C17\u304C\u3059\u308B\u3002\u5C5E\u3057\u305F\u3044\u3063\u3066\u5E0C\u671B\u306F\u3042\u308B\u3051\u308C\u3069\u3002",
  "id" : 65451883048869889,
  "created_at" : "2011-05-03 16:25:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65450420633481216",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3042\u3089\u73CD\u3057\u3044\u3002\u8F9B\u8FA3\u3060\u3051\u3069\u672C\u97F3\u304C\u6E9C\u307E\u3063\u3066\u308B\u30A4\u30E1\u30FC\u30B8\u3002",
  "id" : 65450420633481216,
  "created_at" : "2011-05-03 16:19:30 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65449734034305026",
  "text" : "\uFF13\u6642\u307E\u3067\u306B\u306F\u5BDD\u308C\u308B\u304B\u306A\u3041\u3002\u305F\u3060\u305F\u3060\u7720\u308C\u306A\u3044\u3002",
  "id" : 65449734034305026,
  "created_at" : "2011-05-03 16:16:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65448207559299072",
  "geo" : { },
  "id_str" : "65448506650923008",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30AB\u30C3\u30BF\u30FC\u30B7\u30E3\u30C4\u306F\u3053\u3063\u3061\u6765\u308B\u307E\u3067\u77E5\u3089\u306A\u304B\u3063\u305F\u3002\u666E\u901A\u306B\u30EF\u30A4\u30B7\u30E3\u30C4\u3063\u3066\u8A00\u3063\u3061\u3083\u3046\u3002",
  "id" : 65448506650923008,
  "in_reply_to_status_id" : 65448207559299072,
  "created_at" : "2011-05-03 16:11:54 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65448053376696320",
  "geo" : { },
  "id_str" : "65448266514432001",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30CE\u30FC\u30C8\u306A\u3089\u6A5F\u7A2E\u306B\u4F9D\u3063\u3066\u306F\u5185\u81D3\u3057\u3066\u308B\u3002\u7121\u304F\u3066\u3082\u30C1\u30E3\u30C3\u30C8\u306F\u51FA\u6765\u308B\u304C\u2026\u3002",
  "id" : 65448266514432001,
  "in_reply_to_status_id" : 65448053376696320,
  "created_at" : "2011-05-03 16:10:57 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65446837758328832",
  "geo" : { },
  "id_str" : "65447295264620544",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u3001\u81EA\u5DF1\u5ACC\u60AA\u3088\uFF1F\u4ED6\u610F\u306F\u306A\u3044\u306E\u3055\u3002",
  "id" : 65447295264620544,
  "in_reply_to_status_id" : 65446837758328832,
  "created_at" : "2011-05-03 16:07:05 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65446743583633408",
  "text" : "\u6687\u306A\u5272\u306B\u53CD\u5FDC\u8CB0\u3048\u306A\u3044\u304B\u3089\u3063\u3066bot\u306A\u3093\u304B\u306B\u53CD\u5FDC\u3092\u6C42\u3081\u3066\u3057\u307E\u3046\u6839\u6027\u306B\u5ACC\u6C17\u304C\u5DEE\u3059\u3002\u305D\u3082\u305D\u3082\u30C1\u30E9\u88CF\u3060\u3063\u3066\u5206\u304B\u3063\u3066\u308B\u306E\u306B\u3002",
  "id" : 65446743583633408,
  "created_at" : "2011-05-03 16:04:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9060\u5C71\u54B2",
      "screen_name" : "g4saku_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "215845940",
      "id" : 215845940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65445618428022785",
  "geo" : { },
  "id_str" : "65446198856781825",
  "in_reply_to_user_id" : 215845940,
  "text" : "@g4saku_bot \u30CE\u30FC\u30C8\u30F3\u5165\u308C\u3066\u306A\u3044\u304B\u3089\u306A\u30FC",
  "id" : 65446198856781825,
  "in_reply_to_status_id" : 65445618428022785,
  "created_at" : "2011-05-03 16:02:44 +0000",
  "in_reply_to_screen_name" : "g4saku_bot",
  "in_reply_to_user_id_str" : "215845940",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C0\u30FB\u30F4\u30A3\u30F3\u30C1\u30FB\u6050\u5C71",
      "screen_name" : "d_v_osorezan",
      "indices" : [ 9, 22 ],
      "id_str" : "96289411",
      "id" : 96289411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65445778604306432",
  "text" : "RT\u3057\u3066\u307F\u305F RT@d_v_osorezan:\u30CB\u30B3\u30CB\u30B3\u5468\u8FBA\u3067\u4F7F\u308F\u308C\u308B\u300C\u301C\u3057\u3066\u307F\u305F\u300D\u3068\u3044\u3046\u8A00\u3044\u65B9\u304B\u3089\u300C\u3042\u304F\u307E\u3067TRY\u3067\u3042\u3063\u3066\u3001\u51FA\u6765\u304C\u60AA\u304F\u3066\u3082\u4F5C\u54C1\u3068\u3057\u3066\u4F4E\u30EC\u30D9\u30EB\u3067\u3082\u300E\u3057\u3066\u307F\u305F\u300F\u7A0B\u5EA6\u306E\u3082\u306E\u3060\u304B\u3089\u3001\u898B\u5F53\u9055\u3044\u306A\u3054\u6279\u5224\u306F\u3054\u9060\u616E\u4E0B\u3055\u3044\u3001\u8912\u3081\u308B\u306A\u3089\u3044\u304F\u3089\u3067\u3082\u805E\u304F\u3051\u3069\u300D\u7684\u5FC3\u7406\u304C\u50CD\u3044\u3066\u308B\u306E\u3092\u611F\u3058\u308B\u3002",
  "id" : 65445778604306432,
  "created_at" : "2011-05-03 16:01:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http:\/\/t.co\/VAqWt6X",
      "expanded_url" : "http:\/\/shindanmaker.com\/106395",
      "display_url" : "shindanmaker.com\/106395"
    } ]
  },
  "geo" : { },
  "id_str" : "65444819664777216",
  "text" : "\u305D\u3093\u306A\u306B\u7D4C\u6E08\u529B\u3042\u308B\u306A\u3089\u4E3B\u592B\u3084\u308A\u305F\u3044\u3093\u3067\u3059\u3051\u3069\u30FC\uFF1F \u3010end\u304C\u604B\u4EBA\u306B\u6C42\u3081\u308B\u6761\u4EF6\u30111\u4F4D\u300C\u5BB6\u5EAD\u7684\u300D 2\u4F4D\u300C\u5BC2\u3057\u305D\u3046\u306A\u6A2A\u9854\u300D 3\u4F4D\u300C\u8272\u6C17\u304C\u3042\u308B\u300D 4\u4F4D\u300C\u7D4C\u6E08\u529B\u300D 5\u4F4D\u300C\u597D\u304D\u306B\u306A\u308C\u3070\u8AB0\u3067\u3082\u300D http:\/\/t.co\/VAqWt6X",
  "id" : 65444819664777216,
  "created_at" : "2011-05-03 15:57:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65443601538228224",
  "text" : "\u6587\u5B66\u7684\u306A\u96F0\u56F2\u6C17\u306A\u3093\u304B\u3088\u308A\u6570\u5B66\u7684\u306A\u96F0\u56F2\u6C17\u304C\u6B32\u3057\u3044\u3057\u3001\u6587\u5B66\u7684\u306A\u80FD\u529B\u3088\u308A\u6570\u5B66\u7684\u80FD\u529B\u304C\u6B32\u3057\u3044\u3002",
  "id" : 65443601538228224,
  "created_at" : "2011-05-03 15:52:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9060\u5C71\u54B2",
      "screen_name" : "g4saku_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "215845940",
      "id" : 215845940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65443107939942400",
  "geo" : { },
  "id_str" : "65443333765468160",
  "in_reply_to_user_id" : 215845940,
  "text" : "@g4saku_bot \u601D\u3063\u305F\u3053\u3068\u3092\u8A00\u3063\u305F\u3060\u3051\u306A\u3093\u3060\u3051\u3069\u306D\u3002",
  "id" : 65443333765468160,
  "in_reply_to_status_id" : 65443107939942400,
  "created_at" : "2011-05-03 15:51:21 +0000",
  "in_reply_to_screen_name" : "g4saku_bot",
  "in_reply_to_user_id_str" : "215845940",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65442961432915968",
  "text" : "\u7720\u308C\u306C\u2026",
  "id" : 65442961432915968,
  "created_at" : "2011-05-03 15:49:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65442553956278272",
  "text" : "\u305D\u3046\u3044\u3084\u3001\u6570\u5B66\u306E\u554F\u984C\u306E\u3063\u3066\u8457\u4F5C\u6A29\u3069\u3046\u306A\u3063\u3066\u308B\u3093\u3060\u308D\u3046\u304B\u3002\u30AB\u30F3\u30CB\u30F3\u30B0\u306E\u6D41\u51FA\u3067\u3061\u3087\u3063\u3068\u6C17\u306B\u306A\u3063\u305F\u306E\u3092\u4ECA\u601D\u3044\u51FA\u3057\u305F\u3002",
  "id" : 65442553956278272,
  "created_at" : "2011-05-03 15:48:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9060\u5C71\u54B2",
      "screen_name" : "g4saku_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "215845940",
      "id" : 215845940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65441588914036736",
  "geo" : { },
  "id_str" : "65441888202801152",
  "in_reply_to_user_id" : 215845940,
  "text" : "@g4saku_bot \u304A\u56E3\u5B50\u4F3C\u5408\u3046\u3088\u306D",
  "id" : 65441888202801152,
  "in_reply_to_status_id" : 65441588914036736,
  "created_at" : "2011-05-03 15:45:36 +0000",
  "in_reply_to_screen_name" : "g4saku_bot",
  "in_reply_to_user_id_str" : "215845940",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u540D\u8A00\u96C6",
      "screen_name" : "Einstein_ja",
      "indices" : [ 3, 15 ],
      "id_str" : "76905775",
      "id" : 76905775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65440050212646912",
  "text" : "RT @Einstein_ja: \u73FE\u5B9F\u306F\u5E7B\u60F3\u306B\u904E\u304E\u306A\u3044\u3002\u975E\u5E38\u306B\u3057\u3064\u3053\u3044\u3082\u306E\u3067\u306F\u3042\u308B\u304C\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/Einstein_ja\" rel=\"nofollow\"\u003E\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65439570463952897",
    "text" : "\u73FE\u5B9F\u306F\u5E7B\u60F3\u306B\u904E\u304E\u306A\u3044\u3002\u975E\u5E38\u306B\u3057\u3064\u3053\u3044\u3082\u306E\u3067\u306F\u3042\u308B\u304C\u3002",
    "id" : 65439570463952897,
    "created_at" : "2011-05-03 15:36:24 +0000",
    "user" : {
      "name" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u540D\u8A00\u96C6",
      "screen_name" : "Einstein_ja",
      "protected" : false,
      "id_str" : "76905775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433263313\/einstein_normal.jpg",
      "id" : 76905775,
      "verified" : false
    }
  },
  "id" : 65440050212646912,
  "created_at" : "2011-05-03 15:38:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65437700995547136",
  "text" : "\u53CB\u4EBA\u6765\u3066\u308B\u304B\u3089\u663C\u306FTL\u8FFD\u3048\u306A\u3044\u3002\u5225\u306B\u826F\u3044\u3051\u3069\u306D\u30FC\u3002\u591C\u306F\u30C1\u30E9\u30C1\u30E9\u307F\u3066\u308B\u3002",
  "id" : 65437700995547136,
  "created_at" : "2011-05-03 15:28:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65436561872916480",
  "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u30B3\u30DF\u30C3\u30AF\u8AAD\u3093\u3060\u3002\u30E6\u30FC\u30EA\u306F\u30B2\u30FC\u30C7\u30EB\u306E\u304C\u30A4\u30E1\u30FC\u30B8\u901A\u308A\u304B\u306A\u30FC\u3002",
  "id" : 65436561872916480,
  "created_at" : "2011-05-03 15:24:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65434842065678336",
  "text" : "\u3080\u3057\u308D\u7247\u624B\u3067\u6570\u3048\u3089\u308C\u308B\u3001\u3067\u5373\u5EA7\u306B\u4E8C\u9032\u6570\u8868\u73FE\u306B\u601D\u3044\u5F53\u305F\u308B\u5B50\u304C\u3044\u305F\u3089\u3068\u304D\u3081\u304F\u30EC\u30D9\u30EB",
  "id" : 65434842065678336,
  "created_at" : "2011-05-03 15:17:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EB\u30CD",
      "screen_name" : "rene_0123",
      "indices" : [ 3, 13 ],
      "id_str" : "197867559",
      "id" : 197867559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65434554940395521",
  "text" : "RT @rene_0123: \u3010\u7406\u7CFB\u7537\u5B50\u306E\u611B\u60C5\u8868\u73FE\u3011\u300C\uFF27\uFF37\u306F\u4F1A\u3048\u308B\uFF1F\u300D\u300C\u3054\u3081\u3093\u5FD9\u3057\u3044\u300D\u300C\u4F1A\u3044\u305F\u3044\u300D\u300C\u4FFA\u3060\u3063\u3066\u4F1A\u3044\u305F\u3044\u3088\u3001\u6708\u306B\u3061\u3087\u3046\u3069\u7247\u624B\u3067\u6570\u3048\u304D\u308C\u308B\u304F\u3089\u3044\u306F\u300D\u300C\u6708\uFF15\u56DE\u2026\u8981\u306F\u9031\u4E00\u56DE\u3067\u3044\u3044\u3093\u3067\u3057\u3087\u300D\u300C\u3053\u306E\u6587\u7CFB\u5973\u5B50\u304C\uFF01\u300D\u300C\u306A\u306B\u3088\u300D\u300C\u4E8C\u9032\u6CD5\u3060\u3068\u7247\u624B\u3067\u6570\u3048\u304D\u308C\u308B\u6700\u5927\u5024\u306F\uFF12\u306E\uFF15\u4E57\uFF0D\uFF11 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65409135176450049",
    "text" : "\u3010\u7406\u7CFB\u7537\u5B50\u306E\u611B\u60C5\u8868\u73FE\u3011\u300C\uFF27\uFF37\u306F\u4F1A\u3048\u308B\uFF1F\u300D\u300C\u3054\u3081\u3093\u5FD9\u3057\u3044\u300D\u300C\u4F1A\u3044\u305F\u3044\u300D\u300C\u4FFA\u3060\u3063\u3066\u4F1A\u3044\u305F\u3044\u3088\u3001\u6708\u306B\u3061\u3087\u3046\u3069\u7247\u624B\u3067\u6570\u3048\u304D\u308C\u308B\u304F\u3089\u3044\u306F\u300D\u300C\u6708\uFF15\u56DE\u2026\u8981\u306F\u9031\u4E00\u56DE\u3067\u3044\u3044\u3093\u3067\u3057\u3087\u300D\u300C\u3053\u306E\u6587\u7CFB\u5973\u5B50\u304C\uFF01\u300D\u300C\u306A\u306B\u3088\u300D\u300C\u4E8C\u9032\u6CD5\u3060\u3068\u7247\u624B\u3067\u6570\u3048\u304D\u308C\u308B\u6700\u5927\u5024\u306F\uFF12\u306E\uFF15\u4E57\uFF0D\uFF11\uFF1D\uFF13\uFF11\u300D\u300C\u3064\u307E\u308A\uFF1F\u300D\u300C\u6BCE\u65E5\u3060\u3088\/\/\/\u300D",
    "id" : 65409135176450049,
    "created_at" : "2011-05-03 13:35:27 +0000",
    "user" : {
      "name" : "\u30EB\u30CD",
      "screen_name" : "rene_0123",
      "protected" : false,
      "id_str" : "197867559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135998215\/t_logo-a_normal.png",
      "id" : 197867559,
      "verified" : false
    }
  },
  "id" : 65434554940395521,
  "created_at" : "2011-05-03 15:16:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "indices" : [ 3, 14 ],
      "id_str" : "99736344",
      "id" : 99736344
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kaibun",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65430813013057536",
  "text" : "RT @Kaibun_bot: \u7AF9\u99AC\u306E\u53CB\u3068\u306E\u30D0\u30AF\u30C1\u3000\uFF08\u3061\u304F\u3070\u306E\u3068\u3082\u3068\u306E\u3070\u304F\u3061\uFF09 #kaibun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kaibun",
        "indices" : [ 24, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65419424483639296",
    "text" : "\u7AF9\u99AC\u306E\u53CB\u3068\u306E\u30D0\u30AF\u30C1\u3000\uFF08\u3061\u304F\u3070\u306E\u3068\u3082\u3068\u306E\u3070\u304F\u3061\uFF09 #kaibun",
    "id" : 65419424483639296,
    "created_at" : "2011-05-03 14:16:20 +0000",
    "user" : {
      "name" : "\u56DE\u6587bot",
      "screen_name" : "Kaibun_bot",
      "protected" : false,
      "id_str" : "99736344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595160109\/09020801_p_normal.jpg",
      "id" : 99736344,
      "verified" : false
    }
  },
  "id" : 65430813013057536,
  "created_at" : "2011-05-03 15:01:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65386990811611136",
  "text" : "\u30DC\u30E0\u3078\u3044!",
  "id" : 65386990811611136,
  "created_at" : "2011-05-03 12:07:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/Cb2xysn",
      "expanded_url" : "http:\/\/shindanmaker.com\/115415",
      "display_url" : "shindanmaker.com\/115415"
    } ]
  },
  "geo" : { },
  "id_str" : "65386680433115136",
  "text" : "\u306A\u307F\u3078\u3044! end313124\u306F\u8A9E\u5C3E\u306B\u300C\u3078\u3044\uFF01\u300D\u3092\u3064\u3051\u308C\u3070\u5973\u5B50\u529B\u500D\u5897\u3002 http:\/\/t.co\/Cb2xysn",
  "id" : 65386680433115136,
  "created_at" : "2011-05-03 12:06:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65386413646036992",
  "text" : "\u30D5\u30A1\u30B8\u30FC\u30CD\u30FC\u30D6\u30EB\u3068\u30AB\u30B7\u30B9\u30AA\u30EC\u30F3\u30B8\u306E\u5883\u754C\u306A\u3046\u3002\u540D\u524D\u3042\u308B\u306E\u304B\u3057\u3089\u3002 http:\/\/twitpic.com\/4ss08p",
  "id" : 65386413646036992,
  "created_at" : "2011-05-03 12:05:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65378879006711808",
  "geo" : { },
  "id_str" : "65379461025112064",
  "in_reply_to_user_id" : 230889478,
  "text" : "@kouennnoyuugu  TL\u3061\u3083\u3093\u3068\u8FFD\u3048\u3066\u306A\u3044\u306E\u3067\u3059\u304C\u962A\u5927\u3067\u3059\u304B\uFF1F",
  "id" : 65379461025112064,
  "in_reply_to_status_id" : 65378879006711808,
  "created_at" : "2011-05-03 11:37:32 +0000",
  "in_reply_to_screen_name" : "phy_neko",
  "in_reply_to_user_id_str" : "230889478",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65375285478039552",
  "geo" : { },
  "id_str" : "65377832506896384",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u30B3\u30B3\u30ED\u3061\u3083\u3093\u306F\u8868\u9ED2\u3044\u3082\u3093\u306D",
  "id" : 65377832506896384,
  "in_reply_to_status_id" : 65375285478039552,
  "created_at" : "2011-05-03 11:31:04 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65275718866714624",
  "geo" : { },
  "id_str" : "65276038502031361",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u643A\u5E2F\u306E\u982D\u304C\u60AA\u3044\u306E\u3067\u3059\u2026",
  "id" : 65276038502031361,
  "in_reply_to_status_id" : 65275718866714624,
  "created_at" : "2011-05-03 04:46:35 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65275243761115136",
  "geo" : { },
  "id_str" : "65275706434785280",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u6B69\u304D\u75B2\u308C\u305F\u3002\u6696\u304B\u304F\u3066\u6C17\u6301\u3061\u826F\u304B\u3063\u305F\u3002\u9E7F\u304C\u8CE2\u304B\u3063\u305F\u3002",
  "id" : 65275706434785280,
  "in_reply_to_status_id" : 65275243761115136,
  "created_at" : "2011-05-03 04:45:15 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65274841065992192",
  "text" : "\u3053\u3093\u307A\u3044\u3068\u3046\u304C\u5909\u63DB\u3067\u51FA\u306A\u3044\u3002\u3053\u3093\u307A\u3044\u3068\u3046\u5C4B\u3055\u3093\u6DF7\u3093\u3067\u305F\u3002",
  "id" : 65274841065992192,
  "created_at" : "2011-05-03 04:41:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65273487253708800",
  "text" : "RT @hyuki: \u300C\u30AF\u30AF\u30AF\u2026\u56DB\u5929\u738B\u304C\u3084\u3089\u308C\u305F\u3088\u3046\u3060\u306A\u2026\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "65264669186736129",
    "text" : "\u300C\u30AF\u30AF\u30AF\u2026\u56DB\u5929\u738B\u304C\u3084\u3089\u308C\u305F\u3088\u3046\u3060\u306A\u2026\u300D",
    "id" : 65264669186736129,
    "created_at" : "2011-05-03 04:01:24 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 65273487253708800,
  "created_at" : "2011-05-03 04:36:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64866945870204928",
  "geo" : { },
  "id_str" : "64872733615460352",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u5948\u826F\u3067\u6709\u540D\u306A\u98DF\u3079\u7269\uFF08\u5948\u826F\u6F2C\u3051\u9664\u304F)\u306A\u3093\u304B\u3042\u308B\u304B\u306A\u30FC\uFF1F",
  "id" : 64872733615460352,
  "in_reply_to_status_id" : 64866945870204928,
  "created_at" : "2011-05-02 02:03:59 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 14, 25 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 32, 42 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64868738582855680",
  "text" : "\u5948\u826F\u516C\u5712\u304B\u306A\u3001\u591A\u5206\u3002 RT @magokoro84: \u304A\uFF1FRT @end313124: \u5948\u826F\u306B\u3044\u304F\u6D41\u308C\u3002\u52D5\u304F\u3002",
  "id" : 64868738582855680,
  "created_at" : "2011-05-02 01:48:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64866781528981504",
  "text" : "\u5948\u826F\u306B\u3044\u304F\u6D41\u308C\u3002\u52D5\u304F\u3002",
  "id" : 64866781528981504,
  "created_at" : "2011-05-02 01:40:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64585841850318848",
  "text" : "\u30BF\u30B3\u713C\u304D\u306B\u98DF\u3079\u306B\u5927\u962A\u306B\u884C\u304F\u6D41\u308C\u3002\u52D5\u304F\u52D5\u304F\u3002",
  "id" : 64585841850318848,
  "created_at" : "2011-05-01 07:03:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64578473154449408",
  "text" : "\u7F8E\u3057\u3044 http:\/\/twitpic.com\/4rszh1",
  "id" : 64578473154449408,
  "created_at" : "2011-05-01 06:34:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64566374017662977",
  "text" : "\uFF11\uFF12\u5E74\u3001\u30ED\u30C3\u30AF http:\/\/twitpic.com\/4rseix",
  "id" : 64566374017662977,
  "created_at" : "2011-05-01 05:46:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64565952515293184",
  "text" : "\u84B8\u6E9C\u6240\u3067\u30A6\u30A3\u30B9\u30AD\u30FC\u8A66\u98F2\u306A\u3046\u30FC\u3002\u663C\u304B\u3089\u9152\u2606",
  "id" : 64565952515293184,
  "created_at" : "2011-05-01 05:44:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]