Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130957925190598656",
  "text" : "@i_horse \u30AA\u30B9\u30B9\u30E1\u3067\u3059\uFF01\u3044\u308D\u3044\u308D\u30C8\u30C3\u30D4\u30F3\u30B0\u51FA\u6765\u307E\u3059",
  "id" : 130957925190598656,
  "created_at" : "2011-10-31 10:42:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130941783701069825",
  "text" : "@i_horse \u5730\u5143\u3067\u3059\u304C\u30AB\u30FC\u30CB\u30D0\u30EB\u306E\u3042\u308C\u3067\u3059\u304B\uFF1F",
  "id" : 130941783701069825,
  "created_at" : "2011-10-31 09:38:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130881339519025152",
  "text" : "\u677F\u66F8\u30DE\u30B7\u30FC\u30F3\u8D77\u52D5\u3057\u306A\u3044\u3068\u3044\u3044\u306A\u30FC(\u3057\u308D\u3081",
  "id" : 130881339519025152,
  "created_at" : "2011-10-31 05:38:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130879472932110336",
  "geo" : { },
  "id_str" : "130879883135029248",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4ECA\u65E5\u306F\uFF15\u9650\u3067\u308B\u3093\u3067\u3059\uFF1F",
  "id" : 130879883135029248,
  "in_reply_to_status_id" : 130879472932110336,
  "created_at" : "2011-10-31 05:32:50 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130879806609952768",
  "text" : "\u5B89\u5B9A\u306E\u4EAC\u6025\uFF57\uFF57\uFF57",
  "id" : 130879806609952768,
  "created_at" : "2011-10-31 05:32:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "indices" : [ 3, 10 ],
      "id_str" : "15570902",
      "id" : 15570902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130879711558643712",
  "text" : "RT @m_soba: \u30E1\u30A4\u30C9\u55AB\u8336\u300C\u304A\u5E30\u308A\u306A\u3055\u3044\u307E\u305B\u3054\u4E3B\u4EBA\u69D8\u2661\u300D\u3000\n\u57F7\u4E8B\u55AB\u8336\u300C\u304A\u5B22\u69D8\u3001\u304A\u5E30\u308A\u306A\u3055\u3044\u307E\u305B\u300D\u3000\n\u30E4\u30AF\u30B6\u55AB\u8336\u300C\u53D4\u7236\u8CB4\u3001\u304A\u52E4\u3081\u3054\u82E6\u52B4\u69D8\u3067\u3059\uFF01\u300D\u3000\n\u304A\u304B\u3093\u55AB\u8336\u300C\u30A2\u30F3\u30BF\u307E\u305F\u4E00\u4EBA\u3067\u5E30\u3063\u3066\u304D\u3066\u3001\u65E9\u304F\u5F7C\u5973\u304F\u3089\u3044\u4F5C\u308A\u306A\u3088\uFF01\u300D\u3000\n\u4EAC\u6025\u55AB\u8336\u300C\uFF75\uFF77\uFF6C\uFF78\uFF7B\uFF67!! \uFF75\uFF76\uFF74\uFF98\uFF72\uFF6A\uFF6F\uFF7D!! ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"erased_102559\" rel=\"nofollow\"\u003Eerased_102559\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130663531417833472",
    "text" : "\u30E1\u30A4\u30C9\u55AB\u8336\u300C\u304A\u5E30\u308A\u306A\u3055\u3044\u307E\u305B\u3054\u4E3B\u4EBA\u69D8\u2661\u300D\u3000\n\u57F7\u4E8B\u55AB\u8336\u300C\u304A\u5B22\u69D8\u3001\u304A\u5E30\u308A\u306A\u3055\u3044\u307E\u305B\u300D\u3000\n\u30E4\u30AF\u30B6\u55AB\u8336\u300C\u53D4\u7236\u8CB4\u3001\u304A\u52E4\u3081\u3054\u82E6\u52B4\u69D8\u3067\u3059\uFF01\u300D\u3000\n\u304A\u304B\u3093\u55AB\u8336\u300C\u30A2\u30F3\u30BF\u307E\u305F\u4E00\u4EBA\u3067\u5E30\u3063\u3066\u304D\u3066\u3001\u65E9\u304F\u5F7C\u5973\u304F\u3089\u3044\u4F5C\u308A\u306A\u3088\uFF01\u300D\u3000\n\u4EAC\u6025\u55AB\u8336\u300C\uFF75\uFF77\uFF6C\uFF78\uFF7B\uFF67!! \uFF75\uFF76\uFF74\uFF98\uFF72\uFF6A\uFF6F\uFF7D!! \uFF75\uFF76\uFF74\uFF98\uFF72\uFF6A\uFF6F\uFF7D!!\u300D",
    "id" : 130663531417833472,
    "created_at" : "2011-10-30 15:13:08 +0000",
    "user" : {
      "name" : "\u854E\u9EA6",
      "screen_name" : "m_soba",
      "protected" : false,
      "id_str" : "15570902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484672991460982784\/o-QnjXOh_normal.png",
      "id" : 15570902,
      "verified" : false
    }
  },
  "id" : 130879711558643712,
  "created_at" : "2011-10-31 05:32:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "indices" : [ 3, 15 ],
      "id_str" : "94825321",
      "id" : 94825321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130878315652317184",
  "text" : "RT @milkyholmes: \u52C7\u6C17\u3042\u308B\u30BF\u30A4\u30C8\u30FC\u306E\u307F\u306A\u3055\u3093\u3067\u3059\u306D\u3000\u4FFA\u306F\u6B62\u3081\u305F\u3093\u3060\u2026\u2026\u3000RT \u30C8\u30A5\u30A8\u30F3\u30C6\u30A3\u3055\u3093\u306E\u62B1\u304D\u6795\u304C\u5B09\u3057\u3059\u304E\u3066\u6CE3\u304D\u305D\u3046\u3067\u3059\uFF01\uFF01\uFF01\u3069\u3053\u306B\u304A\u793C\u3092\u8A00\u3048\u3070\u826F\u3044\u306E\u304B\u308F\u304B\u3089\u306A\u3044\u306E\u3067\u3059\u304C\u672C\u5F53\u306B\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\uFF01\u30C8\u30A5\u30A8\u30F3\u30C6\u30A3\u3055\u3093\u3068\u8A00\u3046\u5B58\u5728\u3092\u4F5C\u3063\u3066\u4E0B\u3055\u3063\u3066\u3042\u308A\u304C\u3068 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130877464904859648",
    "text" : "\u52C7\u6C17\u3042\u308B\u30BF\u30A4\u30C8\u30FC\u306E\u307F\u306A\u3055\u3093\u3067\u3059\u306D\u3000\u4FFA\u306F\u6B62\u3081\u305F\u3093\u3060\u2026\u2026\u3000RT \u30C8\u30A5\u30A8\u30F3\u30C6\u30A3\u3055\u3093\u306E\u62B1\u304D\u6795\u304C\u5B09\u3057\u3059\u304E\u3066\u6CE3\u304D\u305D\u3046\u3067\u3059\uFF01\uFF01\uFF01\u3069\u3053\u306B\u304A\u793C\u3092\u8A00\u3048\u3070\u826F\u3044\u306E\u304B\u308F\u304B\u3089\u306A\u3044\u306E\u3067\u3059\u304C\u672C\u5F53\u306B\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\uFF01\u30C8\u30A5\u30A8\u30F3\u30C6\u30A3\u3055\u3093\u3068\u8A00\u3046\u5B58\u5728\u3092\u4F5C\u3063\u3066\u4E0B\u3055\u3063\u3066\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
    "id" : 130877464904859648,
    "created_at" : "2011-10-31 05:23:13 +0000",
    "user" : {
      "name" : "\u30DF\u30EB\u30AD\u30A3\u30DB\u30FC\u30E0\u30BA",
      "screen_name" : "milkyholmes",
      "protected" : false,
      "id_str" : "94825321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593967810226753537\/kej69_3u_normal.jpg",
      "id" : 94825321,
      "verified" : false
    }
  },
  "id" : 130878315652317184,
  "created_at" : "2011-10-31 05:26:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D3\u30EA\u30E4\u30FC\u30C9BUZZ",
      "screen_name" : "BUZZ_1220",
      "indices" : [ 3, 13 ],
      "id_str" : "391252626",
      "id" : 391252626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130788791815385088",
  "text" : "RT @BUZZ_1220: \u4EAC\u5927\uFF8B\uFF9E\uFF98\uFF94\uFF70\uFF84\uFF9E\uFF7B\uFF70\uFF78\uFF99\uFF62\u9591\u8A71\u7403\u53F0\uFF63\u2606\uFF92\uFF9D\uFF8A\uFF9E\uFF70\u52DF\u96C6\u4E2D\u3067\u3059! \u307F\u3093\u306A\uFF92\uFF77\uFF92\uFF77\u8155\u3092\u4E0A\u3052\u3066\u3066\u3001\u3053\u308C\u304B\u3089\u697D\u3057\u307F\u3067\u3059\u266ABUZZ\u3082\u5168\u9762\u5354\u529B\u3057\u305F\u3044\u3068\u601D\u3044\u307E\u3059!!(^-^)b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126900813829382144",
    "text" : "\u4EAC\u5927\uFF8B\uFF9E\uFF98\uFF94\uFF70\uFF84\uFF9E\uFF7B\uFF70\uFF78\uFF99\uFF62\u9591\u8A71\u7403\u53F0\uFF63\u2606\uFF92\uFF9D\uFF8A\uFF9E\uFF70\u52DF\u96C6\u4E2D\u3067\u3059! \u307F\u3093\u306A\uFF92\uFF77\uFF92\uFF77\u8155\u3092\u4E0A\u3052\u3066\u3066\u3001\u3053\u308C\u304B\u3089\u697D\u3057\u307F\u3067\u3059\u266ABUZZ\u3082\u5168\u9762\u5354\u529B\u3057\u305F\u3044\u3068\u601D\u3044\u307E\u3059!!(^-^)b",
    "id" : 126900813829382144,
    "created_at" : "2011-10-20 06:01:26 +0000",
    "user" : {
      "name" : "\u30D3\u30EA\u30E4\u30FC\u30C9BUZZ",
      "screen_name" : "BUZZ_1220",
      "protected" : false,
      "id_str" : "391252626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1592240727\/249462_109173575841154_1000024553718_normal.jpg",
      "id" : 391252626,
      "verified" : false
    }
  },
  "id" : 130788791815385088,
  "created_at" : "2011-10-30 23:30:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130787515987804160",
  "text" : "\u3055 \u3080 \u3044 \u304B\u3089\u5E03\u56E3\u304B\u3089\u51FA\u305F\u304F\u306A\u3044\u3088\u3046",
  "id" : 130787515987804160,
  "created_at" : "2011-10-30 23:25:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130785650852106241",
  "text" : "\u4F11\u8B1B\u306A\u3057",
  "id" : 130785650852106241,
  "created_at" : "2011-10-30 23:18:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130785148198338560",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 130785148198338560,
  "created_at" : "2011-10-30 23:16:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130671981338169345",
  "text" : "\u30B7\u30E3\u30C3\u30C8\u30C0\u30A6\u30F3\uFF01",
  "id" : 130671981338169345,
  "created_at" : "2011-10-30 15:46:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130670352589271041",
  "text" : "\u6700\u60AA\u706B\u66DC\u306E\u663C\u4F11\u307F\u304B\uFF12\u9650\u306B\u3084\u308C\u3070\u3088\u3044\u306E\u3067\u3059\u3002",
  "id" : 130670352589271041,
  "created_at" : "2011-10-30 15:40:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130670257084960768",
  "text" : "\u306F\u3001\u7D50\u5C40\u30D5\u30E9\u30F3\u30B9\u8A9E\u89E6\u3063\u3066\u306A\u3044\u3002\u3002\u3002\u307E\u305F\u7279\u653B\u304B\u3002\u4E88\u7FD2\u3057\u3066\u3044\u304F\u3068\u65E9\u304F\u7D42\u308F\u308B\u3051\u3069\u7D50\u5C40\u30B3\u30FC\u30EB\u306A\u3089\u3044\u3044\u304B",
  "id" : 130670257084960768,
  "created_at" : "2011-10-30 15:39:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130669860677103616",
  "text" : "\u30B3\u30B9\u30C8\u30FB\u30ED\u30B9\u3060\u3063\u305F\u304B\u306A\u3001\u66D6\u6627\u30FC",
  "id" : 130669860677103616,
  "created_at" : "2011-10-30 15:38:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130669240104648705",
  "geo" : { },
  "id_str" : "130669692263219200",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30ED\u30B9\u30C8\u30FB\u30B3\u30B9\u30C8\u30E2\u30C7\u30EB\u3063\u3066\u7406\u8AD6\u304C\u4E91\u3005\u3067\u5584\u5F8C\u7B56\u3092\u53D6\u308B\u306E\u3067\u3059\u3002",
  "id" : 130669692263219200,
  "in_reply_to_status_id" : 130669240104648705,
  "created_at" : "2011-10-30 15:37:37 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9ED2\u4FE1\u53F7\u30106\/14\u604B\u8349\u5B50:\u304643\u3011",
      "screen_name" : "kuroiro2gou",
      "indices" : [ 3, 15 ],
      "id_str" : "319663337",
      "id" : 319663337
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kuroiro2gou\/status\/130663435108220928\/photo\/1",
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/UbiWM7SN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AdA1s7MCAAEI-hm.jpg",
      "id_str" : "130663435112415233",
      "id" : 130663435112415233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdA1s7MCAAEI-hm.jpg",
      "sizes" : [ {
        "h" : 766,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1308,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1603
      } ],
      "display_url" : "pic.twitter.com\/UbiWM7SN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130669221217705984",
  "text" : "RT @kuroiro2gou: \u3082\u3057\u3053\u308C\u304C\u660E\u65E5\u306E\u671D\u307E\u3067\u306B\uFF11\uFF10\uFF10RT\u3055\u308C\u305F\u3089\u3001\u3053\u306E\u683C\u597D\u3067\u5B66\u6821\u884C\u3063\u3066\u6559\u6388\u306B\u30AF\u30C3\u30AD\u30FC\u6E21\u3057\u3066\u304F\u308B\u3002\u7121\u7406\u3060\u3063\u305F\u3089\u666E\u901A\u306B\u53CB\u9054\u306B\u914D\u308B\u3002 http:\/\/t.co\/UbiWM7SN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kuroiro2gou\/status\/130663435108220928\/photo\/1",
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/UbiWM7SN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AdA1s7MCAAEI-hm.jpg",
        "id_str" : "130663435112415233",
        "id" : 130663435112415233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdA1s7MCAAEI-hm.jpg",
        "sizes" : [ {
          "h" : 766,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1308,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1603
        } ],
        "display_url" : "pic.twitter.com\/UbiWM7SN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130663435108220928",
    "text" : "\u3082\u3057\u3053\u308C\u304C\u660E\u65E5\u306E\u671D\u307E\u3067\u306B\uFF11\uFF10\uFF10RT\u3055\u308C\u305F\u3089\u3001\u3053\u306E\u683C\u597D\u3067\u5B66\u6821\u884C\u3063\u3066\u6559\u6388\u306B\u30AF\u30C3\u30AD\u30FC\u6E21\u3057\u3066\u304F\u308B\u3002\u7121\u7406\u3060\u3063\u305F\u3089\u666E\u901A\u306B\u53CB\u9054\u306B\u914D\u308B\u3002 http:\/\/t.co\/UbiWM7SN",
    "id" : 130663435108220928,
    "created_at" : "2011-10-30 15:12:46 +0000",
    "user" : {
      "name" : "\u9ED2\u4FE1\u53F7\u30106\/14\u604B\u8349\u5B50:\u304643\u3011",
      "screen_name" : "kuroiro2gou",
      "protected" : false,
      "id_str" : "319663337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599632413916925952\/fdndwCdC_normal.jpg",
      "id" : 319663337,
      "verified" : false
    }
  },
  "id" : 130669221217705984,
  "created_at" : "2011-10-30 15:35:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130669185452871680",
  "text" : "\uFF13\uFF10%\u3063\u3066\u5FAE\u5999\u3088\u306A\u30FB\u30FB\u30FB\u3002",
  "id" : 130669185452871680,
  "created_at" : "2011-10-30 15:35:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130669119841374208",
  "text" : "\u3080\u3045\u3001\u5348\u524D\u4E2D\u602A\u3057\u3052\u3060\u3063\u305F\u3089\u624B\u63D0\u3052\u3067\u884C\u304F\u304B\u3002\u9769\u306E\u30EA\u30E5\u30C3\u30AF\u306F\u6FE1\u3089\u3057\u305F\u304F\u306A\u3044\u3002",
  "id" : 130669119841374208,
  "created_at" : "2011-10-30 15:35:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130668795852374016",
  "text" : "\u305D\u306E\u524D\u306B\u4ECA\u65E5\u306E\u6E96\u5099\u3002\u5929\u6C17\u306B\u4F9D\u308B\u3051\u3069\u96E8\u3084\u3080\u306E\u304B\u3057\u3089\u3002",
  "id" : 130668795852374016,
  "created_at" : "2011-10-30 15:34:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130668709600706561",
  "text" : "AIP\u5FA9\u6D3B\u3057\u305F\u3068\u3053\u308D\u3067\u30B7\u30E3\u30C3\u30C8\u30C0\u30A6\u30F3\u3059\u308B\u304B\u3002",
  "id" : 130668709600706561,
  "created_at" : "2011-10-30 15:33:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130668404708347906",
  "text" : "\uFF21\uFF1A\uFF1Dtrick\n\uFF22\uFF1A\uFF1Dtreat\n\u300C\uFF21\u2228\uFF22\u300D",
  "id" : 130668404708347906,
  "created_at" : "2011-10-30 15:32:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u536F\u6708",
      "screen_name" : "puzuki",
      "indices" : [ 3, 10 ],
      "id_str" : "110347280",
      "id" : 110347280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130666987897630721",
  "text" : "RT @puzuki: \u300C\u9CE5\u98DF\u3046\uFF1F or \u9CE5eat\uFF1F\u300D\n\u300C\u305D\u308C\u4E00\u7DD2\u3058\u3083\u306D\uFF1F\u300D\n\u300C\u2026\u3060\u306A\u300D\n\u300C\u4ECA\u5EA6\u3001\u713C\u304D\u9CE5\u884C\u304F\u304B\u300D\n\u300C\u304A\u3046\u2026\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130662709409759233",
    "text" : "\u300C\u9CE5\u98DF\u3046\uFF1F or \u9CE5eat\uFF1F\u300D\n\u300C\u305D\u308C\u4E00\u7DD2\u3058\u3083\u306D\uFF1F\u300D\n\u300C\u2026\u3060\u306A\u300D\n\u300C\u4ECA\u5EA6\u3001\u713C\u304D\u9CE5\u884C\u304F\u304B\u300D\n\u300C\u304A\u3046\u2026\u300D",
    "id" : 130662709409759233,
    "created_at" : "2011-10-30 15:09:52 +0000",
    "user" : {
      "name" : "\u536F\u6708",
      "screen_name" : "puzuki",
      "protected" : false,
      "id_str" : "110347280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3438491901\/84754dcbf994569462482fe68080f886_normal.png",
      "id" : 110347280,
      "verified" : false
    }
  },
  "id" : 130666987897630721,
  "created_at" : "2011-10-30 15:26:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130666638805704704",
  "text" : "\u4E45\u3005\u306BAIP\u7121\u304F\u306A\u3063\u305F",
  "id" : 130666638805704704,
  "created_at" : "2011-10-30 15:25:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130666433121239041",
  "text" : "\u60AA\u622F\u3059\u308B\u3060\u3051\u3057\u3066\u304A\u83D3\u5B50\u3042\u3052\u305F\u3093\u3060\u304B\u3089\u8A31\u305B\u3088\u306A\u3001\u307F\u305F\u3044\u306A\u4E0D\u905C\u306A\u614B\u5EA6\u304C\u53EF\u7B11\u3057\u3044\u3093\u3058\u3083\u306A\u3044\u304B\u306A",
  "id" : 130666433121239041,
  "created_at" : "2011-10-30 15:24:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130666118846218241",
  "text" : "treat after trick\u306E\u65B9\u304C\u3084\u3089\u308C\u305F\u65B9\u304C\u5207\u306A\u304F\u3066\u9762\u767D\u3044",
  "id" : 130666118846218241,
  "created_at" : "2011-10-30 15:23:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130663965758996480",
  "text" : "\u30CF\u30ED\u30A6\u30A3\u30F3\u306D\u3047\uFF08\u3057\u308D\u3081",
  "id" : 130663965758996480,
  "created_at" : "2011-10-30 15:14:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130662797083283456",
  "text" : "\u30CD\u30C3\u30C8\u306E\u533F\u540D\u6027\u306F\u826F\u3044\u65B9\u306B\u3082\u52D5\u304F\u3093\u3060\u306A\u30FC",
  "id" : 130662797083283456,
  "created_at" : "2011-10-30 15:10:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130662684734668800",
  "text" : "\u3068\u3044\u3046\u304B\u3001\u5B66\u5185\u3067\u898B\u3064\u3051\u305F\u30D3\u30E9\u306B\u9023\u7D61\u3057\u3066\u307F\u308B\u52C7\u6C17\u306F\u306A\u3044\u3051\u308C\u3069\u3001\u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u30EA\u30D7\u30E9\u30A4\u306A\u308ADM\u98DB\u3070\u3059\u52C7\u6C17\u306F\u5FAE\u3005\u305F\u308B\u3082\u306E\u306A\u306E\u3067\u3059\u3002",
  "id" : 130662684734668800,
  "created_at" : "2011-10-30 15:09:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130661740978511873",
  "text" : "\u53CB\u4EBA\u306E\u643A\u5E2F\u304C\u9707\u3048\u308B\u3068\u904E\u5270\u306B\u3073\u3063\u304F\u308A\u3059\u308B\u4EBA\u304C\u3044\u305F\u3089\u305D\u308C\u304C\u79C1\u3067\u3059\u3002",
  "id" : 130661740978511873,
  "created_at" : "2011-10-30 15:06:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130661559822323712",
  "text" : "\u30E1\u30FC\u30EB\u306E\u901A\u77E5\u3092\u30D0\u30A4\u30D6\u306B\u3057\u3066\u3044\u305F\u3053\u308D\u306F\u643A\u5E2F\u304C\u9707\u3048\u305F\u932F\u899A\u306B\u8972\u308F\u308C\u3066\u3044\u305F\u3051\u308C\u3069\u3001\u901A\u77E5\u3092\u7121\u3057\u306B\u3057\u305F\u3089\u3001\u4ECA\u5EA6\u306F\u4F55\u3067\u3082\u306A\u3044\u5149\u306E\u53CD\u5C04\u3092\u30E1\u30FC\u30EB\u7740\u3066\u307E\u3059\u3088\u306E\u5149\u3068\u898B\u9593\u9055\u3048\u308B\u3088\u3046\u306B\u306A\u3063\u305F\u3002",
  "id" : 130661559822323712,
  "created_at" : "2011-10-30 15:05:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 0, 10 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130660269562134529",
  "geo" : { },
  "id_str" : "130660648081293312",
  "in_reply_to_user_id" : 126326979,
  "text" : "@Keitaecon \u3061\u3087\u3063\u3068\u9762\u767D\u305D\u3046\u3068\u306F\u601D\u3046\u306E\u3067\u3059\u304C\u4E88\u5099\u77E5\u8B58\u3068\u304B\u3044\u308D\u3044\u308D\u7121\u3044\u306E\u3067\u4E00\u6B69\u3072\u3044\u3066\u3057\u307E\u3044\u307E\u3059\uFF57\n\u3067\u3082\u30C4\u30A4\u30C3\u30BF\u30FC\u3067\u306E\u62E1\u6563\u306F\u7D76\u5BFE\u52B9\u679C\u3042\u308B\u3068\u601D\u3044\u307E\u3059\u3088\u3001\u81EA\u5206\u307F\u305F\u3044\u306E\u304C\u5F15\u3063\u304B\u304B\u308A\u307E\u3059\u3057\u2190",
  "id" : 130660648081293312,
  "in_reply_to_status_id" : 130660269562134529,
  "created_at" : "2011-10-30 15:01:40 +0000",
  "in_reply_to_screen_name" : "Keitaecon",
  "in_reply_to_user_id_str" : "126326979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130660330769620993",
  "text" : "\u300C\u62BD\u8C61\u6982\u5FF5\u3092\u7406\u89E3\u3059\u308B\u306E\u304C\u5F97\u610F\u300D\u3063\u3066\u8912\u3081\u3066\u3082\u3089\u3063\u305F\u3053\u3068\u3082\u3042\u308B\u306E\u3060\u3051\u308C\u3069\u3001\u4ECA\u4E00\u3064\u81EA\u4FE1\u304C\u6301\u3066\u307E\u305B\u3093\u3002",
  "id" : 130660330769620993,
  "created_at" : "2011-10-30 15:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130659381154021376",
  "text" : "\u6388\u696D\u805E\u3044\u3066\u3066\u8A3C\u660E\u306F\u4E00\u884C\u4E00\u884C\u8FFD\u3048\u308B\u3057\u3001\u7406\u89E3\u306F\u3067\u304D\u308B\uFF08\u3064\u3082\u308A\u306B\u306A\u3063\u3066\u308B\u3060\u3051\uFF1F\uFF09\u3093\u3060\u3051\u308C\u3069\u3001\u8A3C\u660E\u5168\u4F53\u304C\u4F55\u3092\u6307\u3057\u3066\u308B\u306E\u304B\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u305B\u3044\u3067\u518D\u73FE\u3067\u304D\u306A\u3044\u3057\u601D\u3044\u3064\u3051\u306A\u3044",
  "id" : 130659381154021376,
  "created_at" : "2011-10-30 14:56:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130659035618885633",
  "text" : "\u306A\u3093\u3068\u3044\u3046\u304B\u5B9F\u611F\u3059\u308B\u30D7\u30ED\u30BB\u30B9\u3068\u8AD6\u7406\u3067\u8A70\u3081\u308B\u30D7\u30ED\u30BB\u30B9\u306F\u81EA\u5206\u306E\u4E2D\u3067\u3061\u3087\u3063\u3068\u30AE\u30E3\u30C3\u30D7\u304C\u3042\u308B\u3093\u3060\u3088\u306A\u30FC",
  "id" : 130659035618885633,
  "created_at" : "2011-10-30 14:55:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130658881817935873",
  "text" : "\u300C\u4F8B\u793A\u306F\u7406\u89E3\u306E\u8A66\u91D1\u77F3\u300D\u3063\u3066\u306E\u3082\u5B9F\u611F\u3068\u304B\u53EF\u8996\u5316\u306E\u70BA\u306A\u306E\u304B",
  "id" : 130658881817935873,
  "created_at" : "2011-10-30 14:54:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130657694569865217",
  "geo" : { },
  "id_str" : "130658371396304898",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u591A\u304F\u306F\u306A\u3044\u3051\u308C\u3069\u306D\uFF57",
  "id" : 130658371396304898,
  "in_reply_to_status_id" : 130657694569865217,
  "created_at" : "2011-10-30 14:52:37 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130658206228824064",
  "text" : "\u5B9F\u611F\u3067\u304D\u306A\u3044\u304B\u3089\u9078\u629E\u516C\u7406\u304C\u89E3\u3089\u306A\u3044\u3002\u516C\u7406\u3060\u304B\u3089\u7406\u89E3\u3059\u308B\u7269\u3058\u3083\u306A\u304F\u3066\u53D7\u3051\u5165\u308C\u308B\u3082\u306E\u306A\u3093\u3060\u3051\u3069\u5B9F\u611F\u3067\u304D\u306A\u3044\u3002\u3044\u3064\u304B\u7D76\u5BFE\u53D7\u3051\u5165\u308C\u3066\u3084\u308B\u3002",
  "id" : 130658206228824064,
  "created_at" : "2011-10-30 14:51:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u306A\u304B\u304C\u3076\u3088\u3076\u3088",
      "screen_name" : "onaka_buyo",
      "indices" : [ 24, 35 ],
      "id_str" : "145221588",
      "id" : 145221588
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 46, 56 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130657942126071808",
  "text" : "\u305D\u308C\u3053\u305D\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u306B\u3057\u304B\u901A\u3058\u307E\u305B\u3093\u3088\u3046 RT @onaka_buyo \u540C\u5024\u985E\u3068\u304B\u3002 RT @end313124: \u30C4\u30A4\u30C3\u30BF\u30FC\u3084\u3063\u3066\u306A\u3044\u4EBA\u306B\u30AF\u30E9\u30B9\u30BF\u306E\u8AAC\u660E\u3059\u308B\u306E\u304C\u96E3\u3057\u3044\u3093\u3067\u3059\u3051\u3069\u4F55\u304B\u3044\u3044\u8AAC\u660E\u7121\u3044\u3093\u3067\u3059\uFF1F",
  "id" : 130657942126071808,
  "created_at" : "2011-10-30 14:50:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130657833363574784",
  "text" : "\u305D\u308C\u3092\u76EE\u3067\u898B\u305F\u308A\u3001\u305D\u308C\u3092\u5B9F\u611F\u3057\u305F\u3053\u3068\u306E\u306A\u3044\u4EBA\u306B\u3001\u201D\u305D\u308C\u201D\u3092\u8AAC\u660E\u3059\u308B\u306E\u306F\u96E3\u3057\u3044\u3002",
  "id" : 130657833363574784,
  "created_at" : "2011-10-30 14:50:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u306D",
      "screen_name" : "spine19642",
      "indices" : [ 0, 11 ],
      "id_str" : "264623696",
      "id" : 264623696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130657195061813249",
  "geo" : { },
  "id_str" : "130657583697625089",
  "in_reply_to_user_id" : 264623696,
  "text" : "@spine19642 \u3067\u3059\u304B\u306D\u3047\u2026\u3002\u81EA\u5206\u306F\u96C6\u56E3\u3063\u3066\u8A00\u3046\u3068\u306A\u3093\u304B\u57FA\u6E96\u306E\u3042\u308B\u96C6\u307E\u308A\u3092\u60F3\u50CF\u3057\u3066\u3057\u307E\u3046\u306E\u3067\u300C\u3086\u308B\u3044\u96C6\u307E\u308A\u307F\u305F\u3044\u306A\u3082\u306E\u300D\u3063\u3066\u8A00\u8449\u3092\u6FC1\u3057\u3061\u3083\u3063\u3066\u307E\u3059\u3002",
  "id" : 130657583697625089,
  "in_reply_to_status_id" : 130657195061813249,
  "created_at" : "2011-10-30 14:49:30 +0000",
  "in_reply_to_screen_name" : "spine19642",
  "in_reply_to_user_id_str" : "264623696",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130656706140176385",
  "text" : "\u30C4\u30A4\u30C3\u30BF\u30FC\u3084\u3063\u3066\u306A\u3044\u4EBA\u306B\u30AF\u30E9\u30B9\u30BF\u306E\u8AAC\u660E\u3059\u308B\u306E\u304C\u96E3\u3057\u3044\u3093\u3067\u3059\u3051\u3069\u4F55\u304B\u3044\u3044\u8AAC\u660E\u7121\u3044\u3093\u3067\u3059\uFF1F",
  "id" : 130656706140176385,
  "created_at" : "2011-10-30 14:46:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130656204144914432",
  "text" : "\u5927\u4F53\u30AF\u30E9\u30B9\u30BF\u306E\u5B9A\u7FA9\u304C\u305D\u3082\u305D\u3082\u3042\u3044\u307E\u3044\u306A\u3093\u3060\u304B\u3089\u6A19\u6E96\u88C5\u5099\u3068\u304B\u305D\u3046\u3044\u3046\u898F\u5B9A\u306F\uFF08\uFF52\uFF59",
  "id" : 130656204144914432,
  "created_at" : "2011-10-30 14:44:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130655998837915648",
  "text" : "\u5C11\u306A\u304F\u3068\u3082\u6570\u5B66\u5F92\u30AF\u30E9\u30B9\u30BF\u3067\u306F\u3042\u308A\u305F\u3044\u3002",
  "id" : 130655998837915648,
  "created_at" : "2011-10-30 14:43:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130655891459543040",
  "text" : "\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u306E\u6A19\u6E96\u88C5\u5099\u3092\u5099\u3048\u3066\u306A\u304F\u3066\u3082\u81EA\u5206\u306F\u3001\u201D\u5C11\u3000\u306A\u3000\u304F\u3000\u3068\u3000\u3082\u3000\u6587\u3000\u5B66\u3000\u30AF\u3000\u30E9\u3000\u30B9\u3000\u30BF\u3000\u3088\u3000\u308A\u3000\u306F\u201D\u6570\u5B66\u30AF\u30E9\u30B9\u30BF\u306B\u8FD1\u3044\u3068\u4FE1\u3058\u3066\u3044\u308B\u3002",
  "id" : 130655891459543040,
  "created_at" : "2011-10-30 14:42:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130655278206169088",
  "geo" : { },
  "id_str" : "130655507324207104",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3053\u306E\u524D\u5C0F\u5DDD\u4EAD\u3067\u3061\u3087\u3063\u3068\u3064\u307E\u307E\u305B\u3066\u3082\u3089\u3063\u305F\u306E\u3068\u5076\u7136\u306B\u3082\u540C\u3058\u6599\u7406\uFF57\uFF57\uFF57\uFF57",
  "id" : 130655507324207104,
  "in_reply_to_status_id" : 130655278206169088,
  "created_at" : "2011-10-30 14:41:15 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130653520524349441",
  "text" : "\u3042\u3001\uFF11-\uFF11\uFF0C\uFF11-\uFF12\uFF0C\uFF11-\uFF13\uFF0C\uFF12-\uFF11\uFF0C\uFF12-\uFF12\uFF0C\uFF12-\uFF13\u3063\u3066\u3042\u3063\u3066\uFF11-\uFF11\u3068\uFF11-\uFF12\u3084\u3063\u305F\u3063\u3066\u610F\u5473\u3060\u3051\u3069\u3002",
  "id" : 130653520524349441,
  "created_at" : "2011-10-30 14:33:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130653249513594880",
  "text" : "call\u7D50\u5C40\u5927\u304D\u306A\u30BB\u30AF\u30B7\u30E7\u30F3\u306F\uFF12\u3064\u3057\u304B\u306A\u3044\u3057\u305D\u308C\u305E\u308C\uFF13\u3064\u306B\u5206\u304B\u308C\u3066\u308B\u304B\u3089\u3068\u308A\u3042\u3048\u305A\u4E0A\u304B\u3089\uFF12\u3064\u3084\u3063\u305F\u3051\u3069\u3053\u308C\u3067\u3044\u3044\u306E\u304B\u306D",
  "id" : 130653249513594880,
  "created_at" : "2011-10-30 14:32:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130634887190413314",
  "text" : "\u30B3\u30FC\u30EB\u306E\u52C9\u5F37\u3057\u3088\u3046\u3068\u3057\u3089\u4EEE\u60F3\u30E1\u30E2\u30EA\u8DB3\u308A\u306A\u3044\u3063\u3066\u8A00\u308F\u308C\u3066\u7126\u3063\u305F",
  "id" : 130634887190413314,
  "created_at" : "2011-10-30 13:19:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 0, 7 ],
      "id_str" : "50640629",
      "id" : 50640629
    }, {
      "name" : "\u707C\u773C\u306E\u3042\u304B\u2606\u306D\u3053",
      "screen_name" : "math_neko",
      "indices" : [ 8, 18 ],
      "id_str" : "232545906",
      "id" : 232545906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130632161438081024",
  "geo" : { },
  "id_str" : "130632499238928384",
  "in_reply_to_user_id" : 50640629,
  "text" : "@igaris @math_neko \u3042\u3001\u624B\u3092\u52D5\u304B\u3057\u3066\u3044\u306A\u3044\u306E\u304C\u3070\u308C\u3066\u3057\u307E\u3063\u305F",
  "id" : 130632499238928384,
  "in_reply_to_status_id" : 130632161438081024,
  "created_at" : "2011-10-30 13:09:49 +0000",
  "in_reply_to_screen_name" : "igaris",
  "in_reply_to_user_id_str" : "50640629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 0, 7 ],
      "id_str" : "50640629",
      "id" : 50640629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130630382533087233",
  "geo" : { },
  "id_str" : "130630883672723456",
  "in_reply_to_user_id" : 50640629,
  "text" : "@igaris e\u306E\u5B9A\u7FA9\u304B\u3089\u7C21\u5358\u306B\u5C0E\u3051\u307E\u3059\u306D\u30FC\uFF08\u2190\u77E5\u3089\u306A\u304B\u3063\u305F\u306A\u3093\u3066\u8A00\u3048\u306A\u3044\uFF09",
  "id" : 130630883672723456,
  "in_reply_to_status_id" : 130630382533087233,
  "created_at" : "2011-10-30 13:03:24 +0000",
  "in_reply_to_screen_name" : "igaris",
  "in_reply_to_user_id_str" : "50640629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130630084376797184",
  "geo" : { },
  "id_str" : "130630319891156992",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u306B\u305B\u307B\u30FC",
  "id" : 130630319891156992,
  "in_reply_to_status_id" : 130630084376797184,
  "created_at" : "2011-10-30 13:01:09 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130629099239649280",
  "text" : "\uFF11%\u306E\u78BA\u7387\u3067\u9593\u9055\u3048\u308B\u7CBE\u5EA6\u3067\uFF11\uFF10\uFF10\u554F\u89E3\u304F\u3068\uFF16\uFF10%\u304F\u3089\u3044\u306E\u78BA\u7387\u3067\u5C11\u306A\u304F\u3068\u3082\u4E00\u5EA6\u9593\u9055\u3048\u308B\u3002",
  "id" : 130629099239649280,
  "created_at" : "2011-10-30 12:56:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130628878606680066",
  "text" : "\u5358\u306A\u308B\u8A08\u7B97\u30DF\u30B9\u306F\u6570\u306E\u66B4\u529B\u3002",
  "id" : 130628878606680066,
  "created_at" : "2011-10-30 12:55:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u304A\u306A\u3057",
      "screen_name" : "kao__nashi",
      "indices" : [ 3, 14 ],
      "id_str" : "42397277",
      "id" : 42397277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130623363860283392",
  "text" : "RT @kao__nashi: \u300C\u8CB4\u65B9\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u3053\u306E\u91D1\u306E\u65A7\u3067\u3059\u304B\u300D\u300C\u306F\u3044\u3001\u305D\u306E\u65A7\u3067\u3059\u300D\u300C\u5618\u3064\u304D\u306B\u6E21\u3059\u65A7\u306F\u3042\u308A\u307E\u305B\u3093\uFF01\u300D\u3000\uFF5E\u4E00\u30F5\u6708\u5F8C\uFF5E\u3000\u5973\u5B50\u30A2\u30CA\u300C\u5148\u6708\u306B\u8D77\u304D\u305F\u5927\u91CF\u6BBA\u4EBA\u306E\u5BB9\u7591\u8005\u304C\u902E\u6355\u3055\u308C\u307E\u3057\u305F\u3002\u902E\u6355\u306E\u6C7A\u3081\u624B\u3068\u306A\u3063\u305F\u51F6\u5668\u306E\u65A7\u3092\u6240\u6709\u3057\u3066\u3044\u305F\u5BB9\u7591\u8005\u306F\u300E\u3053\u308C\u306F\u62FE\u3044\u7269\u3060\u3002\u72AF\u4EBA\u306F\u5618\u3064 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130594054126845953",
    "text" : "\u300C\u8CB4\u65B9\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u3053\u306E\u91D1\u306E\u65A7\u3067\u3059\u304B\u300D\u300C\u306F\u3044\u3001\u305D\u306E\u65A7\u3067\u3059\u300D\u300C\u5618\u3064\u304D\u306B\u6E21\u3059\u65A7\u306F\u3042\u308A\u307E\u305B\u3093\uFF01\u300D\u3000\uFF5E\u4E00\u30F5\u6708\u5F8C\uFF5E\u3000\u5973\u5B50\u30A2\u30CA\u300C\u5148\u6708\u306B\u8D77\u304D\u305F\u5927\u91CF\u6BBA\u4EBA\u306E\u5BB9\u7591\u8005\u304C\u902E\u6355\u3055\u308C\u307E\u3057\u305F\u3002\u902E\u6355\u306E\u6C7A\u3081\u624B\u3068\u306A\u3063\u305F\u51F6\u5668\u306E\u65A7\u3092\u6240\u6709\u3057\u3066\u3044\u305F\u5BB9\u7591\u8005\u306F\u300E\u3053\u308C\u306F\u62FE\u3044\u7269\u3060\u3002\u72AF\u4EBA\u306F\u5618\u3064\u304D\u3060\u300F\u7B49\u3068\u4F9B\u8FF0\u3092\u3057\u3066\u304A\u308A\u52D5\u6A5F\u306F\u672A\u3060\u4E0D\u660E\u300D",
    "id" : 130594054126845953,
    "created_at" : "2011-10-30 10:37:03 +0000",
    "user" : {
      "name" : "\u304B\u304A\u306A\u3057",
      "screen_name" : "kao__nashi",
      "protected" : false,
      "id_str" : "42397277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1773042993\/220856380_normal.jpg",
      "id" : 42397277,
      "verified" : false
    }
  },
  "id" : 130623363860283392,
  "created_at" : "2011-10-30 12:33:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130622751512858624",
  "text" : "\u4E00\u306E\u4F4D\u7F6E\u304C\u4E00\u81F4",
  "id" : 130622751512858624,
  "created_at" : "2011-10-30 12:31:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130622356241645568",
  "text" : "\u30E8\u30FC\u30B0\u30EB\u30C8450\uFF47\u3063\u3066\u591A\u3044\u306A\u30FC\u3002\u671F\u9650\u4E91\u3005\u629C\u304D\u306B\u3057\u3066\u304A\u8179\u75DB\u304F\u306A\u308A\u305D\u30FC",
  "id" : 130622356241645568,
  "created_at" : "2011-10-30 12:29:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mtb",
      "screen_name" : "mtb_p",
      "indices" : [ 3, 9 ],
      "id_str" : "2267412714",
      "id" : 2267412714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130621525144502273",
  "text" : "RT @mtb_p: \u60C5\u5831\u7CFB\u306E\u53CB\u4EBA\u306B\u30DE\u30EB\u30A4\u306E\uFF10\uFF11\uFF10\uFF11\u3092\u6307\u3057\u3066\u300C\u3042\u308C\u3001\u4F55\u3066\u8AAD\u3080\u304B\u308F\u304B\u308B\uFF1F\u300D\u3068\u805E\u304F\u3068\u300C\uFF15\u300D\u3068\u8FD4\u3063\u3066\u304D\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130584694302584832",
    "text" : "\u60C5\u5831\u7CFB\u306E\u53CB\u4EBA\u306B\u30DE\u30EB\u30A4\u306E\uFF10\uFF11\uFF10\uFF11\u3092\u6307\u3057\u3066\u300C\u3042\u308C\u3001\u4F55\u3066\u8AAD\u3080\u304B\u308F\u304B\u308B\uFF1F\u300D\u3068\u805E\u304F\u3068\u300C\uFF15\u300D\u3068\u8FD4\u3063\u3066\u304D\u305F\u3002",
    "id" : 130584694302584832,
    "created_at" : "2011-10-30 09:59:51 +0000",
    "user" : {
      "name" : "MtB",
      "screen_name" : "mtb_beta",
      "protected" : false,
      "id_str" : "183331977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000591484572\/f8566335431f675545988be532219378_normal.jpeg",
      "id" : 183331977,
      "verified" : false
    }
  },
  "id" : 130621525144502273,
  "created_at" : "2011-10-30 12:26:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130620857260326912",
  "text" : "\u51B7\u8535\u5EAB\u306B\u671F\u9650\u5207\u308C\u306E\u30E8\u30FC\u30B0\u30EB\u30C8\u3092\u898B\u3064\u3051\u3066\u3057\u307E\u3063\u305F\u3002\u672A\u958B\u5C01\u306A\u3089\u5927\u4E08\u592B\u3068\u4FE1\u3058\u3066\u3044\u305F\u3060\u304D\u307E\u3059\u3002",
  "id" : 130620857260326912,
  "created_at" : "2011-10-30 12:23:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130615091090563072",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 130615091090563072,
  "created_at" : "2011-10-30 12:00:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 17, 26 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 27, 37 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130609397490647040",
  "text" : "\u305D\u306E\u5206\u5E03\u306F\u307E\u3055\u306B\u30DD\u30EF\u30BD\u30F3\uFF01 RT @akeopyaa @end313124 \u305D\u306E\u7E4B\u304C\u308B\u69D8\u306F\u6B63\u306B\u30EA\u30A8\u30BE\u30F3\uFF01\uFF01",
  "id" : 130609397490647040,
  "created_at" : "2011-10-30 11:38:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130608507690024960",
  "text" : "\u983C\u308A\u306B\u3057\u3066\u3044\u305F\u53CB\u4EBA\u304C\u4FFA\u3092\u983C\u308A\u306B\u3057\u3066\u3044\u305F\u2026\u3053\u308C\u304C\u5171\u4F9D\u5B58\uFF01\u2190",
  "id" : 130608507690024960,
  "created_at" : "2011-10-30 11:34:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130608350936309760",
  "text" : "\u3010\u6025\u52DF\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u706B\u66DCcall\u306E\u7B2C\u4E00\u56DE\u306E\u8A66\u9A13\u7BC4\u56F2\u77E5\u3063\u3066\u308B\u4EBA",
  "id" : 130608350936309760,
  "created_at" : "2011-10-30 11:33:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130603068000706560",
  "text" : "\u3068\u3053\u308D\u304C\u3069\u3063\u3053\u3044\u2026\u6587\u7CFB\uFF01\u3053\u308C\u304C\u6587\u7CFB\u3067\u3059\u2026\uFF01",
  "id" : 130603068000706560,
  "created_at" : "2011-10-30 11:12:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130602812383047680",
  "text" : "\u6587\u7CFB\u306F\u301C\u3068\u304B\u306D\u3047\n\n\u79C1\u304C\u53CD\u4F8B\u3060",
  "id" : 130602812383047680,
  "created_at" : "2011-10-30 11:11:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/mqBN4oSd",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=Harayamada",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "130554703124774912",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001Harayamada\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/mqBN4oSd",
  "id" : 130554703124774912,
  "created_at" : "2011-10-30 08:00:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u660E\u667A\u5C0F\u8863",
      "screen_name" : "kokoro_G4_bot",
      "indices" : [ 0, 14 ],
      "id_str" : "216818830",
      "id" : 216818830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130538701204885504",
  "geo" : { },
  "id_str" : "130539289607024640",
  "in_reply_to_user_id" : 216818830,
  "text" : "@kokoro_G4_bot \u30CE\u30FC",
  "id" : 130539289607024640,
  "in_reply_to_status_id" : 130538701204885504,
  "created_at" : "2011-10-30 06:59:26 +0000",
  "in_reply_to_screen_name" : "kokoro_G4_bot",
  "in_reply_to_user_id_str" : "216818830",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130538902229487617",
  "text" : "\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u66B4\u308C\u3059\u304E\u3067\u3059\u3057",
  "id" : 130538902229487617,
  "created_at" : "2011-10-30 06:57:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130538557923266560",
  "text" : "16\u6642\u5E30\u5B85\u306F\u9593\u306B\u5408\u308F\u306A\u3055\u305D\u3046\u2026\u3002\n\n\u59B9\u3082\u308F\u3056\u308F\u3056\u9326\u901A\u307E\u3067\u51FA\u306A\u3044\u3068\u8CB7\u3048\u306A\u3044\u6F2C\u7269\u5C4B\u3092\u6307\u5B9A\u3057\u306A\u304F\u3066\u3082\u3044\u30FC\u306E\u306B\u3002",
  "id" : 130538557923266560,
  "created_at" : "2011-10-30 06:56:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130536291203952640",
  "geo" : { },
  "id_str" : "130538149444194304",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u304A\u3044\u3067\u30FC",
  "id" : 130538149444194304,
  "in_reply_to_status_id" : 130536291203952640,
  "created_at" : "2011-10-30 06:54:54 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130520276160086016",
  "text" : "\u4ED5\u65B9\u306A\u3044\u300216\u6642\u307E\u3067\u306B\u5E30\u3063\u3066\u6765\u3066\u8AB2\u984C\u3092\u3084\u308D\u3046\u3002",
  "id" : 130520276160086016,
  "created_at" : "2011-10-30 05:43:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130520094810963968",
  "text" : "\u3042\u30FC\u3001\u7D50\u5C40\u4ECA\u65E5\u6F2C\u7269\u8CB7\u3044\u306B\u3044\u304B\u306A\u3044\u3068\u30BF\u30A4\u30DF\u30F3\u30B0\u9003\u3059\u611F\u3058\u304B\u2026\u3002",
  "id" : 130520094810963968,
  "created_at" : "2011-10-30 05:43:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130518493232775168",
  "text" : "\u548C\u83D3\u5B50\u5C4B\u306E\u304A\u3070\u3061\u3083\u3093\u304A\u307E\u3051\u3057\u3066\u304F\u308C\u305F\u3002\u6817\u9905\u3068\u30B3\u30FC\u30D2\u30FC\u3082\u3050\u3082\u3050\u3002",
  "id" : 130518493232775168,
  "created_at" : "2011-10-30 05:36:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 9, 16 ],
      "id_str" : "50640629",
      "id" : 50640629
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 26, 33 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 44, 51 ],
      "id_str" : "50640629",
      "id" : 50640629
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 61, 68 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 79, 86 ],
      "id_str" : "50640629",
      "id" : 50640629
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 96, 103 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 114, 121 ],
      "id_str" : "50640629",
      "id" : 50640629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130468970825388032",
  "text" : "\u59BB\u306E\u3064\u307E\u307F RT @igaris: \u5144\u306E\u674F\u4EC1 RT @tenapi: \u53D4\u7236\u306E\u5F80\u6642 RT @igaris: \u59C9\u306E\u5B89\u5BE7 RT @tenapi: \u7956\u7236\u306E\u9001\u4ED8 RT @igaris: \u5AC1\u306E\u4F59\u547D RT @tenapi: \u5A7F\u306E\u5411\u3053\u3046 RT @igaris: \u59EB\u306E\u60B2\u9CF4",
  "id" : 130468970825388032,
  "created_at" : "2011-10-30 02:20:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130336439408934913",
  "text" : "\u4ECA\u65E5\u306F\u8CA0\u3051\u306A\u304B\u3063\u305F\u3051\u3069\u52DD\u3063\u3066\u306A\u3044\u306A\u2026\u4E00\u56DE3\u4F4D\u304C\u3042\u3063\u305F\u4EE5\u5916\u307F\u3093\u306A\u4E8C\u4F4D\u3060\u3063\u305F\u304B\u3089\u8CA0\u3051\u304B\uFF57",
  "id" : 130336439408934913,
  "created_at" : "2011-10-29 17:33:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130336170335936512",
  "text" : "\u5BDD\u306A\u304A\u3059\u304B\u30FC\uFF0819\u6642\u304B\u30890\u6642\u307E\u3067\u5BDD\u3066\u3044\u305F\uFF09",
  "id" : 130336170335936512,
  "created_at" : "2011-10-29 17:32:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130335640360452096",
  "text" : "\u622F\u8A00\u3060\u3051\u3069\u306D",
  "id" : 130335640360452096,
  "created_at" : "2011-10-29 17:30:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/Ob0guriO",
      "expanded_url" : "http:\/\/shindanmaker.com\/163601",
      "display_url" : "shindanmaker.com\/163601"
    } ]
  },
  "geo" : { },
  "id_str" : "130335569774510081",
  "text" : "\u7570\u6027\u304Cend313124\u306B\u5BFE\u3057\u3066\u8A00\u3044\u305F\u3044\u3053\u3068\u2192\u300C\u611B\u3057\u3066\u308B\u300D\u300C\u611B\u3057\u3066\u308B\u300D\u300C\u611B\u3057\u3066\u308B\u300D\u300C\u611B\u3057\u3066\u308B\u300D\u300C\u611B\u3057\u3066\u308B\u300D\u300C\u611B\u3057\u3066\u308B\u300D\u300C\u30DE\u30B8\u3067\u611B\u3057\u3066\u308B\u300D http:\/\/t.co\/Ob0guriO  \n\u611B\u3055\u308C\u306620\u5E74\u3001\u5B89\u5B9A\u3068\u4FE1\u983C\u306Eend313124\u3067\u3054\u3056\u3044\u307E\u3059\u3002",
  "id" : 130335569774510081,
  "created_at" : "2011-10-29 17:29:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130313125433065472",
  "text" : "@Malmach140 \u3084\u308A\u307E\u3059\u30FC",
  "id" : 130313125433065472,
  "created_at" : "2011-10-29 16:00:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130312790878593024",
  "text" : "@Malmach140 \u6771\u98A8\u3067\u3059\u304B\uFF57",
  "id" : 130312790878593024,
  "created_at" : "2011-10-29 15:59:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307B\u304F\u307B\u304F\u3068",
      "screen_name" : "hokuhokuto",
      "indices" : [ 3, 14 ],
      "id_str" : "176634531",
      "id" : 176634531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RT\u3067\u8A08\u308D\u3046\u30AD\u30E3\u30E9\u30AF\u30BF\u30FC\u306E\u4EBA\u6C17\u5EA6",
      "indices" : [ 22, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130303106180329472",
  "text" : "RT @hokuhokuto: \u304F\u3063\u3061\u3093\u3071 #RT\u3067\u8A08\u308D\u3046\u30AD\u30E3\u30E9\u30AF\u30BF\u30FC\u306E\u4EBA\u6C17\u5EA6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RT\u3067\u8A08\u308D\u3046\u30AD\u30E3\u30E9\u30AF\u30BF\u30FC\u306E\u4EBA\u6C17\u5EA6",
        "indices" : [ 6, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130288160742711297",
    "text" : "\u304F\u3063\u3061\u3093\u3071 #RT\u3067\u8A08\u308D\u3046\u30AD\u30E3\u30E9\u30AF\u30BF\u30FC\u306E\u4EBA\u6C17\u5EA6",
    "id" : 130288160742711297,
    "created_at" : "2011-10-29 14:21:32 +0000",
    "user" : {
      "name" : "\u307B\u304F\u307B\u304F\u3068",
      "screen_name" : "hokuhokuto",
      "protected" : false,
      "id_str" : "176634531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607914634943725569\/xYEJu6fx_normal.jpg",
      "id" : 176634531,
      "verified" : false
    }
  },
  "id" : 130303106180329472,
  "created_at" : "2011-10-29 15:20:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130300662276829185",
  "text" : "\u3069\u3070\u306B\u3083\u3093\u3055\u3093\u306E\u30DD\u30EA\u30B7\u30FC\u308F\u304B\u308B\u304B\u3082\u3002",
  "id" : 130300662276829185,
  "created_at" : "2011-10-29 15:11:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130300557205315584",
  "text" : "RT @dovanyahn: \u30AA\u30EC\u30F3\u30B8\u30B8\u30E5\u30FC\u30B9\u3068\u304B\u306F\u57FA\u672C\u679C\u6C41100\uFF05\u306E\u3082\u306E\u3057\u304B\u98F2\u307E\u306A\u3044\u3051\u3069\u5C0F\u5CA9\u4E95\u306F\u679C\u6C4120\uFF05\u3068\u304B\u3060\u3051\u3069\u7F8E\u5473\u3057\u3044\u3002\u5C0F\u5CA9\u4E95\u7D14\u6C34\u3076\u3069\u3046\u3054\u304F\u3054\u304F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130300312425738241",
    "text" : "\u30AA\u30EC\u30F3\u30B8\u30B8\u30E5\u30FC\u30B9\u3068\u304B\u306F\u57FA\u672C\u679C\u6C41100\uFF05\u306E\u3082\u306E\u3057\u304B\u98F2\u307E\u306A\u3044\u3051\u3069\u5C0F\u5CA9\u4E95\u306F\u679C\u6C4120\uFF05\u3068\u304B\u3060\u3051\u3069\u7F8E\u5473\u3057\u3044\u3002\u5C0F\u5CA9\u4E95\u7D14\u6C34\u3076\u3069\u3046\u3054\u304F\u3054\u304F",
    "id" : 130300312425738241,
    "created_at" : "2011-10-29 15:09:50 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 130300557205315584,
  "created_at" : "2011-10-29 15:10:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130252777191518208",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 130252777191518208,
  "created_at" : "2011-10-29 12:00:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129856651133075456",
  "geo" : { },
  "id_str" : "129858196444684288",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF",
  "id" : 129858196444684288,
  "in_reply_to_status_id" : 129856651133075456,
  "created_at" : "2011-10-28 09:53:01 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129858100093128704",
  "text" : "\u30E1\u30D3\u30A6\u30B9\u306E\u8F2A\u3068\u305F\u3060\u306E\u8F2A\u306F\u540C\u76F8\uFF1F",
  "id" : 129858100093128704,
  "created_at" : "2011-10-28 09:52:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304C\u3043",
      "screen_name" : "GAi9112",
      "indices" : [ 1, 9 ],
      "id_str" : "169436782",
      "id" : 169436782
    }, {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 10, 20 ],
      "id_str" : "254452685",
      "id" : 254452685
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrrn",
      "indices" : [ 21, 35 ],
      "id_str" : "295216106",
      "id" : 295216106
    }, {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 36, 47 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129848798288683008",
  "text" : ".@GAi9112 @Lisa_math @nisehorrrrrrn @magokoro84 \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 129848798288683008,
  "created_at" : "2011-10-28 09:15:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129843079254523904",
  "text" : "\u98DF\u3079\u308B\u306E\u3082\u5BDD\u308B\u306E\u3082\u597D\u304D\u3060\u3051\u308C\u3069\u5FD9\u3057\u3044\u6642\u306F\u3069\u3063\u3061\u3082\u7169\u308F\u3057\u3044\u3088\u306A\u30FC",
  "id" : 129843079254523904,
  "created_at" : "2011-10-28 08:52:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129842877017767936",
  "text" : "\u3053\u3053\u304B\u3089\u529B\u5C3D\u304D\u308B\u307E\u3067\u9811\u5F35\u308B\u4E88\u5B9A\n\u304A\u8179\u6E1B\u3063\u305F\u304B\u3089\u3069\u3053\u304B\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u3054\u98EF\u98DF\u3079\u306A\u304D\u3083",
  "id" : 129842877017767936,
  "created_at" : "2011-10-28 08:52:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 22, 32 ],
      "id_str" : "254452685",
      "id" : 254452685
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 34, 44 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129841959807352832",
  "text" : "\u30EA\u30B5\u3061\u3083\u3093\u8FD4\u4FE1\u65E9\u3044\u3051\u3069\u9593\u9055\u3063\u3066\u308B\u3088\uFF01 RT @Lisa_math: @end313124 \u30CA\u30A4\u30B9\u66B4\u5F92",
  "id" : 129841959807352832,
  "created_at" : "2011-10-28 08:48:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129841668429058049",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046",
  "id" : 129841668429058049,
  "created_at" : "2011-10-28 08:47:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 7, 21 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129782436723834880",
  "geo" : { },
  "id_str" : "129782824285913088",
  "in_reply_to_user_id" : 109537708,
  "text" : "\u3060\u306F\u3041 QT @OhgakiRintaro: \u30A2\u30E1\u30EA\u30AB\u306E\u653F\u6CBB\u5B66\u8005\u3068\u304B\u304C\u66F8\u3044\u3066\u308B\u30D6\u30ED\u30B0\u3068\u304B\u3001\u610F\u5473\u304C\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u3053\u3068\u304C\u591A\u3044\u2026\u3002\u3060\u306F\u3041\u3002\u3002\u3002",
  "id" : 129782824285913088,
  "in_reply_to_status_id" : 129782436723834880,
  "created_at" : "2011-10-28 04:53:31 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u3082\u3057\u308D\u30D5\u30E9\u30C3\u30B7\u30E5\u5009\u5EAB",
      "screen_name" : "eve_kawa",
      "indices" : [ 3, 12 ],
      "id_str" : "209609719",
      "id" : 209609719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129764876603228160",
  "text" : "RT @eve_kawa: \u3010\u8C46\u77E5\u8B58\u3011\n\u304B\u3063\u3071\u5BFF\u53F8\u306E\u6CE8\u6587\u3059\u308B\u30BF\u30C3\u30C1\u30D1\u30CD\u30EB\u306E\u5DE6\u4E0B\u9685\u3092\u57F7\u62D7\u306B\u9023\u6253\u3059\u308B\u3068\u6CE8\u6587\u753B\u9762\u304C\u6D88\u3048\u3066Windows\u306E\u30C7\u30B9\u30AF\u30C8\u30C3\u30D7\u304C\u51FA\u3066\u304F\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.movatwi.jp\" rel=\"nofollow\"\u003E\u30E2\u30D0\u30C4\u30A4 \/ www.movatwi.jp .\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129756282122010624",
    "text" : "\u3010\u8C46\u77E5\u8B58\u3011\n\u304B\u3063\u3071\u5BFF\u53F8\u306E\u6CE8\u6587\u3059\u308B\u30BF\u30C3\u30C1\u30D1\u30CD\u30EB\u306E\u5DE6\u4E0B\u9685\u3092\u57F7\u62D7\u306B\u9023\u6253\u3059\u308B\u3068\u6CE8\u6587\u753B\u9762\u304C\u6D88\u3048\u3066Windows\u306E\u30C7\u30B9\u30AF\u30C8\u30C3\u30D7\u304C\u51FA\u3066\u304F\u308B\u3002",
    "id" : 129756282122010624,
    "created_at" : "2011-10-28 03:08:03 +0000",
    "user" : {
      "name" : "\u304A\u3082\u3057\u308D\u30D5\u30E9\u30C3\u30B7\u30E5\u5009\u5EAB",
      "screen_name" : "eve_kawa",
      "protected" : false,
      "id_str" : "209609719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481105962204282880\/Ol-3GwkW_normal.jpeg",
      "id" : 209609719,
      "verified" : false
    }
  },
  "id" : 129764876603228160,
  "created_at" : "2011-10-28 03:42:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129528380981919745",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 129528380981919745,
  "created_at" : "2011-10-27 12:02:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 3, 14 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "J_K\u306F\u7406\u60F3",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129478801955618816",
  "text" : "RT @haguruma20: \u67D0\u52D5\u753B\u30B5\u30A4\u30C8\u306A\u3089\u3001\uFF62\u3053\u308C\u304C\u8A00\u3044\u305F\u304B\u3063\u305F\u3060\u3051\u3060\u308D\uFF63\u306E\u30BF\u30B0\u304C\u3064\u3051\u3089\u4EE5\u4E0B\u7565\u3000#J_K\u306F\u7406\u60F3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "J_K\u306F\u7406\u60F3",
        "indices" : [ 35, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129474231200251904",
    "text" : "\u67D0\u52D5\u753B\u30B5\u30A4\u30C8\u306A\u3089\u3001\uFF62\u3053\u308C\u304C\u8A00\u3044\u305F\u304B\u3063\u305F\u3060\u3051\u3060\u308D\uFF63\u306E\u30BF\u30B0\u304C\u3064\u3051\u3089\u4EE5\u4E0B\u7565\u3000#J_K\u306F\u7406\u60F3",
    "id" : 129474231200251904,
    "created_at" : "2011-10-27 08:27:16 +0000",
    "user" : {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "protected" : false,
      "id_str" : "349830212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598099530144292864\/KdP7hjPX_normal.jpg",
      "id" : 349830212,
      "verified" : false
    }
  },
  "id" : 129478801955618816,
  "created_at" : "2011-10-27 08:45:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/mqBN4oSd",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=Harayamada",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129459531594993664",
  "text" : "end313124\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3001Harayamada\u3055\u3093\u304C\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/mqBN4oSd",
  "id" : 129459531594993664,
  "created_at" : "2011-10-27 07:28:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129429929132691456",
  "text" : "\u91D1\u878D\u8AD6\u3067\u30CD\u30A4\u30D4\u30A2\u6570\uFF45\u304C\u7121\u7406\u6570\u3068\u304B\u622F\u8A00\u3060\u308D\u2026",
  "id" : 129429929132691456,
  "created_at" : "2011-10-27 05:31:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "indices" : [ 3, 17 ],
      "id_str" : "101753216",
      "id" : 101753216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129211200385990656",
  "text" : "RT @factoring_bot: 20111027 is prime! Today is prime!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/prime.4403.biz\/factoring_bot\/\" rel=\"nofollow\"\u003Efactoring_bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129210939567386624",
    "text" : "20111027 is prime! Today is prime!",
    "id" : 129210939567386624,
    "created_at" : "2011-10-26 15:01:03 +0000",
    "user" : {
      "name" : "\u7D20\u56E0\u6570\u5206\u89E3\u30DC\u30C3\u30C8\u300C\u3075\u3041\u304F\u305F\u3093\u300D",
      "screen_name" : "factoring_bot",
      "protected" : false,
      "id_str" : "101753216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727655584\/factan_normal.png",
      "id" : 101753216,
      "verified" : false
    }
  },
  "id" : 129211200385990656,
  "created_at" : "2011-10-26 15:02:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129204928274116608",
  "geo" : { },
  "id_str" : "129210314943250432",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u6B8B\u5FF5\u3067\u3059\u3002\u3002\u3002",
  "id" : 129210314943250432,
  "in_reply_to_status_id" : 129204928274116608,
  "created_at" : "2011-10-26 14:58:34 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 0, 6 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129209565114933248",
  "geo" : { },
  "id_str" : "129209807654764544",
  "in_reply_to_user_id" : 184844182,
  "text" : "@0_uda \u628A\u63E1\u3057\u307E\u3057\u305F\u30FC\u3001\u7A7A\u304D\u30B3\u30DE\u306A\u306E\u3067\u884C\u304D\u307E\u3059\uFF57",
  "id" : 129209807654764544,
  "in_reply_to_status_id" : 129209565114933248,
  "created_at" : "2011-10-26 14:56:33 +0000",
  "in_reply_to_screen_name" : "0_uda",
  "in_reply_to_user_id_str" : "184844182",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129208968886239233",
  "text" : "\u7406\u5B66\u90E82\u53F7\u9928\u3063\u3066\u3069\u3053\u3067\u3059\uFF1F",
  "id" : 129208968886239233,
  "created_at" : "2011-10-26 14:53:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129200160105431040",
  "geo" : { },
  "id_str" : "129200543133478912",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u3048\u3001\u4FFA\u3063\u3066\u5148\u8F29\u306E\u4E2D\u3067\u305D\u3093\u306A\u306B\u5984\u60F3\u6FC0\u3057\u3044\u30AD\u30E3\u30E9\u306A\u3093\u3067\u3059\u304B",
  "id" : 129200543133478912,
  "in_reply_to_status_id" : 129200160105431040,
  "created_at" : "2011-10-26 14:19:44 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129198052752887808",
  "geo" : { },
  "id_str" : "129198879060144128",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u6765\u9031\u4E0B\u624B\u3057\u305F\u3089\u4F1A\u3048\u308B\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u3051\u3069\u306D\uFF57\uFF57\u5148\u8F29\u304C\u6765\u306A\u304F\u3066\u3082\u5712\u541B\u304B\u897F\u6797\u3055\u3093\u306B\u8A3C\u4EBA\u306B\u306A\u3063\u3066\u3082\u3089\u3048\u3070\u5341\u5206\u3067\u3057\u3087\u3046\uFF57",
  "id" : 129198879060144128,
  "in_reply_to_status_id" : 129198052752887808,
  "created_at" : "2011-10-26 14:13:07 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3057\u304B\u3057\u3066: \u30C6\u30C3\u30C6\u30EC\u30FC",
      "screen_name" : "modestrella",
      "indices" : [ 0, 12 ],
      "id_str" : "146090085",
      "id" : 146090085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129197138117791744",
  "geo" : { },
  "id_str" : "129197695599521792",
  "in_reply_to_user_id" : 146090085,
  "text" : "@modestrella \u4E00\u4EBA\u3063\u5B50\u306B\u898B\u3089\u308C\u308B\u3053\u3068\u304C\u591A\u3044\u3067\u3059\u306D\u3002\u6D41\u77F3\u306B\u672B\u3063\u5B50\u3068\u8A00\u308F\u308C\u305F\u3053\u3068\u306F\u306A\u3044\u3067\u3059\u304C\u3002",
  "id" : 129197695599521792,
  "in_reply_to_status_id" : 129197138117791744,
  "created_at" : "2011-10-26 14:08:25 +0000",
  "in_reply_to_screen_name" : "modestrella",
  "in_reply_to_user_id_str" : "146090085",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "indices" : [ 3, 9 ],
      "id_str" : "5335922",
      "id" : 5335922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mathgirl",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129172341472231424",
  "text" : "RT @hyuki: #mathgirl \u79C1\u306F\u300C\u6570\u5B66\u30AC\u30FC\u30EB\u300D\u3092\u5947\u8DE1\u7684\u306B\u9762\u767D\u3044\u7269\u8A9E\u3060\u3068\u601D\u3063\u3066\u3044\u3066\u3001\u591A\u304F\u306E\u4EBA\u306B\u8AAD\u3093\u3067\u3044\u305F\u3060\u304D\u305F\u3044\u3068\u601D\u3063\u3066\u3044\u307E\u3059\u3002\u30E9\u30CE\u30D9\u7684\u306A\u30C8\u30FC\u30F3\u306B\u62B5\u6297\u304C\u306A\u3051\u308C\u3070\u3001\u6570\u5B66\u306B\u95A2\u308F\u3063\u3066\u3044\u308B\u5EA6\u5408\u3044\u306B\u5FDC\u3058\u3066\u305D\u308C\u305E\u308C\u306E\u9762\u767D\u307F\u3092\u898B\u3064\u3051\u3066\u304F\u3060\u3055\u308B\u3068\u601D\u3063\u3066\u3044\u307E\u3059\u3002\u3067\u3059\u304B\u3089\u3001\u751F\u5F92\u3055 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mathgirl",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129172266599727104",
    "text" : "#mathgirl \u79C1\u306F\u300C\u6570\u5B66\u30AC\u30FC\u30EB\u300D\u3092\u5947\u8DE1\u7684\u306B\u9762\u767D\u3044\u7269\u8A9E\u3060\u3068\u601D\u3063\u3066\u3044\u3066\u3001\u591A\u304F\u306E\u4EBA\u306B\u8AAD\u3093\u3067\u3044\u305F\u3060\u304D\u305F\u3044\u3068\u601D\u3063\u3066\u3044\u307E\u3059\u3002\u30E9\u30CE\u30D9\u7684\u306A\u30C8\u30FC\u30F3\u306B\u62B5\u6297\u304C\u306A\u3051\u308C\u3070\u3001\u6570\u5B66\u306B\u95A2\u308F\u3063\u3066\u3044\u308B\u5EA6\u5408\u3044\u306B\u5FDC\u3058\u3066\u305D\u308C\u305E\u308C\u306E\u9762\u767D\u307F\u3092\u898B\u3064\u3051\u3066\u304F\u3060\u3055\u308B\u3068\u601D\u3063\u3066\u3044\u307E\u3059\u3002\u3067\u3059\u304B\u3089\u3001\u751F\u5F92\u3055\u3093\u306B\u306F\u518D\u8AAD\u3092\u304A\u52E7\u3081\u3057\u3066\u3044\u307E\u3059\u3002",
    "id" : 129172266599727104,
    "created_at" : "2011-10-26 12:27:22 +0000",
    "user" : {
      "name" : "\u7D50\u57CE\u6D69",
      "screen_name" : "hyuki",
      "protected" : false,
      "id_str" : "5335922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556785665845624832\/svOdvq6q_normal.png",
      "id" : 5335922,
      "verified" : false
    }
  },
  "id" : 129172341472231424,
  "created_at" : "2011-10-26 12:27:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iris pe\u00F1a",
      "screen_name" : "iris1211",
      "indices" : [ 0, 9 ],
      "id_str" : "601994539",
      "id" : 601994539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129170352793321472",
  "geo" : { },
  "id_str" : "129170678875291648",
  "in_reply_to_user_id" : 199550192,
  "text" : "@iris1211\u3000\u611A\u59B9\u3067\u3059\u304C\uFF57\uFF57\u5C0F6\u3060\u304B\u3089\u3080\u3063\u3061\u3083\u5E74\u96E2\u308C\u3066\u308B\u3002\u9593\u306B\u5F1F\u3044\u308B\u3051\u3069\u3002",
  "id" : 129170678875291648,
  "in_reply_to_status_id" : 129170352793321472,
  "created_at" : "2011-10-26 12:21:04 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129170371231498241",
  "text" : "@nartakio \u5869\u304A\u3059\u3059\u3081\u3067\u3059\u3057\u304A\u5BFF\u53F8",
  "id" : 129170371231498241,
  "created_at" : "2011-10-26 12:19:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129170130331648000",
  "text" : "\u307E\u3041\u305D\u3082\u305D\u3082\u4F55\u304B\u8CB7\u3063\u3066\u3042\u3052\u308B\u4E88\u5B9A\u304C\u3042\u308B\u308F\u3051\u3058\u3083\u306A\u3044\u3093\u3060\u3051\u3069\u3055\uFF57\uFF57\uFF57",
  "id" : 129170130331648000,
  "created_at" : "2011-10-26 12:18:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129169974358048768",
  "text" : "\u89AA\u306B\u96FB\u8A71\u3057\u3066\u305F\u3089\u3057\u3070\u3089\u304F\u3057\u3066\u59B9\u306B\u4EE3\u308F\u3063\u305F\n\u81EA\u5206\u300C\u4F55\uFF1F\u300D\n\u59B9\u300C\u3042\u306E\u3055\u3001\u3057\u3070\u6F2C\u3051\u8CB7\u3063\u3066\u304D\u3066\u307B\u3057\u3044\u3093\u3060\u3051\u3069\u3002\u300D\n\u81EA\u5206\u300C\u3048\u30FC\u3001\u9762\u5012\u306A\u3093\u3060\u3088\u306A\uFF0D\u300D\n\u59B9\u300C\u307B\u3089\u3001\u308F\u305F\u305710\u6708\u8A95\u751F\u65E5\u3042\u308B\u3057\u300D\n\u81EA\u5206\u300C\u304A\u524D\u8A95\u751F\u65E5\u3057\u3070\u6F2C\u3051\u3067\u3044\u3044\u306E\u304B\uFF57\uFF57\uFF57\uFF57\u300D",
  "id" : 129169974358048768,
  "created_at" : "2011-10-26 12:18:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129167097942118400",
  "text" : "\u30A8\u30AF\u30B9\u30C8\u30EA\u30FC\u30E0\u30FB\u30BB\u30DF\u30CA\u30FC",
  "id" : 129167097942118400,
  "created_at" : "2011-10-26 12:06:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129167002706264064",
  "text" : "\u30B5\u30A6\u30CA\u306B\u767D\u677F\u304B\u9ED2\u677F\u3042\u3063\u305F\u3089\u9762\u767D\u3044\u306E\u306B",
  "id" : 129167002706264064,
  "created_at" : "2011-10-26 12:06:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129166797160194048",
  "text" : "\u75C7\u72B6\u2026\u3060\u3044\u305F\u3044\u5C11\u5E74\u3063\u3066\u5E74\u3067\u3082\u306A\u304F\u306A\u3063\u3066\u304D\u3066\u3057\u307E\u3063\u305F\u3057\u306A\u3041\u3002",
  "id" : 129166797160194048,
  "created_at" : "2011-10-26 12:05:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129166683796545536",
  "text" : "\u8FD1\u6240\u306E\u92AD\u6E6F\u3067\u30B5\u30A6\u30CA\u3067\u81EA\u5206\u3092\u8FFD\u3044\u8FBC\u3080\u904A\u3073\u3092\u3084\u3063\u3066\u304D\u305F\u3002\u8131\u6C34\u5C11\u5973\u30C1\u30AD\u30F3\u30EC\u30FC\u30B9\u307F\u305F\u3044\u306A\u3002",
  "id" : 129166683796545536,
  "created_at" : "2011-10-26 12:05:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129108088845385729",
  "text" : "\u8352\u3076\u308B\u30AD\u30E5\u30FC\u5B50\u2026",
  "id" : 129108088845385729,
  "created_at" : "2011-10-26 08:12:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3082\u3082\u3053",
      "screen_name" : "momo_miku28",
      "indices" : [ 0, 12 ],
      "id_str" : "131856285",
      "id" : 131856285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129044395164049409",
  "geo" : { },
  "id_str" : "129045277825961985",
  "in_reply_to_user_id" : 131856285,
  "text" : "@momo_miku28 \u305D\u308C\u3092\u306A\u3093\u3068\u304B\u7E4B\u3052\u3066\u307F\u305F\u3044\u3093\u3067\u3059\u3051\u3069\u306D\u3047",
  "id" : 129045277825961985,
  "in_reply_to_status_id" : 129044395164049409,
  "created_at" : "2011-10-26 04:02:46 +0000",
  "in_reply_to_screen_name" : "momo_miku28",
  "in_reply_to_user_id_str" : "131856285",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129044857195999232",
  "text" : "\u5408\u7406\u6027\u3092\u5408\u7406\u7684\u306B\n\u516C\u7406\u6027\u3092\u5B9A\u7FA9\u7684\u306B",
  "id" : 129044857195999232,
  "created_at" : "2011-10-26 04:01:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129044375127859200",
  "text" : "\u54F2\u5B66\u304B\u3089\u898B\u308C\u3070\u6570\u5B66\u306F\u524D\u63D0\u3092\u7591\u308F\u306A\u3055\u904E\u304E\u308B\u3057\u3001\u6570\u5B66\u304B\u3089\u307F\u308C\u3070\u3001\u54F2\u5B66\u306F\u524D\u63D0\u304C\u66D6\u6627\u3059\u304E\u308B",
  "id" : 129044375127859200,
  "created_at" : "2011-10-26 03:59:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129043945538863105",
  "text" : "\u5B58\u5728\u3057\u306A\u3044\u5883\u754C\u4E0A\u306B\u3044\u308B\u6C17\u304C\u3057\u3066\u6765\u308B\u306E\u306F\u52C9\u5F37\u4E0D\u8DB3\u306A\u3093\u3060\u3051\u308C\u3069",
  "id" : 129043945538863105,
  "created_at" : "2011-10-26 03:57:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129043708116078592",
  "text" : "\u6587\u5B66\u306E\u8B70\u8AD6\u3068\u6570\u5B66\u306E\u8B70\u8AD6\u306E\u5DEE\u7570\u306B\u8F9F\u6613\u3059\u308B\u2026",
  "id" : 129043708116078592,
  "created_at" : "2011-10-26 03:56:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C8\u30EA\u30D3\u5C4B",
      "screen_name" : "toribiabot",
      "indices" : [ 3, 14 ],
      "id_str" : "544951675",
      "id" : 544951675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129043080161673216",
  "text" : "RT @toribiabot: \u30CE\u30EB\u30A6\u30A7\u30FC\u9678\u8ECD\u5927\u4F50\u306E\u968E\u7D1A\u3092\u6301\u3061\u3001\u738B\u5BA4\u89AA\u885B\u968A\u306E\u540D\u8A89\u9023\u968A\u9577\u306B\u4EFB\u547D\u3055\u308C\u305F\u30DA\u30F3\u30AE\u30F3\u304C\u3044\u308B \u3000\u30CB\u30EB\u30B9\u30FB\u30AA\u30FC\u30E9\u30F4\u306F\u3001\u30A4\u30AE\u30EA\u30B9\u30FB\u30B9\u30B3\u30C3\u30C8\u30E9\u30F3\u30C9\u306E\u30A8\u30B8\u30F3\u30D0\u30E9\u52D5\u7269\u5712\u306B\u3044\u308B\u30AD\u30F3\u30B0\u30DA\u30F3\u30AE\u30F3\u3002\u30CE\u30EB\u30A6\u30A7\u30FC\u9678\u8ECD\u8FD1\u885B\u90E8\u968A\u306E\u30DE\u30B9\u30B3\u30C3\u30C8\u3067\u3042\u308A\u30012008\u5E74\u6642\u70B9\u3067\u30CE\u30EB\u30A6\u30A7\u30FC\u306E\u9A0E ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129041923838185472",
    "text" : "\u30CE\u30EB\u30A6\u30A7\u30FC\u9678\u8ECD\u5927\u4F50\u306E\u968E\u7D1A\u3092\u6301\u3061\u3001\u738B\u5BA4\u89AA\u885B\u968A\u306E\u540D\u8A89\u9023\u968A\u9577\u306B\u4EFB\u547D\u3055\u308C\u305F\u30DA\u30F3\u30AE\u30F3\u304C\u3044\u308B \u3000\u30CB\u30EB\u30B9\u30FB\u30AA\u30FC\u30E9\u30F4\u306F\u3001\u30A4\u30AE\u30EA\u30B9\u30FB\u30B9\u30B3\u30C3\u30C8\u30E9\u30F3\u30C9\u306E\u30A8\u30B8\u30F3\u30D0\u30E9\u52D5\u7269\u5712\u306B\u3044\u308B\u30AD\u30F3\u30B0\u30DA\u30F3\u30AE\u30F3\u3002\u30CE\u30EB\u30A6\u30A7\u30FC\u9678\u8ECD\u8FD1\u885B\u90E8\u968A\u306E\u30DE\u30B9\u30B3\u30C3\u30C8\u3067\u3042\u308A\u30012008\u5E74\u6642\u70B9\u3067\u30CE\u30EB\u30A6\u30A7\u30FC\u306E\u9A0E\u58EB\u53F7\u3068\u540D\u8A89\u9023\u968A\u9577\u306E\u8EAB\u5206\u3092\u6301\u3064\u3002\u3000",
    "id" : 129041923838185472,
    "created_at" : "2011-10-26 03:49:26 +0000",
    "user" : {
      "name" : "\u51CD\u7D50\u89E3\u9664\u3055\u308C\u305F\u30C8\u30EA\u30D3\u30A2\u57A2",
      "screen_name" : "toribiaaka",
      "protected" : false,
      "id_str" : "310569105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488327075078492160\/uLsZPB_c_normal.jpeg",
      "id" : 310569105,
      "verified" : false
    }
  },
  "id" : 129043080161673216,
  "created_at" : "2011-10-26 03:54:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129042744432799745",
  "text" : "\u306C\u3044\u3050\u308B\u307F\u306F\u826F\u3044\u3060\u308D\u2026\u3044\u3084\u3001\u5BB6\u306B\u306F\u306A\u3044\u3051\u3069",
  "id" : 129042744432799745,
  "created_at" : "2011-10-26 03:52:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6A58 \u543E\u59BB",
      "screen_name" : "nekonendo",
      "indices" : [ 3, 13 ],
      "id_str" : "126691264",
      "id" : 126691264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129042584344596480",
  "text" : "RT @nekonendo: \u7537\u6027\u306E\u90E8\u5C4B\u306B\u3042\u3063\u305F\u3089\u5F15\u304F\u3082\u306E\u4E00\u89A7\uFF20\u3081\u3056\u307E\u3057\u300C\u6C34\u7740\u59FF\u306E\u30A2\u30A4\u30C9\u30EB\u306E\u30DD\u30B9\u30BF\u30FC\u300D\u300C\u5973\u6027\u3082\u306E\u306E\u5316\u7CA7\u54C1\u300D\u300C\u5143\u30AB\u30CE\u306E\u30D7\u30EA\u30AF\u30E9\u300D\u300C\u30D8\u30A2\u30A2\u30A4\u30ED\u30F3\u300D\u300C\u30A2\u30CB\u30E1\u7CFB\u30D5\u30A3\u30AE\u30E5\u30A2\u300D\u300C\u30D4\u30F3\u30AF\u8272\u306E\u30B0\u30C3\u30BA\u300D\u300C\u306C\u3044\u3050\u308B\u307F\u300D\u300C\u30C7\u30B9\u30AF\u30C8\u30C3\u30D7\u304C\u30A2\u30CB\u30E1\u306E\u58C1\u7D19\u300D\u3053\u308C\u3089\u5168\u90E8\u3001\u4E16\u306E\u5973\u6027\u306F\u7121\u7406\u3060 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128963457851719681",
    "text" : "\u7537\u6027\u306E\u90E8\u5C4B\u306B\u3042\u3063\u305F\u3089\u5F15\u304F\u3082\u306E\u4E00\u89A7\uFF20\u3081\u3056\u307E\u3057\u300C\u6C34\u7740\u59FF\u306E\u30A2\u30A4\u30C9\u30EB\u306E\u30DD\u30B9\u30BF\u30FC\u300D\u300C\u5973\u6027\u3082\u306E\u306E\u5316\u7CA7\u54C1\u300D\u300C\u5143\u30AB\u30CE\u306E\u30D7\u30EA\u30AF\u30E9\u300D\u300C\u30D8\u30A2\u30A2\u30A4\u30ED\u30F3\u300D\u300C\u30A2\u30CB\u30E1\u7CFB\u30D5\u30A3\u30AE\u30E5\u30A2\u300D\u300C\u30D4\u30F3\u30AF\u8272\u306E\u30B0\u30C3\u30BA\u300D\u300C\u306C\u3044\u3050\u308B\u307F\u300D\u300C\u30C7\u30B9\u30AF\u30C8\u30C3\u30D7\u304C\u30A2\u30CB\u30E1\u306E\u58C1\u7D19\u300D\u3053\u308C\u3089\u5168\u90E8\u3001\u4E16\u306E\u5973\u6027\u306F\u7121\u7406\u3060\u305D\u3046\u3067\u3059\u3088\u3002\u5168\u90E8OK\u306A\u3042\u305F\u3057\u306F\u4E00\u4F53\u3002",
    "id" : 128963457851719681,
    "created_at" : "2011-10-25 22:37:39 +0000",
    "user" : {
      "name" : "\u6A58 \u543E\u59BB",
      "screen_name" : "nekonendo",
      "protected" : false,
      "id_str" : "126691264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582921019486134273\/b7bqcX8r_normal.jpg",
      "id" : 126691264,
      "verified" : false
    }
  },
  "id" : 129042584344596480,
  "created_at" : "2011-10-26 03:52:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128996891177394176",
  "text" : "\u4E7E\u71E5\u3057\u3066\u5589\u306E\u75DB\u307F\u3068\u8D77\u5E8A\u3059\u308B\u5B63\u7BC0",
  "id" : 128996891177394176,
  "created_at" : "2011-10-26 00:50:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128995722518478848",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 128995722518478848,
  "created_at" : "2011-10-26 00:45:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128995563160080384",
  "text" : "\uFF2E\uFF28\uFF2B\u306E\u96C6\u91D1\u306B\u4ECA\u65E5\u3070\u304B\u308A\u306F\u611F\u8B1D\u3084\u306A\u3002\n\u76EE\u899A\u307E\u3057\u639B\u3051\u5FD8\u308C\u3066\u305F\u3057\u2190",
  "id" : 128995563160080384,
  "created_at" : "2011-10-26 00:45:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128855888109903873",
  "text" : "\u6700\u8FD1\u30DB\u30F3\u30C8\u306B\u300C\u4F8B\u793A\u306F\u7406\u89E3\u306E\u8A66\u91D1\u77F3\u300D\u3068\u5B9F\u611F\u3057\u3066\u3044\u308B\u3002",
  "id" : 128855888109903873,
  "created_at" : "2011-10-25 15:30:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128855379798011904",
  "text" : "\u30CF\u30A6\u30B9\u30C9\u30EB\u30D5\u7A7A\u9593\u3067\u306A\u3044\u308F\u304B\u308A\u3084\u3059\u3044\u4F8B\u3063\u3066\u4F55\u304B\u7121\u3044\u304B\u306A\u30FC",
  "id" : 128855379798011904,
  "created_at" : "2011-10-25 15:28:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iris pe\u00F1a",
      "screen_name" : "iris1211",
      "indices" : [ 0, 9 ],
      "id_str" : "601994539",
      "id" : 601994539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128852418833293312",
  "geo" : { },
  "id_str" : "128853912924065792",
  "in_reply_to_user_id" : 199550192,
  "text" : "@iris1211 \u6F2B\u753B\u4E8C\u5DFB\u307E\u3067\u6301\u3063\u3066\u308B\u305C\u3002\u4FFA\u306F\u30D5\u30E9\u30AF\u30BF\u30EB\u7D50\u69CB\u597D\u304D\u3060\u3063\u305F\u3093\u3060\u3051\u3069\u306D\u3047\u3002",
  "id" : 128853912924065792,
  "in_reply_to_status_id" : 128852418833293312,
  "created_at" : "2011-10-25 15:22:21 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128803211996962817",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 128803211996962817,
  "created_at" : "2011-10-25 12:00:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E1\u30A4\u30C9\u30B9\u30AD\u30FC\u306E\u30C9\u30B9",
      "screen_name" : "maidskii",
      "indices" : [ 3, 12 ],
      "id_str" : "101190268",
      "id" : 101190268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128802588886958080",
  "text" : "RT @maidskii: \u3010\u307E\u3061\u3071\u308B\u4F1D\u8AAC\u3011\n\u30FB\u7058\u2192\u74063\u2192\u7406\u7269\n\u30FB\u30A4\u30B1\u30E1\u30F3\n\u30FB\u5B9F\u9A13\u30CE\u30FC\u30C8\u306F\u5168\u90E8\u82F1\u8A9E\u3001\u6570\u5B66\u30CE\u30FC\u30C8\u306F\u30DA\u30EB\u30B7\u30A2\u8A9E\n\u30FB\u30A2\u30E9\u30D3\u30A2\u8A9E\u3082\u582A\u80FD\n\u30FB\u6570\u5B66\u8D85\u3067\u304D\u308B\u30CF\u30A4\u30B9\u30DA\u4EBA\u9593\n\u30FB\u82F1\u691C\u4E00\u7D1A\u6301\u3061\u3067TOEIC\u4E00\u56DE\u76EE\u3067975\n\u30FBIQ150over\n\u30FB\u300C\u5DE5\u4E8B\u73FE\u5834\u300D\u3092\u300C\u9AD8\u6B21\u5143\u5834\u300D\u3068\u805E\u304D\u9593 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128802280362348545",
    "text" : "\u3010\u307E\u3061\u3071\u308B\u4F1D\u8AAC\u3011\n\u30FB\u7058\u2192\u74063\u2192\u7406\u7269\n\u30FB\u30A4\u30B1\u30E1\u30F3\n\u30FB\u5B9F\u9A13\u30CE\u30FC\u30C8\u306F\u5168\u90E8\u82F1\u8A9E\u3001\u6570\u5B66\u30CE\u30FC\u30C8\u306F\u30DA\u30EB\u30B7\u30A2\u8A9E\n\u30FB\u30A2\u30E9\u30D3\u30A2\u8A9E\u3082\u582A\u80FD\n\u30FB\u6570\u5B66\u8D85\u3067\u304D\u308B\u30CF\u30A4\u30B9\u30DA\u4EBA\u9593\n\u30FB\u82F1\u691C\u4E00\u7D1A\u6301\u3061\u3067TOEIC\u4E00\u56DE\u76EE\u3067975\n\u30FBIQ150over\n\u30FB\u300C\u5DE5\u4E8B\u73FE\u5834\u300D\u3092\u300C\u9AD8\u6B21\u5143\u5834\u300D\u3068\u805E\u304D\u9593\u9055\u3048\u308B\u2190New!\n\u30FB\u574A\u4E3B\u982D\u2190\u6700\u91CD\u8981",
    "id" : 128802280362348545,
    "created_at" : "2011-10-25 11:57:11 +0000",
    "user" : {
      "name" : "\u30E1\u30A4\u30C9\u30B9\u30AD\u30FC\u306E\u30C9\u30B9",
      "screen_name" : "maidskii",
      "protected" : false,
      "id_str" : "101190268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605038848502923265\/wopKWa1p_normal.png",
      "id" : 101190268,
      "verified" : false
    }
  },
  "id" : 128802588886958080,
  "created_at" : "2011-10-25 11:58:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128802344828796928",
  "text" : "RT @0_uda: \u3061\u306A\u307F\u306B\u4ECA\u65E5\u3082\u300C\u30EA\u30A2\u5145\u3063\u3066\u306E\u306F\u30EA\u30A2\u30EB\uFF08R\uFF09\u306B\u5145\u5B9F\u3057\u3066\u308B\u3063\u3066\u3044\u3046\u610F\u5473\u306A\u3093\u3067\u3059\u3088\u300D\u300C\u3067\u3082\u30EA\u30A2\u30EB\u306F\u30A2\u30A4\uFF08\u221A-1\uFF09\u304C\u306A\u3044\u304B\u3089\u30C0\u30E1\u300D\u300C2\u6B21\u5143\uFF08C\uFF09\u306A\u3089\u30A2\u30A4\u304C\u3042\u308B\u300D\u300C\u3057\u304B\u3082\u30A2\u30A4\u306B\u30A2\u30A4\u30B8\u30E7\u30A6\u3092\u305F\u3063\u3077\u308A\u304B\u3051\u308B\uFF08i^i\uFF09\u3068\u3061\u3083\u3093\u3068\u30EA\u30A2\u30EB\u306B\u306A\u308B\u3057\u306D\u300D\u307F\u305F\u3044\u306A\u4F1A\u8A71\u3092\u805E\u3044\u305F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128801979450400768",
    "text" : "\u3061\u306A\u307F\u306B\u4ECA\u65E5\u3082\u300C\u30EA\u30A2\u5145\u3063\u3066\u306E\u306F\u30EA\u30A2\u30EB\uFF08R\uFF09\u306B\u5145\u5B9F\u3057\u3066\u308B\u3063\u3066\u3044\u3046\u610F\u5473\u306A\u3093\u3067\u3059\u3088\u300D\u300C\u3067\u3082\u30EA\u30A2\u30EB\u306F\u30A2\u30A4\uFF08\u221A-1\uFF09\u304C\u306A\u3044\u304B\u3089\u30C0\u30E1\u300D\u300C2\u6B21\u5143\uFF08C\uFF09\u306A\u3089\u30A2\u30A4\u304C\u3042\u308B\u300D\u300C\u3057\u304B\u3082\u30A2\u30A4\u306B\u30A2\u30A4\u30B8\u30E7\u30A6\u3092\u305F\u3063\u3077\u308A\u304B\u3051\u308B\uFF08i^i\uFF09\u3068\u3061\u3083\u3093\u3068\u30EA\u30A2\u30EB\u306B\u306A\u308B\u3057\u306D\u300D\u307F\u305F\u3044\u306A\u4F1A\u8A71\u3092\u805E\u3044\u305F\u7A0B\u5EA6\u306B\u306F\u6570\u5B66\u7CFB\u3067\u3059\u3002 \/\u039E\/",
    "id" : 128801979450400768,
    "created_at" : "2011-10-25 11:55:59 +0000",
    "user" : {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "protected" : false,
      "id_str" : "184844182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547956554922614784\/ccU36n2B_normal.png",
      "id" : 184844182,
      "verified" : false
    }
  },
  "id" : 128802344828796928,
  "created_at" : "2011-10-25 11:57:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128712868903391232",
  "text" : "\u306F\u306E\u5B57\u306E\u304A\u304B\u3052\u3067\u30D5\u30A9\u30ED\u30EF\u30FC\u5897\u3048\u308B",
  "id" : 128712868903391232,
  "created_at" : "2011-10-25 06:01:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "0. 3",
      "screen_name" : "Reiten_san",
      "indices" : [ 3, 14 ],
      "id_str" : "1003592594",
      "id" : 1003592594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128712114725584897",
  "text" : "RT @Reiten_san: \u6771\u5DE5\u5927\u3067\u3088\u304F\u898B\u304B\u3051\u308B\u30C1\u30A7\u30C3\u30AF\u67C4\u306E\u5B66\u751F\u306F\u3010\u30C7\u30AB\u30EB\u30C8\u5EA7\u6A19\u306E\u795E\u3011\u3078\u306E\u656C\u610F\u3092\u8868\u3057\u3066\u3044\u308B\u3082\u306E\u305F\u3061\u3067\u3042\u308B\u3002\u306A\u304A\u3001\u30A2\u30FC\u30AC\u30A4\u30EB\u67C4\u306F\u3010\u659C\u4EA4\u5EA7\u6A19\u306E\u795E\u3011\u3092\u4FE1\u4EF0\u3059\u308B\u4E00\u6D3E\u3067\u3042\u308B\u304C\u3001\u7570\u7AEF\u5150\u6271\u3044\u3055\u308C\u3066\u3044\u308B\u3002\u3053\u306E\u3088\u3046\u306B\u3010\u5EA7\u6A19\u7CFB\u4FE1\u4EF0\u3011\u3092\u670D\u88C5\u3067\u8868\u73FE\u3057\u3001\u795E\u3078\u306E\u656C\u610F\u3092\u793A\u3059\u3053\u3068\u304C\u6771 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128700072450990080",
    "text" : "\u6771\u5DE5\u5927\u3067\u3088\u304F\u898B\u304B\u3051\u308B\u30C1\u30A7\u30C3\u30AF\u67C4\u306E\u5B66\u751F\u306F\u3010\u30C7\u30AB\u30EB\u30C8\u5EA7\u6A19\u306E\u795E\u3011\u3078\u306E\u656C\u610F\u3092\u8868\u3057\u3066\u3044\u308B\u3082\u306E\u305F\u3061\u3067\u3042\u308B\u3002\u306A\u304A\u3001\u30A2\u30FC\u30AC\u30A4\u30EB\u67C4\u306F\u3010\u659C\u4EA4\u5EA7\u6A19\u306E\u795E\u3011\u3092\u4FE1\u4EF0\u3059\u308B\u4E00\u6D3E\u3067\u3042\u308B\u304C\u3001\u7570\u7AEF\u5150\u6271\u3044\u3055\u308C\u3066\u3044\u308B\u3002\u3053\u306E\u3088\u3046\u306B\u3010\u5EA7\u6A19\u7CFB\u4FE1\u4EF0\u3011\u3092\u670D\u88C5\u3067\u8868\u73FE\u3057\u3001\u795E\u3078\u306E\u656C\u610F\u3092\u793A\u3059\u3053\u3068\u304C\u6771\u5DE5\u5927\u3067\u306E\u6697\u9ED9\u306E\u30D5\u30A1\u30C3\u30B7\u30E7\u30F3\u3068\u306A\u3063\u3066\u3044\u308B\u3002",
    "id" : 128700072450990080,
    "created_at" : "2011-10-25 05:11:03 +0000",
    "user" : {
      "name" : "\u308C\u3044\u3066\u3093\u3055\u3093",
      "screen_name" : "Reitensan",
      "protected" : false,
      "id_str" : "117398530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2421334918\/ow9fado3latjhnjdj3x9_normal.jpeg",
      "id" : 117398530,
      "verified" : false
    }
  },
  "id" : 128712114725584897,
  "created_at" : "2011-10-25 05:58:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 24, 31 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 60, 67 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "\u5E73\u5C71\u2601",
      "screen_name" : "H_Hirayama",
      "indices" : [ 77, 88 ],
      "id_str" : "121496430",
      "id" : 121496430
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 102, 109 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "Genki",
      "screen_name" : "gnkm",
      "indices" : [ 122, 127 ],
      "id_str" : "75457315",
      "id" : 75457315
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30BF\u30A4\u30C8\u30EB\u3092\u5426\u5B9A\u5F62\u306B\u3059\u308B\u3068\u5207\u306A\u304F\u306A\u308B",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128676654775140352",
  "text" : "RT @sugiyama1990: \u7A7A\u624B\u8E0A\u3089\u306A\u3044@tenapi:\u7D20\u30A4\u30C7\u306A\u3044 RT @38valleys:\u305B\u305A\u3046\u8AD6 RT @tenapi:\u30AC\u30ED\u306A\u3057\u8AD6 RT @H_Hirayama:\u3079\u3063\u305B\u3089\u306A\u3044\u95A2\u6570 RT: @tenapi:\u3079\u304F\u3068\u3089\u306A\u3044\u7A7A\u9593 RT @gnkm:\u3044\u306A\u3055\u305D\u3046\u7A7A\u9593  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "api",
        "screen_name" : "TenApi",
        "indices" : [ 6, 13 ],
        "id_str" : "3240677334",
        "id" : 3240677334
      }, {
        "name" : "api",
        "screen_name" : "TenApi",
        "indices" : [ 42, 49 ],
        "id_str" : "3240677334",
        "id" : 3240677334
      }, {
        "name" : "\u5E73\u5C71\u2601",
        "screen_name" : "H_Hirayama",
        "indices" : [ 59, 70 ],
        "id_str" : "121496430",
        "id" : 121496430
      }, {
        "name" : "api",
        "screen_name" : "TenApi",
        "indices" : [ 84, 91 ],
        "id_str" : "3240677334",
        "id" : 3240677334
      }, {
        "name" : "Genki",
        "screen_name" : "gnkm",
        "indices" : [ 104, 109 ],
        "id_str" : "75457315",
        "id" : 75457315
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u30BF\u30A4\u30C8\u30EB\u3092\u5426\u5B9A\u5F62\u306B\u3059\u308B\u3068\u5207\u306A\u304F\u306A\u308B",
        "indices" : [ 118, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128674978743848961",
    "text" : "\u7A7A\u624B\u8E0A\u3089\u306A\u3044@tenapi:\u7D20\u30A4\u30C7\u306A\u3044 RT @38valleys:\u305B\u305A\u3046\u8AD6 RT @tenapi:\u30AC\u30ED\u306A\u3057\u8AD6 RT @H_Hirayama:\u3079\u3063\u305B\u3089\u306A\u3044\u95A2\u6570 RT: @tenapi:\u3079\u304F\u3068\u3089\u306A\u3044\u7A7A\u9593 RT @gnkm:\u3044\u306A\u3055\u305D\u3046\u7A7A\u9593 #\u30BF\u30A4\u30C8\u30EB\u3092\u5426\u5B9A\u5F62\u306B\u3059\u308B\u3068\u5207\u306A\u304F\u306A\u308B",
    "id" : 128674978743848961,
    "created_at" : "2011-10-25 03:31:20 +0000",
    "user" : {
      "name" : "\u3059\u304E\uFF20\u5168\u81EA\u52D5\u8AD6\u6587\u751F\u6210\u30DE\u30B7\u30FC\u30F3",
      "screen_name" : "sugi3_34",
      "protected" : false,
      "id_str" : "239811064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000759083368\/e85c8ef377b223436c38148680eb4e4a_normal.jpeg",
      "id" : 239811064,
      "verified" : false
    }
  },
  "id" : 128676654775140352,
  "created_at" : "2011-10-25 03:37:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128535441669488641",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 128535441669488641,
  "created_at" : "2011-10-24 18:16:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128535237377523713",
  "text" : "\u306B\u305B\u307B\u3053\u3093\u306A\u6642\u9593\u306B\u2026",
  "id" : 128535237377523713,
  "created_at" : "2011-10-24 18:16:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128525417924661248",
  "text" : "\u4ECA\u304B\u3089\u5E30\u5B85\u3059\u308B",
  "id" : 128525417924661248,
  "created_at" : "2011-10-24 17:37:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128491100662005760",
  "text" : "\uFF11\uFF10\u9650\u4EE3\u6570\n\uFF11\uFF11\u9650\u591A\u69D8\u4F53\u2190\u3044\u307E\u3053\u3053",
  "id" : 128491100662005760,
  "created_at" : "2011-10-24 15:20:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128397957107163137",
  "text" : "\u5168\u304F\u9593\u306B\u5408\u3063\u3066\u306A\u3044\u3057\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 128397957107163137,
  "created_at" : "2011-10-24 09:10:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128397849091244032",
  "text" : "\u9593\u306B\u5408\u3063\u305F\u304B\u3057\u3089",
  "id" : 128397849091244032,
  "created_at" : "2011-10-24 09:10:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128397795462873089",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 128397795462873089,
  "created_at" : "2011-10-24 09:09:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/MmWJoonM",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=tohru1101",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128303335680901120",
  "text" : "tohru1101\u3055\u3093\u304C\u3001\u79C1\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/MmWJoonM",
  "id" : 128303335680901120,
  "created_at" : "2011-10-24 02:54:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128246331104968704",
  "text" : "\u8179\u75DB\u3068\u7720\u6C17\u3068\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002",
  "id" : 128246331104968704,
  "created_at" : "2011-10-23 23:08:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128149732345380864",
  "geo" : { },
  "id_str" : "128149984196575232",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6700\u5F8C\u300C\u4ECA\u8DF3\u306D\u305F\u3044\u300D\u3060\u3063\u305F\u3089\u9762\u767D\u304B\u3063\u305F\u306E\u306B\u3002",
  "id" : 128149984196575232,
  "in_reply_to_status_id" : 128149732345380864,
  "created_at" : "2011-10-23 16:45:11 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128149857243369472",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u30671\u9650\u9593\u306B\u5408\u3046\u306E\u304B\u77E5\u3089\u3093\u3051\u3069\u5BDD\u307E\u3059\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 128149857243369472,
  "created_at" : "2011-10-23 16:44:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128149655526703104",
  "text" : "\u8EE2\u5B66\u90E8\u3057\u305F\u3089\u4ECA\u3084\u3063\u3066\u308B\u8A9E\u5B66\u306E\u9762\u5012\u306A\u8AB2\u984C\u5168\u90E8\u7121\u8996\u3067\u304D\u308B\u3068\u8003\u3048\u308B\u3068\u3059\u3054\u304F\u9B45\u529B\u7684\u2190\n\u3044\u3084\u3001\u3061\u3083\u3093\u3068\u3084\u308B\u3051\u3069\u3055\uFF01",
  "id" : 128149655526703104,
  "created_at" : "2011-10-23 16:43:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128149429080436738",
  "text" : "\u3082\u3046\u3060\u3081\u3002\u4ECA\u9031\u524D\u534A\u306F\u81EA\u8EE2\u8ECA\u64CD\u696D\u3067\u4E57\u308A\u5207\u308B\u3057\u304B\u306A\u3044\u3063\u3002",
  "id" : 128149429080436738,
  "created_at" : "2011-10-23 16:42:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128137507341742080",
  "geo" : { },
  "id_str" : "128138293400449024",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u6B63\u78BA\u306B\u306F\u4E00\u67081\u30BF\u30FC\u30F3\u8A08\u7B97\u306799\u5E74\u3067\u3059\u306D\u3001\u3084\u3063\u305F\u3053\u3068\u306F\u306A\u3044\u3067\u3059\u304C\u3002",
  "id" : 128138293400449024,
  "in_reply_to_status_id" : 128137507341742080,
  "created_at" : "2011-10-23 15:58:44 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128136184017850368",
  "geo" : { },
  "id_str" : "128136816263053312",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u307E\u3041\u3048\u3052\u3064\u306A\u3044\u3059\u3054\u308D\u304F\u307F\u305F\u3044\u306A\u3082\u306E\u3067\u3059\u306D\uFF57",
  "id" : 128136816263053312,
  "in_reply_to_status_id" : 128136184017850368,
  "created_at" : "2011-10-23 15:52:52 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128134983540932608",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u30B7\u30E3\u30EF\u30FC\u3002",
  "id" : 128134983540932608,
  "created_at" : "2011-10-23 15:45:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128134887378141184",
  "text" : "\u9EBB\u96C0\u2192\u6843\u9244\u2192\u30DD\u30FC\u30AB\u30FC\u3068\u304B\u6628\u65E5\u4E00\u65E5\u904B\u306E\u8981\u7D20\u306E\u5927\u304D\u3044\u30B2\u30FC\u30E0\u3057\u304B\u3084\u3063\u3066\u306A\u3044\uFF57\uFF57\uFF57\uFF57",
  "id" : 128134887378141184,
  "created_at" : "2011-10-23 15:45:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128134663494582272",
  "text" : "\u3055\u3041\u4ECA\u304B\u3089\u30B7\u30E3\u30EF\u30FC\u3092\u6D74\u3073\u30665\u9650\u306E\u8AB2\u984C\u3092\u30BF\u30A4\u30E0\u30A2\u30BF\u30C3\u30AF\u3059\u308B\u30D7\u30EC\u30A4\u30F3\u30B0\u304C\u59CB\u307E\u308B\u3002",
  "id" : 128134663494582272,
  "created_at" : "2011-10-23 15:44:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128078295593005057",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 128078295593005057,
  "created_at" : "2011-10-23 12:00:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127950668328730625",
  "text" : "\u4E8C\u5EA6\u5BDD\u3057\u3066\u4E00\u5EA6\u76EE\u306B\u898B\u305F\u5922\u306E\u5185\u5BB9\u3092\u4E8C\u5EA6\u76EE\u306E\u5922\u3067\u558B\u3063\u3066\u305F\uFF57",
  "id" : 127950668328730625,
  "created_at" : "2011-10-23 03:33:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u624B\u52D5\u4EBA\u5F62",
      "screen_name" : "Manualmaton",
      "indices" : [ 3, 15 ],
      "id_str" : "64014806",
      "id" : 64014806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127777528403341312",
  "text" : "RT @Manualmaton: \u30B7\u30FC\u30BF\u300C\u79C1\u3001\u4F55\u6545\u30D6\u30E9\u30C3\u30AF\u4F01\u696D\u304C\u6EC5\u3073\u305F\u306E\u304B\u304C\u3088\u304F\u308F\u304B\u308B\u2026\u3000\u30B4\u30F3\u30C9\u30A2\u306E\u8C37\u306E\u8A69\u306B\u3042\u308B\u3082\u306E\u3002\u300E\u52B4\u57FA\u306B\u6839\u3092\u4E0B\u308D\u3057\u3001\u5B9A\u6642\u3068\u5171\u306B\u5E30\u308D\u3046\u3002\u5BB6\u65CF\u3068\u5171\u306B\u98DF\u4E8B\u3092\u53D6\u308A\u3001\u3088\u308B\u3068\u5171\u306B\u5E03\u56E3\u3067\u7720\u308D\u3046\u300F \u6050\u308D\u3057\u3044\u30CE\u30EB\u30DE\u3067\u793E\u54E1\u3092\u7E1B\u3063\u3066\u3082\u3001\u304B\u308F\u3044\u305D\u3046\u306A\u6D3E\u9063\u3092\u3053\u304D\u4F7F\u3063\u3066\u3082\u3001\u4EBA\u306F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"erased_102559\" rel=\"nofollow\"\u003Eerased_102559\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127231810731118592",
    "text" : "\u30B7\u30FC\u30BF\u300C\u79C1\u3001\u4F55\u6545\u30D6\u30E9\u30C3\u30AF\u4F01\u696D\u304C\u6EC5\u3073\u305F\u306E\u304B\u304C\u3088\u304F\u308F\u304B\u308B\u2026\u3000\u30B4\u30F3\u30C9\u30A2\u306E\u8C37\u306E\u8A69\u306B\u3042\u308B\u3082\u306E\u3002\u300E\u52B4\u57FA\u306B\u6839\u3092\u4E0B\u308D\u3057\u3001\u5B9A\u6642\u3068\u5171\u306B\u5E30\u308D\u3046\u3002\u5BB6\u65CF\u3068\u5171\u306B\u98DF\u4E8B\u3092\u53D6\u308A\u3001\u3088\u308B\u3068\u5171\u306B\u5E03\u56E3\u3067\u7720\u308D\u3046\u300F \u6050\u308D\u3057\u3044\u30CE\u30EB\u30DE\u3067\u793E\u54E1\u3092\u7E1B\u3063\u3066\u3082\u3001\u304B\u308F\u3044\u305D\u3046\u306A\u6D3E\u9063\u3092\u3053\u304D\u4F7F\u3063\u3066\u3082\u3001\u4EBA\u306F\u4F11\u606F\u306A\u3057\u3067\u306F\u751F\u304D\u3089\u308C\u306A\u3044\u306E\u3088\uFF01\u300D",
    "id" : 127231810731118592,
    "created_at" : "2011-10-21 03:56:42 +0000",
    "user" : {
      "name" : "\u624B\u52D5\u4EBA\u5F62",
      "screen_name" : "Manualmaton",
      "protected" : false,
      "id_str" : "64014806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521164752328728576\/psQJF5hx_normal.png",
      "id" : 64014806,
      "verified" : false
    }
  },
  "id" : 127777528403341312,
  "created_at" : "2011-10-22 16:05:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127772919899230209",
  "text" : "\u3075\u3041\u307C\u306E\u30DC\u30BF\u30F3\u3068\u516C\u5F0FRT\u306E\u30DC\u30BF\u30F3\u9593\u9055\u3048\u305F\u2026",
  "id" : 127772919899230209,
  "created_at" : "2011-10-22 15:46:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127771310599319553",
  "text" : "\u3044\u306C\u306E\u7ACB\u3066\u305F\u90E8\u5C4B\u306B\u4EBA\u304C\u6848\u5916\u3044\u308B\uFF57",
  "id" : 127771310599319553,
  "created_at" : "2011-10-22 15:40:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    }, {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 10, 17 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127763718225412096",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa @rpdexp \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 127763718225412096,
  "created_at" : "2011-10-22 15:10:18 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u306E\u307F\u3093\u306A\u304C\u79C1\u306E\u5C02\u653B\u3092\u4F55\u3060\u3068\u601D\u3063\u3066\u3044\u308B\u304B\u6559\u3048\u3066\u304F\u308C\u308B",
      "indices" : [ 9, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127744486460755968",
  "text" : "\u3053\u308C\u306F\u5371\u967A\u306A\u554F\u3044\u3000#\u30D5\u30A9\u30ED\u30EF\u30FC\u306E\u307F\u3093\u306A\u304C\u79C1\u306E\u5C02\u653B\u3092\u4F55\u3060\u3068\u601D\u3063\u3066\u3044\u308B\u304B\u6559\u3048\u3066\u304F\u308C\u308B",
  "id" : 127744486460755968,
  "created_at" : "2011-10-22 13:53:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127738275304710145",
  "text" : "\u3066\u304B\u4ED6\u4EBA\u306E\u643A\u5E2F\u304C\u9707\u3048\u305F\u6642\u306B\u904E\u5270\u306B\u3073\u3063\u304F\u308A\u3059\u308B\u3093\u3060\u3088\u306A\u30FC",
  "id" : 127738275304710145,
  "created_at" : "2011-10-22 13:29:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127737648491139073",
  "text" : "\u30E1\u30FC\u30EB\u3058\u3083\u9CF4\u3089\u306A\u3044\u304B\u3089\u53C2\u52A0\u3067\u304D\u3093\u2026",
  "id" : 127737648491139073,
  "created_at" : "2011-10-22 13:26:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u307F\u3093\u306A\u306E\u643A\u5E2F\u306E\u30E1\u30FC\u30EB\u7740\u4FE1\u97F3\u3092\u6652\u305D\u3046",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127737529557467136",
  "text" : "#\u307F\u3093\u306A\u306E\u643A\u5E2F\u306E\u30E1\u30FC\u30EB\u7740\u4FE1\u97F3\u3092\u6652\u305D\u3046",
  "id" : 127737529557467136,
  "created_at" : "2011-10-22 13:26:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127715998576021504",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 127715998576021504,
  "created_at" : "2011-10-22 12:00:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127678417637343232",
  "text" : "\u30D5\u30A9\u30FC\u30B9\u30AF\u30A8\u30A2\u30FC\u3063\u3066\u7D50\u5C40\u3069\u3046\u3084\u3063\u3066\u4F7F\u3046\u306E\u304B\u3088\u304F\u308F\u304B\u3089\u306A\u3044\u3093\u3060\u3051\u308C\u3069",
  "id" : 127678417637343232,
  "created_at" : "2011-10-22 09:31:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127666184186376192",
  "text" : "\u65E5\u5E38\u3092\u3072\u305F\u3059\u3089\uFF47\u3067\u5FAE\u5206\u3057\u3066\u3044\u308B\u3088\u3046\u306A\u2026\u3002",
  "id" : 127666184186376192,
  "created_at" : "2011-10-22 08:42:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127646398123483136",
  "text" : "\u96E8\u3082\u306E\u51C4\u3044\u3093\u3067\u3059\u3051\u308C\u3069",
  "id" : 127646398123483136,
  "created_at" : "2011-10-22 07:24:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/JTQZKeh0",
      "expanded_url" : "http:\/\/togetter.com\/li\/115602",
      "display_url" : "togetter.com\/li\/115602"
    } ]
  },
  "geo" : { },
  "id_str" : "127645476022517760",
  "text" : "\u898B\u3064\u3051\u3066\u5439\u3044\u305F\u3000\u7406\u4E0D\u5C3D\u306B\u305B\u307B http:\/\/t.co\/JTQZKeh0",
  "id" : 127645476022517760,
  "created_at" : "2011-10-22 07:20:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127427866337087489",
  "text" : "\u77F3\u4E38\u5C0F\u5504\u3068\u97F3\u3060\u3051\u306A\u3089\u4E8C\u6587\u5B57\u9055\u3044\u3068\u6C17\u4ED8\u3044\u305F\u885D\u6483\u3002\u5341\u5168\u3067\u3059\u308F\u3002",
  "id" : 127427866337087489,
  "created_at" : "2011-10-21 16:55:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127247736331436032",
  "text" : "10\u4E07\u4EE5\u4E0A\u884C\u304F\u3093\u3060\u3082\u3093\u306A\u3002\u6687\u306A\u6642\u306B\u8003\u3048\u3088\u3063\u3068\u3002",
  "id" : 127247736331436032,
  "created_at" : "2011-10-21 04:59:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127247098096795648",
  "text" : "\u30D1\u30C3\u3068\u601D\u3044\u3064\u304F\u9650\u308A\u3067(1.9+2.0)\u00F7\uFF3B(-1.1+1.2)\u00D7(-1.3+1.4)\u00D7(-1.5+1.6)\u00D7(-1.7+1.8)\uFF3D\n3.9\/(0.1)^4\u3060\u304B\u3089\n3.9\u00D710^4\uFF1D39000\u3063\u3066\u3068\u3053\u308D\u304B\u306A\u30FC\u3002\u3082\u3046\u3061\u3087\u3044\u5927\u304D\u304F\u306A\u308B\uFF1F",
  "id" : 127247098096795648,
  "created_at" : "2011-10-21 04:57:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sylph01",
      "screen_name" : "s01",
      "indices" : [ 3, 7 ],
      "id_str" : "5708182",
      "id" : 5708182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127244510584520704",
  "text" : "RT @s01: \u300C1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0\u306E10\u500B\u3068 + - \u00D7 \u00F7 ( )\u3092\u4F7F\u3063\u3066\u5927\u304D\u3044\u6570\u3092\u4F5C\u308C\u300D\u3068\u3044\u3046\u554F\u984C\u300210\u4E07\u4EE5\u4E0A\u304B\u3089\u300C\u3061\u3087\u3063\u3068\u8CE2\u3044\u300D\u30E9\u30A4\u30F3\u3060\u305D\u3046\u3060\u3051\u30691\u4E07\u3082\u53B3\u3057\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "21375206236",
    "text" : "\u300C1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0\u306E10\u500B\u3068 + - \u00D7 \u00F7 ( )\u3092\u4F7F\u3063\u3066\u5927\u304D\u3044\u6570\u3092\u4F5C\u308C\u300D\u3068\u3044\u3046\u554F\u984C\u300210\u4E07\u4EE5\u4E0A\u304B\u3089\u300C\u3061\u3087\u3063\u3068\u8CE2\u3044\u300D\u30E9\u30A4\u30F3\u3060\u305D\u3046\u3060\u3051\u30691\u4E07\u3082\u53B3\u3057\u3044",
    "id" : 21375206236,
    "created_at" : "2010-08-17 04:31:55 +0000",
    "user" : {
      "name" : "sylph01",
      "screen_name" : "s01",
      "protected" : false,
      "id_str" : "5708182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514076121801822208\/kyzdHHy7_normal.png",
      "id" : 5708182,
      "verified" : false
    }
  },
  "id" : 127244510584520704,
  "created_at" : "2011-10-21 04:47:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127240463261515776",
  "text" : "RT @kussytessy: \u3059\u3054\u3044\u52E2\u3044\u3067\u5897\u3048\u3066\u3044\u304Fwwww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127238832767774720",
    "text" : "\u3059\u3054\u3044\u52E2\u3044\u3067\u5897\u3048\u3066\u3044\u304Fwwww",
    "id" : 127238832767774720,
    "created_at" : "2011-10-21 04:24:36 +0000",
    "user" : {
      "name" : "DEAD END",
      "screen_name" : "7ksts",
      "protected" : false,
      "id_str" : "96237218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593483929\/091227_0015_0001_normal.jpg",
      "id" : 96237218,
      "verified" : false
    }
  },
  "id" : 127240463261515776,
  "created_at" : "2011-10-21 04:31:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127240437420396544",
  "text" : "RT @kussytessy: \u5642\u306E\u5F7C\u6C0F\u3055\u3093\u3001\u30D5\u30A9\u30ED\u30FC1\u306B\u5BFE\u3057\u3066\u30D5\u30A9\u30ED\u30EF\u30FC\u304C150\u4EBA\u304F\u3089\u3044\u3044\u308Bww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127238674734784512",
    "text" : "\u5642\u306E\u5F7C\u6C0F\u3055\u3093\u3001\u30D5\u30A9\u30ED\u30FC1\u306B\u5BFE\u3057\u3066\u30D5\u30A9\u30ED\u30EF\u30FC\u304C150\u4EBA\u304F\u3089\u3044\u3044\u308Bww",
    "id" : 127238674734784512,
    "created_at" : "2011-10-21 04:23:58 +0000",
    "user" : {
      "name" : "DEAD END",
      "screen_name" : "7ksts",
      "protected" : false,
      "id_str" : "96237218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593483929\/091227_0015_0001_normal.jpg",
      "id" : 96237218,
      "verified" : false
    }
  },
  "id" : 127240437420396544,
  "created_at" : "2011-10-21 04:30:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5948\u3005\u3000",
      "screen_name" : "airarairai",
      "indices" : [ 35, 46 ],
      "id_str" : "184067568",
      "id" : 184067568
    }, {
      "name" : "\u307F\u306A\u307F \u3053\u3044",
      "screen_name" : "c_oi",
      "indices" : [ 48, 53 ],
      "id_str" : "292975099",
      "id" : 292975099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127237027614830592",
  "text" : "RT @kussytessy: \u6D41\u77F3\u306B\u30CD\u30BF\u3060\u3088\u306A\u2026\u2026\u9762\u767D\u3059\u304E\u308B RT @airarairai: @c_oi \u3000\u79C1\u306E\u5F7C\u6C0F\u306B\u7D61\u307E\u306A\u3044\u3067\u304F\u3060\u3055\u3044\uDBBA\uDF57\u30D5\u30A9\u30ED\u30FC\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u81F3\u6025\u306B\u30D6\u30ED\u30C3\u30AF\u304B\u3051\u3066\u304F\u3060\u3055\u3044\uDBBA\uDF57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5948\u3005\u3000",
        "screen_name" : "airarairai",
        "indices" : [ 19, 30 ],
        "id_str" : "184067568",
        "id" : 184067568
      }, {
        "name" : "\u307F\u306A\u307F \u3053\u3044",
        "screen_name" : "c_oi",
        "indices" : [ 32, 37 ],
        "id_str" : "292975099",
        "id" : 292975099
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127235816803155968",
    "text" : "\u6D41\u77F3\u306B\u30CD\u30BF\u3060\u3088\u306A\u2026\u2026\u9762\u767D\u3059\u304E\u308B RT @airarairai: @c_oi \u3000\u79C1\u306E\u5F7C\u6C0F\u306B\u7D61\u307E\u306A\u3044\u3067\u304F\u3060\u3055\u3044\uDBBA\uDF57\u30D5\u30A9\u30ED\u30FC\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u81F3\u6025\u306B\u30D6\u30ED\u30C3\u30AF\u304B\u3051\u3066\u304F\u3060\u3055\u3044\uDBBA\uDF57",
    "id" : 127235816803155968,
    "created_at" : "2011-10-21 04:12:37 +0000",
    "user" : {
      "name" : "DEAD END",
      "screen_name" : "7ksts",
      "protected" : false,
      "id_str" : "96237218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593483929\/091227_0015_0001_normal.jpg",
      "id" : 96237218,
      "verified" : false
    }
  },
  "id" : 127237027614830592,
  "created_at" : "2011-10-21 04:17:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3071\u308D\u3059\u3051",
      "screen_name" : "parosky1",
      "indices" : [ 3, 12 ],
      "id_str" : "255779484",
      "id" : 255779484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127236170538156032",
  "text" : "RT @parosky1: \u300C\u30CD\u30C3\u30C8\u30D3\u30B8\u30CD\u30B9\u9053\u5834\u306F\u3058\u3081\u307E\u3057\u305F\u3002\u4FA1\u5024\u89B3\u304C\u540C\u3058\u306A\u3089\u305C\u3072\u53C2\u52A0\u3057\u3066\u304F\u3060\u3055\u3044\u306D\u3002\u300D\u3063\u3066\u30E1\u30C3\u30BB\u30FC\u30B8\u304C\u5C4A\u3044\u305F\u3093\u3060\u3051\u3069\u300C\u4FA1\u5024\u89B3\u304C\u540C\u3058\u300D\u3063\u3066\u3082\u306E\u3059\u3063\u3054\u304F\u53B3\u3057\u3044\u6761\u4EF6\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u3002\u305D\u3046\u601D\u3046\u6642\u70B9\u3067\u4FA1\u5024\u89B3\u9055\u3046\u3063\u3066\u3053\u3068\u3067\u3059\u304B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\" rel=\"nofollow\"\u003Eparosky-app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127235654064152577",
    "text" : "\u300C\u30CD\u30C3\u30C8\u30D3\u30B8\u30CD\u30B9\u9053\u5834\u306F\u3058\u3081\u307E\u3057\u305F\u3002\u4FA1\u5024\u89B3\u304C\u540C\u3058\u306A\u3089\u305C\u3072\u53C2\u52A0\u3057\u3066\u304F\u3060\u3055\u3044\u306D\u3002\u300D\u3063\u3066\u30E1\u30C3\u30BB\u30FC\u30B8\u304C\u5C4A\u3044\u305F\u3093\u3060\u3051\u3069\u300C\u4FA1\u5024\u89B3\u304C\u540C\u3058\u300D\u3063\u3066\u3082\u306E\u3059\u3063\u3054\u304F\u53B3\u3057\u3044\u6761\u4EF6\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u3002\u305D\u3046\u601D\u3046\u6642\u70B9\u3067\u4FA1\u5024\u89B3\u9055\u3046\u3063\u3066\u3053\u3068\u3067\u3059\u304B\u3002",
    "id" : 127235654064152577,
    "created_at" : "2011-10-21 04:11:58 +0000",
    "user" : {
      "name" : "\u3071\u308D\u3059\u3051",
      "screen_name" : "parosky1",
      "protected" : false,
      "id_str" : "255779484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1250985074\/ys_normal.png",
      "id" : 255779484,
      "verified" : false
    }
  },
  "id" : 127236170538156032,
  "created_at" : "2011-10-21 04:14:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127188653909868544",
  "text" : "\u7406\u5B66\u90E8\u56F3\u66F8\u9928\u306E\u6642\u8A08\u300110\u79D2\u306B\u4E00\u5EA6\u304F\u3089\u3044\u306E\u9593\u9694\u3067\u3001\u79D2\u91DD\u304C\uFF76\uFF81\uFF76\uFF81\uFF76\uFF81\uFF76\uFF81\uFF76\uFF81\uFF76\uFF81\u3063\u3066\u307E\u3068\u3081\u3066\u52D5\u304F\u3093\u3060\u3051\u3069\u79D2\u91DD\u306E\u610F\u5473\u2026",
  "id" : 127188653909868544,
  "created_at" : "2011-10-21 01:05:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127181577808654336",
  "text" : "\u30CB\u30E5\u30FC\u30C8\u30EA\u30CE\u304C\u6E1B\u901F\u3057\u305F\u308F\u3051\u3058\u3083\u306A\u3044\u3088\u306A",
  "id" : 127181577808654336,
  "created_at" : "2011-10-21 00:37:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jinmensou",
      "screen_name" : "jinmensou",
      "indices" : [ 3, 13 ],
      "id_str" : "18717985",
      "id" : 18717985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2YErxvLv",
      "expanded_url" : "http:\/\/researchmap.jp\/jod7y7m3o-13620\/#_13620",
      "display_url" : "researchmap.jp\/jod7y7m3o-1362\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127181406836232192",
  "text" : "RT @jinmensou: \u3048\u3047\u30FC\u30FB\u30FB\u30FB\u3002 \u300COPERA\u5B9F\u9A13\u30C1\u30FC\u30E0\u306E\u89E3\u6790\u3067\u306F\u3001GPS\u3092\u7A4D\u3093\u3060\u885B\u661F\u306E\u904B\u52D5\u306E\u76F8\u5BFE\u8AD6\u7684\u52B9\u679C\u3092\u5165\u308C\u5FD8\u308C\u3066\u3044\u305F\u3089\u3057\u3044\u3002\u305D\u308C\u3092\u8003\u616E\u3059\u308B\u3068\u3001\u3061\u3087\u3046\u3069\uFF16\uFF14nsec\u3060\u3051\u30CB\u30E5\u30FC\u30C8\u30EA\u30CE\u304C\u9045\u304F\u5230\u7740\u3057\u3066\u308B\u52D8\u5B9A\u306B\u306A\u308B\u300D \u30CB\u30E5\u30FC\u30C8\u30EA\u30CE\u6E1B\u901F\u3059 http:\/\/t.co\/2 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/2YErxvLv",
        "expanded_url" : "http:\/\/researchmap.jp\/jod7y7m3o-13620\/#_13620",
        "display_url" : "researchmap.jp\/jod7y7m3o-1362\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "127042763685498880",
    "text" : "\u3048\u3047\u30FC\u30FB\u30FB\u30FB\u3002 \u300COPERA\u5B9F\u9A13\u30C1\u30FC\u30E0\u306E\u89E3\u6790\u3067\u306F\u3001GPS\u3092\u7A4D\u3093\u3060\u885B\u661F\u306E\u904B\u52D5\u306E\u76F8\u5BFE\u8AD6\u7684\u52B9\u679C\u3092\u5165\u308C\u5FD8\u308C\u3066\u3044\u305F\u3089\u3057\u3044\u3002\u305D\u308C\u3092\u8003\u616E\u3059\u308B\u3068\u3001\u3061\u3087\u3046\u3069\uFF16\uFF14nsec\u3060\u3051\u30CB\u30E5\u30FC\u30C8\u30EA\u30CE\u304C\u9045\u304F\u5230\u7740\u3057\u3066\u308B\u52D8\u5B9A\u306B\u306A\u308B\u300D \u30CB\u30E5\u30FC\u30C8\u30EA\u30CE\u6E1B\u901F\u3059 http:\/\/t.co\/2YErxvLv",
    "id" : 127042763685498880,
    "created_at" : "2011-10-20 15:25:29 +0000",
    "user" : {
      "name" : "jinmensou",
      "screen_name" : "jinmensou",
      "protected" : false,
      "id_str" : "18717985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1668023957\/ce17e7e3-e404-4d5c-b617-a741ac12bf6f_normal.jpg",
      "id" : 18717985,
      "verified" : false
    }
  },
  "id" : 127181406836232192,
  "created_at" : "2011-10-21 00:36:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127180652276756480",
  "text" : "@ayu167 \u304A\u306F\u3088\u3046",
  "id" : 127180652276756480,
  "created_at" : "2011-10-21 00:33:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C8\u30EA\u30D3\u5C4B",
      "screen_name" : "toribiabot",
      "indices" : [ 3, 14 ],
      "id_str" : "544951675",
      "id" : 544951675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127178593531994112",
  "text" : "RT @toribiabot: \u3000\u30C9\u30E9\u3048\u3082\u3093\u306E\u8EAB\u9577\u306F\uFF11\uFF12\uFF19\uFF0E\uFF13\uFF43\uFF4D\u3001\u30B9\u30EA\u30FC\u30B5\u30A4\u30BA\u3082\u5168\u3066\uFF11\uFF12\uFF19\uFF0E\uFF13\uFF43\uFF4D\u3067\u3001\u4F53\u91CD\u3082\uFF11\uFF12\uFF19\uFF0E\uFF13\uFF4B\uFF47\u3068\u3044\u3046\u4F53\u578B\u3060\u304C\u3001\u6700\u9AD8\u901F\u5EA6\u306F\u6642\u901F\uFF11\uFF12\uFF19\uFF0E\uFF13km\/h\u3068\u610F\u5916\u306B\u4FCA\u8DB3\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127177126251208704",
    "text" : "\u3000\u30C9\u30E9\u3048\u3082\u3093\u306E\u8EAB\u9577\u306F\uFF11\uFF12\uFF19\uFF0E\uFF13\uFF43\uFF4D\u3001\u30B9\u30EA\u30FC\u30B5\u30A4\u30BA\u3082\u5168\u3066\uFF11\uFF12\uFF19\uFF0E\uFF13\uFF43\uFF4D\u3067\u3001\u4F53\u91CD\u3082\uFF11\uFF12\uFF19\uFF0E\uFF13\uFF4B\uFF47\u3068\u3044\u3046\u4F53\u578B\u3060\u304C\u3001\u6700\u9AD8\u901F\u5EA6\u306F\u6642\u901F\uFF11\uFF12\uFF19\uFF0E\uFF13km\/h\u3068\u610F\u5916\u306B\u4FCA\u8DB3\u3002",
    "id" : 127177126251208704,
    "created_at" : "2011-10-21 00:19:24 +0000",
    "user" : {
      "name" : "\u51CD\u7D50\u89E3\u9664\u3055\u308C\u305F\u30C8\u30EA\u30D3\u30A2\u57A2",
      "screen_name" : "toribiaaka",
      "protected" : false,
      "id_str" : "310569105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488327075078492160\/uLsZPB_c_normal.jpeg",
      "id" : 310569105,
      "verified" : false
    }
  },
  "id" : 127178593531994112,
  "created_at" : "2011-10-21 00:25:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127171894129598464",
  "text" : "\u56F3\u66F8\u9928\uFF19\u6642\u304B\u3089\u306A\u3089\u6388\u696D\u3082\uFF19\u6642\u304B\u3089\u306B\u3057\u3066\u6B32\u3057\u3044\u306A",
  "id" : 127171894129598464,
  "created_at" : "2011-10-20 23:58:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127171698867965952",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u56F3\u66F8\u9928\u3042\u304F\u307E\u3067\u3042\u304F\u307E\u3067\u5F85\u6A5F",
  "id" : 127171698867965952,
  "created_at" : "2011-10-20 23:57:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127169633282293760",
  "text" : "\u4F11\u8B1B\u304B\u3088\n\u4ECA\u9031\u4E8C\u5EA6\u76EE\u3068\u304B\u2026orz",
  "id" : 127169633282293760,
  "created_at" : "2011-10-20 23:49:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30F4\u30A1\u30A4\u541B",
      "screen_name" : "Vaisya46",
      "indices" : [ 3, 12 ],
      "id_str" : "131120799",
      "id" : 131120799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127169110328094720",
  "text" : "RT @Vaisya46: \u30B5\u30F3\u30BF\u30AF\u30ED\u30FC\u30B9\u300C\u30E1\u30EA\u30FC\u30AF\u30EA\u30B9\u30DE\u30B9\uFF01\uFF01\u725B\u30ED\u30FC\u30B9\u306B\u3059\u308B\uFF1F\u8C5A\u30ED\u30FC\u30B9\u306B\u3059\u308B\uFF1F\u305D\u308C\u3068\u3082\u2026\u7F8A\u30ED\u30FC\u30B9\uFF1F\u300D\n\n\u5B50\u4F9B\u300C\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\uFF1F\u300D\n\n\u30B5\u30F3\u30BF\u30AF\u30ED\u30FC\u30B9\u300C\u4E09\u629E\u30ED\u30FC\u30B9\u3060\u3088\u7B11\u3048\u3088\u30AF\u30BD\u30AC\u30AD\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94373975399997441",
    "text" : "\u30B5\u30F3\u30BF\u30AF\u30ED\u30FC\u30B9\u300C\u30E1\u30EA\u30FC\u30AF\u30EA\u30B9\u30DE\u30B9\uFF01\uFF01\u725B\u30ED\u30FC\u30B9\u306B\u3059\u308B\uFF1F\u8C5A\u30ED\u30FC\u30B9\u306B\u3059\u308B\uFF1F\u305D\u308C\u3068\u3082\u2026\u7F8A\u30ED\u30FC\u30B9\uFF1F\u300D\n\n\u5B50\u4F9B\u300C\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\u30FB\uFF1F\u300D\n\n\u30B5\u30F3\u30BF\u30AF\u30ED\u30FC\u30B9\u300C\u4E09\u629E\u30ED\u30FC\u30B9\u3060\u3088\u7B11\u3048\u3088\u30AF\u30BD\u30AC\u30AD\u300D",
    "id" : 94373975399997441,
    "created_at" : "2011-07-22 11:51:23 +0000",
    "user" : {
      "name" : "\u30F4\u30A1\u30A4\u541B",
      "screen_name" : "Vaisya46",
      "protected" : false,
      "id_str" : "131120799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587620185474932737\/HkrsWqzF_normal.jpg",
      "id" : 131120799,
      "verified" : false
    }
  },
  "id" : 127169110328094720,
  "created_at" : "2011-10-20 23:47:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127155643382636545",
  "text" : "\u76F8\u99AC\u3055\u3093\u3068\u6771\u4EAC\u884C\u304D\u304C\u88AB\u3063\u305F\uFF57\uFF57\uFF57",
  "id" : 127155643382636545,
  "created_at" : "2011-10-20 22:54:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/mqBN4oSd",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=Harayamada",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127143923280904193",
  "text" : "Harayamada\u304C\u3001\u79C1\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/mqBN4oSd",
  "id" : 127143923280904193,
  "created_at" : "2011-10-20 22:07:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127032453289349120",
  "text" : "\u3055\u3041\u5BDD\u3088\u3046\u3002\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 127032453289349120,
  "created_at" : "2011-10-20 14:44:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 3, 10 ],
      "id_str" : "93311525",
      "id" : 93311525
    }, {
      "name" : "mana",
      "screen_name" : "e_eusa",
      "indices" : [ 22, 29 ],
      "id_str" : "154906716",
      "id" : 154906716
    }, {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "indices" : [ 31, 38 ],
      "id_str" : "93311525",
      "id" : 93311525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127032155476996096",
  "text" : "RT @NHK_PR: \u30D7\u30EA\u30AD\u30E5\u30A2\u3002 RT @e_eusa: @NHK_PR _PR\u306E\u90E8\u5206\u306F\u306A\u3093\u3068\u3044\u3046\u7565\u3067\u3059\u304B\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "mana",
        "screen_name" : "e_eusa",
        "indices" : [ 10, 17 ],
        "id_str" : "154906716",
        "id" : 154906716
      }, {
        "name" : "NHK\u5E83\u5831\u5C40",
        "screen_name" : "NHK_PR",
        "indices" : [ 19, 26 ],
        "id_str" : "93311525",
        "id" : 93311525
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127032092713426944",
    "text" : "\u30D7\u30EA\u30AD\u30E5\u30A2\u3002 RT @e_eusa: @NHK_PR _PR\u306E\u90E8\u5206\u306F\u306A\u3093\u3068\u3044\u3046\u7565\u3067\u3059\u304B\uFF1F",
    "id" : 127032092713426944,
    "created_at" : "2011-10-20 14:43:05 +0000",
    "user" : {
      "name" : "NHK\u5E83\u5831\u5C40",
      "screen_name" : "NHK_PR",
      "protected" : false,
      "id_str" : "93311525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598480953950908417\/uVnPVV0H_normal.jpg",
      "id" : 93311525,
      "verified" : true
    }
  },
  "id" : 127032155476996096,
  "created_at" : "2011-10-20 14:43:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u897F\u5C3E\u7DAD\u65B0\u98A8\u306B\u6570\u5B66\u3092\u8A9E\u308B\u3068\u622F\u8A00\u3060",
      "indices" : [ 69, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127030418758316033",
  "text" : "\u300C\u307C\u304F\u306F\u5618\u306F\u3064\u304F\u3051\u3069\u7D04\u675F\u306F\u7834\u3089\u306A\u3044\u3093\u3067\u3059\u300D\u300C\u3075\u3046\u3093\u2026\u2026\u305D\u308C\u3053\u305D\u3059\u3063\u3052\u30FC\u5618\u3063\u307D\u3044\u3051\u3069\u306A\u3002\u300A\u81F3\u308B\u3068\u3053\u308D\u3067\u9023\u7D9A\u3001\u305F\u3060\u3057\u5FAE\u5206\u4E0D\u53EF\u80FD\u300B\u307F\u305F\u3044\u306A\uFF1F\u300D #\u897F\u5C3E\u7DAD\u65B0\u98A8\u306B\u6570\u5B66\u3092\u8A9E\u308B\u3068\u622F\u8A00\u3060",
  "id" : 127030418758316033,
  "created_at" : "2011-10-20 14:36:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127028407744724993",
  "text" : "\u5B9F\u6226\u3067\u306F\u306A\u304B\u306A\u304B\u65E9\u304F\u7D44\u3081\u306A\u3044\u3067\u3059",
  "id" : 127028407744724993,
  "created_at" : "2011-10-20 14:28:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127028253255925760",
  "text" : "\u3077\u3088\u3077\u3088\u3082\u540C\u30EC\u30D9\u30EB\u306E\u4EBA\u3068\u5F53\u305F\u3063\u3066\u30EC\u30FC\u30C8\u304C\u539F\u70B9\u304F\u3089\u3044\u307E\u3067\u623B\u3063\u305F\u3002",
  "id" : 127028253255925760,
  "created_at" : "2011-10-20 14:27:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127027755702423553",
  "text" : "\u7406\u89E3\u3067\u304D\u305F\u611F\u6FC0\u304C\u4ED6\u304B\u3089\u898B\u305F\u3089\u4E9B\u7D30\u3067\u3082\u3044\u3044\u3058\u3083\u306A\u3044\u304B\u3001",
  "id" : 127027755702423553,
  "created_at" : "2011-10-20 14:25:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u539F\u2252\u306B\u305B\u7269\u7406\u5B66\u5F92",
      "screen_name" : "hhara_iwate",
      "indices" : [ 3, 15 ],
      "id_str" : "276105342",
      "id" : 276105342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127027583081644032",
  "text" : "RT @hhara_iwate: \u4EE5\u4E0A\u3001\u521D\u6B69\u7684\u306A\u4E8B\u306A\u306E\u306B\"\u7406\u89E3\u3067\u304D\u3066\u611F\u6FC0\u3057\u305F\u3088\"\u3068\u8A00\u3044\u305F\u304F\u3066\u30C4\u30A3\u30FC\u30C8\u3057\u307E\u3057\u305F\u3002\u3082\u3061\u308D\u3093\u5B66\u7FD2\u4E2D\u306E\u767A\u8A00\u306A\u306E\u3067\u9593\u9055\u3044\u52D8\u9055\u3044\u304C\u542B\u307E\u308C\u3066\u3044\u308B\u3053\u3068\u3082\u3042\u308A\u307E\u3059\u306E\u3067\u3001\u3042\u3057\u304B\u3089\u305A\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127027362763243520",
    "text" : "\u4EE5\u4E0A\u3001\u521D\u6B69\u7684\u306A\u4E8B\u306A\u306E\u306B\"\u7406\u89E3\u3067\u304D\u3066\u611F\u6FC0\u3057\u305F\u3088\"\u3068\u8A00\u3044\u305F\u304F\u3066\u30C4\u30A3\u30FC\u30C8\u3057\u307E\u3057\u305F\u3002\u3082\u3061\u308D\u3093\u5B66\u7FD2\u4E2D\u306E\u767A\u8A00\u306A\u306E\u3067\u9593\u9055\u3044\u52D8\u9055\u3044\u304C\u542B\u307E\u308C\u3066\u3044\u308B\u3053\u3068\u3082\u3042\u308A\u307E\u3059\u306E\u3067\u3001\u3042\u3057\u304B\u3089\u305A\u3002",
    "id" : 127027362763243520,
    "created_at" : "2011-10-20 14:24:17 +0000",
    "user" : {
      "name" : "\u539F\u2252\u306B\u305B\u7269\u7406\u5B66\u5F92",
      "screen_name" : "hhara_iwate",
      "protected" : false,
      "id_str" : "276105342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1300186277\/image_normal.jpg",
      "id" : 276105342,
      "verified" : false
    }
  },
  "id" : 127027583081644032,
  "created_at" : "2011-10-20 14:25:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E5\u30FC\u5B50\uFF08\u308Dbot\uFF09",
      "screen_name" : "DigitalCuko",
      "indices" : [ 0, 12 ],
      "id_str" : "180848288",
      "id" : 180848288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126998498712363009",
  "geo" : { },
  "id_str" : "126999916655546369",
  "in_reply_to_user_id" : 180848288,
  "text" : "@DigitalCuko \u6C17\u3092\u3064\u3051\u3066\u3082\u52DD\u3066\u306C",
  "id" : 126999916655546369,
  "in_reply_to_status_id" : 126998498712363009,
  "created_at" : "2011-10-20 12:35:14 +0000",
  "in_reply_to_screen_name" : "DigitalCuko",
  "in_reply_to_user_id_str" : "180848288",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126998286124056577",
  "text" : "\u643A\u5E2F\u304B\u3089\u898B\u3066\u308B",
  "id" : 126998286124056577,
  "created_at" : "2011-10-20 12:28:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126998197682962432",
  "text" : "\u3068\u3044\u3046\u308F\u3051\u3067\u30B7\u30E3\u30C3\u30C8\u30C0\u30A6\u30F3\uFF01",
  "id" : 126998197682962432,
  "created_at" : "2011-10-20 12:28:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126997937678065664",
  "text" : "\u982D\u56DE\u3089\u306A\u3044\u2026\u3077\u3088\u3077\u3088\u306B\u79FB\u308B\u304B\u306A\u3002\u6B8B\u3063\u305F30\u5206\u306F\u660E\u65E5\u306E\u4E00\u9650\u306B3\u500D\u306B\u62E1\u5927\u3057\u3066\u4F7F\u3046\u3053\u3068\u306B\u3057\u3088\u3046\u3002",
  "id" : 126997937678065664,
  "created_at" : "2011-10-20 12:27:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126992226042646528",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 126992226042646528,
  "created_at" : "2011-10-20 12:04:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126991680598585344",
  "geo" : { },
  "id_str" : "126992192651796480",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u304A\u3044\u3084\u3081\u308D\uFF57\uFF57\uFF57",
  "id" : 126992192651796480,
  "in_reply_to_status_id" : 126991680598585344,
  "created_at" : "2011-10-20 12:04:32 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 10, 21 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126991741277581312",
  "text" : "\u9006\u3082\u3042\u308B\u3042\u308B RT @haguruma20 \u611F\u899A\u7684\u306B\u306F\u7D0D\u5F97\u3057\u305F\u3051\u3069\u6570\u7406\u7684\u306B\u793A\u305B\u306A\u3044\u3042\u308B\u3042\u308B\u306A\u3046",
  "id" : 126991741277581312,
  "created_at" : "2011-10-20 12:02:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u308B\u3093 [\u6700\u7D42\u898F\u5236\u30A2\u30AB]",
      "screen_name" : "nisehorrrrrrrn",
      "indices" : [ 0, 15 ],
      "id_str" : "295218654",
      "id" : 295218654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126988897082290176",
  "geo" : { },
  "id_str" : "126989147398344704",
  "in_reply_to_user_id" : 295218654,
  "text" : "@nisehorrrrrrrn \u8AE6\u3081\u3093\u306A\u3088",
  "id" : 126989147398344704,
  "in_reply_to_status_id" : 126988897082290176,
  "created_at" : "2011-10-20 11:52:26 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrrrn",
  "in_reply_to_user_id_str" : "295218654",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u308B\u3093 [\u6700\u7D42\u898F\u5236\u30A2\u30AB]",
      "screen_name" : "nisehorrrrrrrn",
      "indices" : [ 0, 15 ],
      "id_str" : "295218654",
      "id" : 295218654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126988176085626881",
  "geo" : { },
  "id_str" : "126988698112892928",
  "in_reply_to_user_id" : 295218654,
  "text" : "@nisehorrrrrrrn \u884C\u3063\u3066\u3089",
  "id" : 126988698112892928,
  "in_reply_to_status_id" : 126988176085626881,
  "created_at" : "2011-10-20 11:50:39 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrrrn",
  "in_reply_to_user_id_str" : "295218654",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 27, 35 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126988306390061056",
  "text" : "\u6B21\u5143\u3092\u8D85\u3048\u305F\u5AC1\u7684\u306A\u610F\u5473\u306720\u5272\u4EE5\u4E0A\u306B\u306A\u308B\u3068\u4E88\u60F3 RT @i_horse \u305B\u3081\u3066\u3001\u914D\u308B\u524D\u306B\u7406\u5B66\u90E8\u751F\u306E\u4F55\u5272\u304C\u604B\u4EBA\u3044\u308B\u304B\u3092\u30A2\u30F3\u30B1\u30FC\u30C8\u8ABF\u67FB\u3059\u308B\u3079\u304D\u3002\u305D\u3057\u3066\u601D\u3044\u76F4\u305B\u3002\u3053\u3053\u306B\u914D\u3063\u3066\u3082\u914D\u308B\u3060\u3051\u30E0\u30C0\u3060\u3068",
  "id" : 126988306390061056,
  "created_at" : "2011-10-20 11:49:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126987617324638208",
  "geo" : { },
  "id_str" : "126987925866029057",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u6075\u6BD4\u5BFF\u306B\u7F8E\u5473\u3057\u3044\u30E9\u30FC\u30E1\u30F3\u5C4B\u3055\u3093\u304C\u3042\u3063\u3066\u306D",
  "id" : 126987925866029057,
  "in_reply_to_status_id" : 126987617324638208,
  "created_at" : "2011-10-20 11:47:35 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126986609957666816",
  "geo" : { },
  "id_str" : "126987419928113153",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u3069\u3053\u884C\u304F\u306E\uFF1F",
  "id" : 126987419928113153,
  "in_reply_to_status_id" : 126986609957666816,
  "created_at" : "2011-10-20 11:45:34 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3053\u308C\u3060\u3051\u3067\u4F55\u306E\u4F5C\u54C1\u304B\u5206\u304B\u3063\u305F\u3089\u516C\u5F0Frt",
      "indices" : [ 19, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126987028800868352",
  "text" : "\u6C34\u306E\u4E2D\u306B\u5165\u308B\u3068\u30C9\u30ED\u30C9\u30ED\u304C\u9045\u304F\u306A\u308B\u305E\uFF01\u3000#\u3053\u308C\u3060\u3051\u3067\u4F55\u306E\u4F5C\u54C1\u304B\u5206\u304B\u3063\u305F\u3089\u516C\u5F0Frt",
  "id" : 126987028800868352,
  "created_at" : "2011-10-20 11:44:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126986818162925568",
  "text" : "\u3066\u304B\uFF50\uFF44\uFF46\u5316\u3055\u308C\u3066\u308B\u306E\u304C\u65E2\u306B\u9762\u767D\u3044\u3093\u3060\u3051\u3069\uFF57\uFF57\uFF57\uFF57",
  "id" : 126986818162925568,
  "created_at" : "2011-10-20 11:43:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126985624581443584",
  "geo" : { },
  "id_str" : "126986304243240962",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u2026\u30CE\u30FC\u30AB\u30F3\uFF01\u30CE\u30FC\u30AB\u30F3\uFF01",
  "id" : 126986304243240962,
  "in_reply_to_status_id" : 126985624581443584,
  "created_at" : "2011-10-20 11:41:08 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/OvDgICic",
      "expanded_url" : "http:\/\/bit.ly\/nZJNZs",
      "display_url" : "bit.ly\/nZJNZs"
    } ]
  },
  "geo" : { },
  "id_str" : "126986144264097792",
  "text" : "\u8A71\u984C\u306B\u306F\u306A\u3063\u3066\u305F\u304B\u3089\u6C17\u306B\u306A\u3063\u3066\u305F\u3051\u3069\u2026\u3053\u308C\u304C\u65E2\u306B\u3042\u308B\u7A2E\u306E\u4EBA\u3005\u306B\u306F\u30D0\u30A4\u30AA\u30EC\u30F3\u30B9\u3060\u306A\u3041 RT \u5C65\u4FEE\u767B\u9332\u306E\u6642\u3001\u3053\u308C\u304C\u914D\u3089\u308C\u305F\u3002http:\/\/t.co\/OvDgICic",
  "id" : 126986144264097792,
  "created_at" : "2011-10-20 11:40:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126985128160411648",
  "geo" : { },
  "id_str" : "126985399456382977",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u30A2\u30FC\u30AF\u30A8\u30F3\u30B8\u30A7\u30EB\u306B\u3067\u3082\u805E\u3044\u3066\u304F\u308C",
  "id" : 126985399456382977,
  "in_reply_to_status_id" : 126985128160411648,
  "created_at" : "2011-10-20 11:37:33 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126984594116448256",
  "geo" : { },
  "id_str" : "126984967329816577",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u5927\u4E08\u592B\u3060\u3001\u554F\u984C\u306A\u3044\u3002",
  "id" : 126984967329816577,
  "in_reply_to_status_id" : 126984594116448256,
  "created_at" : "2011-10-20 11:35:50 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126984742078914560",
  "text" : "\u7E70\u308A\u8FD4\u3057\u8A00\u8449\u304C\u597D\u304D\u3002\u64EC\u97F3\u8A9E\u3068\u3044\u3046\u3079\u304D\uFF1F",
  "id" : 126984742078914560,
  "created_at" : "2011-10-20 11:34:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126984485672714240",
  "text" : "\u3050\u308B\u3050\u308B\u3050\u308B\u3050\u308B",
  "id" : 126984485672714240,
  "created_at" : "2011-10-20 11:33:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126982719254167552",
  "text" : "20:45\uFF5E22:00\u307E\u3067\u4EE3\u6570\u3084\u3063\u3066\u304B\u3089\u3077\u3088\u3077\u3088\u3084\u308D\u3046\u3002",
  "id" : 126982719254167552,
  "created_at" : "2011-10-20 11:26:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126982383508537345",
  "text" : "1\u6642\u9593\u304C\u77ED\u3044\u3002",
  "id" : 126982383508537345,
  "created_at" : "2011-10-20 11:25:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126981968108847104",
  "text" : "\u7403\u5F62\u2026\u3058\u3083\u306A\u304F\u3066\u4F11\u61A9\uFF01",
  "id" : 126981968108847104,
  "created_at" : "2011-10-20 11:23:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126970452781449216",
  "text" : "\u304F\u308D\u306D\u3063\u304B\u30FC\u306E\u3067\u308B\u305F",
  "id" : 126970452781449216,
  "created_at" : "2011-10-20 10:38:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126916545858379776",
  "text" : "\u4EE3\u6570\u306F\u306A\u3093\u3068\u304B\u7740\u3044\u3066\u884C\u3063\u3066\u308B\u3064\u3082\u308A\u3060\u304C\u591A\u69D8\u4F53\u304C\u3001\u304C\u3001\u304C",
  "id" : 126916545858379776,
  "created_at" : "2011-10-20 07:03:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126915412385480704",
  "text" : "\u30E4\u30B3\u30D3\u30A2\u30F3\u306E\u5B9A\u7FA9\u304C\u89E3\u3089\u305A\u3001\u52D8\u3067\u5C0E\u3044\u3066\u3042\u3063\u3066\u308B\u304B\u3089\u826F\u304F\u306A\u3044",
  "id" : 126915412385480704,
  "created_at" : "2011-10-20 06:59:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126914930560598016",
  "text" : "\u3084\u3063\u3071\u5FAE\u7A4D\u5F31\u3044\u3068\u30D9\u30AF\u30C8\u30EB\u89E3\u6790\u3082\u4ECA\u3072\u3068\u3064\u3060\u3088\u306A\u30FC",
  "id" : 126914930560598016,
  "created_at" : "2011-10-20 06:57:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126895735080878080",
  "text" : "\u6F14\u7FD2\u3060\u304C\u5E7E\u4F55\u306E\u30CE\u30FC\u30C8\u8CB8\u3057\u3063\u3071\u3060\u3063\u305F\u3002\n\u4ECA\u9031\u306F\u30AC\u30F3\u30B9\u30EB\u30FC\u304B\u306A\u3002",
  "id" : 126895735080878080,
  "created_at" : "2011-10-20 05:41:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126893753129635840",
  "text" : "\u3042\u3001\u4ECA\u65E5\u306F\u5B66\u90E8\u306B\u884C\u304B\u306A\u3044\u65E5\u306B\u306A\u3063\u3061\u3083\u3063\u305F\u3002",
  "id" : 126893753129635840,
  "created_at" : "2011-10-20 05:33:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126892961601568770",
  "text" : "\u30DB\u30FC\u30E0\u30E1\u30A4\u30C9\u30A4\u30F3\u30D5\u30EC\u30FC\u30B7\u30E7\u30F3",
  "id" : 126892961601568770,
  "created_at" : "2011-10-20 05:30:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 1, 12 ],
      "id_str" : "213268728",
      "id" : 213268728
    }, {
      "name" : "\u9577\u8C37\u5DDD \u5E73\u4E43",
      "screen_name" : "G4_Hirano_chan",
      "indices" : [ 13, 28 ],
      "id_str" : "227502200",
      "id" : 227502200
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 29, 39 ],
      "id_str" : "96560355",
      "id" : 96560355
    }, {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 40, 48 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126851338901532673",
  "text" : ".@magokoro84 @G4_Hirano_chan @nisehorrn @i_horse \u304A\u3084\u3059\u307F\u3069\u3046\u3082\u3067\u3057\u305F\u30FC",
  "id" : 126851338901532673,
  "created_at" : "2011-10-20 02:44:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126850641447493632",
  "geo" : { },
  "id_str" : "126851045929390080",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30C9\u30F3\u30DE\u30A4\u2606",
  "id" : 126851045929390080,
  "in_reply_to_status_id" : 126850641447493632,
  "created_at" : "2011-10-20 02:43:40 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126850545322442752",
  "text" : "\u4ECA\u8D77\u304D\u305F\uFF57\uFF57\uFF57",
  "id" : 126850545322442752,
  "created_at" : "2011-10-20 02:41:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126850463038586881",
  "text" : "\u3042\u3001\u4E8C\u9650\u9593\u306B\u5408\u308F\u306A\u3044\uFF57\uFF57\uFF57",
  "id" : 126850463038586881,
  "created_at" : "2011-10-20 02:41:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126703994226745344",
  "geo" : { },
  "id_str" : "126704750308757506",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3048\u3063",
  "id" : 126704750308757506,
  "in_reply_to_status_id" : 126703994226745344,
  "created_at" : "2011-10-19 17:02:21 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126703647328448512",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 126703647328448512,
  "created_at" : "2011-10-19 16:57:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126703522958938112",
  "text" : "\u3055\u3041\u3001\u624B\u52A0\u6E1B\u306F\u3057\u306A\u3044\u3067\u5BDD\u305F\u3075\u308A\u3059\u308B\u3088\u3002\u30CD\u30BF\u632F\u308A\u306F\u3057\u306A\u3044\u3088\u3002\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 126703522958938112,
  "created_at" : "2011-10-19 16:57:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126701010965102592",
  "text" : "\u4F55\u3067\u3082\u3067\u304D\u308B\u4EBA\u306B\u306F\u6210\u308C\u306A\u3044\u3060\u308D\u3046\u3051\u308C\u3069\u3001\u3044\u308D\u3044\u308D\u3067\u304D\u308B\u4EBA\u306B\u306F\u6210\u308A\u305F\u3044\u3002",
  "id" : 126701010965102592,
  "created_at" : "2011-10-19 16:47:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126698954330079232",
  "text" : "\u5168\u5C04\u3063\u3066\u4E00\u767A\u3067\u51FA\u308B\u3042\u305F\u308A\u30A2\u30EC\u3002\u524D\u8005\u30A7\u2026\u3002",
  "id" : 126698954330079232,
  "created_at" : "2011-10-19 16:39:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126698106657062912",
  "geo" : { },
  "id_str" : "126698835291549697",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u5168\u5C04\u3092\u8003\u3048\u3066\u307E\u3059\u3051\u3069\u5F8C\u8005\u306A\u3089\u9662\u306F\u78BA\u5B9A\u3067\u3059\u3088\u306D\u3047\u2026",
  "id" : 126698835291549697,
  "in_reply_to_status_id" : 126698106657062912,
  "created_at" : "2011-10-19 16:38:50 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126696168318177280",
  "geo" : { },
  "id_str" : "126696856834158592",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u307E\u3041\u307E\u3060\u5984\u60F3\u306B\u8FD1\u3044\u3067\u3059\u3051\u3069\u306D\u3047\u3002\u306A\u3093\u304B\u90FD\u5408\u306E\u3044\u3044\u306E\u304C\u306A\u3044\u304B\u306A\u30FC\u3001\u3068\u3002",
  "id" : 126696856834158592,
  "in_reply_to_status_id" : 126696168318177280,
  "created_at" : "2011-10-19 16:30:59 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126695679732105216",
  "text" : "\u3080\u3057\u308D\u305D\u3046\u3044\u3046\u30A4\u30EC\u30AE\u30E5\u30E9\u30FC\u3092\u53D7\u3051\u5165\u308C\u3066\u304F\u308C\u308B\u67D4\u8EDF\u6027\u3092\u6301\u3064\u4F01\u696D\u306B\u5165\u308A\u305F\u3044\u304B\u3089\u3001\u3054\u308A\u62BC\u3057\u306E\u30C1\u30E3\u30F3\u30B9\u3042\u308B\u306A\u3089\u3084\u3063\u3066\u307F\u305F\u3044\u3002",
  "id" : 126695679732105216,
  "created_at" : "2011-10-19 16:26:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126695382611804160",
  "text" : "\u4E0B\u624B\u306A\u7D4C\u6E08\u3084\u5546\u306E\u4EBA\u3088\u308A\u7406\u5DE5\u7CFB\u306B\u5F37\u3044\u4EBA\u9593\u304C\u51FA\u6765\u4E0A\u304C\u308B\u4E88\u5B9A\u306A\u3093\u3060\u3051\u3069\u306A\u3041\u2026\u3002",
  "id" : 126695382611804160,
  "created_at" : "2011-10-19 16:25:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126695183747252224",
  "text" : "\u30B7\u30E5\u30D7\u30EA\u30F3\u30AC\u30FC\u306F\u7D4C\u6E08\u3001\u5546\u3063\u3066\u66F8\u3044\u3066\u3042\u3063\u305F\u3057\u306A\u3041\u3002",
  "id" : 126695183747252224,
  "created_at" : "2011-10-19 16:24:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126694932575567873",
  "text" : "\u6587\u5B66\u90E8\u5352\u304C\u79D1\u5B66\u7CFB\u306E\u696D\u754C\u3078\u306E\u5C31\u8077\u306B\u652F\u969C\u3092\u304D\u305F\u3059\u306A\u3089\u30DE\u30B8\u3067\u8EE2\u90E8\u304B\u9662\u3067\u4ED6\u306B\u884C\u304F\u306E\u3042\u308B\u306A\u3002",
  "id" : 126694932575567873,
  "created_at" : "2011-10-19 16:23:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126694146168733697",
  "text" : "\u9078\u629E\u516C\u7406\u306E\u8A71\u3068\u304B\u805E\u304D\u305F\u3044\u306A\u30FC",
  "id" : 126694146168733697,
  "created_at" : "2011-10-19 16:20:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126692577519992833",
  "text" : "\u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u898B\u3066\u308B\u6642\u306F\u5F35\u308A\u4ED8\u3044\u3066\u308B\u3051\u3069\u898B\u3066\u306A\u3044\u6642\u306F5\uFF5E6\u6642\u9593\u5358\u4F4D\u3067\u898B\u3066\u306A\u3044\u304B\u3089\u306A\u3041\u30FB\u30FB\u30FB",
  "id" : 126692577519992833,
  "created_at" : "2011-10-19 16:13:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126688486102286337",
  "text" : "\u6700\u8FD1\u4E00\u65E5\u304C24\u6642\u9593\u3058\u3083\u5727\u5012\u7684\u306B\u8DB3\u308A\u306A\u3044\u3002",
  "id" : 126688486102286337,
  "created_at" : "2011-10-19 15:57:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126688302525976576",
  "text" : "\u4ECA\u66F4\u3060\u304C\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3088\u3046\u3002",
  "id" : 126688302525976576,
  "created_at" : "2011-10-19 15:56:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126687965421371392",
  "text" : "\u306A\u3093\u304BSoicha\u306E\u53D6\u5F97\u304C\u4ECA\u4E00\u3064\u4E0A\u624B\u304F\u3044\u3063\u3066\u306A\u3044\u306A\u30FC",
  "id" : 126687965421371392,
  "created_at" : "2011-10-19 15:55:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126687281770790912",
  "text" : "\u5FAE\u5206\u7A4D\u5206\u5B66\u7D9A\u8AD6B\u306E\u4E0A\u6728\u3055\u3093\u3063\u3066\u4EBA\u306E\u8A66\u9A13\u60C5\u5831\uFF08\u7279\u306B\u4E2D\u9593\uFF09\u6301\u3063\u3066\u308B\u4EBA\u3044\u305F\u3089\u4E0B\u3055\u3044\uFF08\u3057\u308D\u3081",
  "id" : 126687281770790912,
  "created_at" : "2011-10-19 15:52:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126686341563039746",
  "geo" : { },
  "id_str" : "126686720811991040",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307E\u3041\u3069\u3053\u307E\u3067\u3084\u3063\u305F\u304B\u3060\u3051\u805E\u304D\u306B\u884C\u304F\u306A\u3089\u6642\u9593\u901A\u308A\u306B\u884C\u304F\u5FC5\u8981\u306F\u306A\u3044\u3093\u3060\u3088\u306D\u3001\u3069\u3046\u305B\u51FA\u5E2D\u3082\u3089\u3048\u306A\u3044\u3093\u3060\u3057\u3002",
  "id" : 126686720811991040,
  "in_reply_to_status_id" : 126686341563039746,
  "created_at" : "2011-10-19 15:50:42 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126686518390685696",
  "text" : "\u96A3\u306E\u90E8\u5C4B\u304B\u3089\u7537\u5973\u8907\u6570\u306E\u697D\u3057\u3052\u306A\u58F0\u304C\u3059\u308B\u2026\u3046\u308B\u3055\u3044\u3068\u307E\u3067\u306F\u8A00\u308F\u306A\u3044\u3057\u81EA\u5206\u3082\u9EBB\u96C0\u3084\u308B\u304B\u3089\u6587\u53E5\u306F\u8A00\u308F\u306A\u3044\u3051\u3069\u3055\u3002",
  "id" : 126686518390685696,
  "created_at" : "2011-10-19 15:49:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126684534451343361",
  "geo" : { },
  "id_str" : "126686223694692352",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u524D\u304C\u884C\u304F\u306A\u3089\u304A\u308C\u306F\u884C\u304B\u306A\u3044\u3068\u3044\u3046\u9078\u629E\u80A2\u3082\uFF08\u3057\u308D\u3081",
  "id" : 126686223694692352,
  "in_reply_to_status_id" : 126684534451343361,
  "created_at" : "2011-10-19 15:48:44 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126685946899992576",
  "text" : "\u30C8\u30A4\u30EC\u306B\u884C\u304F\u306E\u3068\u304B\u3067\u3055\u3048\u305F\u3081\u3089\u308F\u308C\u308B\u30EC\u30D9\u30EB\u2026\u601D\u8003\u3092\u6B62\u3081\u305F\u3089\u677F\u66F8\u30DE\u30B7\u30FC\u30F3\u3068\u5316\u3059",
  "id" : 126685946899992576,
  "created_at" : "2011-10-19 15:47:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126685690162454528",
  "text" : "\u7406\u5B66\u90E8\u306E\u4EBA\u591A\u305D\u3046\u3067\u3059\u3057\u6570\u5B66\u7CFB\u306E\u6388\u696D\u30AA\u30D5\u306A\u3093\u304B\u306A\u3044\u304B\u306A\u30FC\u3068\u601D\u3063\u305F\u304C\u81EA\u5206\u306B\u30C4\u30A4\u30C3\u30BF\u30FC\u898B\u3066\u308B\u4F59\u88D5\u306A\u3093\u3066\u7121\u304B\u3063\u305F\u3002",
  "id" : 126685690162454528,
  "created_at" : "2011-10-19 15:46:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126684723614461952",
  "geo" : { },
  "id_str" : "126685587766902784",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u4ECA\u671F\u306F\u5FD9\u3057\u3044\u306E\u3067\u6765\u671F\u306F\u6388\u696D\u30AA\u30D5\u884C\u3063\u3066\u898B\u305F\u3044\u3067\u3059\uFF57\uFF57",
  "id" : 126685587766902784,
  "in_reply_to_status_id" : 126684723614461952,
  "created_at" : "2011-10-19 15:46:12 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 35, 42 ],
      "id_str" : "141811283",
      "id" : 141811283
    }, {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 44, 52 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/lzETIKkB",
      "expanded_url" : "http:\/\/togetter.com\/li\/202711",
      "display_url" : "togetter.com\/li\/202711"
    } ]
  },
  "geo" : { },
  "id_str" : "126684510703194112",
  "text" : "\u53BB\u5E74\u53D6\u3063\u3066\u305F\u3051\u3069\u30C4\u30A4\u30C3\u30BF\u30FC\u304C\u3042\u308B\u3060\u3051\u3067\u3053\u3093\u306A\u306B\u697D\u3057\u3044\u306E\u304B\u30FB\u30FB\u30FB RT @rpdexp .@maucha_ \u3055\u3093\u306E\u300C\u904B\u52D5\u79D1\u5B66\u3000\u7B2C\u4E09\u56DE\u8B1B\u7FA9\u300D\u3092\u304A\u6C17\u306B\u5165\u308A\u306B\u3057\u307E\u3057\u305F\u3002 http:\/\/t.co\/lzETIKkB",
  "id" : 126684510703194112,
  "created_at" : "2011-10-19 15:41:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126683252097417217",
  "geo" : { },
  "id_str" : "126683980996149249",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u8A18\u61B6\u306A\u3044\u30FB\u30FB\u30FB\u30D7\u30EA\u30F3\u30C8\u306B\u66F8\u3044\u3066\u3042\u3063\u305F\u3063\u3051",
  "id" : 126683980996149249,
  "in_reply_to_status_id" : 126683252097417217,
  "created_at" : "2011-10-19 15:39:49 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126682042107834368",
  "geo" : { },
  "id_str" : "126682963759988737",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u306D\u3047\u30FB\u30FB\u30FB\u3067\u3082\u4ECA\u304B\u3089\u4E88\u7FD2\u3068\u304B\u3059\u308B\u6C17\u306B\u306A\u3089\u306A\u3044\u3057\u306A\u30FC\u3002",
  "id" : 126682963759988737,
  "in_reply_to_status_id" : 126682042107834368,
  "created_at" : "2011-10-19 15:35:46 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126681564246581248",
  "geo" : { },
  "id_str" : "126681932095430657",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u884C\u3063\u3066\u3001\u5C45\u306A\u3044\u30D5\u30EA\u3060\u306D\u3001\u89E3\u308A\u96E3\u304F\u3066\u6E08\u307E\u306A\u3044\u3002",
  "id" : 126681932095430657,
  "in_reply_to_status_id" : 126681564246581248,
  "created_at" : "2011-10-19 15:31:40 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126681807885320192",
  "text" : "\u3042\u3001\u3053\u306E\u500D\u6E80\u306F\u9177\u3044\u3002",
  "id" : 126681807885320192,
  "created_at" : "2011-10-19 15:31:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126680811993956353",
  "geo" : { },
  "id_str" : "126681467362361344",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4FFA\u3082\u2026\u5834\u6240\u3082\u308F\u304B\u3089\u3093\u3057\u3001\u884C\u3063\u3066\u3044\u306A\u3044\u632F\u308A\u3057\u3088\u3046\u304B\u3068\u601D\u3063\u3066\u308B\u3002",
  "id" : 126681467362361344,
  "in_reply_to_status_id" : 126680811993956353,
  "created_at" : "2011-10-19 15:29:50 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126680495995092992",
  "geo" : { },
  "id_str" : "126680980344942592",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u3080\u3001\u3067\u306F\u307E\u305F\u306E\u6A5F\u4F1A\u306B\u53C2\u52A0\u3055\u305B\u3066\u3082\u3089\u3044\u307E\u3059\u306D",
  "id" : 126680980344942592,
  "in_reply_to_status_id" : 126680495995092992,
  "created_at" : "2011-10-19 15:27:53 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126679270297829376",
  "geo" : { },
  "id_str" : "126680049863757824",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u53C2\u52A0\u3057\u3066\u3082\u3044\u3044\u3067\u3059\u304B\uFF1F",
  "id" : 126680049863757824,
  "in_reply_to_status_id" : 126679270297829376,
  "created_at" : "2011-10-19 15:24:12 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Springer Japan",
      "screen_name" : "SpringerJapan",
      "indices" : [ 13, 27 ],
      "id_str" : "72223432",
      "id" : 72223432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/bUXkcQEm",
      "expanded_url" : "http:\/\/bit.ly\/ovbIbz",
      "display_url" : "bit.ly\/ovbIbz"
    } ]
  },
  "geo" : { },
  "id_str" : "126679346168606720",
  "text" : "\u6587\u5B66\u90E8\u5352\u30C0\u30E1\u306A\u306E\u2026 RT @SpringerJapan \u3010\u63A1\u7528\u60C5\u5831\u3011\u5927\u5B66\u306F\u6587\u7CFB\u3067\u3082\u3001\u9AD8\u6821\u3067\u6570\u5B66IIB\u307E\u3067\u3057\u3063\u304B\u308A\u52C9\u5F37\u3057\u3066\u304A\u3089\u308C\u305F\u65B9\u3001\u304A\u5F85\u3061\u3057\u3066\u304A\u308A\u307E\u3059\uFF01\u2192 http:\/\/t.co\/bUXkcQEm (B)",
  "id" : 126679346168606720,
  "created_at" : "2011-10-19 15:21:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3058\u3083\u3063\u3053",
      "screen_name" : "jackojacko_",
      "indices" : [ 3, 15 ],
      "id_str" : "118357981",
      "id" : 118357981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kuttinpa_follow_me",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126671544947720192",
  "text" : "RT @jackojacko_: \u3053\u306E\u524D\u6CB3\u5408\u587E\u3067\u73FE\u4EE3\u6587\u306E\u8B1B\u5E2B\u304C\u300C\u92AD\u6E6F\u306E\u5165\u53E3\u306B\u306F\u305F\u3081\u3044\u3066\u3044\u308B\u300E\u3086\u300F\u3068\u3044\u3046\u5B57\u306F\u3001\u305D\u308C\u3060\u3051\u3067\u5B8C\u6210\u3055\u308C\u305F\u30C7\u30B6\u30A4\u30F3\u306E\u3088\u3046\u306B\u601D\u3044\u307E\u3059\u3002\u300E\u3086\u300F\u306F\u7D20\u6674\u3089\u3057\u3044\u300D\u3068\u306E\u3088\u3046\u306A\u3053\u3068\u3092\u8A9E\u3063\u3066\u3044\u305F\u306E\u3067\u3001\u65E9\u901F\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u3092\u30D5\u30A9\u30ED\u30FC\u3055\u305B\u3066\u9802\u304D\u307E\u3057\u305F\uFF01\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u3057\u307E\u3059 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yubitter.com\/\" rel=\"nofollow\"\u003Eyubitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kuttinpa_follow_me",
        "indices" : [ 121, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126669217146732545",
    "text" : "\u3053\u306E\u524D\u6CB3\u5408\u587E\u3067\u73FE\u4EE3\u6587\u306E\u8B1B\u5E2B\u304C\u300C\u92AD\u6E6F\u306E\u5165\u53E3\u306B\u306F\u305F\u3081\u3044\u3066\u3044\u308B\u300E\u3086\u300F\u3068\u3044\u3046\u5B57\u306F\u3001\u305D\u308C\u3060\u3051\u3067\u5B8C\u6210\u3055\u308C\u305F\u30C7\u30B6\u30A4\u30F3\u306E\u3088\u3046\u306B\u601D\u3044\u307E\u3059\u3002\u300E\u3086\u300F\u306F\u7D20\u6674\u3089\u3057\u3044\u300D\u3068\u306E\u3088\u3046\u306A\u3053\u3068\u3092\u8A9E\u3063\u3066\u3044\u305F\u306E\u3067\u3001\u65E9\u901F\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u3092\u30D5\u30A9\u30ED\u30FC\u3055\u305B\u3066\u9802\u304D\u307E\u3057\u305F\uFF01\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u3057\u307E\u3059\uFF01\uFF01#kuttinpa_follow_me",
    "id" : 126669217146732545,
    "created_at" : "2011-10-19 14:41:09 +0000",
    "user" : {
      "name" : "\u3058\u3083\u3063\u3053",
      "screen_name" : "jackojacko_",
      "protected" : false,
      "id_str" : "118357981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2983017366\/db76f582f49ae6197aa84fe352d657d3_normal.jpeg",
      "id" : 118357981,
      "verified" : false
    }
  },
  "id" : 126671544947720192,
  "created_at" : "2011-10-19 14:50:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oudanseminar",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126554588882014208",
  "text" : "RT @t_uda: \u300C\u3042\u308B\u81EA\u7136\u6570N \u2026 \u3048\u3063\u3068\u3053\u308C\u306F 1 \u4EE5\u4E0A\u306E\u6574\u6570\u306E\u3053\u3068\u306A\u3093\u3067\u3059\u3051\u3069\u300D\u300C\u306F\u3044\u306F\u3044\u300D #oudanseminar \/\u039E\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oudanseminar",
        "indices" : [ 41, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126553916514119680",
    "text" : "\u300C\u3042\u308B\u81EA\u7136\u6570N \u2026 \u3048\u3063\u3068\u3053\u308C\u306F 1 \u4EE5\u4E0A\u306E\u6574\u6570\u306E\u3053\u3068\u306A\u3093\u3067\u3059\u3051\u3069\u300D\u300C\u306F\u3044\u306F\u3044\u300D #oudanseminar \/\u039E\/",
    "id" : 126553916514119680,
    "created_at" : "2011-10-19 07:02:59 +0000",
    "user" : {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "protected" : false,
      "id_str" : "91551881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2672060221\/0f35a7ef7843ca03ed5048770fe5ecc4_normal.png",
      "id" : 91551881,
      "verified" : false
    }
  },
  "id" : 126554588882014208,
  "created_at" : "2011-10-19 07:05:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oudanseminar",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126554289198997506",
  "text" : "RT @t_uda: \u300C\u3054\u3081\u3093\u306A\u3055\u3044\u3061\u3087\u3063\u3068\u81EA\u5206\u306E\u30CE\u30FC\u30C8\u8AAD\u3081\u306A\u3044\u300D \uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57 #oudanseminar \/\u039E\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oudanseminar",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126552947663454209",
    "text" : "\u300C\u3054\u3081\u3093\u306A\u3055\u3044\u3061\u3087\u3063\u3068\u81EA\u5206\u306E\u30CE\u30FC\u30C8\u8AAD\u3081\u306A\u3044\u300D \uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57 #oudanseminar \/\u039E\/",
    "id" : 126552947663454209,
    "created_at" : "2011-10-19 06:59:08 +0000",
    "user" : {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "protected" : false,
      "id_str" : "91551881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2672060221\/0f35a7ef7843ca03ed5048770fe5ecc4_normal.png",
      "id" : 91551881,
      "verified" : false
    }
  },
  "id" : 126554289198997506,
  "created_at" : "2011-10-19 07:04:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "91551881",
      "id" : 91551881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oudanseminar",
      "indices" : [ 37, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126552885881339904",
  "text" : "RT @t_uda: \u3053\u306E\u5F0F\u899A\u3048\u3061\u3083\u3063\u3066\u4F55\u306E\u5F79\u306B\u7ACB\u3064\u306E\uFF57\uFF57\uFF57 \uFF08\u677F\u66F8\u653E\u68C4 #oudanseminar \/\u039E\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oudanseminar",
        "indices" : [ 26, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126549219371782144",
    "text" : "\u3053\u306E\u5F0F\u899A\u3048\u3061\u3083\u3063\u3066\u4F55\u306E\u5F79\u306B\u7ACB\u3064\u306E\uFF57\uFF57\uFF57 \uFF08\u677F\u66F8\u653E\u68C4 #oudanseminar \/\u039E\/",
    "id" : 126549219371782144,
    "created_at" : "2011-10-19 06:44:19 +0000",
    "user" : {
      "name" : "\u9032\u6357NaN\u3067\u3059",
      "screen_name" : "t_uda",
      "protected" : false,
      "id_str" : "91551881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2672060221\/0f35a7ef7843ca03ed5048770fe5ecc4_normal.png",
      "id" : 91551881,
      "verified" : false
    }
  },
  "id" : 126552885881339904,
  "created_at" : "2011-10-19 06:58:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126537008142225408",
  "text" : "\u30BB\u30DF\u30CA\u30FC\u5B9F\u6CC1\u3057\u3066\u308B\u4F59\u88D5\u306A\u3044\uFF57\uFF57",
  "id" : 126537008142225408,
  "created_at" : "2011-10-19 05:55:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126467151581282304",
  "text" : "\u3042\u3001\u9593\u306B\u5408\u308F\u306C",
  "id" : 126467151581282304,
  "created_at" : "2011-10-19 01:18:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126345033904422912",
  "text" : "\u4ECA\u65E5\u306E\u30BB\u30DF\u30CA\u30FC\u306E\u51FD\u6570\u3086(\uFF58)\u306B\u671F\u5F85\u3057\u3064\u3064\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 126345033904422912,
  "created_at" : "2011-10-18 17:12:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126344053498445824",
  "text" : "\u4E00\u90E8\u306E\u7406\u5B66\u90E8\u751F\u3088\u308A\u7406\u5B66\u90E8\u6765\u3066\u308B\u7CFB\u6587\u5B66\u90E8\u7537\u5B50\u306E\u30A2\u30AB\u30A6\u30F3\u30C8\u306F\u3053\u3061\u3089",
  "id" : 126344053498445824,
  "created_at" : "2011-10-18 17:09:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126340793207226368",
  "geo" : { },
  "id_str" : "126342108507406336",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u3042\u30FC\u30E1\u30FC\u30EB\u8A2D\u5B9A\u306F\u9B31\u9676\u3057\u3044\u304B\u3089\u5207\u3063\u3061\u3083\u3063\u3066\u308B\u308F\u3002\uFF34\uFF2C\u306B\u898B\u3048\u305F\u304B\u3089\u3064\u3044\u306D\uFF57",
  "id" : 126342108507406336,
  "in_reply_to_status_id" : 126340793207226368,
  "created_at" : "2011-10-18 17:01:20 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u3050\u308B\u307E=\u306F\u3050\u308B\u3093",
      "screen_name" : "haguruma20",
      "indices" : [ 0, 11 ],
      "id_str" : "349830212",
      "id" : 349830212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126340058952376321",
  "geo" : { },
  "id_str" : "126340122726764544",
  "in_reply_to_user_id" : 349830212,
  "text" : "@haguruma20 \u4FFA\u306F\u884C\u304F\u305C\uFF57\uFF57\uFF57",
  "id" : 126340122726764544,
  "in_reply_to_status_id" : 126340058952376321,
  "created_at" : "2011-10-18 16:53:27 +0000",
  "in_reply_to_screen_name" : "haguruma20",
  "in_reply_to_user_id_str" : "349830212",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126339737995841537",
  "geo" : { },
  "id_str" : "126340060009340929",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u304A\u3084\u3059\u30DF\u30EB\u30AB\u3055\u3093",
  "id" : 126340060009340929,
  "in_reply_to_status_id" : 126339737995841537,
  "created_at" : "2011-10-18 16:53:12 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126337183555653633",
  "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u3068\u306E\u7D61\u307F\u3082\u542B\u3081\u3066\u6BCE\u65E5\u697D\u3057\u3044\u304B\u3089\u30C0\u30A6\u30C8",
  "id" : 126337183555653633,
  "created_at" : "2011-10-18 16:41:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126267958996631552",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 126267958996631552,
  "created_at" : "2011-10-18 12:06:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u897F\u5C3E\u7DAD\u65B0\u98A8\u306B\u6570\u5B66\u3092\u8A9E\u308B\u3068\u622F\u8A00\u3060",
      "indices" : [ 66, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126177388726992896",
  "text" : "\u300C\u304B\u304B\u304B\u3002\u304A\u524D\u69D8\u3001\u305D\u3057\u3066\u50BE\u304F\u3068\u3044\u3046\u306E\u306A\u3089\u3001\u3069\u3046\u50BE\u304F\uFF1F\u300D\u300C\u305D\u3046\u3060\u306A\u3002\u307E\u3042\u3068\u308A\u3042\u3048\u305A\u3001\u76EE\u306E\u524D\u306E\u5973\u306E\u5B50\u306E\u305F\u3081\u306B\u3053\u306E\u95A2\u6570\u3092\u5FAE\u5206\u3057\u3066\u307F\u308B\u304B\u300D #\u897F\u5C3E\u7DAD\u65B0\u98A8\u306B\u6570\u5B66\u3092\u8A9E\u308B\u3068\u622F\u8A00\u3060",
  "id" : 126177388726992896,
  "created_at" : "2011-10-18 06:06:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u897F\u5C3E\u7DAD\u65B0\u98A8\u306B\u6570\u5B66\u3092\u8A9E\u308B\u3068\u622F\u8A00\u3060",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126176180217974784",
  "text" : "#\u897F\u5C3E\u7DAD\u65B0\u98A8\u306B\u6570\u5B66\u3092\u8A9E\u308B\u3068\u622F\u8A00\u3060",
  "id" : 126176180217974784,
  "created_at" : "2011-10-18 06:02:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126175581934063616",
  "text" : "\u516C\u7406\u3068\u3044\u3046\u516C\u7406\u3092\u516C\u7406\u3057\u308D\u3002\u5B9A\u7406\u3068\u3044\u3046\u5B9A\u7406\u3092\u5B9A\u7406\u3057\u308D\u3002\u5B9A\u7FA9\u3068\u3044\u3046\u5B9A\u7FA9\u3092\u5B9A\u7FA9\u3057\u308D\u3002\u8A3C\u660E\u3068\u3044\u3046\u8A3C\u660E\u3092\u8A3C\u660E\u3057\u308D\u3002\u5FAE\u5206\u3068\u3044\u3046\u5FAE\u5206\u3092\u5FAE\u5206\u3057\u308D\u3002\u7A4D\u5206\u3068\u3044\u3046\u7A4D\u5206\u3092\u7A4D\u5206\u3057\u308D\u3002\u9060\u616E\u306F\u3059\u308B\u306A\u8AB0\u306B\u306F\u3070\u304B\u308B\u3053\u3068\u3082\u306A\u3044\u3002\u6211\u3005\u306F\u7F8E\u3057\u3044\u4E16\u754C\u306B\u8A87\u308C\u3002\u3053\u3053\u306F\u5927\u5B66\u306E\u6559\u5BA4\u3060\u3001\u5B58\u5206\u306B\u4E71\u308C\u308D\u4EEE\u5B9A\u304C\u8A31\u3059\u3002",
  "id" : 126175581934063616,
  "created_at" : "2011-10-18 05:59:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126112769769619456",
  "text" : "\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 126112769769619456,
  "created_at" : "2011-10-18 01:50:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126112590282764289",
  "text" : "\u3055\u3041\uFF12\u9650\u7D42\u308F\u308A\u307E\u3067\u306B\u884C\u3063\u3066\u30D7\u30EA\u30F3\u30C8\u8CB0\u3046\u7C21\u5358\u306A\u304A\u4ED5\u4E8B",
  "id" : 126112590282764289,
  "created_at" : "2011-10-18 01:49:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125982687092686849",
  "geo" : { },
  "id_str" : "125982947173072896",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u4E09\u6761\u306E\u304B\u3063\u3071\u5BFF\u53F8\u304C\u7121\u304F\u306A\u3063\u305F\u3089\u3057\u3044\u306A\u30FC",
  "id" : 125982947173072896,
  "in_reply_to_status_id" : 125982687092686849,
  "created_at" : "2011-10-17 17:14:09 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125982787630141440",
  "text" : "\u2026\u5BDD\u307E\u3059\u308F\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 125982787630141440,
  "created_at" : "2011-10-17 17:13:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125982378500960256",
  "geo" : { },
  "id_str" : "125982586806874112",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u307E\u3041\u5185\u9678\u3067\u3059\u3057\u304A\u3059\u3057",
  "id" : 125982586806874112,
  "in_reply_to_status_id" : 125982378500960256,
  "created_at" : "2011-10-17 17:12:43 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125982454497554432",
  "text" : "\u7FA4\u74B0",
  "id" : 125982454497554432,
  "created_at" : "2011-10-17 17:12:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125982374327615489",
  "text" : "\u3050\u3093\u304B\u3093",
  "id" : 125982374327615489,
  "created_at" : "2011-10-17 17:11:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 8, 19 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125982330052546560",
  "text" : "\u3069\u3046\u304B\u3093 RT @magokoro84: \u304A\u3059\u3057\u305F\u3079\u305F\u3044",
  "id" : 125982330052546560,
  "created_at" : "2011-10-17 17:11:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125982078687920128",
  "text" : "\u9AD8\u6821\u306F\u697D\u3057\u304B\u3063\u305F\u3057\u53CB\u4EBA\u306B\u3082\u6075\u307E\u308C\u305F\u304C\u5FC5\u305A\u3057\u3082\u77E5\u6027\u306B\u6EA2\u308C\u3066\u306F\u306A\u304B\u3063\u305F\u3002\u30E6\u30FC\u30E2\u30A2\u306F\u30C0\u30C0\u6F0F\u308C\u3060\u3063\u305F\u3051\u3069\u3002",
  "id" : 125982078687920128,
  "created_at" : "2011-10-17 17:10:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125981725124866049",
  "text" : "\u305D\u308C\u3092\u5857\u308A\u66FF\u3048\u308B\u305F\u3081\u306B\u5927\u5B66\u306B\u6765\u305F\u3093\u3060\u304C",
  "id" : 125981725124866049,
  "created_at" : "2011-10-17 17:09:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125980591408680960",
  "geo" : { },
  "id_str" : "125980852093063168",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u666E\u901A\u306B\u300C\u3061\u3087\u3063\u3068\u90FD\u5408\u3067\u30C0\u30E1\u306B\u306A\u3063\u305F\u306E\u3067\u767D\u7D19\u306B\u300D\u3001\u3066\uFF34\uFF25\uFF2C\u3059\u308C\u3070\uFF1F",
  "id" : 125980852093063168,
  "in_reply_to_status_id" : 125980591408680960,
  "created_at" : "2011-10-17 17:05:50 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JARA",
      "screen_name" : "Harayamada",
      "indices" : [ 0, 11 ],
      "id_str" : "324819663",
      "id" : 324819663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125978919135490048",
  "geo" : { },
  "id_str" : "125980473917837312",
  "in_reply_to_user_id" : 324819663,
  "text" : "@Harayamada \u4F53\u529B\u3068\u6642\u9593\u3055\u3048\u3042\u308C\u3070\u671D\u307E\u3067\u3084\u308A\u304B\u306D\u306A\u3044\u611F\u3058\u3067\u3057\u305F\u306D\uFF57\n\u52C9\u5F37\u3057\u306A\u304F\u3066\u306F\u3067\u3059\u3002",
  "id" : 125980473917837312,
  "in_reply_to_status_id" : 125978919135490048,
  "created_at" : "2011-10-17 17:04:20 +0000",
  "in_reply_to_screen_name" : "Harayamada",
  "in_reply_to_user_id_str" : "324819663",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125979795250089986",
  "text" : "@np2i \u30DB\u30F3\u30C8\u306B\u53CB\u4EBA\u306B\u6075\u307E\u308C\u307E\u3057\u305F\u3002\u4E00\u5FDC\u76F8\u4E92\u8B1B\u7FA9\u5F62\u5F0F\u306A\u306E\u3067\u3059\u304C\u307B\u3068\u3093\u3069\u6559\u308F\u3063\u3066\u3070\u304B\u308A\u3067\u7533\u3057\u8A33\u306A\u3044\u9650\u308A\u3067\u3059\u3002\u52C9\u5F37\u3057\u306A\u304F\u3066\u306F\u3002",
  "id" : 125979795250089986,
  "created_at" : "2011-10-17 17:01:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 0, 5 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125977795317858305",
  "text" : "@np2i \u53CB\u4EBA\u5B85\u3067\u52C9\u5F37\u4F1A\uFF08\u4E8C\u4EBA\uFF09\u3067\u3057\u305F\u30FC",
  "id" : 125977795317858305,
  "created_at" : "2011-10-17 16:53:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125977287282798592",
  "geo" : { },
  "id_str" : "125977535052918785",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u30B5\u30FC\u30AF\u30EB\u3063\u3066\u3088\u308A\u52C9\u5F37\u4F1A\u306B\u8FD1\u3044\u3067\u3059\u304B\u306D\u30FC",
  "id" : 125977535052918785,
  "in_reply_to_status_id" : 125977287282798592,
  "created_at" : "2011-10-17 16:52:39 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125976611626561536",
  "geo" : { },
  "id_str" : "125977070386950144",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3082\u3046\u306A\u3093\u306B\u3082\u308F\u304B\u3093\u306A\u304F\u306A\u3063\u3066\u304D\u305F\u3002\n\n\u6B63\u76F4\u96C6\u4E2D\u304C\u6301\u3066\u3070\u671D\u307E\u3067\u3084\u308A\u304B\u306D\u306A\u3044\u52E2\u3044\u3060\u3063\u305F\u3002",
  "id" : 125977070386950144,
  "in_reply_to_status_id" : 125976611626561536,
  "created_at" : "2011-10-17 16:50:48 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125976548498079744",
  "text" : "\uFF16\u9650\u3001\u5FAE\u5206\u65B9\u7A0B\u5F0F\n\uFF17\u9650\u3001\u5FAE\u5206\u65B9\u7A0B\u5F0F\n\uFF18\u9650\u3001\u7DDA\u5F62\u4EE3\u6570\n\uFF19\u9650\u3001\u8907\u7D20\u89E3\u6790\n\uFF11\uFF10\u9650\u3001\u8907\u7D20\u89E3\u6790\n\uFF11\uFF11\u9650\u3001\u8907\u7D20\u89E3\u6790\n\u5E30\u5B85\u2190\uFF72\uFF8F\uFF7A\uFF7A\uFF01",
  "id" : 125976548498079744,
  "created_at" : "2011-10-17 16:48:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125975787743621121",
  "text" : "\u81EA\u899A\u3057\u3088\u3046\u3001\u3073\u3076\u3093\u305B\u304D\u3076\u3093\u5B66\u90E8\u3060\u304C\u4E00\u756A\u7518\u3044\u306E\u306F\u5FAE\u7A4D\u5206\u3060\u3002",
  "id" : 125975787743621121,
  "created_at" : "2011-10-17 16:45:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 23, 32 ],
      "id_str" : "612419223",
      "id" : 612419223
    }, {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 57, 66 ],
      "id_str" : "102399578",
      "id" : 102399578
    }, {
      "name" : "\u3056\u3079\u3059",
      "screen_name" : "Elizabeth_H_01",
      "indices" : [ 91, 106 ],
      "id_str" : "323566206",
      "id" : 323566206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125970713235562496",
  "text" : "\u8AB0\u304B\u79C1\u306B\u6570\u5B66\u6559\u3048\u3066 \u6587\u7CFB\u306E\u4EBA\u3067\u3082\u3044\u304B\u3089 RT @nartakio: \u8AB0\u304B\u79C1\u306B\u6570\u5B66\u6559\u3048\u3066 \u6587\u7CFB\u306E\u4EBA\u3067\u3082\u3044\u304B\u3089 RT @kuttinpa: \u8AB0\u304B\u79C1\u306B\u6570\u5B66\u6559\u3048\u3066 \u6587\u7CFB\u306E\u4EBA\u3067\u3082\u3044\u304B\u3089 RT @Elizabeth_H_01: \u8AB0\u304B\u79C1\u306B\u6570\u5B66\u6559\u3048\u3066 \u6587\u7CFB\u306E\u4EBA\u3067\u3082\u3044\u3044\u304B\u3089",
  "id" : 125970713235562496,
  "created_at" : "2011-10-17 16:25:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125970258774327299",
  "text" : "\u6708\u66DC\u306E\uFF11\uFF11\u9650\u7D42\u308F\u3063\u305F\uFF57\uFF57\uFF57\uFF57",
  "id" : 125970258774327299,
  "created_at" : "2011-10-17 16:23:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/rV1pYyGd",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=fumiexcel",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "125962905492520961",
  "text" : "fumiexcel\u304C\u3001\u79C1\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/rV1pYyGd",
  "id" : 125962905492520961,
  "created_at" : "2011-10-17 15:54:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125763143661133824",
  "text" : "2010\u5E74\u30EF\u30FC\u30EB\u30C9\u30AB\u30C3\u30D7\u4E00\u6B21\u30EA\u30FC\u30B0\u5F97\u70B9\u3068\u30DD\u30EF\u30BD\u30F3\u5206\u5E03\u306E\u6BD4\u8F03\uFF57\uFF57",
  "id" : 125763143661133824,
  "created_at" : "2011-10-17 02:40:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "indices" : [ 3, 13 ],
      "id_str" : "249297914",
      "id" : 249297914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125762826672410624",
  "text" : "RT @JOJO_math: \u3060 \u304B \u3089 \u3053 \u306E '97 \u30BB \u30F3 \u30BF \u30FC \u8A66 \u9A13 \u3067 \u3053 \u306E \u82B1 \u4EAC \u9662 \u5178 \u660E \u306B \u7CBE \u795E \u7684 \u52D5 \u63FA \u306B \u3088 \u308B 39\/45 \u306E \u7D04 \u5206 \u3057 \u5FD8 \u308C \u306F \u6C7A \u3057 \u3066 \u306A \u3044 \uFF01 \u3068\u601D\u3063\u3066\u3044\u305F\u3060\u3053\u3046\u30C3\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/maraigue.hhiro.net\/twbot\/\" rel=\"nofollow\"\u003Etwbot2.rb\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125759952194244608",
    "text" : "\u3060 \u304B \u3089 \u3053 \u306E '97 \u30BB \u30F3 \u30BF \u30FC \u8A66 \u9A13 \u3067 \u3053 \u306E \u82B1 \u4EAC \u9662 \u5178 \u660E \u306B \u7CBE \u795E \u7684 \u52D5 \u63FA \u306B \u3088 \u308B 39\/45 \u306E \u7D04 \u5206 \u3057 \u5FD8 \u308C \u306F \u6C7A \u3057 \u3066 \u306A \u3044 \uFF01 \u3068\u601D\u3063\u3066\u3044\u305F\u3060\u3053\u3046\u30C3\uFF01",
    "id" : 125759952194244608,
    "created_at" : "2011-10-17 02:28:03 +0000",
    "user" : {
      "name" : "\u30B8\u30E7\u30B8\u30E7\u306E\u5947\u5999\u306A\u6570\u5B66",
      "screen_name" : "JOJO_math",
      "protected" : false,
      "id_str" : "249297914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608774862\/icon676027938986332265616times55_normal.png",
      "id" : 249297914,
      "verified" : false
    }
  },
  "id" : 125762826672410624,
  "created_at" : "2011-10-17 02:39:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125762728009793537",
  "text" : "\u4F59\u3063\u305F\u6642\u9593\u3067\u6559\u6388\u304C\u4E0E\u592A\u8A71\u59CB\u3081\u305F\u3002\u9ED2\u677F\u306B\u4E0E\u592A\u8A71\u3063\u3066\uFF57\uFF57\uFF57",
  "id" : 125762728009793537,
  "created_at" : "2011-10-17 02:39:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125742007762161665",
  "text" : "\u540C\u5024\u95A2\u4FC2\u95A2\u4FC2\u3092\u7406\u89E3\u3057\u3066\u3044\u305F\u3089\u3082\u3046\u4E8C\u9650\u306E\u6642\u9593\u304B",
  "id" : 125742007762161665,
  "created_at" : "2011-10-17 01:16:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125732653960925184",
  "text" : "\u540C\u5024\u95A2\u4FC2",
  "id" : 125732653960925184,
  "created_at" : "2011-10-17 00:39:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 3, 17 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125724197967237120",
  "text" : "RT @OhgakiRintaro: Google\u30DE\u30C3\u30D7\u306E\u30B9\u30C8\u30EA\u30FC\u30C8\u30D3\u30E5\u30FC\u3067\u884C\u304D\u305F\u3044\u3068\u3053\u308D\u3092\u63A2\u3057\u3066\u305F\u3089\u3001\u305D\u306E\u5EFA\u7269\u306E\u76EE\u306E\u524D\u306B\u5927\u578B\u30C8\u30E9\u30C3\u30AF\u304C\u3068\u307E\u3063\u3066\u3044\u3066\u78BA\u8A8D\u4E0D\u53EF\u80FD\u3067\u3057\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125723789215531009",
    "text" : "Google\u30DE\u30C3\u30D7\u306E\u30B9\u30C8\u30EA\u30FC\u30C8\u30D3\u30E5\u30FC\u3067\u884C\u304D\u305F\u3044\u3068\u3053\u308D\u3092\u63A2\u3057\u3066\u305F\u3089\u3001\u305D\u306E\u5EFA\u7269\u306E\u76EE\u306E\u524D\u306B\u5927\u578B\u30C8\u30E9\u30C3\u30AF\u304C\u3068\u307E\u3063\u3066\u3044\u3066\u78BA\u8A8D\u4E0D\u53EF\u80FD\u3067\u3057\u305F\u3002",
    "id" : 125723789215531009,
    "created_at" : "2011-10-17 00:04:21 +0000",
    "user" : {
      "name" : "R.Ohgaki",
      "screen_name" : "yokuwaraou",
      "protected" : false,
      "id_str" : "109537708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415978646050856961\/YcOdHwEv_normal.jpeg",
      "id" : 109537708,
      "verified" : false
    }
  },
  "id" : 125724197967237120,
  "created_at" : "2011-10-17 00:05:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125719687513378816",
  "text" : "\u5317\u90E8\u3067\u671D\u3054\u306F\u3093\u98DF\u3079\u3066\u3084\u308B",
  "id" : 125719687513378816,
  "created_at" : "2011-10-16 23:48:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125719463457865728",
  "text" : "\u4E00\u9650\u4F11\u8B1B\u3068\u304Borz",
  "id" : 125719463457865728,
  "created_at" : "2011-10-16 23:47:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125712833248894979",
  "text" : "\u81EA\u610F\u8B58\u904E\u5270\u306A\u306E\u304B\u3082",
  "id" : 125712833248894979,
  "created_at" : "2011-10-16 23:20:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125712542407475201",
  "text" : "\u30AD\u30E3\u30E9\u7269\u306E\u62B1\u304D\u6795\u306F\u753B\u671F\u7684\u306A\u30A2\u30A4\u30C7\u30A3\u30A2\u3060\u3068\u601D\u3046\u3051\u308C\u3069\u5148\u306B\u305D\u3063\u3061\u3092\u9023\u60F3\u3055\u308C\u304C\u3061\u306A\u306E\u306F\u3061\u3087\u3063\u3068\u2026",
  "id" : 125712542407475201,
  "created_at" : "2011-10-16 23:19:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125712055482318849",
  "text" : "\u3042\u3001\u7E70\u308A\u8FD4\u3057\u3067\u3059\u304C\u62B1\u304D\u6795\u306F\u7121\u5730\u3067\u3059\u3002\u8272\u306F\u30EF\u30A4\u30F3\u30EC\u30C3\u30C9\u3002",
  "id" : 125712055482318849,
  "created_at" : "2011-10-16 23:17:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125711842822721536",
  "text" : "\u5E03\u56E3\u306E\u604B\u3057\u3044\u5B63\u7BC0\u3002\u62B1\u304D\u6795\u304C\u5FC3\u5730\u3044\u3044\u3002\u590F\u306F\u6691\u82E6\u3057\u3044\u304B\u3089\u306A\u30FC\u3002",
  "id" : 125711842822721536,
  "created_at" : "2011-10-16 23:16:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125711494158630912",
  "text" : "\u305D\u308D\u305D\u308D\u5E03\u56E3\u304B\u3089\u51FA\u306A\u3044\u3068\u306A\u30FC",
  "id" : 125711494158630912,
  "created_at" : "2011-10-16 23:15:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrn",
      "indices" : [ 11, 22 ],
      "id_str" : "229752118",
      "id" : 229752118
    }, {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 23, 33 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125707450824400896",
  "geo" : { },
  "id_str" : "125710694606839808",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math @nisehorrrn @blackVELU \u304A\u306F\u3042\u308A\u3067\u3057\u305F\u30FC",
  "id" : 125710694606839808,
  "in_reply_to_status_id" : 125707450824400896,
  "created_at" : "2011-10-16 23:12:19 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125708497961758721",
  "text" : "\u3093\u30FC\u3001\u5973\u3060\u304B\u3089\u5927\u5909\u306A\u4E8B\u3068\u540C\u3058\u304F\u3089\u3044\u7537\u3060\u304B\u3089\u5927\u5909\u306A\u4E8B\u304C\u3042\u308B\u3068\u601D\u3046\u3051\u3069\u306A\u30FC\u3002\n\u4ED6\u4EBA\u306E\u829D\u304C\u9752\u3044\u3060\u3051\u3058\u3083\u2026\u3002",
  "id" : 125708497961758721,
  "created_at" : "2011-10-16 23:03:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3053\u305F\u3064@\u3044\u306E\u3048\u3055\u3093\u304C\u30AD\u30B9\u5F85\u3061\u3057\u3066\u307E\u3059",
      "screen_name" : "kotatutyan",
      "indices" : [ 3, 14 ],
      "id_str" : "207944379",
      "id" : 207944379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125708127520817153",
  "text" : "RT @kotatutyan: \u7537\u5B50\u304C\u30B9\u30C3\u30D4\u30F3\u306F\u5F53\u7136\u3002\u5973\u5B50\u304C\u5316\u7CA7\u3092\u3059\u308B\u306E\u306F\u30DE\u30CA\u30FC\u3002\u7537\u5B50\u304C\u7325\u8AC7\u3057\u3066\u3082\u4F55\u3082\u8A00\u308F\u308C\u306A\u3044\u3002\u5973\u5B50\u304C\u7325\u8AC7\u3092\u597D\u304D\u3060\u3068\u5F15\u304B\u308C\u308B\u3002\u7537\u5B50\u306F\u7121\u99C4\u6BDB\u3042\u3063\u3066\u3082\u554F\u984C\u306A\u3044\u3002\u5973\u5B50\u306F\u7121\u99C4\u6BDB\u3042\u308B\u3068\u5973\u6368\u3066\u3066\u308B\u3068\u8A00\u308F\u308C\u308B\u3002\u7D42\u3044\u306B\u306F\u7537\u5B50\u306F\u6B66\u52C7\u4F1D\u3001\u5973\u5B50\u306F\u5C3B\u8EFD\u3002\u5973\u5B50\u306F\u4ECA\u65E5\u3082\u61F8\u547D\u306B\u751F\u304D\u3066\u3044\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125591357908713472",
    "text" : "\u7537\u5B50\u304C\u30B9\u30C3\u30D4\u30F3\u306F\u5F53\u7136\u3002\u5973\u5B50\u304C\u5316\u7CA7\u3092\u3059\u308B\u306E\u306F\u30DE\u30CA\u30FC\u3002\u7537\u5B50\u304C\u7325\u8AC7\u3057\u3066\u3082\u4F55\u3082\u8A00\u308F\u308C\u306A\u3044\u3002\u5973\u5B50\u304C\u7325\u8AC7\u3092\u597D\u304D\u3060\u3068\u5F15\u304B\u308C\u308B\u3002\u7537\u5B50\u306F\u7121\u99C4\u6BDB\u3042\u3063\u3066\u3082\u554F\u984C\u306A\u3044\u3002\u5973\u5B50\u306F\u7121\u99C4\u6BDB\u3042\u308B\u3068\u5973\u6368\u3066\u3066\u308B\u3068\u8A00\u308F\u308C\u308B\u3002\u7D42\u3044\u306B\u306F\u7537\u5B50\u306F\u6B66\u52C7\u4F1D\u3001\u5973\u5B50\u306F\u5C3B\u8EFD\u3002\u5973\u5B50\u306F\u4ECA\u65E5\u3082\u61F8\u547D\u306B\u751F\u304D\u3066\u3044\u307E\u3059\u3002",
    "id" : 125591357908713472,
    "created_at" : "2011-10-16 15:18:07 +0000",
    "user" : {
      "name" : "\u3053\u305F\u3064@\u3044\u306E\u3048\u3055\u3093\u304C\u30AD\u30B9\u5F85\u3061\u3057\u3066\u307E\u3059",
      "screen_name" : "kotatutyan",
      "protected" : false,
      "id_str" : "207944379",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2834942310\/64b6715f532f8eab37586b1ff9dc0536_normal.jpeg",
      "id" : 207944379,
      "verified" : false
    }
  },
  "id" : 125708127520817153,
  "created_at" : "2011-10-16 23:02:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125707818006355968",
  "text" : "\u76F4\u8FD150\u304F\u3089\u3044\u306E\u30C4\u30A4\u30FC\u30C8\u307F\u308C\u3070\u30D5\u30A9\u30ED\u30FC\u3057\u305F\u304F\u306A\u308B\u767A\u8A00\u306E\u4E00\u3064\u3084\u4E8C\u3064\u3042\u308B\u304B\u3082\u3060\u3051\u3069\u3001\u898B\u308C\u306A\u3044\u3057\u3002\n\u307E\u3041\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB\u3067\u8DA3\u5473\u3042\u3048\u3070\u898B\u306A\u3044\u3067\u30D5\u30A9\u30ED\u30FC\u3059\u308B\u3053\u3068\u3082\u3042\u308B\u3051\u3069\u3055\u3001\u30D5\u30A9\u30ED\u30FC\u8FD4\u3057\u3066\u6B32\u3057\u3044\u306A\u3089\u3061\u3083\u3093\u3068\u66F8\u3044\u3066\u6B32\u3057\u3044\u306A\u3002",
  "id" : 125707818006355968,
  "created_at" : "2011-10-16 23:00:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125707023282221057",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 125707023282221057,
  "created_at" : "2011-10-16 22:57:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125706962884239362",
  "text" : "\u9375\u4ED8\u304D\u57A2\u3067bio\u77ED\u3044\u3068\u306A\u3093\u306B\u3082\u308F\u304B\u3093\u306A\u3044\u3067\u3059\u3088\u3046",
  "id" : 125706962884239362,
  "created_at" : "2011-10-16 22:57:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 0, 7 ],
      "id_str" : "50640629",
      "id" : 50640629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125570937394438144",
  "geo" : { },
  "id_str" : "125572172373692416",
  "in_reply_to_user_id" : 50640629,
  "text" : "@igaris \u30DF\u30B9\u30C9\u306E\u30C9\u30FC\u30CA\u30C4\u3067\u3059\u30FB\u30FB\u30FB\u52E2\u3044\u3067\u66F8\u3044\u3066\u3059\u307F\u307E\u305B\u3093",
  "id" : 125572172373692416,
  "in_reply_to_status_id" : 125570937394438144,
  "created_at" : "2011-10-16 14:01:53 +0000",
  "in_reply_to_screen_name" : "igaris",
  "in_reply_to_user_id_str" : "50640629",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125570723166167045",
  "text" : "\u3042\u3001\u30AF\u30EB\u30FC\u30E9\u30FC\u3060\u3063\u305Forz",
  "id" : 125570723166167045,
  "created_at" : "2011-10-16 13:56:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 15, 22 ],
      "id_str" : "50640629",
      "id" : 50640629
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 37, 44 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 59, 66 ],
      "id_str" : "50640629",
      "id" : 50640629
    }, {
      "name" : "api",
      "screen_name" : "TenApi",
      "indices" : [ 81, 88 ],
      "id_str" : "3240677334",
      "id" : 3240677334
    }, {
      "name" : "\u3044\u304C\u308A\u3059",
      "screen_name" : "igaris",
      "indices" : [ 103, 110 ],
      "id_str" : "50640629",
      "id" : 50640629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125570574415175680",
  "text" : "\u30D5\u30EC\u30F3\u30C1\u30D5\u30EB\u30FC\u30E9\u30FC\u30AD\u30B9 RT @igaris \u30D5\u30EC\u30F3\u30C1\u30DD\u30C3\u30D7\u30B9\u30AD\u30B9 RT @tenapi: \u30D5\u30EC\u30F3\u30C1\u30D5\u30E9\u30A4\u30AD\u30B9 RT @igaris: \u30D5\u30EC\u30F3\u30C1\u30B3\u30FC\u30C8\u30AD\u30B9 RT @tenapi: \u30D5\u30EC\u30F3\u30C1\u30DB\u30EB\u30F3\u30AD\u30B9 RT @igaris: \u30D5\u30EC\u30F3\u30C1\u30C8\u30FC\u30B9\u30C8\u30AD\u30B9",
  "id" : 125570574415175680,
  "created_at" : "2011-10-16 13:55:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    }, {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 11, 22 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125568321801293824",
  "geo" : { },
  "id_str" : "125569275497938944",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu @akiyohmori \u304A\u304A\u3082\u308A\u3042\u304D\u3088\u304C\u3084\u308B\u6C17\u306B\u306A\u3063\u305F\u3089\u5927\u5909\u3060\u3088\u306A\u30FC\uFF57\uFF57\u53C2\u8003\u306B\u306A\u308A\u305D\u3046\u306A\u5148\u8F29\u304C\u305F\u304F\u3055\u3093\u3044\u3066\u3042\u308A\u304C\u305F\u3044\u3053\u3068\u3067\u3059\u3002",
  "id" : 125569275497938944,
  "in_reply_to_status_id" : 125568321801293824,
  "created_at" : "2011-10-16 13:50:22 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B9\u30B1\u30FC\u30D1\u30FC",
      "screen_name" : "_ScApEr",
      "indices" : [ 3, 11 ],
      "id_str" : "226843343",
      "id" : 226843343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125566749918756864",
  "text" : "RT @_ScApEr: \u2460\u30A8\u30F3\u30C7\u30A3\u30F3\u30B0\u306E\u6B4C\u8A5E\u306F\u3001\u300C\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306F\u541B\u3055\u300D\u3068\u8A00\u3063\u3066\u3044\u308B\u3002\n\u2461\u30AA\u30FC\u30D7\u30CB\u30F3\u30B0\u306E\u6B4C\u8A5E\u306F\u3001\u300C\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306F\u611B\u3068\u52C7\u6C17\u3060\u3051\u304C\u53CB\u9054\u3055\u300D\u3068\u8A00\u3063\u3066\u3044\u308B\u3002\n\u2462\u4EE5\u4E0A\u3088\u308A\u3001\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306F\u6697\u306B\u300C\u541B\u306F\u53CB\u9054\u304C\u3044\u306A\u3044\u300D\u3068\u3044\u3063\u3066\u3044\u308B\u306E\u3060\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bit.ly\/UDldit\" rel=\"nofollow\"\u003ESaezuri\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125443489256312833",
    "text" : "\u2460\u30A8\u30F3\u30C7\u30A3\u30F3\u30B0\u306E\u6B4C\u8A5E\u306F\u3001\u300C\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306F\u541B\u3055\u300D\u3068\u8A00\u3063\u3066\u3044\u308B\u3002\n\u2461\u30AA\u30FC\u30D7\u30CB\u30F3\u30B0\u306E\u6B4C\u8A5E\u306F\u3001\u300C\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306F\u611B\u3068\u52C7\u6C17\u3060\u3051\u304C\u53CB\u9054\u3055\u300D\u3068\u8A00\u3063\u3066\u3044\u308B\u3002\n\u2462\u4EE5\u4E0A\u3088\u308A\u3001\u30A2\u30F3\u30D1\u30F3\u30DE\u30F3\u306F\u6697\u306B\u300C\u541B\u306F\u53CB\u9054\u304C\u3044\u306A\u3044\u300D\u3068\u3044\u3063\u3066\u3044\u308B\u306E\u3060\u3002",
    "id" : 125443489256312833,
    "created_at" : "2011-10-16 05:30:33 +0000",
    "user" : {
      "name" : "\u30B9\u30B1\u30FC\u30D1\u30FC",
      "screen_name" : "_ScApEr",
      "protected" : false,
      "id_str" : "226843343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1290499293\/2228552822_70b56cdb2b_b_normal.jpg",
      "id" : 226843343,
      "verified" : false
    }
  },
  "id" : 125566749918756864,
  "created_at" : "2011-10-16 13:40:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125557442208739329",
  "text" : "\u4ECA\u66F4\u7DDA\u578B\u306E\u6559\u79D1\u66F8\u898B\u8FD4\u3059\u3068\u4EE3\u6570\u5B66\u3068\u5E7E\u4F55\u5B66\uFF08\u591A\u69D8\u4F53\uFF09\u306E\u6388\u696D\u306E\u304A\u304B\u3052\u304B\u3059\u308B\u3059\u308B\u8AAD\u3081\u308B\u3002",
  "id" : 125557442208739329,
  "created_at" : "2011-10-16 13:03:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 0, 9 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125543768295358464",
  "geo" : { },
  "id_str" : "125544077671415808",
  "in_reply_to_user_id" : 150662260,
  "text" : "@isaribiz \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 125544077671415808,
  "in_reply_to_status_id" : 125543768295358464,
  "created_at" : "2011-10-16 12:10:15 +0000",
  "in_reply_to_screen_name" : "isaribiz",
  "in_reply_to_user_id_str" : "150662260",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125541832733102080",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 125541832733102080,
  "created_at" : "2011-10-16 12:01:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125536376346259456",
  "text" : "@nartakio \u3082\u3046\u305D\u3046\u3044\u3046\u6642\u03C7\u2019\u3068\u304B\u03C70\u3068\u304B\u66F8\u3044\u3061\u3083\u3044\u307E\u3059\u306D\u3047",
  "id" : 125536376346259456,
  "created_at" : "2011-10-16 11:39:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125530466047635456",
  "text" : "\u30D5\u30E9\u30F3\u30B9\u8A9E\u306F\u3042\u3068\u306F\u73FE\u5730\u3067\u3054\u308A\u62BC\u3057\u3059\u308B\u3002\n\u7DDA\u578B\u4EE3\u6570\u3068\u4EE3\u6570\uFF08\u2190\u3084\u3084\u3053\u3057\u3044\uFF09\u3084\u3089\u306A\u3044\u3068",
  "id" : 125530466047635456,
  "created_at" : "2011-10-16 11:16:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 0, 10 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125522375012913153",
  "geo" : { },
  "id_str" : "125522723408588800",
  "in_reply_to_user_id" : 102325414,
  "text" : "@blackVELU \u3044\u3048\u3044\u3048\u30FC\u3002\u8EFD\u3044\u6C17\u6301\u3061\u3067\u8A98\u3063\u3066\u307E\u3059\u306E\u3067\u304A\u6C17\u306B\u306A\u3055\u3089\u305A\u3002",
  "id" : 125522723408588800,
  "in_reply_to_status_id" : 125522375012913153,
  "created_at" : "2011-10-16 10:45:24 +0000",
  "in_reply_to_screen_name" : "blackVELU",
  "in_reply_to_user_id_str" : "102325414",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 0, 10 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125521884619083776",
  "geo" : { },
  "id_str" : "125522250899275776",
  "in_reply_to_user_id" : 102325414,
  "text" : "@blackVELU \u3042\u3089\u3089\u2026\u3058\u3083\u3042\u53B3\u3057\u305D\u3046\u3067\u3059\u306D",
  "id" : 125522250899275776,
  "in_reply_to_status_id" : 125521884619083776,
  "created_at" : "2011-10-16 10:43:31 +0000",
  "in_reply_to_screen_name" : "blackVELU",
  "in_reply_to_user_id_str" : "102325414",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 0, 10 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125521023268425729",
  "geo" : { },
  "id_str" : "125521782840111104",
  "in_reply_to_user_id" : 102325414,
  "text" : "@blackVELU\u3000\u4E00\u5FDC\u6708\u66DC\u306E\u653E\u8AB2\u5F8C\u306B\u3084\u308B\u3053\u3068\u306B\u306A\u3063\u3066\u308B\u3093\u3067\u3059\u304C\u2026\u6687\u3060\u3063\u305F\u3089\u4E00\u5EA6\u53C2\u52A0\u3057\u3066\u307F\u307E\u3059\uFF1F",
  "id" : 125521782840111104,
  "in_reply_to_status_id" : 125521023268425729,
  "created_at" : "2011-10-16 10:41:39 +0000",
  "in_reply_to_screen_name" : "blackVELU",
  "in_reply_to_user_id_str" : "102325414",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 0, 10 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125520609567457280",
  "geo" : { },
  "id_str" : "125520943132049408",
  "in_reply_to_user_id" : 102325414,
  "text" : "@blackVELU \u4ECA\u671F\u53CB\u4EBA\u3068\uFF12\u4EBA\u3067\u8907\u7D20\u95A2\u6570\u8AD6\u3082\u542B\u3081\u305F\u6570\u5B66\u30BC\u30DF\u3084\u3063\u305F\u308A\u3057\u3066\u307E\u3059\u304C\u3001\u8208\u5473\u3042\u308A\u307E\u3059\uFF1F",
  "id" : 125520943132049408,
  "in_reply_to_status_id" : 125520609567457280,
  "created_at" : "2011-10-16 10:38:19 +0000",
  "in_reply_to_screen_name" : "blackVELU",
  "in_reply_to_user_id_str" : "102325414",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 0, 10 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125520106427138050",
  "geo" : { },
  "id_str" : "125520479074258944",
  "in_reply_to_user_id" : 102325414,
  "text" : "@blackVELU \u304D\u3063\u3068\u51FA\u6765\u307E\u3059\uFF01\uFF08\u4E00\u56DE\u5F8C\u671F\u3067\u6388\u696D\u306B\u7A81\u6483\u3057\u3066\u5358\u4F4D\u3092\u843D\u3068\u3057\u305F\u6587\u5B66\u90E8\uFF12\u56DE\u751F\uFF09",
  "id" : 125520479074258944,
  "in_reply_to_status_id" : 125520106427138050,
  "created_at" : "2011-10-16 10:36:28 +0000",
  "in_reply_to_screen_name" : "blackVELU",
  "in_reply_to_user_id_str" : "102325414",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125519107721404416",
  "geo" : { },
  "id_str" : "125519785487372288",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30EC\u30D0\u30FC\u3082\u597D\u304D\u3060\u306A\u30FC\u3001\u30EC\u30D0\u30CB\u30E9\u3068\u304B\u98DF\u3079\u3066\u307F\u308C\u3070\uFF1F\n\u751F\u30EC\u30D0\u30FC\u304C\u30EC\u30A2\u306B\u306A\u3063\u3061\u3083\u3063\u3066\u60B2\u3057\u3044",
  "id" : 125519785487372288,
  "in_reply_to_status_id" : 125519107721404416,
  "created_at" : "2011-10-16 10:33:43 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125518186111184896",
  "text" : "\u6700\u8FD1\u306B\u306A\u3063\u3066\u9B8E\u3068\u304B\u79CB\u5200\u9B5A\u306E\u5185\u81D3\u306E\u7F8E\u5473\u3057\u3055\u304C\u89E3\u308B\u3088\u3046\u306B\u306A\u3063\u3066\u304D\u305F\u306A\u30FC\u3002\n\u3080\u304B\u3057\u304B\u3089\u30B5\u30B6\u30A8\u3068\u304B\u30A2\u30EF\u30D3\u306E\u30AD\u30E2\u306F\u597D\u304D\u3060\u3063\u305F\u3051\u308C\u3069\u3002",
  "id" : 125518186111184896,
  "created_at" : "2011-10-16 10:27:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125516402747645952",
  "geo" : { },
  "id_str" : "125516855145283585",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u6210\u7E3E\u306A\u3093\u3066\u4F4E\u4FD7\u306A\u6982\u5FF5\u306B\u3068\u3089\u308F\u308C\u3061\u3083\u3060\u3081\u3060\uFF08\u8FEB\u771F",
  "id" : 125516855145283585,
  "in_reply_to_status_id" : 125516402747645952,
  "created_at" : "2011-10-16 10:22:04 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125515473356996608",
  "text" : "\u89E3\u3063\u3061\u3083\u3044\u305F\u3051\u3069\u5CA9\u5869\u7F8E\u5473\uFF01",
  "id" : 125515473356996608,
  "created_at" : "2011-10-16 10:16:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125513811103989760",
  "geo" : { },
  "id_str" : "125514190038372353",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u30B3\u30F3\u30D1\u30AF\u30C8\u3068\u3044\u3046\u6570\u5B66\u7528\u8A9E\u306E\u305B\u3044\u3067\u4FFA\u306E\u4E2D\u3067\u306F\u30B3\u30F3\u30D1\u30AF\u30C8\u3068\u3044\u3046\u8A00\u8449\u3055\u3048\u3082\u30B3\u30F3\u30D1\u30AF\u30C8\u3067\u306F\u3042\u308A\u307E\u305B\u3093",
  "id" : 125514190038372353,
  "in_reply_to_status_id" : 125513811103989760,
  "created_at" : "2011-10-16 10:11:29 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/RTPjQFwo",
      "expanded_url" : "http:\/\/twitpic.com\/716dwy",
      "display_url" : "twitpic.com\/716dwy"
    } ]
  },
  "geo" : { },
  "id_str" : "125512587268988929",
  "text" : "\u79CB\u5200\u9B5A\uFF01 http:\/\/t.co\/RTPjQFwo",
  "id" : 125512587268988929,
  "created_at" : "2011-10-16 10:05:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ohta Nao",
      "screen_name" : "Ohtanao",
      "indices" : [ 3, 11 ],
      "id_str" : "151350196",
      "id" : 151350196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125511406605971456",
  "text" : "RT @Ohtanao: \u52E2\u3044\u3067\u5098\u3042\u3052\u305F\u3089\u3001\u96E8\u5F37\u3059\u304E\u3066\u5E30\u308C\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125191984632700928",
    "text" : "\u52E2\u3044\u3067\u5098\u3042\u3052\u305F\u3089\u3001\u96E8\u5F37\u3059\u304E\u3066\u5E30\u308C\u306A\u3044",
    "id" : 125191984632700928,
    "created_at" : "2011-10-15 12:51:09 +0000",
    "user" : {
      "name" : "Ohta Nao",
      "screen_name" : "Ohtanao",
      "protected" : false,
      "id_str" : "151350196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1723078697\/__12_normal.JPG",
      "id" : 151350196,
      "verified" : false
    }
  },
  "id" : 125511406605971456,
  "created_at" : "2011-10-16 10:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125507542758596608",
  "geo" : { },
  "id_str" : "125507919105097728",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u8A73\u7D30\u6C7A\u307E\u3063\u305F\u3089\u544A\u77E5\u3057\u3066\u304F\u3060\u3055\u3044\u306D\u30FC\u3002\u5185\u5BB9\u306B\u3064\u3044\u3066\u3044\u304F\u81EA\u4FE1\u306F\u7686\u7121\u3067\u3059\u304C\u898B\u306B\u884C\u304D\u307E\u3059\u306E\u3067\uFF57",
  "id" : 125507919105097728,
  "in_reply_to_status_id" : 125507542758596608,
  "created_at" : "2011-10-16 09:46:34 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125507427952099328",
  "text" : "\u7D50\u5C40\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u306E\u89E3\u6790\u306F\u4F55\u6642\u306B\u3069\u3053\u3067\u3084\u308B\u3093\u3067\u3057\u3087\u3046\u30FB\u30FB\u30FB\u30FB(\uFF81\uFF97\uFF6F",
  "id" : 125507427952099328,
  "created_at" : "2011-10-16 09:44:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125506621853016065",
  "geo" : { },
  "id_str" : "125506877634248704",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 125506877634248704,
  "in_reply_to_status_id" : 125506621853016065,
  "created_at" : "2011-10-16 09:42:26 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125504382392479744",
  "text" : "RT @dozaezop: \u3010\u65B0\u3057\u3044\u6570\u5B66\u7406\u8AD6\u306E\u3064\u304F\u308A\u304B\u305F\u3011\n\u2460\u307E\u305A\u5929\u624D\u3092\u7528\u610F\u3057\u307E\u3059\n\n\u3067\u304D\u3042\u304C\u308A\uFF01\uFF3C(o^\u2200^o)\uFF0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124395474345144321",
    "text" : "\u3010\u65B0\u3057\u3044\u6570\u5B66\u7406\u8AD6\u306E\u3064\u304F\u308A\u304B\u305F\u3011\n\u2460\u307E\u305A\u5929\u624D\u3092\u7528\u610F\u3057\u307E\u3059\n\n\u3067\u304D\u3042\u304C\u308A\uFF01\uFF3C(o^\u2200^o)\uFF0F",
    "id" : 124395474345144321,
    "created_at" : "2011-10-13 08:06:06 +0000",
    "user" : {
      "name" : "ezop",
      "screen_name" : "_ezop",
      "protected" : false,
      "id_str" : "178308981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492239477532663808\/YXEJVZ5k_normal.jpeg",
      "id" : 178308981,
      "verified" : false
    }
  },
  "id" : 125504382392479744,
  "created_at" : "2011-10-16 09:32:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125504315413630976",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u3001\u3053\u308C\u7D76\u5BFE\u5E73\u5747\u3068\u308B\u3093\u3060\u308D\u3046\u306A\u30FC\u3063\u3066\u30A2\u30F3\u30B1\u30FC\u30C8\u3067i\u3063\u3066\u66F8\u3044\u3066\u3084\u3063\u305F\u3053\u3068\u304C\u3042\u3063\u305F\u306A\u3002",
  "id" : 125504315413630976,
  "created_at" : "2011-10-16 09:32:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125498690772283392",
  "text" : "\u306B\u305B\u307B\u30CE\u30EA\u30CE\u30EA\u3067\u5439\u3044\u305F\uFF57\uFF57\uFF57",
  "id" : 125498690772283392,
  "created_at" : "2011-10-16 09:09:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 3, 15 ],
      "id_str" : "229754624",
      "id" : 229754624
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 17, 27 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125498613236371456",
  "text" : "RT @nisehorrrrn: @end313124 \uFF8A\uFF70\uFF72! \uFF1E ( | | )\u4E8C\u4E8C\u4E8C\u2283",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/halmidi.com\/doc\/nisehorn\/\" rel=\"nofollow\"\u003E\u306B\u305B\u307B\u8133\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "125498330297012224",
    "geo" : { },
    "id_str" : "125498568567037952",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \uFF8A\uFF70\uFF72! \uFF1E ( | | )\u4E8C\u4E8C\u4E8C\u2283",
    "id" : 125498568567037952,
    "in_reply_to_status_id" : 125498330297012224,
    "created_at" : "2011-10-16 09:09:25 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "protected" : false,
      "id_str" : "229754624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1196972020\/06-12-24_23-49_kisee2_normal.jpg",
      "id" : 229754624,
      "verified" : false
    }
  },
  "id" : 125498613236371456,
  "created_at" : "2011-10-16 09:09:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125498571763097600",
  "text" : "\u3055\u3066\u3001\u304A\u5915\u98EF\u306E\u70BA\u306B\u79CB\u5200\u9B5A\u3092\u8CB7\u3063\u3066\u304D\u305F\u3051\u3069\u3001\u4ECA\u306F\u304A\u8179\u6E1B\u3063\u3066\u306A\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\n\u307E\u3041\u3054\u98EF\u3060\u3051\u708A\u3044\u3066\u304A\u3044\u3066\u30D5\u30E9\u30F3\u30B9\u8A9E\u3042\u305F\u308A\u3092\u7247\u4ED8\u3051\u3066\u304B\u3089\u3086\u3063\u304F\u308A\u5869\u713C\u304D\u306B\u3059\u308B\u3068\u3057\u307E\u3059\u304B\u30FC\u3002",
  "id" : 125498571763097600,
  "created_at" : "2011-10-16 09:09:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125498330297012224",
  "text" : "\u30CB\u30E3\u30C3\u30AD\uFF01",
  "id" : 125498330297012224,
  "created_at" : "2011-10-16 09:08:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/1paZpMWK",
      "expanded_url" : "http:\/\/photozou.jp\/photo\/show\/1387281\/104013851",
      "display_url" : "photozou.jp\/photo\/show\/138\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "125498298063785984",
  "text" : "RT @rex343029: \u3053\u3000\u3044\u3000\u3064\u3000\u77E5\u3000\u3063\u3000\u3066\u3000\u308B\u3000\u4EBA\u3000\u516C\u3000\u5F0F\u3000R\u3000T http:\/\/t.co\/1paZpMWK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/1paZpMWK",
        "expanded_url" : "http:\/\/photozou.jp\/photo\/show\/1387281\/104013851",
        "display_url" : "photozou.jp\/photo\/show\/138\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "125495643329404928",
    "text" : "\u3053\u3000\u3044\u3000\u3064\u3000\u77E5\u3000\u3063\u3000\u3066\u3000\u308B\u3000\u4EBA\u3000\u516C\u3000\u5F0F\u3000R\u3000T http:\/\/t.co\/1paZpMWK",
    "id" : 125495643329404928,
    "created_at" : "2011-10-16 08:57:47 +0000",
    "user" : {
      "name" : "\u30CA\u30C3\u30C4\u6C0F@\u57A2\u8EE2\u751F \u30D7\u30ED\u30D5\u53C2\u7167",
      "screen_name" : "nats3430290",
      "protected" : false,
      "id_str" : "230738677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3452691536\/29b4fe7e8ce3e5f40fdbafa52d9742cc_normal.png",
      "id" : 230738677,
      "verified" : false
    }
  },
  "id" : 125498298063785984,
  "created_at" : "2011-10-16 09:08:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125469462580297728",
  "text" : "\u7136\u308B\u5F8C\u306B\u7DDA\u5F62\u4EE3\u6570\u3068\u4EE3\u6570\u3092\u3084\u308D\u3046\u3067\u306F\u306A\u3044\u304B",
  "id" : 125469462580297728,
  "created_at" : "2011-10-16 07:13:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125469325363642368",
  "text" : "\u82F1\u8A9E\u3068\u30D5\u30E9\u30F3\u30B9\u8A9E\u306E\u8AB2\u984C\u3092\u3084\u3063\u3064\u3051\u308B\uFF01",
  "id" : 125469325363642368,
  "created_at" : "2011-10-16 07:13:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B9\u30E9\u30B9\u30C6",
      "screen_name" : "slapstick123",
      "indices" : [ 3, 16 ],
      "id_str" : "137764483",
      "id" : 137764483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125450507660697601",
  "text" : "RT @slapstick123: \u54B2\u307F\u305F\u3044\u306A\u30AB\u30C3\u30C1\u30E7\u30A4\u30A4\u6F14\u51FA\u3059\u308C\u3070\u6570\u5B66\u30AC\u30FC\u30EB\u3082\u610F\u5473\u89E3\u3093\u306A\u304F\u3066\u3082\u611F\u52D5\u3059\u308B\u3068\u601D\u3046\u306E\u3067\u30A2\u30CB\u30E1\u5316\u3057\u3066\u6B32\u3057\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125400175161245697",
    "text" : "\u54B2\u307F\u305F\u3044\u306A\u30AB\u30C3\u30C1\u30E7\u30A4\u30A4\u6F14\u51FA\u3059\u308C\u3070\u6570\u5B66\u30AC\u30FC\u30EB\u3082\u610F\u5473\u89E3\u3093\u306A\u304F\u3066\u3082\u611F\u52D5\u3059\u308B\u3068\u601D\u3046\u306E\u3067\u30A2\u30CB\u30E1\u5316\u3057\u3066\u6B32\u3057\u3044",
    "id" : 125400175161245697,
    "created_at" : "2011-10-16 02:38:26 +0000",
    "user" : {
      "name" : "\u30B9\u30E9\u30B9\u30C6",
      "screen_name" : "slapstick123",
      "protected" : false,
      "id_str" : "137764483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432410465063288832\/DvKo3hH0_normal.png",
      "id" : 137764483,
      "verified" : false
    }
  },
  "id" : 125450507660697601,
  "created_at" : "2011-10-16 05:58:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 0, 10 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125427218758373376",
  "geo" : { },
  "id_str" : "125427587358007296",
  "in_reply_to_user_id" : 133376125,
  "text" : "@blackpiyu \u5927\u5B66\u304B\u3089\u9060\u304F\u3066\u3082\u732B\u3092\u98FC\u3048\u308B\u4E0B\u5BBF\u306B\u5F15\u3063\u8D8A\u305D\u3046\u304B\u3068\u3061\u3087\u3063\u3068\u8003\u3048\u308B\u4F4D\u306B\u306F\u5927\u597D\u304D\uFF01",
  "id" : 125427587358007296,
  "in_reply_to_status_id" : 125427218758373376,
  "created_at" : "2011-10-16 04:27:21 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 0, 10 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125426482381197313",
  "geo" : { },
  "id_str" : "125427292171288576",
  "in_reply_to_user_id" : 126326979,
  "text" : "@Keitaecon \u50D5\u3082\u3042\u3093\u307E\u308A\u597D\u304D\u3058\u3083\u306A\u3044\u3067\u3059\u3002\u796D\u305D\u306E\u3082\u306E\u304C\u3001\u3068\u3044\u3046\u3088\u308A\u306F\u9A12\u3050\u305F\u3081\u306B\u9A12\u3044\u3067\u308B\u5974\u304C\u3001\u304B\u3082\u3067\u3059\u304C\u3002",
  "id" : 125427292171288576,
  "in_reply_to_status_id" : 125426482381197313,
  "created_at" : "2011-10-16 04:26:11 +0000",
  "in_reply_to_screen_name" : "Keitaecon",
  "in_reply_to_user_id_str" : "126326979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125426358003302400",
  "text" : "\u5E03\u56E3\u304B\u3089\u51FA\u308B\u3068\u3053\u308D\u304B\u3089\u59CB\u3081\u3088\u3046",
  "id" : 125426358003302400,
  "created_at" : "2011-10-16 04:22:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125425460229324801",
  "geo" : { },
  "id_str" : "125425837037199360",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u3061\u3083\u3093\u3068\u8D77\u304D\u308C\u305F\u304B\u3089\u9664\u3044\u305F\u2190",
  "id" : 125425837037199360,
  "in_reply_to_status_id" : 125425460229324801,
  "created_at" : "2011-10-16 04:20:24 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125425695097753600",
  "text" : "\u7B2C\u96F6\u8A00\u8A9E\u306F\u6570\u5B66\u8A9E\n\u7B2C\u4E00\u8A00\u8A9E\u306F\u65E5\u672C\u8A9E\n\u7B2C\u4E8C\u8A00\u8A9E\u306F\uFF23\n\u7B2C\u4E09\u8A00\u8A9E\u306F\u82F1\u8A9E",
  "id" : 125425695097753600,
  "created_at" : "2011-10-16 04:19:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125425179877842945",
  "text" : "\u8CB7\u3044\u7269\u3001\u6383\u9664\u3001\u6D17\u3044\u7269\u3001\u82F1\u8A9E\u3001\u82F1\u8A9E\u3001\u30D5\u30E9\u30F3\u30B9\u8A9E\u3001\u4EE3\u6570\u3001\u7DDA\u5F62\u4EE3\u6570\u2026\n\u3042\u308C\u3001\u4F11\u65E5\u306A\u306E\u306B\u4F11\u3081\u306A\u3055\u305D\u3046",
  "id" : 125425179877842945,
  "created_at" : "2011-10-16 04:17:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 14, 24 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/yr7lRHAm",
      "expanded_url" : "http:\/\/twitter.com\/blackpiyu\/status\/125423879488409600\/photo\/1",
      "display_url" : "pic.twitter.com\/yr7lRHAm"
    } ]
  },
  "in_reply_to_status_id_str" : "125423879488409600",
  "geo" : { },
  "id_str" : "125424241725280257",
  "in_reply_to_user_id" : 133376125,
  "text" : "\u6BCE\u56DE\u53EF\u611B\u304F\u3066\u548C\u3080\u308F\u30FC QT @blackpiyu: \u65B0\u805E\u8AAD\u3093\u3067\u308B\u306E\u306B\u30FC\u2026\n\n\u3053\u3053\u3082\u3001\u843D\u3061\u304F\u3093\u3060\u306B\u3083\u30FC http:\/\/t.co\/yr7lRHAm",
  "id" : 125424241725280257,
  "in_reply_to_status_id" : 125423879488409600,
  "created_at" : "2011-10-16 04:14:04 +0000",
  "in_reply_to_screen_name" : "blackpiyu",
  "in_reply_to_user_id_str" : "133376125",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 3, 13 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/blackpiyu\/status\/125423879488409600\/photo\/1",
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/YeyHdoyX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ab2YWpdCEAEucMv.jpg",
      "id_str" : "125423879488409601",
      "id" : 125423879488409601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ab2YWpdCEAEucMv.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YeyHdoyX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125424074380943360",
  "text" : "RT @blackpiyu: \u65B0\u805E\u8AAD\u3093\u3067\u308B\u306E\u306B\u30FC\u2026\n\n\u3053\u3053\u3082\u3001\u843D\u3061\u304F\u3093\u3060\u306B\u3083\u30FC http:\/\/t.co\/YeyHdoyX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/blackpiyu\/status\/125423879488409600\/photo\/1",
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/YeyHdoyX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ab2YWpdCEAEucMv.jpg",
        "id_str" : "125423879488409601",
        "id" : 125423879488409601,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ab2YWpdCEAEucMv.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/YeyHdoyX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125423879488409600",
    "text" : "\u65B0\u805E\u8AAD\u3093\u3067\u308B\u306E\u306B\u30FC\u2026\n\n\u3053\u3053\u3082\u3001\u843D\u3061\u304F\u3093\u3060\u306B\u3083\u30FC http:\/\/t.co\/YeyHdoyX",
    "id" : 125423879488409600,
    "created_at" : "2011-10-16 04:12:38 +0000",
    "user" : {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "protected" : true,
      "id_str" : "133376125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513499671176556545\/FfEMKZYN_normal.jpeg",
      "id" : 133376125,
      "verified" : false
    }
  },
  "id" : 125424074380943360,
  "created_at" : "2011-10-16 04:13:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125423394408763392",
  "geo" : { },
  "id_str" : "125423824828243968",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 \u5F37\u3044\u3066\u8A00\u3048\u3070\u6700\u5F8C\u9664\u3044\u3066\u5408\u6210\u6570\uFF08\u7D20\u6570\u3067\u306A\u3044\u6570\uFF09\u304B\u306A\u30FC",
  "id" : 125423824828243968,
  "in_reply_to_status_id" : 125423394408763392,
  "created_at" : "2011-10-16 04:12:24 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sigmapsi",
      "screen_name" : "sigmapsi",
      "indices" : [ 0, 9 ],
      "id_str" : "22502063",
      "id" : 22502063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125422666881581056",
  "geo" : { },
  "id_str" : "125423165496229888",
  "in_reply_to_user_id" : 22502063,
  "text" : "@sigmapsi \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 125423165496229888,
  "in_reply_to_status_id" : 125422666881581056,
  "created_at" : "2011-10-16 04:09:47 +0000",
  "in_reply_to_screen_name" : "sigmapsi",
  "in_reply_to_user_id_str" : "22502063",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125423079739498496",
  "text" : "6\u6642\u30018\u6642\u30019\u6642\u300110\u6642\u300113\u6642\u306B\u8D77\u304D\u305F\u3002\n\u3046\u306A\u30FC\u3002",
  "id" : 125423079739498496,
  "created_at" : "2011-10-16 04:09:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DE\u30B5\u30E4\u30F3",
      "screen_name" : "masayan24",
      "indices" : [ 3, 13 ],
      "id_str" : "80728960",
      "id" : 80728960
    }, {
      "name" : "\u3074\u3087\u3093\u3055\u3093\u3058\u3085\u3046\u304D\u3085\u3046\u3055\u3044",
      "screen_name" : "n_scattering",
      "indices" : [ 44, 57 ],
      "id_str" : "78584941",
      "id" : 78584941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125422803716550657",
  "text" : "RT @MasaYan24: \u8907\u7D20\u6570\u306B\u306F\u611B\u304C\u3042\u308B\u3063\u3066\u3001\u5B66\u751F\u304C\u53C8\u805E\u304D\u3067\u8A00\u3063\u3066\u307E\u3057\u305F\u3002\n\n\u201C@n_scattering: \u30EA\u30A2\u5145(\u30EA\u30A2\u30EB(\u5B9F\u6570)\u3067\u5145\u5206\u306A\u4EBA)&lt;\u30B3\u30F3\u30D7\u30EC\u30C3\u30AF\u30B9(\u8907\u7D20\u6570\u304C\u5FC5\u8981\u306A\u4EBA)\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3074\u3087\u3093\u3055\u3093\u3058\u3085\u3046\u304D\u3085\u3046\u3055\u3044",
        "screen_name" : "n_scattering",
        "indices" : [ 29, 42 ],
        "id_str" : "78584941",
        "id" : 78584941
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125420875649523712",
    "text" : "\u8907\u7D20\u6570\u306B\u306F\u611B\u304C\u3042\u308B\u3063\u3066\u3001\u5B66\u751F\u304C\u53C8\u805E\u304D\u3067\u8A00\u3063\u3066\u307E\u3057\u305F\u3002\n\n\u201C@n_scattering: \u30EA\u30A2\u5145(\u30EA\u30A2\u30EB(\u5B9F\u6570)\u3067\u5145\u5206\u306A\u4EBA)&lt;\u30B3\u30F3\u30D7\u30EC\u30C3\u30AF\u30B9(\u8907\u7D20\u6570\u304C\u5FC5\u8981\u306A\u4EBA)\u201D",
    "id" : 125420875649523712,
    "created_at" : "2011-10-16 04:00:41 +0000",
    "user" : {
      "name" : "\u30DE\u30B5\u30E4\u30F3",
      "screen_name" : "masayan24",
      "protected" : false,
      "id_str" : "80728960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000757836871\/c1d3d6a69e8764d24f8aa50515d4a360_normal.png",
      "id" : 80728960,
      "verified" : false
    }
  },
  "id" : 125422803716550657,
  "created_at" : "2011-10-16 04:08:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125251862545965056",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 125251862545965056,
  "created_at" : "2011-10-15 16:49:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125226696537419777",
  "text" : "\u5F85\u3066\u3088\u2026\u201D\u4E16\u754C\u53F2\u306F\u6700\u521D\u304B\u3089\u899A\u3048\u3066\u306A\u304B\u3063\u305F\u201D\u3068\u8003\u3048\u308C\u3070\u5F53\u7136\u2026\u3063\u3066\u3082\u3063\u3068\u30C0\u30E1\u3058\u3083\u3093\u304B\uFF01",
  "id" : 125226696537419777,
  "created_at" : "2011-10-15 15:09:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125226398813134848",
  "text" : "\u826F\u304F\u8003\u3048\u305F\u3089\u4E16\u754C\u53F2\u899A\u3048\u3066\u307E\u305B\u3093\u3054\u3081\u3093\u306A\u3055\u3044\u3002",
  "id" : 125226398813134848,
  "created_at" : "2011-10-15 15:07:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125226329493876736",
  "text" : "\u307E\u3041\u3001\u6587\u5B66\u90E8\u3067\u6A2A\u30D9\u30AF\u30C8\u30EB\u306E\u8AAC\u660E\u304C\u5FC5\u8981\u306B\u306A\u308B\u3063\u3066\u306E\u3082\u304A\u304B\u3057\u3044\u3068\u601D\u3046\u3093\u3060\u3051\u3069\u3002\u3044\u3084\u3001\u6587\u5B66\u90E8\u306E\u6388\u696D\u306A\u306E\u306B\u3001\u3063\u3066\u610F\u5473\u3058\u3083\u306A\u304F\u3066\u3001\u6587\u5B66\u90E8\u306E\u6388\u696D\u3067\u3082\u53D7\u9A13\u306E\u6642\u306B\u30D9\u30AF\u30C8\u30EB\u306F\u5FC5\u4FEE\u306A\u3093\u3060\u304B\u3089\u899A\u3048\u3066\u3066\u5F53\u7136\u3060\u308D\u7684\u306A\u610F\u5473\u5408\u3044\u3067\u3002",
  "id" : 125226329493876736,
  "created_at" : "2011-10-15 15:07:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125225857173299200",
  "text" : "\u6C17\u6301\u3061\u60AA\u3044\u3063\u3066\u7A0B\u3058\u3083\u306A\u3044\u3093\u3060\u3051\u3069\u3001\u6587\u5B66\u90E8\u306E\u6559\u6388\u304C\u6A2A\u30D9\u30AF\u30C8\u30EB\u306E\u8AAC\u660E\u3092\u3059\u308B\u306E\u306B\n\uFF08a\u3001b\uFF09\u3063\u3066\u66F8\u3044\u3066\u3066\u3001\n\uFF08x0\u3001x1\uFF09\u3067\u66F8\u304B\u306A\u3044\u4E8B\u306B\u9055\u548C\u611F\u3092\u899A\u3048\u305F\u306A\u30FC\u3002",
  "id" : 125225857173299200,
  "created_at" : "2011-10-15 15:05:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125225212106129408",
  "text" : "\u300C\u3062\u300D\u3001\u3068\u304B\u300C\u308E\u300D\u3068\u304B\u3067\u66F8\u304B\u308C\u305F\u6587\u7AE0\u3063\u3066\u6C17\u6301\u3061\u60AA\u3044\u3068\u601D\u3063\u3066\u308B\u3002",
  "id" : 125225212106129408,
  "created_at" : "2011-10-15 15:03:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125224882605793280",
  "text" : "\u306A\u3093\u304B\u3041\u3001\u3055\u3044\u304D\u3093\u304B\u308C\u3057\u304C\u304B\u307E\u3063\u3066\u304F\u308C\u306A\u304F\u3066\u3047\u3001\u3061\u3087\u3046\u3055\u307F\u3057\u3044\u3093\u3067\u3059\u3088\u306D\u3047\u3002\u3093\u3067\u3047\u3001\u3055\u3044\u304D\u3093\u304B\u307E\u3063\u3066\u304F\u308C\u306A\u3044\u3058\u3083\u3093\u3063\u3066\u3044\u3063\u305F\u3089\u3041\u3001\u3042\u3044\u3064\u3001\u304D\u3085\u3046\u306B\u65E5\u672C\u8A9E\u3067\u3057\u3083\u3079\u308C\u3068\u304B\u3044\u3044\u3060\u3057\u3066\u3047\u3001\u307E\u3058\u3044\u307F\u3075\u3063\u3066\u304B\u3093\u3058\u3002 \n\u3069\u3046\u3044\u3046\u308F\u3051\u304B\u3055\u3089\u3063\u3068\u8AAD\u3081\u305F\u3051\u3069\u306A\u3093\u3060\u3053\u306E\u865A\u7121\u611F\u3002",
  "id" : 125224882605793280,
  "created_at" : "2011-10-15 15:01:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3077\u308A\u306B\u3043",
      "screen_name" : "nauticfish",
      "indices" : [ 3, 14 ],
      "id_str" : "64721393",
      "id" : 64721393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125224781749563393",
  "text" : "RT @nauticfish: \u8AB0\u304B\u8A33\u305B\uFF57 \uFF32\uFF34 \uFF62\uFF85\u3087\u03C9\u30F5\u3041\u3001\u00B1\u3043\u2260\u03C9\u30F5\u2228\u30B7\u30F5\"\u30F5\u307E\u30C3\u3012\uFF1C\u308C\uFF85\u3087\uFF1C\u3012\u3047\u3001\u3061\u3087\u3045\u00B1\u3090\u222A\u3043\u03C9\u3067\uFF7D\u3087\u306D\u3047\u3002\u03C9\u3067\u3047\u3001\u00B1\u3043\u2260\u03C9\u30F5\u307E\u30C3\u3012\uFF1C\u308C\uFF85\u3087\u3043\u3062\u3083\u03C9\u30C3\u3066\u3086\u30C3\uFF85\uFF1D\u3089\u3041\u3001\u3041\u3043\u3063\u2260\u3085\u3045\uFF5C\uFF1D\u30A3\u3001\u65E5\u672C\u8A9E\u3067\u3057\u3083\u3079\u308C \u3068\u30F5\u3043\u3043\uFF85\uFF1D\u309B\u222A\u3012\u30A7\u3001\u307E\uFF81\uFF9E\u30A3\u3090\uFF8C\u30C3\u3012\u30F5\uFF9D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67905879357407232",
    "text" : "\u8AB0\u304B\u8A33\u305B\uFF57 \uFF32\uFF34 \uFF62\uFF85\u3087\u03C9\u30F5\u3041\u3001\u00B1\u3043\u2260\u03C9\u30F5\u2228\u30B7\u30F5\"\u30F5\u307E\u30C3\u3012\uFF1C\u308C\uFF85\u3087\uFF1C\u3012\u3047\u3001\u3061\u3087\u3045\u00B1\u3090\u222A\u3043\u03C9\u3067\uFF7D\u3087\u306D\u3047\u3002\u03C9\u3067\u3047\u3001\u00B1\u3043\u2260\u03C9\u30F5\u307E\u30C3\u3012\uFF1C\u308C\uFF85\u3087\u3043\u3062\u3083\u03C9\u30C3\u3066\u3086\u30C3\uFF85\uFF1D\u3089\u3041\u3001\u3041\u3043\u3063\u2260\u3085\u3045\uFF5C\uFF1D\u30A3\u3001\u65E5\u672C\u8A9E\u3067\u3057\u3083\u3079\u308C \u3068\u30F5\u3043\u3043\uFF85\uFF1D\u309B\u222A\u3012\u30A7\u3001\u307E\uFF81\uFF9E\u30A3\u3090\uFF8C\u30C3\u3012\u30F5\uFF9D\uFF81\uFF9E\uFF1F\uFF63\u2190\u8AAD\u3081\u305F\u3089\uFF32\uFF34",
    "id" : 67905879357407232,
    "created_at" : "2011-05-10 10:56:37 +0000",
    "user" : {
      "name" : "\u3077\u308A\u306B\u3043",
      "screen_name" : "nauticfish",
      "protected" : false,
      "id_str" : "64721393",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1711674110\/d073310c-e34c-4719-b22b-305bf85fbe27_normal.jpg",
      "id" : 64721393,
      "verified" : false
    }
  },
  "id" : 125224781749563393,
  "created_at" : "2011-10-15 15:01:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125224047821860865",
  "text" : "\u4E0B\u306E\u540D\u524D\u3067\u547C\u3093\u3067\u304F\u308C\u308B\u4EBA\u306F\u5C11\u306A\u3044\u3051\u308C\u3069\u3001\u4E00\u5B9A\u6570\u5C45\u3066\u304F\u308C\u308B\u3002\n\u305D\u3093\u306A\u306B\u6C17\u306B\u5165\u3063\u3066\u3044\u306A\u3044\u3068\u306F\u3044\u3048\u3001\u4E0B\u306E\u540D\u524D\u805E\u304B\u308C\u3066\u300C\u25CB\u25CB\u300D\u3068\u7B54\u3048\u305F\u3089\u300C\u25CB\u25CB\u3063\u307D\u304F\u306A\u3044\u300D\u3068\u3044\u308F\u308C\u305F\u3068\u304D\u306F\u3061\u3087\u3063\u3068\u5207\u306A\u304B\u3063\u305F\u306A\u30FC\u3002",
  "id" : 125224047821860865,
  "created_at" : "2011-10-15 14:58:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125223365786075136",
  "text" : "\u81EA\u5206\u306E\u4E0B\u306E\u540D\u524D\u306F\u305D\u3053\u307E\u3067\u597D\u304D\u3058\u3083\u306A\u3044\u3051\u308C\u3069\u3001\u540D\u524D\u8CA0\u3051\u3059\u308B\u3067\u3082\u306A\u3044\u3057\u3001\u5206\u76F8\u5FDC\u306A\u3093\u3060\u308D\u3046\u3051\u308C\u3069\u3002\u9006\u306B\u4F55\u306A\u3089\u826F\u304B\u3063\u305F\u3068\u8A00\u3048\u306A\u3044\u3057\u3002",
  "id" : 125223365786075136,
  "created_at" : "2011-10-15 14:55:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125222838444638209",
  "text" : "\u540D\u524D\u304C\u597D\u304D\u306A\u3089\u305D\u306E\u4EBA\u304C\u597D\u304D\u3063\u3066\u306E\u3082\u4E00\u5BFE\u4E00\u5BFE\u5FDC\u3057\u306A\u3044\u3051\u3069\u306A\u30FC\u3002\u307E\u3041\u5370\u8C61\u3068\u3057\u3066\u597D\u304D\u306B\u306A\u308A\u3084\u3059\u3044\u3063\u3066\u306E\u306F\u3042\u308B\u3051\u308C\u3069\u3002",
  "id" : 125222838444638209,
  "created_at" : "2011-10-15 14:53:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125222060791308288",
  "text" : "\u6F22\u5B57\u3068\u3072\u3089\u304C\u306A\u3067\u3082\u5370\u8C61\u9055\u3046\u3088\u306A\u30FC\u3002\u3086\u304B\u308A\u3068\u7D2B\u3058\u3083\u5370\u8C61\u304C\u3002",
  "id" : 125222060791308288,
  "created_at" : "2011-10-15 14:50:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125221730435342336",
  "text" : "\u53CC\u5009\u30EA\u30B5\u3001\u516B\u96F2\u7D2B\u3001\u5FCD\u91CE\u5FCD\u3001\u5B89\u85E4\u308A\u3093\u3054\u3001\u7396\u6E1A\u53CB\u3042\u305F\u308A\u306E\u540D\u524D\u306F\u597D\u304D\u3060\u306A\n\u4E0B\u306E\u540D\u524D\u304C\u597D\u304D\u306A\u306E\u304B\u3082\u3002",
  "id" : 125221730435342336,
  "created_at" : "2011-10-15 14:49:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125219270178250754",
  "text" : "\u597D\u304D\u5ACC\u3044\u306B\u3064\u3044\u3066\u7A76\u6975\u7684\u306B\u305D\u306E\u7406\u7531\u306F\u8AAC\u660E\u3067\u304D\u306A\u3044\u3001\u3068\u3061\u3087\u3063\u3068\u601D\u3063\u3066\u3044\u308B\u3002",
  "id" : 125219270178250754,
  "created_at" : "2011-10-15 14:39:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125218440238735361",
  "text" : "\u9CF4\u6EDD\u3055\u3093\u306E\u540D\u524D\u840C\u3048\u307F\u305F\u3044\u306E\u3061\u3087\u3063\u3068\u7406\u89E3\u3067\u304D\u308B\u306A\u30FC\u3002\u5B8C\u5168\u306B\u611F\u899A\u3067\u4F53\u7CFB\u7ACB\u3063\u3066\u306A\u3044\u3057\u3001\u8AAC\u660E\u306A\u3093\u3066\u3067\u304D\u306A\u3044\u3051\u308C\u3069\u3002",
  "id" : 125218440238735361,
  "created_at" : "2011-10-15 14:36:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AA\u30C4\u30AB\u30EC\u3000\u30CE\u30F4\u30A1",
      "screen_name" : "Tired_Nova",
      "indices" : [ 3, 14 ],
      "id_str" : "119994574",
      "id" : 119994574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/AC0FDCte",
      "expanded_url" : "http:\/\/twitpic.com\/70hwx9",
      "display_url" : "twitpic.com\/70hwx9"
    } ]
  },
  "geo" : { },
  "id_str" : "125216991811338240",
  "text" : "RT @Tired_Nova: \u3059\u3054\u30FC\u3044 http:\/\/t.co\/AC0FDCte",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 5, 25 ],
        "url" : "http:\/\/t.co\/AC0FDCte",
        "expanded_url" : "http:\/\/twitpic.com\/70hwx9",
        "display_url" : "twitpic.com\/70hwx9"
      } ]
    },
    "geo" : { },
    "id_str" : "125083098227556352",
    "text" : "\u3059\u3054\u30FC\u3044 http:\/\/t.co\/AC0FDCte",
    "id" : 125083098227556352,
    "created_at" : "2011-10-15 05:38:29 +0000",
    "user" : {
      "name" : "\u30AA\u30C4\u30AB\u30EC\u3000\u30CE\u30F4\u30A1",
      "screen_name" : "Tired_Nova",
      "protected" : false,
      "id_str" : "119994574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1147219298\/nyan_normal.jpg",
      "id" : 119994574,
      "verified" : false
    }
  },
  "id" : 125216991811338240,
  "created_at" : "2011-10-15 14:30:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125213926576234496",
  "text" : "\u62EC\u5F27\u306E\u4ED8\u3051\u65B9\u304C\u30B9\u30DE\u30FC\u30C8\u3058\u3083\u306A\u3044\u306A\u3002\u307E\u3041\u30C9\u30F3\u30DE\u30A4\u3002",
  "id" : 125213926576234496,
  "created_at" : "2011-10-15 14:18:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125213763300368386",
  "text" : "\u96F6\uFF08\u5D0E\uFF09\u4EBA\u8B58\uFF08\u7B49\u3057\u304D\uFF09\uFF1D\u3044\u30FC\u3061\u3083\u3093\uFF08\uFF11\uFF09\u3001\u3067\uFF10\uFF1D\uFF11\u3092\u8868\u73FE\u3057\u3066\u305F\u308A\u3002",
  "id" : 125213763300368386,
  "created_at" : "2011-10-15 14:17:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125213278900207616",
  "text" : "\u897F\u5C3E\u5148\u751F\u306F\u30AD\u30E3\u30E9\u306E\u540D\u524D\u304C\u7279\u5FB4\u7684\u3060\u3088\u306A\u30FC\u3002\u9762\u767D\u3044\u3051\u3069\u3002",
  "id" : 125213278900207616,
  "created_at" : "2011-10-15 14:15:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125211914639917056",
  "text" : "@nartakio \u3042\u3001\u3054\u5B58\u77E5\u3067\u3057\u305F\u304B\u3002\u307B\u3068\u3093\u3069\u8A00\u3063\u3066\u898B\u305F\u3060\u3051\u3067\u3059\u3051\u3069\u306D\uFF57",
  "id" : 125211914639917056,
  "created_at" : "2011-10-15 14:10:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 0, 9 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125211601560285184",
  "text" : "@nartakio \u300C\u306A\u306A\u306A\u306A\u307F\u306A\u306A\u307F\u300D\u3068\u3044\u3046\u30AD\u30E3\u30E9\u304C\u5C45\u307E\u3059\u306D",
  "id" : 125211601560285184,
  "created_at" : "2011-10-15 14:09:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125211288040259584",
  "text" : "\u3044\u3055\u308A\u3093\u3055\u3093\u306B\u3064\u3089\u308C\u305F\u3068\u307F\u3066\u3044\u3044\u306E\u3060\u308D\u3046\u304B\u3002\u5F7C\u306E\u30C4\u30A4\u30FC\u30C8\u3092\u898B\u3066\u9061\u3063\u3066\u307F\u305F\u3089\uFF11\uFF10\uFF0F\uFF15\u3000\uFF12\uFF13\u6642\u306E\u306B\u305B\u307B\u30FC\u3060\u3063\u305F\u3002",
  "id" : 125211288040259584,
  "created_at" : "2011-10-15 14:07:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125210778826588160",
  "text" : "\u3042\u3001\u3064\u3089\u308C\u305F\u3002\u507D\u307B\u30FC\u3060\u3063\u305Forz",
  "id" : 125210778826588160,
  "created_at" : "2011-10-15 14:05:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u3068\u308B",
      "screen_name" : "senakick",
      "indices" : [ 3, 12 ],
      "id_str" : "47020664",
      "id" : 47020664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125210357030600704",
  "text" : "RT @senakick: \u5148\u307B\u3069\u3001\u30D0\u30B9\u306E\u964D\u8ECA\u30DC\u30BF\u30F3\u3092\u62BC\u3057\u305F\u3089\u3001\u898B\u305A\u77E5\u3089\u305A\u306E\u82E5\u8005\u304C\u7A81\u7136\u300C\u8D8A\u5F8C\u88FD\u83D3\uFF01\u300D\u3068\u53EB\u3073\u3001\u8ECA\u5185\u306F\u30AF\u30B9\u30AF\u30B9\u7B11\u3044\u306E\u6E26\u3002\u305D\u308C\u3092\u898B\u305F\u50D5\u306F\u300C\u304A\u524D\u306E\u7B11\u3044\u304C\u901A\u7528\u3059\u308B\u306E\u306F\u30EA\u30A2\u30EB\u3060\u3051\u3002\u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u30B7\u30D3\u30A2\u3060\u304B\u3089\u306A\uFF01\u300D\u3068\u601D\u3063\u3066\u6B6F\u304E\u3057\u308A\u3057\u305F\u3093\u3060\u3051\u3069\u3001\u6094\u3057\u3055\u304C\u304A\u3055\u307E\u3063\u305F\u9803\u306B\u3075\u3068\u6C17 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125209960094240770",
    "text" : "\u5148\u307B\u3069\u3001\u30D0\u30B9\u306E\u964D\u8ECA\u30DC\u30BF\u30F3\u3092\u62BC\u3057\u305F\u3089\u3001\u898B\u305A\u77E5\u3089\u305A\u306E\u82E5\u8005\u304C\u7A81\u7136\u300C\u8D8A\u5F8C\u88FD\u83D3\uFF01\u300D\u3068\u53EB\u3073\u3001\u8ECA\u5185\u306F\u30AF\u30B9\u30AF\u30B9\u7B11\u3044\u306E\u6E26\u3002\u305D\u308C\u3092\u898B\u305F\u50D5\u306F\u300C\u304A\u524D\u306E\u7B11\u3044\u304C\u901A\u7528\u3059\u308B\u306E\u306F\u30EA\u30A2\u30EB\u3060\u3051\u3002\u30C4\u30A4\u30C3\u30BF\u30FC\u306F\u30B7\u30D3\u30A2\u3060\u304B\u3089\u306A\uFF01\u300D\u3068\u601D\u3063\u3066\u6B6F\u304E\u3057\u308A\u3057\u305F\u3093\u3060\u3051\u3069\u3001\u6094\u3057\u3055\u304C\u304A\u3055\u307E\u3063\u305F\u9803\u306B\u3075\u3068\u6C17\u3065\u3044\u305F\u306E\u3002\u300C\u964D\u308A\u308B\u306E\u5FD8\u308C\u3066\u305F\u300D\u3063\u3066\u3002",
    "id" : 125209960094240770,
    "created_at" : "2011-10-15 14:02:35 +0000",
    "user" : {
      "name" : "\u3055\u3068\u308B",
      "screen_name" : "senakick",
      "protected" : false,
      "id_str" : "47020664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606819505\/s-051206_1925_01_normal.jpg",
      "id" : 47020664,
      "verified" : false
    }
  },
  "id" : 125210357030600704,
  "created_at" : "2011-10-15 14:04:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125210201195413504",
  "text" : "\u53D6\u5F97\u6F0F\u308C\u306A\u306E\u304B\u306B\u305B\u307B\u30FC\u898B\u3048\u306A\u304B\u3063\u305F\u3002\u307E\u3041TL\u3067\u5224\u65AD\u3067\u304D\u308B\u3051\u3069\u3002",
  "id" : 125210201195413504,
  "created_at" : "2011-10-15 14:03:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121585497838587905",
  "geo" : { },
  "id_str" : "125209986925211649",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u306B\u305B\u307B\u30FC",
  "id" : 125209986925211649,
  "in_reply_to_status_id" : 121585497838587905,
  "created_at" : "2011-10-15 14:02:41 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125209762051788800",
  "text" : "\u308A\u3093\u3054\u3061\u3083\u3093\u306F\u30B7\u30E5\u30EC\u30EA\u30F3\u30AC\u30FC\u97F3\u982D\u306E\u4E00\u90E8\u3092\u9023\u9396\u30DC\u30A4\u30B9\u306B\u3057\u3066\u308B\u3068\u8003\u3048\u308B\u3068\u30B7\u30E5\u30FC\u30EB\u3002\u2026\u30B5\u30A4\u30F3\u3001\u30B3\u30B5\u30A4\u30F3\u3001\u30BF\u30F3\u30B8\u30A7\u30F3\u30C8\u3002",
  "id" : 125209762051788800,
  "created_at" : "2011-10-15 14:01:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u521D\u3081\u3066lv100\u306B\u3057\u305F\u30DD\u30B1\u30E2\u30F3",
      "indices" : [ 19, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125209314813161472",
  "text" : "\u672A\u3060\u306B\u899A\u3048\u3066\u3044\u308B\u3002\u30B7\u30E3\u30EF\u30FC\u30BA\u3060\u3063\u305F\u3002\u3000#\u521D\u3081\u3066lv100\u306B\u3057\u305F\u30DD\u30B1\u30E2\u30F3",
  "id" : 125209314813161472,
  "created_at" : "2011-10-15 14:00:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125208896884314112",
  "text" : "\u4ECA\u65E5\u4E00\u65E5\u4F55\u306B\u3082\u98F2\u307E\u305A\u306B\u904E\u3054\u3057\u3066\u5E30\u308A\u306B\uFF12\uFF4C\u306E\u30A6\u30FC\u30ED\u30F3\u8336\u8CB7\u3063\u3066\u304D\u3066\u306A\u3093\u3068\u306A\u3057\u306B\u98F2\u3093\u3067\u305F\u3089\u3082\u3046\u534A\u5206\u3002\n\u6C34\u5206\u5927\u4E8B\u3002",
  "id" : 125208896884314112,
  "created_at" : "2011-10-15 13:58:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 3, 13 ],
      "id_str" : "177404480",
      "id" : 177404480
    }, {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u308B\u3093 [\u6700\u7D42\u898F\u5236\u30A2\u30AB]",
      "screen_name" : "nisehorrrrrrrn",
      "indices" : [ 31, 46 ],
      "id_str" : "295218654",
      "id" : 295218654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u3053\u3068\u3092\uFF13\u3064\u306E\u5358\u8A9E\u3067\u8868\u3057\u3066\u304F\u308C\u308B",
      "indices" : [ 48, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125206035207168000",
  "text" : "RT @dovanyahn: \u30DA\u30F3\u30AE\u30F3 bot  \u898F\u5236 RT @nisehorrrrrrrn: #\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u3053\u3068\u3092\uFF13\u3064\u306E\u5358\u8A9E\u3067\u8868\u3057\u3066\u304F\u308C\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u308B\u308B\u3093 [\u6700\u7D42\u898F\u5236\u30A2\u30AB]",
        "screen_name" : "nisehorrrrrrrn",
        "indices" : [ 16, 31 ],
        "id_str" : "295218654",
        "id" : 295218654
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u3053\u3068\u3092\uFF13\u3064\u306E\u5358\u8A9E\u3067\u8868\u3057\u3066\u304F\u308C\u308B",
        "indices" : [ 33, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125205880273768448",
    "text" : "\u30DA\u30F3\u30AE\u30F3 bot  \u898F\u5236 RT @nisehorrrrrrrn: #\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u3053\u3068\u3092\uFF13\u3064\u306E\u5358\u8A9E\u3067\u8868\u3057\u3066\u304F\u308C\u308B",
    "id" : 125205880273768448,
    "created_at" : "2011-10-15 13:46:22 +0000",
    "user" : {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "protected" : false,
      "id_str" : "177404480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2342155294\/dovanyahn_normal.jpg",
      "id" : 177404480,
      "verified" : false
    }
  },
  "id" : 125206035207168000,
  "created_at" : "2011-10-15 13:46:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/rzOnkAhT",
      "expanded_url" : "http:\/\/www.kyoto-np.co.jp\/top\/article\/20111014000114",
      "display_url" : "kyoto-np.co.jp\/top\/article\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "125204035673391104",
  "text" : "\u3082\u3046\u96E8\u3067\u30C0\u30E1\u3060\u308D\u3046\u306A\u30FC RT @a_univ_student \u9D28\u5DDD\u306B\u30CF\u30FC\u30C8\u5F62\u306E\u4E2D\u5DDE\u51FA\u73FE\u3000\u5317\u533A http:\/\/t.co\/rzOnkAhT",
  "id" : 125204035673391104,
  "created_at" : "2011-10-15 13:39:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/sxuek10j",
      "expanded_url" : "http:\/\/schrodinger.haun.org\/",
      "display_url" : "schrodinger.haun.org"
    } ]
  },
  "geo" : { },
  "id_str" : "125203412190109696",
  "text" : "\u306A\u306B\u3053\u308C\u304A\u3082\u3057\u308D\u3044\u3000http:\/\/t.co\/sxuek10j\u3000",
  "id" : 125203412190109696,
  "created_at" : "2011-10-15 13:36:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125201712079306752",
  "text" : "\u91CE\u83DC\u98DF\u3079\u305F\u3044\u306A\u30FC\n\u30B5\u30E9\u30C0\u30D0\u30FC\u306E\u3042\u308B\u30D5\u30A1\u30DF\u30EC\u30B9\u306B\u884C\u304D\u305F\u3044\u306A",
  "id" : 125201712079306752,
  "created_at" : "2011-10-15 13:29:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125179239082369024",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 125179239082369024,
  "created_at" : "2011-10-15 12:00:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/JgCzkNkc",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=igaris",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124848545957294080",
  "text" : "igaris\u304C\u3001\u79C1\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/JgCzkNkc",
  "id" : 124848545957294080,
  "created_at" : "2011-10-14 14:06:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124708638899175424",
  "text" : "\uFF34\uFF2F\uFF2B\uFF25\uFF34\uFF21\uFF01",
  "id" : 124708638899175424,
  "created_at" : "2011-10-14 04:50:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124694712169930752",
  "text" : "\u3042\u30FC\u3001\u8A08\u7B97\u7528\u7D19\u306B\u306A\u308B\u7121\u99C4\u7D19\u304C\u306A\u3044\u3002",
  "id" : 124694712169930752,
  "created_at" : "2011-10-14 03:55:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124692977208668163",
  "text" : "\u30D9\u30EB\u30CC\u30A4\u578B\u306E\u5FAE\u65B9\u306E\u89E3\u304C\u3001\u7DDA\u5F62\u30D1\u30BF\u30FC\u30F3\u3068\u5909\u6570\u5206\u96E2\u30D1\u30BF\u30FC\u30F3\u3067\u9055\u3046\u3002\n\u9593\u9055\u3044\u306A\u304F\u3001\u3069\u3061\u3089\u304B\u304C\u9593\u9055\u3063\u3066\u3044\u308B\u2026\u3002",
  "id" : 124692977208668163,
  "created_at" : "2011-10-14 03:48:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124621556663062530",
  "text" : "\u3053\u306E\u6642\u671F\u3066\u3053\u3093\u306A\u306B\u96E8\u964D\u308B\u3082\u306E\u3060\u3063\u305F\u3063\u3051\n\n\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 124621556663062530,
  "created_at" : "2011-10-13 23:04:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124545307706007553",
  "text" : "\u5FAE\u7A4D\u3082\u5FAE\u65B9\u3082\u3042\u308B\u3093\u3060\u3088",
  "id" : 124545307706007553,
  "created_at" : "2011-10-13 18:01:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3048\u3060\u307E\u3048\u3060",
      "screen_name" : "blackpiyu",
      "indices" : [ 10, 20 ],
      "id_str" : "133376125",
      "id" : 133376125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/Pm9jMxXS",
      "expanded_url" : "http:\/\/yfrog.com\/oc3h0lj",
      "display_url" : "yfrog.com\/oc3h0lj"
    } ]
  },
  "geo" : { },
  "id_str" : "124468668313780224",
  "text" : "\u3042\u3089\u304B\u308F\u3044\u3044 RT @blackpiyu \u3053\u3053\u304C\u843D\u3061\u7740\u304F http:\/\/t.co\/Pm9jMxXS",
  "id" : 124468668313780224,
  "created_at" : "2011-10-13 12:56:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3063\u304F\u308D\u304F\u308D\u3044\u306E",
      "screen_name" : "makkurokuroino",
      "indices" : [ 3, 18 ],
      "id_str" : "185255752",
      "id" : 185255752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124468398355787776",
  "text" : "RT @makkurokuroino: \u300C\u3042\u306A\u305F\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u9078\u629E\u306E\u5358\u4F4D\u3067\u3059\u304B\uFF1F\u305D\u308C\u3068\u3082\u5916\u56FD\u8A9E\u306E\u5358\u4F4D\u3067\u3059\u304B\uFF1F\u300D\u300C\u3044\u3044\u3048\u5973\u795E\u69D8\u3001\u79C1\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u5FC5\u4FEE\u306E\u5358\u4F4D\u3067\u3059\u300D\u300C\u6B63\u76F4\u8005\u306E\u304A\u524D\u306B\u306F\u697D\u3057\u3044\u5B66\u751F\u751F\u6D3B\u3092\u3082\u3046\u4E00\u5E74\u5DEE\u3057\u4E0A\u3052\u307E\u3057\u3087\u3046\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124462473414848512",
    "text" : "\u300C\u3042\u306A\u305F\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u9078\u629E\u306E\u5358\u4F4D\u3067\u3059\u304B\uFF1F\u305D\u308C\u3068\u3082\u5916\u56FD\u8A9E\u306E\u5358\u4F4D\u3067\u3059\u304B\uFF1F\u300D\u300C\u3044\u3044\u3048\u5973\u795E\u69D8\u3001\u79C1\u304C\u843D\u3068\u3057\u305F\u306E\u306F\u5FC5\u4FEE\u306E\u5358\u4F4D\u3067\u3059\u300D\u300C\u6B63\u76F4\u8005\u306E\u304A\u524D\u306B\u306F\u697D\u3057\u3044\u5B66\u751F\u751F\u6D3B\u3092\u3082\u3046\u4E00\u5E74\u5DEE\u3057\u4E0A\u3052\u307E\u3057\u3087\u3046\u300D",
    "id" : 124462473414848512,
    "created_at" : "2011-10-13 12:32:20 +0000",
    "user" : {
      "name" : "\u307E\u3063\u304F\u308D\u304F\u308D\u3044\u306E",
      "screen_name" : "makkurokuroino",
      "protected" : false,
      "id_str" : "185255752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583387282540859392\/1LGXrROZ_normal.png",
      "id" : 185255752,
      "verified" : false
    }
  },
  "id" : 124468398355787776,
  "created_at" : "2011-10-13 12:55:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 56, 65 ],
      "id_str" : "102399578",
      "id" : 102399578
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 82, 92 ],
      "id_str" : "155546700",
      "id" : 155546700
    }, {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 116, 125 ],
      "id_str" : "102399578",
      "id" : 102399578
    }, {
      "name" : "Dova",
      "screen_name" : "Dova",
      "indices" : [ 135, 140 ],
      "id_str" : "8268132",
      "id" : 8268132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124468339132211200",
  "text" : "\u5965\u304B\u3089\u5E97\u9577\u3060\u304B\u30DE\u30CD\u30FC\u30B8\u30E3\u30FC\u3060\u304B\u5049\u3044\u4EBA\u304C\u51FA\u3066\u304D\u3066\u518D\u4E09\u300C\u304A\u8089\u306E\u307F\u3067\u3088\u308D\u3057\u3044\u3093\u3067\u3059\u306D\uFF1F\u300D\u3068\u78BA\u8A8D\u3055\u308C\u3066\u307E\u3057\u305F\u304C\uFF57 RT @kuttinpa \u307E\u3058\u304B\u3001\u50D5\u306F\u65AD\u3089\u308C\u307E\u3057\u305F RT @end313124: \u8089\u4EE5\u5916\u629C\u304D\u3084\u3063\u3066\u305F\u53CB\u9054\u304C\u3044\u305F\u3051\u3069\u306A\u30FC RT @kuttinpa \u3053\u308C\u306F\u7121\u7406 RT @dova",
  "id" : 124468339132211200,
  "created_at" : "2011-10-13 12:55:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 22, 31 ],
      "id_str" : "102399578",
      "id" : 102399578
    }, {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 41, 51 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124466363677945856",
  "text" : "\u8089\u4EE5\u5916\u629C\u304D\u3084\u3063\u3066\u305F\u53CB\u9054\u304C\u3044\u305F\u3051\u3069\u306A\u30FC RT @kuttinpa \u3053\u308C\u306F\u7121\u7406 RT @dovanyahn: \u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u306E\u30D1\u30F3\u629C\u304D\u306F\u7121\u7406\u3063\u3066\u3053\u3068\u304B",
  "id" : 124466363677945856,
  "created_at" : "2011-10-13 12:47:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u79CB\u5C71@Flips\uFF08\u30D5\u30EA\u30C3\u30D7\u30B9\uFF09\u4E8B\u52D9\u5C40",
      "screen_name" : "flips_jp",
      "indices" : [ 99, 108 ],
      "id_str" : "176590647",
      "id" : 176590647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/YE8AHwJE",
      "expanded_url" : "http:\/\/flips.cc\/njOaXD",
      "display_url" : "flips.cc\/njOaXD"
    } ]
  },
  "geo" : { },
  "id_str" : "124454656381431808",
  "text" : "\u304A\u5F01\u5F53\u306E\u89E3\u4F53\u304C8271\u756A\u76EE\u306B\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002\u6240\u8981\u6642\u9593\u306F2\u520618\u79D2\u3001 \u7206\u767A0\u56DE\u3067\u3059\u3002 Amazon\u30AE\u30D5\u30C8\u523810,000\u5186\u304C\u3042\u305F\u308BFlips\u00D7\u89E3\u4F53\u30D1\u30BA\u30EB http:\/\/t.co\/YE8AHwJE via @Flips_jp",
  "id" : 124454656381431808,
  "created_at" : "2011-10-13 12:01:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124454534595620865",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 124454534595620865,
  "created_at" : "2011-10-13 12:00:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124450185576329216",
  "text" : "\u30D0\u30FC\u30EB\u306E\u3088\u3046\u306A\u3082\u306E\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 124450185576329216,
  "created_at" : "2011-10-13 11:43:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124446016559779840",
  "text" : "\u30B7\u30E3\u30EF\u30FC\u6D74\u3073\u3088",
  "id" : 124446016559779840,
  "created_at" : "2011-10-13 11:26:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124445347299852288",
  "text" : "\u3086\u30D0\u30C3\u30B8\u6B32\u3057\u3044\u3088\u306A\u3041",
  "id" : 124445347299852288,
  "created_at" : "2011-10-13 11:24:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124419555761192960",
  "text" : "\u548C\u98A8\u30AA\u30E0\u30E9\u30A4\u30B9\u304A\u3044\u3057\u3044\u3067\u3059\u3002\u79C1\u306F\u30AA\u30E0\u30E9\u30A4\u30B9\u98DF\u3079\u308C\u307E\u3059\u3088\uFF57\uFF57\uFF57",
  "id" : 124419555761192960,
  "created_at" : "2011-10-13 09:41:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 18, 27 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124323628346130432",
  "text" : "\u4ECA\u3044\u308B\u306E\u306F\u9650\u308A\u306A\u304F\u8FD1\u3044\u6240\u3067\u3059 RT @nartakio: \u6587\u5B66\u90E8\u6570\u5B66\u79D1\u304C\u3042\u3063\u305F\u3089\u305D\u3063\u3061\u884C\u3063\u305F\u306E\u306B",
  "id" : 124323628346130432,
  "created_at" : "2011-10-13 03:20:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124323232609341443",
  "text" : "\u8D77\u304D\u305F\u3089\u5589\u3001\u80A9\u3001\u982D\u75DB\u3044\u3002\n\u98A8\u90AA\u307F\u305F\u3044\u306B\u5185\u7684\u306B\u75DB\u3044\u3068\u8A00\u3046\u3088\u308A\u306F\u3001\u4E7E\u71E5\u3068\u80A9\u51DD\u308A\u3002",
  "id" : 124323232609341443,
  "created_at" : "2011-10-13 03:19:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124322139926052864",
  "text" : "\uFF12\u6642\u524D\u306B\u5929\u6C17\u4E88\u5831\u307F\u305F\u3089\uFF11\uFF10\uFF05\u3060\u3063\u305F\u3088\u3046",
  "id" : 124322139926052864,
  "created_at" : "2011-10-13 03:14:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124321982333456384",
  "text" : "\u5FAE\u5999\u306A\u96E8\u2026\uFF1F\uFF01\u30DE\u30B8\u3067\uFF1F",
  "id" : 124321982333456384,
  "created_at" : "2011-10-13 03:14:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124321300809400321",
  "text" : "\u306A\u3093\u304B\u4E0D\u601D\u8B70\u306A\u7A7A\u9593\u306B\u9589\u3058\u8FBC\u3081\u3089\u308C\u3066\u8131\u51FA\u3059\u308B\u5922\u3092\u898B\u305F\u306A",
  "id" : 124321300809400321,
  "created_at" : "2011-10-13 03:11:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124320637769613312",
  "text" : "\u4E00\u9650\u51FA\u3089\u308C\u3066\u3082\u30CB\u9650\u306B\u5BDD\u574A\u3059\u308B\u30D1\u30E9\u30C9\u30C3\u30AF\u30B9",
  "id" : 124320637769613312,
  "created_at" : "2011-10-13 03:08:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124320186475098113",
  "text" : "RT @akeopyaa: \u306A\u3093\u304B\u96A3\u306E\u5973\u306E\u5B50\u306B\u8912\u3081\u3089\u308C\u305F\u305E(*'-'*)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124318986837041154",
    "text" : "\u306A\u3093\u304B\u96A3\u306E\u5973\u306E\u5B50\u306B\u8912\u3081\u3089\u308C\u305F\u305E(*'-'*)",
    "id" : 124318986837041154,
    "created_at" : "2011-10-13 03:02:10 +0000",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 124320186475098113,
  "created_at" : "2011-10-13 03:06:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124300610156773376",
  "text" : "\u4E8C\u5EA6\u5BDD \u5BDD\u574A \u306E\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
  "id" : 124300610156773376,
  "created_at" : "2011-10-13 01:49:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124164092696068096",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 124164092696068096,
  "created_at" : "2011-10-12 16:46:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124163970633433089",
  "text" : "\u7406\u89E3\u3057\u3066\u3044\u305F\u306F\u305A\u306E\u5206\u91CE\u3067\u3082\u5927\u5B66\u6570\u5B66\u306E\u7BC4\u56F2\u3060\u3068\u8B0E\u304C\u6EA2\u308C\u3066\u6B62\u307E\u3089\u306A\u3044\u3002",
  "id" : 124163970633433089,
  "created_at" : "2011-10-12 16:46:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124141562274906113",
  "geo" : { },
  "id_str" : "124143187446075392",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u3044\u3048\u3059\uFF01\u3067\u3082\u5F7C\u3001\u73FE\u5F79or\u6D6A\u4EBA\u306E\u6642\u3001\u61C7\u8AC7\u4F1A\u3067\u300C\u8E74\u3089\u306A\u304F\u3066\u3082\u3044\u3044\u3093\u3058\u3083\u306D\u300D\u3063\u3066\u89AA\u306B\u8A00\u3063\u3066\u305F\u3089\u3057\u3044\uFF57\uFF57",
  "id" : 124143187446075392,
  "in_reply_to_status_id" : 124141562274906113,
  "created_at" : "2011-10-12 15:23:37 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3080\u3046\u307F\u3093",
      "screen_name" : "_submoomin",
      "indices" : [ 3, 14 ],
      "id_str" : "284046922",
      "id" : 284046922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124138809892929536",
  "text" : "RT @_submoomin: \u6771\u5927\u751F\u306E\u30CE\u30FC\u30C8\u306B\u66F8\u3044\u3066\u3042\u308B\u304B\u3069\u3046\u304B\u306B\u95A2\u308F\u3089\u305A\u3053\u306E\u6570\u5F0F\u306F\u7F8E\u3057\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124136243301851136",
    "text" : "\u6771\u5927\u751F\u306E\u30CE\u30FC\u30C8\u306B\u66F8\u3044\u3066\u3042\u308B\u304B\u3069\u3046\u304B\u306B\u95A2\u308F\u3089\u305A\u3053\u306E\u6570\u5F0F\u306F\u7F8E\u3057\u3044",
    "id" : 124136243301851136,
    "created_at" : "2011-10-12 14:56:01 +0000",
    "user" : {
      "name" : "\u3080\u3046\u307F\u3093",
      "screen_name" : "_submoomin",
      "protected" : true,
      "id_str" : "284046922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603530782649397248\/Se0jPYxq_normal.png",
      "id" : 284046922,
      "verified" : false
    }
  },
  "id" : 124138809892929536,
  "created_at" : "2011-10-12 15:06:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124137540805607424",
  "text" : "\u307E\u3001\uFF34\uFF2C\u306F\u773A\u3081\u3066\u308B\u3051\u3069",
  "id" : 124137540805607424,
  "created_at" : "2011-10-12 15:01:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124137460899909632",
  "text" : "\u3042\u30FC\u30BF\u30A4\u30E0\u30A2\u30C3\u30D7\u3002\u771F\u9762\u76EE\u306B\u3084\u308B\u3075\u308A\u3057\u307E\u3059\u3057\u3002",
  "id" : 124137460899909632,
  "created_at" : "2011-10-12 15:00:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 30, 38 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124137180342927360",
  "text" : "\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u8089\u4EE5\u5916\u629C\u304D\u3092\u3084\u3063\u305F\u53CB\u4EBA\u304C\u3044\u3066\u3067\u3059\u306D\u30FB\u30FB\u30FB RT @i_horse \u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u8089\u629C\u304D\u306A\u3089\u3084\u3089\u305B\u305F\u3053\u3068\u304C\u3042\u308B\uFF57\uFF57\uFF57",
  "id" : 124137180342927360,
  "created_at" : "2011-10-12 14:59:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124137060738154498",
  "text" : "\u65B9\u306B\u901A\u8A33\u306E\u305B\u3066\u82F1\u8A9E\u570F\u3092\u65C5\u884C\u3059\u308B\u3053\u3068\u3092\u305D\u3046\u305E\u3046\u3057\u3066\u30D1\u30A4\u30EC\u30FC\u30C4\u306B\u51FA\u3066\u304F\u308B\u4EBA\u3092\u601D\u3044\u51FA\u3057\u305F\u3002",
  "id" : 124137060738154498,
  "created_at" : "2011-10-12 14:59:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124136840067424257",
  "text" : "\u4E2D\u5B66\u5411\u3051\u306E\u30C6\u30AD\u30B9\u30C8\u3067\u3001\u300C\u5F7C\u5973\u306F\u82F1\u8A9E\u3092\u8A71\u305B\u308B\u9CE5\u3092\u98FC\u3063\u3066\u3044\u307E\u3059\u300D\u3063\u3066\u6587\u304C\u3042\u3063\u305F\u306A\u3002\n\u30C0\u30A6\u30C8\u3002",
  "id" : 124136840067424257,
  "created_at" : "2011-10-12 14:58:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124135813385695232",
  "text" : "\u306C\u308B\u308A\u3093\u3055\u3093\u7D20\u6575\uFF57\uFF57",
  "id" : 124135813385695232,
  "created_at" : "2011-10-12 14:54:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "indices" : [ 3, 12 ],
      "id_str" : "105498380",
      "id" : 105498380
    }, {
      "name" : " .",
      "screen_name" : "Jojo__0707",
      "indices" : [ 14, 25 ],
      "id_str" : "1512646136",
      "id" : 1512646136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124135649338081281",
  "text" : "RT @_Nururin: @Jojo__0707 \u5642\u306E\u308C\u304A\u3055\u3093\uFF81\uFF70\uFF70\uFF70\uFF70\uFF70\uFF6F\uFF7D!!!!\u4ECA\u65E5\u3082\u30C4\u30A4\u30FC\u30C8\u8F1D\u3044\u3066\u2026\u2026\u306D\u30FC\u3088\uFF57\uFF57\uFF57\u306A\u3093\u3060\u3053\u306E\u610F\u8B58\u4F4E\u3044\u3060\u3051\u306E\uFF78\uFF7F\uFF82\uFF72\uFF70\uFF84\uFF57\uFF57\uFF57\uFF57\uFF57Twitter\u3084\u3081\u3061\u307E\u3048\uFF57\uFF57\uFF57\uFF57\uFF57\u3048\u3001\u30CD\u30BF\uFF1F\u3064\u307E\u3089\u306A\u3055\u3059\u304E\u3066\u5206\u304B\u3093\u306D\u3047\u3088\uFF57\uFF57\uFF57\uFF57\u3055\u3063\u3055\u3068r4s\u98DF\u3089\u3044\u307E ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : " .",
        "screen_name" : "Jojo__0707",
        "indices" : [ 0, 11 ],
        "id_str" : "1512646136",
        "id" : 1512646136
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124134709147082752",
    "text" : "@Jojo__0707 \u5642\u306E\u308C\u304A\u3055\u3093\uFF81\uFF70\uFF70\uFF70\uFF70\uFF70\uFF6F\uFF7D!!!!\u4ECA\u65E5\u3082\u30C4\u30A4\u30FC\u30C8\u8F1D\u3044\u3066\u2026\u2026\u306D\u30FC\u3088\uFF57\uFF57\uFF57\u306A\u3093\u3060\u3053\u306E\u610F\u8B58\u4F4E\u3044\u3060\u3051\u306E\uFF78\uFF7F\uFF82\uFF72\uFF70\uFF84\uFF57\uFF57\uFF57\uFF57\uFF57Twitter\u3084\u3081\u3061\u307E\u3048\uFF57\uFF57\uFF57\uFF57\uFF57\u3048\u3001\u30CD\u30BF\uFF1F\u3064\u307E\u3089\u306A\u3055\u3059\u304E\u3066\u5206\u304B\u3093\u306D\u3047\u3088\uFF57\uFF57\uFF57\uFF57\u3055\u3063\u3055\u3068r4s\u98DF\u3089\u3044\u307E\u304F\u3063\u3066\u57A2\u51CD\u7D50\u3055\u308C\u3061\u307E\u3048\u3088\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
    "id" : 124134709147082752,
    "created_at" : "2011-10-12 14:49:55 +0000",
    "user" : {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "protected" : false,
      "id_str" : "105498380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591661205489520640\/gzUrW2-9_normal.jpg",
      "id" : 105498380,
      "verified" : false
    }
  },
  "id" : 124135649338081281,
  "created_at" : "2011-10-12 14:53:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124135557461843968",
  "text" : "\u4E8C\u9650\u3060\u3051\u3001\u4E8C\u9650\u3060\u3051\u4E57\u308A\u5207\u308C\u3070\u2026",
  "id" : 124135557461843968,
  "created_at" : "2011-10-12 14:53:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D30\u5DDD\u8CB4\u82F1 #\u58F0\u306B\u51FA\u3057\u3066\u8E0F\u307F\u305F\u3044\u97FB",
      "screen_name" : "takahide_h",
      "indices" : [ 3, 14 ],
      "id_str" : "99548215",
      "id" : 99548215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124134784652939265",
  "text" : "RT @takahide_h: \u30AA\u30FC\u30CB\uFF01\u30A4\u30A7\u30A4\u30B9\u30BA\u30E1\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124134447988748288",
    "text" : "\u30AA\u30FC\u30CB\uFF01\u30A4\u30A7\u30A4\u30B9\u30BA\u30E1\uFF01",
    "id" : 124134447988748288,
    "created_at" : "2011-10-12 14:48:53 +0000",
    "user" : {
      "name" : "\u7D30\u5DDD\u8CB4\u82F1 #\u58F0\u306B\u51FA\u3057\u3066\u8E0F\u307F\u305F\u3044\u97FB",
      "screen_name" : "takahide_h",
      "protected" : false,
      "id_str" : "99548215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2018385558\/150_normal.jpg",
      "id" : 99548215,
      "verified" : false
    }
  },
  "id" : 124134784652939265,
  "created_at" : "2011-10-12 14:50:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124133886262382592",
  "text" : "\uFF47\uFF44\uFF47\uFF44\u304C\uFF47\u3067\u5FAE\u5206\u3001\uFF47\u3067\u5FAE\u5206\u306B\u898B\u3048\u3066\u304F\u308B\u7CFB\u7537\u5B50",
  "id" : 124133886262382592,
  "created_at" : "2011-10-12 14:46:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124133767869759488",
  "text" : "\u65E5\u4ED8\u5909\u3063\u305F\u3089\uFF11\u6642\u9593\u3060\u3051\u9811\u5F35\u308B\u3053\u3068\u306B\u3057\u3088\u3046\u3002\u3042\u3068\uFF11\uFF15\u5206\u306F\uFF47\uFF44\uFF47\uFF44\u3057\u3088\u3046\u3002",
  "id" : 124133767869759488,
  "created_at" : "2011-10-12 14:46:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124132815460777984",
  "text" : "\u9AD8\u6821\u3067\u306E\u6D6E\u304D\u65B9\u3082\u5ACC\u3044\u3058\u3083\u306A\u304B\u3063\u305F\u3051\u3069\u306D\u3047\n\u4ECA\u3042\u306E\u30E1\u30F3\u30D0\u30FC\u3067\u96C6\u307E\u3063\u305F\u3089\u51C4\u304F\u6D6E\u304F\u3093\u3060\u308D\u3046\u306A\u30FC\u3002",
  "id" : 124132815460777984,
  "created_at" : "2011-10-12 14:42:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124132625660116992",
  "text" : "\u5909\u614B\u3068\u3044\u3046\u304B\u3001\u3042\u3093\u307E\u308A\u6D6E\u304B\u306A\u304F\u306A\u3063\u305F\u305C\uFF57\uFF57\uFF57",
  "id" : 124132625660116992,
  "created_at" : "2011-10-12 14:41:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 14, 22 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124132501756190721",
  "text" : "\u5B66\u90E8\u306F\u9055\u3048\u3069\u3042\u308B\u3042\u308B RT @i_horse \u4EAC\u90FD\u5927\u5B66\u7406\u5B66\u90E8\u306B\u5165\u3063\u3066\u6B63\u76F4\u81EA\u5206\u306E\u5909\u614B\u5EA6\u304C\u76F8\u5BFE\u7684\u306B\u8584\u308C\u3066\u308B\u6C17\u304C\u3059\u308B\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57\uFF57",
  "id" : 124132501756190721,
  "created_at" : "2011-10-12 14:41:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124132410731409408",
  "text" : "\u307E\u3041\u3001\u5197\u8AC7\u3068\u304B\u901A\u3058\u307E\u305B\u3093\u3057\uFF57",
  "id" : 124132410731409408,
  "created_at" : "2011-10-12 14:40:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6559\u5E2B\u306B\u8A00\u308F\u308C\u305F\u885D\u6483\u7684\u306A\u8A00\u8449",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124132298055614464",
  "text" : "\u300C\u304A\u524D\u6D6A\u4EBA\u3057\u305F\u3089\u6771\u5927\u304B\u4EAC\u5927\u3044\u3051\u3093\u3058\u3083\u306D\uFF1F\u300D\n\u7D50\u679C\u3001\u4EBA\u751F\u3092\u5909\u3048\u305F\u306A\u30FC\u3002\u5F7C\u306F\u3059\u3054\u3044\u8EFD\u3044\u30CE\u30EA\u3067\"\u8A00\u3063\u3066\u898B\u305F\u3060\u3051\u301D\u3060\u3063\u305F\u307D\u3044\u3051\u308C\u3069\u3002\n#\u6559\u5E2B\u306B\u8A00\u308F\u308C\u305F\u885D\u6483\u7684\u306A\u8A00\u8449",
  "id" : 124132298055614464,
  "created_at" : "2011-10-12 14:40:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u306A\u308A\u306E\u5742\u7530\u3055\u3093",
      "screen_name" : "sakatandao",
      "indices" : [ 3, 14 ],
      "id_str" : "108223197",
      "id" : 108223197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6559\u5E2B\u306B\u8A00\u308F\u308C\u305F\u885D\u6483\u7684\u306A\u8A00\u8449",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124131916873076736",
  "text" : "RT @sakatandao: \u5148\u751F\u306F\u6570\u5B66\u3092\u7814\u7A76\u3057\u3059\u304E\u3066\u4E00\u56DE\u982D\u304C\u304A\u304B\u3057\u304F\u306A\u308A\u3061\u3087\u3063\u3068\u306E\u9593\u56DB\u3064\u3093\u9019\u3044\u3067\u79FB\u52D5\u3057\u3066\u3044\u305F\u9803\u304C\u3042\u308B\u3002 #\u6559\u5E2B\u306B\u8A00\u308F\u308C\u305F\u885D\u6483\u7684\u306A\u8A00\u8449",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B for iPhone\u3000\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u6559\u5E2B\u306B\u8A00\u308F\u308C\u305F\u885D\u6483\u7684\u306A\u8A00\u8449",
        "indices" : [ 46, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123569746481389568",
    "text" : "\u5148\u751F\u306F\u6570\u5B66\u3092\u7814\u7A76\u3057\u3059\u304E\u3066\u4E00\u56DE\u982D\u304C\u304A\u304B\u3057\u304F\u306A\u308A\u3061\u3087\u3063\u3068\u306E\u9593\u56DB\u3064\u3093\u9019\u3044\u3067\u79FB\u52D5\u3057\u3066\u3044\u305F\u9803\u304C\u3042\u308B\u3002 #\u6559\u5E2B\u306B\u8A00\u308F\u308C\u305F\u885D\u6483\u7684\u306A\u8A00\u8449",
    "id" : 123569746481389568,
    "created_at" : "2011-10-11 01:24:58 +0000",
    "user" : {
      "name" : "\u3068\u306A\u308A\u306E\u5742\u7530\u3055\u3093",
      "screen_name" : "sakatandao",
      "protected" : false,
      "id_str" : "108223197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573869892006383618\/d8_JID_l_normal.jpeg",
      "id" : 108223197,
      "verified" : false
    }
  },
  "id" : 124131916873076736,
  "created_at" : "2011-10-12 14:38:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124131714267234305",
  "text" : "\u4E2D\u70B9\u9023\u7D50\u5B9A\u7406\u3068\u304B\u6761\u4EF6\u304D\u3064\u304F\u3066\u5927\u597D\u304D\u3060\u3063\u305F\u306A\u3041",
  "id" : 124131714267234305,
  "created_at" : "2011-10-12 14:38:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124130557121667072",
  "text" : "\u793E\u4F1A\u4EBA\u2026",
  "id" : 124130557121667072,
  "created_at" : "2011-10-12 14:33:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E5\u30A2\u30AB\u30A4\u30B7\u30E3\u30A4\u30F3\u5C0F\u9CE5\u904A",
      "screen_name" : "taka_nashi",
      "indices" : [ 3, 14 ],
      "id_str" : "151319183",
      "id" : 151319183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124130449315471360",
  "text" : "RT @taka_nashi: \u5C0F\u5B66\u751F\u300C\u6771\u65B9\u3063\u3066\u306A\u306B\uFF1F\u300D\n\u4E2D\u5B66\u751F\u300C\u30D1\u30BD\u30B3\u30F3\u306E\u30B7\u30E5\u30FC\u30C6\u30A3\u30F3\u30B0\u30B2\u30FC\u30E0\u3060\u3063\u3066\u300D\n\u9AD8\u6821\u751F\u300C\u30AA\u30EC\u4F8B\u5927\u796D\u884C\u3063\u3066\u304D\u305F\u3057wCD20\u679A\u8FD1\u304F\u8CB7\u3063\u3066\u304D\u305Fw\u30B2\u30FC\u30E0\u306E\u65B9\u306F\u8CB7\u3048\u306A\u304B\u3063\u305F\u3051\u3069w\u300D\n\u5927\u5B66\u751F\u300C\u4ECA\u5EA6\u5B66\u796D\u3067\u6771\u65B9\u30AD\u30E3\u30E9\u306E\u30B3\u30B9\u30D7\u30EC\u3057\u307E\u3059\u304C\u4FFA\u306F\u7537\u3067\u3059\u300D\n\u793E\u4F1A\u4EBA(\u3053\u306E\u6E80 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124129934984749056",
    "text" : "\u5C0F\u5B66\u751F\u300C\u6771\u65B9\u3063\u3066\u306A\u306B\uFF1F\u300D\n\u4E2D\u5B66\u751F\u300C\u30D1\u30BD\u30B3\u30F3\u306E\u30B7\u30E5\u30FC\u30C6\u30A3\u30F3\u30B0\u30B2\u30FC\u30E0\u3060\u3063\u3066\u300D\n\u9AD8\u6821\u751F\u300C\u30AA\u30EC\u4F8B\u5927\u796D\u884C\u3063\u3066\u304D\u305F\u3057wCD20\u679A\u8FD1\u304F\u8CB7\u3063\u3066\u304D\u305Fw\u30B2\u30FC\u30E0\u306E\u65B9\u306F\u8CB7\u3048\u306A\u304B\u3063\u305F\u3051\u3069w\u300D\n\u5927\u5B66\u751F\u300C\u4ECA\u5EA6\u5B66\u796D\u3067\u6771\u65B9\u30AD\u30E3\u30E9\u306E\u30B3\u30B9\u30D7\u30EC\u3057\u307E\u3059\u304C\u4FFA\u306F\u7537\u3067\u3059\u300D\n\u793E\u4F1A\u4EBA(\u3053\u306E\u6E80\u54E1\u96FB\u8ECA\u306E\u4E2D\u306B\u54B2\u591C\u3055\u3093\u304C\u5C45\u305F\u3089\u3044\u3044\u306E\u306B\u306A)",
    "id" : 124129934984749056,
    "created_at" : "2011-10-12 14:30:57 +0000",
    "user" : {
      "name" : "\u30AD\u30E5\u30A2\u30AB\u30A4\u30B7\u30E3\u30A4\u30F3\u5C0F\u9CE5\u904A",
      "screen_name" : "taka_nashi",
      "protected" : false,
      "id_str" : "151319183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598106211997749248\/sAQfQxqY_normal.jpg",
      "id" : 151319183,
      "verified" : false
    }
  },
  "id" : 124130449315471360,
  "created_at" : "2011-10-12 14:33:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124129524593078272",
  "text" : "\u8C9D\uFF08\u03C7\uFF09\u3068\u304B\u3082\u4E00\u7DD2\u306B\u305C\u3072\u3002",
  "id" : 124129524593078272,
  "created_at" : "2011-10-12 14:29:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sigmapsi",
      "screen_name" : "sigmapsi",
      "indices" : [ 3, 12 ],
      "id_str" : "22502063",
      "id" : 22502063
    }, {
      "name" : "\u7121\u9813\u7740\u306A\u3075\u3089\u3093",
      "screen_name" : "Furrane",
      "indices" : [ 32, 40 ],
      "id_str" : "170659577",
      "id" : 170659577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124129407722983425",
  "text" : "RT @sigmapsi: \u03A8\u3068\u30BB\u30C3\u30C8\u3067\u98FC\u80B2\u3059\u308B\u3068\u826F\u3044 RT: @Furrane: \u51FA\u5178:2ch\nQ.\u7528\u6C34\u8DEF\u3067\u9B5A\u53D6\u3063\u305F\u3093\u3060\u3051\u3069\u3081\u3060\u304B\u3063\u307D\u3044\u3051\u3069\u3081\u3060\u304B\u3058\u3083\u306A\u3044\u3002 \n\u5C3E\u30D2\u30EC\u304C\u03A3\u2190\u3053\u3093\u306A\u5F62\u3002 \u3053\u308C\u4F55\u3060\u308D\uFF1F  \nA.\u300C\u30B7\u30B0\u30DE\u300D\u3067\u3059\u3002 \nQ.\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01 \n\u3081\u3060\u304B\u306F\u98FC\u3063\u3066 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u7121\u9813\u7740\u306A\u3075\u3089\u3093",
        "screen_name" : "Furrane",
        "indices" : [ 18, 26 ],
        "id_str" : "170659577",
        "id" : 170659577
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124129121050705920",
    "text" : "\u03A8\u3068\u30BB\u30C3\u30C8\u3067\u98FC\u80B2\u3059\u308B\u3068\u826F\u3044 RT: @Furrane: \u51FA\u5178:2ch\nQ.\u7528\u6C34\u8DEF\u3067\u9B5A\u53D6\u3063\u305F\u3093\u3060\u3051\u3069\u3081\u3060\u304B\u3063\u307D\u3044\u3051\u3069\u3081\u3060\u304B\u3058\u3083\u306A\u3044\u3002 \n\u5C3E\u30D2\u30EC\u304C\u03A3\u2190\u3053\u3093\u306A\u5F62\u3002 \u3053\u308C\u4F55\u3060\u308D\uFF1F  \nA.\u300C\u30B7\u30B0\u30DE\u300D\u3067\u3059\u3002 \nQ.\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01 \n\u3081\u3060\u304B\u306F\u98FC\u3063\u3066\u308B\u3093\u3067\u3059\u304C\u30B7\u30B0\u30DE\u3082\u98FC\u80B2\u53EF\u80FD\u3067\u3059\u304B\uFF1F",
    "id" : 124129121050705920,
    "created_at" : "2011-10-12 14:27:43 +0000",
    "user" : {
      "name" : "sigmapsi",
      "screen_name" : "sigmapsi",
      "protected" : false,
      "id_str" : "22502063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583384013827534848\/0mN7RLwV_normal.png",
      "id" : 22502063,
      "verified" : false
    }
  },
  "id" : 124129407722983425,
  "created_at" : "2011-10-12 14:28:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124129257852125184",
  "text" : "\u4ECA\u304B\u3089\u660E\u65E5\u306E\u4E8C\u9650\u306E\u4E88\u7FD2\u3060\u3088\u3063\u3002\u524D\u671F\u304C\u697D\u3060\u3063\u305F\u3060\u3051\u306B\u5927\u3057\u3066\u5927\u5909\u306A\u8AB2\u984C\u3058\u3083\u306A\u3044\u306E\u306B\u3060\u308B\u304F\u611F\u3058\u308B\u3088\u3063\u3002\n\u3042\u3068\u7720\u3044\u3088\u3063\u3002",
  "id" : 124129257852125184,
  "created_at" : "2011-10-12 14:28:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124129100976758785",
  "text" : "\u307F\u305F\u3044\u306A\u8A71\u304C\u3050\u308B\u3050\u308B\u3002",
  "id" : 124129100976758785,
  "created_at" : "2011-10-12 14:27:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124128990633013248",
  "text" : "\u305D\u3082\u305D\u3082\u30D9\u30AF\u30C8\u30EB\u3063\u3066\u57FA\u5E95\u306E\u7DDA\u578B\u7D50\u5408\u3060\u3057\u306A\u3041\u30FB\u30FB\u30FB",
  "id" : 124128990633013248,
  "created_at" : "2011-10-12 14:27:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124128782440337408",
  "text" : "\u30D9\u30AF\u30C8\u30EB\u306E\u639B\u3051\u7B97\uFF08\u5185\u7A4D\uFF1F\uFF09\u3063\u3066\u7FA4\u8AD6\u7684\u306B\u306F\u3069\u3046\u306A\u308B\u3093\u3060\u308D\u3046\uFF1F\u3068\u304B\u8003\u3048\u3066\u308B\u3002\u30B9\u30AB\u30E9\u500D\u3068\u304B\u8DB3\u3057\u7B97\u306A\u3089\u3044\u3044\u3060\u308D\u3046\u3051\u3069\u3002\u307E\u305A\u9006\u5143\u304C\u60F3\u5B9A\u3067\u304D\u306A\u3044\u3088\u306A\u30FC\u3002",
  "id" : 124128782440337408,
  "created_at" : "2011-10-12 14:26:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124128245712035840",
  "text" : "\u3059\u3093\u306A\u308A\u300C\u304E\u3083\u304F\uFF47\u300D\u4F4D\u307E\u3067\u6253\u3063\u3066\u6C17\u4ED8\u3044\u305F\u3088\u3001\u3082\u3046\u30C0\u30E1\u306A\u3093\u3060\u308D\u3046\u3002",
  "id" : 124128245712035840,
  "created_at" : "2011-10-12 14:24:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124128077918896128",
  "text" : "\u300C\u8A00\u8449\u3092\u304B\u307F\u7815\u304F\u300D\u306E\u9006\u5143\u30FB\u30FB\u30FB\u3058\u3083\u306A\u304F\u3066\u5BFE\u7FA9\u8A9E\u3063\u3066\u306A\u3093\u3060\u308D\u3046\u3002",
  "id" : 124128077918896128,
  "created_at" : "2011-10-12 14:23:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "np2i",
      "screen_name" : "np2i",
      "indices" : [ 12, 17 ],
      "id_str" : "1154899267",
      "id" : 1154899267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124127737144295424",
  "text" : "\u66F8\u304D\u8FBC\u307F\u307E\u305B\u3093\uFF01 RT @np2i \u6570\u5B66\u66F8\u306B\u66F8\u304D\u8FBC\u307E\u306A\u3044\u6D3E\u304C\u8907\u6570\u540D\u3044\u308B\u3088\u3046\u3067\u5B89\u5FC3\u3057\u305F\u3002\u540C\u610F\u306ERT\u3060\u3063\u305F\u306A\u3089\u3068\u3044\u3046\u524D\u63D0\u3060\u3051\u3069\u3002",
  "id" : 124127737144295424,
  "created_at" : "2011-10-12 14:22:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123965058584821760",
  "text" : "\u6587\u5B66\u90E8\u30E9\u30A6\u30F3\u30B8\u3067\u4ED6\u5B66\u90E8\u3046\u3089\u3084\u307E\u3057\u3044\u3068\u304B\u5BA3\u3046\u30AC\u30FC\u30EB\u30BA\u30C8\u30FC\u30AF\uFF08\u7B11\uFF09\u304C\u30A2\u30EC",
  "id" : 123965058584821760,
  "created_at" : "2011-10-12 03:35:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123924159649677312",
  "text" : "\u30A6\u30A7\u30B6\u30FC\u30CB\u30E5\u30FC\u30B9\u304C\u534A\u8896\u3067\u5E73\u6C17\u3063\u3066\u8A00\u3044\u5F35\u308B\u304B\u3089\u534A\u8896\u3067\u884C\u3053\u3046",
  "id" : 123924159649677312,
  "created_at" : "2011-10-12 00:53:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123923175942791169",
  "text" : "\u7D50\u5C40\u304E\u308A\u304E\u308A\u307E\u3067\u6DF7\u6FC1\u3057\u3066\u305F\u304B\n\n\u304A\u306F\u3088\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 123923175942791169,
  "created_at" : "2011-10-12 00:49:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123812719953592320",
  "text" : "\u5BDD\u306A\u3070\u3001\u56E0\u5E61\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 123812719953592320,
  "created_at" : "2011-10-11 17:30:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 12, 28 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123812390243536896",
  "text" : "\u3082\u3046\u4F59\u3063\u3066\u308B\u3088\u3045 RT @takasan_san_san: B\u7FA4\u300110\u5358\u4F4D\u3050\u3089\u3044\u4F59\u3089\u305B\u3066\u3084\u308B\u305C\uFF01",
  "id" : 123812390243536896,
  "created_at" : "2011-10-11 17:29:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "indices" : [ 3, 9 ],
      "id_str" : "127940910",
      "id" : 127940910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123794448755851264",
  "text" : "RT @alg_d: \u3010\u9078\u629E\u516C\u7406\u4E03\u3064\u306E\u5927\u7F6A\u3011\u5F37\u6B32\u300C\u5404\u96C6\u5408\u304B\u3089\u4E00\u500B\u305A\u3064\u5143\u3092\u53D6\u308C\u308B\u300D\u5AC9\u59AC\u300CZorn\u306E\u88DC\u984C\u4F7F\u3044\u3084\u3059\u3059\u304E\u3060\u308D\u2026\u300D\u50B2\u6162\u300CZF\u3068\u306F\u72EC\u7ACB\u300D\u6020\u60F0\u300C\u9078\u629E\u304C\u5177\u4F53\u7684\u306B\u3069\u3093\u306A\u304B\u306A\u3093\u3066\u77E5\u308B\u304B\u300D\u61A4\u6012\u300C\u30EB\u30D9\u30FC\u30B0\u6E2C\u5EA6\u3068\u304B\u4E0D\u5B8C\u5168\u3058\u3083\u306A\u3044\u304B\u7CDE\u304C\u300D\u66B4\u98DF\u300C\u3053\u306E\u30EA\u30F3\u30B4\u3092\u5897\u3084\u305D\u3046\u300D\u8272\u6B32\u300C\u3053\u306E\u96C6\u5408\u306B\u7FA4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "31378631162863616",
    "text" : "\u3010\u9078\u629E\u516C\u7406\u4E03\u3064\u306E\u5927\u7F6A\u3011\u5F37\u6B32\u300C\u5404\u96C6\u5408\u304B\u3089\u4E00\u500B\u305A\u3064\u5143\u3092\u53D6\u308C\u308B\u300D\u5AC9\u59AC\u300CZorn\u306E\u88DC\u984C\u4F7F\u3044\u3084\u3059\u3059\u304E\u3060\u308D\u2026\u300D\u50B2\u6162\u300CZF\u3068\u306F\u72EC\u7ACB\u300D\u6020\u60F0\u300C\u9078\u629E\u304C\u5177\u4F53\u7684\u306B\u3069\u3093\u306A\u304B\u306A\u3093\u3066\u77E5\u308B\u304B\u300D\u61A4\u6012\u300C\u30EB\u30D9\u30FC\u30B0\u6E2C\u5EA6\u3068\u304B\u4E0D\u5B8C\u5168\u3058\u3083\u306A\u3044\u304B\u7CDE\u304C\u300D\u66B4\u98DF\u300C\u3053\u306E\u30EA\u30F3\u30B4\u3092\u5897\u3084\u305D\u3046\u300D\u8272\u6B32\u300C\u3053\u306E\u96C6\u5408\u306B\u7FA4\u6F14\u7B97\u3092\u5165\u308C\u308B\u300D",
    "id" : 31378631162863616,
    "created_at" : "2011-01-29 15:50:23 +0000",
    "user" : {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "protected" : false,
      "id_str" : "127940910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579632693668773888\/0Susg2n0_normal.jpg",
      "id" : 127940910,
      "verified" : false
    }
  },
  "id" : 123794448755851264,
  "created_at" : "2011-10-11 16:17:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123793372069629952",
  "geo" : { },
  "id_str" : "123793587178713089",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30A2\u30B7\u30AB\u306F\u98FC\u308F\u306A\u3044\u3060\u308D\uFF57\uFF57\uFF57",
  "id" : 123793587178713089,
  "in_reply_to_status_id" : 123793372069629952,
  "created_at" : "2011-10-11 16:14:25 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 19, 26 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123793291039879168",
  "text" : "\u9078\u629E\u516C\u7406TL\u306BAC\u3068\u306F\u5947\u9047\u306A\u308A QT @ayu167: \u6700\u8FD1BMS\u306E\u65B0\u898F\u304C\u6E1B\u3063\u3066\u304D\u3066AC\u306E\u65B9\u304C\u697D\u3057\u304F\u306A\u3063\u3066\u304D\u305F",
  "id" : 123793291039879168,
  "created_at" : "2011-10-11 16:13:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123793046688120833",
  "text" : "\u305D\u3046\u3044\u3084\u6559\u6388\u304C\u6388\u696D\u4E2D\u306B\u30D9\u30EB\u30CA\u30C3\u30D7\u3063\u3066\u8AD6\u7406\u5B66\u8005\u306Ebot\u306E\u8A71\u3057\u3066\u3066\u7B11\u3063\u305F\u3002\u6642\u9593\u304C\u3042\u308B\u3068\u304D\u8ABF\u3079\u3066\u307F\u3088\u3046\u3002",
  "id" : 123793046688120833,
  "created_at" : "2011-10-11 16:12:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123792373829480448",
  "geo" : { },
  "id_str" : "123792671285329920",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3081\u3093\u3069\u3044\u304B\u3089\u5409\u7965\u5BFA\u306E\u3042\u305F\u308A\u306B\u4F4F\u3093\u3067\u308B\u3053\u3068\u306B\u3057\u3061\u3083\u3046\u7CFB\u7537\u5B50",
  "id" : 123792671285329920,
  "in_reply_to_status_id" : 123792373829480448,
  "created_at" : "2011-10-11 16:10:47 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123792452585926656",
  "text" : "\uFF13\u5E74\u5F8C\u3001\u6C34\u65CF\u9928\u3067\u9ED9\u3005\u3068\u50CD\u304Fend313124\u306E\u59FF\u304C\u3063\uFF01\u307F\u305F\u3044\u306A\uFF1F",
  "id" : 123792452585926656,
  "created_at" : "2011-10-11 16:09:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123792228442324992",
  "text" : "\u30A2\u30B7\u30AB\u597D\u304D\u3063\u3066\u66F8\u3044\u305F\u3089\u98FC\u80B2\u54E1\u3055\u3093\u304B\u3089\u30EA\u30D7\u30E9\u30A4\u98DB\u3093\u3067\u304D\u305F\u3002\n\u666E\u901A\u306B\u751F\u304D\u3066\u305F\u3089\u7D76\u5BFE\u95A2\u308F\u3089\u306A\u3044\u30BF\u30A4\u30D7\u306E\u8077\u696D\u3060\u308D\u3046\u306A\u3002",
  "id" : 123792228442324992,
  "created_at" : "2011-10-11 16:09:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123790900278206464",
  "text" : "\u5FAE\u7A4D\u7D9A\u8AD6\uFF22\u3060\u3051\u8A66\u9A13\u7279\u653B\u3057\u3088\u3046\u3002\n\u3073\u3076\u3093\u30FB\u305B\u304D\u3076\u3093\u5B66\u90E8\u304C\u8352\u3076\u308B\uFF6F\uFF08\u4E88\u5B9A\uFF09",
  "id" : 123790900278206464,
  "created_at" : "2011-10-11 16:03:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123790445066199040",
  "text" : "\u9078\u629E\u516C\u7406\u306E\u4EBA\u304C\u8352\u3076\u3063\u3066\u308B\uFF57",
  "id" : 123790445066199040,
  "created_at" : "2011-10-11 16:01:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "indices" : [ 3, 9 ],
      "id_str" : "127940910",
      "id" : 127940910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123790247397040128",
  "text" : "RT @alg_d: \u3055\u3042\u3069\u3046\u3057\u305F\u3000\u307E\u3060\u96C6\u5408\u65CF\u3092\u5B9A\u7FA9\u3057\u305F\u3060\u3051\u3060\u305E\u3000\u304B\u304B\u3063\u3066\u3053\u3044!\u3000\u9078\u629E\u95A2\u6570\u3092\u51FA\u305B!!\u96C6\u5408\u3092\u6574\u5217\u3055\u305B\u308D!!\u6F14\u7B97\u3092\u518D\u5B9A\u7FA9\u3057\u3066\u7FA4\u69CB\u9020\u3092\u5165\u308C\u308D!!Hamel\u57FA\u3092\u62FE\u3063\u3066\u95A2\u6570\u3092\u4F5C\u308C!!\u3055\u3042\u591C\u306F\u3053\u308C\u304B\u3089\u3060!!\u304A\u697D\u3057\u307F\u306F\u3053\u308C\u304B\u3089\u3060!!\u3000\u9078\u3079! \u9078\u3079\u9078\u3079!! \u9078\u3079\u9078\u3079\u9078\u3079! ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123787453344653312",
    "text" : "\u3055\u3042\u3069\u3046\u3057\u305F\u3000\u307E\u3060\u96C6\u5408\u65CF\u3092\u5B9A\u7FA9\u3057\u305F\u3060\u3051\u3060\u305E\u3000\u304B\u304B\u3063\u3066\u3053\u3044!\u3000\u9078\u629E\u95A2\u6570\u3092\u51FA\u305B!!\u96C6\u5408\u3092\u6574\u5217\u3055\u305B\u308D!!\u6F14\u7B97\u3092\u518D\u5B9A\u7FA9\u3057\u3066\u7FA4\u69CB\u9020\u3092\u5165\u308C\u308D!!Hamel\u57FA\u3092\u62FE\u3063\u3066\u95A2\u6570\u3092\u4F5C\u308C!!\u3055\u3042\u591C\u306F\u3053\u308C\u304B\u3089\u3060!!\u304A\u697D\u3057\u307F\u306F\u3053\u308C\u304B\u3089\u3060!!\u3000\u9078\u3079! \u9078\u3079\u9078\u3079!! \u9078\u3079\u9078\u3079\u9078\u3079!!!\u3000(\u9078\u3079\u306E\u8AAD\u307F\u306F\u30C1\u30E7\u30A4\u30B9)",
    "id" : 123787453344653312,
    "created_at" : "2011-10-11 15:50:03 +0000",
    "user" : {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "protected" : false,
      "id_str" : "127940910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579632693668773888\/0Susg2n0_normal.jpg",
      "id" : 127940910,
      "verified" : false
    }
  },
  "id" : 123790247397040128,
  "created_at" : "2011-10-11 16:01:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 3, 19 ],
      "id_str" : "230918258",
      "id" : 230918258
    }, {
      "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
      "screen_name" : "alg_d",
      "indices" : [ 24, 30 ],
      "id_str" : "127940910",
      "id" : 127940910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123790206221549569",
  "text" : "RT @takasan_san_san: RT @alg_d: \u3055\u3042\u3069\u3046\u3057\u305F\u3000\u307E\u3060\u96C6\u5408\u65CF\u3092\u5B9A\u7FA9\u3057\u305F\u3060\u3051\u3060\u305E\u3000\u304B\u304B\u3063\u3066\u3053\u3044!\u3000\u9078\u629E\u95A2\u6570\u3092\u51FA\u305B!!\u96C6\u5408\u3092\u6574\u5217\u3055\u305B\u308D!!\u6F14\u7B97\u3092\u518D\u5B9A\u7FA9\u3057\u3066\u7FA4\u69CB\u9020\u3092\u5165\u308C\u308D!!Hamel\u57FA\u3092\u62FE\u3063\u3066\u95A2\u6570\u3092\u4F5C\u308C!!\u3055\u3042\u591C\u306F\u3053\u308C\u304B\u3089\u3060!!\u304A\u697D\u3057\u307F\u306F\u3053\u308C\u304B\u3089\u3060 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u30EB\u30FC\u30EB\u8FFD\u52A0\u5927\u5BCC\u8C6A\u5927\u597D\u304Dbot",
        "screen_name" : "alg_d",
        "indices" : [ 3, 9 ],
        "id_str" : "127940910",
        "id" : 127940910
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123788101532397568",
    "text" : "RT @alg_d: \u3055\u3042\u3069\u3046\u3057\u305F\u3000\u307E\u3060\u96C6\u5408\u65CF\u3092\u5B9A\u7FA9\u3057\u305F\u3060\u3051\u3060\u305E\u3000\u304B\u304B\u3063\u3066\u3053\u3044!\u3000\u9078\u629E\u95A2\u6570\u3092\u51FA\u305B!!\u96C6\u5408\u3092\u6574\u5217\u3055\u305B\u308D!!\u6F14\u7B97\u3092\u518D\u5B9A\u7FA9\u3057\u3066\u7FA4\u69CB\u9020\u3092\u5165\u308C\u308D!!Hamel\u57FA\u3092\u62FE\u3063\u3066\u95A2\u6570\u3092\u4F5C\u308C!!\u3055\u3042\u591C\u306F\u3053\u308C\u304B\u3089\u3060!!\u304A\u697D\u3057\u307F\u306F\u3053\u308C\u304B\u3089\u3060!!\u3000\u9078\u3079! \u9078\u3079\u9078\u3079!!...",
    "id" : 123788101532397568,
    "created_at" : "2011-10-11 15:52:37 +0000",
    "user" : {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "protected" : false,
      "id_str" : "230918258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1856992486\/proko2_normal.jpeg",
      "id" : 230918258,
      "verified" : false
    }
  },
  "id" : 123790206221549569,
  "created_at" : "2011-10-11 16:00:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/JgCzkNkc",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=igaris",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "123739661502914560",
  "text" : "igaris\u304C\u3001\u79C1\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/JgCzkNkc",
  "id" : 123739661502914560,
  "created_at" : "2011-10-11 12:40:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123729698172833792",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 123729698172833792,
  "created_at" : "2011-10-11 12:00:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123649742965190656",
  "text" : "@ayu167 \u6559\u6388\u300C\u30AF\u30AF\u30AF\u2026\u5974\u306F\u56DB\u5929\u738B\u306E\u4E2D\u3067\u3082\u6700\u5F31\u2026\u300D",
  "id" : 123649742965190656,
  "created_at" : "2011-10-11 06:42:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123609614032961538",
  "geo" : { },
  "id_str" : "123634774916079616",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u3042\u3001\u306F\u3044",
  "id" : 123634774916079616,
  "in_reply_to_status_id" : 123609614032961538,
  "created_at" : "2011-10-11 05:43:22 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123632389795745792",
  "text" : "\u7761\u9B54\u3068\u8E0A\u308D\u3046",
  "id" : 123632389795745792,
  "created_at" : "2011-10-11 05:33:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123608367225769984",
  "geo" : { },
  "id_str" : "123609476740820992",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u3061\u3087\u3063\u3068\u8A00\u3063\u3066\u308B\u610F\u5473\u304C\u2026",
  "id" : 123609476740820992,
  "in_reply_to_status_id" : 123608367225769984,
  "created_at" : "2011-10-11 04:02:50 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrn",
      "indices" : [ 0, 12 ],
      "id_str" : "229754624",
      "id" : 229754624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123608078552797184",
  "geo" : { },
  "id_str" : "123608245603545088",
  "in_reply_to_user_id" : 229754624,
  "text" : "@nisehorrrrn \u30D2\u30E4\u30B7\u30F3\u30B9",
  "id" : 123608245603545088,
  "in_reply_to_status_id" : 123608078552797184,
  "created_at" : "2011-10-11 03:57:56 +0000",
  "in_reply_to_screen_name" : "nisehorrrrn",
  "in_reply_to_user_id_str" : "229754624",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123608009745248256",
  "text" : "\u30CF\u30A4\u30BB\u30F3\u30B9",
  "id" : 123608009745248256,
  "created_at" : "2011-10-11 03:57:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E6\u30F3\u30B0\uFF20VIPPER\u306A\u4FFA\u7BA1\u7406\u4EBA",
      "screen_name" : "news23vip",
      "indices" : [ 3, 13 ],
      "id_str" : "9420872",
      "id" : 9420872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123607949116571648",
  "text" : "RT @news23vip: \u6614\u3001\u3058\u3044\u3061\u3083\u3093\u306B\u300C\u3053\u308C\u3067\u7F8E\u5473\u3044\u3082\u3093\u98DF\u3048\u300D\u3063\u3066\u5C01\u7B52\u6E21\u3055\u308C\u3066\u4E2D\u3092\u898B\u3066\u307F\u305F\u3089\u7BB8\u304C\u51FA\u3066\u304D\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123523198791852032",
    "text" : "\u6614\u3001\u3058\u3044\u3061\u3083\u3093\u306B\u300C\u3053\u308C\u3067\u7F8E\u5473\u3044\u3082\u3093\u98DF\u3048\u300D\u3063\u3066\u5C01\u7B52\u6E21\u3055\u308C\u3066\u4E2D\u3092\u898B\u3066\u307F\u305F\u3089\u7BB8\u304C\u51FA\u3066\u304D\u305F\u3002",
    "id" : 123523198791852032,
    "created_at" : "2011-10-10 22:20:00 +0000",
    "user" : {
      "name" : "\u30E6\u30F3\u30B0\uFF20VIPPER\u306A\u4FFA\u7BA1\u7406\u4EBA",
      "screen_name" : "news23vip",
      "protected" : false,
      "id_str" : "9420872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2788875639\/71b5b93abdbcd85ab7b2481cda336951_normal.jpeg",
      "id" : 9420872,
      "verified" : false
    }
  },
  "id" : 123607949116571648,
  "created_at" : "2011-10-11 03:56:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u500D\u5897\u8A08\u753B\u3078\u306Econtribution",
      "screen_name" : "naota344",
      "indices" : [ 3, 12 ],
      "id_str" : "82888635",
      "id" : 82888635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123602528825917440",
  "text" : "RT @naota344: \u306A\u3093\u304B\u3088\u304F\u9759\u96FB\u6C17\u306A\u308B\u306E\u3067\u3001\u5B66\u6821\u306E\u30C9\u30A2\u306B\u624B\u3092\u304B\u3051\u3066\u306F\u30D1\u30C1\u30C3\u3068\u306A\u3063\u3066\u300C\u304F\u3063\uFF01\u3053\u3053\u306B\u3082\u7D50\u754C\u304C\u2026\uFF01\u3084\u3080\u3092\u3048\u3093\u4ECA\u65E5\u306E\u3068\u3053\u308D\u306F\u9000\u6563\u3059\u308B\u304B\u2026\u300D\u3068\u3044\u3046\u904A\u3073\u3092\u7E70\u308A\u8FD4\u3057\u3066\u305F\u3089\u7559\u5E74\u3059\u308B\u306E\u3067\u307F\u3093\u306A\u6C17\u3092\u3064\u3051\u307E\u3057\u3087\u3046\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123601981519568896",
    "text" : "\u306A\u3093\u304B\u3088\u304F\u9759\u96FB\u6C17\u306A\u308B\u306E\u3067\u3001\u5B66\u6821\u306E\u30C9\u30A2\u306B\u624B\u3092\u304B\u3051\u3066\u306F\u30D1\u30C1\u30C3\u3068\u306A\u3063\u3066\u300C\u304F\u3063\uFF01\u3053\u3053\u306B\u3082\u7D50\u754C\u304C\u2026\uFF01\u3084\u3080\u3092\u3048\u3093\u4ECA\u65E5\u306E\u3068\u3053\u308D\u306F\u9000\u6563\u3059\u308B\u304B\u2026\u300D\u3068\u3044\u3046\u904A\u3073\u3092\u7E70\u308A\u8FD4\u3057\u3066\u305F\u3089\u7559\u5E74\u3059\u308B\u306E\u3067\u307F\u3093\u306A\u6C17\u3092\u3064\u3051\u307E\u3057\u3087\u3046\u3002",
    "id" : 123601981519568896,
    "created_at" : "2011-10-11 03:33:03 +0000",
    "user" : {
      "name" : "\u500D\u5897\u8A08\u753B\u3078\u306Econtribution",
      "screen_name" : "naota344",
      "protected" : false,
      "id_str" : "82888635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2939771372\/f426a99aa4318d893371abe8eeb5915e_normal.jpeg",
      "id" : 82888635,
      "verified" : false
    }
  },
  "id" : 123602528825917440,
  "created_at" : "2011-10-11 03:35:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123602439269130240",
  "text" : "\u30D1\u30FC\u30DF\u30C6\u30FC\u30B7\u30E7\u30F3\u306B\u3082\u30D1\u30F3\u30C7\u30C8\u30A5\u30FC\u30C9\u306B\u3082\u53CD\u5FDC\u3057\u3066\u307B\u3057\u3044\u306A",
  "id" : 123602439269130240,
  "created_at" : "2011-10-11 03:34:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123602151967703040",
  "text" : "\u304A\u90AA\u9B54\u3077\u3088\u304B\u3088\u3063\u3001\u8A00\u308F\u308C\u306A\u304D\u3083\u6C17\u3065\u304B\u306A\u3044\u3088",
  "id" : 123602151967703040,
  "created_at" : "2011-10-11 03:33:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3077\u3088\u3077\u3088",
      "screen_name" : "PuyoPuyo_",
      "indices" : [ 3, 13 ],
      "id_str" : "92454439",
      "id" : 92454439
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 15, 25 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123602032891408384",
  "text" : "RT @PuyoPuyo_: @end313124 (\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/PuyoPuyo_\" rel=\"nofollow\"\u003E\u3077\u3088\u3077\u3088\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "123601255510708224",
    "geo" : { },
    "id_str" : "123601408699281409",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 (\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)(\u2299\u2299)",
    "id" : 123601408699281409,
    "in_reply_to_status_id" : 123601255510708224,
    "created_at" : "2011-10-11 03:30:46 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u3077\u3088\u3077\u3088",
      "screen_name" : "PuyoPuyo_",
      "protected" : false,
      "id_str" : "92454439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543211451\/puyo_normal.png",
      "id" : 92454439,
      "verified" : false
    }
  },
  "id" : 123602032891408384,
  "created_at" : "2011-10-11 03:33:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123601515272351745",
  "text" : "\u99AC\u3068\u7F8A\u3068\u30CD\u30B3\u3068\u30DA\u30F3\u30AE\u30F3\u3068\u30A2\u30B7\u30AB\u306F\u4E00\u65B9\u7684\u306B\u53CB\u9054\u3002\u5927\u597D\u304D\u3002",
  "id" : 123601515272351745,
  "created_at" : "2011-10-11 03:31:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3059\u304E",
      "screen_name" : "sugipack",
      "indices" : [ 3, 12 ],
      "id_str" : "9344212",
      "id" : 9344212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123601337706496001",
  "text" : "RT @sugipack: \u30DA\u30F3\u30AE\u30F3\u3063\u3066\u51C4\u304F\u597D\u5947\u5FC3\u65FA\u76DB\u3067\u666E\u6BB5\u5357\u6975\u306B\u3044\u306A\u3044\u300C\u4F55\u304B\u300D\u3092\u898B\u3064\u3051\u308B\u3068\u8FD1\u3065\u3044\u3066\u78BA\u304B\u3081\u3088\u3046\u3068\u3059\u308B\u3002\u3067\u3082\u5357\u6975\u6761\u7D04\u3067\u30DA\u30F3\u30AE\u30F3\u306B\u89E6\u308B\u306E\u306F\u3082\u3061\u308D\u3093\u8FD1\u3065\u304F\u3053\u3068\u3082\u7981\u6B62\u3055\u308C\u3066\u3044\u308B\u305F\u3081\u8D8A\u51AC\u968A\u54E1\u9054\u306F\u30D4\u30E7\u30B3\u30D4\u30E7\u30B3\u8FD1\u5BC4\u3063\u3066\u304F\u308B\u30DA\u30F3\u30AE\u30F3\u304B\u3089\u5FC5\u6B7B\u3067\u9003\u3052\u306A\u3051\u308C\u3070\u306A\u3089\u306A\u3044\u2026\u3068\u968A\u54E1\u306E ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123543226350182401",
    "text" : "\u30DA\u30F3\u30AE\u30F3\u3063\u3066\u51C4\u304F\u597D\u5947\u5FC3\u65FA\u76DB\u3067\u666E\u6BB5\u5357\u6975\u306B\u3044\u306A\u3044\u300C\u4F55\u304B\u300D\u3092\u898B\u3064\u3051\u308B\u3068\u8FD1\u3065\u3044\u3066\u78BA\u304B\u3081\u3088\u3046\u3068\u3059\u308B\u3002\u3067\u3082\u5357\u6975\u6761\u7D04\u3067\u30DA\u30F3\u30AE\u30F3\u306B\u89E6\u308B\u306E\u306F\u3082\u3061\u308D\u3093\u8FD1\u3065\u304F\u3053\u3068\u3082\u7981\u6B62\u3055\u308C\u3066\u3044\u308B\u305F\u3081\u8D8A\u51AC\u968A\u54E1\u9054\u306F\u30D4\u30E7\u30B3\u30D4\u30E7\u30B3\u8FD1\u5BC4\u3063\u3066\u304F\u308B\u30DA\u30F3\u30AE\u30F3\u304B\u3089\u5FC5\u6B7B\u3067\u9003\u3052\u306A\u3051\u308C\u3070\u306A\u3089\u306A\u3044\u2026\u3068\u968A\u54E1\u306E\u65B9\u306B\u805E\u304D\u307E\u3057\u305F(*\u00B4\u03C9\uFF40*)",
    "id" : 123543226350182401,
    "created_at" : "2011-10-10 23:39:35 +0000",
    "user" : {
      "name" : "\u3059\u304E",
      "screen_name" : "sugipack",
      "protected" : false,
      "id_str" : "9344212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484521519217795072\/Um26HnN6_normal.jpeg",
      "id" : 9344212,
      "verified" : false
    }
  },
  "id" : 123601337706496001,
  "created_at" : "2011-10-11 03:30:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CD\u30AE\u5E73",
      "screen_name" : "negi_hei",
      "indices" : [ 3, 12 ],
      "id_str" : "10021732",
      "id" : 10021732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123601255510708224",
  "text" : "RT @negi_hei: \u3075\u3044\u305F\u3000\uFF1E\u30AE\u30EA\u30B7\u30E3\u300C\u3048\u3044\u3063\u300D \n\u30A4\u30BF\u30EA\u30A2\u300C\u30D5\u30A1\u30A4\u30A2\u30FC\u300D \n\u30B9\u30DA\u30A4\u30F3\u300C\u30A2\u30A4\u30B9\u30B9\u30C8\u30FC\u30E0\u300D \n\u30DD\u30EB\u30C8\u30AC\u30EB\u300C\u30C0\u30A4\u30A2\u30AD\u30E5\u30FC\u30C8\u300D \n\u30A4\u30AE\u30EA\u30B9\u300C\u30D6\u30EC\u30A4\u30F3\u30C0\u30E0\u30C9\u300D \n\u30C9\u30A4\u30C4\u300C\u30B8\u30E5\u30B2\u30E0\u300D \n\u30A2\u30E1\u30EA\u30AB\u300C\u3070\u3063\u3088\u3048\u30FC\u3093\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123542977686671361",
    "text" : "\u3075\u3044\u305F\u3000\uFF1E\u30AE\u30EA\u30B7\u30E3\u300C\u3048\u3044\u3063\u300D \n\u30A4\u30BF\u30EA\u30A2\u300C\u30D5\u30A1\u30A4\u30A2\u30FC\u300D \n\u30B9\u30DA\u30A4\u30F3\u300C\u30A2\u30A4\u30B9\u30B9\u30C8\u30FC\u30E0\u300D \n\u30DD\u30EB\u30C8\u30AC\u30EB\u300C\u30C0\u30A4\u30A2\u30AD\u30E5\u30FC\u30C8\u300D \n\u30A4\u30AE\u30EA\u30B9\u300C\u30D6\u30EC\u30A4\u30F3\u30C0\u30E0\u30C9\u300D \n\u30C9\u30A4\u30C4\u300C\u30B8\u30E5\u30B2\u30E0\u300D \n\u30A2\u30E1\u30EA\u30AB\u300C\u3070\u3063\u3088\u3048\u30FC\u3093\u300D",
    "id" : 123542977686671361,
    "created_at" : "2011-10-10 23:38:35 +0000",
    "user" : {
      "name" : "\u30CD\u30AE\u5E73",
      "screen_name" : "negi_hei",
      "protected" : false,
      "id_str" : "10021732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588390145071579136\/8L_7hBo1_normal.png",
      "id" : 10021732,
      "verified" : false
    }
  },
  "id" : 123601255510708224,
  "created_at" : "2011-10-11 03:30:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123589390890041344",
  "text" : "@reflexio \u884C\u3063\u3066\u3089\u3063\u3057\u3083\u3044",
  "id" : 123589390890041344,
  "created_at" : "2011-10-11 02:43:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123588923892047874",
  "text" : "\u6559\u80B2\u3067\u66F8\u985E\u51FA\u3057\u3066\u3001\u501F\u308A\u305F\u53C2\u8003\u66F8\u30B3\u30D4\u30FC\u3057\u3066\u2026\u3084\u308B\u3053\u3068\u305F\u304F\u3055\u3093\u3002\u30CB\u9650\u304C\u65E9\u3081\u306B\u7D42\u308F\u3063\u3066\u304F\u308C\u3066\u52A9\u304B\u3063\u305F\u3002",
  "id" : 123588923892047874,
  "created_at" : "2011-10-11 02:41:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3067",
      "screen_name" : "Kadesh_Laurant",
      "indices" : [ 3, 18 ],
      "id_str" : "115065863",
      "id" : 115065863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123588457518989312",
  "text" : "RT @Kadesh_Laurant: 60\u6B73\u306B\u8FD1\u3044\u4EBA\u306F\u3001\u30A2\u30E9\u30AB\u30F3(\u30A2\u30E9\u30A6\u30F3\u30C9\u9084\u66A6) \u3067\u300160\u6B73\u904E\u304E\u3066\u3082\u3001\u30A2\u30E9\u30AB\u30F3(\u30A2\u30E9\u30A6\u30F3\u30C9\u68FA\u6876)\u3063\u3066\u306E\u306F\u7B11\u3063\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mixi.jp\/promotion.pl?id=voice_twitter\" rel=\"nofollow\"\u003E mixi\u30DC\u30A4\u30B9\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123584329514364928",
    "text" : "60\u6B73\u306B\u8FD1\u3044\u4EBA\u306F\u3001\u30A2\u30E9\u30AB\u30F3(\u30A2\u30E9\u30A6\u30F3\u30C9\u9084\u66A6) \u3067\u300160\u6B73\u904E\u304E\u3066\u3082\u3001\u30A2\u30E9\u30AB\u30F3(\u30A2\u30E9\u30A6\u30F3\u30C9\u68FA\u6876)\u3063\u3066\u306E\u306F\u7B11\u3063\u305F",
    "id" : 123584329514364928,
    "created_at" : "2011-10-11 02:22:54 +0000",
    "user" : {
      "name" : "\u304B\u3067",
      "screen_name" : "Kadesh_Laurant",
      "protected" : false,
      "id_str" : "115065863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608193672207867904\/bNkF6dGg_normal.png",
      "id" : 115065863,
      "verified" : false
    }
  },
  "id" : 123588457518989312,
  "created_at" : "2011-10-11 02:39:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123577788446937088",
  "text" : "\u3042\u30FC\u60C5\u3051\u306A\u3084\u3002\u3084\u3063\u3071\uFF13\uFF23\u306E\u6F14\u7FD2\u306F\u8DB3\u308A\u3066\u306A\u3044\u3088\u306A\u3041\u3002",
  "id" : 123577788446937088,
  "created_at" : "2011-10-11 01:56:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3068\u3082",
      "screen_name" : "tomo37",
      "indices" : [ 0, 7 ],
      "id_str" : "26393410",
      "id" : 26393410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123576992258981888",
  "geo" : { },
  "id_str" : "123577482375991297",
  "in_reply_to_user_id" : 26393410,
  "text" : "@tomo37 \u5206\u3051\u308B\u3063\u3066\u57FA\u672C\u7684\u767A\u60F3\u306E\u6B20\u5982\u3067\u3057\u305F\u3002\n\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\u3002\n\u6F14\u7FD2\u4E0D\u8DB3\uFF6F\u2026",
  "id" : 123577482375991297,
  "in_reply_to_status_id" : 123576992258981888,
  "created_at" : "2011-10-11 01:55:42 +0000",
  "in_reply_to_screen_name" : "tomo37",
  "in_reply_to_user_id_str" : "26393410",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 30, 40 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123575836849864704",
  "geo" : { },
  "id_str" : "123576567644422145",
  "in_reply_to_user_id" : 155546700,
  "text" : "tan\u306A\u3089\u89E3\u3051\u308B\u3051\u3069\u3001\u3069\u3046\u3084\u3063\u3066\u3082\u03B8\u304C\u6B8B\u308B\u3093\u3060\u3088\u306A\u3041 QT @end313124: (1-x)\/(1+x^2)\u306E\u7A4D\u5206\u304C\u89E3\u3051\u306A\u3044\u2026",
  "id" : 123576567644422145,
  "in_reply_to_status_id" : 123575836849864704,
  "created_at" : "2011-10-11 01:52:04 +0000",
  "in_reply_to_screen_name" : "end313124",
  "in_reply_to_user_id_str" : "155546700",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123575836849864704",
  "text" : "(1-x)\/(1+x^2)\u306E\u7A4D\u5206\u304C\u89E3\u3051\u306A\u3044\u2026",
  "id" : 123575836849864704,
  "created_at" : "2011-10-11 01:49:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123570007039938561",
  "text" : "\u5287\u7684\uFF01\u5FAE\u65B9\u30A2\u30D5\u30BF\u30FC\uFF01",
  "id" : 123570007039938561,
  "created_at" : "2011-10-11 01:26:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123311524692504576",
  "text" : "\u53CB\u4EBA\u5B85\u3067\u81EA\u4E3B\u6570\u5B66\u30BB\u30DF\u30CA\u30FC\n\u5FAE\u65B9\u3068\u4EE3\u6570\u3002\u9762\u767D\u304B\u3063\u305F\u308F\u30FC\u3002",
  "id" : 123311524692504576,
  "created_at" : "2011-10-10 08:18:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123310964161527808",
  "text" : "\u30AD\u30C1\u4E3C\u306E\u8A71\u3068\u304B\u80F8\u71B1",
  "id" : 123310964161527808,
  "created_at" : "2011-10-10 08:16:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123235010621878272",
  "text" : "\u92FC\uFF1F",
  "id" : 123235010621878272,
  "created_at" : "2011-10-10 03:14:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7F86",
      "screen_name" : "mhlworz",
      "indices" : [ 3, 11 ],
      "id_str" : "126808077",
      "id" : 126808077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123234949443764224",
  "text" : "RT @mhlworz: \u53CB\u4EBA\u306E\u5F01\u8B77\u58EB\u304B\u3089\u3002\u300C\u79CB\u306E\u591C\u9577\u306B\u3001\u7537\u5973\u95A2\u4FC2\u306E\u7D42\u308F\u308A\u306B\u3064\u3044\u3066\u3001\u6170\u8B1D\u6599\u8ACB\u6C42\u306E\u901A\u77E5\u66F8\u3092\u8D77\u6848\u3057\u3066\u305F\u308A\u3059\u308B\u3068\u3001\u3061\u3087\u3063\u3068\u3001\u3057\u3093\u307F\u308A\u3059\u308B\u306E\u3067\u3059\u3002\u611B\u306E\u7D42\u308F\u308A\u3092\u304A\u91D1\u306B\u5909\u3048\u3066\u307F\u305B\u307E\u3057\u3087\u3046\u3002\u305D\u3046\u3055\u3001\u6211\u3089\u306F\u3001\u92FC\u306E\u932C\u91D1\u8853\u5E2B\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121846659067023360",
    "text" : "\u53CB\u4EBA\u306E\u5F01\u8B77\u58EB\u304B\u3089\u3002\u300C\u79CB\u306E\u591C\u9577\u306B\u3001\u7537\u5973\u95A2\u4FC2\u306E\u7D42\u308F\u308A\u306B\u3064\u3044\u3066\u3001\u6170\u8B1D\u6599\u8ACB\u6C42\u306E\u901A\u77E5\u66F8\u3092\u8D77\u6848\u3057\u3066\u305F\u308A\u3059\u308B\u3068\u3001\u3061\u3087\u3063\u3068\u3001\u3057\u3093\u307F\u308A\u3059\u308B\u306E\u3067\u3059\u3002\u611B\u306E\u7D42\u308F\u308A\u3092\u304A\u91D1\u306B\u5909\u3048\u3066\u307F\u305B\u307E\u3057\u3087\u3046\u3002\u305D\u3046\u3055\u3001\u6211\u3089\u306F\u3001\u92FC\u306E\u932C\u91D1\u8853\u5E2B\u300D",
    "id" : 121846659067023360,
    "created_at" : "2011-10-06 07:18:01 +0000",
    "user" : {
      "name" : "\u7F86",
      "screen_name" : "mhlworz",
      "protected" : false,
      "id_str" : "126808077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000522940987\/a22a7b1b9fe6ed24be997eff3eb84e0a_normal.jpeg",
      "id" : 126808077,
      "verified" : false
    }
  },
  "id" : 123234949443764224,
  "created_at" : "2011-10-10 03:14:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123234264807514112",
  "geo" : { },
  "id_str" : "123234802282405889",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u30CA\u30A4\u30B9\u30DE\u30C3\u30C4\uFF01",
  "id" : 123234802282405889,
  "in_reply_to_status_id" : 123234264807514112,
  "created_at" : "2011-10-10 03:14:01 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123230814879236096",
  "text" : "\u5730\u9707\u76F8\u5909\u308F\u3089\u305A\u6D41\u884C\u3063\u3066\u308B\u306A",
  "id" : 123230814879236096,
  "created_at" : "2011-10-10 02:58:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123229820929835008",
  "geo" : { },
  "id_str" : "123230376662536192",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u7686\u307E\u3067\u8A00\u308F\u306D\u3070\u89E3\u3089\u306C\u304B",
  "id" : 123230376662536192,
  "in_reply_to_status_id" : 123229820929835008,
  "created_at" : "2011-10-10 02:56:25 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u3093",
      "screen_name" : "nisehorrn",
      "indices" : [ 0, 10 ],
      "id_str" : "96560355",
      "id" : 96560355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123229086259752960",
  "geo" : { },
  "id_str" : "123229644110561280",
  "in_reply_to_user_id" : 96560355,
  "text" : "@nisehorrn \u306F\u3041",
  "id" : 123229644110561280,
  "in_reply_to_status_id" : 123229086259752960,
  "created_at" : "2011-10-10 02:53:31 +0000",
  "in_reply_to_screen_name" : "nisehorrn",
  "in_reply_to_user_id_str" : "96560355",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123228808542298112",
  "text" : "\u8CE2\u3044",
  "id" : 123228808542298112,
  "created_at" : "2011-10-10 02:50:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3058\u306E",
      "screen_name" : "vibgyor_rainbow",
      "indices" : [ 3, 19 ],
      "id_str" : "94336239",
      "id" : 94336239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123228723381149696",
  "text" : "RT @vibgyor_rainbow: \u8272\u3093\u306A\u4EBA\u306B\u533F\u540D\u3067\u597D\u304D\u306A\u8CEA\u554F\u304C\u3067\u304D\u308B\u300C\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u300D\u3068\u3044\u3046\u30B5\u30FC\u30D3\u30B9\u3092\u4F7F\u3063\u3066\u3001\u300E\u6700\u8FD1\u306E\u51FA\u6765\u4E8B\u3067\u3001\u6700\u3082\u8208\u5473\u3092\u6301\u3063\u305F\u3082\u306E\u306F\u4F55\u3067\u3059\u304B\uFF1F\u300F\u3068\u304B\u300E\u3042\u306A\u305F\u3068\u3044\u3046\u4EBA\u9593\u3092\u4E00\u8A00\u3067\u8868\u73FE\u3057\u3066\u304F\u3060\u3055\u3044\u300F\u307F\u305F\u3044\u306A\u5C31\u8077\u9762\u63A5\u3067\u4F7F\u3048\u305D\u3046\u306A\u8CEA\u554F\u3092\u3057\u3066\u3001\u79C0\u9038\u306A\u56DE\u7B54 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/anond.hatelabo.jp\/20100118164647\" rel=\"nofollow\"\u003E\u975E\u516C\u5F0FRT\u3055\u308C\u305F\u3089\u79C1\u3001\u6CE3\u3044\u3061\u3083\u3046\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109553823839825921",
    "text" : "\u8272\u3093\u306A\u4EBA\u306B\u533F\u540D\u3067\u597D\u304D\u306A\u8CEA\u554F\u304C\u3067\u304D\u308B\u300C\u30B6\u30FB\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC\u30BA\u300D\u3068\u3044\u3046\u30B5\u30FC\u30D3\u30B9\u3092\u4F7F\u3063\u3066\u3001\u300E\u6700\u8FD1\u306E\u51FA\u6765\u4E8B\u3067\u3001\u6700\u3082\u8208\u5473\u3092\u6301\u3063\u305F\u3082\u306E\u306F\u4F55\u3067\u3059\u304B\uFF1F\u300F\u3068\u304B\u300E\u3042\u306A\u305F\u3068\u3044\u3046\u4EBA\u9593\u3092\u4E00\u8A00\u3067\u8868\u73FE\u3057\u3066\u304F\u3060\u3055\u3044\u300F\u307F\u305F\u3044\u306A\u5C31\u8077\u9762\u63A5\u3067\u4F7F\u3048\u305D\u3046\u306A\u8CEA\u554F\u3092\u3057\u3066\u3001\u79C0\u9038\u306A\u56DE\u7B54\u3092\u30E1\u30E2\u3057\u3066\u308B\u78EF\u91CE\u30AB\u30C4\u30AA\u3070\u308A\u306B\u60AA\u77E5\u6075\u306E\u50CD\u304F\u79C1\u306E\u53CB\u4EBA\u3002",
    "id" : 109553823839825921,
    "created_at" : "2011-09-02 09:10:41 +0000",
    "user" : {
      "name" : "\u306B\u3058\u306E",
      "screen_name" : "vibgyor_rainbow",
      "protected" : false,
      "id_str" : "94336239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1141883562\/aria_normal.png",
      "id" : 94336239,
      "verified" : false
    }
  },
  "id" : 123228723381149696,
  "created_at" : "2011-10-10 02:49:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123067131960115201",
  "text" : "\u3055\u3066\u3001\u5E03\u56E3\u3067\u4EE3\u6570\u3084\u308A\u306A\u304C\u3089\u7761\u9B54\u3092\u8FCE\u3048\u307E\u3059\u304B\u3002",
  "id" : 123067131960115201,
  "created_at" : "2011-10-09 16:07:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123067018579677186",
  "text" : "@koketomi \u30EC\u30DD\u30FC\u30C8\u671F\u9593\u306B\u30D6\u30EB\u30FC\u30B9\u30AF\u30EA\u30FC\u30F3\u3092\u898B\u305F\u6709\u540D\u4EBA\u3055\u3093\u304C\u3044\u307E\u3057\u3066\u306D\u30FB\u30FB\u30FB\u30FB",
  "id" : 123067018579677186,
  "created_at" : "2011-10-09 16:07:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123063240438718464",
  "text" : "\u30A2\u30A4\u30F3\u30B7\u30E5\u30BF\u30A4\u30F3\u81EA\u8EAB\u3082\u76F8\u5BFE\u6027\u7406\u8AD6\u306F\u771F\u7406\u306E\u8FD1\u4F3C\u3067\u3057\u304B\u306A\u3044\u3063\u3066\u8A00\u3063\u3066\u305F\u306E\u304B\u3002\u3053\u306E\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u8A00\u3046\u3068\u30CB\u30E5\u30FC\u30C8\u30EA\u30CE\u306E\u8A71\u306B\u898B\u3048\u308B\u3051\u3069\u3001\u305D\u3046\u3044\u3046\u610F\u56F3\u306F\u306A\u3044\u3093\u3060\u3051\u308C\u3069\u3002",
  "id" : 123063240438718464,
  "created_at" : "2011-10-09 15:52:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123061743655194624",
  "geo" : { },
  "id_str" : "123062233780596736",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5F15\u8D8A\u3057\u3057\u305F\u76F4\u5F8C\u306B\u8584\u3081\u306E\u6BDB\u5E03\u304C\uFF13\u679A\u3068\u539A\u624B\u306E\u5E03\u56E3\u304C\u3042\u3063\u305F\u5BB6\u306F\u7570\u7AEF\u306A\u306E\u304B",
  "id" : 123062233780596736,
  "in_reply_to_status_id" : 123061743655194624,
  "created_at" : "2011-10-09 15:48:17 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123055498814697474",
  "text" : "\u300C\u4FE1\u5FF5\u3068\u3044\u3046\u3082\u306E\u3092\u4FE1\u3058\u306A\u3044\u3002\u300D\u306A\u304B\u306A\u304B\u6DF1\u3044\u3002",
  "id" : 123055498814697474,
  "created_at" : "2011-10-09 15:21:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 10, 19 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123015336101556224",
  "geo" : { },
  "id_str" : "123016319196086274",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa @koketomi \u305D\u306E\u5FC5\u8981\u306F\u306A\u3044\u308F\u2606",
  "id" : 123016319196086274,
  "in_reply_to_status_id" : 123015336101556224,
  "created_at" : "2011-10-09 12:45:50 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123010042487259136",
  "text" : "@ayu167 \u98DB\u884C\u6A5F\u304C\u98DB\u3076\u7406\u5C48\u306F\u5B8C\u5168\u306B\u306F\u89E3\u3063\u3066\u306A\u3044\u3001\u3063\u3066\u6559\u3048\u3066\u3042\u3052\u308C",
  "id" : 123010042487259136,
  "created_at" : "2011-10-09 12:20:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123007927056478208",
  "geo" : { },
  "id_str" : "123008548207726592",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3042\u308A\u304C\u3068\u3002",
  "id" : 123008548207726592,
  "in_reply_to_status_id" : 123007927056478208,
  "created_at" : "2011-10-09 12:14:57 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123005945537249280",
  "geo" : { },
  "id_str" : "123006522438586368",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u82F1\u66F8\u8CFC\u8AAD\u3063\u3066\u3069\u3053\u307E\u3067\u9032\u3080\u3063\u3066\u8A00\u3063\u3066\u305F\u3063\u3051\uFF1F",
  "id" : 123006522438586368,
  "in_reply_to_status_id" : 123005945537249280,
  "created_at" : "2011-10-09 12:06:54 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123005430493487104",
  "text" : "@gnawty49 \u3042\u308C\u306F\u4E8C\u56DE\u76EE\u3067\u3082\u7B11\u3063\u3066\u3057\u307E\u3046",
  "id" : 123005430493487104,
  "created_at" : "2011-10-09 12:02:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123005092550033408",
  "text" : "\u30D5\u30EC\u30C3\u30B7\u30E5\u30CD\u30B9\u30D0\u30FC\u30AC\u30FC\u304F\u3089\u3044\u3067\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u306E\u8A8D\u8B58\u3002\u30E2\u30B9\u306F\u4E01\u5EA6\u5883\u754C\u304F\u3089\u3044\u304B\u306A\u30FC\u3002",
  "id" : 123005092550033408,
  "created_at" : "2011-10-09 12:01:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123004891982598146",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 123004891982598146,
  "created_at" : "2011-10-09 12:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123004537417109504",
  "text" : "\u3042\u3001\u3069\u3046\u3057\u3066\u3082\u4ED8\u304D\u5408\u3044\u3067\u884C\u304B\u306A\u304D\u3083\u3044\u3051\u306A\u3044\u6642\u306F\u91CE\u83DC\u751F\u6D3B\u306E\u30D1\u30C3\u30AF\u30B8\u30E5\u30FC\u30B9\u3067\u3059\u3057",
  "id" : 123004537417109504,
  "created_at" : "2011-10-09 11:59:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123004355862462464",
  "text" : "\u30DE\u30C3\u30AF\u306B\u98DF\u3079\u7269\u306A\u3093\u3066\u58F2\u3063\u3066\u306A\u3044\u3001\u3068\u3044\u3046\u504F\u3063\u305F\u8A8D\u8B58\u3002\u304A\u91D1\u3082\u3089\u3063\u3066\u3082\u98DF\u3079\u306A\u3044\u304B\u3082\u3002",
  "id" : 123004355862462464,
  "created_at" : "2011-10-09 11:58:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123004227726479360",
  "text" : "RT @0_uda: \u3068\u3053\u308D\u3067\u30DE\u30B8\u30EC\u30B9\u3057\u3066\u304A\u304F\u3068\u3001\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u304C\u305F\u304B\u3060\u304B 20 \u500B\u7A0B\u5EA6\u306A\u3089\u3001\u30B9\u30DE\u30A4\u30EB \u007B\u6700\u5C0F\u306E\u81EA\u7136\u6570\u007D \u5186\u3067\u559C\u3093\u3067\u300C\u304A\u6642\u9593\u9802\u3051\u307E\u3059\u304B\uFF1F\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u3060\u3051\u3060\u3068\u601D\u3046\u3002 (\u30FB\u03B5\u30FB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123003966249385984",
    "text" : "\u3068\u3053\u308D\u3067\u30DE\u30B8\u30EC\u30B9\u3057\u3066\u304A\u304F\u3068\u3001\u30CF\u30F3\u30D0\u30FC\u30AC\u30FC\u304C\u305F\u304B\u3060\u304B 20 \u500B\u7A0B\u5EA6\u306A\u3089\u3001\u30B9\u30DE\u30A4\u30EB \u007B\u6700\u5C0F\u306E\u81EA\u7136\u6570\u007D \u5186\u3067\u559C\u3093\u3067\u300C\u304A\u6642\u9593\u9802\u3051\u307E\u3059\u304B\uFF1F\u300D\u3063\u3066\u8A00\u308F\u308C\u308B\u3060\u3051\u3060\u3068\u601D\u3046\u3002 (\u30FB\u03B5\u30FB",
    "id" : 123003966249385984,
    "created_at" : "2011-10-09 11:56:45 +0000",
    "user" : {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "protected" : false,
      "id_str" : "184844182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547956554922614784\/ccU36n2B_normal.png",
      "id" : 184844182,
      "verified" : false
    }
  },
  "id" : 123004227726479360,
  "created_at" : "2011-10-09 11:57:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9234\u9375",
      "screen_name" : "SuzuKey",
      "indices" : [ 3, 11 ],
      "id_str" : "56093989",
      "id" : 56093989
    }, {
      "name" : "\u304E\u304A\u3093",
      "screen_name" : "gion_XY",
      "indices" : [ 13, 21 ],
      "id_str" : "194901561",
      "id" : 194901561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123003408612466688",
  "text" : "RT @SuzuKey: @gion_XY \u3072\u304D\u3064\u3063\u305F\u7B11\u307F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u304E\u304A\u3093",
        "screen_name" : "gion_XY",
        "indices" : [ 0, 8 ],
        "id_str" : "194901561",
        "id" : 194901561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "123002316533145600",
    "geo" : { },
    "id_str" : "123002479179874304",
    "in_reply_to_user_id" : 194901561,
    "text" : "@gion_XY \u3072\u304D\u3064\u3063\u305F\u7B11\u307F\u3002",
    "id" : 123002479179874304,
    "in_reply_to_status_id" : 123002316533145600,
    "created_at" : "2011-10-09 11:50:50 +0000",
    "in_reply_to_screen_name" : "gion_XY",
    "in_reply_to_user_id_str" : "194901561",
    "user" : {
      "name" : "\u9234\u9375",
      "screen_name" : "SuzuKey",
      "protected" : false,
      "id_str" : "56093989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000263894386\/f97273ebffcfc842c85485a211cbad7e_normal.png",
      "id" : 56093989,
      "verified" : false
    }
  },
  "id" : 123003408612466688,
  "created_at" : "2011-10-09 11:54:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304E\u304A\u3093",
      "screen_name" : "gion_XY",
      "indices" : [ 3, 11 ],
      "id_str" : "194901561",
      "id" : 194901561
    }, {
      "name" : "\u9234\u9375",
      "screen_name" : "SuzuKey",
      "indices" : [ 13, 21 ],
      "id_str" : "56093989",
      "id" : 56093989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123003394322477056",
  "text" : "RT @gion_XY: @SuzuKey \u30B9\u30DE\u30A4\u30EB2+3i\u500B\u304F\u3060\u3055\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u9234\u9375",
        "screen_name" : "SuzuKey",
        "indices" : [ 0, 8 ],
        "id_str" : "56093989",
        "id" : 56093989
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "123001917642256384",
    "geo" : { },
    "id_str" : "123002316533145600",
    "in_reply_to_user_id" : 56093989,
    "text" : "@SuzuKey \u30B9\u30DE\u30A4\u30EB2+3i\u500B\u304F\u3060\u3055\u3044",
    "id" : 123002316533145600,
    "in_reply_to_status_id" : 123001917642256384,
    "created_at" : "2011-10-09 11:50:12 +0000",
    "in_reply_to_screen_name" : "SuzuKey",
    "in_reply_to_user_id_str" : "56093989",
    "user" : {
      "name" : "\u304E\u304A\u3093",
      "screen_name" : "gion_XY",
      "protected" : false,
      "id_str" : "194901561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488071615721132033\/zQGVW6uU_normal.jpeg",
      "id" : 194901561,
      "verified" : false
    }
  },
  "id" : 123003394322477056,
  "created_at" : "2011-10-09 11:54:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9234\u9375",
      "screen_name" : "SuzuKey",
      "indices" : [ 3, 11 ],
      "id_str" : "56093989",
      "id" : 56093989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123003367059488768",
  "text" : "RT @SuzuKey: \u79C1\u306E\u4E2D\u3067\u306E\u81EA\u7136\u6570\u306E\u5B9A\u7FA9\u306F\u201D\u30DE\u30C3\u30AF\u3067\u6CE8\u6587\u3057\u3066\u3082\u5ACC\u306A\u9854\u3055\u308C\u306A\u3044\u6570\u201D\u3063\u3066\u8A00\u3044\u8A33\u8003\u3048\u305F\u3051\u3069\u3001\u3053\u308C\u3060\u3068\uFF12\uFF10\u3042\u305F\u308A\u304B\u3089\u81EA\u7136\u6570\u3058\u3083\u306A\u304F\u306A\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123001708820443136",
    "text" : "\u79C1\u306E\u4E2D\u3067\u306E\u81EA\u7136\u6570\u306E\u5B9A\u7FA9\u306F\u201D\u30DE\u30C3\u30AF\u3067\u6CE8\u6587\u3057\u3066\u3082\u5ACC\u306A\u9854\u3055\u308C\u306A\u3044\u6570\u201D\u3063\u3066\u8A00\u3044\u8A33\u8003\u3048\u305F\u3051\u3069\u3001\u3053\u308C\u3060\u3068\uFF12\uFF10\u3042\u305F\u308A\u304B\u3089\u81EA\u7136\u6570\u3058\u3083\u306A\u304F\u306A\u308B\u3002",
    "id" : 123001708820443136,
    "created_at" : "2011-10-09 11:47:47 +0000",
    "user" : {
      "name" : "\u9234\u9375",
      "screen_name" : "SuzuKey",
      "protected" : false,
      "id_str" : "56093989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000263894386\/f97273ebffcfc842c85485a211cbad7e_normal.png",
      "id" : 56093989,
      "verified" : false
    }
  },
  "id" : 123003367059488768,
  "created_at" : "2011-10-09 11:54:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122990317589905409",
  "text" : "\u304A\u5BFF\u53F8\u98DF\u3079\u305F\u3044\u2026\u6B21\u306B\u5E30\u7701\u3057\u305F\u6642\u306B\u7D76\u5BFE\u98DF\u3079\u3066\u3084\u308D\u3046\u3002",
  "id" : 122990317589905409,
  "created_at" : "2011-10-09 11:02:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122921484611096576",
  "text" : "\u6642\u9593\u3092\u8CAF\u84C4\u51FA\u6765\u305F\u3089\u826F\u3044\u306E\u306B\u306A",
  "id" : 122921484611096576,
  "created_at" : "2011-10-09 06:29:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122921387512954880",
  "text" : "\u3080\u3045\u3001\u3082\u3046\u4E09\u9023\u4F11\u306E\u534A\u5206\u4EE5\u4E0A\u4F7F\u3063\u3061\u3083\u3063\u305F\u306E\u304B",
  "id" : 122921387512954880,
  "created_at" : "2011-10-09 06:28:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122888128422883328",
  "text" : "\u3042\u3001\u304A\u306F\u3088\u3046\u3002\u5B9F\u306F\u4E8C\u5EA6\u5BDD\u3057\u305F\u3051\u3069\u5BDD\u904E\u304E\u305F\u3002",
  "id" : 122888128422883328,
  "created_at" : "2011-10-09 04:16:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122887173740560384",
  "geo" : { },
  "id_str" : "122887987523620864",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u98DB\u3079\u308B\u306A\u3089\u8CB7\u3046\u306E\u3082\u3084\u3076\u3055\u304B\u3067\u306A\u3044",
  "id" : 122887987523620864,
  "in_reply_to_status_id" : 122887173740560384,
  "created_at" : "2011-10-09 04:15:54 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "184844182",
      "id" : 184844182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122715091639615488",
  "text" : "RT @0_uda: \u8A00\u308F\u308C\u3066\u307E\u3059\u3088\u8CB4\u65B9\u9054\u3002 (\u30FB\u03B5\u30FB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122714640076640257",
    "text" : "\u8A00\u308F\u308C\u3066\u307E\u3059\u3088\u8CB4\u65B9\u9054\u3002 (\u30FB\u03B5\u30FB",
    "id" : 122714640076640257,
    "created_at" : "2011-10-08 16:47:04 +0000",
    "user" : {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "protected" : false,
      "id_str" : "184844182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547956554922614784\/ccU36n2B_normal.png",
      "id" : 184844182,
      "verified" : false
    }
  },
  "id" : 122715091639615488,
  "created_at" : "2011-10-08 16:48:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3089\u3070Q",
      "screen_name" : "lbqcom",
      "indices" : [ 45, 52 ],
      "id_str" : "91107876",
      "id" : 91107876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/nrDEUz3y",
      "expanded_url" : "http:\/\/labaq.com\/archives\/50777956.html",
      "display_url" : "labaq.com\/archives\/50777\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "122699793674932224",
  "text" : "\u8077\u5834\u3067\u5ACC\u308F\u308C\u305F\u3044\u4EBA\u306E\u305F\u3081\u306E101\u306E\u65B9\u6CD5 http:\/\/t.co\/nrDEUz3y via @lbqcom",
  "id" : 122699793674932224,
  "created_at" : "2011-10-08 15:48:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 3, 12 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122696141224685568",
  "text" : "RT @hanaoka_: \u6559\u6388\u300C\u304D\u307F\u306F\u30A6\u30A3\u30AD\u30DA\u30C7\u30A3\u30A2\u306E\u3053\u306E\u9805\u76EE\u3092\u30B3\u30D4\u30DA\u3057\u305F\u306D\u300D\n\u5B66\u751F\u300C\u306F\u3044\u3002\u3053\u308C\u306F\u6559\u6388\u304C\u7DE8\u96C6\u3057\u305F\u3082\u306E\u3067\u3059\u306D\u300D\n\u6559\u6388\u300C\u3044\u304B\u306B\u3082\u300D\n\u5B66\u751F\u300C\u3053\u3053\u306B\u306F\u95B2\u89A7\u8005\u3092\u6B3A\u304F\u305F\u3081\u3068\u3057\u304B\u601D\u3048\u306A\u3044\u8AA4\u8B2C\u304C\u3042\u308A\u307E\u3059\u3002\u4F55\u3092\u76EE\u7684\u3068\u3057\u3066\u8A18\u8FF0\u3057\u305F\u3093\u3067\u3059\u304B\uFF1F\u771F\u610F\u3092\u6559\u3048\u3066\u4E0B\u3055\u3044\u300D\n\u6559\u6388\u300C\u541B\u306E\u3088 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122695475903201280",
    "text" : "\u6559\u6388\u300C\u304D\u307F\u306F\u30A6\u30A3\u30AD\u30DA\u30C7\u30A3\u30A2\u306E\u3053\u306E\u9805\u76EE\u3092\u30B3\u30D4\u30DA\u3057\u305F\u306D\u300D\n\u5B66\u751F\u300C\u306F\u3044\u3002\u3053\u308C\u306F\u6559\u6388\u304C\u7DE8\u96C6\u3057\u305F\u3082\u306E\u3067\u3059\u306D\u300D\n\u6559\u6388\u300C\u3044\u304B\u306B\u3082\u300D\n\u5B66\u751F\u300C\u3053\u3053\u306B\u306F\u95B2\u89A7\u8005\u3092\u6B3A\u304F\u305F\u3081\u3068\u3057\u304B\u601D\u3048\u306A\u3044\u8AA4\u8B2C\u304C\u3042\u308A\u307E\u3059\u3002\u4F55\u3092\u76EE\u7684\u3068\u3057\u3066\u8A18\u8FF0\u3057\u305F\u3093\u3067\u3059\u304B\uFF1F\u771F\u610F\u3092\u6559\u3048\u3066\u4E0B\u3055\u3044\u300D\n\u6559\u6388\u300C\u541B\u306E\u3088\u3046\u306A\u52D8\u306E\u3044\u3044\u30AC\u30AD\u306F\u5ACC\u3044\u3060\u3088\u300D",
    "id" : 122695475903201280,
    "created_at" : "2011-10-08 15:30:55 +0000",
    "user" : {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "protected" : false,
      "id_str" : "126927392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540399732707688448\/Iqz4rTVp_normal.jpeg",
      "id" : 126927392,
      "verified" : false
    }
  },
  "id" : 122696141224685568,
  "created_at" : "2011-10-08 15:33:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122685437377654784",
  "text" : "\u307E\u3041\u3001\u81EA\u5206\u304C\u6587\u5B66\u90E8\u3092\u8A9E\u308B\u306A\u3093\u3066\u3061\u3083\u3093\u3061\u3083\u3089\u5999\u306A\u8A71\u306A\u3093\u3060\u3051\u3069\u3002",
  "id" : 122685437377654784,
  "created_at" : "2011-10-08 14:51:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 26, 36 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122685231319883776",
  "text" : "\u6587\u5B66\u90E8\u306F\u904A\u3076\u3093\u5B66\u90E8\u3060\u3051\u308C\u3069\u3082\u3001\u4EE5\u4E0B\u540C\u6587\u3067\u3059\u3002 RT @Keitaecon \u7D4C\u6E08\u5B66\u90E8\u306F\u30D1\u30E9\u30C0\u30A4\u30B9\u7D4C\u6E08\u5B66\u90E8\u3060\u3051\u308C\u3069\u3082\uFF0C\u305A\u3063\u3068\u305A\u3063\u3068\u52C9\u5F37\u3057\u3066\u3044\u306A\u3044\u5974\u3084\u6642\u9593\u304C\u6709\u308A\u4F59\u3063\u3066\u308B\u5974\u3070\u304B\u308A\u3067\u306F\u6709\u308A\u307E\u305B\u3093\u3088\uFF0E",
  "id" : 122685231319883776,
  "created_at" : "2011-10-08 14:50:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iris pe\u00F1a",
      "screen_name" : "iris1211",
      "indices" : [ 0, 9 ],
      "id_str" : "601994539",
      "id" : 601994539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122683959128752129",
  "geo" : { },
  "id_str" : "122684306194833408",
  "in_reply_to_user_id" : 199550192,
  "text" : "@iris1211 \u672C\u5F53\u306B\u30C6\u30EC\u30D3\u306A\u3044\u304B\u3089\u6255\u3063\u3066\u306A\u3044\u3002\u30D4\u30BF\u30B4\u30E9\u30B9\u30A4\u30C3\u30C1\u306B\u306F\u6255\u3063\u3066\u3082\u3044\u3044\u3068\u601D\u3046\u3002",
  "id" : 122684306194833408,
  "in_reply_to_status_id" : 122683959128752129,
  "created_at" : "2011-10-08 14:46:32 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toshi",
      "screen_name" : "iwa_bj21",
      "indices" : [ 0, 9 ],
      "id_str" : "305542897",
      "id" : 305542897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122683364154155009",
  "geo" : { },
  "id_str" : "122683802874150912",
  "in_reply_to_user_id" : 305542897,
  "text" : "@iwa_bj21 \u304C\u3093\u3070\u3063\u3066\u304F\u3060\u3055\u3044\u3002\u524D\u3088\u308A\u7D76\u5BFE\u3046\u307E\u304F\u306A\u3063\u3066\u308B\u306F\u305A\u3067\u3059\uFF01",
  "id" : 122683802874150912,
  "in_reply_to_status_id" : 122683364154155009,
  "created_at" : "2011-10-08 14:44:32 +0000",
  "in_reply_to_screen_name" : "iwa_bj21",
  "in_reply_to_user_id_str" : "305542897",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122681943308500992",
  "text" : "\u3042\u3089\u3001\u5168\u89D2\u306B\u306A\u3063\u3061\u3083\u3063\u3066\u308B\u3002\u307E\u3041\u3044\u3044\u3093\u3060\u3051\u3069\u3055\u3002",
  "id" : 122681943308500992,
  "created_at" : "2011-10-08 14:37:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122681808352587776",
  "text" : "\u76F8\u5909\u308F\u3089\u305A\u3042\u3089\u3076\u3063\u3066\u308B\u3088\u306A\u30FC\u3002\uFF2C\uFF49\uFF53\uFF41_\uFF2D\uFF41\uFF54\uFF48\u306E\u8A71\u3060\u3051\u3069\u3002",
  "id" : 122681808352587776,
  "created_at" : "2011-10-08 14:36:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122681523848740864",
  "text" : "\u914D\u724C\u3068\u304B\u30C4\u30E2\u3068\u304B\u8A00\u3063\u3061\u3083\u3046\u3088\u3001\u3046\u3093\u3002",
  "id" : 122681523848740864,
  "created_at" : "2011-10-08 14:35:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122680696836861952",
  "geo" : { },
  "id_str" : "122680942388199424",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u5168\u6821\u96C6\u4F1A\u306F\u7121\u610F\u5473",
  "id" : 122680942388199424,
  "in_reply_to_status_id" : 122680696836861952,
  "created_at" : "2011-10-08 14:33:10 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122680289033068544",
  "geo" : { },
  "id_str" : "122680613810606080",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math \u300A\u3061\u3083\u3093\u300B\u306F\u4E0D\u8981",
  "id" : 122680613810606080,
  "in_reply_to_status_id" : 122680289033068544,
  "created_at" : "2011-10-08 14:31:52 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122680549537099776",
  "text" : "\u81EA\u5206\u3082\u3075\u3056\u3051\u3066\u4F7F\u3046\u3051\u308C\u3069\u3001\u25CB\u25CB\u7CFB\u5973\u5B50\uFF0F\u7537\u5B50\u3001\u25CB\u25CB\u529B\u3063\u3066\u8513\u5EF6\u308A\u3059\u304E\u3060\u3088\u306A\u30FC\u3002",
  "id" : 122680549537099776,
  "created_at" : "2011-10-08 14:31:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u53CC\u5009\u30EA\u30B5",
      "screen_name" : "Lisa_math",
      "indices" : [ 0, 10 ],
      "id_str" : "254452685",
      "id" : 254452685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122680144224714752",
  "geo" : { },
  "id_str" : "122680242019115009",
  "in_reply_to_user_id" : 254452685,
  "text" : "@Lisa_math 00101",
  "id" : 122680242019115009,
  "in_reply_to_status_id" : 122680144224714752,
  "created_at" : "2011-10-08 14:30:23 +0000",
  "in_reply_to_screen_name" : "Lisa_math",
  "in_reply_to_user_id_str" : "254452685",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iris pe\u00F1a",
      "screen_name" : "iris1211",
      "indices" : [ 0, 9 ],
      "id_str" : "601994539",
      "id" : 601994539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122678791888838656",
  "geo" : { },
  "id_str" : "122679307725312000",
  "in_reply_to_user_id" : 199550192,
  "text" : "@iris1211 \u5B8C\u5168\u6570\u840C\u3048\u3068\u304B\u3001\u8907\u96D1\u305D\u3046\u306A\u51FD\u6570\u3060\u3051\u3069\u7A4D\u5206\u3057\u3066\u307F\u305F\u3089\u7DBA\u9E97\u306A\u5024\u306B\u306A\u3063\u305F\u840C\u3048\u3068\u304B",
  "id" : 122679307725312000,
  "in_reply_to_status_id" : 122678791888838656,
  "created_at" : "2011-10-08 14:26:40 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122679046814437377",
  "text" : "\u3080\u3057\u308D\u300C\u53EF\u611B\u3044\u3063\u3066\u8A00\u3063\u3066\u308B\u81EA\u5206\u53EF\u611B\u3044\u7CFB\u5973\u5B50\u300D\u3088\u308A\u306F\u7D14\u7C8B\u3060\u3068\u601D\u3063\u3066\u3057\u307E\u3046\u3002",
  "id" : 122679046814437377,
  "created_at" : "2011-10-08 14:25:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122678573055213568",
  "text" : "\u6700\u5F8C\u306E\u4E00\u6587\u306F\u4F59\u8A08\u3060\u3051\u308C\u3069\u3001\u304B\u308F\u3044\u3044\u3082\u306E\u597D\u304D\u3067\u4F55\u304C\u60AA\u3044\u3002",
  "id" : 122678573055213568,
  "created_at" : "2011-10-08 14:23:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122678372114501632",
  "text" : "\u307E\u3060\u65E5\u4ED8\u304C\u5909\u308F\u3063\u3066\u306A\u3044\u3053\u3068\u306B\u9A5A\u304D\u3092\u96A0\u305B\u306A\u3044\uFF12\uFF13\uFF1A\uFF12\uFF12\u5206",
  "id" : 122678372114501632,
  "created_at" : "2011-10-08 14:22:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122677392178294785",
  "text" : "\uFF34\uFF2C\u304C\u3069\u3093\u3069\u3093\u6570\u5B66\u8272\u306B\u306A\u3063\u3066\u3044\u304F\u2026\u3044\u3044\u610F\u5473\u3067\u3002",
  "id" : 122677392178294785,
  "created_at" : "2011-10-08 14:19:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122676386577125376",
  "text" : "\u3044\u307E\u3055\u3089\u03C0\u3092\uFF50\u3068\u306F\u8AAD\u3081\u306A\u3044\u3057\u306D\u30FC",
  "id" : 122676386577125376,
  "created_at" : "2011-10-08 14:15:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122676297590767616",
  "text" : "\u53CB\u4EBA\u300C\u4E00\u7DD2\u306B\u30AE\u30EA\u30B7\u30E3\u8A9E\u3084\u3089\u306A\u3044\uFF1F\u300D\n\u4FFA\u300C\u3042\u30FC\u3001\u4E00\u6587\u5B57\u4E00\u6587\u5B57\u306B\u610F\u5473\u304C\u3042\u308B\u3088\u3046\u306B\u898B\u3048\u308B\u304B\u3089\u7121\u7406\u300D",
  "id" : 122676297590767616,
  "created_at" : "2011-10-08 14:14:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/cXxKfwmH",
      "expanded_url" : "http:\/\/shindanmaker.com\/159116",
      "display_url" : "shindanmaker.com\/159116"
    } ]
  },
  "geo" : { },
  "id_str" : "122675690461085696",
  "text" : "end313124\u304C\u544A\u767D\u3055\u308C\u308B\u307E\u3067\u3042\u3068111\u5E74\u3067\u3059\u3002\u304A\u3081\u3067\u3068\u3046\u3002 http:\/\/t.co\/cXxKfwmH  \u308F\u30FC\u3044\u3001\u305E\u308D\u76EE\u3060(\u767D\u76EE",
  "id" : 122675690461085696,
  "created_at" : "2011-10-08 14:12:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/8o2HD0A5",
      "expanded_url" : "http:\/\/shindanmaker.com\/159415",
      "display_url" : "shindanmaker.com\/159415"
    } ]
  },
  "geo" : { },
  "id_str" : "122674906453393408",
  "text" : "end313124\u3055\u3093\u306B\u4F3C\u5408\u3046\u540D\u5B57\u306F\u963F\u90E8(\u3042\u3079)\u3067\u3059\u3002\u306F\u3044\u3001\u7D20\u6575\u3067\u3059\u3002 http:\/\/t.co\/8o2HD0A5  \u6BCD\u65B9\u306E\u5B9F\u5BB6\u304C\u305D\u3046\u3060\u3063\u305F\u3088\u3046\u306A",
  "id" : 122674906453393408,
  "created_at" : "2011-10-08 14:09:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122661845600440320",
  "text" : "RT @akeopyaa: \u53CB\u300C\u304A\u524D\u5F7C\u5973\u3044\u308B\uFF1F\u300D\n\u4FFA\u300C\u3044\u3089\u306A\u3044\u300D\n\u53CB\u300C\u300D\n\u4FFA\u300C\u300D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122661749387309056",
    "text" : "\u53CB\u300C\u304A\u524D\u5F7C\u5973\u3044\u308B\uFF1F\u300D\n\u4FFA\u300C\u3044\u3089\u306A\u3044\u300D\n\u53CB\u300C\u300D\n\u4FFA\u300C\u300D",
    "id" : 122661749387309056,
    "created_at" : "2011-10-08 13:16:54 +0000",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 122661845600440320,
  "created_at" : "2011-10-08 13:17:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 0, 10 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122661502179221504",
  "geo" : { },
  "id_str" : "122661727660802049",
  "in_reply_to_user_id" : 126326979,
  "text" : "@Keitaecon \u81EA\u5BA4\u3067\u7D4C\u6E08\u30BB\u30DF\u30CA\u30FC\u3068\u304B\u958B\u3044\u305F\u3089\u4FBF\u5229\u304B\u3082\u3057\u308C\u307E\u305B\u3093\u306D\uFF57",
  "id" : 122661727660802049,
  "in_reply_to_status_id" : 122661502179221504,
  "created_at" : "2011-10-08 13:16:49 +0000",
  "in_reply_to_screen_name" : "Keitaecon",
  "in_reply_to_user_id_str" : "126326979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122661355953205248",
  "text" : "\u307E\u3001\u5C11\u3057\u306F\u52D5\u304B\u306A\u3044\u3053\u3068\u3092\u899A\u3048\u3066\u304F\u308C\u308B\u3068\u3044\u3044\u306E\u3067\u3059\u304C",
  "id" : 122661355953205248,
  "created_at" : "2011-10-08 13:15:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122661272285229056",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u5F1F\u306E\u8DB3\u9996\u306E\u9AA8\u304C\u307B\u307C\u9AA8\u6298\u3089\u3057\u3044\u3002\u30B9\u30DD\u30FC\u30C4\u5C11\u5E74\uFF08\uFF09\u3060\u304B\u3089\u306A\u3001\u3056\u307E\u3041\uFF57\uFF57\uFF57\uFF57",
  "id" : 122661272285229056,
  "created_at" : "2011-10-08 13:15:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAKANO, Keita.econ",
      "screen_name" : "Keitaecon",
      "indices" : [ 26, 36 ],
      "id_str" : "126326979",
      "id" : 126326979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/h2J1stJG",
      "expanded_url" : "http:\/\/twitpic.com\/6x0qq6",
      "display_url" : "twitpic.com\/6x0qq6"
    } ]
  },
  "in_reply_to_status_id_str" : "122660407755288576",
  "geo" : { },
  "id_str" : "122660793660616704",
  "in_reply_to_user_id" : 126326979,
  "text" : "\u3042\u3089\u304B\u308F\u3044\u3044\u3002\u3066\u304B\u81EA\u5BA4\u306B\u767D\u677F\u3042\u308B\u3093\u3067\u3059\u304B\uFF57\uFF57 RT @Keitaecon \u5E30\u5B85\u3057\u305F\u3089\u81EA\u5BA4\u306E\u30DB\u30EF\u30A4\u30C8\u30DC\u30FC\u30C9\u306B\u843D\u66F8\u304D\u304C\u3057\u3066\u3042\u3063\u305F\u3002\u53EF\u611B\u3044w http:\/\/t.co\/h2J1stJG",
  "id" : 122660793660616704,
  "in_reply_to_status_id" : 122660407755288576,
  "created_at" : "2011-10-08 13:13:06 +0000",
  "in_reply_to_screen_name" : "Keitaecon",
  "in_reply_to_user_id_str" : "126326979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122659983488847872",
  "text" : "\u732B\u3092\u98FC\u3048\u308B\u3068\u3053\u308D\u306B\u5F15\u3063\u8D8A\u3057\u3092\u4E00\u77AC\u8003\u3048\u306A\u3044\u3067\u3082\u306A\u3044\u7A0B\u5EA6\u306B\u306F\u732B\u597D\u304D",
  "id" : 122659983488847872,
  "created_at" : "2011-10-08 13:09:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122659833571840001",
  "text" : "\u3053\u306E\u5B63\u7BC0\u306B\u306A\u308B\u3068\u6E6F\u305F\u3093\u307D\u307F\u305F\u3044\u306A\u732B\u304C\u6B32\u3057\u3044\u3002",
  "id" : 122659833571840001,
  "created_at" : "2011-10-08 13:09:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122656469605826561",
  "text" : "\u30EA\u30B5\u3061\u3083\u3093\u306B0\u306F\u81EA\u7136\u6570\u30AF\u30E9\u30B9\u30BF\u306E\u653B\u6483\u304C\uFF57\uFF57",
  "id" : 122656469605826561,
  "created_at" : "2011-10-08 12:55:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122649168392101888",
  "text" : "\u77F3\u6A4B\u3092\u53E9\u3044\u3066\u6E21\u308B\u3068\u304B\u53E9\u3044\u3066\u5272\u308B\u3068\u304B\u3001\u3069\u3063\u3061\u306B\u3057\u308D\u81EA\u5206\u306B\u3068\u3063\u3066\u306F\u81EA\u6BBA\u5FD7\u9858\u3060",
  "id" : 122649168392101888,
  "created_at" : "2011-10-08 12:26:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122642551411982336",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 122642551411982336,
  "created_at" : "2011-10-08 12:00:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/IXH4lIKd",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/78?prefill=maucha_",
      "display_url" : "gohantabeyo.com\/nani\/78?prefil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "122627934543548418",
  "text" : "maucha_\u304C\u3001\u79C1\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u7A4D\u5206\u3084\u308A\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u7A4D\u5206\u3084\u308A\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/IXH4lIKd",
  "id" : 122627934543548418,
  "created_at" : "2011-10-08 11:02:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122608632356540416",
  "text" : "\u982D\u60AA\u3044\u51FA\u4F1A\u3044\u53A8\u3060\u306A",
  "id" : 122608632356540416,
  "created_at" : "2011-10-08 09:45:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122584071959359488",
  "text" : "\u975E\u8CA0\u6574\u6570\u3063\u3066\u8A00\u8449\u306E\u304C\u6B63\u78BA\u3067\u306F\u3042\u308B\u3088\u306A\u30FC\u3002",
  "id" : 122584071959359488,
  "created_at" : "2011-10-08 08:08:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "indices" : [ 3, 9 ],
      "id_str" : "184844182",
      "id" : 184844182
    }, {
      "name" : "nartakio",
      "screen_name" : "nartakio",
      "indices" : [ 11, 20 ],
      "id_str" : "612419223",
      "id" : 612419223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122583940153360385",
  "text" : "RT @0_uda: @nartakio \u306F\u3044\u3002\u4E2D\u5B66\u9AD8\u6821\u3067\u306F\u975E\u8CA0\u6574\u6570\u3067\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u306D\u3002\u3069\u3046\u305B\u7B97\u6570\u306E\u6BB5\u968E\u3067\u306F\u300C\u6570\u300D\u3068\u3057\u304B\u547C\u3093\u3067\u306A\u3044\u306E\u3060\u304B\u3089\uFF08\u3055\u3063\u304D\u300C\u6570\u5B57\u300D\u3067\u3044\u3044\u3093\u3058\u3083\u306A\u3044\uFF1F\u3068\u8A00\u3063\u305F\u306E\u306F\u3053\u3046\u3044\u3046\u7406\u7531\u3082\u3042\u308A\u307E\u3059\uFF09\u3002\u305D\u308C\u306B\u3001\u77E5\u3063\u3066\u308B\u4EBA\u306F\u5B9A\u7FA9\u3057\u305F\u4E0A\u3067\u81EA\u7136\u6570\u3063\u3066\u547C\u3079\u3070\u3044\u3044\u3093\u3067 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nartakio",
        "screen_name" : "nartakio",
        "indices" : [ 0, 9 ],
        "id_str" : "612419223",
        "id" : 612419223
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122583434660020224",
    "text" : "@nartakio \u306F\u3044\u3002\u4E2D\u5B66\u9AD8\u6821\u3067\u306F\u975E\u8CA0\u6574\u6570\u3067\u3044\u3044\u3093\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u306D\u3002\u3069\u3046\u305B\u7B97\u6570\u306E\u6BB5\u968E\u3067\u306F\u300C\u6570\u300D\u3068\u3057\u304B\u547C\u3093\u3067\u306A\u3044\u306E\u3060\u304B\u3089\uFF08\u3055\u3063\u304D\u300C\u6570\u5B57\u300D\u3067\u3044\u3044\u3093\u3058\u3083\u306A\u3044\uFF1F\u3068\u8A00\u3063\u305F\u306E\u306F\u3053\u3046\u3044\u3046\u7406\u7531\u3082\u3042\u308A\u307E\u3059\uFF09\u3002\u305D\u308C\u306B\u3001\u77E5\u3063\u3066\u308B\u4EBA\u306F\u5B9A\u7FA9\u3057\u305F\u4E0A\u3067\u81EA\u7136\u6570\u3063\u3066\u547C\u3079\u3070\u3044\u3044\u3093\u3067\u3059\u3088\u3002 (\u30FB\u03B5\u30FB",
    "id" : 122583434660020224,
    "created_at" : "2011-10-08 08:05:42 +0000",
    "user" : {
      "name" : "\u30AB\u30D5\u30A7\u74064-220",
      "screen_name" : "0_uda",
      "protected" : false,
      "id_str" : "184844182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547956554922614784\/ccU36n2B_normal.png",
      "id" : 184844182,
      "verified" : false
    }
  },
  "id" : 122583940153360385,
  "created_at" : "2011-10-08 08:07:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 3, 10 ],
      "id_str" : "443191476",
      "id" : 443191476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122574072650530816",
  "text" : "RT @ac_key: \u516C\u7406\u306F\u4E16\u754C\u306E\u59CB\u307E\u308A\u3001\u5B9A\u7406\u306F\u4E16\u754C\u306B\u751F\u307E\u308C\u305F\u4F55\u304B\u3060\u3068\u601D\u3063\u3066\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122573368703721475",
    "text" : "\u516C\u7406\u306F\u4E16\u754C\u306E\u59CB\u307E\u308A\u3001\u5B9A\u7406\u306F\u4E16\u754C\u306B\u751F\u307E\u308C\u305F\u4F55\u304B\u3060\u3068\u601D\u3063\u3066\u308B\u3002",
    "id" : 122573368703721475,
    "created_at" : "2011-10-08 07:25:43 +0000",
    "user" : {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "protected" : false,
      "id_str" : "106036912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600553053863817216\/2TsFpIn8_normal.png",
      "id" : 106036912,
      "verified" : false
    }
  },
  "id" : 122574072650530816,
  "created_at" : "2011-10-08 07:28:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122570695292092416",
  "text" : "\u3069\u3070\u306B\u3083\u3093\u3055\u3093\u79CB\u8449\u306B\u3044\u308B\u306E\u304B\u3088\uFF57\uFF57",
  "id" : 122570695292092416,
  "created_at" : "2011-10-08 07:15:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u713C\u304D\u305F\u30C6\u30E9\u30CD\u30B7\u30A2",
      "screen_name" : "Teranesia",
      "indices" : [ 3, 13 ],
      "id_str" : "86714487",
      "id" : 86714487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122550139511517184",
  "text" : "RT @Teranesia: \u5C0F\u5B66\u6821\u306E\u5352\u696D\u6587\u96C6\u3067\u5C06\u6765\u306E\u5922\u6B04\u306B\u300C\u4FFA\u305D\u3063\u304F\u308A\u306E\u30A2\u30E9\u30D6\u306E\u77F3\u6CB9\u738B\u304C\u6765\u65E5\u3057\u305F\u6642\u306B\u5165\u308C\u66FF\u308F\u308B\u4E8B\u300D\u3063\u3066\u66F8\u3044\u3066\u3044\u305F\uFF2D\u541B\u3068\u753A\u3067\u5076\u7136\u518D\u4F1A\u3057\u305F\u3093\u3060\u3051\u3069\u3001\u808C\u304C\u6D45\u9ED2\u304F\u306A\u3063\u3066\u308B\u3057\u3001\u30BF\u30FC\u30D0\u30F3\u5DFB\u3044\u3066\u308B\u3057\u3001\u7247\u8A00\u3067\u5FC5\u6B7B\u306B\u300C\u30A4\u30E9\u30AF\u30CB\u5E30\u30EB\u30CB\u30CF\u30C9\u30A6\u30B9\u30EC\u30D0\u30A4\u30A4\u30C7\u30B9\u30AB\uFF01\u300D\u3063\u3066\u8A00\u3063\u3066\u3066\u76F8 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122209699482443776",
    "text" : "\u5C0F\u5B66\u6821\u306E\u5352\u696D\u6587\u96C6\u3067\u5C06\u6765\u306E\u5922\u6B04\u306B\u300C\u4FFA\u305D\u3063\u304F\u308A\u306E\u30A2\u30E9\u30D6\u306E\u77F3\u6CB9\u738B\u304C\u6765\u65E5\u3057\u305F\u6642\u306B\u5165\u308C\u66FF\u308F\u308B\u4E8B\u300D\u3063\u3066\u66F8\u3044\u3066\u3044\u305F\uFF2D\u541B\u3068\u753A\u3067\u5076\u7136\u518D\u4F1A\u3057\u305F\u3093\u3060\u3051\u3069\u3001\u808C\u304C\u6D45\u9ED2\u304F\u306A\u3063\u3066\u308B\u3057\u3001\u30BF\u30FC\u30D0\u30F3\u5DFB\u3044\u3066\u308B\u3057\u3001\u7247\u8A00\u3067\u5FC5\u6B7B\u306B\u300C\u30A4\u30E9\u30AF\u30CB\u5E30\u30EB\u30CB\u30CF\u30C9\u30A6\u30B9\u30EC\u30D0\u30A4\u30A4\u30C7\u30B9\u30AB\uFF01\u300D\u3063\u3066\u8A00\u3063\u3066\u3066\u76F8\u5909\u308F\u3089\u305A\u3072\u3087\u3046\u304D\u3093\u306A\u5974\u3060\u306A\u30FC\u3063\u3066\u601D\u3063\u305F",
    "id" : 122209699482443776,
    "created_at" : "2011-10-07 07:20:37 +0000",
    "user" : {
      "name" : "\u713C\u304D\u305F\u30C6\u30E9\u30CD\u30B7\u30A2",
      "screen_name" : "Teranesia",
      "protected" : false,
      "id_str" : "86714487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1055277909\/_____ksk004435_normal.jpg",
      "id" : 86714487,
      "verified" : false
    }
  },
  "id" : 122550139511517184,
  "created_at" : "2011-10-08 05:53:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 0, 16 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122545692232261632",
  "geo" : { },
  "id_str" : "122545945132007424",
  "in_reply_to_user_id" : 230918258,
  "text" : "@takasan_san_san \u3053\u3063\u3061\u306F\uFF12\uFF10\u5E74\u8FD1\u304F\u305D\u306E\u30CD\u30BF\u3092\u7E70\u308A\u8FD4\u3055\u308C\u3066\u308B\u304B\u3089\u6163\u308C\u3061\u3083\u3063\u3066\u308B\u3051\u3069\u306D\uFF57",
  "id" : 122545945132007424,
  "in_reply_to_status_id" : 122545692232261632,
  "created_at" : "2011-10-08 05:36:44 +0000",
  "in_reply_to_screen_name" : "takasan_san_san",
  "in_reply_to_user_id_str" : "230918258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122526930334531584",
  "text" : "\u7092\u98EF\u3067\u3082\u4F5C\u308B\u304B\u30FC",
  "id" : 122526930334531584,
  "created_at" : "2011-10-08 04:21:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 3, 13 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122526414380609536",
  "text" : "RT @blackVELU: '\u03C9')\uFF8E\uFF9F\uFF77\uFF9E\uFF6D\uFF97\uFF8A\uFF9F\uFF8E\uFF9F\uFF6F\uFF8E\uFF9F\uFF70\uFF91\uFF98\uFF93\uFF70\uFF99\uFF7B\uFF6F\uFF7B\uFF70\uFF6F\uFF7C\uFF6E\uFF98\uFF7C\uFF6E\uFF70\uFF6F\uFF8B\uFF9F\uFF6E\uFF9D\uFF87\uFF97\uFF93\uFF9D\uFF87\uFF97(^-^)\uFF8D\uFF9E\uFF6F\uFF97\uFF76\uFF9E\uFF97\uFF9C\uFF97\uFF78\uFF89\uFF70\uFF98\uFF6F\uFF98\uFF6D\uFF74\uFF74\uFF71\uFF6F\uFF84\uFF9E\uFF6F\uFF7A\uFF6B\uFF67\uFF7E\uFF67",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122526350488780800",
    "text" : "'\u03C9')\uFF8E\uFF9F\uFF77\uFF9E\uFF6D\uFF97\uFF8A\uFF9F\uFF8E\uFF9F\uFF6F\uFF8E\uFF9F\uFF70\uFF91\uFF98\uFF93\uFF70\uFF99\uFF7B\uFF6F\uFF7B\uFF70\uFF6F\uFF7C\uFF6E\uFF98\uFF7C\uFF6E\uFF70\uFF6F\uFF8B\uFF9F\uFF6E\uFF9D\uFF87\uFF97\uFF93\uFF9D\uFF87\uFF97(^-^)\uFF8D\uFF9E\uFF6F\uFF97\uFF76\uFF9E\uFF97\uFF9C\uFF97\uFF78\uFF89\uFF70\uFF98\uFF6F\uFF98\uFF6D\uFF74\uFF74\uFF71\uFF6F\uFF84\uFF9E\uFF6F\uFF7A\uFF6B\uFF67\uFF7E\uFF67",
    "id" : 122526350488780800,
    "created_at" : "2011-10-08 04:18:53 +0000",
    "user" : {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "protected" : false,
      "id_str" : "102325414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450656382325248000\/cnubEZOd_normal.jpeg",
      "id" : 102325414,
      "verified" : false
    }
  },
  "id" : 122526414380609536,
  "created_at" : "2011-10-08 04:19:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122524912807190528",
  "text" : "\u3010\u3086\u308B\u307C\u3011\u9AD8\u6821\u7269\u7406\u306E\u5165\u9580\u7684\u306A\u53C2\u8003\u66F8\u3001\u554F\u984C\u96C6\u3001\u4E2D\u5B66\u301C\u9AD8\u6821\u5316\u5B66\u306E\u5165\u9580\u7684\u306A\u53C2\u8003\u66F8\u3001\u554F\u984C\u96C6",
  "id" : 122524912807190528,
  "created_at" : "2011-10-08 04:13:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122523180396064768",
  "text" : "\u7A7A\u3092\u98DB\u3073\u3001\u6642\u9593\u304C\u6B62\u307E\u308B\u5922\u3092\u898B\u305F\u3002",
  "id" : 122523180396064768,
  "created_at" : "2011-10-08 04:06:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 0, 16 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122521168694620160",
  "geo" : { },
  "id_str" : "122521274013589504",
  "in_reply_to_user_id" : 230918258,
  "text" : "@takasan_san_san \u30C9\u30AD\u30C3\u3068\u3057\u305F",
  "id" : 122521274013589504,
  "in_reply_to_status_id" : 122521168694620160,
  "created_at" : "2011-10-08 03:58:42 +0000",
  "in_reply_to_screen_name" : "takasan_san_san",
  "in_reply_to_user_id_str" : "230918258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122339131740274691",
  "text" : "\u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 122339131740274691,
  "created_at" : "2011-10-07 15:54:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122333726020612097",
  "geo" : { },
  "id_str" : "122333913141084160",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u70AC\u71F5\u306F\uFF1F",
  "id" : 122333913141084160,
  "in_reply_to_status_id" : 122333726020612097,
  "created_at" : "2011-10-07 15:34:12 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "indices" : [ 3, 12 ],
      "id_str" : "126927392",
      "id" : 126927392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122333738712571904",
  "text" : "RT @hanaoka_: \u30E1\u30ED\u30B9\u306F\u6FC0\u6012\u3057\u305F\u3002\u5FC5\u305A\u3001\u304B\u306E\u90AA\u667A\u66B4\u8650\u306E\u6559\u6388\u3092\u9664\u304B\u306A\u3051\u308C\u3070\u306A\u3089\u306C\u3068\u6C7A\u610F\u3057\u305F\u3002\u30E1\u30ED\u30B9\u306B\u306F\u30C9\u30A4\u30C4\u8A9E\u304C\u308F\u304B\u3089\u306C\u3002\u82F1\u8A9E\u3082\u308F\u304B\u3089\u306C\u3002\u5FC5\u4FEE\u8B1B\u7FA9\u304C\u3069\u308C\u304B\u3059\u3089\u5206\u304B\u3089\u306C\u3002\u30E1\u30ED\u30B9\u306F\uFF11\u56DE\u751F\u3067\u3042\u308B\u3002\u5927\u5B66\u306B\u884C\u304B\u305A\u3001\u3072\u305F\u3059\u3089\u5F15\u304D\u3053\u3082\u308A\u30B2\u30FC\u30E0\u3070\u304B\u308A\u3057\u3066\u66AE\u3089\u3057\u3066\u6765\u305F\u3002\u3051\u308C\u3069\u3082\u7559 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86364495529775104",
    "text" : "\u30E1\u30ED\u30B9\u306F\u6FC0\u6012\u3057\u305F\u3002\u5FC5\u305A\u3001\u304B\u306E\u90AA\u667A\u66B4\u8650\u306E\u6559\u6388\u3092\u9664\u304B\u306A\u3051\u308C\u3070\u306A\u3089\u306C\u3068\u6C7A\u610F\u3057\u305F\u3002\u30E1\u30ED\u30B9\u306B\u306F\u30C9\u30A4\u30C4\u8A9E\u304C\u308F\u304B\u3089\u306C\u3002\u82F1\u8A9E\u3082\u308F\u304B\u3089\u306C\u3002\u5FC5\u4FEE\u8B1B\u7FA9\u304C\u3069\u308C\u304B\u3059\u3089\u5206\u304B\u3089\u306C\u3002\u30E1\u30ED\u30B9\u306F\uFF11\u56DE\u751F\u3067\u3042\u308B\u3002\u5927\u5B66\u306B\u884C\u304B\u305A\u3001\u3072\u305F\u3059\u3089\u5F15\u304D\u3053\u3082\u308A\u30B2\u30FC\u30E0\u3070\u304B\u308A\u3057\u3066\u66AE\u3089\u3057\u3066\u6765\u305F\u3002\u3051\u308C\u3069\u3082\u7559\u5E74\u306B\u5BFE\u3057\u3066\u306F\u3001\u4EBA\u4E00\u500D\u306B\u654F\u611F\u3067\u3042\u3063\u305F\u3002",
    "id" : 86364495529775104,
    "created_at" : "2011-06-30 09:24:34 +0000",
    "user" : {
      "name" : "\u82B1\u5CA1\u4FEE\u4E00\u90CE \/ \u260518.78",
      "screen_name" : "hanaoka_",
      "protected" : false,
      "id_str" : "126927392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540399732707688448\/Iqz4rTVp_normal.jpeg",
      "id" : 126927392,
      "verified" : false
    }
  },
  "id" : 122333738712571904,
  "created_at" : "2011-10-07 15:33:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/wBG4dG9m",
      "expanded_url" : "http:\/\/shindanmaker.com\/159199",
      "display_url" : "shindanmaker.com\/159199"
    } ]
  },
  "geo" : { },
  "id_str" : "122329563287130112",
  "text" : "\u58F0\u512A\u306E\u300E\u5357\u689D\u611B\u4E43\u300F\u304C\u71B1\u611B\u767A\u899A\uFF01\u304A\u76F8\u624B\u306Fend313124\uFF01\uFF01 http:\/\/t.co\/wBG4dG9m  \u3053\u3053\u308D\u3061\u3083\u3093\u2026\u2026",
  "id" : 122329563287130112,
  "created_at" : "2011-10-07 15:16:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122329117260656640",
  "text" : "\u6570\u5B66\u7528\u8A9E\u306B\u53CD\u5FDC\u3059\u308Bbot\u3068\u304B\u30BB\u30F3\u30B9\u3042\u308B\u306A\u30FC",
  "id" : 122329117260656640,
  "created_at" : "2011-10-07 15:15:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FixpointDaemon",
      "screen_name" : "ha_uda",
      "indices" : [ 3, 10 ],
      "id_str" : "244493681",
      "id" : 244493681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122328999442649088",
  "text" : "RT @ha_uda: \u300C\u3053\u308C\u306F RT \u3057\u306A\u3044\u3067\u6B32\u3057\u3044\u300D\u300C\u3053\u3046\u3044\u3046\u7528\u8A9E\u3092\u6355\u6349\u3057\u3066\u6B32\u3057\u3044\u300D\u306A\u3069\u306E\u610F\u898B\u52DF\u96C6\u4E2D\u3067\u3059\u3002\u3061\u306A\u307F\u306B\u3001\u3042\u3068\u3044\u304F\u3064\u304B\u306E\u8FFD\u52A0\u6A5F\u80FD\u3092\u5B9F\u88C5\u3057\u305F\u3089\u672C\u756A\u3078\u79FB\u884C\u4E88\u5B9A\u3067\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122326383522353152",
    "text" : "\u300C\u3053\u308C\u306F RT \u3057\u306A\u3044\u3067\u6B32\u3057\u3044\u300D\u300C\u3053\u3046\u3044\u3046\u7528\u8A9E\u3092\u6355\u6349\u3057\u3066\u6B32\u3057\u3044\u300D\u306A\u3069\u306E\u610F\u898B\u52DF\u96C6\u4E2D\u3067\u3059\u3002\u3061\u306A\u307F\u306B\u3001\u3042\u3068\u3044\u304F\u3064\u304B\u306E\u8FFD\u52A0\u6A5F\u80FD\u3092\u5B9F\u88C5\u3057\u305F\u3089\u672C\u756A\u3078\u79FB\u884C\u4E88\u5B9A\u3067\u3059\u3002",
    "id" : 122326383522353152,
    "created_at" : "2011-10-07 15:04:17 +0000",
    "user" : {
      "name" : "FixpointDaemon",
      "screen_name" : "ha_uda",
      "protected" : false,
      "id_str" : "244493681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1228964991\/ha_normal.png",
      "id" : 244493681,
      "verified" : false
    }
  },
  "id" : 122328999442649088,
  "created_at" : "2011-10-07 15:14:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3084\u3059\u3060\u30FC\u30FC\u3093",
      "screen_name" : "yasudaaaan",
      "indices" : [ 3, 14 ],
      "id_str" : "170971483",
      "id" : 170971483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122261455021146112",
  "text" : "RT @yasudaaaan: \u3046\u3061\uFF62\u4ECA\u65E5\u3054\u98EF\u4F55\u3067\u3059\u304B\uFF1F\uFF63\u6BCD\uFF62\u30B3\u30B7\u30D2\u30AB\u30EA\u3067\u3059\uDBB8\uDF30\uFF63 \u54C1\u7A2E\u3058\u3083\u306A\u304F\u3066\u30E1\u30CB\u30E5\u30FC\u2026\u5225\u306B\u3044\u3044\u3051\u3069\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122259111445397504",
    "text" : "\u3046\u3061\uFF62\u4ECA\u65E5\u3054\u98EF\u4F55\u3067\u3059\u304B\uFF1F\uFF63\u6BCD\uFF62\u30B3\u30B7\u30D2\u30AB\u30EA\u3067\u3059\uDBB8\uDF30\uFF63 \u54C1\u7A2E\u3058\u3083\u306A\u304F\u3066\u30E1\u30CB\u30E5\u30FC\u2026\u5225\u306B\u3044\u3044\u3051\u3069\u2026",
    "id" : 122259111445397504,
    "created_at" : "2011-10-07 10:36:58 +0000",
    "user" : {
      "name" : "\u3084\u3059\u3060\u30FC\u30FC\u3093",
      "screen_name" : "yasudaaaan",
      "protected" : false,
      "id_str" : "170971483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1190372012\/image2581_normal.jpg",
      "id" : 170971483,
      "verified" : false
    }
  },
  "id" : 122261455021146112,
  "created_at" : "2011-10-07 10:46:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "indices" : [ 3, 12 ],
      "id_str" : "150662260",
      "id" : 150662260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122219246448148480",
  "text" : "RT @isaribiz: \u3053\u306E\u6642\u671F\u306B\u868A\u306B\u304B\u307E\u308C\u305F(\u00B4\u30FB\u03C9\u30FB\uFF40)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122218047648968704",
    "text" : "\u3053\u306E\u6642\u671F\u306B\u868A\u306B\u304B\u307E\u308C\u305F(\u00B4\u30FB\u03C9\u30FB\uFF40)",
    "id" : 122218047648968704,
    "created_at" : "2011-10-07 07:53:47 +0000",
    "user" : {
      "name" : "\u3044\u3055\u308A\u3093",
      "screen_name" : "isaribiz",
      "protected" : true,
      "id_str" : "150662260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586179377114685441\/2LPKH2Xn_normal.jpg",
      "id" : 150662260,
      "verified" : false
    }
  },
  "id" : 122219246448148480,
  "created_at" : "2011-10-07 07:58:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122180527708061696",
  "geo" : { },
  "id_str" : "122180931820847104",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u30D2\u30F3\u30C8\uFF1A\u52D8\u9055\u3044",
  "id" : 122180931820847104,
  "in_reply_to_status_id" : 122180527708061696,
  "created_at" : "2011-10-07 05:26:18 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u3093",
      "screen_name" : "nisehorn",
      "indices" : [ 0, 9 ],
      "id_str" : "96348838",
      "id" : 96348838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122179938378973184",
  "geo" : { },
  "id_str" : "122180132311023616",
  "in_reply_to_user_id" : 96348838,
  "text" : "@nisehorn \u3042\u308A\u304C\u3068",
  "id" : 122180132311023616,
  "in_reply_to_status_id" : 122179938378973184,
  "created_at" : "2011-10-07 05:23:08 +0000",
  "in_reply_to_screen_name" : "nisehorn",
  "in_reply_to_user_id_str" : "96348838",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122179334814449665",
  "text" : "\u5FA9\u6D3B\uFF67\uFF01",
  "id" : 122179334814449665,
  "created_at" : "2011-10-07 05:19:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122119818353721344",
  "text" : "@koketomi \u304A\u304B\u3048\u308A",
  "id" : 122119818353721344,
  "created_at" : "2011-10-07 01:23:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3048\u308B\u3057\u30FC",
      "screen_name" : "elsea823",
      "indices" : [ 3, 12 ],
      "id_str" : "159890168",
      "id" : 159890168
    }, {
      "name" : "\u3069\u3070\u306B\u3083\u3093",
      "screen_name" : "dovanyahn",
      "indices" : [ 14, 24 ],
      "id_str" : "177404480",
      "id" : 177404480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122110680542351362",
  "text" : "RT @elsea823: @dovanyahn \u307E\u3060\u6765\u9031\u304C\u3042\u308B\u2026\u2026\u305D\u3046\u3060\u6765\u9031\u304B\u3089\u51FA\u308C\u3070\u3044\u3044\u2026\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/peraperaprv\/Home\" rel=\"nofollow\"\u003EP3:PeraPeraPrv\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3069\u3070\u306B\u3083\u3093",
        "screen_name" : "dovanyahn",
        "indices" : [ 0, 10 ],
        "id_str" : "177404480",
        "id" : 177404480
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "122108931643420672",
    "geo" : { },
    "id_str" : "122109264788586496",
    "in_reply_to_user_id" : 177404480,
    "text" : "@dovanyahn \u307E\u3060\u6765\u9031\u304C\u3042\u308B\u2026\u2026\u305D\u3046\u3060\u6765\u9031\u304B\u3089\u51FA\u308C\u3070\u3044\u3044\u2026\u2026",
    "id" : 122109264788586496,
    "in_reply_to_status_id" : 122108931643420672,
    "created_at" : "2011-10-07 00:41:32 +0000",
    "in_reply_to_screen_name" : "dovanyahn",
    "in_reply_to_user_id_str" : "177404480",
    "user" : {
      "name" : "\u3048\u308B\u3057\u30FC",
      "screen_name" : "elsea823",
      "protected" : false,
      "id_str" : "159890168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1458335504\/20110724twitter_icon_normal.jpg",
      "id" : 159890168,
      "verified" : false
    }
  },
  "id" : 122110680542351362,
  "created_at" : "2011-10-07 00:47:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122107333781368832",
  "text" : "\u30CB\u30E5\u30FC\u30C8\u30EA\u30CE\u306E\u65E9\u3055\u3067\u30D5\u30A9\u30ED\u30FC\u5E30\u3063\u3066\u304D\u3066\u3073\u3063\u304F\u308A",
  "id" : 122107333781368832,
  "created_at" : "2011-10-07 00:33:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4E0D\u5B8C\u5168\u306B\u5618\u3092\u3064\u3053\u3046",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122101499265425408",
  "text" : "\u3053\u3063\u3061\u306E\u304C\u3044\u3044\u304B\u3082 #\u4E0D\u5B8C\u5168\u306B\u5618\u3092\u3064\u3053\u3046",
  "id" : 122101499265425408,
  "created_at" : "2011-10-07 00:10:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u5B8C\u5168\u306B\u5618\u3092\u3064\u3053\u3046",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122101162353766401",
  "text" : "\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u306B\u3057\u305F\u304C\u3063\u3066\u5618\u4ED8\u304F\u3068\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u306F\u771F\u3001\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u306B\u5F93\u308F\u305A\u306B\u771F\u5B9F\u3092\u8FF0\u3079\u308B\u3068\u3001\u30CF\u30C3\u30B7\u30E5\u30BF\u30B0\u4EE5\u5916\u304C\u771F\n #\u5B8C\u5168\u306B\u5618\u3092\u3064\u3053\u3046",
  "id" : 122101162353766401,
  "created_at" : "2011-10-07 00:09:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122099906432335873",
  "geo" : { },
  "id_str" : "122100106790055936",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 122100106790055936,
  "in_reply_to_status_id" : 122099906432335873,
  "created_at" : "2011-10-07 00:05:08 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan",
      "screen_name" : "kanoto_hitsuji",
      "indices" : [ 0, 15 ],
      "id_str" : "112678195",
      "id" : 112678195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122098317835505664",
  "geo" : { },
  "id_str" : "122098889951154176",
  "in_reply_to_user_id" : 112678195,
  "text" : "@kanoto_hitsuji \u304A\u306F\u3088\u3046",
  "id" : 122098889951154176,
  "in_reply_to_status_id" : 122098317835505664,
  "created_at" : "2011-10-07 00:00:18 +0000",
  "in_reply_to_screen_name" : "kanoto_hitsuji",
  "in_reply_to_user_id_str" : "112678195",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fathar_POGE",
      "screen_name" : "father_POP",
      "indices" : [ 3, 14 ],
      "id_str" : "12359362",
      "id" : 12359362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122098786771288064",
  "text" : "RT @father_POP: \u30C8\u30C3\u30DD\u306B\u30DD\u30C3\u30AD\u30FC\u7A81\u3063\u8FBC\u3093\u3060\u3089\u3001\u30C8\u30C3\u30DD\u306E\u30D7\u30EC\u30C3\u30C4\u30A7\u30EB\u3067\u30DD\u30C3\u30AD\u30FC\u306E\u30C1\u30E7\u30B3\u304C\u3001\u30DD\u30C3\u30AD\u30FC\u306E\u30D7\u30EC\u30C3\u30C4\u30A7\u30EB\u3067\u30C8\u30C3\u30DD\u306E\u30C1\u30E7\u30B3\u304C\u305D\u308C\u305E\u308C\u6392\u9664\u3055\u308C\u308B\u305F\u3081\u592A\u3044\u30D7\u30EA\u30C3\u30C4\u304C\u3067\u304D\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122098323070005249",
    "text" : "\u30C8\u30C3\u30DD\u306B\u30DD\u30C3\u30AD\u30FC\u7A81\u3063\u8FBC\u3093\u3060\u3089\u3001\u30C8\u30C3\u30DD\u306E\u30D7\u30EC\u30C3\u30C4\u30A7\u30EB\u3067\u30DD\u30C3\u30AD\u30FC\u306E\u30C1\u30E7\u30B3\u304C\u3001\u30DD\u30C3\u30AD\u30FC\u306E\u30D7\u30EC\u30C3\u30C4\u30A7\u30EB\u3067\u30C8\u30C3\u30DD\u306E\u30C1\u30E7\u30B3\u304C\u305D\u308C\u305E\u308C\u6392\u9664\u3055\u308C\u308B\u305F\u3081\u592A\u3044\u30D7\u30EA\u30C3\u30C4\u304C\u3067\u304D\u308B\u3002",
    "id" : 122098323070005249,
    "created_at" : "2011-10-06 23:58:03 +0000",
    "user" : {
      "name" : "fathar_POGE",
      "screen_name" : "father_POP",
      "protected" : false,
      "id_str" : "12359362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604838188289359872\/97PHG5yq_normal.jpg",
      "id" : 12359362,
      "verified" : false
    }
  },
  "id" : 122098786771288064,
  "created_at" : "2011-10-06 23:59:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122096257547247617",
  "text" : "\u3042\u3001\uFF19\u6642\u306B\u3082\u9593\u306B\u5408\u308F\u306A\u3044",
  "id" : 122096257547247617,
  "created_at" : "2011-10-06 23:49:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122094163293507584",
  "text" : "\u4E00\u9650\u306F\uFF19\u6642\u304B\u3089",
  "id" : 122094163293507584,
  "created_at" : "2011-10-06 23:41:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122094088861384704",
  "text" : "\u3042\u3046\u3001\u4E00\u9650\u9593\u306B\u5408\u308F\u306A\u3044",
  "id" : 122094088861384704,
  "created_at" : "2011-10-06 23:41:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 3, 10 ],
      "id_str" : "443191476",
      "id" : 443191476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121972857357082625",
  "text" : "RT @ac_key: \u9CE9\u30CE\u5DE3\u539F\u7406\u306E\u5909\u308F\u308A\u306B\u732B\u934B\u539F\u7406\u3063\u3066\u8A00\u3048\u3070\u3044\u3044\u3058\u3083\u306A\u3044\u3063\u3066\u601D\u3063\u305F\u3051\u3069\u3001\u732B\u934B\u306F\u934B\u4E00\u3064\u306B\u3064\u304D\u732B\u304C\u8907\u6570\u5339\u5165\u308A\u3046\u308B\u306E\u3067\u4F7F\u3044\u7269\u306B\u306A\u3089\u306A\u304B\u3063\u305F\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121970117121814528",
    "text" : "\u9CE9\u30CE\u5DE3\u539F\u7406\u306E\u5909\u308F\u308A\u306B\u732B\u934B\u539F\u7406\u3063\u3066\u8A00\u3048\u3070\u3044\u3044\u3058\u3083\u306A\u3044\u3063\u3066\u601D\u3063\u305F\u3051\u3069\u3001\u732B\u934B\u306F\u934B\u4E00\u3064\u306B\u3064\u304D\u732B\u304C\u8907\u6570\u5339\u5165\u308A\u3046\u308B\u306E\u3067\u4F7F\u3044\u7269\u306B\u306A\u3089\u306A\u304B\u3063\u305F\u3002",
    "id" : 121970117121814528,
    "created_at" : "2011-10-06 15:28:36 +0000",
    "user" : {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "protected" : false,
      "id_str" : "106036912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600553053863817216\/2TsFpIn8_normal.png",
      "id" : 106036912,
      "verified" : false
    }
  },
  "id" : 121972857357082625,
  "created_at" : "2011-10-06 15:39:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121970144040849409",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u4ED6\u4EBA\u306E\u4E0D\u5E78\u306F\u871C\u306E\u5473\u3060\u306A",
  "id" : 121970144040849409,
  "created_at" : "2011-10-06 15:28:43 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "indices" : [ 3, 11 ],
      "id_str" : "5965172",
      "id" : 5965172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121969708722421760",
  "text" : "RT @mr_konn: \u6B86\u3093\u3069\u81F3\u308B\u3068\u3053\u308D\u306D\u3053",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121969604728860674",
    "text" : "\u6B86\u3093\u3069\u81F3\u308B\u3068\u3053\u308D\u306D\u3053",
    "id" : 121969604728860674,
    "created_at" : "2011-10-06 15:26:34 +0000",
    "user" : {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "protected" : false,
      "id_str" : "5965172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566615944194060288\/nh8McKGS_normal.jpeg",
      "id" : 5965172,
      "verified" : false
    }
  },
  "id" : 121969708722421760,
  "created_at" : "2011-10-06 15:26:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u305B\u307B\u308B\u308B\u308B\u308B\u308B\u3093",
      "screen_name" : "nisehorrrrrn",
      "indices" : [ 0, 13 ],
      "id_str" : "295206903",
      "id" : 295206903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121969088934322176",
  "geo" : { },
  "id_str" : "121969505835560963",
  "in_reply_to_user_id" : 295206903,
  "text" : "@nisehorrrrrn \u4F55\u304B\u8A00\u3063\u305F\u304B\uFF1F",
  "id" : 121969505835560963,
  "in_reply_to_status_id" : 121969088934322176,
  "created_at" : "2011-10-06 15:26:10 +0000",
  "in_reply_to_screen_name" : "nisehorrrrrn",
  "in_reply_to_user_id_str" : "295206903",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u5370\u8C61\u3092\u8A73\u3057\u304F\u6559\u3048\u3066\u304F\u308C\u308B",
      "indices" : [ 0, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121968886915661824",
  "text" : "#\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u81EA\u5206\u306E\u5370\u8C61\u3092\u8A73\u3057\u304F\u6559\u3048\u3066\u304F\u308C\u308B",
  "id" : 121968886915661824,
  "created_at" : "2011-10-06 15:23:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121917742424141824",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 121917742424141824,
  "created_at" : "2011-10-06 12:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iris pe\u00F1a",
      "screen_name" : "iris1211",
      "indices" : [ 0, 9 ],
      "id_str" : "601994539",
      "id" : 601994539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121850324720951296",
  "in_reply_to_user_id" : 199550192,
  "text" : "@iris1211 \u96C6\u307E\u308A\u304B\u3051\u3066\u308B\u3088\u30FC",
  "id" : 121850324720951296,
  "created_at" : "2011-10-06 07:32:35 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121822862259658752",
  "text" : "\u30A2\u30A6\u30A7\u30FC\u611F\u306B\u582A\u3048\u308B\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0",
  "id" : 121822862259658752,
  "created_at" : "2011-10-06 05:43:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121822671334948865",
  "text" : "\u51FD\u6570\u8AD6\u306F\u8A18\u61B6\u306E\u5965\u5E95\u3060\u304C\u5927\u4E08\u592B\u304B\u306A",
  "id" : 121822671334948865,
  "created_at" : "2011-10-06 05:42:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121822381802127360",
  "text" : "\u6587\u5B66\u90E8\u3067\u8CFC\u8AAD\u2192\u6CD5\u7D4C\u3067\u91D1\u878D\u2192\u7406\u5B66\u90E8\u3067\u6570\u5B66\u6F14\u7FD2\u2190\uFF72\uFF8F\uFF7A\uFF7A\uFF01",
  "id" : 121822381802127360,
  "created_at" : "2011-10-06 05:41:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121749368696078337",
  "text" : "\u3055\u3041\u7740\u66FF\u3048\u3066\u51FA\u304B\u3051\u3088",
  "id" : 121749368696078337,
  "created_at" : "2011-10-06 00:51:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121734068973993984",
  "text" : "\u808C\u5BD2\u3044\u306A\u3001\u3046\u3093",
  "id" : 121734068973993984,
  "created_at" : "2011-10-05 23:50:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121733711774490624",
  "text" : "\u8D77\u304D\u305F\u3051\u3069",
  "id" : 121733711774490624,
  "created_at" : "2011-10-05 23:49:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121627105489457152",
  "text" : "\u3088\u3057\uFF19\u6642\u306B\u8D77\u304D\u305F\u3093\u3058\u3083\uFF12\u9650\u304C\u65E9\u304F\u7D42\u308F\u3089\u306A\u3044\u3068\u3059\u3079\u3066\u56DE\u3089\u306A\u3044\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 121627105489457152,
  "created_at" : "2011-10-05 16:45:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "akiyo",
      "screen_name" : "akiyohmori",
      "indices" : [ 0, 11 ],
      "id_str" : "171457320",
      "id" : 171457320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121623213305368576",
  "geo" : { },
  "id_str" : "121623810666536961",
  "in_reply_to_user_id" : 171457320,
  "text" : "@akiyohmori \u6A5F\u4F1A\u304C\u3042\u3063\u305F\u3089\u805E\u304D\u307E\u3057\u3087\u3046\u3002\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002",
  "id" : 121623810666536961,
  "in_reply_to_status_id" : 121623213305368576,
  "created_at" : "2011-10-05 16:32:30 +0000",
  "in_reply_to_screen_name" : "akiyohmori",
  "in_reply_to_user_id_str" : "171457320",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 0, 16 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121620827681726466",
  "geo" : { },
  "id_str" : "121621401089224704",
  "in_reply_to_user_id" : 230918258,
  "text" : "@takasan_san_san \u8272\u3005\u3044\u3063\u3071\u3044\u3044\u3063\u3071\u3044\u3067\u7533\u3057\u8A33\u306A\u3044orz",
  "id" : 121621401089224704,
  "in_reply_to_status_id" : 121620827681726466,
  "created_at" : "2011-10-05 16:22:56 +0000",
  "in_reply_to_screen_name" : "takasan_san_san",
  "in_reply_to_user_id_str" : "230918258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121619153881804800",
  "geo" : { },
  "id_str" : "121619222110552064",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u3084\u3059\u307F\u306A\u3055\u3044",
  "id" : 121619222110552064,
  "in_reply_to_status_id" : 121619153881804800,
  "created_at" : "2011-10-05 16:14:16 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121619169048403969",
  "text" : "\u3042\u3001\u90E8\u5C4B\u3082\u7DBA\u9E97\u306B\u3057\u306A\u3044\u3068\u53CB\u4EBA\u304C\u6765\u308B\u8A71\u304C\u3042\u3063\u305F\u306A\u3002\u55DA\u547C\u3001\u3084\u308B\u3053\u3068\u3044\u3063\u3071\u3044\u306A\u306E\u306B\u30C4\u30A4\u30C3\u30BF\u30FC\u3068\u304B\u3084\u3063\u3066\u3066\u3069\u3046\u3059\u3093\u306E\uFF57",
  "id" : 121619169048403969,
  "created_at" : "2011-10-05 16:14:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121618887119880193",
  "text" : "\u81EA\u4E3B\u30BC\u30DF\u3067\u8AAD\u3093\u3067\u304F\u308B\u306F\u305A\u306E\u8457\u4F5C\u96C6\u306E\uFF12\u5DFB\u3092\u501F\u308A\u3066\u304D\u3066\u3057\u307E\u3063\u3066\u3044\u305Forz\u9053\u7406\u3067\u8A00\u308F\u308C\u305F\u5185\u5BB9\u3068\u305A\u308C\u305F\u7AE0\u3057\u304B\u306A\u3044\u308F\u3051\u3060\u3002\u660E\u65E5\u3061\u3087\u3063\u3068\u65E9\u8D77\u304D\u3057\u3066\u56F3\u66F8\u9928\u884C\u304F\u30B3\u30FC\u30B9\u304B\u306A\u3002\u3053\u3093\u306A\u6642\u9593\u306A\u306E\u306B\u3002",
  "id" : 121618887119880193,
  "created_at" : "2011-10-05 16:12:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121615051957354496",
  "text" : "\u300C\u6587\u5B66\u90E8\u3067\u4E00\u756A\u6570\u7406\u306B\u5F37\u304F\u306A\u308B\u3002\u300D\u304F\u3089\u3044\u306E\u5999\u306A\u76EE\u6A19\u8A2D\u5B9A\u3067\u3082\u3044\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u3002",
  "id" : 121615051957354496,
  "created_at" : "2011-10-05 15:57:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121614539010736128",
  "text" : "\uFF11\uFF19\u65E5\u306E\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u306E\u89E3\u6790\u306E\u8B1B\u7FA9\u884C\u3063\u3066\u898B\u3088\u3046\u3001\uFF08\u3069\u3046\u305B\u4F55\u3082\u308F\u304B\u3089\u306A\u3044\u3060\u308D\u3046\u3051\u3069\uFF09\u3042\u3068\u3001\u3053\u308C\u3092\u6A5F\u306B\uFF08\uFF1F\uFF09\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u30D5\u30A9\u30ED\u30FC\u3057\u305F\u3002",
  "id" : 121614539010736128,
  "created_at" : "2011-10-05 15:55:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121600306365734912",
  "geo" : { },
  "id_str" : "121604845064028160",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u304B\u3048\u308A\u3042\u308A\u304C\u3068\u3046\u3067\u3057\u305F\u3002",
  "id" : 121604845064028160,
  "in_reply_to_status_id" : 121600306365734912,
  "created_at" : "2011-10-05 15:17:09 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 19, 27 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/rwoz102J",
      "expanded_url" : "http:\/\/bit.ly\/r2JnwE",
      "display_url" : "bit.ly\/r2JnwE"
    } ]
  },
  "geo" : { },
  "id_str" : "121604414967513088",
  "text" : "\u30BB\u30EB\u30D3\u30F3\uFF08\u30E2\u30F3\u30C9\u30EA\uFF09\u3060\u305D\u3046\u3067\u3059 RT @i_horse \u3010\u6025\u52DF\uFF01\uFF01\u3011\u3053\u306E\u4ED5\u639B\u3051\u306E\u3053\u3068\u306A\u3093\u3066\u8A00\u3044\u307E\u3059\u304B\uFF01\uFF1F\nhttp:\/\/t.co\/rwoz102J",
  "id" : 121604414967513088,
  "created_at" : "2011-10-05 15:15:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 17, 25 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/rwoz102J",
      "expanded_url" : "http:\/\/bit.ly\/r2JnwE",
      "display_url" : "bit.ly\/r2JnwE"
    } ]
  },
  "geo" : { },
  "id_str" : "121602373218074624",
  "text" : "\u62E1\u6563\u3002\u6C17\u306B\u306A\u3063\u3066\u7720\u308C\u306A\u3044\u3002 RT @i_horse \u3010\u6025\u52DF\uFF01\uFF01\u3011\u3053\u306E\u4ED5\u639B\u3051\u306E\u3053\u3068\u306A\u3093\u3066\u8A00\u3044\u307E\u3059\u304B\uFF01\uFF1F\nhttp:\/\/t.co\/rwoz102J",
  "id" : 121602373218074624,
  "created_at" : "2011-10-05 15:07:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121601558893969408",
  "text" : "\u4E00\u56DE\u30EB\u30CD\u30AA\u30D5\u7684\u306A\u306E\u306B\u884C\u3063\u3066\u898B\u305F\u3044\u3002\u3042\u3068\u304F\u3063\u3061\u3093\u3071\u3055\u3093\u306E\u89E3\u6790\u3002\u3086\u3002",
  "id" : 121601558893969408,
  "created_at" : "2011-10-05 15:04:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121601164784566272",
  "text" : "\u306A\u3093\u304B\u5B66\u90E8\u306E\u30E9\u30A6\u30F3\u30B8\u3068\u304B\u3067\u30C4\u30A4\u30C3\u30BF\u30FC\u306E\u8A71\u3057\u3066\u308B\u4EBA\u304C\u3044\u308B\u3068\u30C9\u30AE\u30DE\u30AE\u3059\u308B\u3002\u3044\u3084\u3001\u4F55\u4EBA\u304B\u77E5\u308A\u5408\u3044\u304C\u3044\u305D\u3046\u306A\u3001\u3044\u306A\u3055\u305D\u3046\u306A\u3002",
  "id" : 121601164784566272,
  "created_at" : "2011-10-05 15:02:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121600640270077952",
  "text" : "\u55DA\u547C\u65E5\u4ED8\u5909\u3063\u3061\u3083\u3063\u305F",
  "id" : 121600640270077952,
  "created_at" : "2011-10-05 15:00:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121600270231797761",
  "text" : "\u5E30\u5B85\u3045\u3002\u6700\u8FD1\u5FD9\u3057\u3044\u3002\u3044\u3084\u3001\u5FD9\u3057\u304F\u3057\u3066\u308B\u306E\u306F\u81EA\u5206\u3060\u3051\u3069\u3055\u3002",
  "id" : 121600270231797761,
  "created_at" : "2011-10-05 14:58:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121562367782952960",
  "text" : "\u884C\u3063\u3066\u307F\u3088\u30FC\u304B\u306A\u2026",
  "id" : 121562367782952960,
  "created_at" : "2011-10-05 12:28:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4ECA\u65E5\u3082\u30A4\u30AA\u30BF\u3060\u306B\u3083\u30FC",
      "screen_name" : "_iota",
      "indices" : [ 3, 9 ],
      "id_str" : "69003052",
      "id" : 69003052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/e5KxN28J",
      "expanded_url" : "http:\/\/yaraon.blog109.fc2.com\/blog-entry-4390.html",
      "display_url" : "yaraon.blog109.fc2.com\/blog-entry-439\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121558573535858688",
  "text" : "RT @_iota: \u54B2 -Saki- \u963F\u77E5\u8CC0\u7DE8 \u304CTV\u30A2\u30CB\u30E1\u5316\u6C7A\u5B9A\uFF01http:\/\/t.co\/e5KxN28J \u6C60\u7530\u304C\u4E3B\u5F79\u3067\u3059\u3088\u306D\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/e5KxN28J",
        "expanded_url" : "http:\/\/yaraon.blog109.fc2.com\/blog-entry-4390.html",
        "display_url" : "yaraon.blog109.fc2.com\/blog-entry-439\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "121556996133634048",
    "text" : "\u54B2 -Saki- \u963F\u77E5\u8CC0\u7DE8 \u304CTV\u30A2\u30CB\u30E1\u5316\u6C7A\u5B9A\uFF01http:\/\/t.co\/e5KxN28J \u6C60\u7530\u304C\u4E3B\u5F79\u3067\u3059\u3088\u306D\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
    "id" : 121556996133634048,
    "created_at" : "2011-10-05 12:07:00 +0000",
    "user" : {
      "name" : "\u4ECA\u65E5\u3082\u30A4\u30AA\u30BF\u3060\u306B\u3083\u30FC",
      "screen_name" : "_iota",
      "protected" : false,
      "id_str" : "69003052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000693751472\/3c0460eae07e54575d1addcf3e5aba0a_normal.png",
      "id" : 69003052,
      "verified" : false
    }
  },
  "id" : 121558573535858688,
  "created_at" : "2011-10-05 12:13:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 13, 22 ],
      "id_str" : "566116291",
      "id" : 566116291
    }, {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 46, 54 ],
      "id_str" : "102002367",
      "id" : 102002367
    }, {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 56, 65 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121556615093698560",
  "text" : "\u3042\u30FC\u3001\u3075\u3044\u305F\u3075\u3044\u305F RT @reflexio: \u5439\u3044\u305F\u611F\u304C\u4F1D\u308F\u3063\u3066\u3053\u306A\u3044\u3093\u3060\u304Cwww RT @maten10: @reflexio \u3075\u3044\u305F",
  "id" : 121556615093698560,
  "created_at" : "2011-10-05 12:05:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9AD8\u4E09 \u548C\u6643",
      "screen_name" : "takasan_san_san",
      "indices" : [ 0, 16 ],
      "id_str" : "230918258",
      "id" : 230918258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121548504760979456",
  "geo" : { },
  "id_str" : "121549189242032128",
  "in_reply_to_user_id" : 230918258,
  "text" : "@takasan_san_san \u660E\u65E5\u7D50\u5C40\u5834\u6240\u306F\u3069\u3053\u306B\u306A\u308B\u304B\u306A\u3002\u8A98\u3063\u305F\u4EBA\u306B\u30A2\u30CA\u30A6\u30F3\u30B9\u3057\u306A\u3044\u3068\u30FB\u30FB\u30FB\u3002",
  "id" : 121549189242032128,
  "in_reply_to_status_id" : 121548504760979456,
  "created_at" : "2011-10-05 11:35:59 +0000",
  "in_reply_to_screen_name" : "takasan_san_san",
  "in_reply_to_user_id_str" : "230918258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121543965399982080",
  "text" : "\u4ECA\u671F\u306F\u5FD9\u3057\u3044\u3093\u3058\u3083\u306A\u3044\u3001\u305F\u3060\u52C9\u5F37\u306B\u5145\u5B9F\u3057\u3066\u308B\u3060\u3051\u3060\uFF08\u767D\u76EE",
  "id" : 121543965399982080,
  "created_at" : "2011-10-05 11:15:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121543843354128385",
  "text" : "\u306A\u3093\u304B\u5B66\u90E8\u3068\u304B\u3069\u3046\u3067\u3082\u3088\u304F\u306A\u3063\u3066\u304D\u305F\u3002\u660E\u65E5\uFF13\u9650\u306F\u91D1\u878D\u8AD6\u306B\u884C\u3063\u3066\u307F\u3088\u3046\u3002",
  "id" : 121543843354128385,
  "created_at" : "2011-10-05 11:14:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 3, 12 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121543329610612736",
  "text" : "RT @the_TQFT: \u30C9\u306F\u6955\u5186\u306E\u30C9\uFF57\uFF57\uFF57\u30EC\u306F\u6955\u5186\u306E\u30EC\uFF57\uFF57\uFF57\u30DF\u306F\u6955\u5186\u306E\u30DF\uFF57\uFF57\uFF57\u30D5\u30A1\u306F\u6955\u5186\u306E\u30D5\u30A1\uFF57\uFF57\uFF57\u30BD\u306F\u8D85\u6955\u5186\uFF57\uFF57\uFF57\u30E9\u306F\u8D85\u6955\u5186\uFF57\uFF57\uFF57\u30B7\u306F\u8D85\u6955\u5186\uFF57\uFF57\uFF57\u3055\u3042\u30D5\u30D2\u30D2\u30D2\u30D2\uFF57\uFF57\uFF57\uFF57\uFF57",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121539464257478656",
    "text" : "\u30C9\u306F\u6955\u5186\u306E\u30C9\uFF57\uFF57\uFF57\u30EC\u306F\u6955\u5186\u306E\u30EC\uFF57\uFF57\uFF57\u30DF\u306F\u6955\u5186\u306E\u30DF\uFF57\uFF57\uFF57\u30D5\u30A1\u306F\u6955\u5186\u306E\u30D5\u30A1\uFF57\uFF57\uFF57\u30BD\u306F\u8D85\u6955\u5186\uFF57\uFF57\uFF57\u30E9\u306F\u8D85\u6955\u5186\uFF57\uFF57\uFF57\u30B7\u306F\u8D85\u6955\u5186\uFF57\uFF57\uFF57\u3055\u3042\u30D5\u30D2\u30D2\u30D2\u30D2\uFF57\uFF57\uFF57\uFF57\uFF57",
    "id" : 121539464257478656,
    "created_at" : "2011-10-05 10:57:21 +0000",
    "user" : {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "protected" : false,
      "id_str" : "176127240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537606320774328320\/aCSpGQiZ_normal.jpeg",
      "id" : 176127240,
      "verified" : false
    }
  },
  "id" : 121543329610612736,
  "created_at" : "2011-10-05 11:12:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u77F3\u585A\uFF08\u7121\u6240\u5C5E\uFF09",
      "screen_name" : "Yusuke_Ishizuka",
      "indices" : [ 3, 19 ],
      "id_str" : "132814552",
      "id" : 132814552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121516280086925312",
  "text" : "RT @Yusuke_Ishizuka: \u4FFA\u304C\u8A3C\u660E\u3067\u304D\u3066\u306A\u3044\u547D\u984C\u306F\u5168\u3066\u72EC\u7ACB\u547D\u984C\u3060\u3068\u601D\u3063\u3066\u307F\u305F\u3089\u4E16\u754C\u304C\u5909\u308F\u3063\u305F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/yubitter.com\/\" rel=\"nofollow\"\u003Eyubitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121514783538282496",
    "text" : "\u4FFA\u304C\u8A3C\u660E\u3067\u304D\u3066\u306A\u3044\u547D\u984C\u306F\u5168\u3066\u72EC\u7ACB\u547D\u984C\u3060\u3068\u601D\u3063\u3066\u307F\u305F\u3089\u4E16\u754C\u304C\u5909\u308F\u3063\u305F",
    "id" : 121514783538282496,
    "created_at" : "2011-10-05 09:19:16 +0000",
    "user" : {
      "name" : "\u77F3\u585A\uFF08\u7121\u6240\u5C5E\uFF09",
      "screen_name" : "Yusuke_Ishizuka",
      "protected" : false,
      "id_str" : "132814552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572415497040175104\/3hfuo4r5_normal.png",
      "id" : 132814552,
      "verified" : false
    }
  },
  "id" : 121516280086925312,
  "created_at" : "2011-10-05 09:25:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 10, 17 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121514471993769984",
  "geo" : { },
  "id_str" : "121516007671074816",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa @ayu167 \uFF08\u30DC\u30FC\u30EB\u30DA\u30F3\u306E\u8A71\u304B\u3068\u601D\u3063\u305F\u306A\u3093\u3066\u672C\u97F3\u3092\u8A00\u3046\u6C17\u306F\u3055\u3089\u3055\u3089\u306A\u3044\uFF09",
  "id" : 121516007671074816,
  "in_reply_to_status_id" : 121514471993769984,
  "created_at" : "2011-10-05 09:24:08 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    }, {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 9, 18 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121465722546290689",
  "geo" : { },
  "id_str" : "121514828954206208",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 @reflexio \u3080\u3001\u4ECA\u671F\u306F\u304B\u306A\u308A\u5FD9\u3057\u3044\u3093\u3060\u305C",
  "id" : 121514828954206208,
  "in_reply_to_status_id" : 121465722546290689,
  "created_at" : "2011-10-05 09:19:27 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121461261081911296",
  "geo" : { },
  "id_str" : "121462855362027520",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u30A2\u30CA\u30A6\u30F3\u30B9\u306A\u3055\u3059\u304E\u3060\u3057\u5373\u8208\u3060\u3057\u4ED5\u65B9\u306A\u3044",
  "id" : 121462855362027520,
  "in_reply_to_status_id" : 121461261081911296,
  "created_at" : "2011-10-05 05:52:56 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121460740237430784",
  "geo" : { },
  "id_str" : "121460965643534336",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3088\u3001\uFF14\u884C\u304F\u3089\u3044\u3067\u3057\u3087\u3046\u304B",
  "id" : 121460965643534336,
  "in_reply_to_status_id" : 121460740237430784,
  "created_at" : "2011-10-05 05:45:25 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121460595236155392",
  "text" : "\u6587\u5B66\u90E8\u3063\u3066\u611F\u3058\uFF08\u767D\u76EE",
  "id" : 121460595236155392,
  "created_at" : "2011-10-05 05:43:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121460490940583936",
  "text" : "RT @magokoro84: \u30C6\u30ED\u3068\u306E\u6226\u3044\u6642\u4EE3\u306E\u30A2\u30E1\u30EA\u30AB\u306E\u5916\u4EA4\u653F\u7B56\u3092\u4E2D\u5FC3\u306B\u5B66\u3073\u305F\u3044\u3068\u306F\u66F8\u3044\u305F\u3082\u306E\u306E\u3042\u3093\u307E\u308A\u6587\u5B66\u90E8\u3063\u3066\u611F\u3058\u3057\u306A\u3044\u306A",
  "id" : 121460490940583936,
  "created_at" : "2011-10-05 05:43:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121459176827387904",
  "geo" : { },
  "id_str" : "121460303794933760",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u3069\u3046\u305B\u8AB0\u3082\u8AAD\u307E\u306A\u3044\u304B\u3089\u5927\u4E08\u592B\u3055",
  "id" : 121460303794933760,
  "in_reply_to_status_id" : 121459176827387904,
  "created_at" : "2011-10-05 05:42:47 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    }, {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 10, 18 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121456838792314880",
  "text" : "@reflexio @maten10 \u3069\u3046\u305B\u7C21\u5358\u306B\u3042\u3064\u307E\u308B\u3002\u30A2\u30EC\u306A\u3089\u5927\u5B66\u306E\u53CB\u4EBA\u3067\u3082\u3002",
  "id" : 121456838792314880,
  "created_at" : "2011-10-05 05:29:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 0, 9 ],
      "id_str" : "566116291",
      "id" : 566116291
    }, {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 10, 18 ],
      "id_str" : "102002367",
      "id" : 102002367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121456150158913536",
  "text" : "@reflexio @maten10 \uFF14\u4EBA\u304C\u3044\u3044\u306A\u30FC",
  "id" : 121456150158913536,
  "created_at" : "2011-10-05 05:26:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121455990280433664",
  "text" : "\u3042\u3001\u6587\u5B66\u90E8\u306E\uFF12\u56DE\u306E\u4EBA\u5C02\u4FEE\u5E0C\u671B\u306E\u7D1917\u6642\u7DE0\u3081\u5207\u308A\u3089\u3057\u3044\u3088\uFF08\u767D\u76EE",
  "id" : 121455990280433664,
  "created_at" : "2011-10-05 05:25:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121455759354630144",
  "text" : "\u4ECA\u671F\u306F\u79D1\u54F2\u4EBA\u3067\u6570\u5B66\u5F92\u3067\u6559\u80B2\u8005\u306A\u6642\u9593\u5272\u3002\u3044\u3084\u3001\u6642\u9593\u5272\u5916\u3067\u3082\u305D\u3046\u304B\u3082\u3002",
  "id" : 121455759354630144,
  "created_at" : "2011-10-05 05:24:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3066\u3043\u3093",
      "screen_name" : "maten10",
      "indices" : [ 0, 8 ],
      "id_str" : "102002367",
      "id" : 102002367
    }, {
      "name" : "L. S. ",
      "screen_name" : "reflexio",
      "indices" : [ 9, 18 ],
      "id_str" : "566116291",
      "id" : 566116291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121450424946532353",
  "geo" : { },
  "id_str" : "121455353929023489",
  "in_reply_to_user_id" : 102002367,
  "text" : "@maten10 @reflexio \u9EBB\u96C0\u2026\uFF08\uFF81\uFF97\uFF6F",
  "id" : 121455353929023489,
  "in_reply_to_status_id" : 121450424946532353,
  "created_at" : "2011-10-05 05:23:07 +0000",
  "in_reply_to_screen_name" : "maten10",
  "in_reply_to_user_id_str" : "102002367",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/PkbI7wb0",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/14?prefill=sigmapsi",
      "display_url" : "gohantabeyo.com\/nani\/14?prefil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121437726691180544",
  "text" : "sigmapsi\u304C\u3001\u79C1\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3042\u3044\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3042\u3044\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/PkbI7wb0",
  "id" : 121437726691180544,
  "created_at" : "2011-10-05 04:13:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121390675462852608",
  "text" : "\u305D\u308D\u305D\u308D\u51FA\u306A\u3044\u3068\u9593\u306B\u5408\u308F\u306A\u3044\u3088\u306A\uFF08\u767D\u76EE",
  "id" : 121390675462852608,
  "created_at" : "2011-10-05 01:06:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 3, 11 ],
      "id_str" : "112886536",
      "id" : 112886536
    }, {
      "name" : "Ivan",
      "screen_name" : "3dzin",
      "indices" : [ 21, 27 ],
      "id_str" : "3231433158",
      "id" : 3231433158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121230946174382080",
  "text" : "RT @maucha_: \u6ECB\u8CC0\u305F\u306A\u3044RT @3dzin \u6ECB\u8CC0\u3063\u3066\u5B57\u9762\u304C\u30C0\u30B5\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ivan",
        "screen_name" : "3dzin",
        "indices" : [ 8, 14 ],
        "id_str" : "3231433158",
        "id" : 3231433158
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121229543276154880",
    "text" : "\u6ECB\u8CC0\u305F\u306A\u3044RT @3dzin \u6ECB\u8CC0\u3063\u3066\u5B57\u9762\u304C\u30C0\u30B5\u3044",
    "id" : 121229543276154880,
    "created_at" : "2011-10-04 14:25:50 +0000",
    "user" : {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "protected" : false,
      "id_str" : "112886536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597796967784153089\/nKjalxOi_normal.png",
      "id" : 112886536,
      "verified" : false
    }
  },
  "id" : 121230946174382080,
  "created_at" : "2011-10-04 14:31:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121193848230789120",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 121193848230789120,
  "created_at" : "2011-10-04 12:03:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3080\u3089\u304B\u307F\u307F\u304B\u3093",
      "screen_name" : "mikanredtail",
      "indices" : [ 3, 16 ],
      "id_str" : "138340661",
      "id" : 138340661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121114828034158593",
  "text" : "RT @mikanredtail: \u300CI saw a real bad blog about you, you seen this?\u300D\u3068\u3044\u3046DM\u304C\u5C4A\u3044\u3066\u3082\u958B\u3051\u3066\u306F\u3044\u3051\u307E\u305B\u3093\u3002\u3064\u3044\u958B\u3051\u305F\u304F\u306A\u3063\u3061\u3083\u3046\u3051\u3069\u3002\u958B\u3051\u308B\u3068\u3001\u540C\u3058\u30E1\u30FC\u30EB\u304C\u81EA\u5206\u306E\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u306B\u4E00\u6589\u9001\u4FE1\u3055\u308C\u3066\u3057\u307E\u3046\u3088\u3046\u3067\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121101083350269952",
    "text" : "\u300CI saw a real bad blog about you, you seen this?\u300D\u3068\u3044\u3046DM\u304C\u5C4A\u3044\u3066\u3082\u958B\u3051\u3066\u306F\u3044\u3051\u307E\u305B\u3093\u3002\u3064\u3044\u958B\u3051\u305F\u304F\u306A\u3063\u3061\u3083\u3046\u3051\u3069\u3002\u958B\u3051\u308B\u3068\u3001\u540C\u3058\u30E1\u30FC\u30EB\u304C\u81EA\u5206\u306E\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u306B\u4E00\u6589\u9001\u4FE1\u3055\u308C\u3066\u3057\u307E\u3046\u3088\u3046\u3067\u3059\u3002",
    "id" : 121101083350269952,
    "created_at" : "2011-10-04 05:55:22 +0000",
    "user" : {
      "name" : "\u3080\u3089\u304B\u307F\u307F\u304B\u3093",
      "screen_name" : "mikanredtail",
      "protected" : false,
      "id_str" : "138340661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/859636323\/e0012955_238367_normal.jpg",
      "id" : 138340661,
      "verified" : false
    }
  },
  "id" : 121114828034158593,
  "created_at" : "2011-10-04 06:49:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EC\u30C8\u30B9\uFF20\u7169\u60A9\u9ED2\u5B50",
      "screen_name" : "miretoss",
      "indices" : [ 3, 12 ],
      "id_str" : "111577811",
      "id" : 111577811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121103059685343232",
  "text" : "RT @miretoss: \u4ED6\u5927\u751F\u300C\u7B51\u6CE2\u5927\u5B66\u6848\u5185\u3057\u3066\u6B32\u3057\u3044\u3093\u3060\u3051\u3069\u300D\u7B51\u6CE2\u751F\u300C\u3042\u30FC\u3001\u4FFA\u5927\u5B66\u3088\u304F\u77E5\u3089\u306A\u3044\u304B\u3089\u300D\u4ED6\u300C\u3048\u3001\u3058\u3083\u3042\u6388\u696D\u3069\u3046\u3084\u3063\u3066\u53D7\u3051\u308B\u306E\uFF1F\u300D\u7B51\u300C\u3048\u3001\u666E\u901A\u306B\u6559\u5BA4\u884C\u304F\u3051\u3069\u300D\u4ED6\u300C\u3058\u3083\u3042\u308F\u304B\u3063\u3066\u308B\u3058\u3083\u3093\u300D\u7B51\u300C\u3044\u3084\u5168\u7136\u77E5\u3089\u306A\u3044\u304B\u3089\u300D\u4ED6\u300C\u3058\u3083\u3042\u56F3\u66F8\u9928\u306F\uFF1F\u300D\u7B51\u300C\u3069\u3053\u306E\uFF1F\u300D\u4ED6\u300C\u3048\uFF1F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121098917579460609",
    "text" : "\u4ED6\u5927\u751F\u300C\u7B51\u6CE2\u5927\u5B66\u6848\u5185\u3057\u3066\u6B32\u3057\u3044\u3093\u3060\u3051\u3069\u300D\u7B51\u6CE2\u751F\u300C\u3042\u30FC\u3001\u4FFA\u5927\u5B66\u3088\u304F\u77E5\u3089\u306A\u3044\u304B\u3089\u300D\u4ED6\u300C\u3048\u3001\u3058\u3083\u3042\u6388\u696D\u3069\u3046\u3084\u3063\u3066\u53D7\u3051\u308B\u306E\uFF1F\u300D\u7B51\u300C\u3048\u3001\u666E\u901A\u306B\u6559\u5BA4\u884C\u304F\u3051\u3069\u300D\u4ED6\u300C\u3058\u3083\u3042\u308F\u304B\u3063\u3066\u308B\u3058\u3083\u3093\u300D\u7B51\u300C\u3044\u3084\u5168\u7136\u77E5\u3089\u306A\u3044\u304B\u3089\u300D\u4ED6\u300C\u3058\u3083\u3042\u56F3\u66F8\u9928\u306F\uFF1F\u300D\u7B51\u300C\u3069\u3053\u306E\uFF1F\u300D\u4ED6\u300C\u3048\uFF1F\u7B51\u6CE2\u306E\u3060\u3051\u3069\u300D\u7B51\u300C\u3060\u304B\u3089\u3069\u3053\u306E\uFF1F\u300D",
    "id" : 121098917579460609,
    "created_at" : "2011-10-04 05:46:46 +0000",
    "user" : {
      "name" : "\u30DF\u30EC\u30C8\u30B9\uFF20\u7169\u60A9\u9ED2\u5B50",
      "screen_name" : "miretoss",
      "protected" : false,
      "id_str" : "111577811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1566549487\/___normal.jpg",
      "id" : 111577811,
      "verified" : false
    }
  },
  "id" : 121103059685343232,
  "created_at" : "2011-10-04 06:03:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121096088835985408",
  "text" : "\u3069\u3061\u3089\u304B\u3068\u8A00\u3048\u3070\u5F8C\u308D\u306E\u65B9\u3060\u304C\u5F8C\u308D\u306E\u673A\u306E\u30B0\u30EB\u30FC\u30D7\u3067\u306F\u3069\u3061\u3089\u304B\u3068\u8A00\u3048\u3070\u524D\u306E\u65B9\u306B\u5EA7\u308B\u30AF\u30E9\u30B9\u30BF",
  "id" : 121096088835985408,
  "created_at" : "2011-10-04 05:35:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121033509627371520",
  "text" : "\u610F\u8B58\u4F4E\u3044\u3069\u3053\u308D\u304B\u610F\u8B58\u7121\u3044\u30EC\u30D9\u30EB\u306E\u53CB\u4EBA\u304C\u3084\u3063\u3071\u308A\u3044\u306A\u3044\u3002\u6765\u308B\u306E\u304B\u306A\u3041\u2026\u3002",
  "id" : 121033509627371520,
  "created_at" : "2011-10-04 01:26:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayu",
      "screen_name" : "Ayu167",
      "indices" : [ 0, 7 ],
      "id_str" : "2577910765",
      "id" : 2577910765
    }, {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 8, 17 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120831272825257984",
  "text" : "@ayu167 @akeopyaa \u6307\u5B9A\u6821\u3092\u5426\u5B9A\u3057\u3066\u3044\u3053\u3046",
  "id" : 120831272825257984,
  "created_at" : "2011-10-03 12:03:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120829899199086593",
  "text" : "\uFF2B\uFF35\u3077\u3088\u3077\u3088\u30AA\u30D5\u3068\u304B\u2026\u884C\u3063\u3066\u898B\u305F\u3044\u3051\u3069\u53C2\u8003\u306B\u306A\u3089\u306A\u3044\u3060\u308D\u3046\u306A\uFF1E\uFF1C",
  "id" : 120829899199086593,
  "created_at" : "2011-10-03 11:57:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120823685627125760",
  "text" : "\u3044\u306C\u304C\u3044\u3058\u3081\u3089\u308C\u3066\u3066\u3001\u30A2\u30EC\u3002\u3044\u3084\u3001\u3082\u3061\u308D\u3093\u3044\u3044\u610F\u5473\u3067\u3002",
  "id" : 120823685627125760,
  "created_at" : "2011-10-03 11:33:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "indices" : [ 3, 12 ],
      "id_str" : "105498380",
      "id" : 105498380
    }, {
      "name" : " .",
      "screen_name" : "Jojo__0707",
      "indices" : [ 14, 25 ],
      "id_str" : "1512646136",
      "id" : 1512646136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120823576961105920",
  "text" : "RT @_Nururin: @Jojo__0707 \u3053\u306E\u7A0B\u5EA6\u306E\u62E1\u6563\u529B\u3060\u3068\u9762\u767D\u3044\u30CD\u30BF\u3058\u3083\u306A\u3044\u3068\u30DE\u30C8\u30E2\u306B\u5E83\u304C\u3089\u306A\u3044\u3093\u3060\u3001\u3054\u3081\u3093\u306D\u3001\u9762\u767D\u304F\u306A\u3044\u3068\u3044\u3046\u4E8B\u5B9F\u3092\u7A81\u304D\u3064\u3051\u3061\u3083\u3063\u3066\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : " .",
        "screen_name" : "Jojo__0707",
        "indices" : [ 0, 11 ],
        "id_str" : "1512646136",
        "id" : 1512646136
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120823136626286593",
    "text" : "@Jojo__0707 \u3053\u306E\u7A0B\u5EA6\u306E\u62E1\u6563\u529B\u3060\u3068\u9762\u767D\u3044\u30CD\u30BF\u3058\u3083\u306A\u3044\u3068\u30DE\u30C8\u30E2\u306B\u5E83\u304C\u3089\u306A\u3044\u3093\u3060\u3001\u3054\u3081\u3093\u306D\u3001\u9762\u767D\u304F\u306A\u3044\u3068\u3044\u3046\u4E8B\u5B9F\u3092\u7A81\u304D\u3064\u3051\u3061\u3083\u3063\u3066\u3002",
    "id" : 120823136626286593,
    "created_at" : "2011-10-03 11:30:55 +0000",
    "user" : {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "protected" : false,
      "id_str" : "105498380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591661205489520640\/gzUrW2-9_normal.jpg",
      "id" : 105498380,
      "verified" : false
    }
  },
  "id" : 120823576961105920,
  "created_at" : "2011-10-03 11:32:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "indices" : [ 3, 12 ],
      "id_str" : "105498380",
      "id" : 105498380
    }, {
      "name" : "\u6DF1\u4E95\u4E00\u8DE1",
      "screen_name" : "Raptor1992",
      "indices" : [ 22, 33 ],
      "id_str" : "616849027",
      "id" : 616849027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120822541739769856",
  "text" : "RT @_Nururin: \u308C\u304A\u304F\u3093 RT @Raptor1992: \u93E1\u3088\u93E1\u3001\u4E16\u754C\u3067\u4E00\u756A\u8981\u3089\u306A\u3044\u306E\u306F\u8AB0\uFF1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u6DF1\u4E95\u4E00\u8DE1",
        "screen_name" : "Raptor1992",
        "indices" : [ 8, 19 ],
        "id_str" : "616849027",
        "id" : 616849027
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120822402895712256",
    "text" : "\u308C\u304A\u304F\u3093 RT @Raptor1992: \u93E1\u3088\u93E1\u3001\u4E16\u754C\u3067\u4E00\u756A\u8981\u3089\u306A\u3044\u306E\u306F\u8AB0\uFF1F",
    "id" : 120822402895712256,
    "created_at" : "2011-10-03 11:28:00 +0000",
    "user" : {
      "name" : "\u306C\u308B\u30FC",
      "screen_name" : "_Nururin",
      "protected" : false,
      "id_str" : "105498380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591661205489520640\/gzUrW2-9_normal.jpg",
      "id" : 105498380,
      "verified" : false
    }
  },
  "id" : 120822541739769856,
  "created_at" : "2011-10-03 11:28:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120810354182856704",
  "text" : "\u30EB\u30CD\u30AA\u30D5\u3044\u3064\u304B\u3053\u3063\u305D\u308A\u53C2\u52A0\u3057\u3066\u307F\u305F\u3044\u306A\u3041",
  "id" : 120810354182856704,
  "created_at" : "2011-10-03 10:40:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120786022186500096",
  "text" : "\u306B\u305B\u307B\u30FC",
  "id" : 120786022186500096,
  "created_at" : "2011-10-03 09:03:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feel like I been rid",
      "screen_name" : "i_horse",
      "indices" : [ 0, 8 ],
      "id_str" : "1689818772",
      "id" : 1689818772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120679351074295809",
  "text" : "@i_horse \u898B\u3089\u308C\u305F\u304B\u3082\u3057\u308C\u307E\u305B\u3093\uFF57",
  "id" : 120679351074295809,
  "created_at" : "2011-10-03 01:59:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120671548486062082",
  "text" : "\u7406\u5B66\u5DE5\u5B66\u90E8\u5411\u3051\uFF57\uFF57\uFF57\u30A2\u30A6\u30A7\u30FC\uFF57\uFF57\uFF57",
  "id" : 120671548486062082,
  "created_at" : "2011-10-03 01:28:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120671351932596224",
  "text" : "\u6570\u7406\u7D71\u8A08\u3063\uFF01\u305F\u3060\u3057\u6587\u5B66\u90E8\u3063\uFF01\u307F\u305F\u3044\u306A\u3063\uFF01",
  "id" : 120671351932596224,
  "created_at" : "2011-10-03 01:27:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120651814134743040",
  "text" : "\u6587\u5B66\u90E8\u4E00\u9650\u3068\u304B\u7121\u4EBA\u306B\u8FD1\u3044\u3082\u3093\u306A\u3001\u958B\u3044\u3066\u308B\u306F\u305A\u3060",
  "id" : 120651814134743040,
  "created_at" : "2011-10-03 00:10:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120649242992848896",
  "text" : "\u305D\u3057\u3066\u3042\u307E\u308A\u52E2\u3044\u304C\u8870\u3048\u306A\u3044TL",
  "id" : 120649242992848896,
  "created_at" : "2011-10-02 23:59:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 3, 14 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120649120422699010",
  "text" : "RT @magokoro84: \u4ECA\u9031\u306F5\u65E5\u3082\u8B1B\u7FA9\u3042\u308B\u306E\u304B\u3000\u5148\u9031\u306F\u306A\u304B\u3063\u305F\u306E\u306B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120648835742711808",
    "text" : "\u4ECA\u9031\u306F5\u65E5\u3082\u8B1B\u7FA9\u3042\u308B\u306E\u304B\u3000\u5148\u9031\u306F\u306A\u304B\u3063\u305F\u306E\u306B",
    "id" : 120648835742711808,
    "created_at" : "2011-10-02 23:58:18 +0000",
    "user" : {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "protected" : false,
      "id_str" : "213268728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598083357839265792\/q6CsfIW__normal.jpg",
      "id" : 213268728,
      "verified" : false
    }
  },
  "id" : 120649120422699010,
  "created_at" : "2011-10-02 23:59:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120648244295503872",
  "text" : "\u540C\u3058\u6559\u5BA4\u306B\u3001\u30EA\u30B9\u30C8\u4E0A\u306E\u4EBA\u3005\u304C\u3061\u3089\u307B\u3089\u3044\u308B\u3089\u3057\u3044\u2026",
  "id" : 120648244295503872,
  "created_at" : "2011-10-02 23:55:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120647870025187329",
  "text" : "\u3053\u30FC\u307F\u30FC\u3059\u30FC\u304E\u30FC\uFF01\n\u6559\u5BA4\u5909\u3048\u3088\u3046\uFF1F",
  "id" : 120647870025187329,
  "created_at" : "2011-10-02 23:54:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atsuki Nagao",
      "screen_name" : "ac_key",
      "indices" : [ 3, 10 ],
      "id_str" : "443191476",
      "id" : 443191476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120647559374053376",
  "text" : "RT @ac_key: \u300E\u4FFA\u9054\u306E\u5F8C\u671F\u306F\u3001\u307E\u3060\u59CB\u307E\u3063\u305F\u3070\u304B\u308A\u3060\uFF6F\uFF01\uFF01\uFF01\u300F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120646788427423744",
    "text" : "\u300E\u4FFA\u9054\u306E\u5F8C\u671F\u306F\u3001\u307E\u3060\u59CB\u307E\u3063\u305F\u3070\u304B\u308A\u3060\uFF6F\uFF01\uFF01\uFF01\u300F",
    "id" : 120646788427423744,
    "created_at" : "2011-10-02 23:50:10 +0000",
    "user" : {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "protected" : false,
      "id_str" : "106036912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600553053863817216\/2TsFpIn8_normal.png",
      "id" : 106036912,
      "verified" : false
    }
  },
  "id" : 120647559374053376,
  "created_at" : "2011-10-02 23:53:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120647474867220480",
  "text" : "RT @senna0218: \u6559\u80B2\u76F8\u8AC7\u6DF7\u307F\u3059\u304E\u30EF\u30ED\u30BF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120645820461744130",
    "text" : "\u6559\u80B2\u76F8\u8AC7\u6DF7\u307F\u3059\u304E\u30EF\u30ED\u30BF",
    "id" : 120645820461744130,
    "created_at" : "2011-10-02 23:46:19 +0000",
    "user" : {
      "name" : "\u702C\u540D\uFF20\u306C\u3044\u3050\u308B\u307F\u738B\u56FD",
      "screen_name" : "Nao_esperanza",
      "protected" : false,
      "id_str" : "167773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000455774748\/c1efa70be03b029a2bab166e73687830_normal.jpeg",
      "id" : 167773216,
      "verified" : false
    }
  },
  "id" : 120647474867220480,
  "created_at" : "2011-10-02 23:52:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3056\u3079\u3059",
      "screen_name" : "Elizabeth_H_01",
      "indices" : [ 25, 40 ],
      "id_str" : "323566206",
      "id" : 323566206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120647388288397312",
  "text" : "RT @kussytessy: \u203B\u6700\u521D\u3060\u3051 RT @Elizabeth_H_01: Twitter\u898B\u3066\u3066\u308F\u304B\u308B\u3053\u3068\uFF1A\u306A\u3093\u3084\u304B\u3093\u3084\u3067\u65B0\u5B66\u671F\u304C\u59CB\u307E\u308C\u3070\u7686\u3055\u3093\u3061\u3083\u3093\u3068\u8D77\u304D\u308C\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3056\u3079\u3059",
        "screen_name" : "Elizabeth_H_01",
        "indices" : [ 9, 24 ],
        "id_str" : "323566206",
        "id" : 323566206
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120645543813853186",
    "text" : "\u203B\u6700\u521D\u3060\u3051 RT @Elizabeth_H_01: Twitter\u898B\u3066\u3066\u308F\u304B\u308B\u3053\u3068\uFF1A\u306A\u3093\u3084\u304B\u3093\u3084\u3067\u65B0\u5B66\u671F\u304C\u59CB\u307E\u308C\u3070\u7686\u3055\u3093\u3061\u3083\u3093\u3068\u8D77\u304D\u308C\u308B",
    "id" : 120645543813853186,
    "created_at" : "2011-10-02 23:45:13 +0000",
    "user" : {
      "name" : "DEAD END",
      "screen_name" : "7ksts",
      "protected" : false,
      "id_str" : "96237218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593483929\/091227_0015_0001_normal.jpg",
      "id" : 96237218,
      "verified" : false
    }
  },
  "id" : 120647388288397312,
  "created_at" : "2011-10-02 23:52:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120645870868901889",
  "text" : "\u4EBA\u304C\u3053\u3093\u306A\u306B\u96C6\u307E\u3063\u3066\u308B\u306E\u3092\u4E45\u3005\u306B\u898B\u305F",
  "id" : 120645870868901889,
  "created_at" : "2011-10-02 23:46:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u306D",
      "screen_name" : "spine19642",
      "indices" : [ 3, 14 ],
      "id_str" : "264623696",
      "id" : 264623696
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u307F\u3093\u306A\u304C\u3082\u3046\u5FD8\u308C\u3066\u3044\u308B\u3053\u3068",
      "indices" : [ 52, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120643722126958592",
  "text" : "RT @spine19642: \u300C\u3042\u30FC\u3001\u524D\u671F\u52C9\u5F37\u3057\u3066\u306A\u3044\u305B\u3044\u3067\u30DE\u30B8\u671F\u672B\u7126\u3063\u305F\u3002\u5F8C\u671F\u306F\u3061\u3083\u3093\u3068\u3084\u308B\u308F\u30FC\u300D #\u307F\u3093\u306A\u304C\u3082\u3046\u5FD8\u308C\u3066\u3044\u308B\u3053\u3068",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u307F\u3093\u306A\u304C\u3082\u3046\u5FD8\u308C\u3066\u3044\u308B\u3053\u3068",
        "indices" : [ 36, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120640906205474816",
    "text" : "\u300C\u3042\u30FC\u3001\u524D\u671F\u52C9\u5F37\u3057\u3066\u306A\u3044\u305B\u3044\u3067\u30DE\u30B8\u671F\u672B\u7126\u3063\u305F\u3002\u5F8C\u671F\u306F\u3061\u3083\u3093\u3068\u3084\u308B\u308F\u30FC\u300D #\u307F\u3093\u306A\u304C\u3082\u3046\u5FD8\u308C\u3066\u3044\u308B\u3053\u3068",
    "id" : 120640906205474816,
    "created_at" : "2011-10-02 23:26:48 +0000",
    "user" : {
      "name" : "\u304F\u308D\u306D",
      "screen_name" : "spine19642",
      "protected" : true,
      "id_str" : "264623696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546664642706038784\/zIKF1Qxx_normal.jpeg",
      "id" : 264623696,
      "verified" : false
    }
  },
  "id" : 120643722126958592,
  "created_at" : "2011-10-02 23:37:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120637124935553024",
  "text" : "\u4F55\u304B\u3057\u3089\u5922\u3092\u898B\u3066\u3044\u305F\u6C17\u304C\u3057\u3066\u306A\u3089\u306A\u3044\u3001\u304C\u7121\u7C8B\u306A\u76EE\u899A\u307E\u3057\u306E\u97F3\u3067\u5168\u90E8\u5FD8\u308C\u305F",
  "id" : 120637124935553024,
  "created_at" : "2011-10-02 23:11:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3054\u3053\u308D",
      "screen_name" : "magokoro84",
      "indices" : [ 0, 11 ],
      "id_str" : "213268728",
      "id" : 213268728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120634996456300544",
  "geo" : { },
  "id_str" : "120635401621864449",
  "in_reply_to_user_id" : 213268728,
  "text" : "@magokoro84 \u304A\u306F\u3088\u3046",
  "id" : 120635401621864449,
  "in_reply_to_status_id" : 120634996456300544,
  "created_at" : "2011-10-02 23:04:55 +0000",
  "in_reply_to_screen_name" : "magokoro84",
  "in_reply_to_user_id_str" : "213268728",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120632652419182592",
  "text" : "\u8D77\u5E8A \u55DA\u547C",
  "id" : 120632652419182592,
  "created_at" : "2011-10-02 22:54:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120535788575395840",
  "text" : "\u7720\u308C\u306A\u3044\u3060\u308D\u3046\u304C\u304A\u3084\u3059\u307F\u306A\u3055\u3044\n\u958B\u5E55\u4E00\u9650\u3060\u2026",
  "id" : 120535788575395840,
  "created_at" : "2011-10-02 16:29:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "erecipe",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/sqg5MD6q",
      "expanded_url" : "http:\/\/exci.to\/pMtzTL",
      "display_url" : "exci.to\/pMtzTL"
    } ]
  },
  "geo" : { },
  "id_str" : "120524953455034368",
  "text" : "memo[ \u30AB\u30B7\u30E5\u30FC\u30CA\u30C3\u30C4\u98EF by E\u30EC\u30B7\u30D4] #erecipe http:\/\/t.co\/sqg5MD6q",
  "id" : 120524953455034368,
  "created_at" : "2011-10-02 15:46:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120513855368605696",
  "text" : "\u6642\u9593\u5272\u7D44\u3093\u3067\u3066\u6182\u9B31\u306B\u306A\u3063\u305F\u3002\u524D\u671F\u304C\u6687\u3060\u3063\u305F\u304B\u3089\u843D\u5DEE\u3001\u697D\u3058\u3083\u306A\u3044\u3055",
  "id" : 120513855368605696,
  "created_at" : "2011-10-02 15:01:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120509980427300864",
  "text" : "\u3042\u3041\u660E\u65E5\u304C\u3059\u3050\u305D\u3053\u307E\u3067\u6765\u3066\u3044\u308B\u2026",
  "id" : 120509980427300864,
  "created_at" : "2011-10-02 14:46:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120468206480658432",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 120468206480658432,
  "created_at" : "2011-10-02 12:00:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 3, 10 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120389272879628288",
  "text" : "RT @rpdexp: \u304A\u304B\u3057\u3044\u2026\u2026 \u5E30\u308B\u3068\u304D\u306B\u306F\u81EA\u8EE2\u8ECA\u306E\u30AB\u30B4\u306B\u306FPS\u30B3\u30F3\u30C8\u30ED\u30FC\u30E9\u304C\u5165\u3063\u3066\u3044\u308B\u306F\u305A\u3060\u3063\u305F\u306E\u306B\u725B\u8089\u304C\u5165\u3063\u3066\u308B\u2026\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120383645851725824",
    "text" : "\u304A\u304B\u3057\u3044\u2026\u2026 \u5E30\u308B\u3068\u304D\u306B\u306F\u81EA\u8EE2\u8ECA\u306E\u30AB\u30B4\u306B\u306FPS\u30B3\u30F3\u30C8\u30ED\u30FC\u30E9\u304C\u5165\u3063\u3066\u3044\u308B\u306F\u305A\u3060\u3063\u305F\u306E\u306B\u725B\u8089\u304C\u5165\u3063\u3066\u308B\u2026\u2026",
    "id" : 120383645851725824,
    "created_at" : "2011-10-02 06:24:32 +0000",
    "user" : {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "protected" : false,
      "id_str" : "141811283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583276832234999810\/sa3_ZPQ4_normal.jpg",
      "id" : 141811283,
      "verified" : false
    }
  },
  "id" : 120389272879628288,
  "created_at" : "2011-10-02 06:46:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "indices" : [ 3, 13 ],
      "id_str" : "102325414",
      "id" : 102325414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120360784739057665",
  "text" : "RT @blackVELU: \u3082\u3057\u304B\u3057\u3066\uFF1A\u660E\u65E5\u304B\u3089\u8B1B\u7FA9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120360209330880512",
    "text" : "\u3082\u3057\u304B\u3057\u3066\uFF1A\u660E\u65E5\u304B\u3089\u8B1B\u7FA9",
    "id" : 120360209330880512,
    "created_at" : "2011-10-02 04:51:24 +0000",
    "user" : {
      "name" : "\u7D44\u307F\u8FBC\u307E\u308C\u7CFB",
      "screen_name" : "blackVELU",
      "protected" : false,
      "id_str" : "102325414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450656382325248000\/cnubEZOd_normal.jpeg",
      "id" : 102325414,
      "verified" : false
    }
  },
  "id" : 120360784739057665,
  "created_at" : "2011-10-02 04:53:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/6TFpGxWj",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=masanikasu",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120321618449936384",
  "text" : "masanikasu\u304C\u3001\u79C1\u3092\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u308B\u8AB0\u304B(\u305D\u308C\u306F\u3042\u306A\u305F\u304B\u3082)\u3068\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u305D\u3046\u3067\u3059\u3002\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u306B\u306A\u308A\u307E\u305B\u3093\u304B\uFF1F http:\/\/t.co\/6TFpGxWj",
  "id" : 120321618449936384,
  "created_at" : "2011-10-02 02:18:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120105830614974464",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 120105830614974464,
  "created_at" : "2011-10-01 12:00:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u87C6",
      "screen_name" : "patho_logic",
      "indices" : [ 3, 15 ],
      "id_str" : "24158110",
      "id" : 24158110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120083637789147137",
  "text" : "RT @patho_logic: 0\u306F\u81EA\u7136\u6570\u6D3E \u3092\u91E3\u308B\u305F\u3081\u306E\u30CD\u30BF\u3068\u3057\u3066\u51C4\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twipple.jp\/\" rel=\"nofollow\"\u003E\u3064\u3044\u3063\u3077\u308B  for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120083023034200065",
    "text" : "0\u306F\u81EA\u7136\u6570\u6D3E \u3092\u91E3\u308B\u305F\u3081\u306E\u30CD\u30BF\u3068\u3057\u3066\u51C4\u3044\u3002",
    "id" : 120083023034200065,
    "created_at" : "2011-10-01 10:29:58 +0000",
    "user" : {
      "name" : "\u87C6",
      "screen_name" : "patho_logic",
      "protected" : true,
      "id_str" : "24158110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422378956\/gama_normal.jpg",
      "id" : 24158110,
      "verified" : false
    }
  },
  "id" : 120083637789147137,
  "created_at" : "2011-10-01 10:32:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u690D\u7530\u771F\u7406\u5B50",
      "screen_name" : "marikobabel",
      "indices" : [ 3, 15 ],
      "id_str" : "217148668",
      "id" : 217148668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120083616419168256",
  "text" : "RT @marikobabel: \u5197\u8AC7\u534A\u5206\u3067\u843D\u5408\u4EC1\u53F8\u3055\u3093\u306E\u300E\u6570\u7406\u795E\u5B66\u3092\u5B66\u3076\u4EBA\u306E\u305F\u3081\u306B\u300F\u3092\u53E4\u672C\u3067\u8CB7\u3063\u3066\u307F\u305F\u3051\u3069\u3001p.20\u3001\u306A\u3093\u3067\u81EA\u7136\u6570\u304C0\u304B\u3089\u59CB\u307E\u308B\u306E\u3088? \u3053\u306E\u4EBA\u4E2D\u5B66\u6570\u5B66\u3082\u308F\u304B\u3063\u3066\u306A\u3044\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119979063866703872",
    "text" : "\u5197\u8AC7\u534A\u5206\u3067\u843D\u5408\u4EC1\u53F8\u3055\u3093\u306E\u300E\u6570\u7406\u795E\u5B66\u3092\u5B66\u3076\u4EBA\u306E\u305F\u3081\u306B\u300F\u3092\u53E4\u672C\u3067\u8CB7\u3063\u3066\u307F\u305F\u3051\u3069\u3001p.20\u3001\u306A\u3093\u3067\u81EA\u7136\u6570\u304C0\u304B\u3089\u59CB\u307E\u308B\u306E\u3088? \u3053\u306E\u4EBA\u4E2D\u5B66\u6570\u5B66\u3082\u308F\u304B\u3063\u3066\u306A\u3044\u3002",
    "id" : 119979063866703872,
    "created_at" : "2011-10-01 03:36:52 +0000",
    "user" : {
      "name" : "\u690D\u7530\u771F\u7406\u5B50",
      "screen_name" : "marikobabel",
      "protected" : false,
      "id_str" : "217148668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523463755082911744\/fYAWqSjf_normal.png",
      "id" : 217148668,
      "verified" : false
    }
  },
  "id" : 120083616419168256,
  "created_at" : "2011-10-01 10:32:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307C\u3093\u3066\u3093\u3074\u3087\u3093(Bontenp\u00F8n)",
      "screen_name" : "y_bonten",
      "indices" : [ 3, 12 ],
      "id_str" : "86233299",
      "id" : 86233299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120042036492632064",
  "text" : "RT @y_bonten: \u6570\u5B66\u30AC\u30FC\u30EB\u306E\u300C\u77E5\u3089\u306A\u3044\u3075\u308A\u30B2\u30FC\u30E0\u300D\u3068\u3044\u3046\u8868\u73FE\u304C\u6709\u540D\u306B\u306A\u3063\u3066\u304D\u305F\u3002\u77E5\u3089\u306A\u3044\u3075\u308A\u3092\u6C7A\u3081\u8FBC\u3081\u305A\u3001\u4F7F\u3063\u3061\u3083\u3044\u3051\u306A\u3044\u3053\u3068\u3092\u4F7F\u3046\u5931\u6557\u3092\u7E70\u308A\u8FD4\u3059\u3046\u3061\u3001\u4ECA\u5EA6\u306F\u30CF\u30B7\u30B4\u3092\u5B8C\u5168\u306B\u5916\u3055\u308C\u3001\u4F55\u3092\u4F7F\u3046\u306E\u3082\u4E0D\u5B89\u306A\u611F\u899A\u306B\u9665\u308B\u3002\u305D\u3046\u3084\u3063\u3066\u6B63\u3057\u3044\u4F5C\u6CD5\u306E\u4E21\u5074\u3092\u5F80\u5FA9\u3057\u3066\u3044\u308B\u3068\u3001\u30D4\u30BF\u30C3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120029176756580352",
    "text" : "\u6570\u5B66\u30AC\u30FC\u30EB\u306E\u300C\u77E5\u3089\u306A\u3044\u3075\u308A\u30B2\u30FC\u30E0\u300D\u3068\u3044\u3046\u8868\u73FE\u304C\u6709\u540D\u306B\u306A\u3063\u3066\u304D\u305F\u3002\u77E5\u3089\u306A\u3044\u3075\u308A\u3092\u6C7A\u3081\u8FBC\u3081\u305A\u3001\u4F7F\u3063\u3061\u3083\u3044\u3051\u306A\u3044\u3053\u3068\u3092\u4F7F\u3046\u5931\u6557\u3092\u7E70\u308A\u8FD4\u3059\u3046\u3061\u3001\u4ECA\u5EA6\u306F\u30CF\u30B7\u30B4\u3092\u5B8C\u5168\u306B\u5916\u3055\u308C\u3001\u4F55\u3092\u4F7F\u3046\u306E\u3082\u4E0D\u5B89\u306A\u611F\u899A\u306B\u9665\u308B\u3002\u305D\u3046\u3084\u3063\u3066\u6B63\u3057\u3044\u4F5C\u6CD5\u306E\u4E21\u5074\u3092\u5F80\u5FA9\u3057\u3066\u3044\u308B\u3068\u3001\u30D4\u30BF\u30C3\u3068\u8DB3\u5834\u304C\u56FA\u307E\u308B\u6642\u304C\u6765\u308B\u3002\u62BD\u8C61\u306E\u77AC\u9593\u3002",
    "id" : 120029176756580352,
    "created_at" : "2011-10-01 06:56:00 +0000",
    "user" : {
      "name" : "\u307C\u3093\u3066\u3093\u3074\u3087\u3093(Bontenp\u00F8n)",
      "screen_name" : "y_bonten",
      "protected" : false,
      "id_str" : "86233299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450831342222049280\/uOo2dErR_normal.jpeg",
      "id" : 86233299,
      "verified" : false
    }
  },
  "id" : 120042036492632064,
  "created_at" : "2011-10-01 07:47:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mathpico",
      "screen_name" : "mathpico",
      "indices" : [ 3, 12 ],
      "id_str" : "151399293",
      "id" : 151399293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120032734222618626",
  "text" : "RT @mathpico: \u5B50\u4F9B\u305F\u3061\u3068\u904A\u3076\u3002\u300C\u4E00\u756A\u5C0F\u3055\u3044\u6570\u3092\u53EB\u3093\u3067\u307F\u3088\u3046\uFF01\u300D\u300C\u305B\u30FC\u306E\u3063\uFF01\u300D\u300C1\u300D\u300C1\u300D\u300C1\u300D\u300C0\u300D\u5C0F\u5B66\u751F\u306E\u5A18\u306F\u300C\u305D\u30FC\u3060\u3001\uFF10\u304C\u3042\u3063\u305F\u30FC\u3001\u5931\u6557\u3057\u305F\u301C\u300D\u3068\u8A00\u3063\u305F\u304C\u3001\uFF14\u624D\u606F\u5B50\u306F\u300C\uFF11\u3001\u7D76\u5BFE\uFF11\u300D\u3068\u8B72\u3089\u306A\u3044\u3002\u81EA\u7136\u6570\u306E\u4E16\u754C\u3092\u8131\u3059\u308B\u306E\u306F\u3001\u3084\u306F\u308A\u9AD8\u5EA6\u306A\u3053\u3068\u306A\u306E\u3060\u306D\u3047\u2026\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120030507542126592",
    "text" : "\u5B50\u4F9B\u305F\u3061\u3068\u904A\u3076\u3002\u300C\u4E00\u756A\u5C0F\u3055\u3044\u6570\u3092\u53EB\u3093\u3067\u307F\u3088\u3046\uFF01\u300D\u300C\u305B\u30FC\u306E\u3063\uFF01\u300D\u300C1\u300D\u300C1\u300D\u300C1\u300D\u300C0\u300D\u5C0F\u5B66\u751F\u306E\u5A18\u306F\u300C\u305D\u30FC\u3060\u3001\uFF10\u304C\u3042\u3063\u305F\u30FC\u3001\u5931\u6557\u3057\u305F\u301C\u300D\u3068\u8A00\u3063\u305F\u304C\u3001\uFF14\u624D\u606F\u5B50\u306F\u300C\uFF11\u3001\u7D76\u5BFE\uFF11\u300D\u3068\u8B72\u3089\u306A\u3044\u3002\u81EA\u7136\u6570\u306E\u4E16\u754C\u3092\u8131\u3059\u308B\u306E\u306F\u3001\u3084\u306F\u308A\u9AD8\u5EA6\u306A\u3053\u3068\u306A\u306E\u3060\u306D\u3047\u2026\u3002",
    "id" : 120030507542126592,
    "created_at" : "2011-10-01 07:01:17 +0000",
    "user" : {
      "name" : "mathpico",
      "screen_name" : "mathpico",
      "protected" : false,
      "id_str" : "151399293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1620449932\/____normal.png",
      "id" : 151399293,
      "verified" : false
    }
  },
  "id" : 120032734222618626,
  "created_at" : "2011-10-01 07:10:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120031094388178945",
  "text" : "\u6C17\u306B\u5165\u3089\u308C\u308B\u305F\u3081\u306B\u884C\u52D5\u3059\u308B\u306E\u306F\u672C\u672B\u8EE2\u5012\u3002\u666E\u901A\u306B\u884C\u52D5\u3057\u3066\u6C17\u306B\u5165\u3089\u308C\u308B\u306E\u304C\u4F55\u3088\u308A\u3060\u3088\u306D\u3002\u3075\u3041\u307C\u306E\u8A71\u3060\u3051\u3069\u3055\u3002",
  "id" : 120031094388178945,
  "created_at" : "2011-10-01 07:03:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304B\u3044\u304D\u3085\u3093",
      "screen_name" : "rpdexp",
      "indices" : [ 0, 7 ],
      "id_str" : "141811283",
      "id" : 141811283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120029715032588288",
  "geo" : { },
  "id_str" : "120030096030580736",
  "in_reply_to_user_id" : 141811283,
  "text" : "@rpdexp \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 120030096030580736,
  "in_reply_to_status_id" : 120029715032588288,
  "created_at" : "2011-10-01 06:59:39 +0000",
  "in_reply_to_screen_name" : "rpdexp",
  "in_reply_to_user_id_str" : "141811283",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.soicha.com\" rel=\"nofollow\"\u003ESOICHA\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3072\u308D",
      "screen_name" : "HIROMEER",
      "indices" : [ 3, 12 ],
      "id_str" : "240922609",
      "id" : 240922609
    }, {
      "name" : "\u3076\u3093\u305F\u3093@\u3055\u306B\u308F",
      "screen_name" : "kakogawa626",
      "indices" : [ 24, 36 ],
      "id_str" : "106298006",
      "id" : 106298006
    }, {
      "name" : "\u304F\u3089\u308C\uFF0F\u308C\u3089\u304F",
      "screen_name" : "reraku",
      "indices" : [ 45, 52 ],
      "id_str" : "25061763",
      "id" : 25061763
    }, {
      "name" : "\u2728\u79C1\u304C\u3046\u3044\u306B\u3083\u3093\u3060\u2728",
      "screen_name" : "ui_nyan",
      "indices" : [ 63, 71 ],
      "id_str" : "14052309",
      "id" : 14052309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120017173337997312",
  "text" : "RT @HIROMEER: \u304F\u305D\u308F\u308D\uFF57\uFF57 RT @kakogawa626: \u3059\u3054\u3044wRT @reraku: \u4E88\u8A00\u7684\u4E2D\uFF57 RT @ui_nyan: \u865A\u69CB\u65B0\u805E\u304C\u8B1D\u7F6A\u3057\u3066\u3044\u308B\u30FB\u30FB\u30FB\uFF01\uFF01\uFF01\uFF01 http:\/\/j.mp\/r1Tj8q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3076\u3093\u305F\u3093@\u3055\u306B\u308F",
        "screen_name" : "kakogawa626",
        "indices" : [ 10, 22 ],
        "id_str" : "106298006",
        "id" : 106298006
      }, {
        "name" : "\u304F\u3089\u308C\uFF0F\u308C\u3089\u304F",
        "screen_name" : "reraku",
        "indices" : [ 31, 38 ],
        "id_str" : "25061763",
        "id" : 25061763
      }, {
        "name" : "\u2728\u79C1\u304C\u3046\u3044\u306B\u3083\u3093\u3060\u2728",
        "screen_name" : "ui_nyan",
        "indices" : [ 49, 57 ],
        "id_str" : "14052309",
        "id" : 14052309
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120004784727138304",
    "text" : "\u304F\u305D\u308F\u308D\uFF57\uFF57 RT @kakogawa626: \u3059\u3054\u3044wRT @reraku: \u4E88\u8A00\u7684\u4E2D\uFF57 RT @ui_nyan: \u865A\u69CB\u65B0\u805E\u304C\u8B1D\u7F6A\u3057\u3066\u3044\u308B\u30FB\u30FB\u30FB\uFF01\uFF01\uFF01\uFF01 http:\/\/j.mp\/r1Tj8q",
    "id" : 120004784727138304,
    "created_at" : "2011-10-01 05:19:04 +0000",
    "user" : {
      "name" : "\u3072\u308D",
      "screen_name" : "HIROMEER",
      "protected" : false,
      "id_str" : "240922609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574436725335818240\/0d23fuI7_normal.jpeg",
      "id" : 240922609,
      "verified" : false
    }
  },
  "id" : 120017173337997312,
  "created_at" : "2011-10-01 06:08:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119985236271570944",
  "text" : "\u8D77\u5E8A\u3002",
  "id" : 119985236271570944,
  "created_at" : "2011-10-01 04:01:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]