Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9260617546338304",
  "geo" : { },
  "id_str" : "9261373166981120",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u305D\u3053\u306F\u5148\u8F29\u306B\u8B72\u308A\u307E\u3057\u3087\u3046\uFF57\u3042\u3068\u306F\uFF27\uFF14\u306E\u54B2\u304C\u500B\u4EBA\u7684\u306B\u306F\uFF27\uFF4F\uFF4F\uFF44\u3067\u3059\u304C",
  "id" : 9261373166981120,
  "in_reply_to_status_id" : 9260617546338304,
  "created_at" : "2010-11-29 15:04:18 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9259508983398400",
  "geo" : { },
  "id_str" : "9259668442456065",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u9AEA\u3092\u304A\u308D\u3057\u305F\u30B7\u30E3\u30ED\u306E\u304B\u308F\u3044\u3055\u306F\u7570\u5E38",
  "id" : 9259668442456065,
  "in_reply_to_status_id" : 9259508983398400,
  "created_at" : "2010-11-29 14:57:31 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9192789799608320",
  "geo" : { },
  "id_str" : "9218785114329089",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u9B5A\u306F\u5207\u308A\u8EAB\u3067\u6CF3\u3044\u3067\u308B\u3068\u601D\u3063\u3066\u308B\u4EBA\u9593\u304C\u3059\u3067\u306B\u3044\u308B\u3089\u3057\u3044\u304B\u3089\u306A",
  "id" : 9218785114329089,
  "in_reply_to_status_id" : 9192789799608320,
  "created_at" : "2010-11-29 12:15:04 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u308A\u30FC",
      "screen_name" : "Nacchoss",
      "indices" : [ 0, 9 ],
      "id_str" : "173685638",
      "id" : 173685638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9150006997024768",
  "geo" : { },
  "id_str" : "9151690489995266",
  "in_reply_to_user_id" : 173685638,
  "text" : "@Nacchoss \u4ECA\u66F4\u6C17\u3065\u3044\u305F\u304B\u30FC\uFF57\u672A\u5C65\u4FEE\u3070\u3063\u304B\u3060\u3088\uFF57",
  "id" : 9151690489995266,
  "in_reply_to_status_id" : 9150006997024768,
  "created_at" : "2010-11-29 07:48:27 +0000",
  "in_reply_to_screen_name" : "Nacchoss",
  "in_reply_to_user_id_str" : "173685638",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8786370784927745",
  "geo" : { },
  "id_str" : "8795842618068992",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u306A\u3093\u304B\u3001\u60AA\u3044\u3053\u3068\u3092\u3057\u305F\u6C17\u304C\u3057\u3066\u306A\u3089\u306A\u3044\uFF57\uFF57",
  "id" : 8795842618068992,
  "in_reply_to_status_id" : 8786370784927745,
  "created_at" : "2010-11-28 08:14:26 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8739727435894784",
  "text" : "\u8D77\u5E8A \u4ECA\u65E5\u306F\u30EC\u30DD\u30FC\u30C8\u3092\uFF12\u3064\u307B\u3069\u3067\u3063\u3061\u4E0A\u3052\u306D\u3070\uFF57",
  "id" : 8739727435894784,
  "created_at" : "2010-11-28 04:31:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8507549254946816",
  "geo" : { },
  "id_str" : "8508055822012416",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u30CB\u30B3\u52D5\u306F\u307E\u3060\u3060\u3068\u601D\u3044\u307E\u3059\u3002\u3044\u3084\u3001\u5909\u306A\u6C34\u7740\u306F\u4ED6\u306E\u30AD\u30E3\u30E9\u306E\u5439\u3063\u98DB\u3073\u5177\u5408\u306B\u6BD4\u3079\u305F\u3089\u8FD1\u4F3C\u3067\u7121\u8996\u3067\u304D\u308B\u304B\u3068\uFF57\u3042\u3068\u30B9\u30C8\u30FC\u30F3\u30EA\u30D0\u30FC\u3082\u6BD4\u8F03\u7684\u307E\u3068\u3082\u304B\u3068\u3002",
  "id" : 8508055822012416,
  "in_reply_to_status_id" : 8507549254946816,
  "created_at" : "2010-11-27 13:10:53 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "milkyhomes",
      "indices" : [ 71, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8506827746578432",
  "text" : "\u521D\u767B\u5834\u6642\u306B\u30B3\u30B3\u30ED\u3061\u3083\u3093\u3092\u7A81\u3063\u8FBC\u307F\u30AD\u30E3\u30E9\u3060\u3068\u601D\u3063\u305F\u81EA\u5206\u304C\u60C5\u3051\u306A\u3044\u3002\uFF27\uFF14\u306E\u305D\u306E\u4ED6\u3082\u81EA\u7531\u306B\u653E\u7F6E\u3059\u308B\u3060\u3051\u3060\u3057\u3000\u7D50\u5C40\u771F\u306B\u307E\u3068\u3082\u306A\u306E\u3063\u3066\u751F\u5F92\u4F1A\u9577\u306E\u307F\u304B\uFF57\u3000#milkyhomes",
  "id" : 8506827746578432,
  "created_at" : "2010-11-27 13:06:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "milkyhomes",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8504079873474560",
  "text" : "\u30B7\u30E3\u30ED\u304C\u300C\u304A\u723A\u3061\u3083\u3093\u304C\u6614\uFF5E\u300D\u3063\u3066\u8A00\u3044\u51FA\u3059\u3068\u7D4C\u9A13\u4E0A\u308D\u304F\u306A\u4E8B\u306B\u306A\u3089\u306A\u3044\u6C17\u304C\u2026#milkyhomes",
  "id" : 8504079873474560,
  "created_at" : "2010-11-27 12:55:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8500984854609920",
  "text" : "\u30B3\u30B3\u30ED\u3061\u3083\u3093\u81EA\u79F0\uFF29\uFF31\u306E\u6841\u304C\u56DE\u3092\u5897\u3059\u3054\u3068\u306B\u3059\u3054\u3044\u52E2\u3044\u3067\u5897\u3048\u3066\u308B\u4EF6\u306B\u3064\u3044\u3066#mikyhomes",
  "id" : 8500984854609920,
  "created_at" : "2010-11-27 12:42:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8494494257250304",
  "geo" : { },
  "id_str" : "8499045035151360",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3042\u308C\u3082\u4E00\u9577\u4E00\u77ED\u3060\u304B\u3089\u306A\u3041\u3002\u3042\u3093\u307E\u308A\u304A\u52E7\u3081\u3057\u306A\u3044\u3051\u3069\u3002",
  "id" : 8499045035151360,
  "in_reply_to_status_id" : 8494494257250304,
  "created_at" : "2010-11-27 12:35:04 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8492031957536768",
  "text" : "@koketomi \u7A79\u3068\u304A\u91D1\u304C\u964D\u3063\u3066\u3053\u306A\u3044\u304B\u306A\u3041\u30FB\u30FB\u30FB",
  "id" : 8492031957536768,
  "created_at" : "2010-11-27 12:07:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8220773202264064",
  "text" : "\u8AAD\u4E86\u3000\u5BDD\u307E\u3059",
  "id" : 8220773202264064,
  "created_at" : "2010-11-26 18:09:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8208466564874241",
  "text" : "\u307E\u3055\u304B\u306E\u30A8\u30D4\u30BD\u30FC\u30C9\u518D\u6765",
  "id" : 8208466564874241,
  "created_at" : "2010-11-26 17:20:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8192249712082944",
  "text" : "\u3072\u305F\u304E\u300C\u79C1\u3068\u7FBD\u5DDD\u3055\u3093\u304C\u624B\u3092\u7D44\u3081\u3070\u5343\u77F3\u3061\u3083\u3093\u3092\u5012\u305B\u308B\u306F\u305A\u306A\u306E\u3088\uFF01\u300D\n\u6226\u5834\u30F6\u539F\u306B\u3042\u306E\u30E9\u30B9\u30DC\u30B9\u306F\u5012\u305B\u307E\u3044\uFF57",
  "id" : 8192249712082944,
  "created_at" : "2010-11-26 16:15:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8185056157765632",
  "text" : "\u305D\u3057\u3066\u4ECA\u304B\u3089\u9ED2\u3092\u8AAD\u3080",
  "id" : 8185056157765632,
  "created_at" : "2010-11-26 15:47:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8184982660976640",
  "text" : "\u3068\u3001\u809D\u5FC3\u306E\u7FBD\u5DDD\u3055\u3093\u306B\u8A00\u53CA\u3057\u306A\u3044\u306E\u3082\u3069\u3046\u306A\u306E\u304B\uFF57",
  "id" : 8184982660976640,
  "created_at" : "2010-11-26 15:47:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8184900100300801",
  "text" : "\u732B\u7269\u8A9E \u9ED2\u3000\u8AAD\u4E86 \u6642\u7CFB\u5217\u7684\u306B\u64AB\u5B50\u304C\u51FA\u3066\u6765\u306A\u3044\u306E\u306F\u3068\u3082\u304B\u304F\u3001\u5FCD\u91CE\uFF08\u30E1\u30E1\uFF09\u306F\u3044\u3044\u30AD\u30E3\u30E9\u3057\u3066\u305F\u306A\u3041\u3002\u8A00\u3044\u3059\u304E\u3068\u3044\u3063\u3066\u3082\u904E\u8A00\u3067\u306F\u306A\u3044\u3002",
  "id" : 8184900100300801,
  "created_at" : "2010-11-26 15:46:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8154356746551296",
  "text" : "\u5B87\u5B99\u3092\u6CBB\u3081\u308B\u3068\u66F8\u3044\u3066\u5B87\u6CBB\u306A\u3046\u3002",
  "id" : 8154356746551296,
  "created_at" : "2010-11-26 13:45:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8154203163725824",
  "text" : "\u3042\u308C\u30FC\u6700\u65B0\u30C4\u30A4\u30FC\u30C8\uFF13\u65E5\u524D\u304B\u30FC",
  "id" : 8154203163725824,
  "created_at" : "2010-11-26 13:44:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6871183404302336",
  "text" : "\u643A\u5E2F\u3060\u304C\u30EA\u30F3\u30B7\u30E3\u30F3\u3067\u5927\u4E09\u5143ktkr",
  "id" : 6871183404302336,
  "created_at" : "2010-11-23 00:46:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6692897227280384",
  "text" : "\u2026\u524D\u304B\u3089\u601D\u3063\u3066\u306F\u3044\u305F\u304C\u3053\u3046\u3044\u3046\u307E\u3068\u3081\u3066\u3064\u3076\u3084\u304F\u306E\u3063\u3066\u3069\u3046\u306A\u3093\u3060\u308D\u3046\u306D\u3002",
  "id" : 6692897227280384,
  "created_at" : "2010-11-22 12:58:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6692617840500736",
  "text" : "\u3042\u30FC\u3001\u50B7\u7269\u8A9E\u3068\u507D\u7269\u8A9E\u306F\u60AA\u304F\u306A\u304B\u3063\u305F\u3002\u3053\u308C\u3082\u501F\u308A\u305F\u3051\u3069\u3082\u3002",
  "id" : 6692617840500736,
  "created_at" : "2010-11-22 12:56:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6692306610556928",
  "text" : "\u305F\u3060\u30A2\u30CB\u30E1\u5316\u3057\u305F\u6642\u306B\u6210\u529F\u3057\u3084\u3059\u3044\u6C17\u306F\u3059\u308B\u3002",
  "id" : 6692306610556928,
  "created_at" : "2010-11-22 12:55:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6691800559390720",
  "text" : "\u3053\u308C\u306F\u78BA\u5B9F\u306B\u504F\u898B\u3060\u3051\u3069\u3001\u3069\u30FC\u3082\u30E9\u30CE\u30D9\u306E\u985E\u306F\u8AAD\u8A9E\u306E\u300C\u4E00\u3064\u306E\u7269\u8A9E\u3092\u8FFD\u4F53\u9A13\u3057\u305F\u611F\u300D\u304C\u8584\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\u8AAD\u5F8C\u306B\u30B9\u30C3\u30AD\u30EA\u3059\u308B\u3057\u306A\u3044\u306F\u3068\u3082\u304B\u304F\u3002",
  "id" : 6691800559390720,
  "created_at" : "2010-11-22 12:53:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6690917301886977",
  "text" : "\u307E\u3041\u501F\u308A\u3066\u8AAD\u3093\u3067\u308B\u8A33\u3060\u3057\u4F55\u3068\u3082\u8A00\u3048\u3093\u306E\u3060\u3051\u3069\u3002",
  "id" : 6690917301886977,
  "created_at" : "2010-11-22 12:50:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6690758622973952",
  "text" : "\u306A\u30FC\u3093\u304B\u7269\u8DB3\u308A\u306A\u3044\u3093\u3060\u3088\u306A\u30FC\u3002\u8A71\u306E\u7B4B\u3082\u30AD\u30E3\u30E9\u3082\u7D42\u308F\u308A\u65B9\u3082\u4F0F\u7DDA\u3082\u3001\u8AAD\u307F\u7D42\u3048\u3066\u307F\u308C\u3070\u5370\u8C61\u8584\u3044\u3057\u3002",
  "id" : 6690758622973952,
  "created_at" : "2010-11-22 12:49:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6690227905105921",
  "text" : "\u9762\u767D\u304F\u306A\u304B\u3063\u305F\u8A33\u3058\u3083\u306A\u3044\u3051\u3069\u3001\u4F55\u3068\u8A00\u3046\u304B\u30E9\u30A4\u30C8\u904E\u304E\u3002\uFF11\u6642\u9593\u307B\u3069\u3067\u8AAD\u4E86\u3002",
  "id" : 6690227905105921,
  "created_at" : "2010-11-22 12:47:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6689780821663744",
  "text" : "\u501F\u308A\u3066\u8AAD\u3093\u3060\u30E9\u30A4\u30C8\u30CE\u30D9\u30EB\u306E\u8A71\u3092\u3057\u3088\u3046\u3002",
  "id" : 6689780821663744,
  "created_at" : "2010-11-22 12:45:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6565264829190144",
  "text" : "\u540D\u53E4\u5C4B\u901A\u904E\u306A\u3046",
  "id" : 6565264829190144,
  "created_at" : "2010-11-22 04:30:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6332393011027968",
  "text" : "\u30C1\u30E3\u30F3\u30AB\u30F3\u30C9\u30E9\uFF11\u3067\u548C\u4E86\u3063\u305F\u3002\u30EA\u30A2\u30EB\u3067\u30C1\u30E3\u30F3\u30AB\u30F3\u306F\u521D\uFF01",
  "id" : 6332393011027968,
  "created_at" : "2010-11-21 13:05:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5876686943952896",
  "geo" : { },
  "id_str" : "5901479420362752",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u304A\uFF4B\u3067\u3059\u3002\u30E1\u30FC\u30EB\u304F\u3060\u3057\u3042",
  "id" : 5901479420362752,
  "in_reply_to_status_id" : 5876686943952896,
  "created_at" : "2010-11-20 08:33:16 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5635822569132032",
  "geo" : { },
  "id_str" : "5638241621381120",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u3042\u304D\u3089\u306FC\u30D1\u30FC\u30C8\u306E\u4F5C\u753B\u304C\u3072\u3069\u3059\u304E\u308B\uFF57\u9762\u767D\u3044\u304B\u3089\u3044\u3044\u3051\u3069\uFF57",
  "id" : 5638241621381120,
  "in_reply_to_status_id" : 5635822569132032,
  "created_at" : "2010-11-19 15:07:16 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5489884353536000",
  "text" : "\u3084\u3063\u3068\u5409\u7965\u5BFA \u6765\u308B\u5EA6\u5909\u308F\u3063\u3066\u3066\u5207\u306A\u3044",
  "id" : 5489884353536000,
  "created_at" : "2010-11-19 05:17:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5478685930946560",
  "text" : "\u304B\u304F\u3082\u901F\u3044\u3068\u4F53\u306F\u3068\u3082\u304B\u304F\u611F\u899A\u304C\u79FB\u52D5\u306B\u8FFD\u3044\u3064\u304B\u306A\u3044\u3002",
  "id" : 5478685930946560,
  "created_at" : "2010-11-19 04:33:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5429765557190657",
  "text" : "\u30A4\u30A4\u30C6\u30F3\u30AD\u30C0\u30CA\u30FC",
  "id" : 5429765557190657,
  "created_at" : "2010-11-19 01:18:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5275088261746688",
  "geo" : { },
  "id_str" : "5275396291428356",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u30EC\u30FC\u30EB\u30AC\u30F3\u307E\u3067\u306A\u3089\u51FA\u308B\uFF01\u30AB\u30E9\u30AA\u30B1\u884C\u304D\u307E\u3057\u3087\u3046\u3088\uFF01",
  "id" : 5275396291428356,
  "in_reply_to_status_id" : 5275088261746688,
  "created_at" : "2010-11-18 15:05:27 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5268541372633088",
  "geo" : { },
  "id_str" : "5268672624984064",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u4ECA\u304B\u3089\uFF57\uFF57\uFF57",
  "id" : 5268672624984064,
  "in_reply_to_status_id" : 5268541372633088,
  "created_at" : "2010-11-18 14:38:44 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5267693074649088",
  "geo" : { },
  "id_str" : "5267877665972225",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u30DE\u30B8\u3067\u98DF\u3079\u306B\u6765\u307E\u3059\uFF1F\uFF57\uFF57\uFF57",
  "id" : 5267877665972225,
  "in_reply_to_status_id" : 5267693074649088,
  "created_at" : "2010-11-18 14:35:34 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5267264550998016",
  "text" : "\u30D6\u30E9\u30C3\u30AF\u30B8\u30E3\u30C3\u30AF\u300C\u7A0E\u8FBC\u307F105\u5186\u306B\u306A\u308A\u307E\u30FC\u3059\u300D",
  "id" : 5267264550998016,
  "created_at" : "2010-11-18 14:33:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5265337557712896",
  "geo" : { },
  "id_str" : "5266809615814656",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u5BB6\u306B\u3042\u308B\u306E\u306F\u8089\u3058\u3083\u304C\u4F4D\u3057\u304B\u306A\u3044\u3067\u3059\uFF1E\uFF1C",
  "id" : 5266809615814656,
  "in_reply_to_status_id" : 5265337557712896,
  "created_at" : "2010-11-18 14:31:19 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5266557802389504",
  "text" : "\u3042\u308B\u30AB\u30E9\u30AA\u30B1\u96C6\u5408\uFF23\u306F\uFF23=\u007B\u03A6\u007D\u3067\u5B9A\u7FA9\u3055\u308C\u308B\u3002 \u3060\u3063\u3066\u7A7A\u30AA\u30B1\u3060\u3082\u306E\u3002",
  "id" : 5266557802389504,
  "created_at" : "2010-11-18 14:30:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5265298609405952",
  "text" : "\u53CB\u4EBA\u300C\u5C71\u624B\u7DDA\u3063\u3066\u5185\u56DE\u308A\u3068\u5916\u56DE\u308A\u3067\u5024\u6BB5\u9055\u3046\u3093\uFF1F\u300D\u4FFA\u300C\u7A4D\u5206\u3068\u4E00\u7DD2\u3067\u7AEF\u70B9\u4F9D\u5B58\u3060\u3088\u300D",
  "id" : 5265298609405952,
  "created_at" : "2010-11-18 14:25:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5263682707652609",
  "text" : "\u3064\u304B\u767D\u7C73\u4EE5\u524D\u306B\u6628\u65E5\u5927\u91CF\u306B\u4F5C\u3063\u305F\u8089\u3058\u3083\u304C\u3092\u6D88\u8CBB\u3057\u304D\u308C\u308B\u306E\u304B\u306A\uFF57",
  "id" : 5263682707652609,
  "created_at" : "2010-11-18 14:18:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5263469104340992",
  "text" : "\u304A\u5915\u98EF\u306E\u767D\u7C73\u3092\u708A\u3044\u3066\u304A\u3044\u3066\u304F\u308C\u308B\u5C0F\u9593\u4F7F\u3044\u304C\u6B32\u3057\u3044\u3002",
  "id" : 5263469104340992,
  "created_at" : "2010-11-18 14:18:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5263036046647296",
  "text" : "\u5B87\u6CBB\u306A\u3046\u3002\u65E5\u4ED8\u5909\u308F\u308B\u524D\u306B\u5E30\u308C\u308B\u304B\u3057\u3089\u3093\u3002\u3053\u3053\u307E\u3067\u6012\u6D9B\u306E\u6728\u66DC\u3084\u3063\u305F\u308F\u3002",
  "id" : 5263036046647296,
  "created_at" : "2010-11-18 14:16:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "5206154200227840",
  "geo" : { },
  "id_str" : "5207501087711233",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u3053\u306E\u30C4\u30A4\u30FC\u30C8\u3082\u6C17\u306B\u3057\u306A\u3044\u3053\u3068\u306B\u3057\u3088\u3046",
  "id" : 5207501087711233,
  "in_reply_to_status_id" : 5206154200227840,
  "created_at" : "2010-11-18 10:35:39 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5078786781478912",
  "text" : "\u4ECA\u65E5\u304C\u5C71\u3060\u3002\u30CF\u30FC\u30C9\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB\uFF01",
  "id" : 5078786781478912,
  "created_at" : "2010-11-18 02:04:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5036962234765312",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro\u3000\u554F\u984C\u3067\u3059\u3002\u30A4\u30A8\u30B9\u304B\u30CE\u30FC\u3067\u7B54\u3048\u3066\u304F\u3060\u3055\u3044\u3002\u300C\u3053\u306E\u554F\u984C\u306E\u7B54\u3048\u306F\u30CE\u30FC\u3067\u3042\u308B\u300D",
  "id" : 5036962234765312,
  "created_at" : "2010-11-17 23:18:00 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4924742133882880",
  "text" : "\u30E8\u30B9\u30AC\u30CE\u30BD\u30E9\u4E03\u8A71\u3002\u6700\u5F8C\u306E\u7A79\u6016\u3044\u308F\u30FC\u3002",
  "id" : 4924742133882880,
  "created_at" : "2010-11-17 15:52:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4882147903012864",
  "text" : "\u2033\u4E00\u2033\u756A\u545F\u3044\u3066\u308B\u306E\u304C\u300C\u4E00\u300D\u3063\u3066\u306E\u3082\u76AE\u8089\u306A\u8A71\u306D\uFF57",
  "id" : 4882147903012864,
  "created_at" : "2010-11-17 13:02:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nenga2011",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4881869657079810",
  "text" : "end313124\u304C2010\u5E74\u3067\u4E00\u756A\u3064\u3076\u3084\u3044\u305F\u6587\u5B57\u306F\u300C\u4E00\u300D\u300234\u6587\u5B57\u3064\u3076\u3084\u3044\u3066\u307E\u3059\u3002\n\u305D\u3093\u306A\u3042\u306A\u305F\u306E2011\u5E74\u306F\u3001\u30C1\u30E3\u30EC\u30F3\u30B8\u306E\u5E74\u3067\u3059\u3002\u65B0\u3057\u3044\u3053\u3068\u3082\u5C3B\u8FBC\u307F\u305B\u305A\u306B\u3084\u308C\u3070\u3044\u3044\u7D50\u679C\u304C\u30FB\u30FBhttp:\/\/bit.ly\/ynhito #nenga2011",
  "id" : 4881869657079810,
  "created_at" : "2010-11-17 13:01:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4833059576741888",
  "text" : "\u5727\u529B\u934B\u8003\u3048\u305F\u3084\u3064\u5929\u624D\u3060\uFF01\u3084\u3063\u3066\u308B\u3053\u3068\u306F\u305F\u3060\u306E\u71B1\u529B\u5B66\u3060\u3051\u3069\u3001\u3053\u3053\u307E\u3067\u4FBF\u5229\u306A\u8ABF\u7406\u5668\u5177\u306F\u3042\u3093\u307E\u308A\u3042\u308B\u307E\u3044\u3002",
  "id" : 4833059576741888,
  "created_at" : "2010-11-17 09:47:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4730400542826497",
  "text" : "\u5ECA\u4E0B\u5BD2\u3044 \u65E9\u304F\u6B21\u306E\u6559\u5BA4\u3042\u304B\u306A\u3044\u304B\u306A\u30FC",
  "id" : 4730400542826497,
  "created_at" : "2010-11-17 02:59:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4555171833053186",
  "text" : "\u70AC\u71F5\u3067\u30A2\u30A4\u30B9\u3000\u3053\u308C\u306F\u8D05\u6CA2\u306A\u632F\u308B\u821E\u3044\uFF57\uFF57",
  "id" : 4555171833053186,
  "created_at" : "2010-11-16 15:23:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4553122265440256",
  "geo" : { },
  "id_str" : "4553540580147200",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5148\u8F29\u3063\u3066\u6D45\u6CBC\u5148\u8F29\u306D\uFF57\u304A\u3084\u3059\u307F\u306A\u3057\u3042",
  "id" : 4553540580147200,
  "in_reply_to_status_id" : 4553122265440256,
  "created_at" : "2010-11-16 15:17:03 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4549751135535104",
  "geo" : { },
  "id_str" : "4550289193435136",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u30ED\u30FC\u30DE\u5B57\u5909\u63DB\u3057\u3066\u306A\u3044\uFF57\uFF57\uFF57\uFF57",
  "id" : 4550289193435136,
  "in_reply_to_status_id" : 4549751135535104,
  "created_at" : "2010-11-16 15:04:08 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4548451907936256",
  "geo" : { },
  "id_str" : "4548846327697408",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3055\u3080\u3044\uFF1F\uFF57\uFF57\uFF57\uFF57\u3000\u3000\nSAMUI\u2192ASUMI\u3000\u3063\u3066\u5148\u8F29\u304C\u8A00\u3063\u3066\u305F\u3002\u8A00\u3044\u51FA\u3057\u305F\u306E\u4FFA\u3060\u3051\u3069\uFF57\uFF57\uFF57",
  "id" : 4548846327697408,
  "in_reply_to_status_id" : 4548451907936256,
  "created_at" : "2010-11-16 14:58:24 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4548345762684928",
  "text" : "\u904B\u547D\u7684\u306A\u8A00\u8449\u904A\u3073\u3092\u767A\u898B\u3057\u305F\u3002ISIBASI\u3092\u53CD\u5BFE\u306B\u3059\u308B\u2192ISABISI\uFF08\u3044\u3055\u3073\u3057\uFF09\u2192\u300C\u3044\u3055\u3073\u3057\u300D\u3092\u643A\u5E2F\u3067\u5165\u529B\u3057\u3066\u30ED\u30FC\u30DE\u5B57\u5909\u63DB\u3059\u308B\u3002\u305D\u308C\u3092\u9006\u304B\u3089\u8AAD\u3080\u3068\u2026\u2026\uFF01",
  "id" : 4548345762684928,
  "created_at" : "2010-11-16 14:56:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4393968372551680",
  "text" : "\u4E00\u9650\u6570\u5B66\u3060\u3063\u305F\u306E\u306B\u306A\u3041\u2026\u30D5\u30A9\u30ED\u30FC\u9762\u5012orz",
  "id" : 4393968372551680,
  "created_at" : "2010-11-16 04:42:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4366030503673856",
  "text" : "\u4E00\u9650\u9045\u523B\u78BA\u5B9A\u3092\u78BA\u8A8D\u3057\u3066\u304B\u3089\u8EFD\u3084\u304B\u306B\u4E8C\u5EA6\u5BDD\u3002\u4ECA\u306B\u81F3\u308B\u3002",
  "id" : 4366030503673856,
  "created_at" : "2010-11-16 02:51:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4204684914982913",
  "geo" : { },
  "id_str" : "4205677564133377",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u305D\u306E\u767A\u60F3\u306F\u7121\u304B\u3063\u305F\uFF57\uFF57",
  "id" : 4205677564133377,
  "in_reply_to_status_id" : 4204684914982913,
  "created_at" : "2010-11-15 16:14:46 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4202078117302272",
  "text" : "\u3042\u30FC\u4ECA\u65E5\uFF11\u9650\u306A\u306E\u306B\u306A\u3041\u2026\u3082\u3046\uFF11\u6642",
  "id" : 4202078117302272,
  "created_at" : "2010-11-15 16:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4148494495391744",
  "text" : "\u4E2D\u4E8C\u306E\u4E00\u6B21\u95A2\u6570\u2026\u7269\u8DB3\u308A\u306A\u3044\u3002\u81EA\u5206\u306E\u8907\u7D20\u95A2\u6570\u2026\u529B\u8DB3\u308A\u306A\u3044\u3002",
  "id" : 4148494495391744,
  "created_at" : "2010-11-15 12:27:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4083864234369024",
  "text" : "\u4ECA\u9031\u6728\u66DC\uFF14\u9650\u307E\u3067\u6388\u696D\u2192\u30D0\u30A4\u30C8\uFF11\uFF17:\uFF10\uFF10\uFF5E\uFF19\uFF10\u5206\u2192\u30D0\u30A4\u30C8'\uFF12\uFF10\uFF1A\uFF13\uFF10\uFF5E\uFF11\uFF12\uFF10\u5206\u2192\u591C\u884C\u30D0\u30B9\u3067\u5E30\u7701\u306B\u306A\u308B\u304B\u3082\u3002\u9B3C\u755C\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB\uFF57\uFF57",
  "id" : 4083864234369024,
  "created_at" : "2010-11-15 08:10:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3816257811914752",
  "geo" : { },
  "id_str" : "3816734494560256",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u305D\u308C\u306B\u5439\u3044\u305F\uFF57",
  "id" : 3816734494560256,
  "in_reply_to_status_id" : 3816257811914752,
  "created_at" : "2010-11-14 14:29:15 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3810871444774912",
  "text" : "http:\/\/news.nicovideo.jp\/watch\/nw5416 \u3053\u306E\u6388\u696D\u3068\u308C\u3070\u3088\u304B\u3063\u305F\uFF57\uFF57\uFF57",
  "id" : 3810871444774912,
  "created_at" : "2010-11-14 14:05:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3778939486998529",
  "text" : "\u964D\u308A\u305D\u3053\u306A\u3063\u305F\u6C17\u304C\u3057\u305F\u3089\u5927\u4E08\u592B\u3060\u3063\u305F\u3002",
  "id" : 3778939486998529,
  "created_at" : "2010-11-14 11:59:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3728139377184768",
  "text" : "\u5B87\u6CBB\u306A\u3046\u3001\u3058\u3064\u306F\u901A\u904E\u3002",
  "id" : 3728139377184768,
  "created_at" : "2010-11-14 08:37:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3474128212336640",
  "text" : "1mol\u306E\u6C34\u304C\uFF11\uFF10\uFF10\u2103\u3001\uFF11bar(\u305F\u3076\u3093\uFF11\u6C17\u5727)\u3000\u3067\u84B8\u767A\u3059\u308B\u3068\u304D\u5916\u754C\u3078\u306E\u4ED5\u4E8B\uFF08\u30FC\uFF57\uFF09\u5185\u90E8\u30A8\u30CD\u30EB\u30AE\u30FC\u5909\u5316\uFF08\u0394U\uFF09\u3000\u30A8\u30F3\u30BF\u30EB\u30D4\u30FC\u5909\u5316\uFF08\u0394H\uFF09\u3092\u6C42\u3081\u3088\u3002\u306A\u304A\u6C34\u306E\u84B8\u767A\u71B1\u3092\uFF14\uFF10\uFF0E\uFF17KJ\/mol \u6C34\u84B8\u6C17\u3092\u7406\u60F3\u6C17\u4F53\u3001\u6C34\u84B8\u6C17\u306B\u5BFE\u3059\u308B\u6C34\u306E\u4F53\u7A4D\u3092\u7121\u8996\u3057\u3066\u3088\u3044\u3002\u307E\u305FR=\uFF18\uFF0E\uFF13\uFF11\uFF14J\/K\u30FBmol\u3000\u89E3\u3051\u306C",
  "id" : 3474128212336640,
  "created_at" : "2010-11-13 15:47:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3418789060284416",
  "geo" : { },
  "id_str" : "3427959926951936",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5FC5\u8981\u30DA\u30FC\u30B8\u3060\u3051\u5207\u308A\u629C\u304F\u306E\u304C\u5B89\u5B9A\u3060\u3063\u305F\u3002",
  "id" : 3427959926951936,
  "in_reply_to_status_id" : 3418789060284416,
  "created_at" : "2010-11-13 12:44:23 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3361626510065664",
  "text" : "\u5DE5\u5B66\u90E8\u306E\u5B66\u90E8\u9577\u304C\u300C\u5BB6\u3067\u4E00\u4EBA\u3067PC\u3059\u308B\u306A\u3089\u53CB\u9054\u3068\u9EBB\u96C0\u3067\u3082\u3044\u3044\u304B\u3089\u30B3\u30DF\u30E5\u30CB\u30B1\u30FC\u30B7\u30E7\u30F3\u4E0B\u624B\u3092\u76F4\u3057\u3066\u307B\u3057\u3044\u300D\u3063\u3066\u767A\u8A00\u3057\u305F\u3053\u3068\u304C\u3042\u308B\u3068\u304B\u306A\u3044\u3068\u304B\u3002\u30A4\u30A4\u30CF\u30CA\u30B7\u30C0\u30CA\u30FC\u3002",
  "id" : 3361626510065664,
  "created_at" : "2010-11-13 08:20:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3321596160770048",
  "text" : "\u30A4\u30F3\u30C7\u30C3\u30AF\u30B9\u76DB\u308A\u4E0A\u304C\u3063\u3066\u304D\u305F\u306A\u30FC\u3001\u5EA7\u6A19\u306E\u4EBA\u3082\u4E00\u901A\u3055\u3093\u3082\u51FA\u3066\u304D\u305F\u3057\uFF57",
  "id" : 3321596160770048,
  "created_at" : "2010-11-13 05:41:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "6V\u30CF\u30EB\u30C8\u30DE\u30F3",
      "screen_name" : "kazma0318",
      "indices" : [ 0, 10 ],
      "id_str" : "181342377",
      "id" : 181342377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3076298113032192",
  "geo" : { },
  "id_str" : "3077867961323520",
  "in_reply_to_user_id" : 181342377,
  "text" : "@kazma0318 \u6D6A\u6F2B\u3067\u3057\u305F\uFF57\uFF57",
  "id" : 3077867961323520,
  "in_reply_to_status_id" : 3076298113032192,
  "created_at" : "2010-11-12 13:33:15 +0000",
  "in_reply_to_screen_name" : "kazma0318",
  "in_reply_to_user_id_str" : "181342377",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2956097560252416",
  "text" : "\u6DE1\u8DEF\u306A\u3046\u3002\u3044\u3064\u305E\u3084\u306E\u82F1\u691C\u306E\u4E8C\u6B21\u8A66\u9A13\u4F1A\u5834\u306B\u9078\u3093\u3060\u3063\u3051\uFF1F\u3042\u308C\u306F\u59EB\u8DEF\u3060\u3063\u305F\u304B\u306A\uFF1F",
  "id" : 2956097560252416,
  "created_at" : "2010-11-12 05:29:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2348079990706176",
  "geo" : { },
  "id_str" : "2349664108023808",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30A2\u30DE\u30AC\u30DF\u9762\u767D\u3044\u30FC\uFF1F\u3063\u3066\u304A\u524D\u306B\u805E\u3044\u305F\u3089\u9762\u767D\u3044\u3063\u3066\u3044\u3046\u3060\u308D\u3046\u304C\uFF57\u3000\u500B\u4EBA\u7684\u306B\u306F\u5E3D\u5B50\u306A\u3044\u307B\u3046\u304C\u3044\u3044\u304B\u3089\u8B72\u308A\u307E\u3059\uFF57\uFF57",
  "id" : 2349664108023808,
  "in_reply_to_status_id" : 2348079990706176,
  "created_at" : "2010-11-10 13:19:38 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2347624673845248",
  "text" : "\u4ED9\u8C37\u3088\u308A\u5343\u77F3\u3000\u3067\u3082\u8AB0\u3082\u6C17\u306B\u3057\u306A\u3044\u3002\u6052\u5E38\u7684\u8AB0\u3082\u6C17\u306B\u3057\u306A\u3044\u72B6\u614B\u3002",
  "id" : 2347624673845248,
  "created_at" : "2010-11-10 13:11:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2332737247649792",
  "text" : "\u5148\u6597\u753A\u308F\u305A\u30022\uFF0C3\u5E74\u3076\u308A\u306B\u3059\u304D\u713C\u304D\u3092\u98DF\u3079\u305F\u6C17\u304C\u3059\u308B\u3002",
  "id" : 2332737247649792,
  "created_at" : "2010-11-10 12:12:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2234721719296000",
  "text" : "\u5317\u90E8\u9060\u3059\u304E\u3002\u5BD2\u3059\u304E\u3002\u3001\u5317\u3060\u304B\u3089\u3068\u304B\u3058\u3083\u306A\u3044\u3051\u308C\u3069\u3002",
  "id" : 2234721719296000,
  "created_at" : "2010-11-10 05:42:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1480793150988289",
  "text" : "\u3055\u3080\u3044\u3002\u5BA4\u5185\u306A\u3093\u3060\u3051\u3069\u306A\u3002",
  "id" : 1480793150988289,
  "created_at" : "2010-11-08 03:47:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1254827724115968",
  "text" : "\u5B9F\u969B\u306B\u98DF\u3079\u308B\u4E8B\u306F\u307E\u305A\u306A\u3044\u3051\u3069\u306D\u30FC",
  "id" : 1254827724115968,
  "created_at" : "2010-11-07 12:49:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1254760090968064",
  "text" : "\u3068\u3044\u3046\u304BAngelBeats!\u306E\u9EBB\u5A46\u8C46\u8150\u3082\u305D\u3046\u3060\u3051\u3069\u3001\u3069\u3046\u3082\u898B\u305F\u3082\u306E\u8AAD\u3093\u3060\u3082\u306E\u304C\u98DF\u3079\u305F\u304F\u306A\u308B\u306A\u3041\u3002kanon\u306E\u305F\u3044\u3084\u304D\u3068\u304B\u3001\u9ED2\u57F7\u4E8B\u306E\u30DE\u30AB\u30ED\u30F3\u3068\u304B\u3002",
  "id" : 1254760090968064,
  "created_at" : "2010-11-07 12:48:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1254333068873729",
  "text" : "\u3042\u30FC\u3053\u3093\u306A\u6642\u9593\u306B\u507D\u7269\u8A9E\u3068\u304B\u8AAD\u3080\u3079\u304D\u3058\u3083\u306A\u304B\u3063\u305F\u3002\u30DF\u30B9\u30C9\u98DF\u3079\u305F\u304F\u3066\u4ED5\u65B9\u306A\u3044\u3002",
  "id" : 1254333068873729,
  "created_at" : "2010-11-07 12:47:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "937975131148288",
  "text" : "@koketomi \u304A\u3044\u3057\u3044\u30AA\u30C1\u3092\u3042\u308A\u304C\u3068\u3046\uFF57\uFF57",
  "id" : 937975131148288,
  "created_at" : "2010-11-06 15:50:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879919173210112",
  "geo" : { },
  "id_str" : "880488130547712",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u3042\u3093\u307E\u308A\u304A\u3044\u3057\u304F\u306A\u3044\u306E\u306F\u77E5\u3063\u3066\u308B\u3093\u3060\u3051\u3069\u306A\u30FC\u2190\u3000\u305D\u3046\u304B\u3001\u307E\u3041\u3042\u3068\u306F\u30B3\u30FC\u30D2\u30FC\u3068\u304B\u306B\u5165\u308C\u3066\u30BD\u30A4\u30E9\u30C6\u306B\u3057\u3066\u304A\u304F\u3053\u3068\u306B\u3059\u308B\u3088",
  "id" : 880488130547712,
  "in_reply_to_status_id" : 879919173210112,
  "created_at" : "2010-11-06 12:01:39 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877934000734208",
  "geo" : { },
  "id_str" : "878544146145280",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u7121\u8ABF\u6574\u306E\u3084\u3064\u8CB7\u3063\u3066\u304D\u3061\u3083\u3063\u305F\u3093\u3060\u304C\u3053\u308C\u3063\u3066\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u3093\u3060\u308D\u3046\u306D\uFF57",
  "id" : 878544146145280,
  "in_reply_to_status_id" : 877934000734208,
  "created_at" : "2010-11-06 11:53:55 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5927\u57A3\u51DC\u592A\u90CE",
      "screen_name" : "OhgakiRintaro",
      "indices" : [ 0, 14 ],
      "id_str" : "2228951886",
      "id" : 2228951886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "873681504964609",
  "geo" : { },
  "id_str" : "877513110716416",
  "in_reply_to_user_id" : 109537708,
  "text" : "@OhgakiRintaro \u524D\u304B\u3089\u805E\u3053\u3046\u3068\u601D\u3063\u3066\u3044\u305F\u304C\u7121\u8ABF\u6574\u306E\u8C46\u4E73\u3063\u3066\u305D\u306E\u307E\u307E\u98F2\u3080\u306E\u304B\uFF1F\u7802\u7CD6\u3068\u304B\u5165\u308C\u308B\u306E\u304B\uFF1F",
  "id" : 877513110716416,
  "in_reply_to_status_id" : 873681504964609,
  "created_at" : "2010-11-06 11:49:50 +0000",
  "in_reply_to_screen_name" : "yokuwaraou",
  "in_reply_to_user_id_str" : "109537708",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "871441507557376",
  "text" : "@koketomi \u5357\u3082\u304A\u8C46\u8150\u3082\u5C71\u306B\u3042\u3068\u4E00\u679A\u3065\u3064\u3002\u7D50\u69CB\u304D\u3064\u3044\u306D\uFF57",
  "id" : 871441507557376,
  "created_at" : "2010-11-06 11:25:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82D4\u5BCC",
      "screen_name" : "koketomi",
      "indices" : [ 0, 9 ],
      "id_str" : "2576974334",
      "id" : 2576974334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786993306927104",
  "text" : "@koketomi \uFF15\u9023\u4F11\uFF14\u65E5\u76EE\u3060\u3057\u75B2\u308C\u3066\u308B\u3093\u3060\u306A\u3001\u304D\u3063\u3068\u3002",
  "id" : 786993306927104,
  "created_at" : "2010-11-06 05:50:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762559003103232",
  "text" : "\u504F\u982D\u75DB \u5909\u982D\u75DB \u80A9\u51DD\u308A \u9996\u51DD\u308A \u306A\u3093\u3068\u304B\u306A\u3089\u306A\u3044\u3082\u306E\u304B",
  "id" : 762559003103232,
  "created_at" : "2010-11-06 04:13:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29673525026",
  "geo" : { },
  "id_str" : "29674012719",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u9AD8\u6821\u3067\u3001\u3057\u304B\u3082\u4E00\u7D44\u306E\u4E00\u90E8\u30E1\u30F3\u30D0\u30FC\u306E\u307F\u3067\u50AC\u3055\u308C\u308B\u3089\u3057\u3044\u300C\u5352\u696D\u751F\u3092\u56F2\u3080\u4F1A\u300D\u306E\u65E5\u53D6\u308A\u304C\u6587\u5316\u796D\u521D\u65E5\u2190\u5225\u306B\u53C2\u52A0\u3057\u306A\u3044\u3051\u3069\u3002\u3069\u3046\u305B\u884C\u3051\u306A\u3044\u3057\u884C\u304B\u306A\u3044\u304C\u4FFA\u3092\u5DEE\u3057\u7F6E\u3044\u3066\u3044\u3063\u305F\u3044\u8AB0\u3092\u56F2\u3080\u3064\u3082\u308A\u306A\u306E\u304B\u3002\u306A\u305C\u590F\u306E\u9593\u306B\u3084\u3089\u306A\u3044\u306E\u304B\u3002\u5C0F\u4E00\u6642\u9593\u554F\u3044\u8A70\u3081\u305F\u3044\u3002",
  "id" : 29674012719,
  "in_reply_to_status_id" : 29673525026,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29674462571",
  "text" : "3\u6B21\u5143\u306E\u4EBA\u9593\u306B\u304A\u3051\u308B\u30C4\u30F3\u30C7\u30EC\u306F\u3001\u6B63\u76F4\u8A00\u3063\u3066\u9B31\u9676\u3057\u3044\u3057\u95A2\u308F\u308A\u305F\u304F\u306A\u3044\u3068\u3055\u3048\u601D\u3046\u306E\u3060\u304C\u3001\u3053\u3068\u732B\u306B\u95A2\u3057\u3066\u306F\u4F8B\u5916\u3092\u8A8D\u3081\u3088\u3046\u3002\u547C\u3093\u3067\u3082\u6765\u306A\u3044\u304F\u305B\u306B\u3075\u3089\u3063\u3068\u5BC4\u3063\u3066\u304F\u308B\u2026\u305D\u3046\u3044\u3046\u732B\u3092\u3001\u79C1\u306F\u98FC\u3044\u305F\u3044\u3002",
  "id" : 29674462571,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29565982888",
  "text" : "\u3053\u305F\u3064\u3067\u934B\u3002\u79C1\u306F\u5E78\u305B\u306A\u65E5\u672C\u4EBA\u3067\u3042\u308B\u3002",
  "id" : 29565982888,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29581483991",
  "text" : "\u3053\u3053\u4E00\u9031\u95932\u5EA6\u307B\u3069\uFF21\uFF2D3\uFF0C4\u6642\u306B\u4E0B\u9D28\u795E\u793E\u3092\u901A\u3063\u3066\u3044\u308B\u304C\u732B\u30E9\u30FC\u30E1\u30F3\u306E\u6C17\u914D\u306A\u3057\u3002\u5B58\u5728\u3059\u308B\u306A\u3089\u98DF\u3079\u3066\u307F\u305F\u3044\u3082\u306E\u3060\u304C\u3002",
  "id" : 29581483991,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29354353085",
  "text" : "\u30DF\u30EB\u30AD\u30FC\u30DB\u30FC\u30E0\u30BA\u306E\u30AE\u30E3\u30B0\u30BB\u30F3\u30B9\u304C\u4EBA\u77E5\u3092\u8D85\u3048\u3066\u3044\u308B\uFF57\uFF57\uFF57\uFF57",
  "id" : 29354353085,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29364236600",
  "text" : "\u30BD\u30EA\u30C6\u30A3\u30A245\u79D2\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 29364236600,
  "created_at" : "2010-11-01 00:00:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]