Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450648378968244225",
  "text" : "@Kyo_Hiiragi \u308F\u304B\u308B",
  "id" : 450648378968244225,
  "created_at" : "2014-03-31 14:58:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450648278921527296",
  "text" : "@Kyo_Hiiragi \u3067\u306F\u305D\u3046\u8A00\u3044\u305F\u307E\u3048",
  "id" : 450648278921527296,
  "created_at" : "2014-03-31 14:58:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450648107093471232",
  "text" : "@Kyo_Hiiragi \u4ECA\u65E5\u3092\u6A5F\u306B\u30B3\u30FC\u30EB\u30C9\u30B9\u30EA\u30FC\u30D7\u3067\u3082\u3059\u308B\u306E\uFF1F",
  "id" : 450648107093471232,
  "created_at" : "2014-03-31 14:57:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450647613822361601",
  "geo" : { },
  "id_str" : "450647805594320896",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u99D0\u8F2A\u3057\u305F\u3084\u3064\u306F\u5168\u54E1\u7DB2\u8D70\u306B\u9001\u3063\u305F\u3001\u3068\u304B\u306A\u3089\u5F37\u3044\u4E3B\u5F35\u306A\u3093\u3058\u3083\u306A\u3044\u3067\u3059\u304B\u306D\uFF1F",
  "id" : 450647805594320896,
  "in_reply_to_status_id" : 450647613822361601,
  "created_at" : "2014-03-31 14:56:24 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450647625096654848",
  "text" : "\u4E3B\u5F35\u304C\u5F37\u3044\u306E\u3068\u5F37\u3044\u4E3B\u5F35\u3067\u3042\u308B\u306E\u306F\u3060\u3044\u3076\u9055\u3046",
  "id" : 450647625096654848,
  "created_at" : "2014-03-31 14:55:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450647078687887360",
  "geo" : { },
  "id_str" : "450647382942695424",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u4ECA\u65E5\u9053\u3092\u3042\u308B\u3044\u3066\u305F\u3089\n\u99D0\u8F2A\u7981\u6B62\u3067\u3059!!\n\u99D0\u8F2A\u7981\u6B62\u3067\u3059!!\n\u99D0\u8F2A\u7981\u6B62\u3067\u3059!!\n\u99D0\u8F2A\u7981\u6B62\u3067\u3059!!\n\u3063\u3066\u4E00\u679A\u306E\u7D19\u306B\u66F8\u3044\u3066\u3042\u3063\u3066\u4E3B\u5F35\u304C\u3064\u3088\u3044\u306A\u3041\u3068\u304A\u3082\u3044\u307E\u3057\u305F\u3002",
  "id" : 450647382942695424,
  "in_reply_to_status_id" : 450647078687887360,
  "created_at" : "2014-03-31 14:54:43 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450646934714212352",
  "text" : "\u304A\u524D\u3089\u305D\u3093\u306A\u306B\u5897\u7A0E\u5ACC\u306A\u3093\u304B\u3063\u3066\u611F\u3058\u3060",
  "id" : 450646934714212352,
  "created_at" : "2014-03-31 14:52:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450646536481800192",
  "geo" : { },
  "id_str" : "450646725988851712",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u30C4\u30A4\u30C3\u30BF\u30FC\u3057\u3066\u3066\u304B\u3064\u53D7\u304B\u3063\u305F\u4EBA\u304C\u5C11\u306A\u304F\u3068\u3082\u4E00\u4EBA\u5B58\u5728\u3059\u308B\u3001\u3068\u3044\u3046\u4E3B\u5F35\u306A\u3089\u5927\u4E08\u592B",
  "id" : 450646725988851712,
  "in_reply_to_status_id" : 450646536481800192,
  "created_at" : "2014-03-31 14:52:06 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450646537358438400",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 450646537358438400,
  "created_at" : "2014-03-31 14:51:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450646523529801728",
  "text" : "LINE\u306A\u3093\u3066\u53E4\u3044\u6280\u8853\u3088\u308A\u6700\u5148\u7AEF\u306EIRC\u3092\u4F7F\u304A\u3046",
  "id" : 450646523529801728,
  "created_at" : "2014-03-31 14:51:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450646396085878784",
  "text" : "\u305D\u306E\u4E0A\u3069\u3046\u304C\u3093\u3070\u3063\u3066\u3082\u7247\u9053\u3060",
  "id" : 450646396085878784,
  "created_at" : "2014-03-31 14:50:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450646222588485634",
  "geo" : { },
  "id_str" : "450646290309738496",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita 0\u304C\u4E00\u3064\u8DB3\u308A\u306A\u304B\u3063\u305F",
  "id" : 450646290309738496,
  "in_reply_to_status_id" : 450646222588485634,
  "created_at" : "2014-03-31 14:50:22 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3078\u3084\u304D\u305F",
      "screen_name" : "heyakita",
      "indices" : [ 0, 9 ],
      "id_str" : "100242979",
      "id" : 100242979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450645978761019393",
  "geo" : { },
  "id_str" : "450646116422258689",
  "in_reply_to_user_id" : 100242979,
  "text" : "@heyakita \u3053\u308C\u4EA4\u901A\u8CBB\u306F\u51FA\u306A\u3044\u306E\uFF1F(\u3054\u3054\u3054\u3054\u3054",
  "id" : 450646116422258689,
  "in_reply_to_status_id" : 450645978761019393,
  "created_at" : "2014-03-31 14:49:41 +0000",
  "in_reply_to_screen_name" : "heyakita",
  "in_reply_to_user_id_str" : "100242979",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450645706865274881",
  "text" : "\u73FE\u4EE3\u793E\u4F1A\u306B\u3064\u3044\u3066\u3044\u3051\u306A\u304F\u306A\u3063\u305F\u306E\u3067LINE\u306F\u3084\u3081\u3061\u3083\u3063\u305F\u3057\u591A\u5206\u518D\u958B\u3057\u306A\u3044",
  "id" : 450645706865274881,
  "created_at" : "2014-03-31 14:48:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450645339490373633",
  "text" : "\u4EBA\u6A29\u5BA3\u8A00",
  "id" : 450645339490373633,
  "created_at" : "2014-03-31 14:46:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450618210723704833",
  "geo" : { },
  "id_str" : "450618813294206977",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u6B7B\u306C\u306A\u3089\u5897\u7A0E\u524D\u306B\uFF01",
  "id" : 450618813294206977,
  "in_reply_to_status_id" : 450618210723704833,
  "created_at" : "2014-03-31 13:01:11 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450617695952572418",
  "text" : "\u5897\u7A0E\u524D\u306B\u6B7B\u306C\u4EBA\u3044\u306A\u3044\u306E",
  "id" : 450617695952572418,
  "created_at" : "2014-03-31 12:56:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450617485528551426",
  "text" : "\u307B\u3068\u3093\u3069\u306A\u3057\u306B\u306A\u3063\u305F",
  "id" : 450617485528551426,
  "created_at" : "2014-03-31 12:55:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450617423188619265",
  "text" : "\u4ECA\u306E\u4EE5\u5916\u306A\u3057",
  "id" : 450617423188619265,
  "created_at" : "2014-03-31 12:55:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450617375105089536",
  "text" : "\u304A\u98A8\u5442\u4E0A\u308A\u306E\u30A2\u30A4\u30B9\u3092\u611B\u3059\u308B",
  "id" : 450617375105089536,
  "created_at" : "2014-03-31 12:55:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450616011243286528",
  "text" : "\u4E0B\u624B\u3057\u305F\u3089\u8AF8\u4E8B\u60C5\u3067\u9759\u5CA1\u767A\u306B\u306A\u308B",
  "id" : 450616011243286528,
  "created_at" : "2014-03-31 12:50:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450615914132541440",
  "text" : "\u6771\u4EAC\u767A\u3001\u4ED9\u53F0\u7D4C\u7531\u3001\u798F\u5CA1\u7D4C\u7531\u306E\u4EAC\u90FD\u884C\u304D\uFF1F\u3084\u3070\u305D\u3046",
  "id" : 450615914132541440,
  "created_at" : "2014-03-31 12:49:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u68EE\u7530\u7D18\u5E73",
      "screen_name" : "kouheimorita",
      "indices" : [ 0, 13 ],
      "id_str" : "160230093",
      "id" : 160230093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450613110668161024",
  "geo" : { },
  "id_str" : "450615582224683009",
  "in_reply_to_user_id" : 160230093,
  "text" : "@kouheimorita \u50D5\u306B\u805E\u304F\u306E\u304C\u9593\u9055\u3063\u3066\u308B\u3068\u3044\u3046\u306E\u306F\u3069\u3046\u3067\u3057\u3087\u3046",
  "id" : 450615582224683009,
  "in_reply_to_status_id" : 450613110668161024,
  "created_at" : "2014-03-31 12:48:21 +0000",
  "in_reply_to_screen_name" : "kouheimorita",
  "in_reply_to_user_id_str" : "160230093",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450609878768185345",
  "text" : "\u5F7C\u306F\u6587\u7CFB\u306B\u884C\u304F\u307F\u305F\u3044\u306A\u306E\u30673C\u306E\u30C6\u30AD\u30B9\u30C8\u304C\u8ED2\u4E26\u307F\u7121\u99C4\u306B",
  "id" : 450609878768185345,
  "created_at" : "2014-03-31 12:25:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u3055\u3061\u3083\u3093",
      "screen_name" : "safour_1",
      "indices" : [ 0, 9 ],
      "id_str" : "397177453",
      "id" : 397177453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450608970537791488",
  "geo" : { },
  "id_str" : "450609314340687872",
  "in_reply_to_user_id" : 397177453,
  "text" : "@safour_1 \u5F7C\u306F\u304D\u3087\u3068\u3093\u3068\u3057\u3066\u307E\u3057\u305F\u306D\u3047\u3089",
  "id" : 450609314340687872,
  "in_reply_to_status_id" : 450608970537791488,
  "created_at" : "2014-03-31 12:23:27 +0000",
  "in_reply_to_screen_name" : "safour_1",
  "in_reply_to_user_id_str" : "397177453",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450608447482900480",
  "text" : "\u6709\u76CA\u306A\u4F1A\u8A71\u3092\u3059\u308B\u6C17\u304C\u306A\u3044\u5144\u3060\u3063\u305F",
  "id" : 450608447482900480,
  "created_at" : "2014-03-31 12:20:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450608365463281665",
  "text" : "\u5F1F\u300C\u6587\u7CFB\uFF1F\u7406\u7CFB\uFF1F\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u96E3\u3057\u3044\u8CEA\u554F\u3060\u300D\n\u5F1F\u300C\u3053\u308C\u308F\u304B\u3093\u306A\u3044\u3093\u3060\u3051\u3069\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u308F\u304B\u308B\u307E\u3067\u554F\u984C\u89E3\u3051\u3070\u308F\u304B\u308B\u300D",
  "id" : 450608365463281665,
  "created_at" : "2014-03-31 12:19:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7766\u6708\u30FE\uFF08\u30FB\u03C9\u30FB\u273F\uFF09\u30CE",
      "screen_name" : "owlmutsuki",
      "indices" : [ 0, 11 ],
      "id_str" : "283993563",
      "id" : 283993563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450607893725732864",
  "geo" : { },
  "id_str" : "450608085988433920",
  "in_reply_to_user_id" : 283993563,
  "text" : "@owlmutsuki \u7D20\u6575\u306A\u3084\u308A\u53D6\u308A\u3060",
  "id" : 450608085988433920,
  "in_reply_to_status_id" : 450607893725732864,
  "created_at" : "2014-03-31 12:18:34 +0000",
  "in_reply_to_screen_name" : "owlmutsuki",
  "in_reply_to_user_id_str" : "283993563",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450607435070193664",
  "text" : "\u6587\u5B66\u5C11\u5E74\u3068\u304B\u30C4\u30F3\u30C7\u30EC\u5E7C\u99B4\u67D3\u304F\u3089\u3044\u3044\u306A\u3044",
  "id" : 450607435070193664,
  "created_at" : "2014-03-31 12:15:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450607021457285120",
  "geo" : { },
  "id_str" : "450607070761336832",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u3042\u3044\u307E\u3057\u3087\u3046",
  "id" : 450607070761336832,
  "in_reply_to_status_id" : 450607021457285120,
  "created_at" : "2014-03-31 12:14:32 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450606561996451840",
  "text" : "\u30A2\u30A4\u30B9\u3092\u4E00\u65E5\u306B\u4E00\u3064\u304B\u4E8C\u3064\u98DF\u3079\u307E\u3059\u3002\u30A2\u30A4\u30B9\u3092\u4E8C\u65E5\u306B\u4E00\u5EA6\u4E09\u3064\u3065\u304F\u3089\u3044\u3065\u3064\u8CB7\u3044\u307E\u3059",
  "id" : 450606561996451840,
  "created_at" : "2014-03-31 12:12:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450606027247869952",
  "text" : "\u3044\u3044\u3068\u3082\u7D42\u4E86\u3001\u63A7\u3048\u3081\u306B\u8A00\u3063\u3066\u3069\u3046\u3067\u3082\u3044\u3044\u306A\u30FC",
  "id" : 450606027247869952,
  "created_at" : "2014-03-31 12:10:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450605308256075776",
  "text" : "\u9061\u3089\u308C",
  "id" : 450605308256075776,
  "created_at" : "2014-03-31 12:07:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450604363514253313",
  "text" : "\u5149",
  "id" : 450604363514253313,
  "created_at" : "2014-03-31 12:03:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "indices" : [ 3, 15 ],
      "id_str" : "295467216",
      "id" : 295467216
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hymathlogic\/status\/450292675573329920\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/WElxlwevca",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj_CzXzCMAABjMW.jpg",
      "id_str" : "450292675577524224",
      "id" : 450292675577524224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj_CzXzCMAABjMW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1125,
        "resize" : "fit",
        "w" : 803
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1125,
        "resize" : "fit",
        "w" : 803
      } ],
      "display_url" : "pic.twitter.com\/WElxlwevca"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450604337908023298",
  "text" : "RT @hymathlogic: Twitter\u6570\u5B66\u5F92\u304C\u3088\u304F\u4F7F\u3046\u30CF\u30F3\u30C9\u30B5\u30A4\u30F3 http:\/\/t.co\/WElxlwevca",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/hymathlogic\/status\/450292675573329920\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/WElxlwevca",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj_CzXzCMAABjMW.jpg",
        "id_str" : "450292675577524224",
        "id" : 450292675577524224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj_CzXzCMAABjMW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1125,
          "resize" : "fit",
          "w" : 803
        }, {
          "h" : 840,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1125,
          "resize" : "fit",
          "w" : 803
        } ],
        "display_url" : "pic.twitter.com\/WElxlwevca"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "450292675573329920",
    "text" : "Twitter\u6570\u5B66\u5F92\u304C\u3088\u304F\u4F7F\u3046\u30CF\u30F3\u30C9\u30B5\u30A4\u30F3 http:\/\/t.co\/WElxlwevca",
    "id" : 450292675573329920,
    "created_at" : "2014-03-30 15:25:14 +0000",
    "user" : {
      "name" : "\u5C71\u5143",
      "screen_name" : "hymathlogic",
      "protected" : false,
      "id_str" : "295467216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439420014165106688\/B9GEeIe7_normal.jpeg",
      "id" : 295467216,
      "verified" : false
    }
  },
  "id" : 450604337908023298,
  "created_at" : "2014-03-31 12:03:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450604221952303105",
  "text" : "\u4E45\u3005\u306B\u80A9\u3053\u308A\u982D\u75DB\u306E\u30B3\u30F3\u30DC\u306E\u4E88\u611F( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 450604221952303105,
  "created_at" : "2014-03-31 12:03:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3089@6\/28\u540D\u53E4\u5C4B",
      "screen_name" : "clarenabel",
      "indices" : [ 0, 11 ],
      "id_str" : "176926259",
      "id" : 176926259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450601432106823683",
  "geo" : { },
  "id_str" : "450601778048806912",
  "in_reply_to_user_id" : 176926259,
  "text" : "@clarenabel \u6D5C\u677E\u3067\u9C3B\u3092\u98DF\u3079\u305D\u3073\u308C\u305F\u306E\u304C\u5FC3\u6B8B\u308A\u3067\u3059\u3002\u3076\u3063\u3061\u3083\u3051\u7279\u306B\u89B3\u5149\u30B9\u30DD\u30C3\u30C8\u8ABF\u3079\u3066\u306A\u304B\u3063\u305F\u3093\u3067\u30A2\u30EC\u3067\u3057\u305F\u304C\u5B63\u7BC0\u3092\u9078\u3079\u3070\u304B\u306A\u308A\u697D\u3057\u3081\u308B\u3068\u601D\u3044\u307E\u3059\u3002\u51AC\u306F\u2026(\u5BDF\u3057)",
  "id" : 450601778048806912,
  "in_reply_to_status_id" : 450601432106823683,
  "created_at" : "2014-03-31 11:53:30 +0000",
  "in_reply_to_screen_name" : "clarenabel",
  "in_reply_to_user_id_str" : "176926259",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450601193232822272",
  "text" : "\u5B58\u5728\u3055\u3048\u5FD8\u308C\u3066\u3044\u305F",
  "id" : 450601193232822272,
  "created_at" : "2014-03-31 11:51:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450600713010167809",
  "text" : "\u5225\u308C\u969B\u306B\u3058\u3083\u3093\u3051\u3093\u3057\u3088\u3046\u3068\u3057\u3066\u304D\u305F\u304B\u3089\u4E00\u8E74\u3057\u305F",
  "id" : 450600713010167809,
  "created_at" : "2014-03-31 11:49:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 3, 13 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450600641845403648",
  "text" : "RT @wa_ta_si_: \u30A8\u30F3\u30C9\u3055\u3093\u3068\u306F\u91D1\u8F2A\u969B\u3058\u3083\u3093\u3051\u3093\u304C\u3067\u304D\u306A\u3044\u3053\u3068\u306B\u306A\u3063\u3066\u3044\u308B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "450600498509254656",
    "text" : "\u30A8\u30F3\u30C9\u3055\u3093\u3068\u306F\u91D1\u8F2A\u969B\u3058\u3083\u3093\u3051\u3093\u304C\u3067\u304D\u306A\u3044\u3053\u3068\u306B\u306A\u3063\u3066\u3044\u308B",
    "id" : 450600498509254656,
    "created_at" : "2014-03-31 11:48:25 +0000",
    "user" : {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "protected" : true,
      "id_str" : "230481483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459354943862751235\/ueed-jK7_normal.jpeg",
      "id" : 230481483,
      "verified" : false
    }
  },
  "id" : 450600641845403648,
  "created_at" : "2014-03-31 11:48:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3074\u3042\u306E\u3093",
      "screen_name" : "piano2683",
      "indices" : [ 0, 10 ],
      "id_str" : "441021193",
      "id" : 441021193
    }, {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 11, 27 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450600455609933826",
  "geo" : { },
  "id_str" : "450600568495415296",
  "in_reply_to_user_id" : 441021193,
  "text" : "@piano2683 @Jelly_in_a_tank \u3081\u3093\u3069\u3044\u304B\u3089\u5225\u3005\u306B\u4E8C\u56DE\u6765\u306A\u3055\u3044(?)",
  "id" : 450600568495415296,
  "in_reply_to_status_id" : 450600455609933826,
  "created_at" : "2014-03-31 11:48:41 +0000",
  "in_reply_to_screen_name" : "piano2683",
  "in_reply_to_user_id_str" : "441021193",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450600356490129408",
  "text" : "\u30B1\u30FC\u30AD\u826F\u3044\u306A\u30FC",
  "id" : 450600356490129408,
  "created_at" : "2014-03-31 11:47:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8D64\u72AC",
      "screen_name" : "akainu_6821",
      "indices" : [ 0, 12 ],
      "id_str" : "329606626",
      "id" : 329606626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450600171261272064",
  "geo" : { },
  "id_str" : "450600334176440321",
  "in_reply_to_user_id" : 329606626,
  "text" : "@akainu_6821 \u30CA\u30A4\u30B9\u30B1\u30FC\u30AD\uFF01",
  "id" : 450600334176440321,
  "in_reply_to_status_id" : 450600171261272064,
  "created_at" : "2014-03-31 11:47:46 +0000",
  "in_reply_to_screen_name" : "akainu_6821",
  "in_reply_to_user_id_str" : "329606626",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450599934555717632",
  "text" : "\u5408\u5BBF\u3048\u3093\u3069\u3055\u3093\u3061\u3063\u3066\u30A2\u30DB\u304B\u20262\uFF0C3\u4EBA\u3057\u304B\u6765\u308C\u306A\u3044\u305E",
  "id" : 450599934555717632,
  "created_at" : "2014-03-31 11:46:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450599548516188160",
  "geo" : { },
  "id_str" : "450599698940710912",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u30C4\u30A4\u30C3\u30BF\u30FC\u3084\u3063\u3066\u308B\u3068\u65E5\u672C\u5404\u5730\u306B\u5BBF\u304C\u767A\u751F\u3059\u308B\u3084\u3064\u3067\u3059\u306D",
  "id" : 450599698940710912,
  "in_reply_to_status_id" : 450599548516188160,
  "created_at" : "2014-03-31 11:45:14 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450599154541006848",
  "text" : "\u306A\u3093\u3060\u3053\u306E\u3048\u3093\u3069\u3055\u3093\u3061\u6CCA\u307E\u308A\u306B\u304F\u308BTL",
  "id" : 450599154541006848,
  "created_at" : "2014-03-31 11:43:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450599032826511360",
  "text" : "\u9014\u4E2D\uFF1F\u4EAC\u90FD\uFF1F\u798F\u5CA1\uFF1F\u3046\u30FC\u3093\u96E3\u3057\u304F\u3066\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u3084",
  "id" : 450599032826511360,
  "created_at" : "2014-03-31 11:42:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450597064691286018",
  "geo" : { },
  "id_str" : "450598908800933888",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u6050\u308D\u3057\u3044\u30EB\u30FC\u30C8\u3060",
  "id" : 450598908800933888,
  "in_reply_to_status_id" : 450597064691286018,
  "created_at" : "2014-03-31 11:42:06 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450596486695227392",
  "geo" : { },
  "id_str" : "450598688587390976",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \u3042\u308A\u305D\u3046(\u3053\u306A\u307F)",
  "id" : 450598688587390976,
  "in_reply_to_status_id" : 450596486695227392,
  "created_at" : "2014-03-31 11:41:13 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3089@6\/28\u540D\u53E4\u5C4B",
      "screen_name" : "clarenabel",
      "indices" : [ 0, 11 ],
      "id_str" : "176926259",
      "id" : 176926259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450596341136121856",
  "geo" : { },
  "id_str" : "450597413447688193",
  "in_reply_to_user_id" : 176926259,
  "text" : "@clarenabel \u8D70\u3063\u3066\u305F\u306E\u306F24\u6642\u9593\u304F\u3089\u3044",
  "id" : 450597413447688193,
  "in_reply_to_status_id" : 450596341136121856,
  "created_at" : "2014-03-31 11:36:09 +0000",
  "in_reply_to_screen_name" : "clarenabel",
  "in_reply_to_user_id_str" : "176926259",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450596230167400448",
  "text" : "\u4EAC\u90FD\u6771\u4EAC\u9593\u3092\u539F\u4ED8\u3067\u79FB\u52D5\u3057\u305F\u3057\u308F\u308A\u3068\u3069\u3053\u306B\u3067\u3082\u884C\u3051\u308B\u6C17\u306F\u3059\u308B\u3002[\u6642\u9593\u306F\u304B\u304B\u308B]",
  "id" : 450596230167400448,
  "created_at" : "2014-03-31 11:31:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450596031881674752",
  "text" : "\u304A\u3081\u3067\u305F\u3044\u8133\u307F\u305D\u3092\u6301\u3063\u3066\u751F\u307E\u308C\u305F\u304B\u3089\u5E78\u305B",
  "id" : 450596031881674752,
  "created_at" : "2014-03-31 11:30:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450595965162893312",
  "text" : "\u3048\uFF1F\u3048\u3093\u3069\u3055\u3093\u7D50\u69CB\u5E78\u305B\u3067\u3059\u3088\u3093\uFF1F",
  "id" : 450595965162893312,
  "created_at" : "2014-03-31 11:30:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450593733252096000",
  "text" : "\u30B3\u30D4\u30DA\u3058\u3083\u306A\u3044\uFF01\uFF01\u4FE1\u3058\u3066\uFF01\uFF01\u3067\u3082\u8ABF\u3079\u306A\u3044\u3067\uFF01\uFF01",
  "id" : 450593733252096000,
  "created_at" : "2014-03-31 11:21:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450592940377653248",
  "geo" : { },
  "id_str" : "450593209907818497",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u8584\u3005\u6C17\u3065\u3044\u3066\u305F\u304C\u2026\u30DE\u30B8\u304B\u2026",
  "id" : 450593209907818497,
  "in_reply_to_status_id" : 450592940377653248,
  "created_at" : "2014-03-31 11:19:27 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450593080526118913",
  "text" : "\u3044\u3084\u3001\u6492\u304B\u306A\u3044\u3051\u3069(\u771F\u9854)",
  "id" : 450593080526118913,
  "created_at" : "2014-03-31 11:18:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450593002193305600",
  "text" : "\u50D5\u306B\u30D3\u30E9\u9001\u3063\u3066\u304F\u308C\u305F\u3089\u6492\u304D\u307E\u3059(?)",
  "id" : 450593002193305600,
  "created_at" : "2014-03-31 11:18:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450592518564876288",
  "text" : "\u3059\u3046\u304C\u304F\u5F92\u306E\u4E2D\u306B\u306F\u4E00\u5B9A\u6570\u96C0\u58EB\u304C\u3044\u308B\u304B\u3089\u666E\u901A\u306B4\u4EBA\u4EE5\u4E0A\u96C6\u307E\u308A\u305D\u3046",
  "id" : 450592518564876288,
  "created_at" : "2014-03-31 11:16:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450592172337672193",
  "geo" : { },
  "id_str" : "450592288876417025",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u30CD\u30C3\u30C8\u3067\u306A\u3089\u662F\u975E\uFF01\u306A\u3093\u306A\u3089\u590F\u306E\u3064\u3069\u3044\u306E\u5F8C\u3068\u304B\uFF1F",
  "id" : 450592288876417025,
  "in_reply_to_status_id" : 450592172337672193,
  "created_at" : "2014-03-31 11:15:47 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450592081535188992",
  "text" : "\u534A\u83585\u56DE\u30673\u56DE\u30C8\u30C3\u30D7\u306A\u3089\u5927\u6E80\u8DB3\u306A\u306E",
  "id" : 450592081535188992,
  "created_at" : "2014-03-31 11:14:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450542139890364418",
  "text" : "\u3053\u3068\u306E\u306F\u306E\u306B\u308F",
  "id" : 450542139890364418,
  "created_at" : "2014-03-31 07:56:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450523594506768384",
  "text" : "\u4E00\u30F6\u6708\u5BB6\u8CC3\u3092\u6211\u6162\u3059\u308C\u3070\u8CB7\u3048\u308B",
  "id" : 450523594506768384,
  "created_at" : "2014-03-31 06:42:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450520985570013184",
  "text" : "\u30A2\u30C9\u30EC\u30B9\u5909\u66F4\u540D\u524D\u66F8\u304B\u306A\u3044\u5168\u4F53\u9001\u4FE1\u304B\u3089\u306E\u4E86\u89E3\u306E\u8FD4\u4FE1\u306E\u6D41\u308C\u3001\u69D8\u5F0F\u7F8E",
  "id" : 450520985570013184,
  "created_at" : "2014-03-31 06:32:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u86C7\u306E\u76EE\u5098",
      "screen_name" : "harusyagiku",
      "indices" : [ 0, 12 ],
      "id_str" : "154170573",
      "id" : 154170573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450520846897909760",
  "in_reply_to_user_id" : 154170573,
  "text" : "@harusyagiku \u30A2\u30C9\u30EC\u30B9\u5909\u66F4\u540D\u524D\u66F8\u304B\u306A\u3044\u5974\u301C",
  "id" : 450520846897909760,
  "created_at" : "2014-03-31 06:31:54 +0000",
  "in_reply_to_screen_name" : "harusyagiku",
  "in_reply_to_user_id_str" : "154170573",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450346815980699648",
  "text" : "\u3042\u30FC\u75B2\u308C\u3066\u3093\u306E\u306B\u7720\u308C\u306A\u3044\u3088\u3046",
  "id" : 450346815980699648,
  "created_at" : "2014-03-30 19:00:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450241085944524801",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 450241085944524801,
  "created_at" : "2014-03-30 12:00:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450240640257781760",
  "text" : "\u5C4A\u3044\u305F\u3089\u3059\u3050\u898B\u308B\u3068\u306F\u8A00\u3063\u3066\u306A\u3044",
  "id" : 450240640257781760,
  "created_at" : "2014-03-30 11:58:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450240589842223104",
  "text" : "21\u6642\u307E\u3067\u306B\u5C4A\u304F\u306F\u305A\u306E\u30EA\u30C8\u30D0\u30B9\u306EBD(\u501F\u308A\u7269)\u304C\u5C4A\u304B\u306A\u3044\u984F",
  "id" : 450240589842223104,
  "created_at" : "2014-03-30 11:58:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450239321291759616",
  "text" : "\u611F\u3058\u3070\u3063\u304B\u308A\u3067\u982D\u60AA\u3044\u611F\u3058",
  "id" : 450239321291759616,
  "created_at" : "2014-03-30 11:53:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450239268732948480",
  "text" : "\u62D7\u3089\u305B\u904E\u304E\u3066\u306A\u3044\u611F\u3058\u304C\u306A\u3093\u3068\u3082\u8A00\u3048\u306A\u3044\u611F\u3058",
  "id" : 450239268732948480,
  "created_at" : "2014-03-30 11:53:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/CGZFc3JxUq",
      "expanded_url" : "http:\/\/cookpad.com\/recipe\/list\/667637",
      "display_url" : "cookpad.com\/recipe\/list\/66\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450239186491043840",
  "text" : "\u5909\u306A\u306E\u30FC http:\/\/t.co\/CGZFc3JxUq",
  "id" : 450239186491043840,
  "created_at" : "2014-03-30 11:52:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450214007324934145",
  "text" : "\uFF1F\uFF1F\uFF1F\uFF1F",
  "id" : 450214007324934145,
  "created_at" : "2014-03-30 10:12:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450213992015732736",
  "text" : "\u6D88\u8CBB\u7A0E\u304C\u4E0A\u304C\u308B\u524D\u306B\u6D88\u8CBB\u7A0E\u3092\u3055\u3052\u3066\u304A\u304F\u3079\u304D\u3060",
  "id" : 450213992015732736,
  "created_at" : "2014-03-30 10:12:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450134393235836928",
  "text" : "\u304A\u308C\u306F\u3082\u3046\u4ECA\u65E5\u5BB6\u304B\u3089\u51FA\u306A\u3044\u305E\uFF01\uFF01\uFF01",
  "id" : 450134393235836928,
  "created_at" : "2014-03-30 04:56:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450118067352137729",
  "text" : "\u8FF8\u308B\u865A\u7121\u611F\uFF6F\uFF01",
  "id" : 450118067352137729,
  "created_at" : "2014-03-30 03:51:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449957951663378432",
  "text" : "\u3075\u3093\u3063\u3002\u305D\u3093\u306A\u4E8B\u306F\u3069\u3061\u3089\u3067\u3082\u540C\u3058\u4E8B\u3060\u3002",
  "id" : 449957951663378432,
  "created_at" : "2014-03-29 17:15:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449957750944976896",
  "text" : "\u5B89\u5FC3\u9662\u306A\u3058\u307F\u3068\u4EBA\u985E\u6700\u60AA\u3092\u8DB3\u3057\u3066\u4E8C\u3067\u5272\u3063\u305F\u3088\u3046\u306A\u30A2\u30C3\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2",
  "id" : 449957750944976896,
  "created_at" : "2014-03-29 17:14:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449957606992252928",
  "text" : "\u307F\u3093\u306A\u5927\u597D\u304D\u81E5\u7159\u304A\u306D\u30FC\u3055\u3093\u3060",
  "id" : 449957606992252928,
  "created_at" : "2014-03-29 17:13:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449956128470753280",
  "text" : "\u304C\u3048\u3093\u3044\u305A\u3053",
  "id" : 449956128470753280,
  "created_at" : "2014-03-29 17:07:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449922611766493184",
  "text" : "\u3044\u304B\u306B\u8AAD\u307F\u6D41\u3057\u3066\u3044\u308B\u304B\u3001\u3088\u304F\u308F\u304B\u3063\u3066\u3044\u305F\u3060\u3051\u305F\u3068",
  "id" : 449922611766493184,
  "created_at" : "2014-03-29 14:54:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449922441213526017",
  "geo" : { },
  "id_str" : "449922524252348416",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \u307B\u3093\u3068\u3060",
  "id" : 449922524252348416,
  "in_reply_to_status_id" : 449922441213526017,
  "created_at" : "2014-03-29 14:54:23 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 3, 15 ],
      "id_str" : "588420029",
      "id" : 588420029
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 17, 27 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449919851943845889",
  "text" : "RT @axis_ponpon: @end313124 \u8CB4\u65B9\u5929\u90AA\u9B3C\u306A\u3068\u3053\u308D\u3042\u308B\u304B\u3089\u52FF\u8AD6\u4F8B\u5916\u3067\u3059\u3088",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.jstwi.com\/kurotwi\/\" rel=\"nofollow\"\u003EKuroTwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "449918384604319745",
    "geo" : { },
    "id_str" : "449918525088358400",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u8CB4\u65B9\u5929\u90AA\u9B3C\u306A\u3068\u3053\u308D\u3042\u308B\u304B\u3089\u52FF\u8AD6\u4F8B\u5916\u3067\u3059\u3088",
    "id" : 449918525088358400,
    "in_reply_to_status_id" : 449918384604319745,
    "created_at" : "2014-03-29 14:38:30 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "protected" : false,
      "id_str" : "588420029",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607281463784964096\/UHWx7ZuN_normal.jpg",
      "id" : 588420029,
      "verified" : false
    }
  },
  "id" : 449919851943845889,
  "created_at" : "2014-03-29 14:43:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449919209296773121",
  "text" : "\u52FF\u8AD6\u8AD6\u5916\u984F\u30C0\u30D6\u30EB\u30D4\u30FC\u30B9",
  "id" : 449919209296773121,
  "created_at" : "2014-03-29 14:41:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449918195818696705",
  "geo" : { },
  "id_str" : "449918384604319745",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \uFF08\u4F55\u3082\u8A00\u308F\u305A\u306B\u6905\u5B50\u304B\u3089\u8EE2\u3052\u843D\u3061\u308B\uFF09",
  "id" : 449918384604319745,
  "in_reply_to_status_id" : 449918195818696705,
  "created_at" : "2014-03-29 14:37:56 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449917785452191745",
  "text" : "\u3042\u30FC\u30AB\u30E9\u30AA\u30B1\u884C\u304D\u305F\u3044\u3093\u3060",
  "id" : 449917785452191745,
  "created_at" : "2014-03-29 14:35:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449914528906506240",
  "text" : "\u307C\u30FC\u304C\u982D\u3063\u3066\u3057\u3066\u304D\u305F",
  "id" : 449914528906506240,
  "created_at" : "2014-03-29 14:22:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449912797925617665",
  "text" : "\u3061\u3087\u3053\u308C\u30FC\u3068\u3044\u3093\u305D\u3080\u306B\u3042",
  "id" : 449912797925617665,
  "created_at" : "2014-03-29 14:15:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449898382203441152",
  "geo" : { },
  "id_str" : "449898464022126593",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \u7D04\u675F\uFF01\u305D\u3046\u3044\u3046\u306E\u3082\u3042\u308B\u306E\u304B\uFF01",
  "id" : 449898464022126593,
  "in_reply_to_status_id" : 449898382203441152,
  "created_at" : "2014-03-29 13:18:47 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/bM6KOycHLY",
      "expanded_url" : "http:\/\/tenhou.net\/0\/?L3124",
      "display_url" : "tenhou.net\/0\/?L3124"
    } ]
  },
  "in_reply_to_status_id_str" : "449898154574368769",
  "geo" : { },
  "id_str" : "449898256118468609",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon http:\/\/t.co\/bM6KOycHLY \u3067\u3055\u3063\u304D\u307E\u3067\u3084\u3063\u3066\u305F\u3088(\u8981\u3089\u306C\u5831\u544A\uFF09",
  "id" : 449898256118468609,
  "in_reply_to_status_id" : 449898154574368769,
  "created_at" : "2014-03-29 13:17:57 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449897512284217344",
  "text" : "\u307F\u306A\u307F\u3093\uFF0C\u653B\u3081\u904E\u304E\u306E\u304D\u3089\u3044\u306F\u3042\u308B\u3051\u3069\u666E\u901A\u306B\u6253\u3066\u3066\u308B\u3057\u3082\u3046\u521D\u5FC3\u8005\u3058\u3083\u306A\u3044\u611F\u3058\u3057\u305F",
  "id" : 449897512284217344,
  "created_at" : "2014-03-29 13:15:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3042@\u6625\u4F11\u307F\u7D42\u4E86",
      "screen_name" : "yua_ws3rd",
      "indices" : [ 0, 10 ],
      "id_str" : "118405160",
      "id" : 118405160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449896944144363520",
  "geo" : { },
  "id_str" : "449897082346692608",
  "in_reply_to_user_id" : 118405160,
  "text" : "@yua_ws3rd \u3059\u307F\u307E\u305B\u3093(\uFF1F)\u305F\u3060\u306E\u5A01\u5687\u3060\u3063\u305F\u3093\u3067\u3059\u304C",
  "id" : 449897082346692608,
  "in_reply_to_status_id" : 449896944144363520,
  "created_at" : "2014-03-29 13:13:17 +0000",
  "in_reply_to_screen_name" : "yua_ws3rd",
  "in_reply_to_user_id_str" : "118405160",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449896994283073537",
  "text" : "\u50D5\u306F\u629C\u3051\u305F\u3044\u611F\u3058\u3067\u3059\u304C\u30ED\u30D3\u30FC\u306B5\u4EBA\u3044\u308B\u306E\u3067\u3088\u304B\u3063\u305F\u3089\u3064\u3065\u3051\u3066\u304F\u3060\u3055\u3044",
  "id" : 449896994283073537,
  "created_at" : "2014-03-29 13:12:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449896842591887361",
  "text" : "(\u6700\u5F8C\u306E\u4E00\u767A\u30C4\u30E2\u3068\u304B\u7406\u4E0D\u5C3D\u3059\u3050\u308B)",
  "id" : 449896842591887361,
  "created_at" : "2014-03-29 13:12:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449896764816904192",
  "text" : "\u304A\u3064\u304B\u308C\u3055\u307E\u3067\u3057\u305F\uFF0E\u3042\u3070\u308C\u3066\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F\uFF0E",
  "id" : 449896764816904192,
  "created_at" : "2014-03-29 13:12:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449893935674949633",
  "text" : "\u826F\u3044\u30A6\u30E9\u30A6\u30E9",
  "id" : 449893935674949633,
  "created_at" : "2014-03-29 13:00:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449891874405244928",
  "text" : "\u3093\u30FC\u304A\u3084\u304B\u3076\u308A",
  "id" : 449891874405244928,
  "created_at" : "2014-03-29 12:52:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449891318076936192",
  "geo" : { },
  "id_str" : "449891433986539520",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u30DE\u30B8\u304B\u2026\u610F\u5916\u3060\u2026",
  "id" : 449891433986539520,
  "in_reply_to_status_id" : 449891318076936192,
  "created_at" : "2014-03-29 12:50:51 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449891222987894784",
  "text" : "\u30CF\u30B8\u30DE\u30BF",
  "id" : 449891222987894784,
  "created_at" : "2014-03-29 12:50:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449891013440450560",
  "geo" : { },
  "id_str" : "449891163445551104",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u8EAB\u5185\u30CD\u30BF\u3092\u5DEE\u3057\u5F15\u3044\u305F\u6642\u306E\u9762\u767D\u3055\u304C\u308F\u304B\u3089\u3093",
  "id" : 449891163445551104,
  "in_reply_to_status_id" : 449891013440450560,
  "created_at" : "2014-03-29 12:49:46 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449890794053189632",
  "geo" : { },
  "id_str" : "449890902626934784",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u8AB0\u306B\u3060\u3088\uFF57\uFF57\uFF57",
  "id" : 449890902626934784,
  "in_reply_to_status_id" : 449890794053189632,
  "created_at" : "2014-03-29 12:48:44 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449890673580183552",
  "text" : "\u305D\u3057\u3066\u96C6\u307E\u3089\u306A\u3044\u8DE1\u4E00\u4EBA",
  "id" : 449890673580183552,
  "created_at" : "2014-03-29 12:47:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449890539823845378",
  "text" : "\/\u304B\u3089\u59CB\u307E\u308B\u6587\u5B57\u5217\u306F\u30B3\u30DE\u30F3\u30C9\u8A8D\u8B58\u3063\u307D\u3044\uFF0E\/list\u3063\u3066\u3084\u3063\u305F\u3089\u767A\u8A00\u3055\u308C\u306A\u304B\u3063\u305F\u3057",
  "id" : 449890539823845378,
  "created_at" : "2014-03-29 12:47:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5341\u6708\u514E@\u6700\u9AD8\u306E\u590F",
      "screen_name" : "nekaya_bot",
      "indices" : [ 0, 11 ],
      "id_str" : "271979824",
      "id" : 271979824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449890100566949888",
  "geo" : { },
  "id_str" : "449890302321381376",
  "in_reply_to_user_id" : 271979824,
  "text" : "@nekaya_bot \u3088\u304F\u8AAD\u3080\u3068\u66F8\u3044\u3066\u3042\u308B\u3088\u3093",
  "id" : 449890302321381376,
  "in_reply_to_status_id" : 449890100566949888,
  "created_at" : "2014-03-29 12:46:21 +0000",
  "in_reply_to_screen_name" : "nekaya_bot",
  "in_reply_to_user_id_str" : "271979824",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449889973169160192",
  "text" : "\u5929\u9CF3\u306E\u30C1\u30E3\u30C3\u30C8\u6B04\uFF0C\/w\u3067\u5F85\u6A5F\u30E1\u30F3\u30D0\u30FC\u898B\u308C\u308B\u6A5F\u80FD\u3081\u3063\u3061\u3087\u4FBF\u5229",
  "id" : 449889973169160192,
  "created_at" : "2014-03-29 12:45:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/bM6KOycHLY",
      "expanded_url" : "http:\/\/tenhou.net\/0\/?L3124",
      "display_url" : "tenhou.net\/0\/?L3124"
    } ]
  },
  "geo" : { },
  "id_str" : "449889773990055936",
  "text" : "\uFF20\u4E00\u4EBA http:\/\/t.co\/bM6KOycHLY",
  "id" : 449889773990055936,
  "created_at" : "2014-03-29 12:44:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449889297919770624",
  "text" : "\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u3066",
  "id" : 449889297919770624,
  "created_at" : "2014-03-29 12:42:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449889243339296769",
  "text" : "\u3080\u3046\u307E\u304F\u3089\u308C\u3066\u306B\u3061\u3083",
  "id" : 449889243339296769,
  "created_at" : "2014-03-29 12:42:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449887021721321472",
  "text" : "\u304A\u3082\u3063\u305F\u307B\u3069\u3053\u308F\u304F\u306A\u304B\u3063\u305F",
  "id" : 449887021721321472,
  "created_at" : "2014-03-29 12:33:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449885264425402369",
  "text" : "\u3042\u30FC\u304B\u3093\u3069\u3089",
  "id" : 449885264425402369,
  "created_at" : "2014-03-29 12:26:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449884033686577152",
  "text" : "\u6DF1\u3044\u3068\u3053\u308D\u306B",
  "id" : 449884033686577152,
  "created_at" : "2014-03-29 12:21:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449883779398516737",
  "text" : "\u3067\u306A\u3044\u2026",
  "id" : 449883779398516737,
  "created_at" : "2014-03-29 12:20:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449883101401841664",
  "text" : "\u3044\u304D\u306A\u308A\u306F\u306D\u3064\u3082\u3064\u3089\u3044",
  "id" : 449883101401841664,
  "created_at" : "2014-03-29 12:17:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449883006832885760",
  "text" : "\u305B\u3081\u3063\u3051",
  "id" : 449883006832885760,
  "created_at" : "2014-03-29 12:17:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449882435019223040",
  "text" : "\u306F\u3058\u307E\u305F",
  "id" : 449882435019223040,
  "created_at" : "2014-03-29 12:15:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bM6KOycHLY",
      "expanded_url" : "http:\/\/tenhou.net\/0\/?L3124",
      "display_url" : "tenhou.net\/0\/?L3124"
    } ]
  },
  "geo" : { },
  "id_str" : "449882411149430784",
  "text" : "http:\/\/t.co\/bM6KOycHLY \u3042\u3068\u4E00\u4EBA\u306A\u306E",
  "id" : 449882411149430784,
  "created_at" : "2014-03-29 12:14:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "8823\u56DE\u76EE\u306E\u6B63\u76F4",
      "screen_name" : "shin_8823",
      "indices" : [ 0, 10 ],
      "id_str" : "547025253",
      "id" : 547025253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449881950765846529",
  "geo" : { },
  "id_str" : "449881998899675138",
  "in_reply_to_user_id" : 547025253,
  "text" : "@shin_8823 \u304A\u3068\u306A\u3057\u304F\u75C5\u9662\u306B\u3044\u3053\u3046",
  "id" : 449881998899675138,
  "in_reply_to_status_id" : 449881950765846529,
  "created_at" : "2014-03-29 12:13:21 +0000",
  "in_reply_to_screen_name" : "shin_8823",
  "in_reply_to_user_id_str" : "547025253",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bM6KOycHLY",
      "expanded_url" : "http:\/\/tenhou.net\/0\/?L3124",
      "display_url" : "tenhou.net\/0\/?L3124"
    } ]
  },
  "geo" : { },
  "id_str" : "449881822139129856",
  "text" : "http:\/\/t.co\/bM6KOycHLY \uFF20\uFF11",
  "id" : 449881822139129856,
  "created_at" : "2014-03-29 12:12:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "8823\u56DE\u76EE\u306E\u6B63\u76F4",
      "screen_name" : "shin_8823",
      "indices" : [ 0, 10 ],
      "id_str" : "547025253",
      "id" : 547025253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449881632996999168",
  "geo" : { },
  "id_str" : "449881740190838784",
  "in_reply_to_user_id" : 547025253,
  "text" : "@shin_8823 \u304A\u3044\u304F\u3064\u306A\u3093\u3067\u3059\u304B",
  "id" : 449881740190838784,
  "in_reply_to_status_id" : 449881632996999168,
  "created_at" : "2014-03-29 12:12:19 +0000",
  "in_reply_to_screen_name" : "shin_8823",
  "in_reply_to_user_id_str" : "547025253",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449881630891454464",
  "text" : "\u307E\u3041\u9069\u5F53\u306B2\u56DE\u307B\u3069\uFF1F",
  "id" : 449881630891454464,
  "created_at" : "2014-03-29 12:11:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/bM6KOycHLY",
      "expanded_url" : "http:\/\/tenhou.net\/0\/?L3124",
      "display_url" : "tenhou.net\/0\/?L3124"
    } ]
  },
  "geo" : { },
  "id_str" : "449881330197598208",
  "text" : "\u3069\u3046\u305E http:\/\/t.co\/bM6KOycHLY",
  "id" : 449881330197598208,
  "created_at" : "2014-03-29 12:10:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/bM6KOycHLY",
      "expanded_url" : "http:\/\/tenhou.net\/0\/?L3124",
      "display_url" : "tenhou.net\/0\/?L3124"
    } ]
  },
  "geo" : { },
  "id_str" : "449881161574014976",
  "text" : "\uFF49d\u306B\u3061\u306A\u3093\u3067\uFF1Fhttp:\/\/t.co\/bM6KOycHLY",
  "id" : 449881161574014976,
  "created_at" : "2014-03-29 12:10:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u3067\u3082\u307F\u306A\u307F\u3093",
      "screen_name" : "37min_",
      "indices" : [ 0, 7 ],
      "id_str" : "544825981",
      "id" : 544825981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449880822045081600",
  "geo" : { },
  "id_str" : "449880860318126080",
  "in_reply_to_user_id" : 544825981,
  "text" : "@37min_ \u307E\u304B\u305B\u308D",
  "id" : 449880860318126080,
  "in_reply_to_status_id" : 449880822045081600,
  "created_at" : "2014-03-29 12:08:50 +0000",
  "in_reply_to_screen_name" : "37min_",
  "in_reply_to_user_id_str" : "544825981",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u590F\u3067\u3082\u307F\u306A\u307F\u3093",
      "screen_name" : "37min_",
      "indices" : [ 0, 7 ],
      "id_str" : "544825981",
      "id" : 544825981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449880682064379904",
  "geo" : { },
  "id_str" : "449880712275980288",
  "in_reply_to_user_id" : 544825981,
  "text" : "@37min_ \u3081\u3063\u3061\u3083\u308F\u304B\u308B",
  "id" : 449880712275980288,
  "in_reply_to_status_id" : 449880682064379904,
  "created_at" : "2014-03-29 12:08:14 +0000",
  "in_reply_to_screen_name" : "37min_",
  "in_reply_to_user_id_str" : "544825981",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449880393773096960",
  "text" : "\u3055\u3059\u304C\u306B\u9B5A\u3092\u604B\u611B\u5BFE\u8C61\u306B\u3059\u308B\u306E\u306F\u3061\u3087\u3063\u3068\u5F15\u304D\u307E\u3059",
  "id" : 449880393773096960,
  "created_at" : "2014-03-29 12:06:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449880320695730176",
  "text" : "\u3061\u3087\u3063\u3068\u4F3A\u3044\u305F\u3044\u306E\u3067\u3059\u304C\uFF0C\u9BC9\u306B\u604B\u3059\u308B\u5E74\u9803\u3063\u3066\u3069\u306E\u304F\u3089\u3044\u306E\u5E74\u9F62\u306A\u3093\u3067\u3057\u3087\u3046",
  "id" : 449880320695730176,
  "created_at" : "2014-03-29 12:06:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449879920710152193",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u304B\u305A\u30FC\u6C0F\u306E\u30B5\u30F3\u30C0\u30FC\u30D5\u30A3\u30B9\u30C8\u3069\u3046\u306A\u3063\u3066\u3093\u3060[\u4E00\u5E74\u8FD1\u304F\u7D4C\u3064\u306E\u3067\u306F]",
  "id" : 449879920710152193,
  "created_at" : "2014-03-29 12:05:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449879453519212544",
  "text" : "\u3053\u3048\u306B\u3060\u3057\u3066\u8AAD\u307F\u305F\u3044\u30D5\u30EC\u30FC\u30BA\u300C\u30AB\u30C4\u30B2\u30F3\u30CB\u30F3\u30B2\u30F3\u300D",
  "id" : 449879453519212544,
  "created_at" : "2014-03-29 12:03:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449879190519545856",
  "text" : "\u30AB\u30C4\u30B2\u30F3",
  "id" : 449879190519545856,
  "created_at" : "2014-03-29 12:02:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449878755566047233",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 449878755566047233,
  "created_at" : "2014-03-29 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449873243734687745",
  "geo" : { },
  "id_str" : "449873546961887232",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u50D5\u3082\u590F\u306B\u306F\u4EAC\u90FD\u306B\u884C\u304D\u307E\u3059\u306E\u3067\uFF08\u305F\u3076\u3093\uFF09\u904A\u3093\u3067\u304F\u3060\u3055\u3044",
  "id" : 449873546961887232,
  "in_reply_to_status_id" : 449873243734687745,
  "created_at" : "2014-03-29 11:39:46 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449872710022086656",
  "geo" : { },
  "id_str" : "449872784265453568",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi I'm at \u672D\u5E4C",
  "id" : 449872784265453568,
  "in_reply_to_status_id" : 449872710022086656,
  "created_at" : "2014-03-29 11:36:44 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449872725385814016",
  "text" : "\u5C06\u6765\u306E\u8A71\u306F\u3059\u308B\u306A\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 449872725385814016,
  "created_at" : "2014-03-29 11:36:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449872382472110080",
  "text" : "\u304B\u3057\u3071\u3093\u304F\u3093\u3068\u5165\u308C\u9055\u3063\u3061\u3083\u3063\u305F\u306E\u3082\u3061\u3087\u3063\u3068\u52FF\u4F53\u7121\u304B\u3063\u305F",
  "id" : 449872382472110080,
  "created_at" : "2014-03-29 11:35:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449871008325844993",
  "text" : "\u3072\u308B\u306E\u307B\u30FC\u3057\u306B\u30FC",
  "id" : 449871008325844993,
  "created_at" : "2014-03-29 11:29:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449870749520523264",
  "text" : "\u9650\u3089\u308C\u3066\u306A\u3044\u4EBA\uFF0E\u30E4\u30D0\u30A4\uFF0E",
  "id" : 449870749520523264,
  "created_at" : "2014-03-29 11:28:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449870704373006338",
  "text" : "\u51FA\u6765\u308B\u3053\u3068\u304C\u9650\u3089\u308C\u3066\u3044\u308B\u306A\u30FC\uFF0E",
  "id" : 449870704373006338,
  "created_at" : "2014-03-29 11:28:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449869578118524928",
  "text" : "\u5352\u696D\u3057\u305F\u4EBA\u305F\u3061\u304C\u6CA2\u5C71\u6771\u4EAC\u306B\u6765\u3066\u308B\u3088\u3046\u3067\u3061\u3087\u3063\u3068\u5B09\u3057\u3044\u3051\u3069\u305D\u308C\u3092\u901A\u308A\u3059\u304E\u3066\u3057\u307E\u3063\u305F\u611F",
  "id" : 449869578118524928,
  "created_at" : "2014-03-29 11:24:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449869257094856704",
  "text" : "\u6C17\u304C\u3064\u3044\u305F\u3089\u30A2\u30A4\u30B9\u8CB7\u3044\u3060\u3081\u3057\u3066\u305F",
  "id" : 449869257094856704,
  "created_at" : "2014-03-29 11:22:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449858474445242369",
  "text" : "\u3042\u30FC\u3042\u30FC\u3089",
  "id" : 449858474445242369,
  "created_at" : "2014-03-29 10:39:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7vOYRNrmED",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449803202716651520",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/7vOYRNrmED",
  "id" : 449803202716651520,
  "created_at" : "2014-03-29 07:00:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449802977792888832",
  "text" : "\u307F\u3056\u308A\u30FC\u3073\u3058\u306D\u3059",
  "id" : 449802977792888832,
  "created_at" : "2014-03-29 06:59:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449802674679328768",
  "text" : "\u5DE6\u8155\uFF0C\u868A\u306B\u3055\u3055\u308C\u305F\u3088\u3046\u306A\u8DE1\u304C\u3042\u3063\u3066\u75D2\u3044\u3093\u3060\u3051\u3069\u3053\u306E\u6642\u671F\u306B\u868A\u306A\u3093\u3066\u3044\u308B\u306E\u304B\u306A",
  "id" : 449802674679328768,
  "created_at" : "2014-03-29 06:58:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449802126391119872",
  "text" : "\uFF8E\uFF8B\uFF6F",
  "id" : 449802126391119872,
  "created_at" : "2014-03-29 06:55:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449548557691781120",
  "text" : "\u5B9F\u969B\u96E2\u5CF6\u3068\u304B\u3067\u306E\u3093\u3073\u308A\u6B7B\u306B\u305F\u3044",
  "id" : 449548557691781120,
  "created_at" : "2014-03-28 14:08:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449547360096382977",
  "text" : "\u51FA\u6765\u308B\u3053\u3068\u306F\u51FA\u6765\u308B\u3057\u51FA\u6765\u306A\u3044\u4E8B\u306F\u51FA\u6765\u306A\u3044\u3093\u3060\u306A",
  "id" : 449547360096382977,
  "created_at" : "2014-03-28 14:03:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449547103685992450",
  "text" : "\u307E\u3041\u3067\u3082\u5B9A\u671F\u7684\u306B\u4EBA\u3068\u558B\u3089\u306A\u3044\u3068\u6B21\u306B\u89AA\u3057\u3044\u4EBA\u3068\u3042\u3063\u305F\u6642\u306B\u7206\u767A\u3059\u308B\u5371\u967A\u304C\u3042\u308B\u306A",
  "id" : 449547103685992450,
  "created_at" : "2014-03-28 14:02:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449546782712680448",
  "geo" : { },
  "id_str" : "449546900903968769",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u96E2\u5CF6\u306B\u90E8\u5C4B\u3092\u501F\u308A\u308B\u3079\u304D\u3060\u3063\u305F(\u932F\u4E71)",
  "id" : 449546900903968769,
  "in_reply_to_status_id" : 449546782712680448,
  "created_at" : "2014-03-28 14:01:48 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449546563816157186",
  "geo" : { },
  "id_str" : "449546663439237120",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u4FEE\u884C\u7A7A\u9593\u2026\uFF1F",
  "id" : 449546663439237120,
  "in_reply_to_status_id" : 449546563816157186,
  "created_at" : "2014-03-28 14:00:51 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449546423885766656",
  "text" : "\u3042\u30FC\u30CD\u30C3\u30C8\u306F\u7121\u3044\u3068\u6B7B\u306C",
  "id" : 449546423885766656,
  "created_at" : "2014-03-28 13:59:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449546353274658816",
  "text" : "\u4E00\u5E74\u304F\u3089\u3044\u7530\u820E\u3067\u4FEE\u884C\u3057\u305F\u3044",
  "id" : 449546353274658816,
  "created_at" : "2014-03-28 13:59:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449506811440164865",
  "text" : "\u5B50\u4F9B\u306E\u500D\u6E80\u304F\u3089\u3044\u6CE8\u6587\u3057\u3066\u3057\u307E\u3063\u305F",
  "id" : 449506811440164865,
  "created_at" : "2014-03-28 11:22:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449506714853720064",
  "text" : "\u6069\u3092\u717D\u308A\u3067\u8FD4\u3059",
  "id" : 449506714853720064,
  "created_at" : "2014-03-28 11:22:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 6, 20 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/EgUSH91QJh",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/B003VM0RX4\/ref=cm_sw_r_tw_asp_9eJBH.05F3TWZ",
      "display_url" : "amazon.co.jp\/dp\/B003VM0RX4\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449506579939721216",
  "text" : "\u7559\u5E74\u3092\u6C7A\u3081\u305F@coscos2coscos \u306B\uFF0C\u5352\u696D\u795D\u3044\u306B\u8CB0\u3063\u305F\u30A2\u30DE\u30BE\u30F3\u30AE\u30D5\u30C8\u3092\u4F7F\u3063\u3066\uFF0C\u6B21\u306E\u5546\u54C1\u3092\u8CFC\u5165\u3057\u307E\u3057\u305F\uFF1AMOGU \u300EMOGU \u6C17\u6301\u3061\u3044\u3044\u62B1\u304D\u307E\u304F\u3089 \u672C\u4F53(\u30AB\u30D0\u30FC\u4ED8) (BR \u30D6\u30E9\u30A6\u30F3) 834317\u300F\u7559\u5E74\u304A\u3081\u3067\u3068\u3046\uFF01\uFF01\uFF01 http:\/\/t.co\/EgUSH91QJh",
  "id" : 449506579939721216,
  "created_at" : "2014-03-28 11:21:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449501526763925504",
  "text" : "\u3060\u304D\u307E\u304F\u3089\u3075\u3093\u3071\u3064\u3057\u3066\u3044\u3053\u3046\uFF0E",
  "id" : 449501526763925504,
  "created_at" : "2014-03-28 11:01:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449499006012362752",
  "text" : "\u5897\u7A0E\u524D\u306B\u30A2\u30DE\u30BE\u30F3\u30DD\u30C1\u308B\u304B",
  "id" : 449499006012362752,
  "created_at" : "2014-03-28 10:51:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449480172312346624",
  "text" : "\u304A\u663C\u306B\u8D77\u304D\u3066\uFF0C\u3057\u3070\u3089\u304F\u3059\u308B\u3068\uFF0C\u591C\u306B\u306A\u308B\uFF0E",
  "id" : 449480172312346624,
  "created_at" : "2014-03-28 09:36:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449476886842707968",
  "text" : "\u304A\u8179\u304C\u6E1B\u308B\u30B7\u30B9\u30C6\u30E0\u304B\u3088\u2026",
  "id" : 449476886842707968,
  "created_at" : "2014-03-28 09:23:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449451389337337856",
  "text" : "\u306A\u3064\u3089\u308B\u3076\u308D\u3063\u304F",
  "id" : 449451389337337856,
  "created_at" : "2014-03-28 07:42:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449444143031283712",
  "text" : "\u826F\u3044\u59FF\u52E2\u304C\u8F9B\u3044\u3068\u3044\u3046\u73FE\u72B6\u3092\u6DF1\u304F\u53D7\u3051\u6B62\u3081\u305F\uFF08\u5B8C\uFF09",
  "id" : 449444143031283712,
  "created_at" : "2014-03-28 07:13:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449443987829452802",
  "text" : "\u59FF\u52E2\u304C\u60AA\u3044\u304B\u3089\u81EA\u7136\u3068\u59FF\u52E2\u3092\u6B63\u3059\u30BF\u30A4\u30D7\u306E\u6905\u5B50\u306B\u5EA7\u308B\u3068\u8272\u3093\u306A\u6240\u304C\u75DB\u3080",
  "id" : 449443987829452802,
  "created_at" : "2014-03-28 07:12:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449443394746466304",
  "text" : "\u30DE\u30B0\u30AB\u30C3\u30D7\u5927\u91CF\u6240\u6301\u306E\u5BB9\u7591\u3067\u66F8\u985E\u9001\u691C\u3055\u308C\u308B",
  "id" : 449443394746466304,
  "created_at" : "2014-03-28 07:10:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449443283958116352",
  "text" : "\u30D1\u30EA\u306F\u7D9A\u6295\uFF0E\u53CB\u4EBA\u304C\u6301\u3063\u3066\u6765\u305F\u30D6\u30E9\u30C3\u30AF\u30ED\u30C3\u30AF\u30B7\u30E5\u30FC\u30BF\u30FC\u306E\u30DE\u30B0\u306E\u4EE3\u308F\u308A\u306B\u65B0\u305F\u306B\u30D5\u30A3\u30EA\u30D4\u30F3\u306E\u3084\u3064\u8FFD\u52A0\u3057\u305F\uFF0E",
  "id" : 449443283958116352,
  "created_at" : "2014-03-28 07:10:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449443064579256320",
  "text" : "\u5929\u90AA\u9B3C\u3060\u304B\u3089\u4EAC\u90FD\u3067\u306F\u672D\u5E4C\u306E\u3054\u5F53\u5730\u30DE\u30B0\u4F7F\u3063\u3066\u3044\u305F\u3051\u3069\u672D\u5E4C\u306B\u6765\u3066\u304B\u3089\u306F\u4ED9\u53F0\u306E\u3084\u3064\u4F7F\u3063\u3066\u308B",
  "id" : 449443064579256320,
  "created_at" : "2014-03-28 07:09:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449442873105084416",
  "text" : "\u304A\u3075\u3043\u30FC\u308A\u3042",
  "id" : 449442873105084416,
  "created_at" : "2014-03-28 07:08:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449427465513889792",
  "text" : "\u30D5\u30A1\u30A4\u30EB\u3092\u958B\u304F\u3068\u304D\u306B\u6587\u5B57\u30B3\u30FC\u30C9\u306E\u30C7\u30D5\u30A9\u30EB\u30C8\u3092EUC-JP\u304B\u3089UTF-8\u306B\u5909\u3048\u3066\u304A\u304D\u305F\u3044\u3063\u3066\u4E94\u5104\u5E74\u304F\u3089\u3044\u601D\u3044\u7D9A\u3051\u3066\u3044\u308B\uFF0E",
  "id" : 449427465513889792,
  "created_at" : "2014-03-28 06:07:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449427270243864576",
  "text" : "\u767B\u9332\u30D5\u30A9\u30FC\u30E0\u306Fphp\u3067\u4F5C\u308B\u306E\u304C\u697D\u305D\u3046\uFF08\u3053\u306A\u307F\uFF09",
  "id" : 449427270243864576,
  "created_at" : "2014-03-28 06:06:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449421734953771008",
  "text" : "\u306A\u3093\u306B\u3082\u77E5\u3089\u306A\u3044",
  "id" : 449421734953771008,
  "created_at" : "2014-03-28 05:44:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449410077821132801",
  "geo" : { },
  "id_str" : "449410219492114433",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u5929\u624D\u535A\u58EBbot\u304C\u79C1\u3063\u307D\u3044\u3093\u3067\u3059(\u50B2\u6162)",
  "id" : 449410219492114433,
  "in_reply_to_status_id" : 449410077821132801,
  "created_at" : "2014-03-28 04:58:40 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449409893867343872",
  "text" : "\u6FC3\u304F\u6DF9\u308C\u305F\u30B3\u30FC\u30D2\u30FC\u306F\u306D\u3001\u6FC3\u3044",
  "id" : 449409893867343872,
  "created_at" : "2014-03-28 04:57:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8D64\u72AC",
      "screen_name" : "akainu_6821",
      "indices" : [ 0, 12 ],
      "id_str" : "329606626",
      "id" : 329606626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449225819240427520",
  "geo" : { },
  "id_str" : "449226028934639616",
  "in_reply_to_user_id" : 329606626,
  "text" : "@akainu_6821 \u523A\u6FC0\u306B\u6163\u308C\u308B\u3068\u5143\u3082\u5B50\u3082\u306A\u3044\u304B\u3089\u672C\u5F53\u306B\u5FC5\u8981\u306A\u6642\u3060\u3051\u3069\u3046\u305E(?)",
  "id" : 449226028934639616,
  "in_reply_to_status_id" : 449225819240427520,
  "created_at" : "2014-03-27 16:46:46 +0000",
  "in_reply_to_screen_name" : "akainu_6821",
  "in_reply_to_user_id_str" : "329606626",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryc_2",
      "screen_name" : "ryc_db_2",
      "indices" : [ 0, 9 ],
      "id_str" : "880096687",
      "id" : 880096687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449225480533573632",
  "geo" : { },
  "id_str" : "449225662146936832",
  "in_reply_to_user_id" : 880096687,
  "text" : "@ryc_db_2 \u75B2\u308C\u3066\u305F\u308A\u663C\u5BDD\u3068\u304B\u3060\u3068\u306A\u308A\u3084\u3059\u3044\u307F\u305F\u3044\uFF1F",
  "id" : 449225662146936832,
  "in_reply_to_status_id" : 449225480533573632,
  "created_at" : "2014-03-27 16:45:18 +0000",
  "in_reply_to_screen_name" : "ryc_db_2",
  "in_reply_to_user_id_str" : "880096687",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449225265072189440",
  "text" : "\u91D1\u7E1B\u308A\u306B\u306A\u308B\u3068\u3001\u300C\u3042\u30FC\u306F\u3044\u306F\u3044\u3001\u91D1\u7E1B\u308A\u306D\u30FC\u3001\u308F\u304B\u308B\u308F\u304B\u308B\u30FC\u300D\u3063\u3066\u306A\u308B\u3002",
  "id" : 449225265072189440,
  "created_at" : "2014-03-27 16:43:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryc_2",
      "screen_name" : "ryc_db_2",
      "indices" : [ 0, 9 ],
      "id_str" : "880096687",
      "id" : 880096687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449224913828577280",
  "geo" : { },
  "id_str" : "449225083295264768",
  "in_reply_to_user_id" : 880096687,
  "text" : "@ryc_db_2 \u6163\u308C\u308B\u3068\u6D41\u308C\u4F5C\u696D\u3060\u3088\u306D",
  "id" : 449225083295264768,
  "in_reply_to_status_id" : 449224913828577280,
  "created_at" : "2014-03-27 16:43:00 +0000",
  "in_reply_to_screen_name" : "ryc_db_2",
  "in_reply_to_user_id_str" : "880096687",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449224156429574144",
  "text" : "\u3067\u3082\u307B\u307C\u9593\u9055\u3044\u306A\u304F\u8D77\u304D\u308C\u308B",
  "id" : 449224156429574144,
  "created_at" : "2014-03-27 16:39:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8D64\u72AC",
      "screen_name" : "akainu_6821",
      "indices" : [ 0, 12 ],
      "id_str" : "329606626",
      "id" : 329606626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449223538075893761",
  "geo" : { },
  "id_str" : "449224068227551232",
  "in_reply_to_user_id" : 329606626,
  "text" : "@akainu_6821 \u51B7\u8535\u5EAB\u306E\u76EE\u306E\u524D\u306B\u7206\u97F3\u306E\u76EE\u899A\u307E\u3057\u3092\u7F6E\u3044\u3066\u3001\u6B62\u3081\u308B\u3064\u3044\u3067\u306B\u51B7\u3084\u3057\u3066\u7F6E\u3044\u305F\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u3092\u98F2\u3080\u3068\u3001\u3068\u3066\u3082\u4F53\u306B\u60AA\u3044",
  "id" : 449224068227551232,
  "in_reply_to_status_id" : 449223538075893761,
  "created_at" : "2014-03-27 16:38:58 +0000",
  "in_reply_to_screen_name" : "akainu_6821",
  "in_reply_to_user_id_str" : "329606626",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449222962269282304",
  "text" : "\u7D76\u5BFE\u3084\u308A\u305F\u304F\u306A\u3044",
  "id" : 449222962269282304,
  "created_at" : "2014-03-27 16:34:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449222927108407297",
  "text" : "\u795E\u7D4C\u8870\u5F31\u3001\u672C\u5F53\u306B\u795E\u7D4C\u3092\u8870\u5F31\u3055\u305B\u308B\u306A\u30896\u30BB\u30C3\u30C8\u7E8F\u3081\u3066\u30016\u679A\u540C\u3058\u6570\u5B57\u7D75\u67C4\u63C3\u3048\u306A\u3044\u3068\u53D6\u308C\u306A\u3044\u3001\u4F4D\u306E\u30EB\u30FC\u30EB\u306B\u3057\u306A\u3044\u3068",
  "id" : 449222927108407297,
  "created_at" : "2014-03-27 16:34:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449222359086399489",
  "text" : "\u3042\u30FC\u307E\u305F\u306A\u3093\u306E\u5F79\u306B\u3082\u7ACB\u305F\u306A\u3044\u300C\u3042\u3084\u305B\u3055\u3093=\u5FC3\u304C\u8C4A\u304B\u306B\u306A\u308B\u300D\u3068\u3044\u3046\u4E00\u554F\u4E00\u7B54\u77E5\u8B58\u3092\u8EAB\u306B\u3064\u3051\u3066\u3057\u307E\u3063\u305F",
  "id" : 449222359086399489,
  "created_at" : "2014-03-27 16:32:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449221749234626562",
  "text" : "\u30B4\u30EA\u62BC\u3057\u306F\u8133\u306B\u826F\u3044\u3093\u3067\u3059\u3088",
  "id" : 449221749234626562,
  "created_at" : "2014-03-27 16:29:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "conjugate_box",
      "screen_name" : "conjugate_box",
      "indices" : [ 0, 14 ],
      "id_str" : "214532657",
      "id" : 214532657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449220568861011969",
  "geo" : { },
  "id_str" : "449221017601183745",
  "in_reply_to_user_id" : 214532657,
  "text" : "@conjugate_box \u306B\u3093\u3052\u3093\u306F\u3044\u3064\u307E\u3067\u3082\u3086\u3081\u3092\u3060\u3044\u3066\u3044\u3089\u308C\u308B\u307B\u3069\u3001\u3064\u3088\u304F\u306A\u3044",
  "id" : 449221017601183745,
  "in_reply_to_status_id" : 449220568861011969,
  "created_at" : "2014-03-27 16:26:51 +0000",
  "in_reply_to_screen_name" : "conjugate_box",
  "in_reply_to_user_id_str" : "214532657",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449220274559279105",
  "text" : "\u8D77\u304D\u305F\u3089\u3086\u3063\u305F\u308A\u8003\u3048\u3088\u3046",
  "id" : 449220274559279105,
  "created_at" : "2014-03-27 16:23:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449220223304880129",
  "text" : "\u3067\u3082\u306A\u3093\u304B\u8CB7\u308F\u306A\u3044\u3068\u4F55\u3092\u62B1\u3044\u3066\u5BDD\u308C\u3070\u3044\u3044\u3093\u3060\u611F\u304C",
  "id" : 449220223304880129,
  "created_at" : "2014-03-27 16:23:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449219927149268992",
  "text" : "\u3081\u3063\u3061\u3087\u53EF\u611B\u3044\u3057\u6B32\u3057\u3044\u3051\u3069\u81EA\u5206\u304C\u3053\u308C\u3092\u62B1\u3044\u3066\u7720\u308B\u306E\u3092\u7B2C\u4E09\u8005\u8996\u70B9\u3067\u8003\u3048\u308B\u3068\u3044\u308D\u3044\u308D\u8F9B\u3044\u3082\u306E\u304C\u3042\u308B",
  "id" : 449219927149268992,
  "created_at" : "2014-03-27 16:22:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 54, 61 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/825zFJrg5I",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/B003V36RK0\/ref=cm_sw_r_tw_awdl_6.entb0DBGZES",
      "display_url" : "amazon.co.jp\/dp\/B003V36RK0\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449219659976306688",
  "text" : "\u62B1\u304D\u6795 \u9ED2\u732B\uFF08\u5927\uFF09\u3000\u30D6\u30E9\u30C3\u30AF\u5927\u578B\u30AF\u30C3\u30B7\u30E7\u30F3\u3000\u30D7\u30EC\u30BC\u30F3\u30C8\u306B\u4EBA\u6C17 http:\/\/t.co\/825zFJrg5I @amazon\u3055\u3093\u304B\u3089",
  "id" : 449219659976306688,
  "created_at" : "2014-03-27 16:21:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449218508883128321",
  "text" : "\u3054\u304F\u63A7\u3048\u3081\u306B\u8A00\u3063\u3066\u96FB\u6E90\u30BF\u30C3\u30D75\u5104\u500B\u304F\u3089\u3044\u5FC5\u8981",
  "id" : 449218508883128321,
  "created_at" : "2014-03-27 16:16:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449217004872822784",
  "text" : "\u305D\u3046\u3044\u3048\u3070\u5E02\u5185\u306B\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u5C4B\u3055\u3093(?)\u304C\u6709\u308B\u3068\u3042\u304F\u3057\u3059\u306B\u805E\u3044\u305F\u306A",
  "id" : 449217004872822784,
  "created_at" : "2014-03-27 16:10:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449216454513025025",
  "text" : "\u3081\u304C\u3057\u3087\u307C\u3057\u3087\u307C\u3057\u59CB\u3081\u305F\u306E\u3067( \u00B4_\u309D\uFF40)\uFF87\uFF70\uFF9D",
  "id" : 449216454513025025,
  "created_at" : "2014-03-27 16:08:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449216160970457088",
  "text" : "\u4E8C\u4EBA\u3067\u5225\u306E\u30B2\u30FC\u30E0\u3067\u904A\u3076\u3068\u304B\u3044\u3046\u51E1\u5EB8\u306A\u767A\u60F3",
  "id" : 449216160970457088,
  "created_at" : "2014-03-27 16:07:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449215519640416256",
  "geo" : { },
  "id_str" : "449216044876328961",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u305D\u308C\u3068\u30CE\u30FC\u30C6\u30A3\u843D\u3068\u3057\u306E\u30AF\u30EA\u30A2\u306E\u65E9\u3055\u3092\u7AF6\u3046\u5168\u304F\u65B0\u3057\u3044\u904A\u3073\u3092\u601D\u3044\u3064\u304D\u307E\u3057\u305F\u3001\u3054\u6D3B\u7528\u4E0B\u3055\u3044",
  "id" : 449216044876328961,
  "in_reply_to_status_id" : 449215519640416256,
  "created_at" : "2014-03-27 16:07:05 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449170072334897153",
  "text" : "\u3077\u3088\u3077\u3088\u00D7\u8266\u3053\u308C\u3001\u58F2\u308C\u305D\u3046(\u5C0F\u4E26\u611F)",
  "id" : 449170072334897153,
  "created_at" : "2014-03-27 13:04:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449163983950340096",
  "text" : "\u51B7\u8535\u5EAB\u306B\u307B\u3068\u3093\u3069\u6DB2\u4F53\u3057\u304B\u5165\u3063\u3066\u306A\u3044",
  "id" : 449163983950340096,
  "created_at" : "2014-03-27 12:40:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449162830160211969",
  "text" : "\u8FD1\u6240\u306E\u30B3\u30F3\u30D3\u30CB\u3001\u70CF\u9F8D\u8336\u304B\u306A\u308A\u5B89\u3044\u3057\u30A2\u30A4\u30B9\u306E\u58F2\u308A\u5834\u304C\u4E00\u5217\u3060\u3063\u305F\u3057\u795E\u304B",
  "id" : 449162830160211969,
  "created_at" : "2014-03-27 12:35:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449160870312951808",
  "text" : "\u3042\u3041\u305D\u3046\u304B\u3001\u30A6\u30FC\u30ED\u30F3\u8336\u304C\u7121\u3044\u3093\u3060",
  "id" : 449160870312951808,
  "created_at" : "2014-03-27 12:27:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449153978794659840",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 449153978794659840,
  "created_at" : "2014-03-27 12:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449151479803166724",
  "text" : "\u30B9\u30DA\u30FC\u30B9\u30C0\u30F3\u30C7\u30A3\u306E\u9069\u5F53\u3055\u306E\u30EC\u30D9\u30EB\u3001\u7D76\u5BFE\u50D5\u3092\u57FA\u6E96\u306B\u3057\u3066\u308B",
  "id" : 449151479803166724,
  "created_at" : "2014-03-27 11:50:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449151069612814336",
  "text" : "\u708A\u98EF\u5668\u306A\u3044\u304B\u3089\u5727\u529B\u934B\u3067\u3054\u98EF\u708A\u304D\u307E\u3059",
  "id" : 449151069612814336,
  "created_at" : "2014-03-27 11:48:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449147694091481088",
  "text" : "\u306A\u3093\u306A\u3093\u3060\u2026",
  "id" : 449147694091481088,
  "created_at" : "2014-03-27 11:35:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449147668900487169",
  "text" : "\u826F\u3044\u3067\u3059\u304B\u7686\u3055\u3093\u3001\u3055\u3063\u304D\u306E\u30DD\u30B9\u30C8\u304C\u3075\u3041\u307C\u3089\u308C\u308B\u3002\u305D\u3046\u3044\u3046\u4E16\u306E\u4E2D\u306A\u3093\u3067\u3059\u3002\n\u305D\u3046\u3044\u3046\u4E16\u306E\u4E2D\u306A\u3093\u3067\u3059\u3002",
  "id" : 449147668900487169,
  "created_at" : "2014-03-27 11:35:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449147218759405569",
  "text" : "\u30A2\uFF01\u30C8\uFF01\u30E2\uFF01\u30B9\uFF01\u30D5\u30A3\u30A2\uFF01(\u4F2F\u65B9\u306E\u5869\u306E\u30EA\u30BA\u30E0\u3067)",
  "id" : 449147218759405569,
  "created_at" : "2014-03-27 11:33:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449117354165690368",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u30B9\u30AD\u30E3\u30CA\u306E\u554F\u984C\u304C\u89E3\u6C7A\u3059\u308B\u307E\u3067\u306F1\u3060\u306A",
  "id" : 449117354165690368,
  "created_at" : "2014-03-27 09:34:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449117279150559232",
  "text" : "1.\u30B9\u30AD\u30E3\u30F3\u5C02\u7528\u6A5F\u3068\u3057\u3066\u30AA\u30D5\u30E9\u30A4\u30F3\u3067\u98FC\u3044\u6BBA\u3059.\n2.\u306A\u3093\u304B\u5165\u308C\u3066\u30B5\u30FC\u30D0\u3068\u3057\u3066\u6271\u3046\n3.\u306A\u3093\u304B\u5165\u308C\u3066linux\u3068\u3057\u3066\u4F7F\u3046\n4.\u30D1\u30FC\u30C4\u6D41\u7528\u3057\u3064\u3064\u65B0\u3057\u3044\u30C7\u30B9\u30AF\u30C8\u30C3\u30D7\u3092\u4F5C\u308B\n\n4\u304C\u826F\u3044\u3051\u3069\u306A\u2026",
  "id" : 449117279150559232,
  "created_at" : "2014-03-27 09:34:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449116558875312128",
  "text" : "\u307B\u3093\u3068\u3046\u306B\u307B\u3093\u3068\u3046\u306B\u9A5A\u304F\u3079\u304D\u4E8B\u3060",
  "id" : 449116558875312128,
  "created_at" : "2014-03-27 09:31:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449108737035223041",
  "geo" : { },
  "id_str" : "449116078614929408",
  "in_reply_to_user_id" : 1960955258,
  "text" : "@refpiyu \u304A\u3069\u308D\u304F\u3079\u304D\u3053\u3068\u306B",
  "id" : 449116078614929408,
  "in_reply_to_status_id" : 449108737035223041,
  "created_at" : "2014-03-27 09:29:51 +0000",
  "in_reply_to_screen_name" : "reflexio_",
  "in_reply_to_user_id_str" : "1960955258",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449106029100285952",
  "text" : "\u3046\u30FC\u3093\u3001\u3069\u3046\u904B\u7528\u3059\u308B\u306E\u304C\u8CE2\u3044\u3093\u3060\u308D\u3046",
  "id" : 449106029100285952,
  "created_at" : "2014-03-27 08:49:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449105967276249088",
  "text" : "scansnap\u304Cubuntu\u3067\u52D5\u304B\u306A\u3044\u4EE5\u4E0A\u3053\u306E\u30C7\u30B9\u30AF\u30C8\u30C3\u30D7(XP)\u306F\u30CD\u30C3\u30C8\u306B\u7E4B\u3052\u305A\u306B\u305F\u3060\u306E\u30B9\u30AD\u30E3\u30CA\u5C02\u7528\u6A5F\u3068\u5316\u3059\u53EF\u80FD\u6027\u304C\u3060\u306A\u2026",
  "id" : 449105967276249088,
  "created_at" : "2014-03-27 08:49:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449104618622963712",
  "text" : "\u52D5\u304F\u3060\u3051\u3067\u5947\u8DE1\u307F\u305F\u3044\u306A\u30DE\u30B7\u30F3\u3060\u304B\u3089\u306A\u2026",
  "id" : 449104618622963712,
  "created_at" : "2014-03-27 08:44:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449104512582553600",
  "text" : "\u6717\u5831:desktop\u306EPC\u304C\u52D5\u304F",
  "id" : 449104512582553600,
  "created_at" : "2014-03-27 08:43:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449094423100391425",
  "text" : "\u904E\u53BB\u306B\u6255\u3063\u3066\u306A\u3044\u306A\u3089\u300C\u904E\u53BB\u306B\u6255\u3063\u3066\u306A\u304B\u3063\u305F\u306E\u306B\u57FA\u6E96\u3069\u3046\u306A\u3063\u3066\u3093\u306E\u300D\u3063\u3066\u8A00\u3048\u308B\u304B\u3089\u5F37\u3044\u3001\u5F8C\u308D\u3081\u305F\u3044\u4E8B\u4E00\u3064\u3082\u306A\u3044\u304B\u3089\u5F37\u6C17\u306B\u51FA\u308C\u308B\u3057",
  "id" : 449094423100391425,
  "created_at" : "2014-03-27 08:03:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 0, 10 ],
      "id_str" : "157989076",
      "id" : 157989076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449093402357821440",
  "geo" : { },
  "id_str" : "449093753114873856",
  "in_reply_to_user_id" : 157989076,
  "text" : "@typekanon \u5B9F\u969B\u3069\u3053\u304B\u3089\u60C5\u5831\u5F97\u3066\u308B\u3093\u3067\u3057\u3087\u3046\u306D\u2026\u305D\u306E\u6C17\u306B\u306A\u308C\u3070\u3069\u3053\u304B\u3089\u3067\u3082\u3070\u308C\u307E\u3059\u3051\u308C\u3069\u2026",
  "id" : 449093753114873856,
  "in_reply_to_status_id" : 449093402357821440,
  "created_at" : "2014-03-27 08:01:09 +0000",
  "in_reply_to_screen_name" : "typekanon",
  "in_reply_to_user_id_str" : "157989076",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449093576979251200",
  "text" : "\u53D7\u4FE1\u6599\u3068\u304B\u3044\u3046\u304B\u3089\u306B\u306F\u53D7\u4FE1\u3057\u3066\u306A\u3044\u30DE\u30F3\u306F\u6255\u308F\u306A\u3044\u3067\u3059\u3088\u3002\u672C\u5F53\u306B\u5168\u56FD\u6C11\u304B\u3089\u53D6\u308A\u305F\u3051\u308C\u3070\u9069\u5F53\u306A\u540D\u524D\u3064\u3051\u3066\u7A0E\u91D1\u3068\u3057\u3066\u53D6\u308A\u7ACB\u3066\u308C\u3070\u3044\u3044\u306E\u306B\u306D\u3002",
  "id" : 449093576979251200,
  "created_at" : "2014-03-27 08:00:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 0, 10 ],
      "id_str" : "157989076",
      "id" : 157989076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449092609986666496",
  "geo" : { },
  "id_str" : "449093076191948800",
  "in_reply_to_user_id" : 157989076,
  "text" : "@typekanon \u92ED\u3044\u3067\u3059\u306D",
  "id" : 449093076191948800,
  "in_reply_to_status_id" : 449092609986666496,
  "created_at" : "2014-03-27 07:58:27 +0000",
  "in_reply_to_screen_name" : "typekanon",
  "in_reply_to_user_id_str" : "157989076",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449092387252367360",
  "text" : "\u74B0\u5883\u306A\u3044\u3093\u3067\u6255\u3044\u307E\u305B\u3093\u3067\u3057\u305F",
  "id" : 449092387252367360,
  "created_at" : "2014-03-27 07:55:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449092321783476224",
  "text" : "NHK\u3081\u3001\u3082\u3046\u3053\u3053\u3092\u55C5\u304E\u3064\u3051\u305F\u304B\u2026",
  "id" : 449092321783476224,
  "created_at" : "2014-03-27 07:55:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449075170917904385",
  "text" : "\u5352\u696D\u8A3C\u66F8\u304C\u5C4A\u3044\u3066\u5352\u696D\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3092\u611F\u3058\u3066\u308B\u3002\u65B0\u5C45\u3067\u3002",
  "id" : 449075170917904385,
  "created_at" : "2014-03-27 06:47:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449073910131085313",
  "text" : "\u30AC\u30B9\u5C4B\u3055\u3093\u3001\u306A\u3093\u304B\u30B3\u30DF\u30E5\u969C\u3063\u307D\u304B\u3063\u305F[\u656C\u8A9E\u304C\u6642\u3005\u4F7F\u3048\u306A\u3044\uFF1F]",
  "id" : 449073910131085313,
  "created_at" : "2014-03-27 06:42:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449040236647968768",
  "text" : "\u30CD\u30EB\u3068\u8C46\u3068\u30DF\u30EB\u306F\u51FA\u3066\u6765\u305F\u304B\u3089\u5F8C\u306F\u30DD\u30C3\u30C8\u304C\u3042\u308C\u3070\u30B3\u30FC\u30D2\u30FC\u3092\u98F2\u3081\u308B",
  "id" : 449040236647968768,
  "created_at" : "2014-03-27 04:28:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449039843482275840",
  "text" : "1\u6642\u9593\u307B\u3069\u30AC\u30B5\u30B4\u30BD\u3084\u3063\u305F\u3060\u3051\u3067\u3053\u306E\u75B2\u52B4\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2",
  "id" : 449039843482275840,
  "created_at" : "2014-03-27 04:26:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449025648476966914",
  "text" : "\u4F55\u304B\u3089\u89E3\u3051\u3070\u3044\u3044\u3093\u3060\u2026",
  "id" : 449025648476966914,
  "created_at" : "2014-03-27 03:30:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449024574240210944",
  "text" : "\u9593\u9055\u3048\u305F\u7D50\u679C6\u30D6\u30ED\u30C3\u30AF\u307B\u3069\u6B69\u304F\u30CF\u30E1\u306B",
  "id" : 449024574240210944,
  "created_at" : "2014-03-27 03:26:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449018887326019584",
  "text" : "\u3042\u306E\u306D\u3001\u8377\u9020\u308A\u306B3\u65E5\u639B\u304B\u3063\u305F\u3093\u3060\u306A\u3089\u306D\u30011\u65E5\u3067\u8377\u89E3\u304D\u3059\u308B\u306E\u306F\u306D\u3001\u7121\u7406",
  "id" : 449018887326019584,
  "created_at" : "2014-03-27 03:03:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449017872426078209",
  "text" : "\u30C1\u30AB\u30C6\u30C4\u30CB\u30F3\u30B2\u30F3",
  "id" : 449017872426078209,
  "created_at" : "2014-03-27 02:59:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448986536499884032",
  "text" : "\u3068\u3066\u3082\u3075\u308F\u3063\u3068\u3057\u3066\u3044\u308B\u30CA\u30FC",
  "id" : 448986536499884032,
  "created_at" : "2014-03-27 00:55:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448986450151755776",
  "text" : "(\u77F3\u5DDD\u5544\u6728\u306E\u9285\u50CF\u898B\u305F)\u59B9\u300C\u4F55\u3057\u305F\u4EBA\uFF1F\u300D\n\u6BCD\u89AA\u300C\u3061\u3087\u3063\u3068\u5049\u3044\u4EBA\u300D\n\n\uFF3F\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\u4EBA\uFF3F\n\uFF1E\u3000\u3061\u3087\u3063\u3068\u5049\u3044\u4EBA\u3000\uFF1C\n\uFFE3Y^Y^Y^Y^Y^Y^Y^Y\uFFE3",
  "id" : 448986450151755776,
  "created_at" : "2014-03-27 00:54:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u3063\u307D\u308D\u30C6\u30EC\u30D3\u5854",
      "screen_name" : "SAPPORO_TVTOWER",
      "indices" : [ 17, 33 ],
      "id_str" : "158604614",
      "id" : 158604614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/k9ngMAfDyA",
      "expanded_url" : "http:\/\/4sq.com\/1gYPhdO",
      "display_url" : "4sq.com\/1gYPhdO"
    } ]
  },
  "geo" : { },
  "id_str" : "448984958477299712",
  "text" : "I'm at \u3055\u3063\u307D\u308D\u30C6\u30EC\u30D3\u5854 (@Sapporo_TVTower) (\u672D\u5E4C\u5E02\u4E2D\u592E\u533A, \u5317\u6D77\u9053) http:\/\/t.co\/k9ngMAfDyA",
  "id" : 448984958477299712,
  "created_at" : "2014-03-27 00:48:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448972042633621504",
  "text" : "sl\u306E\u771F\u9854\u30B8\u30A7\u30CD\u30EC\u30FC\u30BF\u3063\u3077\u308A\u3068\u8A00\u3063\u305F\u3089\u2026",
  "id" : 448972042633621504,
  "created_at" : "2014-03-26 23:57:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448811490854703104",
  "text" : "\u306A\u306B\u3057\u308D\u4ECA\u65E56\u664230\u5206\u306B\u8D77\u304D\u305F\u4E0A\u306B\u6B69\u304D\u307E\u308F\u3063\u305F\u308A\u3057\u305F\u304B\u3089\u3053\u306E\u6642\u9593\u3067\u3068\u3066\u3082\u306D\u3080\u3044\u3084\u3064\u3060",
  "id" : 448811490854703104,
  "created_at" : "2014-03-26 13:19:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u4F55\u3082\u3057\u3066\u306A\u3044\u306E\u306B\u30D1\u30BD\u30B3\u30F3\u304C\u6CBB\u3063\u305F",
      "indices" : [ 15, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448808659418509312",
  "text" : "\u518D\u8D77\u52D5\u3057\u305F\u3089\u6A5F\u5ACC\u3092\u76F4\u3057\u305F\u6A21\u69D8\uFF0E#\u4F55\u3082\u3057\u3066\u306A\u3044\u306E\u306B\u30D1\u30BD\u30B3\u30F3\u304C\u6CBB\u3063\u305F",
  "id" : 448808659418509312,
  "created_at" : "2014-03-26 13:08:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448808057963700224",
  "text" : "\u306A\u305C\u304Bmozc\u304C\u8A00\u3046\u4E8B\u3092\u805E\u304B\u306A\u304F\u306A\u3063\u305F\u2026\u306A\u3093\u306A\u3093\u3060\u2026",
  "id" : 448808057963700224,
  "created_at" : "2014-03-26 13:05:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448791355813146625",
  "text" : "emacs\u3067\u52D5\u304FIRC\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8",
  "id" : 448791355813146625,
  "created_at" : "2014-03-26 11:59:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448791252255776768",
  "text" : "\u601D\u3044\u51FA\u3057\u305F",
  "id" : 448791252255776768,
  "created_at" : "2014-03-26 11:59:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448791199738908672",
  "text" : "\u4F55\u304B\u3084\u308D\u3046\u3068\u601D\u3063\u305F\u3093\u3060\u3051\u3069\u306A\u3093\u3060\u3063\u305F\u306E\uFF1F",
  "id" : 448791199738908672,
  "created_at" : "2014-03-26 11:58:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/JwOxcThRnM",
      "expanded_url" : "http:\/\/sp.nicovideo.jp\/watch\/sm12426559?via=thumb_watch",
      "display_url" : "sp.nicovideo.jp\/watch\/sm124265\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448774707945295872",
  "text" : "\u300C\u3093\u300D\u3092\u53D6\u308A\u7DE0\u307E\u308B\u8005\u305F\u3061http:\/\/t.co\/JwOxcThRnM",
  "id" : 448774707945295872,
  "created_at" : "2014-03-26 10:53:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448771687199162369",
  "geo" : { },
  "id_str" : "448772222203613184",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u3082\u3057\u304B\u3057\u3066:\u4F1D\u308F\u308A\u306B\u304F\u304B\u3063\u305F\u3060\u3051",
  "id" : 448772222203613184,
  "in_reply_to_status_id" : 448771687199162369,
  "created_at" : "2014-03-26 10:43:30 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/JwOxcThRnM",
      "expanded_url" : "http:\/\/sp.nicovideo.jp\/watch\/sm12426559?via=thumb_watch",
      "display_url" : "sp.nicovideo.jp\/watch\/sm124265\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "448750228598833154",
  "geo" : { },
  "id_str" : "448771139188166656",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2  http:\/\/t.co\/JwOxcThRnM \u77E5\u3063\u3066\u308B\u304B\u3068\u601D\u3063\u3066\u307E\u3057\u305F\u3001\u7121\u8336\u3076\u308A\u3057\u3066\u3059\u307F\u307E\u305B\u3093",
  "id" : 448771139188166656,
  "in_reply_to_status_id" : 448750228598833154,
  "created_at" : "2014-03-26 10:39:12 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u306C\u3069\u308C\u3044.dmng",
      "screen_name" : "inudorei4869",
      "indices" : [ 0, 13 ],
      "id_str" : "401255433",
      "id" : 401255433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448769991957958656",
  "geo" : { },
  "id_str" : "448770817455697922",
  "in_reply_to_user_id" : 401255433,
  "text" : "@inudorei4869 \u304A\u30FC\uFF01\u308F\u3056\u308F\u3056\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01",
  "id" : 448770817455697922,
  "in_reply_to_status_id" : 448769991957958656,
  "created_at" : "2014-03-26 10:37:55 +0000",
  "in_reply_to_screen_name" : "inudorei4869",
  "in_reply_to_user_id_str" : "401255433",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u306C\u3069\u308C\u3044.dmng",
      "screen_name" : "inudorei4869",
      "indices" : [ 0, 13 ],
      "id_str" : "401255433",
      "id" : 401255433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448764131412168704",
  "geo" : { },
  "id_str" : "448769783031275520",
  "in_reply_to_user_id" : 401255433,
  "text" : "@inudorei4869 url\u6295\u3052\u3066\u304F\u308C\u307E\u305B\u3093\uFF1F",
  "id" : 448769783031275520,
  "in_reply_to_status_id" : 448764131412168704,
  "created_at" : "2014-03-26 10:33:48 +0000",
  "in_reply_to_screen_name" : "inudorei4869",
  "in_reply_to_user_id_str" : "401255433",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448749758681579521",
  "text" : "\u3057\u3070\u3089\u304F\u308A\u3060\u3064",
  "id" : 448749758681579521,
  "created_at" : "2014-03-26 09:14:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448749010577154048",
  "text" : "\u300C\u3093\u300D\u3092\u53D6\u308A\u7DE0\u307E\u308B\u8005\u305F\u3061\u306E\u30CD\u30BF\u3001\u3080\u3057\u308D\u3042\u3061\u3083\u307F\u3093\u3042\u305F\u308A\u304C\u53CD\u5FDC\u3059\u308B\u304B\u3068\u601D\u3063\u305F\u304C",
  "id" : 448749010577154048,
  "created_at" : "2014-03-26 09:11:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u306C\u3069\u308C\u3044.dmng",
      "screen_name" : "inudorei4869",
      "indices" : [ 0, 13 ],
      "id_str" : "401255433",
      "id" : 401255433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448747782023557120",
  "geo" : { },
  "id_str" : "448748840410038272",
  "in_reply_to_user_id" : 401255433,
  "text" : "@inudorei4869 \u30AF\u30ED\u30CB\u30AF\u30EB\u3067\u3057\u305F\u3063\u3051\uFF1Fyoutube\u3068\u304B\u306B\u3042\u308A\u305D\u3046\u306A\u3082\u3093\u3067\u3059\u304C\u2026",
  "id" : 448748840410038272,
  "in_reply_to_status_id" : 448747782023557120,
  "created_at" : "2014-03-26 09:10:35 +0000",
  "in_reply_to_screen_name" : "inudorei4869",
  "in_reply_to_user_id_str" : "401255433",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448746097972740096",
  "geo" : { },
  "id_str" : "448748741072134144",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \u3068\u3001\u767B\u9332\u76F4\u5F8C\u306F\u914D\u724C\u826F\u304F\u306A\u308B\u4F1D\u8AAC\u304C\u3042\u308B\u304B\u3089(\u3057\u308D\u3081",
  "id" : 448748741072134144,
  "in_reply_to_status_id" : 448746097972740096,
  "created_at" : "2014-03-26 09:10:11 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448745534728069120",
  "geo" : { },
  "id_str" : "448745898567139328",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \u307B\u307B\u3046\u2026\uFF1F",
  "id" : 448745898567139328,
  "in_reply_to_status_id" : 448745534728069120,
  "created_at" : "2014-03-26 08:58:54 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3044\u306C\u3069\u308C\u3044.dmng",
      "screen_name" : "inudorei4869",
      "indices" : [ 0, 13 ],
      "id_str" : "401255433",
      "id" : 401255433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448745236982804481",
  "geo" : { },
  "id_str" : "448745424958939137",
  "in_reply_to_user_id" : 401255433,
  "text" : "@inudorei4869 \u30CD\u30BF\u304C\u901A\u3058\u308B\u4EBA\u304C\u5B58\u5728\u3057\u305F\u4E8B\u306B\u9A5A\u304D\u3067\u3059",
  "id" : 448745424958939137,
  "in_reply_to_status_id" : 448745236982804481,
  "created_at" : "2014-03-26 08:57:01 +0000",
  "in_reply_to_screen_name" : "inudorei4869",
  "in_reply_to_user_id_str" : "401255433",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448745342326943744",
  "text" : "\u60AA\u3044\u5927\u4EBA\u304C\u304A\u7C73\u3092\u708A\u304F\u306E\u306B\u4E0D\u6163\u308C\u306A\u5927\u4EBA\u306B\u5618\u3092\u5439\u304D\u8FBC\u3080\u56F3\u3001\u3068\u3066\u3082\u9762\u767D\u3044",
  "id" : 448745342326943744,
  "created_at" : "2014-03-26 08:56:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448744693405212673",
  "text" : "\u305D\u3046\u3044\u3084\u9031\u672B\u30DB\u30F3\u30A4\u30C4\u5F79\u724C\u30EA\u30F3\u30B7\u30E3\u30F3\u30C9\u30E9\u30C9\u30E9\u3067\u8DF3\u306D\u305F\u4E8B\u4EF6\u304C\u3042\u3063\u305F\u306A",
  "id" : 448744693405212673,
  "created_at" : "2014-03-26 08:54:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448744363179249664",
  "text" : "\u3042\u30FC\u3053\u308C\u306F\u300C\u3093\u300D\u3092\u53D6\u308A\u7DE0\u307E\u308B\u8005\u305F\u3061\u304C\u6765\u3066\u56F2\u3093\u3067\u68D2\u3067\u53E9\u304B\u308C\u308B\u3084\u3064\u3067\u3059\u308F",
  "id" : 448744363179249664,
  "created_at" : "2014-03-26 08:52:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448744250885152769",
  "text" : "\u81EA\u5206\u306E\u540D\u524D\u306E\u6700\u521D\u3068\u6700\u5F8C\u3092\u53D6\u3063\u305F\u3089\u304D\u3063\u3068\u30AB\u30EF\u30A4\u30A4\uFF1F\uFF1F\uFF1F\uFF1F\u300C\u3093\u300D",
  "id" : 448744250885152769,
  "created_at" : "2014-03-26 08:52:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448743409369366528",
  "text" : "\u5B87\u5B99\u8CE2\u8005\u6C0F\u306E\u30B9\u30EC\u30A4\u30D7\u30CB\u30EB\u306E\u305B\u3044\u3067\u30CB\u30E4\u30CB\u30E4\u304C\u6B62\u307E\u3089\u306A\u3044",
  "id" : 448743409369366528,
  "created_at" : "2014-03-26 08:49:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448743134600499200",
  "text" : "(^^)(^^)(^^)(^^)\u252C\u252C\u2190\u3053\u3044\u3064\u304C\u982D\u304C\u91CD\u3059\u304E\u305F\u305B\u3044\u3067\u9032\u5316\u306E\u904E\u7A0B\u3067\u6EC5\u3093\u3060\u3001\u3068\u3044\u3046\u8CE2\u8005\u77E5\u8B58\u3092\u6388\u3051\u3066\u6234\u3044\u305F",
  "id" : 448743134600499200,
  "created_at" : "2014-03-26 08:47:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 0, 9 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448742694383124480",
  "geo" : { },
  "id_str" : "448742841682911232",
  "in_reply_to_user_id" : 176127240,
  "text" : "@the_TQFT \u306A\u308B\u307B\u3069(^^)(^^)(^^)\u5727\u5012\u7684\u751F\u7269\u306E\u795E\u79D8(^^)(^^)(^^)",
  "id" : 448742841682911232,
  "in_reply_to_status_id" : 448742694383124480,
  "created_at" : "2014-03-26 08:46:45 +0000",
  "in_reply_to_screen_name" : "the_TQFT",
  "in_reply_to_user_id_str" : "176127240",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448742529345675264",
  "text" : "\u3081\u3063\u3061\u3083\u5FDC\u7528\u52B9\u304F\uFF01\uFF01\uFF01\uFF01\uFF01\uFF01",
  "id" : 448742529345675264,
  "created_at" : "2014-03-26 08:45:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B87\u5B99\u8CE2\u8005",
      "screen_name" : "the_TQFT",
      "indices" : [ 0, 9 ],
      "id_str" : "176127240",
      "id" : 176127240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448742025098059776",
  "geo" : { },
  "id_str" : "448742421124218880",
  "in_reply_to_user_id" : 176127240,
  "text" : "@the_TQFT (^^)(^^)(^^)\u252C\u252C\u3053\u3046\u3044\u3046\u5974\u306F\u3044\u307E\u3059\u304B\uFF1F",
  "id" : 448742421124218880,
  "in_reply_to_status_id" : 448742025098059776,
  "created_at" : "2014-03-26 08:45:05 +0000",
  "in_reply_to_screen_name" : "the_TQFT",
  "in_reply_to_user_id_str" : "176127240",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448742325494104064",
  "text" : "(^^)(^^)(^^)(^^)(^^)(^^)(^^)\u252C\u252C",
  "id" : 448742325494104064,
  "created_at" : "2014-03-26 08:44:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448741684302446592",
  "text" : "(^^)\u252C\u252C(^^)\u252C\u252C(^^)\u252C\u252C",
  "id" : 448741684302446592,
  "created_at" : "2014-03-26 08:42:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448741601653690370",
  "text" : "\u8CE2\u8005\u304C\u307E\u305F\u65B0\u305F\u306A\u5B87\u5B99\u9854\u6587\u5B57\u3092\u5275\u9020\u306A\u3055\u308C\u305F",
  "id" : 448741601653690370,
  "created_at" : "2014-03-26 08:41:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448741155648192512",
  "text" : "\u3084\u3063\u3071\u30B9\u30AD\u30EB\u30A2\u30C3\u30D7\u3082\u517C\u306D\u3066SE\u3081\u3044\u305F\u30A2\u30EB\u30D0\u30A4\u30C8\u63A2\u305D\u3046",
  "id" : 448741155648192512,
  "created_at" : "2014-03-26 08:40:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448740941403131904",
  "text" : "\u7121\u99C4\u306A\u6575\u3092\u4F5C\u308B\u306E\u306F\u7121\u99C4\u3060\u304B\u3089\u3084\u3081\u3088\u3046",
  "id" : 448740941403131904,
  "created_at" : "2014-03-26 08:39:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448740857500270593",
  "text" : "\u307E\u3041\u307E\u3041\u5404\u3005\u65B9\u3001\u307E\u3060\u5E2F\u5E83\u755C\u7523\u5927\u5B66\u306E\u8A71\u306F\u3057\u3066\u3044\u306A\u3044\u3067\u306F\u306A\u3044\u304B",
  "id" : 448740857500270593,
  "created_at" : "2014-03-26 08:38:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448740710590586880",
  "text" : "\u4EAC\u5927\u3001\u540C\u5FD7\u793E\u3001\u7ACB\u547D\u3001\u4EAC\u90FD\u5E9C\u7ACB\u4E91\u3005",
  "id" : 448740710590586880,
  "created_at" : "2014-03-26 08:38:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448740307103154176",
  "geo" : { },
  "id_str" : "448740489068421120",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 [\u4EAC\u90FD\u304C\u3084\u3070\u304B\u3063\u305F\u3060\u3051\u3068\u3044\u3046\u8AAC\u306F\u3042\u308A\u305D\u3046]",
  "id" : 448740489068421120,
  "in_reply_to_status_id" : 448740307103154176,
  "created_at" : "2014-03-26 08:37:24 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448740240044208128",
  "text" : "\u8A00\u3044\u305F\u3044\u3060\u3051\u30CB\u30F3\u30B2\u30F3",
  "id" : 448740240044208128,
  "created_at" : "2014-03-26 08:36:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448740166614544384",
  "text" : "\u3042\u30FC\u300C\u98FD\u548C\u98FD\u548C\u3057\u3066\u308B\u300D\u3063\u3066\u8A00\u3044\u305F\u3044\u3060\u3051\u306B\u306A\u3063\u3061\u3083\u3063\u305F",
  "id" : 448740166614544384,
  "created_at" : "2014-03-26 08:36:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448739877366951936",
  "text" : "\u5927\u5B66\u306E\u5468\u308A\u306F\u98FD\u548C\u98FD\u548C\u3057\u304C\u3061\u3060\u3088\u306A\u2026",
  "id" : 448739877366951936,
  "created_at" : "2014-03-26 08:34:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448739823562407936",
  "text" : "\u4EAC\u90FD\u3082\u5BB6\u5EAD\u6559\u5E2B\u30CB\u30F3\u30B2\u30F3\u306F\u98FD\u548C\u98FD\u548C\u3057\u3066\u305F\u304B\u3089\u306A\u30FC",
  "id" : 448739823562407936,
  "created_at" : "2014-03-26 08:34:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448739480573186048",
  "geo" : { },
  "id_str" : "448739672722636800",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u3046\u30FC\u3093\u3001\u98FD\u548C\u98FD\u548C\u3057\u3066\u305D\u3046\u306A\u611F\u3058\u3060\u3002\u6559\u3048\u3066\u304F\u308C\u3066\u3042\u308A\u304C\u3068\u3046\u3002",
  "id" : 448739672722636800,
  "in_reply_to_status_id" : 448739480573186048,
  "created_at" : "2014-03-26 08:34:09 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448739317548986368",
  "text" : "\u5272\u308C\u3066\u305F\u80CC\u9762\u306E\u5206\u3060\u3051\u3067\u826F\u304B\u3063\u305F\u3093\u3060\u3051\u3069\u80CC\u9762\u306E\u4FDD\u8B77\u30B7\u30FC\u30EB\u3060\u3051\u3063\u3066\u58F2\u3063\u3066\u306A\u3044\u307F\u305F\u3044",
  "id" : 448739317548986368,
  "created_at" : "2014-03-26 08:32:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448739206089568256",
  "text" : "\u30A2\u30A4\u30D5\u30A3\u30E8\u30E8\u30F3\u306E\u30AB\u30F4\u30A1\u30FC\u30B7\u30FC\u30EB\u3092\u5909\u3048\u305F",
  "id" : 448739206089568256,
  "created_at" : "2014-03-26 08:32:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448738713258840064",
  "text" : "\u4E92\u3044\u306B\u300C\u6C17\u3092\u9063\u308F\u305B\u3066\u3044\u308B\u3068\u3044\u3046\u4E8B\u5B9F\u306B\u6C17\u3092\u9063\u3046\u300D\u4E8B\u306B\u3088\u3063\u3066\u7121\u9650\u306B\u6C17\u3092\u9063\u3044\u7D9A\u3051\u3066\u6B7B\u306C",
  "id" : 448738713258840064,
  "created_at" : "2014-03-26 08:30:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448738488314118144",
  "text" : "\u9063\u3046",
  "id" : 448738488314118144,
  "created_at" : "2014-03-26 08:29:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448738470479949826",
  "text" : "\u6C17\u3092\u4F7F\u3046\u30B9\u30D1\u30A4\u30E9\u30EB\u306B\u4F3C\u3066\u308B",
  "id" : 448738470479949826,
  "created_at" : "2014-03-26 08:29:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448738080640360448",
  "text" : "\u30DB\u30F3\u30DE\u304B",
  "id" : 448738080640360448,
  "created_at" : "2014-03-26 08:27:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448738055260602368",
  "text" : "\u6C17\u3092\u3064\u3051\u904E\u304E\u3066\u6B7B\u3093\u3060\u5974\u306F\u3044\u306A\u3044",
  "id" : 448738055260602368,
  "created_at" : "2014-03-26 08:27:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448737524983136256",
  "text" : "\u300C\u3075\u3063\u300D\u3063\u3066\u601D\u3063\u3066\u3082\u5FC3\u306B\u7559\u3081\u3066\u304A\u3051\u306A\u3044\u5974\u306F\u4F55\u3092\u3084\u3063\u3066\u3082\u30C0\u30E1",
  "id" : 448737524983136256,
  "created_at" : "2014-03-26 08:25:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448737335937482752",
  "text" : "\u4F55\u304B\u3068\u805E\u3044\u3066\u300C\u3075\u3063\u300D\u3063\u3066\u9F3B\u3067\u7B11\u3046\u3088\u3046\u306A\u4EBA\u9593\u3001\u60AA\u3044\u5370\u8C61\u3057\u304B\u4E0E\u3048\u306A\u3044",
  "id" : 448737335937482752,
  "created_at" : "2014-03-26 08:24:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(\u3042\u3093\u3061\u3079! \u4FFA\u304CS\u5F0F\u3060)",
      "screen_name" : "AntiBayesian",
      "indices" : [ 3, 16 ],
      "id_str" : "432456879",
      "id" : 432456879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448737210339061761",
  "text" : "RT @AntiBayesian: Java\u306B\u9650\u3089\u305A\u300C\u25CB\u25CB\u8A00\u8A9E\u3068\u805E\u3044\u3066\u3001\u3075\u3063\u3068\u9F3B\u3067\u7B11\u3046\u300D\u3088\u3046\u306A\u6280\u8853\u8005\u3001\u7D76\u5BFE\u63A5\u89E6\u3057\u305F\u304F\u306A\u3044",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448736875524538368",
    "text" : "Java\u306B\u9650\u3089\u305A\u300C\u25CB\u25CB\u8A00\u8A9E\u3068\u805E\u3044\u3066\u3001\u3075\u3063\u3068\u9F3B\u3067\u7B11\u3046\u300D\u3088\u3046\u306A\u6280\u8853\u8005\u3001\u7D76\u5BFE\u63A5\u89E6\u3057\u305F\u304F\u306A\u3044",
    "id" : 448736875524538368,
    "created_at" : "2014-03-26 08:23:02 +0000",
    "user" : {
      "name" : "(\u3042\u3093\u3061\u3079! \u4FFA\u304CS\u5F0F\u3060)",
      "screen_name" : "AntiBayesian",
      "protected" : false,
      "id_str" : "432456879",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551365370351607810\/kAqQHvgc_normal.png",
      "id" : 432456879,
      "verified" : false
    }
  },
  "id" : 448737210339061761,
  "created_at" : "2014-03-26 08:24:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448736694888452096",
  "geo" : { },
  "id_str" : "448736971758649344",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u78BA\u304B\u306B\u78BA\u304B\u306B\u3002\u6642\u306B\u3046\u307F\u3061\u3083\u3093\u30A2\u30EB\u30D0\u30A4\u30C8\u3063\u3066\u3057\u3066\u307E\u3059\uFF1F[\u5BB6\u5EAD\u6559\u5E2B\uFF1F]",
  "id" : 448736971758649344,
  "in_reply_to_status_id" : 448736694888452096,
  "created_at" : "2014-03-26 08:23:25 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448736518090133504",
  "text" : "\u3068\u306F\u3044\u3048\u30BF\u30AF\u30B7\u30FC\u4E57\u3063\u305F\u3089\u3081\u3063\u3061\u3083\u30AC\u30BF\u30AC\u30BF\u3057\u305F[\u3055\u308A\u3052\u306A\u3044\u30D6\u30EB\u30B8\u30E7\u30EF\u30B8\u30FC\u30A2\u30C3\u30D4\u30EB]",
  "id" : 448736518090133504,
  "created_at" : "2014-03-26 08:21:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448736164711632897",
  "geo" : { },
  "id_str" : "448736355699286017",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u3067\u3082\u3053\u306E\u4F4D\u306E\u96EA\u306E\u7121\u3055\u306A\u3089\u539F\u4ED8\u6301\u3063\u3066\u6765\u3066\u3082\u826F\u304B\u3063\u305F\u304B\u306A\u30FC\u3068\u3082\u601D\u3063\u3066\u307E\u3059[\u8ECA\u6B32\u3057\u3044]",
  "id" : 448736355699286017,
  "in_reply_to_status_id" : 448736164711632897,
  "created_at" : "2014-03-26 08:20:58 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448736163147169792",
  "text" : "\u5B63\u7BC0\u306E\u5909\u308F\u308A\u76EE\u3068\u304B\u82B1\u7C89\u3068\u304B\u30DB\u30B3\u30EA\u3068\u304B\u30A2\u30EC\u30EB\u30AE\u30FC\u95A2\u9023\u306F\u4F75\u767A\u3057\u3059\u304E\u3066\u3066\u4F55\u304C\u539F\u56E0\u306A\u306E\u304B\u7279\u5B9A\u3059\u308B\u306E\u306F\u7121\u7406",
  "id" : 448736163147169792,
  "created_at" : "2014-03-26 08:20:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448735705104015360",
  "geo" : { },
  "id_str" : "448735997723824128",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u5F15\u3063\u8D8A\u3057\u306E\u969B\u306E\u30DB\u30B3\u30EA\u306B\u3088\u308B\u30A2\u30EC\u30EB\u30AE\u30FC\u3068\u533A\u5225\u3067\u304D\u306A\u3044\u306E\u3067\u3042\u308C\u3067\u3059\u304C\u6771\u4EAC\u3068\u6BD4\u3079\u305F\u3089\u304B\u306A\u308A\u30DE\u30B7\u306A\u611F\u3058\u3067\u306F\u3042\u308A\u307E\u3059",
  "id" : 448735997723824128,
  "in_reply_to_status_id" : 448735705104015360,
  "created_at" : "2014-03-26 08:19:33 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448735480528400384",
  "text" : "\u7121\u3044\u3082\u306E\u3092\u63A2\u3057\u3066\u3082\u7121\u3044\u304B\u3089\u306A\u3041",
  "id" : 448735480528400384,
  "created_at" : "2014-03-26 08:17:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448735434202300416",
  "text" : "\u4ED6\u306B\u4F55\u304C\u7121\u3044\u3093\u3060\u2026",
  "id" : 448735434202300416,
  "created_at" : "2014-03-26 08:17:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448735195974217728",
  "geo" : { },
  "id_str" : "448735387762950145",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u306A\u306B\u305D\u308C\u4E0D\u5B89[\u6749\u82B1\u7C89\u304C\u306A\u3044\u306E\u306F\u7D20\u6674\u3089\u3057\u3044\u3051\u3069]",
  "id" : 448735387762950145,
  "in_reply_to_status_id" : 448735195974217728,
  "created_at" : "2014-03-26 08:17:08 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448734881200107520",
  "geo" : { },
  "id_str" : "448734969444057088",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 \u3044\u3048\u3059\uFF01",
  "id" : 448734969444057088,
  "in_reply_to_status_id" : 448734881200107520,
  "created_at" : "2014-03-26 08:15:28 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448734284048654336",
  "text" : "4000\u5186\u306E\u30E9\u30BA\u30D9\u30EA\u30FC\u30D1\u30A4\u3063\u3066\u8A00\u3046\u3068\u3080\u3063\u3061\u3083\u9AD8\u7D1A\u30B9\u30A4\u30FC\u30C4\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u51FA\u308B",
  "id" : 448734284048654336,
  "created_at" : "2014-03-26 08:12:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448734143539462144",
  "text" : "\u63A2\u3057\u65B9\u304C\u60AA\u3044\u306E\u304B\u3082\u3057\u308C\u306A\u3044\u3057\u6271\u3063\u3066\u306A\u3044\u306E\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 448734143539462144,
  "created_at" : "2014-03-26 08:12:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448734000509509632",
  "text" : "\u30D3\u30C3\u30AF\u30AB\u30E1\u30E9\u3067\u30E9\u30BA\u30D9\u30EA\u30FC\u30D1\u30A4\u773A\u3081\u3088\u3046\u3068\u601D\u3063\u305F\u3051\u3069\u58F2\u3063\u3066\u306A\u304B\u3063\u305F",
  "id" : 448734000509509632,
  "created_at" : "2014-03-26 08:11:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448733807114321920",
  "text" : "\u304B\u305E\u304F\u3068\u6226\u3046\u4EBA\u306E\u3001\u4E73\u9178\u83CC",
  "id" : 448733807114321920,
  "created_at" : "2014-03-26 08:10:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448733371938504704",
  "text" : "\u4E00\u65E5\u6B69\u3044\u3066\u8DB3\u306B\u4E73\u9178\u83CC\u304C\u6E9C\u307E\u3063\u3066\u308B\u3045",
  "id" : 448733371938504704,
  "created_at" : "2014-03-26 08:09:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448645723928551424",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 448645723928551424,
  "created_at" : "2014-03-26 02:20:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448645709487562752",
  "text" : "\u3053\u308C\u3067\u5317\u533A\u306B\u5E30\u5B85\u3059\u308B\u65E5\u3005\u3092\u9001\u308C\u308B",
  "id" : 448645709487562752,
  "created_at" : "2014-03-26 02:20:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448644807083040768",
  "text" : "@\u90F5\u4FBF\u5C40\u30DE\u30F3 \u5C11\u3005\u639B\u3051\u3066\u304A\u5F85\u3061\u3057\u3066\u304A\u308A\u307E\u3059",
  "id" : 448644807083040768,
  "created_at" : "2014-03-26 02:17:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448634829144215553",
  "text" : "\u8CA1\u5E03\u304B\u3089\u304F\u3063\u3061\u3093\u3071\u306E\u3082\u306E\u3068\u601D\u3057\u304D\u96FB\u8A71\u756A\u53F7\u3068\u300C\u3086\u300D\u3068\u3060\u3051\u66F8\u304B\u308C\u305F\u4ED8\u7B8B\u304C\u51FA\u3066\u6765\u305F\u6642\u306E\u9854\u30B3\u30F3\u30C6\u30B9\u30C82014\u3067\u512A\u52DD\u51FA\u6765\u305D\u3046",
  "id" : 448634829144215553,
  "created_at" : "2014-03-26 01:37:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448622301404094464",
  "text" : "\u30D4\u30AB\u30F3\u30C6\u30A3\u3001\u3080\u3063\u3061\u3083\u8FD1\u3044",
  "id" : 448622301404094464,
  "created_at" : "2014-03-26 00:47:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448621990237065216",
  "text" : "\u5F15\u3063\u8D8A\u3057\u30CB\u30F3\u30B2\u30F3",
  "id" : 448621990237065216,
  "created_at" : "2014-03-26 00:46:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448599512064335872",
  "text" : "\u5317\u6D77\u9053\u306B\u6749\u306F\u7121\u3044\u304C\u82B1\u7C89\u304C\u7121\u3044\u3068\u306F\u8A00\u3063\u3066\u3044\u306A\u3044\u9854",
  "id" : 448599512064335872,
  "created_at" : "2014-03-25 23:17:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448593253625905152",
  "text" : "\u7A81\u7136\u306E\u4EBA\u6A29",
  "id" : 448593253625905152,
  "created_at" : "2014-03-25 22:52:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448592869507338240",
  "text" : "\u304A\u3068\u3046\u3055\u3093\u30B9\u30A4\u30C3\u30C1\u300C\u307E\u300D\n\u771F\u9854",
  "id" : 448592869507338240,
  "created_at" : "2014-03-25 22:50:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448592714175488000",
  "text" : "\u771F\u9854",
  "id" : 448592714175488000,
  "created_at" : "2014-03-25 22:50:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448592687592005632",
  "text" : "\u307E\u3063\u3001\u307E\u3063\u3001\u307E\u3063",
  "id" : 448592687592005632,
  "created_at" : "2014-03-25 22:50:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448575085851340800",
  "text" : "\u3042\u3055",
  "id" : 448575085851340800,
  "created_at" : "2014-03-25 21:40:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448473973978710016",
  "text" : "\u6A5F\u3092\u898B\u3066\uFF0C\u68EE\u3092\u898B\u305A",
  "id" : 448473973978710016,
  "created_at" : "2014-03-25 14:58:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448473907188621313",
  "text" : "\u6728\u3092\u898B\u3066\uFF0CEmacs\u3067\u52D5\u304FIRC\u3067\u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u3092\u5165\u308C\u3088\u3046\uFF0Eloqui\u304C\u306A\u3093\u304B\u52D5\u304B\u306A\u3044",
  "id" : 448473907188621313,
  "created_at" : "2014-03-25 14:58:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448461656750714880",
  "text" : "\u3042\u308Cloqui\u304C\u4E0A\u624B\u304F\u52D5\u3044\u3066\u306A\u3044",
  "id" : 448461656750714880,
  "created_at" : "2014-03-25 14:09:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448429241797853184",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 448429241797853184,
  "created_at" : "2014-03-25 12:00:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448427873578151936",
  "text" : "\u672D\u5E4C",
  "id" : 448427873578151936,
  "created_at" : "2014-03-25 11:55:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Iat4yH7Ivo",
      "expanded_url" : "http:\/\/4sq.com\/1pvn4Rc",
      "display_url" : "4sq.com\/1pvn4Rc"
    } ]
  },
  "geo" : { },
  "id_str" : "448409472533528576",
  "text" : "I'm at \u65B0\u5343\u6B73\u7A7A\u6E2F (New Chitose Airport) (CTS\/RJCC) (\u5343\u6B73\u5E02, \u5317\u6D77\u9053) w\/ 7 others http:\/\/t.co\/Iat4yH7Ivo",
  "id" : 448409472533528576,
  "created_at" : "2014-03-25 10:42:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448282248400236544",
  "text" : "\u5352\u696D\u5F0F\uFF1F\u4ECA\u8D77\u304D\u305F\u308F",
  "id" : 448282248400236544,
  "created_at" : "2014-03-25 02:16:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448114322011484160",
  "text" : "\u307B\u3093\u307E\u304B",
  "id" : 448114322011484160,
  "created_at" : "2014-03-24 15:09:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448113506047385602",
  "geo" : { },
  "id_str" : "448113741767663616",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u73FE\u4EE3\u4EBA\u306F\u5FD9\u3057\u3044\u304B\u3089\u901F\u3055\u304C\u6C42\u3081\u3089\u308C\u308B\u306E\u306F\u5F53\u7136\u306E\u7D50\u679C",
  "id" : 448113741767663616,
  "in_reply_to_status_id" : 448113506047385602,
  "created_at" : "2014-03-24 15:06:56 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448112776188133376",
  "text" : "\u30DC\u30B4\u30BD\u30FC\u30C8\u304C\u4E16\u754C\u3067\u611B\u3055\u308C\u3066\u3044\u308B\u611F\u3058\u306A\u306E\u3069\u3046\u8003\u3048\u3066\u3082\u5947\u5999",
  "id" : 448112776188133376,
  "created_at" : "2014-03-24 15:03:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448112349845540864",
  "text" : "\u3048\u3093\u3069\u3055\u3093\u5351\u602F\u8AAC\u3063\u307D\u3044\u306E\u6709\u529B\u3081\u3044\u305F\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3063\u307D\u3044\u611F\u3058\u306E\u4F55\u304B",
  "id" : 448112349845540864,
  "created_at" : "2014-03-24 15:01:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448112132278611968",
  "geo" : { },
  "id_str" : "448112207989977088",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u3088\u304F\u8A00\u308F\u308C\u308B\u3063\u307D\u3044",
  "id" : 448112207989977088,
  "in_reply_to_status_id" : 448112132278611968,
  "created_at" : "2014-03-24 15:00:50 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448112064414769153",
  "text" : "\u3042\u30FC\u308F\u304B\u308B\u3063\u307D\u3044",
  "id" : 448112064414769153,
  "created_at" : "2014-03-24 15:00:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448111964640665600",
  "geo" : { },
  "id_str" : "448112026733117440",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u305D\u308C\u3063\u307D\u3044",
  "id" : 448112026733117440,
  "in_reply_to_status_id" : 448111964640665600,
  "created_at" : "2014-03-24 15:00:07 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448111795534696448",
  "text" : "\u87F9\u3063\u307D\u3044\u5473\u306F\u3001\u87F9\u306E\u5473\u3058\u3083\u306A\u3044\u304B\u3089\u306A",
  "id" : 448111795534696448,
  "created_at" : "2014-03-24 14:59:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448111722495086593",
  "text" : "\u307E\u3041\u201D\u3063\u307D\u3044\u201D\u306A\u306E\u3067",
  "id" : 448111722495086593,
  "created_at" : "2014-03-24 14:58:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448111641666674688",
  "text" : "\u3042\u3001\u963F\u4F50\u30F6\u8C37\u3063\u307D\u3044\u30B5\u30E9\u30C0\u3001\u7279\u306B\u963F\u4F50\u30F6\u8C37\u8981\u7D20\u7121\u304B\u3063\u305F\u3067\u3059",
  "id" : 448111641666674688,
  "created_at" : "2014-03-24 14:58:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448110947882631170",
  "text" : "\u3068\u3044\u3046\u3084\u308A\u53D6\u308A\u304C\u3042\u3063\u305F\u3051\u3069\u9B31\u9676\u3057\u3044\u5BA2\u3060\u306A",
  "id" : 448110947882631170,
  "created_at" : "2014-03-24 14:55:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448110903729213440",
  "text" : "\u5E97\u54E1\u3055\u3093\u300C\u3053\u3061\u3089\u963F\u4F50\u30F6\u8C37\u3063\u307D\u3044\u30B5\u30E9\u30C0\u306B\u306A\u308A\u307E\u30FC\u3059\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u4F3A\u3044\u306B\u304F\u3044\u306E\u3067\u3059\u304C\u3001\u3069\u306E\u8FBA\u304C\u963F\u4F50\u30F6\u8C37\u3063\u307D\u3044\u3093\u3067\u3059\u304B\uFF1F\u300D\n\u5E97\u54E1\u3055\u3093\u300C\u305D\u3053\u3089\u3078\u3093\u306F\u3053\u3046\u3001\u30A4\u30DE\u30B8\u30CD\u30FC\u30B7\u30E7\u30F3\u3067\u3001\u306A\u3093\u3068\u304B\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u4EFB\u305B\u3066\u304F\u3060\u3055\u3044\u3001\u5F97\u610F\u5206\u91CE\u3067\u3059\u300D",
  "id" : 448110903729213440,
  "created_at" : "2014-03-24 14:55:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448110091829383169",
  "text" : "\u307B\u3052\u30FC\u3075\u304C\u30FC",
  "id" : 448110091829383169,
  "created_at" : "2014-03-24 14:52:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448109873297764352",
  "text" : "\u305D\u308A\u3083\u3042\u5BB6\u65CF\u306B\u8108\u7D61\u306A\u304F\u300C\u3086\u3086\u5F0F\u306F\u6C38\u9060\u3001\u3086\u3086\u5F0F\u306F\u6551\u3044\u300D\u3068\u304B\u8A00\u3063\u3066\u305F\u3089\u3055\u3059\u304C\u306B\u75C5\u9662\u9001\u308A\u306E\u30B3\u30FC\u30B9\u307E\u3067\u898B\u3048\u3066\u6765\u307E\u3059\u304B\u3089\u306D",
  "id" : 448109873297764352,
  "created_at" : "2014-03-24 14:51:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448109465322008576",
  "geo" : { },
  "id_str" : "448109679160197120",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u307E\u3041\u50D5\u3082\u305D\u3053\u307E\u3067\u9732\u9AA8\u306A\u4E8B\u8A00\u3063\u3066\u306A\u3044\u3067\u3059\u304B\u3089\u306D\u2026[\u3042\u3068\u5F1F\u304C\u6F2B\u753B\u3068\u304B\u30A2\u30CB\u30E1\u3068\u304B[\u6DF1\u591C\u3067\u306F\u306A\u3044]\u304B\u306A\u308A\u898B\u3066\u308B\u306E\u3067\uFF1F]",
  "id" : 448109679160197120,
  "in_reply_to_status_id" : 448109465322008576,
  "created_at" : "2014-03-24 14:50:47 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448109410259189761",
  "text" : "\u5225\u306B\u3044\u308F\u3086\u308B\u30AA\u30BF\u30AF\u6271\u3044\u306F\u3055\u308C\u3066\u306A\u3044\u3067\u3059\uFF1F",
  "id" : 448109410259189761,
  "created_at" : "2014-03-24 14:49:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448109243367837698",
  "text" : "\u504F\u3063\u305F\u77E5\u8B58\u304C\u504F\u3063\u3066\u504F\u3063\u305F\u7D50\u679C\u306E\u504F\u308A",
  "id" : 448109243367837698,
  "created_at" : "2014-03-24 14:49:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448109169770373123",
  "text" : "\u3048\u3093\u3069\u300C\u3042\u3001\u3053\u306E\u66F2\u3001\u5316\u7269\u8A9E\u306EBGM\u3060\u300D\n\u5BB6\u65CF\u300C\u3075\u30FC\u3093\u300D\n\n\u3048\u3093\u3069\u300C\u3053\u308C\u65B0\u6D77\u8AA0\u304C\u4F5C\u3063\u305F\u3084\u3064\u3060\u300D\n\u5BB6\u65CF\u300C\u3075\u30FC\u3093\u300D",
  "id" : 448109169770373123,
  "created_at" : "2014-03-24 14:48:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u540D\u79F0\u4E0D\u5B9A",
      "screen_name" : "llovefriday",
      "indices" : [ 0, 12 ],
      "id_str" : "2224069814",
      "id" : 2224069814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448071360003063809",
  "geo" : { },
  "id_str" : "448105871604604929",
  "in_reply_to_user_id" : 2224069814,
  "text" : "@llovefriday \u306A\u306B\u3057\u308D\u6771\u4EAC\u306B\u3044\u3066\u5317\u6D77\u9053\u306B\u65C5\u7ACB\u3064\u65E5\u306A\u306E\u3067\u3061\u3087\u3063\u3068\u5FD9\u3057\u3044\u3067\u3059",
  "id" : 448105871604604929,
  "in_reply_to_status_id" : 448071360003063809,
  "created_at" : "2014-03-24 14:35:39 +0000",
  "in_reply_to_screen_name" : "llovefriday",
  "in_reply_to_user_id_str" : "2224069814",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448055770504896512",
  "text" : "\u820C\u3092\u3084\u3051\u3069\u3057\u305F\u4EBA\u9593\u306E\u56F3",
  "id" : 448055770504896512,
  "created_at" : "2014-03-24 11:16:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448035226703241216",
  "text" : "\u3054\u98EF\u304C\u30AA\u30FC\u30C8\u306B\u51FA\u3066\u304F\u308B\u5206\u3088\u308A\u5815\u843D\u3057\u3066\u3044\u308B\u3068\u3044\u3046\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3042\u308B",
  "id" : 448035226703241216,
  "created_at" : "2014-03-24 09:54:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448035160634576896",
  "text" : "\u5B9F\u5BB6\u3067\u3082\u70AC\u71F5\u304B\u3089\u51FA\u306A\u3044\u3057\u30A6\u30FC\u30ED\u30F3\u8336\u98F2\u3093\u3067\u308B\u3057PC\u3044\u3058\u3063\u3066\u3070\u3063\u304B\u3060\u3057\u663C\u5BDD\u3059\u308B\u3057\u4E00\u4F53\u4F55\u306A\u3093\u3060",
  "id" : 448035160634576896,
  "created_at" : "2014-03-24 09:54:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448028491783499776",
  "text" : "\u304A\u3053\u308F\u305F\u3079\u305F\u3044",
  "id" : 448028491783499776,
  "created_at" : "2014-03-24 09:28:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448026438571028480",
  "text" : "\u3075\u3049\u30FC\u30FC\u3093",
  "id" : 448026438571028480,
  "created_at" : "2014-03-24 09:20:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447948007153991680",
  "text" : "todo \u6587\u5B57\u30B3\u30FC\u30C9\uFF0C\u30C7\u30A3\u30EC\u30AF\u30C8\u30EA",
  "id" : 447948007153991680,
  "created_at" : "2014-03-24 04:08:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 0, 11 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447933656816836608",
  "geo" : { },
  "id_str" : "447934254916194304",
  "in_reply_to_user_id" : 221377214,
  "text" : "@y_misasagi \u5FAE\u5999\u3068\u304B\u8A00\u3046\u306A\u5931\u793C\u3060\u308D",
  "id" : 447934254916194304,
  "in_reply_to_status_id" : 447933656816836608,
  "created_at" : "2014-03-24 03:13:43 +0000",
  "in_reply_to_screen_name" : "y_misasagi",
  "in_reply_to_user_id_str" : "221377214",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447921631810174976",
  "text" : "700\/h\u306F\u9AD8\u3044\u9AD8\u3044",
  "id" : 447921631810174976,
  "created_at" : "2014-03-24 02:23:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3086\u3089\u308A\u306E\u3089\u308A",
      "screen_name" : "yurariandnorari",
      "indices" : [ 0, 16 ],
      "id_str" : "136960189",
      "id" : 136960189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447880405656829953",
  "geo" : { },
  "id_str" : "447899642533912577",
  "in_reply_to_user_id" : 136960189,
  "text" : "@yurariandnorari \u4F55\u3092\u8A00\u3063\u3068\u308B\u3093\u3058\u3083",
  "id" : 447899642533912577,
  "in_reply_to_status_id" : 447880405656829953,
  "created_at" : "2014-03-24 00:56:11 +0000",
  "in_reply_to_screen_name" : "yurariandnorari",
  "in_reply_to_user_id_str" : "136960189",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447806254736363521",
  "text" : "\u4EAC\u90FD\u3067\u7559\u5E74\u3059\u308B\u3079\u304D\u3060\u3063\u305F\u306E\u304B\u3082\u3057\u308C\u306A\u3044\u3068\u3044\u3046\u8B0E\u306E\u611F\u899A\u306B\u8972\u308F\u308C\u3066\u3044\u308B\u5348\u524D3\u6642",
  "id" : 447806254736363521,
  "created_at" : "2014-03-23 18:45:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447806115611303936",
  "text" : "\u4E00\u5E74\u304F\u3089\u3044\u4FEE\u884C\u306E\u671F\u9593\u304C\u6B32\u3057\u3044\u2026",
  "id" : 447806115611303936,
  "created_at" : "2014-03-23 18:44:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447722362155192320",
  "text" : "\u3042\u30FC\u306D\u3053\u3068\u3075\u308C\u3042\u3044\u305F\u3044\u6B32\u6C42 is \u3042\u308B \u306A\u3041",
  "id" : 447722362155192320,
  "created_at" : "2014-03-23 13:11:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447717247641866240",
  "text" : "\u3042\u305F\u30FC\u305F\u30FC\u304B\u30FC\u3044\u307F\u305A\u306B\u30FC\u3044\u304A\u3088\u3050\u3067\u3068\u308A\u30FC\u305F\u30FC\u3059\u30FC",
  "id" : 447717247641866240,
  "created_at" : "2014-03-23 12:51:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447716866958434305",
  "text" : "\u307B\u3052\u307B\u3052\u3075\u304C\u3075\u304C\u3074\u3088\u3074\u3088\u3075\u30FC\u3070\u30FC",
  "id" : 447716866958434305,
  "created_at" : "2014-03-23 12:49:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447716389730537472",
  "text" : "\u307E\u3041\u3057\u304B\u305F\u306A\u3044\u306D\uFF0E",
  "id" : 447716389730537472,
  "created_at" : "2014-03-23 12:48:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447716366401814528",
  "text" : "\u305D\u3046\u304B\uFF0C\u660E\u5F8C\u65E5\u5352\u696D\u5F0F\u304B\uFF0E\u51FA\u308C\u306A\u3044\u3051\u308C\u3069\uFF0E",
  "id" : 447716366401814528,
  "created_at" : "2014-03-23 12:47:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447715486868840448",
  "text" : "\u3046\u30FC\u3093.\u3046\u30FC\u3093\uFF0E\u3046\u30FC\u3093.\u3046\u30FC\u3093\uFF0E\u3046\u30FC\u3093.\u3046\u30FC\u3093\uFF0E\u3046\u30FC\u3093.\u3046\u30FC\u3093\uFF0E\u3046\u30FC\u3093.\u3046\u30FC\u3093\uFF0E\u3046\u30FC\u3093.\u3046\u30FC\u3093\uFF0E\u3046\u30FC\u3093.\u3046\u30FC\u3093\uFF0E\u3046\u30FC\u3093.\u3046\u30FC\u3093\uFF0E\u3068\u3044\u3046\u611F\u3058\uFF0E",
  "id" : 447715486868840448,
  "created_at" : "2014-03-23 12:44:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447713610605666304",
  "text" : "\u30C6\u30EC\u30D3\u30D4\u30FC\u30D7\u30EB",
  "id" : 447713610605666304,
  "created_at" : "2014-03-23 12:36:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447713567760871424",
  "text" : "\u89AA\u304C\u7D50\u69CB\u30C6\u30EC\u30D3\u4EBA\u9593\u3060\u3063\u305F\u308A\u3059\u308B\uFF0E",
  "id" : 447713567760871424,
  "created_at" : "2014-03-23 12:36:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447711721558253568",
  "geo" : { },
  "id_str" : "447713519782207489",
  "in_reply_to_user_id" : 427714784,
  "text" : "@miattermeyer \u306A\u308B\u307B\u3069\u2026\u5B9F\u5BB6\u3067\u3057\u304B\u898B\u306A\u3044\u306E\u3067\u30A2\u30EC\u3067\u3059\u304C\u3084\u3063\u3071\u308A\u305D\u3046\u3067\u3059\u304B\u2026",
  "id" : 447713519782207489,
  "in_reply_to_status_id" : 447711721558253568,
  "created_at" : "2014-03-23 12:36:35 +0000",
  "in_reply_to_screen_name" : "miantomori",
  "in_reply_to_user_id_str" : "427714784",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447711104345448448",
  "text" : "\u306A\u3093\u3060\u304B\u3082\u3046\uFF0C\u30C6\u30EC\u30D3\u3092\u7D20\u76F4\u306B\u697D\u3057\u3081\u306A\u3044\u4EBA\u9593\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F\u3088\u3046\u3060",
  "id" : 447711104345448448,
  "created_at" : "2014-03-23 12:27:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447708470104449025",
  "text" : "\u305A\u3082\u3082\u3082\u3082\u3082\u3082\u3082\u3082\u3082",
  "id" : 447708470104449025,
  "created_at" : "2014-03-23 12:16:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447704603312668672",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 447704603312668672,
  "created_at" : "2014-03-23 12:01:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447704367261442048",
  "text" : "\u97F3\u306E\u30BD\u30CE\u30EA\u30C6\u30A3",
  "id" : 447704367261442048,
  "created_at" : "2014-03-23 12:00:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447666049966551040",
  "text" : "\u7AEF\u672B\u3067\u8D77\u52D5\u3059\u308B\u3068\u9EC4\u7DD1\u8272\u80CC\u666F\u306B\u306A\u3063\u3066\u3068\u3066\u3082\u8AAD\u307F\u306B\u304F\u3044",
  "id" : 447666049966551040,
  "created_at" : "2014-03-23 09:27:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447664253219000320",
  "text" : "\u30DE\u30B9\u30B3\u30DF\u306E\u30CB\u30E5\u30FC\u30B9\uFF0C\u6839\u62E0\u304C\u66D6\u6627\u3067\u8272\u3005\u30C4\u30C3\u30B3\u30DF\u3069\u3053\u308D\u304C\u591A\u304F\u3066\u3068\u3066\u3082\u9762\u767D\u3044",
  "id" : 447664253219000320,
  "created_at" : "2014-03-23 09:20:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447664084024971264",
  "text" : "\u30EC\u30C3\u30BA\u306E\u30CB\u30E5\u30FC\u30B9\u3084\u3063\u3066\u305F\u3051\u3069\u306C\u30FC\u3093\u30C3\u30C6\u611F\u3058\u3060\u3063\u305F\uFF0E",
  "id" : 447664084024971264,
  "created_at" : "2014-03-23 09:20:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447638652575703040",
  "text" : "\u79C1\u3060\u30FC\uFF01\uFF01",
  "id" : 447638652575703040,
  "created_at" : "2014-03-23 07:39:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447638621881790464",
  "text" : "\u3058\u3063\u304B\u306B\u3044\u308B\u306E\u306B16\u6642\u306B\u8D77\u304D\u308B\u5974\u306F\u8AB0\u304B\u306A\u30FC\uFF1F",
  "id" : 447638621881790464,
  "created_at" : "2014-03-23 07:38:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/NQigbdGyrI",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=yamashitam",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447535324487372800",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/NQigbdGyrI",
  "id" : 447535324487372800,
  "created_at" : "2014-03-23 00:48:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447474051670233089",
  "geo" : { },
  "id_str" : "447474230301454336",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u30C7\u30D0\u30C3\u30B0\u6848\u4EF6",
  "id" : 447474230301454336,
  "in_reply_to_status_id" : 447474051670233089,
  "created_at" : "2014-03-22 20:45:44 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447473979297517569",
  "text" : "\u5916\u304C\u660E\u308B\u304F\u306A\u308B\u30A4\u30D9\u30F3\u30C8\u3001\u6BCE\u65E5\u8D77\u304D\u3066\u308B",
  "id" : 447473979297517569,
  "created_at" : "2014-03-22 20:44:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9BE3\u70CF\u8CCA",
      "screen_name" : "MERUSU",
      "indices" : [ 0, 7 ],
      "id_str" : "97225831",
      "id" : 97225831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447370976137736194",
  "geo" : { },
  "id_str" : "447371127627579393",
  "in_reply_to_user_id" : 97225831,
  "text" : "@MERUSU \u306A\u3093\u304B\u8A71\u984C\u306B\u306E\u307C\u3063\u305F\u306E\u3067\uFF1F",
  "id" : 447371127627579393,
  "in_reply_to_status_id" : 447370976137736194,
  "created_at" : "2014-03-22 13:56:03 +0000",
  "in_reply_to_screen_name" : "MERUSU",
  "in_reply_to_user_id_str" : "97225831",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 46, 55 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nicopedia",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/7VFhfPSCwG",
      "expanded_url" : "http:\/\/dic.nicovideo.jp\/id\/4238845",
      "display_url" : "dic.nicovideo.jp\/id\/4238845"
    } ]
  },
  "geo" : { },
  "id_str" : "447370143924883458",
  "text" : "\u30B7\u30E9\u30CD\u30FC\u30E8 - \u30CB\u30B3\u767E http:\/\/t.co\/7VFhfPSCwG #nicopedia @akeopyaa",
  "id" : 447370143924883458,
  "created_at" : "2014-03-22 13:52:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447342037881212928",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 447342037881212928,
  "created_at" : "2014-03-22 12:00:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/447299001172258816\/photo\/1",
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/ET6Q9rtzGI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjUgElLCMAAwhUu.jpg",
      "id_str" : "447299001063190528",
      "id" : 447299001063190528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjUgElLCMAAwhUu.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/ET6Q9rtzGI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447299001172258816",
  "text" : "\u6226\u7E3E http:\/\/t.co\/ET6Q9rtzGI",
  "id" : 447299001172258816,
  "created_at" : "2014-03-22 09:09:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447192389430419456",
  "text" : "\u30A4\u30C1\u30B4\u5927\u798F\u3068\u8C46\u5927\u798F\u8CB7\u3063\u305F\u306A\u306E",
  "id" : 447192389430419456,
  "created_at" : "2014-03-22 02:05:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/447190329859399680\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/3UEf3jPhWO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjS9PE2CYAAt2_4.jpg",
      "id_str" : "447190329712599040",
      "id" : 447190329712599040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjS9PE2CYAAt2_4.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3UEf3jPhWO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447190329859399680",
  "text" : "\u3053\u3093\u306A\u611F\u3058 http:\/\/t.co\/3UEf3jPhWO",
  "id" : 447190329859399680,
  "created_at" : "2014-03-22 01:57:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/N8993COFYR",
      "expanded_url" : "http:\/\/4sq.com\/1pjoLkE",
      "display_url" : "4sq.com\/1pjoLkE"
    } ]
  },
  "geo" : { },
  "id_str" : "447190247135518720",
  "text" : "\u3086\u3086\u5F0F\uFF01 (@ \u798F\u5409) http:\/\/t.co\/N8993COFYR",
  "id" : 447190247135518720,
  "created_at" : "2014-03-22 01:57:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/u4LuRcZBr6",
      "expanded_url" : "http:\/\/4sq.com\/1gkkTAj",
      "display_url" : "4sq.com\/1gkkTAj"
    } ]
  },
  "geo" : { },
  "id_str" : "447188501956919296",
  "text" : "\u61F2\u308A\u305A\u306B\u3086\u3086\u5F0F\u306E\u3042\u305D\u3053\u307F\u306B\u3044\u304F (@ \u963F\u4F50\u30B1\u8C37\u99C5 (Asagaya Sta.) w\/ 2 others) http:\/\/t.co\/u4LuRcZBr6",
  "id" : 447188501956919296,
  "created_at" : "2014-03-22 01:50:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447162324764209152",
  "text" : "\u5BDD\u8D77\u304D\u306E\u982D\u3067\u3082\u5F1F\u3068\u6BCD\u89AA\u304C\u300C\u306B\u3093\u306B\u304F\u306E\u5302\u3044\u3059\u308B\u3088\u306D\u300D\u300C(\u50D5\u304C)\u6628\u65E5\u305F\u3079\u3066\u304D\u305F\u3093\u3058\u3083\u306A\u3044\u306E\uFF1F\u300D\u307F\u305F\u3044\u306A\u4F1A\u8A71\u3055\u308C\u3066\u305F\u3089\u7533\u3057\u8A33 of the world",
  "id" : 447162324764209152,
  "created_at" : "2014-03-22 00:06:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447162024309448704",
  "text" : "@Kyo_Hiiragi \u9CF4\u308B\u307B\u3069",
  "id" : 447162024309448704,
  "created_at" : "2014-03-22 00:05:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447161283805069312",
  "text" : "\u6628\u65E5\u306E\u306B\u3093\u306B\u304F\u304C\u97FF\u304F\u3045\u3045",
  "id" : 447161283805069312,
  "created_at" : "2014-03-22 00:02:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447078909452894208",
  "text" : "\u3058\u3057\u3093",
  "id" : 447078909452894208,
  "created_at" : "2014-03-21 18:34:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447036707817287681",
  "text" : "3900\u3092\u4E09\u56DE\u523B\u3080\u3088\u308A2000\u30928\u56DE\u523B\u3080",
  "id" : 447036707817287681,
  "created_at" : "2014-03-21 15:47:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447006500246925312",
  "text" : "10\u65E5\u3068\u304B\u3044\u3046\u5358\u4F4D\u3067\u8ECA\u8CB8\u3057\u3066\u304F\u308C\u308B\u30B5\u30FC\u30D3\u30B9\u7121\u3044\u3093\u304B\u306A",
  "id" : 447006500246925312,
  "created_at" : "2014-03-21 13:47:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447005882648244225",
  "text" : "\u3069\u3046\u8003\u3048\u3066\u3082\u96FB\u8ECA\u3067\u306E\u79FB\u52D5\u3088\u308A\u539F\u4ED8\u306E\u65B9\u304C\u52B9\u7387\u826F\u3044\u4E00\u65E5\u3060\u3063\u305F",
  "id" : 447005882648244225,
  "created_at" : "2014-03-21 13:44:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447005754726166528",
  "text" : "\u624B\u304C\u51B7\u305F\u3044\u3001\u624B\u888B\u3044\u308B\u65E5\u3060\u3063\u305F\u306A\u3053\u308A\u3083",
  "id" : 447005754726166528,
  "created_at" : "2014-03-21 13:44:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447005512513499136",
  "text" : "\u5929\u5B50\u306E\u670D\u3068\u3066\u3082\u304B\u308F\u3044\u3044",
  "id" : 447005512513499136,
  "created_at" : "2014-03-21 13:43:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 43, 53 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/c5mXrgieGJ",
      "expanded_url" : "http:\/\/4sq.com\/1ghPeiW",
      "display_url" : "4sq.com\/1ghPeiW"
    } ]
  },
  "geo" : { },
  "id_str" : "446978407692120064",
  "text" : "\u30A2\u30AF\u30BB\u30B9\u3061\u3087\u3063\u3068\u3060\u3051\u5FAE\u5999\u3060\u3051\u3069\u30AA\u30B9\u30B9\u30E1\u306A\u306E\u3067\u6771\u4EAC\u306B\u3044\u308B\u30CB\u30F3\u30B2\u30F3\u306B\u30AA\u30B9\u30B9\u30E1\uFF01\uFF01\uFF01 RT @end313124: \u7F8E\u5473\u3057\u3044\u3082\u306E\u3057\u304B\u51FA\u3066\u3053\u306A\u304F\u3066\u30BA\u30EB\u3044 (@ \u306E\u307F\u55B0\u3044\u51E6 \u5E0C\u6797) http:\/\/t.co\/c5mXrgieGJ",
  "id" : 446978407692120064,
  "created_at" : "2014-03-21 11:55:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/c5mXrgieGJ",
      "expanded_url" : "http:\/\/4sq.com\/1ghPeiW",
      "display_url" : "4sq.com\/1ghPeiW"
    } ]
  },
  "geo" : { },
  "id_str" : "446978107782987776",
  "text" : "\u7F8E\u5473\u3057\u3044\u3082\u306E\u3057\u304B\u51FA\u3066\u3053\u306A\u304F\u3066\u30BA\u30EB\u3044 (@ \u306E\u307F\u55B0\u3044\u51E6 \u5E0C\u6797) http:\/\/t.co\/c5mXrgieGJ",
  "id" : 446978107782987776,
  "created_at" : "2014-03-21 11:54:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/446973405829406721\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/TuEUSN3l4z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjP38b4CUAA5_5v.jpg",
      "id_str" : "446973405686812672",
      "id" : 446973405686812672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjP38b4CUAA5_5v.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/TuEUSN3l4z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446972434650918912",
  "geo" : { },
  "id_str" : "446973405829406721",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u5185\u7530\u7C73\u30A8\u30C7\u30A3\u30B7\u30E7\u30F3\u307F\u305F\u3044\u3067\u3059\u3001\u3053\u3093\u306A\u3093 http:\/\/t.co\/TuEUSN3l4z",
  "id" : 446973405829406721,
  "in_reply_to_status_id" : 446972434650918912,
  "created_at" : "2014-03-21 11:35:38 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446971550357389312",
  "geo" : { },
  "id_str" : "446971677201551361",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u304A\u5E97\u3067\u898B\u304B\u3051\u305F\u306E\u3067\u30FC",
  "id" : 446971677201551361,
  "in_reply_to_status_id" : 446971550357389312,
  "created_at" : "2014-03-21 11:28:46 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446970939767402497",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u5F37\u529B\u3063\u3066\u3069\u3053\u306E\u304A\u9152\u3067\u3057\u305F\u3063\u3051\uFF1F",
  "id" : 446970939767402497,
  "created_at" : "2014-03-21 11:25:51 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446937227000414208",
  "text" : "\u30EA\u30C8\u30D0\u30B9\u306EBD\u501F\u308A\u305F\u3051\u3069\u4F59\u308A\u306B\u591A\u3044\u304B\u3089\u65B0\u3057\u3044\u4E0B\u5BBF\u306B\u9001\u308A\u3053\u3080\uFF0E",
  "id" : 446937227000414208,
  "created_at" : "2014-03-21 09:11:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446934844077916160",
  "text" : "\u30A8\u30C7\u30A3\u30BF\u304C\u77EF\u6B63\u3055\u308C\u308B\u7814\u7A76\u5BA4\u306E\u5B58\u5728\u3092\u805E\u3044\u3066\u6226\u6144\u3057\u3066\u3044\u308B\uFF0E",
  "id" : 446934844077916160,
  "created_at" : "2014-03-21 09:02:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446934323292160000",
  "text" : "\u306A\u304A\u5B9F\u5BB6\u306E\u6A21\u69D8\uFF0E",
  "id" : 446934323292160000,
  "created_at" : "2014-03-21 09:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 1, 10 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446934264966180865",
  "text" : "\uFF0E@akeopyaa \u90B8\u3067\u9EBB\u96C0\u3092\u3057\u3066\u3044\u308B\uFF0E\u3044\u3084\uFF0C\u50D5\u306F\u4ECA\u629C\u3051\u3066\u308B\u3051\u3069\uFF0E",
  "id" : 446934264966180865,
  "created_at" : "2014-03-21 09:00:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446934133353086976",
  "text" : "\u3042\u3086\u308C\u3063\u3066\u3043\u300C\u97F3\u30B2\u30FC\u306F\u30B2\u30FC\u30E0\u3058\u3083\u306A\u3044\u300D",
  "id" : 446934133353086976,
  "created_at" : "2014-03-21 08:59:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446933882814730240",
  "text" : "\u53CB\u4EBA\u5B85\u3067\u4EBA\u6A29\u3092\u5F97\u305F\uFF0E",
  "id" : 446933882814730240,
  "created_at" : "2014-03-21 08:58:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446703718012956672",
  "text" : "\u5B9F\u529B\u306B\u4F34\u308F\u306A\u3044\u534A\u7AEF\u77E5\u8B58\u3092\u62B1\u3044\u3066\u307E\u305F\u5BDD\u307E\u3059",
  "id" : 446703718012956672,
  "created_at" : "2014-03-20 17:44:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446703566120448001",
  "text" : "\u300C\u7D76\u5BFEland\u306E\u65B9\u304C\u697D\u3057\u3044\u300D\u3063\u3066LISP\u306E\u8A71\u3067\u3082\u3057\u3066\u308B\u306E\u304B\u3068\u601D\u3063\u305F\u3089\u30C7\u30A3\u30BA\u30CB\u30FC\u3060\u3063\u305F",
  "id" : 446703566120448001,
  "created_at" : "2014-03-20 17:43:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446638940343136257",
  "text" : "\u3042\u3063\u3068\u5404\u4F4D \u3081\u3063\u3061\u3083\u96D1\u306BFB\u30EA\u30AF\u6295\u3052\u307E\u3057\u305F\uFF0E\u9069\u5F53\u306B\u5BFE\u51E6\u3057\u3066\u304F\u3060\u3055\u3044\uFF0E\uFF08\u30B9\u30EB\u30FC\u3067\u3082\u627F\u8A8D\u3067\u3082\uFF09",
  "id" : 446638940343136257,
  "created_at" : "2014-03-20 13:26:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446638078065512448",
  "text" : "\u601D\u3063\u305F\u3088\u308A\u9577\u6587\u306B\u306A\u3063\u305F\u4E0A\u306B\u307E\u3068\u307E\u308A\u306E\u306A\u3044\u6587\u7AE0\u306B\uFF0E\u63A8\u6572\u3068\u304B\u3057\u306A\u3044\u306E\uFF0E",
  "id" : 446638078065512448,
  "created_at" : "2014-03-20 13:23:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446627830676193280",
  "geo" : { },
  "id_str" : "446627948817162241",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u305D\u308C\u306A\uFF01",
  "id" : 446627948817162241,
  "in_reply_to_status_id" : 446627830676193280,
  "created_at" : "2014-03-20 12:42:55 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446627249614114816",
  "text" : "\u9854\u672C\u306B\u65C5\u30EC\u30DD\u3081\u3044\u305F\u306E\u4E0A\u3052\u308B\u304B\u2026",
  "id" : 446627249614114816,
  "created_at" : "2014-03-20 12:40:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446626809983926272",
  "geo" : { },
  "id_str" : "446627144001531904",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u308F\u304B\u308B",
  "id" : 446627144001531904,
  "in_reply_to_status_id" : 446626809983926272,
  "created_at" : "2014-03-20 12:39:43 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446626223179837440",
  "text" : "\u30EA\u30FC\u30C1\u30C4\u30E2\u30C8\u30A4\u30C8\u30A4\u306A\u308920004000\u306A\u306E\u3067\u306F",
  "id" : 446626223179837440,
  "created_at" : "2014-03-20 12:36:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446626084004429824",
  "text" : "\u304A\u3084\u3059\u307F\u306E\u305B\u304B\u3044\u3078",
  "id" : 446626084004429824,
  "created_at" : "2014-03-20 12:35:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446625864541675520",
  "text" : "\u56DB\u6697\u523B\u304B",
  "id" : 446625864541675520,
  "created_at" : "2014-03-20 12:34:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446623225405927425",
  "text" : "\u5B9F\u969B\u3048\u3093\u3069\u3055\u3093\u3082\u75B2\u308C\u3066\u3044\u308B\u3057\u5BDD\u308B\u304B\u2026",
  "id" : 446623225405927425,
  "created_at" : "2014-03-20 12:24:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446623148440424448",
  "text" : "21\u6642\u306B\u7720\u308B\u5BB6\u65CF\u3092\u5C3B\u76EE\u306B\u4E00\u4EBA\u3067\u306E\u30FC\u3068PC\u3092\u5F04\u308BZU",
  "id" : 446623148440424448,
  "created_at" : "2014-03-20 12:23:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446618179557527552",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 446618179557527552,
  "created_at" : "2014-03-20 12:04:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446609754706571264",
  "text" : "\u3057\u304B\u3057capslock\u304C\u751F\u304D\u3066\u308B\u2026",
  "id" : 446609754706571264,
  "created_at" : "2014-03-20 11:30:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446609629758230528",
  "text" : "\u3042\u3063\u3077\u3067\u30FC\u3068\u3057\u305F",
  "id" : 446609629758230528,
  "created_at" : "2014-03-20 11:30:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u52A0\u85E4",
      "screen_name" : "ryoOOochh",
      "indices" : [ 0, 10 ],
      "id_str" : "616883839",
      "id" : 616883839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446603774610509824",
  "in_reply_to_user_id" : 616883839,
  "text" : "@ryoOOochh \u884C\u3051\u305F\u3089\u884C\u3063\u3066\u308B\u3088\u306D\u3001\u3046\u3093",
  "id" : 446603774610509824,
  "created_at" : "2014-03-20 11:06:52 +0000",
  "in_reply_to_screen_name" : "ryoOOochh",
  "in_reply_to_user_id_str" : "616883839",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446600683458809856",
  "text" : "\u96C0\u8358\u826F\u3044\u306A\u3041\u30FC\u2026\u77AC\u9593\u79FB\u52D5\u3067\u304D\u308B\u4EBA\u5C45\u305F\u3089\u9023\u7D61\u4E0B\u3055\u3044\uFF1F",
  "id" : 446600683458809856,
  "created_at" : "2014-03-20 10:54:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446575438463111168",
  "text" : "\u307E\u3060\u304A\u308F\u3089\u306A\u3044\u30A2\u30C3\u30D7\u30C7\u30FC\u30C8",
  "id" : 446575438463111168,
  "created_at" : "2014-03-20 09:14:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446573588544376832",
  "text" : "\u304A\u5929\u6C17\u304A\u59C9\u3055\u3093\u300C\u96E8\u304C\u964D\u3063\u3066\u3044\u308B\u3068\u3053\u308D\u3068\u6B62\u3093\u3067\u3044\u308B\u6240\u304C\u3042\u308A\u307E\u3059\u300D\n\u3048\u3093\u3069\u3055\u3093\u300C\u305F\u3081\u306B\u306A\u308B\u306A\u3041\u300D",
  "id" : 446573588544376832,
  "created_at" : "2014-03-20 09:06:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446546074346340352",
  "text" : "40\u3075\u3093\u304F\u3089\u3044\u304B\u304B\u308B\u30FC",
  "id" : 446546074346340352,
  "created_at" : "2014-03-20 07:17:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446544955666726912",
  "text" : "\u3059\u3069\u30FC \u3069\u3045\u30FC \u308A\u308A\u30FC\u3059 \u3042\u3063\u3077\u3050\u308C\u30FC\u3069",
  "id" : 446544955666726912,
  "created_at" : "2014-03-20 07:13:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446543517708333056",
  "text" : "ubuntu\u306E\u30A2\u30C3\u30D7\u30C7\u30FC\u30C8\u3059\u308B\u304B\u2026",
  "id" : 446543517708333056,
  "created_at" : "2014-03-20 07:07:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446534688442552320",
  "text" : "\u5E30\u5B85\uFF01\uFF01\uFF01",
  "id" : 446534688442552320,
  "created_at" : "2014-03-20 06:32:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446281895622348800",
  "text" : "\u3066\u304B\u3001\uFF29\uFF32\uFF23\u3084\u3063\u3066\u308B\uFF1F\u7B11",
  "id" : 446281895622348800,
  "created_at" : "2014-03-19 13:47:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446281860067246081",
  "text" : "\u73FE\u4EE3\u793E\u4F1A\u306B\u9069\u5408\u3067\u304D\u306A\u3044\u306E\u3067\uFF2C\uFF29\uFF2E\uFF25\u3084\u3081\u307E\u3057\u305F",
  "id" : 446281860067246081,
  "created_at" : "2014-03-19 13:47:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446281352850059265",
  "text" : "\u3042\u306E\u306D\u3001\u50D5\u306B\u30D6\u30ED\u30C3\u30AF\u3055\u308C\u308B\u3063\u3066\u3044\u3046\u306E\u306F\u306D\u3001\u305D\u3046\u3068\u3046\u30A2\u30EC\u306A\u306E",
  "id" : 446281352850059265,
  "created_at" : "2014-03-19 13:45:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446280878163898368",
  "text" : "\u6700\u8FD1\u3001\u5341\u5206\u8A13\u7DF4\u3055\u308C\u305F\u733F\u3092\u904E\u5927\u8A55\u4FA1\u3057\u3059\u304E\u3066\u3044\u308B\u6C17\u304C\u3059\u308B",
  "id" : 446280878163898368,
  "created_at" : "2014-03-19 13:43:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446280707376033792",
  "text" : "\u300C\u8CE2\u3044\u300D\u300C\u3084\u3063\u305F\u3041\u300D\u306E\u3084\u308A\u3068\u308A\u306E\u30EC\u30D9\u30EB\u306E\u4F4E\u3055",
  "id" : 446280707376033792,
  "created_at" : "2014-03-19 13:43:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0430\u043B\u044F White",
      "screen_name" : "getty_on_r318",
      "indices" : [ 0, 14 ],
      "id_str" : "2884913343",
      "id" : 2884913343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446279688215101440",
  "geo" : { },
  "id_str" : "446280166285643777",
  "in_reply_to_user_id" : 379262851,
  "text" : "@getty_on_r318 \u8CE2\u3044",
  "id" : 446280166285643777,
  "in_reply_to_status_id" : 446279688215101440,
  "created_at" : "2014-03-19 13:40:57 +0000",
  "in_reply_to_screen_name" : "komorin95",
  "in_reply_to_user_id_str" : "379262851",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446279374141022208",
  "text" : "\u307B\u3093\u307E\u304B",
  "id" : 446279374141022208,
  "created_at" : "2014-03-19 13:37:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446279347272306688",
  "text" : "\u3053\u308C\u304B\u3089\u306F\u30E9\u30C3\u30AF\u30B5\u30FC\u30D0\u30FC\u3092\u304A\u304B\u3082\u3061\u3067\u7ACB\u3066\u308B\u6642\u4EE3\u3001\u304A\u304B\u3082\u3061\u30B5\u30FC\u30D0\u30FC\u306E\u6642\u4EE3\u304C\u6765\u308B",
  "id" : 446279347272306688,
  "created_at" : "2014-03-19 13:37:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446279062038671361",
  "geo" : { },
  "id_str" : "446279200920453121",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u304A\u304B\u3082\u3061\u9001\u4ED8\u3082\u8F9E\u3055\u306A\u3044",
  "id" : 446279200920453121,
  "in_reply_to_status_id" : 446279062038671361,
  "created_at" : "2014-03-19 13:37:07 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446278197143814144",
  "geo" : { },
  "id_str" : "446278528128917504",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma\u3000\u3042\u308C\u8131\u9000\u3057\u3066\u306A\u3044\u3064\u3082\u308A\u306A\u3093\u3067\u3059\u304C\u3042\u308C\u3067\u3059\u304B\u5F37\u5236\u9664\u540D\u3067\u3059\u304B",
  "id" : 446278528128917504,
  "in_reply_to_status_id" : 446278197143814144,
  "created_at" : "2014-03-19 13:34:27 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446277793567875072",
  "text" : "\uFF1F\uFF1F\uFF1F",
  "id" : 446277793567875072,
  "created_at" : "2014-03-19 13:31:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446277325781344256",
  "geo" : { },
  "id_str" : "446277769404506113",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u307E\u3055\u304B\u30CF\u30F3\u30B5\u30E0\u306B\u305D\u3093\u306A\u610F\u5473\u304C\u3042\u308B\u306A\u3093\u3066\u77E5\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u30A2\u30FC\u30AF\u3055\u3093\u306F\u7269\u77E5\u308A\u3067\u3059\u306D\uFF01",
  "id" : 446277769404506113,
  "in_reply_to_status_id" : 446277325781344256,
  "created_at" : "2014-03-19 13:31:26 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446277022990336001",
  "text" : "\u50D5\u304C\u5F15\u3063\u8D8A\u3057\u305F\u30BF\u30A4\u30DF\u30F3\u30B0\u3067\u304B\u304C\u304F\u307E\u4EAD\u306E\u30D3\u30F3\u5EC3\u68C4\u2026\u3053\u308C\u306F\u9670\u8B00\u306E\u9999\u308A\u304C\u3057\u307E\u3059\u306D\uFF01",
  "id" : 446277022990336001,
  "created_at" : "2014-03-19 13:28:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446276769578889217",
  "text" : "\u7DD1\u4EE5\u5916\u306E\u30D3\u30F3\u3092\u96C6\u3081\u308B\u3053\u3068\u306B\u3057\u305F\u306E\u304B\u306A\uFF1F",
  "id" : 446276769578889217,
  "created_at" : "2014-03-19 13:27:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446276435057987584",
  "geo" : { },
  "id_str" : "446276658845077504",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u8A34\u8A1F\u3082\u8F9E\u3055\u306A\u3044\u69CB\u3048",
  "id" : 446276658845077504,
  "in_reply_to_status_id" : 446276435057987584,
  "created_at" : "2014-03-19 13:27:01 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446276321224577024",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u597D\u304D\u52DD\u624B\uFF25\uFF4D\uFF41\uFF43\uFF53\u5165\u308C\u308B",
  "id" : 446276321224577024,
  "created_at" : "2014-03-19 13:25:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446276124583010305",
  "text" : "\uFF38\uFF30\u3060\u3057\u2026\u9707\u3048\u58F0\u2026",
  "id" : 446276124583010305,
  "created_at" : "2014-03-19 13:24:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446276002050625537",
  "text" : "\u3053\u306E\uFF30\uFF23\u3001\u52DD\u624B\u306B\uFF23\uFF48\uFF4F\uFF52\uFF4D\uFF45\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3067\u304D\u308B\u306F\uFF2A\uFF41\uFF56\uFF41\u30A2\u30D7\u30C7\u51FA\u6765\u308B\u308F\u3001\uFF30\uFF24\uFF26\u898B\u308C\u306A\u3044\u308F\u3067\u306A\u3093\u304B\u3059\u3063\u3054\u3044",
  "id" : 446276002050625537,
  "created_at" : "2014-03-19 13:24:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446275100686299136",
  "geo" : { },
  "id_str" : "446275483965997056",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u96E8\u306E\u4E88\u5831\u3060\u3063\u305F\u5929\u6C17\u3092\u6674\u308C\u306B\u3057\u3066\u304F\u308C\u308B\u3088\u3046\u306A\u5730\u65B9\u3067\u3059",
  "id" : 446275483965997056,
  "in_reply_to_status_id" : 446275100686299136,
  "created_at" : "2014-03-19 13:22:21 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446274164232429568",
  "text" : "\u3068\u3053\u308D\u3067\u30CF\u30F3\u30B5\u30E0\u306E\u95A2\u6771\u5730\u65B9\u3063\u3066\u4F55\u3067\u3059\u304B",
  "id" : 446274164232429568,
  "created_at" : "2014-03-19 13:17:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446273767002476544",
  "text" : "\u2462\u6FE1\u308C\u306A\u304C\u3089\u5E30\u308B\u3002\u3000\u73FE\u5B9F\u306F\u975E\u60C5\u3067\u3042\u308B",
  "id" : 446273767002476544,
  "created_at" : "2014-03-19 13:15:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446273657615024128",
  "text" : "\u300C\u305D\u3053\u3067\u554F\u984C\u3060\uFF01\u3000\u660E\u65E5\u306E\u96E8\u3067\u3069\u3046\u3084\u3063\u3066\u6CBC\u6D25\u304B\u3089\u6771\u4EAC\u307E\u3067\u539F\u4ED8\u3067\u5E30\u308B\u304B\uFF1F3\u629E\uFF0D\u4E00\u3064\u3060\u3051\u9078\u3073\u306A\u3055\u3044 \u3000\u7B54\u3048\u2460\u30CF\u30F3\u30B5\u30E0\u306E\u95A2\u6771\u5730\u65B9\u306F\u7A81\u5982\u660E\u65E5\u306E\u5929\u6C17\u3092\u6674\u308C\u306B\u3059\u308B \u3000\u7B54\u3048\u2461\u77E5\u3089\u306A\u3044\u4EBA\u304C\u8ECA\u3092\u304F\u308C\u3066\u52A9\u3051\u3066\u304F\u308C\u308B \u3000\u7B54\u3048\u2462\u6FE1\u308C\u306A\u304C\u3089\u5E30\u308B\u3002\u3000\u73FE\u5B9F\u306F\u975E\u60C5\u3067\u3042\u308B\u300D",
  "id" : 446273657615024128,
  "created_at" : "2014-03-19 13:15:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446272529087201280",
  "text" : "\u3069\u308C\u3060\u3051\u6642\u9593\u304C\u304B\u304B\u308B\u3068\u601D\u3063\u3066\u3093\u3058\u3083",
  "id" : 446272529087201280,
  "created_at" : "2014-03-19 13:10:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446272477958651904",
  "text" : "\u89AA\u306B\u3070\u3042\u3061\u3083\u3093\u5BB6(\u4F0A\u8C46\u897F\u90E8)\u306B\u5BC4\u3063\u3066\u304F\u308C\u3070\u3068\u304B\u8A00\u308F\u308C\u305F\u304C\u305D\u3053\u306B\u3088\u308B\u306A\u3089\u305D\u3053\u306B\u3042\u308B\u8ECA\u3092\u539F\u4ED8\u3054\u3068\u596A\u53D6\u3059\u308B\u52E2\u3044\u3058\u3083",
  "id" : 446272477958651904,
  "created_at" : "2014-03-19 13:10:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446270324233863168",
  "text" : "\u96E8\u5F31\u304F\u306A\u3044\u3068\u3059\u3054\u304F\u56F0\u308B",
  "id" : 446270324233863168,
  "created_at" : "2014-03-19 13:01:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446269416762667008",
  "text" : "\u6642\u9593\u3068\u91D1\u304C\u3042\u3063\u305F\u3089\u4F0A\u8C46\u3092\u3050\u308B\u3063\u3068\u3057\u3066\u3082\u3088\u304B\u3063\u305F\u3051\u3069\u6642\u9593\u3082\u91D1\u3082\u306A\u3044\u3093\u3058\u3083",
  "id" : 446269416762667008,
  "created_at" : "2014-03-19 12:58:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446269077669965824",
  "text" : "\u6642\u9593\u304B\u304B\u3063\u3066\u3082\u7BB1\u6839\u306E\u5C71\u306F\u907F\u3051\u308B\u304B\u2026\u5929\u6C17\u306B\u3082\u4F9D\u308B\u3088\u306A\u2026",
  "id" : 446269077669965824,
  "created_at" : "2014-03-19 12:56:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446268023578456064",
  "text" : "\uFF2A\uFF41\uFF56\uFF41\u306E\u66F4\u65B0",
  "id" : 446268023578456064,
  "created_at" : "2014-03-19 12:52:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446267592961826816",
  "text" : "\u7BB1\u6839\u65B0\u9053\u306E\u8DEF\u9762\u72B6\u614B[\u691C\u7D22]",
  "id" : 446267592961826816,
  "created_at" : "2014-03-19 12:51:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446266379625168896",
  "text" : "Chorome\u306E\u30A4\u30F3\u30B9\u30C8\u30FC\u30EB\u3084\u3063\u305F\u306E\u3068\u3066\u3082\u3046\u3051\u308B",
  "id" : 446266379625168896,
  "created_at" : "2014-03-19 12:46:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446245321392128000",
  "geo" : { },
  "id_str" : "446266270963355648",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u304C\u3093\u3070\u308A\u307E\u3059",
  "id" : 446266270963355648,
  "in_reply_to_status_id" : 446245321392128000,
  "created_at" : "2014-03-19 12:45:44 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446266202013179904",
  "text" : "\u306A\u304A\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u30B3\u30FC\u30CA\u30FC\u304C\u3042\u3063\u305F\u306E\u3067\u305D\u3053\u3067PC\u89E6\u308C\u306A\u304B\u3063\u305F\u3089\u6B7B\u3093\u3067\u305F",
  "id" : 446266202013179904,
  "created_at" : "2014-03-19 12:45:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446266103434465281",
  "text" : "\u3069\u3046\u3082\u5145\u96FB\u3067\u304D\u3066\u306A\u3044\u3068\u601D\u3063\u305F\u3089\u30B1\u30FC\u30D6\u30EB\u6B7B\u3093\u3067\u308B\u3063\u307D\u3044",
  "id" : 446266103434465281,
  "created_at" : "2014-03-19 12:45:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446247956245528576",
  "text" : "350\u5186\u306E\u30E4\u30EA\u30A4\u30AB\u3092\u8FFD\u52A0\u3057\u3066\u30821200\u5186\u306A\u306E",
  "id" : 446247956245528576,
  "created_at" : "2014-03-19 11:32:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446247877212246016",
  "text" : "\u3044\u308F\u3057\u3001\u307E\u3050\u308D\u3001\u304B\u3093\u3071\u3061\u306E\u523A\u8EAB\u3001\u307B\u3046\u308C\u3093\u8349\u306E\u548C\u3048\u7269\u3001\u30A4\u30AB\u3068\u5927\u6839\u306E\u716E\u7269\u3001\u304A\u5473\u564C\u6C41\u3001\u3054\u98EF\u3001\u30DB\u30C3\u30B1\u306E\u5E72\u7269\u3001\u3053\u308C\u3067850\u5186\u306F\u5B89\u3044",
  "id" : 446247877212246016,
  "created_at" : "2014-03-19 11:32:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446242439955628033",
  "text" : "\u4E0B\u534A\u8EAB\u306F\u4E0A\u534A\u8EAB\u306B\u6BD4\u3079\u3066\u6E29\u3081\u308B\u5E03\u304C\u5C11\u306A\u3044\u304B\u3089\u8DB3\u51CD\u3048\u308B",
  "id" : 446242439955628033,
  "created_at" : "2014-03-19 11:11:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446241802358517760",
  "text" : "\u660E\u65E5\u96E8\u3068\u304B\u60AA\u3044\u5197\u8AC7\u304B\u3068\u3066\u3082\u60AA\u3044\u5197\u8AC7\u304B\u305D\u306E\u3069\u3061\u3089\u3067\u3082\u306A\u3044\u304B\u3060\u308D\u2026",
  "id" : 446241802358517760,
  "created_at" : "2014-03-19 11:08:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446241433758859264",
  "text" : "\u96E8\u306B\u3093\u3052\u3093\u3060",
  "id" : 446241433758859264,
  "created_at" : "2014-03-19 11:07:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 0, 10 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446241255937175553",
  "geo" : { },
  "id_str" : "446241394164654080",
  "in_reply_to_user_id" : 230481483,
  "text" : "@wa_ta_si_ \u3044\u3048\u30FC\u3044\u3001\u660E\u65E5\u96E8\u3089\u3057\u304F\u3066\u6CE3\u3044\u3066\u308B",
  "id" : 446241394164654080,
  "in_reply_to_status_id" : 446241255937175553,
  "created_at" : "2014-03-19 11:06:53 +0000",
  "in_reply_to_screen_name" : "wa_ta_si_",
  "in_reply_to_user_id_str" : "230481483",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446241120880586752",
  "text" : "\u30D6\u30EB\u30B8\u30E7\u30EF\u3060\u304B\u3089\u307B\u3063\u3051\u306E\u5E72\u7269\u5B9A\u98DF\u3068\u30A4\u30AB\u306E\u304A\u523A\u8EAB\u983C\u3093\u3060",
  "id" : 446241120880586752,
  "created_at" : "2014-03-19 11:05:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/zOP3qtwzs6",
      "expanded_url" : "http:\/\/4sq.com\/1gFSHGG",
      "display_url" : "4sq.com\/1gFSHGG"
    } ]
  },
  "geo" : { },
  "id_str" : "446240968455766016",
  "text" : "\u3044\u3044\u611F\u3058\u306E\u5B9A\u98DF\u5C4B\u3055\u3093\u3092\u898B\u3064\u3051\u305F (@ \u3081\u3057\u51E6 \u6676) http:\/\/t.co\/zOP3qtwzs6",
  "id" : 446240968455766016,
  "created_at" : "2014-03-19 11:05:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446234349902381056",
  "text" : "\u6CBC\u6D25\u307E\u3067\u6765\u305F",
  "id" : 446234349902381056,
  "created_at" : "2014-03-19 10:38:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30ED\u30FC\u30BD\u30F3",
      "screen_name" : "akiko_lawson",
      "indices" : [ 21, 34 ],
      "id_str" : "115639376",
      "id" : 115639376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/dO7bhRZS0z",
      "expanded_url" : "http:\/\/4sq.com\/1palrrQ",
      "display_url" : "4sq.com\/1palrrQ"
    } ]
  },
  "geo" : { },
  "id_str" : "446234273465774080",
  "text" : "I'm at \u30ED\u30FC\u30BD\u30F3 \u6CBC\u6D25\u6771\u690E\u8DEF\u5357 - @akiko_lawson (\u6CBC\u6D25\u5E02, \u9759\u5CA1\u770C) http:\/\/t.co\/dO7bhRZS0z",
  "id" : 446234273465774080,
  "created_at" : "2014-03-19 10:38:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446197615797862400",
  "text" : "\u539F\u4ED8\u3067\u901A\u308C\u308B\u30D0\u30A4\u30D1\u30B9\u3068\u901A\u308C\u306A\u3044\u30D0\u30A4\u30D1\u30B9\u304C\u3042\u308B",
  "id" : 446197615797862400,
  "created_at" : "2014-03-19 08:12:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/BXbiWFoU5r",
      "expanded_url" : "http:\/\/4sq.com\/1ejOA2a",
      "display_url" : "4sq.com\/1ejOA2a"
    } ]
  },
  "geo" : { },
  "id_str" : "446197461099749376",
  "text" : "\u3055\u3080\u3044 (@ \u30B5\u30FC\u30AF\u30EBK\u5CF6\u7530\u91CE\u7530\u5E97) http:\/\/t.co\/BXbiWFoU5r",
  "id" : 446197461099749376,
  "created_at" : "2014-03-19 08:12:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446112655757946880",
  "text" : "\u5915\u65B9\u6D5C\u677E\u3042\u305F\u308A\u3067\u3046\u306A\u304E\u98DF\u3079\u305F\u3044\u306A",
  "id" : 446112655757946880,
  "created_at" : "2014-03-19 02:35:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/bLqJGQtRRF",
      "expanded_url" : "http:\/\/4sq.com\/1p9rDAi",
      "display_url" : "4sq.com\/1p9rDAi"
    } ]
  },
  "geo" : { },
  "id_str" : "446112587554770944",
  "text" : "I'm at \u30D5\u30A1\u30DF\u30EA\u30FC\u30DE\u30FC\u30C8 \u8C4A\u660E\u307B\u3089\u8C9D\u5E97 (\u8C4A\u660E\u5E02, \u611B\u77E5\u770C) http:\/\/t.co\/bLqJGQtRRF",
  "id" : 446112587554770944,
  "created_at" : "2014-03-19 02:35:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445960489667788800",
  "text" : "\u5BDD\u308B\u306E",
  "id" : 445960489667788800,
  "created_at" : "2014-03-18 16:30:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445960011701690369",
  "text" : "\u6700\u60AA\u96FB\u6C17\u5C4B\u3055\u3093\u3067\u30E2\u30D0\u30D6\u8CB7\u3046\u624B\u3082\u3042\u308B\u304B\u2026[\u6DF1\u523B\u306A\u96FB\u6E90\u4E0D\u8DB3]",
  "id" : 445960011701690369,
  "created_at" : "2014-03-18 16:28:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/btvuvWoIp8",
      "expanded_url" : "http:\/\/4sq.com\/1l0wwOZ",
      "display_url" : "4sq.com\/1l0wwOZ"
    } ]
  },
  "geo" : { },
  "id_str" : "445953027091226624",
  "text" : "\u3061\u3087\u3046\u3069\u65E5\u4ED8\u304C\u5909\u308F\u3089\u306A\u3044\u4F4D\u306B\u7740\u3044\u3066\u305F (@ \u30B9\u30D1\u30AC\u30FC\u30E9) http:\/\/t.co\/btvuvWoIp8",
  "id" : 445953027091226624,
  "created_at" : "2014-03-18 16:01:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445924335572631552",
  "text" : "\u663C\u9593\u3060\u3063\u305F\u3089\u826F\u3044\u666F\u8272\u306A\u3093\u3060\u308D\u30FC\u306A\u30FC\u3063\u3066\u6240\u3092\u771F\u3063\u6697\u306A\u72B6\u614B\u3067\u901A\u308A\u629C\u3051\u308B\u5974",
  "id" : 445924335572631552,
  "created_at" : "2014-03-18 14:07:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445922268393127937",
  "text" : "\u696D\u52D9\u7528\u30B9\u30FC\u30D7\u3063\u307D\u3044\u5473\u3060\u304C\u3068\u308A\u3042\u3048\u305A\u6E29\u304B\u3044",
  "id" : 445922268393127937,
  "created_at" : "2014-03-18 13:58:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445919985014018051",
  "text" : "\u3042\u3044\u3061\u307E\u3067\u3001\u6765\u305F\u3093\u3060\u3088",
  "id" : 445919985014018051,
  "created_at" : "2014-03-18 13:49:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/I8nHEDN0pp",
      "expanded_url" : "http:\/\/4sq.com\/1cV1WDn",
      "display_url" : "4sq.com\/1cV1WDn"
    } ]
  },
  "geo" : { },
  "id_str" : "445919924163461120",
  "text" : "\u4F55\u304B\u98DF\u3079\u306A\u3044\u3068\u3001\u6B7B\u306C (@ \u3054\u307E\u3081\u5BB6 \u5C3E\u897F\u5E97) http:\/\/t.co\/I8nHEDN0pp",
  "id" : 445919924163461120,
  "created_at" : "2014-03-18 13:49:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/tyjbCsKlcM",
      "expanded_url" : "http:\/\/4sq.com\/1dky9it",
      "display_url" : "4sq.com\/1dky9it"
    } ]
  },
  "geo" : { },
  "id_str" : "445896757210525696",
  "text" : "\u30BB\u30AD\u30D0\u30CF\u30E9\u306A (@ \u30B5\u30FC\u30AF\u30EBK \u4E0A\u77F3\u6D25\u7267\u7530\u5E97) http:\/\/t.co\/tyjbCsKlcM",
  "id" : 445896757210525696,
  "created_at" : "2014-03-18 12:17:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445893294313066496",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 445893294313066496,
  "created_at" : "2014-03-18 12:03:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30ED\u30FC\u30BD\u30F3",
      "screen_name" : "akiko_lawson",
      "indices" : [ 33, 46 ],
      "id_str" : "115639376",
      "id" : 115639376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/GpujQaRQlG",
      "expanded_url" : "http:\/\/4sq.com\/1p73Voo",
      "display_url" : "4sq.com\/1p73Voo"
    } ]
  },
  "geo" : { },
  "id_str" : "445872833357692928",
  "text" : "\u65E5\u4ED8\u5909\u308F\u308B\u524D\u306B\u7740\u304D\u305F\u3044\u4EBA\u751F\u305F (@ \u30ED\u30FC\u30BD\u30F3 \u4E94\u500B\u8358\u5317\u753A\u5C4B\u5E97 - @akiko_lawson) http:\/\/t.co\/GpujQaRQlG",
  "id" : 445872833357692928,
  "created_at" : "2014-03-18 10:42:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445837069575671808",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u540D\u53E4\u5C4B\u5411\u304B\u3046",
  "id" : 445837069575671808,
  "created_at" : "2014-03-18 08:20:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445830094271963136",
  "geo" : { },
  "id_str" : "445831704729493504",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u53E3\u304B\u3089\u751F\u307E\u308C\u305F\u65E8\u4EE5\u5916\u4F1D\u308F\u3063\u3066\u306A\u3044\u306F\u305A\u3067\u3059\u304C\u305D\u308C\u306F\u2026\u5B9F\u969B\u305D\u3063\u3061\u306B\u884C\u304F\u306E\u306F26\u3068\u304B\u305D\u3093\u306A\u3093\u3067\u3059\u306D",
  "id" : 445831704729493504,
  "in_reply_to_status_id" : 445830094271963136,
  "created_at" : "2014-03-18 07:58:56 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/nyhyjVOYHv",
      "expanded_url" : "http:\/\/4sq.com\/1gBdVFy",
      "display_url" : "4sq.com\/1gBdVFy"
    } ]
  },
  "geo" : { },
  "id_str" : "445829777426251776",
  "text" : "\u6700\u5F8C\u306E\u30C1\u30A7\u30C3\u30AF\u30A4\u30F3 (@ end\u90B8) http:\/\/t.co\/nyhyjVOYHv",
  "id" : 445829777426251776,
  "created_at" : "2014-03-18 07:51:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445786924783906816",
  "text" : "\u3054\u307F\u3068\u30DB\u30B3\u30EA\u306E\u5C71\u306E",
  "id" : 445786924783906816,
  "created_at" : "2014-03-18 05:00:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445786842294538240",
  "text" : "\u305D\u3057\u3066\u4F55\u3082\u306A\u304F\u306A\u3063\u305F",
  "id" : 445786842294538240,
  "created_at" : "2014-03-18 05:00:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/Dsr47hkCqy",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/1?prefill=cocoalix",
      "display_url" : "gohantabeyo.com\/nani\/1?prefill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445639748585934849",
  "text" : "\u3054\u306F\u3093\u305F\u3079\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/Dsr47hkCqy",
  "id" : 445639748585934849,
  "created_at" : "2014-03-17 19:16:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445602251382353920",
  "text" : "\u6FC3\u539A\u306A\u90E8\u5BA4\u96F0\u56F2\u6C17",
  "id" : 445602251382353920,
  "created_at" : "2014-03-17 16:47:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445601812171595776",
  "text" : "\u30DE\u30E8\u30D2\u30AC\u3081\u3044\u3066\u6E29\u60C5",
  "id" : 445601812171595776,
  "created_at" : "2014-03-17 16:45:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445601732282687488",
  "text" : "@Kyo_Hiiragi \u6E29\u60C5\u3092\u671F\u5F85\u3057\u3066\u308B\u3084\u3064\u306B\u306F\u6E29\u60C5\u306F\u8A2A\u308C\u306A\u3044",
  "id" : 445601732282687488,
  "created_at" : "2014-03-17 16:45:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445600924380061696",
  "geo" : { },
  "id_str" : "445601207864680448",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u304A\u3059\u306A\u307F\u3044\u3084\u3055\u3044",
  "id" : 445601207864680448,
  "in_reply_to_status_id" : 445600924380061696,
  "created_at" : "2014-03-17 16:43:01 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445600627859546112",
  "text" : "\u672D\u675F\u3067\u3001\u9854\u3092",
  "id" : 445600627859546112,
  "created_at" : "2014-03-17 16:40:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445600591989841920",
  "text" : "\u30D3\u30EB\u30B2\u30A4\u30C4\u306F\u90FD\u5408\u60AA\u304F\u306A\u308B\u3068\u3059\u3050\u672D\u675F\u51FA\u30AB\u30AA\u3092\u306F\u305F\u3044\u3066\u304F\u308B\u304B\u3089\u306A",
  "id" : 445600591989841920,
  "created_at" : "2014-03-17 16:40:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "KA19NDA4",
      "indices" : [ 0, 9 ],
      "id_str" : "2382379614",
      "id" : 2382379614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445600283750440960",
  "geo" : { },
  "id_str" : "445600424448389121",
  "in_reply_to_user_id" : 2382379614,
  "text" : "@KA19NDA4 \u30DB\u30BF\u30C6\u3063\u3066\u306B\u3093\u3052\u3093\u306B\u98DF\u3079\u3089\u308C\u308B\u305F\u3081\u306B\u751F\u307E\u308C\u305F\u751F\u304D\u7269\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3042\u308B",
  "id" : 445600424448389121,
  "in_reply_to_status_id" : 445600283750440960,
  "created_at" : "2014-03-17 16:39:54 +0000",
  "in_reply_to_screen_name" : "KA19NDA4",
  "in_reply_to_user_id_str" : "2382379614",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445600084059635712",
  "geo" : { },
  "id_str" : "445600332085616640",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u5831\u544A\u3092\u53D7\u3051\u306A\u304B\u3063\u305F\u30D3\u30EB\u30B2\u30A4\u30C4\u300C\u3061\u3083\u3093\u3068\u5831\u544A\u3057\u308D\uFF01\uFF01\uFF01\u300D\n\u5831\u544A\u3092\u53D7\u3051\u305F\u30D3\u30EB\u30B2\u30A4\u30C4\u300C\u3057\u3087\u3046\u3082\u306A\u3044\u3053\u3068\u3067\u3044\u3061\u3044\u3061\u5831\u544A\u3059\u3093\u306A\uFF01\uFF01\uFF01\u300D",
  "id" : 445600332085616640,
  "in_reply_to_status_id" : 445600084059635712,
  "created_at" : "2014-03-17 16:39:32 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "KA19NDA4",
      "indices" : [ 0, 9 ],
      "id_str" : "2382379614",
      "id" : 2382379614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445599826172854273",
  "geo" : { },
  "id_str" : "445600003541594112",
  "in_reply_to_user_id" : 2382379614,
  "text" : "@KA19NDA4 \u3069\u3063\u3061\u3082\u304A\u3044\u3057\u3044",
  "id" : 445600003541594112,
  "in_reply_to_status_id" : 445599826172854273,
  "created_at" : "2014-03-17 16:38:14 +0000",
  "in_reply_to_screen_name" : "KA19NDA4",
  "in_reply_to_user_id_str" : "2382379614",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445599790068285440",
  "geo" : { },
  "id_str" : "445599921060589568",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u4E88\u671F\u305B\u306C\u30A8\u30E9\u30FC\u3067\u7D42\u4E86\u3057\u307E\u3057\u305F\u3001\u524D\u56DE\u306E\u30BB\u30C3\u30B7\u30E7\u30F3\u3092\u5FA9\u5143\u3057\u307E\u3059",
  "id" : 445599921060589568,
  "in_reply_to_status_id" : 445599790068285440,
  "created_at" : "2014-03-17 16:37:54 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3093\u3085\u304D\u3044\u304B",
      "screen_name" : "KA19NDA4",
      "indices" : [ 0, 9 ],
      "id_str" : "2382379614",
      "id" : 2382379614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445599475705188352",
  "geo" : { },
  "id_str" : "445599563743645696",
  "in_reply_to_user_id" : 2382379614,
  "text" : "@KA19NDA4 \u30DB\u30BF\u30C6\u306F\u3072\u3082\u306E\u65B9\u304C\u597D\u304D\u3067\u3059",
  "id" : 445599563743645696,
  "in_reply_to_status_id" : 445599475705188352,
  "created_at" : "2014-03-17 16:36:29 +0000",
  "in_reply_to_screen_name" : "KA19NDA4",
  "in_reply_to_user_id_str" : "2382379614",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445599424664719361",
  "text" : "\u5E72\u7269\u98DF\u3079\u305F\u3044",
  "id" : 445599424664719361,
  "created_at" : "2014-03-17 16:35:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445599189397815296",
  "geo" : { },
  "id_str" : "445599320209776640",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u4ECA\u591C\u306F\u78C1\u6C17\u5D50\u304C\u6FC0\u3057\u3044\u3067\u3059\u304B\u3089\u3057\u304B\u305F\u306A\u3044\u3067\u3059\u306D",
  "id" : 445599320209776640,
  "in_reply_to_status_id" : 445599189397815296,
  "created_at" : "2014-03-17 16:35:31 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445598963706494976",
  "geo" : { },
  "id_str" : "445599088910667776",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u4FDD\u5B58\u304D\u304D\u305D\u3046(\u5C0F\u4E26\u611F)",
  "id" : 445599088910667776,
  "in_reply_to_status_id" : 445598963706494976,
  "created_at" : "2014-03-17 16:34:36 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445598811264528384",
  "text" : "\u6975\u307F\u3067\u306A\u304F\u66F2\u306E\u8AA4\u5909\u63DB\u306A",
  "id" : 445598811264528384,
  "created_at" : "2014-03-17 16:33:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445598747238469632",
  "text" : "\u3042\u308C\u97F3\u30B2\u30FC\u306E\u6975\u3060\u3088\u306D\uFF1F(\u3075\u3042\u3093",
  "id" : 445598747238469632,
  "created_at" : "2014-03-17 16:33:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3053\u308C\u3060\u304B\u3089\u97F3\u30B2\u30FC\u30DE\u30FC\u306F",
      "indices" : [ 13, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445598477565689857",
  "text" : "\u3053\u308C\u3060\u304B\u3089\u97F3\u30B2\u30FC\u30DE\u30FC\u306F\u2026 #\u3053\u308C\u3060\u304B\u3089\u97F3\u30B2\u30FC\u30DE\u30FC\u306F",
  "id" : 445598477565689857,
  "created_at" : "2014-03-17 16:32:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445598292022288384",
  "text" : "\u304D\u3087\u3046\u3075\u306E\u307F\u305D\u3057\u308B",
  "id" : 445598292022288384,
  "created_at" : "2014-03-17 16:31:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445598156810506241",
  "text" : "\u3053\u3053\u3067\u306F\u304D\u3082\u306E\u3092\u306C\u3044\u3067\u304F\u3060\u3055\u3044",
  "id" : 445598156810506241,
  "created_at" : "2014-03-17 16:30:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445597530907082753",
  "text" : "\u6700\u8FD1\u3061\u3047\u308A\u3043\u3055\u3093\u306B\u5BFE\u3057\u3066\u300C\u305D\u308C\u306A\u300D\u4EE5\u5916\u4F55\u3082\u8A00\u3063\u3066\u306A\u3044\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u306F\u3042\u308B",
  "id" : 445597530907082753,
  "created_at" : "2014-03-17 16:28:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445597340343078912",
  "geo" : { },
  "id_str" : "445597392784457728",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u305D\u308C\u306A",
  "id" : 445597392784457728,
  "in_reply_to_status_id" : 445597340343078912,
  "created_at" : "2014-03-17 16:27:51 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445597082733125632",
  "geo" : { },
  "id_str" : "445597150378876929",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u3046\u3093\u3046\u3093",
  "id" : 445597150378876929,
  "in_reply_to_status_id" : 445597082733125632,
  "created_at" : "2014-03-17 16:26:54 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445596886221615104",
  "text" : "\u5B58\u5728\u3068\u5168\u79F0\u3092\u3054\u305F\u307E\u305C\u306B\u3057\u3066\u6279\u5224\u3059\u308B\u4E16\u754C",
  "id" : 445596886221615104,
  "created_at" : "2014-03-17 16:25:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445593382790770688",
  "text" : "\u3066\u304B,IRC\u3084\u3063\u3066\u308B\uFF1F\u7B11",
  "id" : 445593382790770688,
  "created_at" : "2014-03-17 16:11:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445593260807823360",
  "text" : "LINE\u306F\u30AA\u30EF\u30B3\u30F3\u3001\u3053\u308C\u304B\u3089\u306FIRC\u306E\u6642\u4EE3",
  "id" : 445593260807823360,
  "created_at" : "2014-03-17 16:11:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445593152578002944",
  "text" : "\u3084\u3081\u307E\u3057\u305F",
  "id" : 445593152578002944,
  "created_at" : "2014-03-17 16:11:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445592974827610112",
  "text" : "\u4FFA\u306FLINE\u3092\u6B62\u3081\u308B\u305E\uFF01\u30B8\u30E7\u30B8\u30E7\u30FC\u30C3\uFF01\uFF01",
  "id" : 445592974827610112,
  "created_at" : "2014-03-17 16:10:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445592294003970049",
  "text" : "\u4F55\u4E8B\u306B\u3082\u5148\u9054\u304C\u3044\u308B\u3068\u826F\u3044\u611F\u3058(\u5409\u7530\u517C\u597D)",
  "id" : 445592294003970049,
  "created_at" : "2014-03-17 16:07:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445592039292293121",
  "text" : "\u6D77\u3061\u3083\u3093\u306E\u30C4\u30A4\u30FC\u30E8\u3092\u898B\u308B\u9650\u308A\u3001\u6247\u98A8\u6A5F\u306F\u624B\u653E\u3057\u3066\u6B63\u89E3\u3060\u3063\u305F\u307D\u3044",
  "id" : 445592039292293121,
  "created_at" : "2014-03-17 16:06:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445591692683378688",
  "text" : "\u751F\u5354\u304C\u8FD4\u3057\u3066\u304F\u308C\u308B2\u4E07\u5186\u3067\u767D\u677F\u3092\u8CB7\u3046\u8A08\u753B2014",
  "id" : 445591692683378688,
  "created_at" : "2014-03-17 16:05:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445591475217125376",
  "text" : "\u6A5F\u5ACC\u304C\u60AA\u3044\u306E\u304B\u3082\u3057\u308C\u306A\u3044",
  "id" : 445591475217125376,
  "created_at" : "2014-03-17 16:04:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445591270849646593",
  "text" : "\u3044\u3044\u305F\u304B\u3063\u305F\u3044\u3063\u3066\u308B\u306E\u3067\u306F",
  "id" : 445591270849646593,
  "created_at" : "2014-03-17 16:03:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445591237693685761",
  "text" : "\u305A\u3063\u3068\u8A00\u3044\u305F\u304B\u3063\u305F\u3053\u3068\u3092\u30D5\u30A9\u30ED\u30EF\u30FC\u3055\u3093\u304C\u30BA\u30B1\u30BA\u30B1\u8A00\u3063\u3066\u304F\u308C\u308B\uFF1F\uFF1F\uFF1F\uFF1F\u3075\u30FC\u30FC\u30FC\u3093",
  "id" : 445591237693685761,
  "created_at" : "2014-03-17 16:03:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445590762403545088",
  "text" : "\u30B9\u30AE\u30B9\u30EC\u30A4\u30E4\u30FC",
  "id" : 445590762403545088,
  "created_at" : "2014-03-17 16:01:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445590720825397248",
  "text" : "\u6749\u3001\u6B7B\u3059\u3079\u3057",
  "id" : 445590720825397248,
  "created_at" : "2014-03-17 16:01:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445589617908019200",
  "text" : "\u3058\u308F\u3042\u305B\u304C\u3057\u308F\u3057\u308F\u3057\u308F",
  "id" : 445589617908019200,
  "created_at" : "2014-03-17 15:56:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445589543110971395",
  "text" : "\u5E78\u305B\u304C\u3058\u308F\u3058\u308F\u3058\u308F",
  "id" : 445589543110971395,
  "created_at" : "2014-03-17 15:56:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445589204228005888",
  "text" : "\uFF8A\uFF9F\uFF8A\uFF9F\uFF8A\uFF9F\uFF8A\uFF9F\uFF8A\uFF9F\uFF69\uFF9C\uFF70(\uFF84\uFF9E\uFF84\uFF9E\uFF9D",
  "id" : 445589204228005888,
  "created_at" : "2014-03-17 15:55:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445588999344635904",
  "text" : "\u30DB\u30B3\u30EA\u3068\u82B1\u7C89\u3067\u76EE\u3068\u9F3B\u304B\u3089\u3044\u308D\u3044\u308D\u3060\u3089\u3060\u3089",
  "id" : 445588999344635904,
  "created_at" : "2014-03-17 15:54:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u975E\u60C5\u306A\u3046\u307F\u3061\u3087\u3053\u661F\u4EBA",
      "screen_name" : "umichoco611",
      "indices" : [ 0, 12 ],
      "id_str" : "2392701194",
      "id" : 2392701194
    }, {
      "name" : "\u3055\u304B\u306A",
      "screen_name" : "wa_ta_si_",
      "indices" : [ 13, 23 ],
      "id_str" : "230481483",
      "id" : 230481483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445587588221386752",
  "geo" : { },
  "id_str" : "445588825423626241",
  "in_reply_to_user_id" : 2392701194,
  "text" : "@umichoco611 @wa_ta_si_ \u307B\u3093\u3068\u3067\u3059\u304B\uFF01\uFF01\uFF01\uFF01(\u604D\u60DA",
  "id" : 445588825423626241,
  "in_reply_to_status_id" : 445587588221386752,
  "created_at" : "2014-03-17 15:53:49 +0000",
  "in_reply_to_screen_name" : "umichoco611",
  "in_reply_to_user_id_str" : "2392701194",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445588547114786816",
  "text" : "\u3042\u3068\u306F\u5929\u6C17\u6B21\u7B2C\u304B",
  "id" : 445588547114786816,
  "created_at" : "2014-03-17 15:52:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445588502348984320",
  "text" : "\u9593\u306B\u5408\u308F\u306A\u304F\u3082\u306A\u3044\u3051\u3069",
  "id" : 445588502348984320,
  "created_at" : "2014-03-17 15:52:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445588035564888066",
  "text" : "\u3046\u30FC\u3093\u300121\u65E5\u671D\u306B\u306F\u9593\u306B\u5408\u3046\u6C17\u914D\u306A\u3057",
  "id" : 445588035564888066,
  "created_at" : "2014-03-17 15:50:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445587313947467776",
  "text" : "\u65E5\u672C\u306F\u5C71\u304C\u591A\u3044\u56FD\u3060\u306A\u3042",
  "id" : 445587313947467776,
  "created_at" : "2014-03-17 15:47:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445537070585364481",
  "text" : "\u9F3B\u304C\u60B2\u9CF4\u3092\u3042\u3052\u7D9A\u3051\u3066\u308B",
  "id" : 445537070585364481,
  "created_at" : "2014-03-17 12:28:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445536887709515776",
  "text" : "\u5916\u306F\u82B1\u7C89\u3001\u4E2D\u306F\u30DB\u30B3\u30EA\u3001\u306A\u30FC\u3093\u3060\uFF1F",
  "id" : 445536887709515776,
  "created_at" : "2014-03-17 12:27:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445532681023922176",
  "text" : "\u6247\u98A8\u6A5F\u30C7\u30EA\u30D0\u30EA\u30FC\u304A\u3058\u3055\u3093",
  "id" : 445532681023922176,
  "created_at" : "2014-03-17 12:10:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445526585110564864",
  "geo" : { },
  "id_str" : "445527165707112448",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u3054\u3081\u3093\u306A\u3055\u3044\u3001\u4ED6\u306E\u4EBA\u3067\u6B32\u3057\u3044\u4EBA\u3044\u308B\u3088\u3046\u306A\u306E\u3067\u305D\u3063\u3061\u306B\u3042\u3052\u307E\u3059\u306D\u3002\u8A00\u3044\u51FA\u3057\u3066\u7F6E\u3044\u3066\u3054\u3081\u3093\u306A\u3055\u3044\u3002",
  "id" : 445527165707112448,
  "in_reply_to_status_id" : 445526585110564864,
  "created_at" : "2014-03-17 11:48:48 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445522671522967552",
  "geo" : { },
  "id_str" : "445525553500536832",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u3042\u30FC\u307E\u3060\u6D41\u77F3\u306B\u3044\u306A\u3044\u3088\u306A\u2026",
  "id" : 445525553500536832,
  "in_reply_to_status_id" : 445522671522967552,
  "created_at" : "2014-03-17 11:42:24 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445511795147407360",
  "geo" : { },
  "id_str" : "445521587182137344",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u5F15\u3063\u8D8A\u3057\u3066\u304F\u308B\u306E\u306F\u3044\u3064\u3067\u3059\u304B\uFF1F(\u8AB0\u304B\u306B\u9810\u3051\u308B\u5F62\u306B\u306A\u308B\u304B\u3068\u601D\u3044\u307E\u3059\u304C)",
  "id" : 445521587182137344,
  "in_reply_to_status_id" : 445511795147407360,
  "created_at" : "2014-03-17 11:26:38 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445405500272689153",
  "text" : "\u3042\u3063\u3068\u8AB0\u304B\n\u6247\u98A8\u6A5F\u6B32\u3057\u3044\u4EBA\u3044\u307E\u305B\u3093\u304B",
  "id" : 445405500272689153,
  "created_at" : "2014-03-17 03:45:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6B7B\u3057\u3066\u5C4D\u62FE\u3046\u3082\u306E\u306A\u3057",
      "screen_name" : "pankashi",
      "indices" : [ 0, 9 ],
      "id_str" : "137961719",
      "id" : 137961719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445284170072223744",
  "in_reply_to_user_id" : 137961719,
  "text" : "@pankashi \u305B\uFF0C\u6247\u98A8\u6A5F\u307B\u3057\u304F\u306A\u3044\u3067\u3059\u304B\uFF1F",
  "id" : 445284170072223744,
  "created_at" : "2014-03-16 19:43:13 +0000",
  "in_reply_to_screen_name" : "pankashi",
  "in_reply_to_user_id_str" : "137961719",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pixiv",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/8FMFeLACFE",
      "expanded_url" : "http:\/\/www.pixiv.net\/member_illust.php?illust_id=42293911&mode=medium",
      "display_url" : "pixiv.net\/member_illust.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "445282750405156864",
  "text" : "pixiv\u306B\u6295\u7A3F\u3057\u307E\u3057\u305F \u7DB2\u4EA4\u63DB\u30DE\u30F3 #pixiv http:\/\/t.co\/8FMFeLACFE",
  "id" : 445282750405156864,
  "created_at" : "2014-03-16 19:37:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445221654507970561",
  "geo" : { },
  "id_str" : "445221720329162753",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u5341\u5206\u697D\u3057\u304B\u3063\u305F\u3067\u3059",
  "id" : 445221720329162753,
  "in_reply_to_status_id" : 445221654507970561,
  "created_at" : "2014-03-16 15:35:04 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445221650695323648",
  "text" : "\u7D50\u5C40\u5168\u76DB\u671F\u306F\u7DB2\u4EA4\u63DB\u30DE\u30F3\u3060\u3063\u305F\u611F\u3058",
  "id" : 445221650695323648,
  "created_at" : "2014-03-16 15:34:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445221443224104960",
  "text" : "\u3042\u30FC\u3001\u697D\u3057\u304B\u3063\u305F",
  "id" : 445221443224104960,
  "created_at" : "2014-03-16 15:33:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445221123685236737",
  "text" : "\u7D30\u304B\u3059\u304E\u3066\u4F1D\u308F\u3089\u306A\u3044\u3042\u3063\u3061\u3063\u3061\u7802\u6F20",
  "id" : 445221123685236737,
  "created_at" : "2014-03-16 15:32:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445221072321777664\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/6GgX5HFA3S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi2-NMgCcAAAEZt.jpg",
      "id_str" : "445221072082726912",
      "id" : 445221072082726912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi2-NMgCcAAAEZt.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/6GgX5HFA3S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445221072321777664",
  "text" : "\u30D4\u30E9\u30DF\u30C3\u30C9 http:\/\/t.co\/6GgX5HFA3S",
  "id" : 445221072321777664,
  "created_at" : "2014-03-16 15:32:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445219223682301953\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/8yxQzr0d19",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi28hlYCEAAQLHP.jpg",
      "id_str" : "445219223334162432",
      "id" : 445219223334162432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi28hlYCEAAQLHP.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/8yxQzr0d19"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445219223682301953",
  "text" : "\u590F\u76EE\u6F31\u77F3 http:\/\/t.co\/8yxQzr0d19",
  "id" : 445219223682301953,
  "created_at" : "2014-03-16 15:25:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitcasting.tv\/\" rel=\"nofollow\"\u003ETwitCasting\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/1294Tr6zAN",
      "expanded_url" : "http:\/\/moi.st\/2bd0c42",
      "display_url" : "moi.st\/2bd0c42"
    } ]
  },
  "geo" : { },
  "id_str" : "445217328007880704",
  "text" : "\u5F8C\u4E8C\u3064\u304A\u984C\u304F\u3060\u3055\u3044!! http:\/\/t.co\/1294Tr6zAN",
  "id" : 445217328007880704,
  "created_at" : "2014-03-16 15:17:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445216764473786368",
  "geo" : { },
  "id_str" : "445216897433219073",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u305D\u308C\u306A\u2026",
  "id" : 445216897433219073,
  "in_reply_to_status_id" : 445216764473786368,
  "created_at" : "2014-03-16 15:15:54 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445216314232037376\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/sEoHF1gFom",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi254OYCUAARCR3.jpg",
      "id_str" : "445216313762271232",
      "id" : 445216313762271232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi254OYCUAARCR3.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/sEoHF1gFom"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445216314232037376",
  "text" : "\u898B\u306A\u3044\u3067\u66F8\u304D\u307E\u3057\u305F\u304C\u30A4\u30E1\u30FC\u30B8\u3057\u305F\u5B9F\u7269\u304C\u3053\u3061\u3089 http:\/\/t.co\/sEoHF1gFom",
  "id" : 445216314232037376,
  "created_at" : "2014-03-16 15:13:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445215918243586049\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/DqnYDoJmaH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi25hL-CYAE5g1r.jpg",
      "id_str" : "445215917979361281",
      "id" : 445215917979361281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi25hL-CYAE5g1r.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/DqnYDoJmaH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445215918243586049",
  "text" : "\u91A4\u6CB9\u5DEE\u3057 http:\/\/t.co\/DqnYDoJmaH",
  "id" : 445215918243586049,
  "created_at" : "2014-03-16 15:12:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445215818939256832",
  "text" : "\u91A4\u6CB9\u5DEE\u3057",
  "id" : 445215818939256832,
  "created_at" : "2014-03-16 15:11:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445214596287037441\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/vbbx2gPf7k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi24UPDCAAADA1k.jpg",
      "id_str" : "445214595955687424",
      "id" : 445214595955687424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi24UPDCAAADA1k.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/vbbx2gPf7k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445214596287037441",
  "text" : "\u30BC\u30EA\u30FC\u3055\u3093 http:\/\/t.co\/vbbx2gPf7k",
  "id" : 445214596287037441,
  "created_at" : "2014-03-16 15:06:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitcasting.tv\/\" rel=\"nofollow\"\u003ETwitCasting\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/1294Tr6zAN",
      "expanded_url" : "http:\/\/moi.st\/2bd0c42",
      "display_url" : "moi.st\/2bd0c42"
    } ]
  },
  "geo" : { },
  "id_str" : "445213659858337794",
  "text" : "\u30E2\u30A4\uFF01iPad\u304B\u3089\u30AD\u30E3\u30B9\u914D\u4FE1\u4E2D -\u304A\u984C\u304F\u3060\u3055\u3044\u306A http:\/\/t.co\/1294Tr6zAN",
  "id" : 445213659858337794,
  "created_at" : "2014-03-16 15:03:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445213162065772544\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/FTFUfKqSum",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi23AwcCQAAoQee.jpg",
      "id_str" : "445213161809920000",
      "id" : 445213161809920000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi23AwcCQAAoQee.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/FTFUfKqSum"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445213162065772544",
  "text" : "\u4F55\u304B\u9055\u3046\u3082\u306E\u304C\u51FA\u6765\u4E0A\u304C\u3063\u305F http:\/\/t.co\/FTFUfKqSum",
  "id" : 445213162065772544,
  "created_at" : "2014-03-16 15:01:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445212306884931584",
  "text" : "\u304A\u984C\u304F\u3060\u3055\u3044",
  "id" : 445212306884931584,
  "created_at" : "2014-03-16 14:57:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445212028240551937\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/hTmy4UNrux",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi21-wQCcAAzJRx.jpg",
      "id_str" : "445212027888234496",
      "id" : 445212027888234496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi21-wQCcAAzJRx.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/hTmy4UNrux"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445212028240551937",
  "text" : "\u6247\u98A8\u6A5F\u300CAh\u301C\u300D http:\/\/t.co\/hTmy4UNrux",
  "id" : 445212028240551937,
  "created_at" : "2014-03-16 14:56:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445210140455604224\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ocBos7Fioc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi20Q37CAAEdMU8.jpg",
      "id_str" : "445210140161998849",
      "id" : 445210140161998849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi20Q37CAAEdMU8.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/ocBos7Fioc"
    } ],
    "hashtags" : [ {
      "text" : "\u3069\u3046\u307F\u3066\u3082\u821E\u5993\u3058\u3083\u306A\u3044",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445210140455604224",
  "text" : "\u300C\u3069\u3059\u3048\u300D#\u3069\u3046\u307F\u3066\u3082\u821E\u5993\u3058\u3083\u306A\u3044 http:\/\/t.co\/ocBos7Fioc",
  "id" : 445210140455604224,
  "created_at" : "2014-03-16 14:49:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445207868711501824",
  "text" : "\u821E\u5993\u3055\u3093\u306E\u7279\u5FB4\u304F\u3060\u3055\u3044",
  "id" : 445207868711501824,
  "created_at" : "2014-03-16 14:40:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445207267348983808\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/D26lqkzHAK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi2xpouCQAElBtY.jpg",
      "id_str" : "445207267042803713",
      "id" : 445207267042803713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi2xpouCQAElBtY.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/D26lqkzHAK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445207267348983808",
  "text" : "\u6C60\u306E\u4E2D\u306B\u3042\u308B\u3068\u3044\u3046\u91D1\u95A3\u5BFA http:\/\/t.co\/D26lqkzHAK",
  "id" : 445207267348983808,
  "created_at" : "2014-03-16 14:37:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitcasting.tv\/\" rel=\"nofollow\"\u003ETwitCasting\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/yc7QdFTEAk",
      "expanded_url" : "http:\/\/moi.st\/2bceb4b",
      "display_url" : "moi.st\/2bceb4b"
    } ]
  },
  "geo" : { },
  "id_str" : "445206107573608448",
  "text" : "\u30E2\u30A4\uFF01iPad\u304B\u3089\u30AD\u30E3\u30B9\u914D\u4FE1\u4E2D -\u304A\u984C\u304F\u3060\u3055\u3044 http:\/\/t.co\/yc7QdFTEAk",
  "id" : 445206107573608448,
  "created_at" : "2014-03-16 14:33:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445205396240621568",
  "text" : "\u91D1\u95A3\u5BFA\u306E\u7279\u5FB4\u304F\u3060\u3055\u3044",
  "id" : 445205396240621568,
  "created_at" : "2014-03-16 14:30:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445204730516475904",
  "text" : "\u3042\u30FC\u3063\u3066\u8A00\u3063\u3066\u308B\u3069\u3046\u3057\u3066\u3053\u3046\u306A\u308B",
  "id" : 445204730516475904,
  "created_at" : "2014-03-16 14:27:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445204558222868480\/photo\/1",
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/8NUCuNFgNE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi2vL8dCcAA5e0C.jpg",
      "id_str" : "445204557920890880",
      "id" : 445204557920890880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi2vL8dCcAA5e0C.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/8NUCuNFgNE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445204558222868480",
  "text" : "\u88F8\u5A66 http:\/\/t.co\/8NUCuNFgNE",
  "id" : 445204558222868480,
  "created_at" : "2014-03-16 14:26:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beepcap Z3(\u9632\u6C34)",
      "screen_name" : "beepcap",
      "indices" : [ 0, 8 ],
      "id_str" : "3933721",
      "id" : 3933721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445201986841882624",
  "geo" : { },
  "id_str" : "445202070618918912",
  "in_reply_to_user_id" : 3933721,
  "text" : "@beepcap \u3060\u3001\u5927\u4E08\u592B\u3067\u3059\u2026",
  "id" : 445202070618918912,
  "in_reply_to_status_id" : 445201986841882624,
  "created_at" : "2014-03-16 14:16:59 +0000",
  "in_reply_to_screen_name" : "beepcap",
  "in_reply_to_user_id_str" : "3933721",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445201743349968897\/photo\/1",
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/wBqsJ5vVFh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi2soGICYAAmPLP.jpg",
      "id_str" : "445201743018614784",
      "id" : 445201743018614784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi2soGICYAAmPLP.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/wBqsJ5vVFh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445201743349968897",
  "text" : "\u8033\u8840 http:\/\/t.co\/wBqsJ5vVFh",
  "id" : 445201743349968897,
  "created_at" : "2014-03-16 14:15:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445200211262963712",
  "text" : "\u3042\u308C\u3001\u3048\u3093\u3069\u3055\u3093\u601D\u3063\u305F\u3088\u308A\u4E0A\u624B\u306A\u306E\u3067\u306F\u3001\u306A\u3069\u306E\u58F0\u3092\u304A\u5F85\u3061\u3057\u3066\u304A\u308A\u307E\u3059",
  "id" : 445200211262963712,
  "created_at" : "2014-03-16 14:09:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445200087682002944",
  "text" : "\u30BC\u30EA\u30FC\u3055\u3093\u300C\u67D0\u4EBA\u9593\u306F\u7518\u3048\u300D",
  "id" : 445200087682002944,
  "created_at" : "2014-03-16 14:09:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/445199999337381888\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/qFzzbseV1z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi2rCjNCYAA4Bbw.jpg",
      "id_str" : "445199998477557760",
      "id" : 445199998477557760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi2rCjNCYAA4Bbw.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/qFzzbseV1z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445199999337381888",
  "text" : "\u4E00\u3064\u76EE\u306E\u304A\u984C\u3001\u7DB2\u4EA4\u63DB\u30DE\u30F3 http:\/\/t.co\/qFzzbseV1z",
  "id" : 445199999337381888,
  "created_at" : "2014-03-16 14:08:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitcasting.tv\/\" rel=\"nofollow\"\u003ETwitCasting\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/9AVT5Oswl5",
      "expanded_url" : "http:\/\/moi.st\/2bcc835",
      "display_url" : "moi.st\/2bcc835"
    } ]
  },
  "geo" : { },
  "id_str" : "445198518513184769",
  "text" : "\u30E2\u30A4\uFF01iPad\u304B\u3089\u30AD\u30E3\u30B9\u914D\u4FE1\u4E2D -\u304A\u7D75\u304B\u304D\u3057\u307E\u3059 http:\/\/t.co\/9AVT5Oswl5",
  "id" : 445198518513184769,
  "created_at" : "2014-03-16 14:02:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445195162793177088",
  "geo" : { },
  "id_str" : "445195353977942016",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u306F\uFF0C\u306F\u3042\u304F\u3057\u307E\u3057\u305F",
  "id" : 445195353977942016,
  "in_reply_to_status_id" : 445195162793177088,
  "created_at" : "2014-03-16 13:50:18 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445195260465917952",
  "text" : "\u304A\u624B\u672C\u3068\u304B\u898B\u306A\u304C\u3089\u66F8\u3044\u3066\u3082\u4E0A\u624B\u304F\u66F8\u3051\u306A\u3044\u4EBA\u304C\u304A\u624B\u672C\u3082\u898B\u305A\u306B\u7D75\u3092\u66F8\u3044\u305F\u3089\u3069\u3046\u306A\u308B\u304B\uFF0C\u6559\u3048\u3066\u3084\u308B",
  "id" : 445195260465917952,
  "created_at" : "2014-03-16 13:49:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445193234843570176",
  "geo" : { },
  "id_str" : "445194851567419392",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u307B\u304B\u306E\u304A\u3060\u3044\u3092\u6295\u3052\u3066\u304F\u3060\u3055\u3044\u306A",
  "id" : 445194851567419392,
  "in_reply_to_status_id" : 445193234843570176,
  "created_at" : "2014-03-16 13:48:18 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445194755555594240",
  "text" : "\u3069\u3046\u304B\u3093\u304C\u3048\u3066\u3082Emacs\u304B\u3089\u306E\u307B\u3046\u304C\u30C4\u30A4\u30FC\u30C8\u3057\u3084\u3059\u3044\u4F53\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F",
  "id" : 445194755555594240,
  "created_at" : "2014-03-16 13:47:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3063\u304F\u3093",
      "screen_name" : "chr1233",
      "indices" : [ 0, 8 ],
      "id_str" : "145536184",
      "id" : 145536184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445192797629341696",
  "geo" : { },
  "id_str" : "445193145408434176",
  "in_reply_to_user_id" : 145536184,
  "text" : "@chr1233 \u3053\u306E\u307E\u3048\u304B\u3044\u305F\u3093\u3067\u3059\u2026",
  "id" : 445193145408434176,
  "in_reply_to_status_id" : 445192797629341696,
  "created_at" : "2014-03-16 13:41:31 +0000",
  "in_reply_to_screen_name" : "chr1233",
  "in_reply_to_user_id_str" : "145536184",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445193035756748800",
  "text" : "\u3053\u308C\u304C\u4E16\u754C\u306E\u9078\u629E\u304B\u2026",
  "id" : 445193035756748800,
  "created_at" : "2014-03-16 13:41:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 3, 15 ],
      "id_str" : "588420029",
      "id" : 588420029
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 17, 27 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445192977904705536",
  "text" : "RT @axis_ponpon: @end313124 \u7DB2\u4EA4\u63DB\u3059\u308B\u4EBA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "445192560726659072",
    "geo" : { },
    "id_str" : "445192805120360448",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u7DB2\u4EA4\u63DB\u3059\u308B\u4EBA",
    "id" : 445192805120360448,
    "in_reply_to_status_id" : 445192560726659072,
    "created_at" : "2014-03-16 13:40:10 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "protected" : false,
      "id_str" : "588420029",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607281463784964096\/UHWx7ZuN_normal.jpg",
      "id" : 588420029,
      "verified" : false
    }
  },
  "id" : 445192977904705536,
  "created_at" : "2014-03-16 13:40:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445192740448374784",
  "text" : "\u9F3B\u8840\u3068\u304B\u8A00\u3046\u5974\u306F\u30B9\u30EB\u30FC\u30FC\u3059\u308B",
  "id" : 445192740448374784,
  "created_at" : "2014-03-16 13:39:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445192560726659072",
  "text" : "\u3042\u3068\uFF11\uFF0C\uFF12\u6642\u9593\u4EE5\u5185\u306B\u304A\u7D75\u304B\u304D\u30C4\u30A4\u30AD\u30E3\u30B9\u3057\u307E\u3059\uFF0E\u304A\u984C\u3092\u6295\u3052\u3066\u304F\u308C\u308B\u3068\u697D\u3057\u3044\uFF0E",
  "id" : 445192560726659072,
  "created_at" : "2014-03-16 13:39:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ask.fm\/\" rel=\"nofollow\"\u003EAsk.fm\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/rlxc0tTH1i",
      "expanded_url" : "http:\/\/ask.fm\/a\/afo3gem5",
      "display_url" : "ask.fm\/a\/afo3gem5"
    } ]
  },
  "geo" : { },
  "id_str" : "445191671756914688",
  "text" : "\u3044\u3064\u3082\u30D4\u30B6\u306F\u4F55\u679A\u98DF\u3079\u307E\u3059\u304B? \u2014 \u96F6\u679A http:\/\/t.co\/rlxc0tTH1i",
  "id" : 445191671756914688,
  "created_at" : "2014-03-16 13:35:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445167698700288001",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 445167698700288001,
  "created_at" : "2014-03-16 12:00:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u69FD\u30BC\u30EA\u5B50",
      "screen_name" : "Jelly_in_a_tank",
      "indices" : [ 0, 16 ],
      "id_str" : "138430452",
      "id" : 138430452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445140764800987138",
  "geo" : { },
  "id_str" : "445141647785852928",
  "in_reply_to_user_id" : 138430452,
  "text" : "@Jelly_in_a_tank \u3042\u3052\u308B",
  "id" : 445141647785852928,
  "in_reply_to_status_id" : 445140764800987138,
  "created_at" : "2014-03-16 10:16:53 +0000",
  "in_reply_to_screen_name" : "Jelly_in_a_tank",
  "in_reply_to_user_id_str" : "138430452",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445137515746308096",
  "text" : "\u3082\u3046\u3061\u3087\u3044\u3044\u308D\u3044\u308D\u3044\u3089\u3093\u3082\u3093\u51FA\u3066\u6765\u305F\u3089\u544A\u77E5\u3057\u3066\u307F\u308B\u304B",
  "id" : 445137515746308096,
  "created_at" : "2014-03-16 10:00:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445137401950654465",
  "text" : "\u6247\u98A8\u6A5F\u3068\u30E9\u30A4\u30C8\u306E\u62B1\u304D\u5408\u308F\u305B\u8B72\u6E21\u3057\u305F\u3044\u2026",
  "id" : 445137401950654465,
  "created_at" : "2014-03-16 10:00:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445136979324186624",
  "text" : "\u6020\u60F0\u4EBA\u9593\u306F\u6020\u60F0\u3067\u3042\u308B\u3053\u3068\u304C\u3068\u3066\u3082\u591A\u3044",
  "id" : 445136979324186624,
  "created_at" : "2014-03-16 09:58:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445115675011325952",
  "text" : "\u5B8C",
  "id" : 445115675011325952,
  "created_at" : "2014-03-16 08:33:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445109467189768192",
  "text" : "\u3066\u3051\u3066\u3051\u3066\u3051\u3066\u3063\u3051\u3063\u3066\u30FC",
  "id" : 445109467189768192,
  "created_at" : "2014-03-16 08:09:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445090769490038785",
  "text" : "\u304A\u304B\u3048\u308A\u305B\u304B\u3044",
  "id" : 445090769490038785,
  "created_at" : "2014-03-16 06:54:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/6C79SClz9K",
      "expanded_url" : "http:\/\/quizshow2.dominos.jp\/topics\/",
      "display_url" : "quizshow2.dominos.jp\/topics\/"
    } ]
  },
  "geo" : { },
  "id_str" : "444817465030103040",
  "text" : "\u30D4\u30B6\u3092\u5F85\u3064\u6642\u9593\u304C\u3001\u30A8\u30AF\u30BB\u30EC\u30F3\u30C8\u306A\u30B7\u30E7\u30FC\u30BF\u30A4\u30E0\u306B\uFF01\n\u6CE8\u6587\u3057\u305F\u30D4\u30B6\u306E\u72B6\u6CC1\u3092\u30EA\u30A2\u30EB\u30BF\u30A4\u30E0\u3067\u78BA\u8A8D\u3057\u306A\u304C\u3089\u3001\u3055\u3089\u306B\u30AF\u30A4\u30BA\u3082\u697D\u3057\u3081\u308B\u65B0\u611F\u899A\u30B3\u30F3\u30C6\u30F3\u30C4\u3002\n\u30AF\u30A4\u30BA\u306B\u6B63\u89E3\u3059\u308B\u3068\u30AF\u30FC\u30DD\u30F3\u3092\u30D7\u30EC\u30BC\u30F3\u30C8\uFF01\n http:\/\/t.co\/6C79SClz9K",
  "id" : 444817465030103040,
  "created_at" : "2014-03-15 12:48:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444805294430760960",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 444805294430760960,
  "created_at" : "2014-03-15 12:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444756037715759104",
  "text" : "\u9593\u306B\u3042\u3046\u306E\u304B\u2026",
  "id" : 444756037715759104,
  "created_at" : "2014-03-15 08:44:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444550452604968960",
  "text" : "\u3082\u3046\u306D\u3088\u3046",
  "id" : 444550452604968960,
  "created_at" : "2014-03-14 19:07:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me coming",
      "screen_name" : "coscos2coscos",
      "indices" : [ 1, 15 ],
      "id_str" : "470868127",
      "id" : 470868127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444520640003862528",
  "text" : ".@coscos2coscos \u3075\u3041\u307C\u3063\u3066\u306A\u3044\u3067\u52C9\u5F37\u3057\u306A\u3044\u3068\u307E\u305F\u7559\u5E74\u3059\u308B\u305E",
  "id" : 444520640003862528,
  "created_at" : "2014-03-14 17:09:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444520501877030912",
  "text" : "\u3053\u308C\u7559\u5E74\u304C\u3057\u305F\u3044\u308F\u3051\u3058\u3083\u3042\u306A\u3044\u306A",
  "id" : 444520501877030912,
  "created_at" : "2014-03-14 17:08:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u501F\u308A\u65C5\u884C\u306E\u30C8\u30DE\u30B8\u30A6\u30B9",
      "screen_name" : "kagyu_phis",
      "indices" : [ 0, 11 ],
      "id_str" : "129850436",
      "id" : 129850436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444520020068954113",
  "geo" : { },
  "id_str" : "444520460865138688",
  "in_reply_to_user_id" : 129850436,
  "text" : "@kagyu_phis \u304A\u91D1\u304C5\u5104\u304F\u3089\u3044\u3042\u308C\u3070\u3084\u308A\u305F\u3044\u3067\u3059\u306D\u3001\u7D4C\u6E08\u3068\u304B\u60C5\u5831\u3068\u304B\u6CD5\u3068\u304B",
  "id" : 444520460865138688,
  "in_reply_to_status_id" : 444520020068954113,
  "created_at" : "2014-03-14 17:08:31 +0000",
  "in_reply_to_screen_name" : "kagyu_phis",
  "in_reply_to_user_id_str" : "129850436",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444519893762072576",
  "geo" : { },
  "id_str" : "444520274063413248",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u6D3E\u306F\u3042\u3063\u3066\u3082\u6226\u4E89\u306F\u3057\u306A\u3044\u3088\u306D\u30FC\u3001\u9762\u767D\u3044\u4EBA\u306B\u306F\u5168\u8A71\u9762\u767D\u3044\u3057\u3001\u9762\u767D\u3044\u3068\u601D\u308F\u306A\u3044\u4EBA\u306B\u306F\u305F\u3076\u3093\u5168\u8A71\u9762\u767D\u304F\u306A\u3044\u3002[\u8003\u3048\u308C\u3070\u8003\u3048\u308B\u307B\u3069\u5947\u5999\u306A\u4F5C\u54C1\u3060]",
  "id" : 444520274063413248,
  "in_reply_to_status_id" : 444519893762072576,
  "created_at" : "2014-03-14 17:07:46 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u501F\u308A\u65C5\u884C\u306E\u30C8\u30DE\u30B8\u30A6\u30B9",
      "screen_name" : "kagyu_phis",
      "indices" : [ 0, 11 ],
      "id_str" : "129850436",
      "id" : 129850436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444519793870131200",
  "geo" : { },
  "id_str" : "444519836039651328",
  "in_reply_to_user_id" : 129850436,
  "text" : "@kagyu_phis \u306A\u2026\u306A\u308B\u307B\u3069\u2026",
  "id" : 444519836039651328,
  "in_reply_to_status_id" : 444519793870131200,
  "created_at" : "2014-03-14 17:06:02 +0000",
  "in_reply_to_screen_name" : "kagyu_phis",
  "in_reply_to_user_id_str" : "129850436",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444519521554927616",
  "text" : "@jumpiko \u8ABF\u6574\u3082\u98F2\u307E\u305B\u305F\u3051\u3069\u5FAE\u5999\u30EA\u30A2\u30AF\u30B7\u30E7\u30F3",
  "id" : 444519521554927616,
  "created_at" : "2014-03-14 17:04:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444519447294791681",
  "text" : "\u5B9F\u969B\u8C46\u4E73\u306F\u6614\u3088\u308A\u4ECA\u306E\u307B\u3046\u304C\u7F8E\u5473\u3057\u304F\u306A\u3063\u305F\u3068\u306F\u601D\u3046\u304C",
  "id" : 444519447294791681,
  "created_at" : "2014-03-14 17:04:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444519351467511808",
  "text" : "@jumpiko \u3046\u3061\u306E\u89AA\u3082\u8C46\u4E73\u5ACC\u3044\u3060\u3051\u3069\u5E74\u4EE3\u3067\u4F55\u304B\u3042\u308B\u306E\u304B\u306D",
  "id" : 444519351467511808,
  "created_at" : "2014-03-14 17:04:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444519262376312832",
  "text" : "\u7D50\u5C40\u3053\u306E\u611F\u3058\u3063\u3066\u3075\u308F\u3063\u3068\u3057\u3066\u305F",
  "id" : 444519262376312832,
  "created_at" : "2014-03-14 17:03:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444518990090493953",
  "geo" : { },
  "id_str" : "444519222626889728",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u3059\u3063\u3054\u3044\u30DF\u30AF\u30ED\u306B\u3053\u306E\u30B7\u30FC\u30F3\u306E\u3053\u306E\u30AD\u30E3\u30E9\u306E\u3053\u306E\u611F\u3058\u304C\u826F\u3044\u3001\u307F\u305F\u3044\u306B\u306A\u308B\u4E8B\u3082\u3042\u308B",
  "id" : 444519222626889728,
  "in_reply_to_status_id" : 444518990090493953,
  "created_at" : "2014-03-14 17:03:36 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444518850264961024",
  "text" : "@jumpiko \u89AA\u306B\u52DD\u3066\u306A\u3044\u69CB\u9020\u3060\u3088\u306D(\u8CA1\u653F\u7684\u306B?)",
  "id" : 444518850264961024,
  "created_at" : "2014-03-14 17:02:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444518711114747905",
  "text" : "\u30B9\u30D4\u30FC\u30C9\u3092\u30BF\u30FC\u30F3\u6027\u306B\u3057\u305F\u5168\u304F\u65B0\u3057\u3044\u904A\u3073\u3001\u30B9\u30ED\u30FC\u3068\u3044\u3046\u306E\u3092\u7D20\u6570\u6C0F\u306B\u7FD2\u3063\u305F\u3051\u3069\u5168\u304F\u30AF\u30BD\u30B2\u30FC\u3067\u3042\u3063\u305F",
  "id" : 444518711114747905,
  "created_at" : "2014-03-14 17:01:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444518464363839489",
  "text" : "\u69CB\u9020\u7684\u306B\u89AA\u306E\u65B9\u304C\u5F37\u3044",
  "id" : 444518464363839489,
  "created_at" : "2014-03-14 17:00:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444518425059016706",
  "text" : "@jumpiko \u89AA\u3068\u8C46\u4E73\u6226\u4E89\u3067\u3082\u3057\u3066\u308B\u306E\u304B\u3068\u601D\u3063\u305F\u3001\u3069\u3063\u3061\u304C\u3088\u308A\u591A\u304F\u8C46\u4E73\u3092\u98F2\u3081\u308B\u304B\u3001\u307F\u305F\u3044\u306A",
  "id" : 444518425059016706,
  "created_at" : "2014-03-14 17:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444518052655136768",
  "text" : "@jumpiko \u3058\u3085\u3093\u3074\u3053\u304C\u98F2\u307F\u904E\u304E\u3060\u304B\u3089\u89AA\u304C\u96A0\u3057\u3066\u3044\u308B\u3001\u3068\u3044\u3046\u610F\u5473\u3067\u3057\uFF1F",
  "id" : 444518052655136768,
  "created_at" : "2014-03-14 16:58:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444517735695794177",
  "text" : "\u5B66\u90E8\u3067\u306F\u3082\u3046\u51FA\u6765\u306A\u3044",
  "id" : 444517735695794177,
  "created_at" : "2014-03-14 16:57:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444517676522549248",
  "text" : "\u7559\u5E74\u3068\u3044\u3046\u3084\u3064\u3001\u4E00\u5EA6\u3057\u3066\u898B\u305F\u304B\u3063\u305F\u306A\u3041(\u717D",
  "id" : 444517676522549248,
  "created_at" : "2014-03-14 16:57:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444517420028293120",
  "text" : "\u5148\u306B\u30ED\u30FC\u30E4\u30EB\u98F2\u307F\u5207\u308C\u3088\u611Fis",
  "id" : 444517420028293120,
  "created_at" : "2014-03-14 16:56:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444517347940782080",
  "text" : "\u4ECA\u306F\u3082\u3046\u751F\u7523\u3057\u3066\u306A\u3044\u5C71\u5D0E10\u5E74\u306E\u30CF\u30FC\u30D5\u30DC\u30C8\u30EB\u3092\u3042\u3051\u3066\u3084\u308B\u3093\u3060\u304B\u3089",
  "id" : 444517347940782080,
  "created_at" : "2014-03-14 16:56:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444517240780505088",
  "text" : "\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u3092\u3084\u3063\u3064\u3051\u305F\u3089\u304A\u9152\u306E\u3093\u3067\u5BDD\u3066\u3084\u308B\u3093\u3060\u304B\u3089",
  "id" : 444517240780505088,
  "created_at" : "2014-03-14 16:55:43 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444516903164203009",
  "text" : "\u3086\u3086\u3057\u304D",
  "id" : 444516903164203009,
  "created_at" : "2014-03-14 16:54:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444513836695945216",
  "text" : "@jumpiko \u898B\u3064\u304B\u3089\u306A\u3044\u3082\u306E\u3092\u98F2\u3080\u306E\u306F\u81F3\u96E3\u306E\u6280",
  "id" : 444513836695945216,
  "created_at" : "2014-03-14 16:42:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444513653690097664",
  "text" : "\u3086\u3046\u3052\u3093\u306E\u306B\u3093\u3052\u3093\u3092\u306E\u305E\u3044\u3066\u306B\u3093\u3052\u3093\u304C\u3059\u304D",
  "id" : 444513653690097664,
  "created_at" : "2014-03-14 16:41:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444513549826535425",
  "text" : "\u307C\u304F\u306F\u306B\u3093\u3052\u3093\u304C\u3059\u304D\u3067\u3059\u3001\u3042\u306A\u305F\u306E\u3053\u3068\u304C\u3059\u304D\u3068\u306F\u304B\u304E\u308A\u307E\u305B\u3093",
  "id" : 444513549826535425,
  "created_at" : "2014-03-14 16:41:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444512723494133760",
  "text" : "hogehoge\u30DE\u30F3",
  "id" : 444512723494133760,
  "created_at" : "2014-03-14 16:37:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444512702812004352",
  "text" : "\u3075\u3068\u55B6\u696D\u30DE\u30F3\u3068\u3044\u3046\u6587\u5B57\u5217\u3067\u3058\u308F\u3063\u3068\u6765\u308B\u8EAB\u4F53\u306B\u306A\u3063\u3066\u3057\u307E\u3063\u305F",
  "id" : 444512702812004352,
  "created_at" : "2014-03-14 16:37:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444512450268782593",
  "text" : "\u5BDD\u6E9C\u3081\u306F\u51FA\u6765\u306A\u3044\u3051\u3069\u5BDD\u306A\u3044\u6E9C\u3081\u306F\u51FA\u6765\u308B\u306E\u69CB\u9020\u7684\u6B20\u9665",
  "id" : 444512450268782593,
  "created_at" : "2014-03-14 16:36:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444511859341660161",
  "text" : "\u3088\u304B\u3063\u305F",
  "id" : 444511859341660161,
  "created_at" : "2014-03-14 16:34:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444511708908761088",
  "geo" : { },
  "id_str" : "444511843633999872",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \u304A\u3081\u3067\u3068\u3046\u3054\u3056\u3044\u307E\u3059",
  "id" : 444511843633999872,
  "in_reply_to_status_id" : 444511708908761088,
  "created_at" : "2014-03-14 16:34:16 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444511772473434112",
  "text" : "5\u6642\u9593\u30013\u6642\u9593\u300117\u6642\u9593\u3068\u3044\u3046\u4E09\u65E5\u7D9A\u3051\u3066\u306E\u7761\u7720\u6642\u9593\u30C7\u30FC\u30BF\u304B\u3089\u5E73\u5747\u304C8\u6642\u9593\u304F\u3089\u3044\u306B\u306A\u308B\u3088\u3046\u306A\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2",
  "id" : 444511772473434112,
  "created_at" : "2014-03-14 16:33:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444511106329890816",
  "text" : "\u30A2\u30D5\u30BF\u30CC\u30FC\u30F32014\u5E74\u306B\u7A81\u5165\u3057\u3066\u308B",
  "id" : 444511106329890816,
  "created_at" : "2014-03-14 16:31:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444510989430423552",
  "text" : "\u306A\u304B\u3063\u305F\u3089\u3069\u3093\u306A\u9854\u3057\u3066\u3069\u3093\u306A\u98A8\u306B\u4F1D\u3048\u308B\u3079\u304D\u306A\u3093\u3060\u2026\u3042\u308B\u3060\u308D\u3046\u3051\u3069\u2026",
  "id" : 444510989430423552,
  "created_at" : "2014-03-14 16:30:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u304F\u3057\u3059",
      "screen_name" : "axis_ponpon",
      "indices" : [ 0, 12 ],
      "id_str" : "588420029",
      "id" : 588420029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444508880563736577",
  "geo" : { },
  "id_str" : "444510884728012800",
  "in_reply_to_user_id" : 588420029,
  "text" : "@axis_ponpon \u306F\u3044\u3053\u308F\u3044",
  "id" : 444510884728012800,
  "in_reply_to_status_id" : 444508880563736577,
  "created_at" : "2014-03-14 16:30:28 +0000",
  "in_reply_to_screen_name" : "axis_ponpon",
  "in_reply_to_user_id_str" : "588420029",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444496151991943168",
  "text" : "\u81EA\u708A\u4EBA\u9593",
  "id" : 444496151991943168,
  "created_at" : "2014-03-14 15:31:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3061\u3083\u307F\u3093",
      "screen_name" : "acmn13_2",
      "indices" : [ 0, 9 ],
      "id_str" : "803314422",
      "id" : 803314422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444416115620315136",
  "geo" : { },
  "id_str" : "444495353778163712",
  "in_reply_to_user_id" : 803314422,
  "text" : "@acmn13_2 \u3042\u308A\u304C\u3068\u3046\uFF01",
  "id" : 444495353778163712,
  "in_reply_to_status_id" : 444416115620315136,
  "created_at" : "2014-03-14 15:28:45 +0000",
  "in_reply_to_screen_name" : "acmn13_2",
  "in_reply_to_user_id_str" : "803314422",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444415515746779137",
  "text" : "\u3057\u3063\u304B\u308A\u5352\u696D\u8005\u30EA\u30B9\u30C8\u306B\u540D\u524D\u3042\u3063\u305F\u3057\u5927\u52DD\u5229",
  "id" : 444415515746779137,
  "created_at" : "2014-03-14 10:11:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444335777065885696",
  "text" : "\u306A\u3093\u304B\u305F\u3079\u306A\u3044\u3068\u3057\u306C",
  "id" : 444335777065885696,
  "created_at" : "2014-03-14 04:54:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444329127080767488",
  "text" : "\u5BDD\u3066\u8D77\u304D\u305F\u308917\u6642\u9593\u7D4C\u3063\u3066\u305F\u4EBA\u306E\u9854",
  "id" : 444329127080767488,
  "created_at" : "2014-03-14 04:28:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444080529835446272",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 444080529835446272,
  "created_at" : "2014-03-13 12:00:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444036696309370880",
  "text" : "\u8AB0\u304B\u3057\u3089\u4EBA\u6A29\u304C\u3042\u308B\u30BF\u30A4\u30DF\u30F3\u30B0\u304C\u3042\u308B\u306F\u305A",
  "id" : 444036696309370880,
  "created_at" : "2014-03-13 09:06:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7839",
      "screen_name" : "85Astatine",
      "indices" : [ 1, 12 ],
      "id_str" : "271032608",
      "id" : 271032608
    }, {
      "name" : "Knights",
      "screen_name" : "hatsusato",
      "indices" : [ 13, 23 ],
      "id_str" : "515476338",
      "id" : 515476338
    }, {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 24, 35 ],
      "id_str" : "122305557",
      "id" : 122305557
    }, {
      "name" : "\u8F9B\u5B50\u660E\u592A\u5B50@\u30A4\u30ABID: pastak",
      "screen_name" : "pastak",
      "indices" : [ 36, 43 ],
      "id_str" : "14283262",
      "id" : 14283262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444036627690561536",
  "text" : ".@85Astatine @hatsusato @nonamea774 @pastak \u4EE3\u8868\u306B\u7121\u4E8B\u5E30\u308C\u307E\u3057\u305F\u3001\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3001\u3068\u304A\u4F1D\u3048\u304F\u3060\u3055\u3044",
  "id" : 444036627690561536,
  "created_at" : "2014-03-13 09:05:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444035757410226176",
  "text" : "\u50D5\u306F\u7121\u4E8B\u306B\u5E30\u5B85\u3067\u304D\u307E\u3057\u305F\u3001\u3068\u3044\u3046\u554F\u984C",
  "id" : 444035757410226176,
  "created_at" : "2014-03-13 09:02:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444035497157877761",
  "text" : "\u9759\u304B\u306B\u7A4F\u3084\u304B\u306B\u3042\u304B\u3070\u308C",
  "id" : 444035497157877761,
  "created_at" : "2014-03-13 09:01:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOYA",
      "screen_name" : "k08a_",
      "indices" : [ 0, 6 ],
      "id_str" : "2245969236",
      "id" : 2245969236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444014703270834178",
  "geo" : { },
  "id_str" : "444035376483557377",
  "in_reply_to_user_id" : 2245969236,
  "text" : "@k08a_ \u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\uFF01",
  "id" : 444035376483557377,
  "in_reply_to_status_id" : 444014703270834178,
  "created_at" : "2014-03-13 09:00:58 +0000",
  "in_reply_to_screen_name" : "k08a_",
  "in_reply_to_user_id_str" : "2245969236",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444035216667971584",
  "text" : "\u978D\u99AC\u307E\u3067\u964D\u308A\u3066\u6765\u3066\u3001\u3060\u3044\u3076\u4E0B\u754C\u3068\u601D\u3063\u305F",
  "id" : 444035216667971584,
  "created_at" : "2014-03-13 09:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444033626426966016",
  "text" : "\u4FE1\u53F7\u3068\u304B\u30B3\u30F3\u30D3\u30CB\u3068\u304B\u4EBA\u6A29\u306E",
  "id" : 444033626426966016,
  "created_at" : "2014-03-13 08:54:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444033581027835904",
  "text" : "\u4E16\u754C\u306B\u5E30\u3063\u3066\u6765\u305F",
  "id" : 444033581027835904,
  "created_at" : "2014-03-13 08:53:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7vOYRNrmED",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/500?prefill=omo_ti",
      "display_url" : "gohantabeyo.com\/nani\/500?prefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443715572417585152",
  "text" : "\u6570\u5B66\u3057\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/7vOYRNrmED",
  "id" : 443715572417585152,
  "created_at" : "2014-03-12 11:50:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443557636483465217",
  "text" : "\u3042\u307E\u308A\u306B\u306F\u3084\u304F\u3064\u3044\u305F",
  "id" : 443557636483465217,
  "created_at" : "2014-03-12 01:22:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443536028645617664",
  "text" : "\u7D4C\u9A13\u4E0A\u305F\u3076\u3093\u3053\u308C\u306F90\u5206\u304F\u3089\u3044\u3067\u7740\u3044\u3061\u3083\u3063\u3066\u771F\u9854\u306E\u5974\u3060",
  "id" : 443536028645617664,
  "created_at" : "2014-03-11 23:56:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443532614163390464",
  "text" : "\u7121\u610F\u5473\u306B\u5148\u8F29\u3092\u9F13\u821E\u3057\u3066\u308B",
  "id" : 443532614163390464,
  "created_at" : "2014-03-11 23:43:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443532370348490752",
  "geo" : { },
  "id_str" : "443532529132261376",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u305D\u306E\u610F\u6C17\u3067\u3059\uFF01",
  "id" : 443532529132261376,
  "in_reply_to_status_id" : 443532370348490752,
  "created_at" : "2014-03-11 23:42:50 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443531809729417218",
  "geo" : { },
  "id_str" : "443531960892141568",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3067\u3082\u30DD\u30B1\u30E2\u30F3\u306E\u8A71\u306F\u3084\u3063\u3071\u308A\u3057\u3066\u306A\u3044\u306E\u3067\u5927\u4E08\u592B\u3067\u3059\u3002\u81EA\u4FE1\u3092\u6301\u3063\u3066\u304F\u3060\u3055\u3044",
  "id" : 443531960892141568,
  "in_reply_to_status_id" : 443531809729417218,
  "created_at" : "2014-03-11 23:40:34 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443531826947051520",
  "text" : "\u6B63\u3057\u3044",
  "id" : 443531826947051520,
  "created_at" : "2014-03-11 23:40:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443531685460578304",
  "geo" : { },
  "id_str" : "443531772756639744",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u305D\u308C\u306F\u201D\u3082\u306E\u3072\u308D\u3044\u201D\u3067\u306F",
  "id" : 443531772756639744,
  "in_reply_to_status_id" : 443531685460578304,
  "created_at" : "2014-03-11 23:39:49 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443531630234189824",
  "text" : "\u5996\u602A\u3082\u306E\u3082\u3089\u3044",
  "id" : 443531630234189824,
  "created_at" : "2014-03-11 23:39:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443524171704717312",
  "geo" : { },
  "id_str" : "443531591453650944",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u201C\u3082\u306E\u3054\u3044\u201D\u306E\u4E0A\u4F4D\u4E92\u63DB\u304C\u201D\u3082\u306E\u3082\u3089\u3044\u201D\u3067\u3059?",
  "id" : 443531591453650944,
  "in_reply_to_status_id" : 443524171704717312,
  "created_at" : "2014-03-11 23:39:06 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443522450903425024",
  "text" : "\u306C\u3046\u3063\u3068\u3081\u3056\u3081\u305F\u3088",
  "id" : 443522450903425024,
  "created_at" : "2014-03-11 23:02:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443370993948442624",
  "text" : "\u3042\u30FC\u21E1\u3042\u30FC\u2192\u3042\u30FC\u2192\u3042\u30FC\u2192\u3042\u30FC\u2193",
  "id" : 443370993948442624,
  "created_at" : "2014-03-11 13:00:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443356690675544064",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 443356690675544064,
  "created_at" : "2014-03-11 12:04:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443356154765119490",
  "text" : "\u697D\u3057\u3044\uFF0C\u3058\u3083\u3042\u306A\u3044\u3093\u3060\u3088",
  "id" : 443356154765119490,
  "created_at" : "2014-03-11 12:01:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443356093029167104",
  "text" : "\u697D\u3057\u3044\u9032\u6357\u30C0\u30E1\u3067\u3059",
  "id" : 443356093029167104,
  "created_at" : "2014-03-11 12:01:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443354613266149377",
  "text" : "\u5927\u4ECF\u3092\u5927\u52E2\u3067\u8E74\u3063\u3066\u58CA\u3059\u8A71\uFF0C\u5FB3\u304C\u4F4E\u3044\uFF0E",
  "id" : 443354613266149377,
  "created_at" : "2014-03-11 11:55:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443353294409179137",
  "text" : "Llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch",
  "id" : 443353294409179137,
  "created_at" : "2014-03-11 11:50:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443337692621725696",
  "text" : "\u30AD\u30C3\u30C1\u30F3\u30B4\u30EA\u30E9\u306E\u30DD\u30FC\u30AF\u30CF\u30F3\u30D0\u30FC\u30B0\u3001\u9650\u308A\u306A\u304F\u30CF\u30E0\u306B\u8FD1\u3044",
  "id" : 443337692621725696,
  "created_at" : "2014-03-11 10:48:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443142892001837056",
  "text" : "\u304A\u3084\u3059\u307F\u305B\u304B\u3044",
  "id" : 443142892001837056,
  "created_at" : "2014-03-10 21:54:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443131020431216641",
  "text" : "\u306E\u306E\u306E\u306E\u306E\u306E\u306E\u30FC\u30FC\u30FC",
  "id" : 443131020431216641,
  "created_at" : "2014-03-10 21:07:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443096829723283456",
  "text" : "\u76EE\u304C\u3057\u3087\u307C\u304F\u306A\u3063\u3066\u304D\u305F",
  "id" : 443096829723283456,
  "created_at" : "2014-03-10 18:51:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443096718251274240",
  "text" : "\u3053\u3093\u306A\u306B\u9032\u6357\u30A2\u30EC\u306A\u306E\u306B\u5E78\u305B\u3068\u304B\u8A00\u3063\u3066\u308B\u306E\u982D\u304A\u304B\u3057\u3044\u304B\uFF0C\u3068\u3066\u3082\u982D\u304C\u304A\u304B\u3057\u3044\u304B\uFF0C\u305D\u306E\u3069\u3061\u3089\u3067\u3082\u306A\u3044\u306E\u3069\u308C\u304B\u3060",
  "id" : 443096718251274240,
  "created_at" : "2014-03-10 18:51:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443096493386252289",
  "text" : "\u3053\u306E\u6642\u9593\u306F\u672C\u5F53\u306B\u5E78\u305B\u3060",
  "id" : 443096493386252289,
  "created_at" : "2014-03-10 18:50:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443095433871507456",
  "text" : "\u308D\u304F\u3067\u3082\u306A\u3044\u30C4\u30A4\u30FC\u30E8\u751F\u6210\u306B\u5B9A\u8A55\u306E\u3042\u308B",
  "id" : 443095433871507456,
  "created_at" : "2014-03-10 18:45:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443094724706983936",
  "text" : "\u3053\u306E\u6642\u9593\u306F\u4F55\u3067\u3082\u9762\u767D\u3044\u304B\u3089\u3068\u3066\u3082\u5E78\u305B\u306A\u6642\u9593\u3060",
  "id" : 443094724706983936,
  "created_at" : "2014-03-10 18:43:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443094668587180032",
  "text" : "\u304A\u524D\u3082\uFF01\uFF01\uFF01\uFF01\u30D5\u30A1\u30DF\u30EA\u30FC\u30DE\u30FC\u30C8\u306B\u3057\u3066\u3084\u308D\u3046\u304B\uFF01\uFF01\uFF01\uFF01",
  "id" : 443094668587180032,
  "created_at" : "2014-03-10 18:42:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443094474697084928",
  "text" : "\u8150\u3063\u3066\u3082\u9BDB\u3063\u3066\u8A00\u3046\u3051\u3069\u3069\u3046\u8003\u3048\u3066\u3082\u8150\u3063\u305F\u3089\u751F\u30B4\u30DF\u3060",
  "id" : 443094474697084928,
  "created_at" : "2014-03-10 18:42:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443089102024368128",
  "text" : "\u305F\u3060\u3067\u3055\u3048\u8A9E\u5F59\u304C\u30A2\u30EC\u306A\u306E\u306B\u6642\u9593\u304C\u30A2\u30EC\u3060\u304B\u3089\u30A2\u30EC\u304C\u30E4\u30D0\u30A4",
  "id" : 443089102024368128,
  "created_at" : "2014-03-10 18:20:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443041150283161602",
  "text" : "\u3042\u3063\u3071\u3044\u306E\uFF71\uFF6F\uFF8A\uFF72\u611F",
  "id" : 443041150283161602,
  "created_at" : "2014-03-10 15:10:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443041107039883266",
  "text" : "\u5727\u52DD\uFF0C\u5727\u6557",
  "id" : 443041107039883266,
  "created_at" : "2014-03-10 15:10:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443040054693212163",
  "text" : "\u697D\u3057\u3044\u571F\u4E0B\u5EA7\uFF0C\u3068\u304B\u3044\u3046\u6559\u79D1\u66F8\u304C\u3042\u3063\u305F\u3089\u571F\u4E0B\u5EA7\u3057\u306A\u304F\u3066\u3044\u3044\u3088\u3046\u306B\u9811\u5F35\u308B\u6C17\u304C\u3059\u308B\u3093\u3060",
  "id" : 443040054693212163,
  "created_at" : "2014-03-10 15:05:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443038214010322944",
  "text" : "230\u5186\u7389\u306F4\u6708\u4EE5\u964D\u5049\u5927",
  "id" : 443038214010322944,
  "created_at" : "2014-03-10 14:58:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443038151347412993",
  "text" : "3000\u5186\u672D\u3068220\u5186\u7389\u306F\u5049\u5927",
  "id" : 443038151347412993,
  "created_at" : "2014-03-10 14:58:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443029885569613824",
  "text" : "mojibake",
  "id" : 443029885569613824,
  "created_at" : "2014-03-10 14:25:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "410natsuki529",
      "screen_name" : "tatyusa419",
      "indices" : [ 0, 11 ],
      "id_str" : "2531832002",
      "id" : 2531832002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443005338178949123",
  "text" : "@tatyusa419 (\u76F8\u99AC\u3055\u3093\u304C\u96E3\u3057\u305D\u3046\u3067\u624B\u304C\u51FA\u305B\u306A\u3044\u306E\u306B\u50D5\u304C\u51FA\u305B\u308B\u6C17\u304C\u4E00\u5207\u3057\u306A\u3044\u306E\u3067\u3059\u304C)\u30AA\u30E9\u30A4\u30EA\u30FC\u306EHaskell and Yesod\u304C\u6C17\u306B\u306A\u3063\u3066\u3044\u308B",
  "id" : 443005338178949123,
  "created_at" : "2014-03-10 12:47:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "410natsuki529",
      "screen_name" : "tatyusa419",
      "indices" : [ 0, 11 ],
      "id_str" : "2531832002",
      "id" : 2531832002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443001382400847873",
  "text" : "@tatyusa419 \u50D5\u306F\u3068\u308A\u3042\u3048\u305A\u306FCUI\u3067\u3082\u826F\u3044\u3068\u601D\u3044\u307E\u3059\u3067\u3059\uFF0E[Yesod\u3068\u304B\u5B66\u3093\u3067\u307F\u3088\u3046\u304B\u3068\u601D\u3044\u59CB\u3081\u3066\u308B\u3051\u3069][\u4ECAHaskell\u3067Bot\u4F5C\u308D\u3046\u3068\u3057\u3066\u308B\u3051\u3069\u8A8D\u8A3C\u3068\u304B\u306E\u3042\u305F\u308A\u3067\u8272\u3005\u8A70\u307E\u3063\u3066\u308B]",
  "id" : 443001382400847873,
  "created_at" : "2014-03-10 12:32:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443001041806581760",
  "text" : "\u5996\u602A\u30D6\u30E9\u30A6\u30B6\u843D\u3068\u3057",
  "id" : 443001041806581760,
  "created_at" : "2014-03-10 12:30:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "410natsuki529",
      "screen_name" : "tatyusa419",
      "indices" : [ 0, 11 ],
      "id_str" : "2531832002",
      "id" : 2531832002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442991506215809024",
  "text" : "@tatyusa419 \u3048\uFF1F\u306A\u3093\u306E\u306F\u306A\u3057\uFF1F",
  "id" : 442991506215809024,
  "created_at" : "2014-03-10 11:53:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442967126081433600",
  "text" : "\u306A\u3093\u304B\u3082\u3046\u30A2\u30A4\u30A8\u30A8\u30A8",
  "id" : 442967126081433600,
  "created_at" : "2014-03-10 10:16:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442967084008345600",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8 \u30A2\u30A4\u30A8\u30A8\u30A8\u30A8\u30A8 \u30A2\u30A4\u30A8\u30A8\u30A8",
  "id" : 442967084008345600,
  "created_at" : "2014-03-10 10:15:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442955435348213760",
  "text" : "\u3066\u304B\uFF0CIRC\u3084\u3063\u3066\u308B\uFF1F\u7B11",
  "id" : 442955435348213760,
  "created_at" : "2014-03-10 09:29:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442630664664256513",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 442630664664256513,
  "created_at" : "2014-03-09 11:59:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442552631106342913",
  "text" : "\u81EA\u708A(\u81EA\u708A\u3068\u306F\u8A00\u3063\u3066\u3044\u306A\u3044)",
  "id" : 442552631106342913,
  "created_at" : "2014-03-09 06:49:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442369263416786944",
  "text" : "\u601D\u3063\u3066\u3044\u305F\u3088\u308A\u3060\u3044\u3076\u6357\u3063\u3066\u306A\u304F\u3066\u6B7B\u306B\u305F\u3044",
  "id" : 442369263416786944,
  "created_at" : "2014-03-08 18:40:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442368377630097410",
  "text" : "\u3046\u30FC\u3093\uFF0C\u3055\u3063\u3071\u308A\u3046\u307E\u304F\u884C\u304B\u306A\u3044\uFF0E",
  "id" : 442368377630097410,
  "created_at" : "2014-03-08 18:36:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442309186399903744",
  "text" : "\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u3042\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u3063\u3066\u601D\u3046",
  "id" : 442309186399903744,
  "created_at" : "2014-03-08 14:41:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442301429990948864",
  "text" : "\u3068\u308A\u3042\u3048\u305A\u3044\u308D\u3044\u308D\u8AE6\u3081\u5B9F\u9A13\u3092\u59CB\u3081\u3066\u308B",
  "id" : 442301429990948864,
  "created_at" : "2014-03-08 14:10:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442268305726783488",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 442268305726783488,
  "created_at" : "2014-03-08 11:59:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u77E5\u6075\u888B_",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/8I7azU5R8i",
      "expanded_url" : "http:\/\/detail.chiebukuro.yahoo.co.jp\/qa\/question_detail\/q13122145028?fr=pc_tw_share_q",
      "display_url" : "detail.chiebukuro.yahoo.co.jp\/qa\/question_de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442266221539368960",
  "text" : "Twitter\u306EAPI\u3092\u5229\u7528\u3057\u3088\u3046\u3068\u3057\u3066\u3001\u672C\u5BB6\u306E\u30B5\u30A4\u30C8\u3067\u767B\u9332\u3092\u884C\u304A\u3046\u3068\u3057\u305F\u3068\u3053\u308D\u3001Youmu... http:\/\/t.co\/8I7azU5R8i \u5168\u304F\u540C\u3058\u75C7\u72B6\u3060\u30A2\u30A4\u30A8\u30A8\u30A8 #\u77E5\u6075\u888B_",
  "id" : 442266221539368960,
  "created_at" : "2014-03-08 11:50:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442242357165969408",
  "text" : "\u3053\u306E\u6642\u9593\u306B\u8AB0\u3082\u3044\u306A\u3044\u3068\u306F\u601D\u308F\u306A\u304B\u3063\u305F\u306E",
  "id" : 442242357165969408,
  "created_at" : "2014-03-08 10:16:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u8D77\u304D\u305F\u308917\u6642\u306E\u7D76\u671B",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442211820992884736",
  "text" : "#\u8D77\u304D\u305F\u308917\u6642\u306E\u7D76\u671B",
  "id" : 442211820992884736,
  "created_at" : "2014-03-08 08:14:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gohantabeyo.com\" rel=\"nofollow\"\u003Egohantabeyo.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/dUefmiGxms",
      "expanded_url" : "http:\/\/gohantabeyo.com\/nani\/2815?prefill=masayotominaga",
      "display_url" : "gohantabeyo.com\/nani\/2815?pref\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441884943468093440",
  "text" : "\u3046\u307E\u3044\u9152\u3092\u306E\u307F\u305F\u3044\u540C\u58EB\u3092\u767A\u898B\u3057\u307E\u3059\u3002 http:\/\/t.co\/dUefmiGxms",
  "id" : 441884943468093440,
  "created_at" : "2014-03-07 10:35:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441858566635282432",
  "geo" : { },
  "id_str" : "441859668416032768",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u306F\u3044",
  "id" : 441859668416032768,
  "in_reply_to_status_id" : 441858566635282432,
  "created_at" : "2014-03-07 08:55:28 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441829290003283968",
  "text" : "\u89AA\u306B\u96FB\u8A71\u3057\u305F\u3089\u5168\u304F\u5510\u7A81\u306B\u300C\u96EA\u3060\u3088\u300D\u3063\u3066\u8A00\u308F\u308C\u3066\u5510\u7A81\u3060\u306A\u3041\u3063\u3066\u611F\u3058\u305F",
  "id" : 441829290003283968,
  "created_at" : "2014-03-07 06:54:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441824515228573696",
  "text" : "\u6708\u66DC\u65E5\u3001\u90F5\u4FBF\u5C40\u3067\u6255\u8FBC&amp;\u5352\u696D\u5F0F\u30D1\u30B9\u624B\u7D9A\u304D",
  "id" : 441824515228573696,
  "created_at" : "2014-03-07 06:35:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441543884129050624",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 441543884129050624,
  "created_at" : "2014-03-06 12:00:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 0, 9 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441517269441474561",
  "geo" : { },
  "id_str" : "441530795660808192",
  "in_reply_to_user_id" : 1223342047,
  "text" : "@kur_rage \u3088\u308D\u3057\u304F\u30FC\u304A\u9858\u3044\u3057\u307E\u3059",
  "id" : 441530795660808192,
  "in_reply_to_status_id" : 441517269441474561,
  "created_at" : "2014-03-06 11:08:39 +0000",
  "in_reply_to_screen_name" : "kur_rage",
  "in_reply_to_user_id_str" : "1223342047",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441513641481744384",
  "text" : "\u6700\u9AD8\u3068\u8A00\u308F\u308C\u305F\u53BB\u5E74\u3092\u4E0A\u56DE\u308B\u3042\u3046\u3042\u3046\u3042\u30FC",
  "id" : 441513641481744384,
  "created_at" : "2014-03-06 10:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CompactHausdorff\u5C71\u7530",
      "screen_name" : "NoriMathTp",
      "indices" : [ 0, 11 ],
      "id_str" : "231358679",
      "id" : 231358679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441513372287127552",
  "geo" : { },
  "id_str" : "441513467304894465",
  "in_reply_to_user_id" : 231358679,
  "text" : "@NoriMathTp \u308F\u304B\u308B",
  "id" : 441513467304894465,
  "in_reply_to_status_id" : 441513372287127552,
  "created_at" : "2014-03-06 09:59:48 +0000",
  "in_reply_to_screen_name" : "NoriMathTp",
  "in_reply_to_user_id_str" : "231358679",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441513289168613376",
  "text" : "\u4EBA\u306B\u9053\u3092\u805E\u304F\u6642\u304F\u3089\u3044\u30DE\u30B9\u30AF\u3068\u308C\u3088\u304A\u3070\u3055\u3093",
  "id" : 441513289168613376,
  "created_at" : "2014-03-06 09:59:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441513145891164160",
  "text" : "\u3086\u3044\u304B\u304A\u308A\u306E\u4EBA\u306B\u9053\u3092\u805E\u304B\u308C\u308B\u65B9\u306E\u3048\u3093\u3069\u3067\u3059",
  "id" : 441513145891164160,
  "created_at" : "2014-03-06 09:58:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441512878147764224",
  "text" : "\u5727",
  "id" : 441512878147764224,
  "created_at" : "2014-03-06 09:57:27 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441512800297291776",
  "text" : "\u5F85\u3061\u5408\u308F\u305B\u306E5\u5206\u524D\u306B\u306A\u3063\u3066\u3082\u73FE\u308C\u306A\u3044\u5974\u306F\u4F55\u3092\u3084\u3063\u3066\u3082\u30C0\u30E1",
  "id" : 441512800297291776,
  "created_at" : "2014-03-06 09:57:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441512017606610944",
  "text" : "\u4ECA\u5E74\u4E00\u756A\u306E\u771F\u9854",
  "id" : 441512017606610944,
  "created_at" : "2014-03-06 09:54:02 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441511949788921856",
  "text" : "iPhone\u4F7F\u3063\u306618\u30F6\u6708\u3001\u3064\u3044\u306B\u843D\u3068\u3057\u3066\u80CC\u9762\u306B\u30D2\u30D3\u304C\u2026",
  "id" : 441511949788921856,
  "created_at" : "2014-03-06 09:53:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441509518673862656",
  "text" : "\u5168\u56FD\u9053\u8DEF\u5730\u56F3\u304C\u6848\u5916\u9AD8\u304F\u3066\u771F\u9854of the world",
  "id" : 441509518673862656,
  "created_at" : "2014-03-06 09:44:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 0, 9 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441167675167739904",
  "geo" : { },
  "id_str" : "441503988920229889",
  "in_reply_to_user_id" : 1223342047,
  "text" : "@kur_rage \u539F\u4ED8\u3092\u505C\u3081\u3066\u7F6E\u3044\u305F\u306E\u3067\u5F15\u3063\u639B\u3051\u3066\u7F6E\u3044\u3066\u3044\u305F\u3060\u3051\u307E\u3059\u304B(\u304A\u305D\u3089\u304F\u660E\u65E5\u56DE\u53CE)",
  "id" : 441503988920229889,
  "in_reply_to_status_id" : 441167675167739904,
  "created_at" : "2014-03-06 09:22:08 +0000",
  "in_reply_to_screen_name" : "kur_rage",
  "in_reply_to_user_id_str" : "1223342047",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 0, 9 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441167675167739904",
  "geo" : { },
  "id_str" : "441502778527977473",
  "in_reply_to_user_id" : 1223342047,
  "text" : "@kur_rage \u73FE\u5730\u3067\u3059\u304C\u898B\u5F53\u305F\u308A\u307E\u305B\u3093(\u771F\u9854)",
  "id" : 441502778527977473,
  "in_reply_to_status_id" : 441167675167739904,
  "created_at" : "2014-03-06 09:17:19 +0000",
  "in_reply_to_screen_name" : "kur_rage",
  "in_reply_to_user_id_str" : "1223342047",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441495431726383104",
  "text" : "4\u30F6\u6708\u304F\u3089\u3044\u3067\u6765\u3066\u306D\u3068\u8A00\u308F\u308C\u305F\u539F\u4ED8\u306E\u30E1\u30F3\u30C6\u30CA\u30F3\u30B9\u306B24\u30F6\u6708\u5F8C\u306B\u6765\u305F\u30A2\u30AB\u30A6\u30F3\u30C8\u304C\u3053\u3061\u3089",
  "id" : 441495431726383104,
  "created_at" : "2014-03-06 08:48:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u30FC\u304F\u306F4\u30E9\u30C8\u304C\u3057\u305F\u3044(200+)",
      "screen_name" : "ark184",
      "indices" : [ 0, 7 ],
      "id_str" : "812716507",
      "id" : 812716507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441473830075105280",
  "geo" : { },
  "id_str" : "441474643317104640",
  "in_reply_to_user_id" : 812716507,
  "text" : "@ark184 \u3061\u3083\u3093\u3068\u3057\u305F\u60C5\u5831\u304C\u3042\u3063\u305F\u3089\u5BFE\u7B56\u3057\u3066\u308B\u3093\u3067\u3059\u3088\u306D(\uFF1F)",
  "id" : 441474643317104640,
  "in_reply_to_status_id" : 441473830075105280,
  "created_at" : "2014-03-06 07:25:31 +0000",
  "in_reply_to_screen_name" : "ark184",
  "in_reply_to_user_id_str" : "812716507",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441473227030663168",
  "text" : "\u3046\u30FC\u3093\uFF0C2\u65E5\u306B\u53CA\u3076\u65AD\u7D9A\u7684\u306A\u8179\u75DB\u30A7\u2026\u591A\u5206\u304D\u3063\u3068\u80C3\u306E\u3042\u305F\u308A\u306E\u4F55\u304B\u304C\u3044\u307E\u3044\u3061",
  "id" : 441473227030663168,
  "created_at" : "2014-03-06 07:19:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441471791911825408",
  "text" : "\u3053\u306E\u3078\u3093\u304B\u3089\u8003\u3048\u308B\u3068\u884C\u3051\u3066\u3082\u826F\u3055\u305D\u3046\u3060\u3051\u308C\u3069\u540C\u3058\u624B\u9806\u8E0F\u3093\u3067\u3082\u30C0\u30E1\u3067\u306C\u30FC\u3093\u3068\u8A00\u3046\u611F\u3058\u3059\u308B",
  "id" : 441471791911825408,
  "created_at" : "2014-03-06 07:14:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u77E5\u6075\u888B_",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 1, 23 ],
      "url" : "http:\/\/t.co\/YaPQdkD6h2",
      "expanded_url" : "http:\/\/MAKEBOTdev.twitter.com",
      "display_url" : "MAKEBOTdev.twitter.com"
    }, {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/NlUWmxi0Dz",
      "expanded_url" : "http:\/\/detail.chiebukuro.yahoo.co.jp\/qa\/question_detail\/q12120384192?fr=pc_tw_share_q",
      "display_url" : "detail.chiebukuro.yahoo.co.jp\/qa\/question_de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441471652824498177",
  "text" : "\u3010http:\/\/t.co\/YaPQdkD6h2\u3067\u306E\u3064\u3076\u3084\u304D\u5143\u306E\u8A2D\u5B9A\u306B\u3064\u3044\u3066\u3011\u95B2\u89A7\u3044\u305F\u3060\u304D\u3042\u308A\u304C\u3068\u3046... http:\/\/t.co\/NlUWmxi0Dz #\u77E5\u6075\u888B_",
  "id" : 441471652824498177,
  "created_at" : "2014-03-06 07:13:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441469684940935168",
  "text" : "IRC\u306B\u306F\u3075\u3041\u307C\u306E\u6A5F\u80FD\u304C\u6B20\u5982\u3057\u3066\u3044\u308B",
  "id" : 441469684940935168,
  "created_at" : "2014-03-06 07:05:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441468045014208512",
  "text" : "\u307E\u305FTwitterdeveloper\u3067\u30A2\u30D7\u30EA\u30B1\u30FC\u30B7\u30E7\u30F3\u767B\u9332\u3067\u304D\u306A\u3044\u3084\u3064\u3060\u2026\u643A\u5E2F\u7D10\u4ED8\u3051\u3057\u3066\u308B\u306E\u306B\u306A\u3041\u2026",
  "id" : 441468045014208512,
  "created_at" : "2014-03-06 06:59:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441453223899983872",
  "text" : "\u30BD\u30FC\u30C0\u304C\u3042\u308C\u3070",
  "id" : 441453223899983872,
  "created_at" : "2014-03-06 06:00:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441453202852954112",
  "text" : "\u30E1\u30ED\u30F3\u30B7\u30ED\u30C3\u30D7\u5C4A\u3044\u305F\u3057\u3053\u308C\u3067\u304A\u3046\u3061\u3067\u3082\u30E1\u30ED\u30F3\u30BD\u30FC\u30C0\u304C\u98F2\u3081\u308B\uFF0E",
  "id" : 441453202852954112,
  "created_at" : "2014-03-06 06:00:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441290760927727616",
  "text" : "\u65E5\u66DC\u5348\u5F8C\uFF0EBookoff\u6765\u308B\uFF0E\u3081\u3082\u3081\u3082\uFF0E",
  "id" : 441290760927727616,
  "created_at" : "2014-03-05 19:14:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441284957076332545",
  "text" : "1\u518A\u5927\u304D\u3081\u306B\u898B\u30661\u6642\u9593\uFF0E\u307E\u308B\u4E00\u65E5\u304B\u304B\u308B\uFF0E\u305F\u3060\u30B9\u30AD\u30E3\u30F3\u4E2D\u306B\u4ED6\u306E\u3053\u3068\u3067\u304D\u308B\u304B\u3089\u4F55\u3068\u304B\u306A\u308B\u304B\uFF0E",
  "id" : 441284957076332545,
  "created_at" : "2014-03-05 18:51:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441284817426972672",
  "text" : "\u306A\u304A\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\uFF0C\u4ECA2012\u5E74\u306E3\u6708\u5206\uFF0C\u3061\u3087\u3046\u3069\u5F8C24\u518A\u3042\u308B\uFF0E\u771F\u9854\uFF0E",
  "id" : 441284817426972672,
  "created_at" : "2014-03-05 18:51:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441280457800314880",
  "text" : "\u30A2\u30D5\u30BF\u30CC\u30FC\u30F3\u306E\u81EA\u708A\u3068\u5F15\u8D8A\u3057\u4F5C\u696D\u3068\u5FB3\u3092\u7A4D\u3080\u4F5C\u696D\u3092\u4E26\u884C\u3057\u3066\u308B",
  "id" : 441280457800314880,
  "created_at" : "2014-03-05 18:33:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441280310420860929",
  "text" : "\u201D\u3086\u3086\u5F0F\u3068\u4F5C\u696D\u201D\u306E\u89AA\u548C\u6027\uFF0C\u3044\u3084\uFF0C\u4F5C\u696D\u3068\u201D\u3086\u3086\u5F0F\u306E\u795E\u8A71\u6027\u201D",
  "id" : 441280310420860929,
  "created_at" : "2014-03-05 18:33:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441280001053171712",
  "text" : "\u9AD83\u306E\u6642\u306E\u6A21\u8A66\u306E\u7D50\u679C\u3068\u304B\u3067\u3066\u304D\u305F\uFF0E\u6368\u3066\uFF0E",
  "id" : 441280001053171712,
  "created_at" : "2014-03-05 18:32:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441279911970353152",
  "text" : "\u3064\u304F\u3065\u304F\u3082\u306E\u3092\u8CAF\u3081\u3053\u3080\u6027\u683C\u3060\u306A\u3041",
  "id" : 441279911970353152,
  "created_at" : "2014-03-05 18:31:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441264334803460096",
  "text" : "\u30A6\u30A3\u30EB\u30AD\u30F3\u30BD\u30F3\u70AD\u9178",
  "id" : 441264334803460096,
  "created_at" : "2014-03-05 17:29:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441216949733703680",
  "text" : "\u4E80\u30EC\u30B9\u3068\u79CB",
  "id" : 441216949733703680,
  "created_at" : "2014-03-05 14:21:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441216913079676928",
  "text" : "@desole_mi \u6B32\u3057\u3044\u3067\u3059\uFF01",
  "id" : 441216913079676928,
  "created_at" : "2014-03-05 14:21:24 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441169696977457152",
  "text" : "\u6301\u3063\u3066\u308B",
  "id" : 441169696977457152,
  "created_at" : "2014-03-05 11:13:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441169674672144384",
  "text" : "\u3086\u30D0\u30C3\u30B8\u3068\u308A\u30D0\u30C3\u30B8\u3068\u3078\u30D0\u30C3\u30B8\u306F\u76DB\u3063\u3066\u308B",
  "id" : 441169674672144384,
  "created_at" : "2014-03-05 11:13:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mcfadden Guy",
      "screen_name" : "desole_mi",
      "indices" : [ 0, 10 ],
      "id_str" : "3000950780",
      "id" : 3000950780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441169587170578432",
  "text" : "@desole_mi \u660E\u5F8C\u65E5\u5B66\u90E8\u306B\u624B\u7D9A\u304D\u306B\u884C\u304D\u307E\u3059\u3088\uFF1F",
  "id" : 441169587170578432,
  "created_at" : "2014-03-05 11:13:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441168902890864640",
  "text" : "Oauth\u3068API\u306B\u3064\u3044\u3066\u3044\u3044\u611F\u3058\u306B\u307E\u3068\u307E\u3063\u3066\u308B\u30DA\u30FC\u30B8\u63A2\u3059\u3067\u3059\uFF0C",
  "id" : 441168902890864640,
  "created_at" : "2014-03-05 11:10:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441167930844143616",
  "text" : "\u30DE\u30D5\u30E9\u30FC\u56DE\u53CE\u3057\u3064\u3064\u304F\u3063\u3061\u3093\u3071\u81EA\u8EE2\u8ECA\u306B\u3086\u30D0\u30C3\u30B8\u3092\u88C5\u5099\u3059\u308B\u3044\u305F\u305A\u3089\u3092\u601D\u3044\u3064\u3044\u305F",
  "id" : 441167930844143616,
  "created_at" : "2014-03-05 11:06:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 0, 9 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441166828312604672",
  "geo" : { },
  "id_str" : "441166997192069120",
  "in_reply_to_user_id" : 1223342047,
  "text" : "@kur_rage \u304F\u3063\u3061\u3093\u3071\u3058\u3066\u3093\u3057\u3083\u304C\u3044\u3061\u3044\u306B\u5B9A\u307E\u3089\u306A\u305D\u3046\u3067\u3059\u304C\u3001\u660E\u65E5\u96E8\u3058\u3083\u306A\u3051\u308C\u3070\u305D\u3046\u3057\u3066\u304F\u3060\u3055\u3044",
  "id" : 441166997192069120,
  "in_reply_to_status_id" : 441166828312604672,
  "created_at" : "2014-03-05 11:03:03 +0000",
  "in_reply_to_screen_name" : "kur_rage",
  "in_reply_to_user_id_str" : "1223342047",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u308B\u307F\u306A\u3061\u3083\u3093",
      "screen_name" : "rumichang",
      "indices" : [ 0, 10 ],
      "id_str" : "242763253",
      "id" : 242763253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441166651237482496",
  "geo" : { },
  "id_str" : "441166785216143360",
  "in_reply_to_user_id" : 242763253,
  "text" : "@rumichang \u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 441166785216143360,
  "in_reply_to_status_id" : 441166651237482496,
  "created_at" : "2014-03-05 11:02:12 +0000",
  "in_reply_to_screen_name" : "rumichang",
  "in_reply_to_user_id_str" : "242763253",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 0, 9 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441166018195374080",
  "geo" : { },
  "id_str" : "441166216380440576",
  "in_reply_to_user_id" : 1223342047,
  "text" : "@kur_rage \u3054\u3081\u3093\u306A\u3055\u3044\u3001\u4ECA\u304B\u3089\u306F\u3061\u3087\u3063\u3068\u2026\u660E\u65E5\u306E\u5348\u5F8C\u3001\u5915\u65B9\u3088\u308A\u65E9\u3051\u308C\u3070\u3044\u3064\u3067\u3082\u3069\u3053\u3067\u3082\u5927\u4E08\u592B\u3067\u3059",
  "id" : 441166216380440576,
  "in_reply_to_status_id" : 441166018195374080,
  "created_at" : "2014-03-05 10:59:57 +0000",
  "in_reply_to_screen_name" : "kur_rage",
  "in_reply_to_user_id_str" : "1223342047",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 0, 9 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441165020471107584",
  "geo" : { },
  "id_str" : "441165335375265793",
  "in_reply_to_user_id" : 1223342047,
  "text" : "@kur_rage \u3048\u30FC\u3068\u3044\u3064\u3069\u3053\u306B\u53D6\u308A\u306B\u884C\u3063\u305F\u3089\u826F\u3044\u3067\u3059\u304B",
  "id" : 441165335375265793,
  "in_reply_to_status_id" : 441165020471107584,
  "created_at" : "2014-03-05 10:56:27 +0000",
  "in_reply_to_screen_name" : "kur_rage",
  "in_reply_to_user_id_str" : "1223342047",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3089\u3052",
      "screen_name" : "kur_rage",
      "indices" : [ 0, 9 ],
      "id_str" : "1223342047",
      "id" : 1223342047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441165020471107584",
  "geo" : { },
  "id_str" : "441165067715743744",
  "in_reply_to_user_id" : 1223342047,
  "text" : "@kur_rage \u306A\u308B\u307B\u3069\uFF1F",
  "id" : 441165067715743744,
  "in_reply_to_status_id" : 441165020471107584,
  "created_at" : "2014-03-05 10:55:23 +0000",
  "in_reply_to_screen_name" : "kur_rage",
  "in_reply_to_user_id_str" : "1223342047",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441164237491023872",
  "geo" : { },
  "id_str" : "441164279446638592",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u306F\u3044",
  "id" : 441164279446638592,
  "in_reply_to_status_id" : 441164237491023872,
  "created_at" : "2014-03-05 10:52:15 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441163876629897217",
  "geo" : { },
  "id_str" : "441163985690185728",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u3082\u3063\u3068\u65E9\u304F\u884C\u3063\u3066\u304F\u308C\u305F\u3089\u6298\u534A\u3057\u3066\u305F\u306E\u306B",
  "id" : 441163985690185728,
  "in_reply_to_status_id" : 441163876629897217,
  "created_at" : "2014-03-05 10:51:05 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441160880831488000",
  "text" : "\u3042\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\u30FC\uFF01\uFF01\u3063\u3066\u611F\u3058",
  "id" : 441160880831488000,
  "created_at" : "2014-03-05 10:38:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441160738791378944",
  "text" : "\u3044\u3084\uFF0C\u5E38\u5099\u306F\u3057\u3066\u306A\u3044\u3051\u308C\u3069",
  "id" : 441160738791378944,
  "created_at" : "2014-03-05 10:38:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441160691701927936",
  "text" : "\u666E\u901A\u306B\u7BB1\u8CB7\u3044\u5B89\u5B9A\u3067\u3059\u306D\uFF0E\u30C9\u30AF\u30DA\uFF0E",
  "id" : 441160691701927936,
  "created_at" : "2014-03-05 10:37:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441160470443999232",
  "text" : "\u30C9\u30AF\u30DA\u306F\u308F\u304B\u308B\uFF0C\u3059\u3054\u304F\u3088\u304F\u308F\u304B\u308B\uFF0E\u305F\u3060\u3057\u30EB\u30FC\u30C8\u30D3\u30A2\uFF0C\u3066\u3081\u30FC\u306F\u30C0\u30E1\u3060",
  "id" : 441160470443999232,
  "created_at" : "2014-03-05 10:37:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441159988711407616",
  "text" : "\u3069\u3046\u305E\u6B63\u5F53\u306A\u8A55\u4FA1\u3092",
  "id" : 441159988711407616,
  "created_at" : "2014-03-05 10:35:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441158892236443648",
  "text" : "\u3068\u3044\u3046\u304B\u9DB4\u3092\u6570\u7FBD\u6298\u3063\u305F\u4EE5\u5916\u7279\u306B\u4F55\u3082\u3057\u3066\u306A\u3044\u306E\u3067\u306F",
  "id" : 441158892236443648,
  "created_at" : "2014-03-05 10:30:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441158696584749056",
  "geo" : { },
  "id_str" : "441158799357784064",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u4E00\u756A\u304A\u3068\u306A\u3057\u304F\u3057\u3066\u305F\u81EA\u4FE1\u3042\u308B",
  "id" : 441158799357784064,
  "in_reply_to_status_id" : 441158696584749056,
  "created_at" : "2014-03-05 10:30:28 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441158124016107520",
  "geo" : { },
  "id_str" : "441158259592790016",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u8FD1\u3044\u6240\u3067\u305D\u3053\u304B\u2026\u30A2\u30AF\u30BB\u30B7\u30D3\u30EA\u30C6\u30A3\u306E\u4F4E\u3055\u3088\u2026",
  "id" : 441158259592790016,
  "in_reply_to_status_id" : 441158124016107520,
  "created_at" : "2014-03-05 10:28:20 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441157830922358784",
  "geo" : { },
  "id_str" : "441157982621945856",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3044\u3084\uFF0C\u666E\u901A\u306B\u542B\u307E\u306A\u3044\u3060\u308D(",
  "id" : 441157982621945856,
  "in_reply_to_status_id" : 441157830922358784,
  "created_at" : "2014-03-05 10:27:14 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441157743311732736",
  "geo" : { },
  "id_str" : "441157806561849344",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u8FD1\u5834\u3067\u30B5\u30B8\u30A7\u30B9\u30C8\u3057\u3066\u304F\u308C\u30FC",
  "id" : 441157806561849344,
  "in_reply_to_status_id" : 441157743311732736,
  "created_at" : "2014-03-05 10:26:32 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441157587845648384",
  "geo" : { },
  "id_str" : "441157632074596353",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u3080\u3057\u308D\u5B58\u5728\u3059\u308B\u306E\u304B",
  "id" : 441157632074596353,
  "in_reply_to_status_id" : 441157587845648384,
  "created_at" : "2014-03-05 10:25:50 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441157599468077056",
  "text" : "\u306A\u3093\u3067\u81EA\u5206\u3092\u8CAC\u3081\u306B\u3083\u306A\u3089\u3093\u306E\u304B",
  "id" : 441157599468077056,
  "created_at" : "2014-03-05 10:25:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441157437211426817",
  "geo" : { },
  "id_str" : "441157518337654784",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3044\u3084\uFF0C\u81EA\u5206\u306F\u542B\u3093\u3067\u3044\u306A\u3044",
  "id" : 441157518337654784,
  "in_reply_to_status_id" : 441157437211426817,
  "created_at" : "2014-03-05 10:25:23 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441157387118854144",
  "text" : "\u4ED5\u4E8B\u3059\u308B\u3060\u3051\u3067\u30C9\u30AF\u30DA\u98F2\u3081\u308B\u4E16\u754C\u304C\u3053\u306E\u4E16\u306B",
  "id" : 441157387118854144,
  "created_at" : "2014-03-05 10:24:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441156821479219200",
  "geo" : { },
  "id_str" : "441157238585962496",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u3067\u3082\u307E\u3046\u3061\u3083\u306F\u6551\u3063\u3066\u304F\u308C\u306A\u3044",
  "id" : 441157238585962496,
  "in_reply_to_status_id" : 441156821479219200,
  "created_at" : "2014-03-05 10:24:16 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441156909836406784",
  "text" : "\u304A\u8179\u6E1B\u3063\u3066\u308B\u3063\u307D\u3044\u4EBA\u306B\u6587\u5B57\u5217\u3067\u30E1\u30B7\u30C6\u30ED",
  "id" : 441156909836406784,
  "created_at" : "2014-03-05 10:22:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441156531292082176",
  "geo" : { },
  "id_str" : "441156662699630592",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u308D\u304F\u3067\u3082\u306A\u3044\u5148\u8F29\u3092\u91CF\u7523\u3057\u305F\u611F\u306F\u3042\u3063\u305F\uFF0E",
  "id" : 441156662699630592,
  "in_reply_to_status_id" : 441156531292082176,
  "created_at" : "2014-03-05 10:21:59 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441156235065171968",
  "text" : "\u6587\u5B57\u5217\u306B\u3088\u308B\u30E1\u30B7\u30C6\u30ED",
  "id" : 441156235065171968,
  "created_at" : "2014-03-05 10:20:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u307E\u3046\u8336",
      "screen_name" : "maucha_",
      "indices" : [ 0, 8 ],
      "id_str" : "112886536",
      "id" : 112886536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441155994966843392",
  "geo" : { },
  "id_str" : "441156197043806209",
  "in_reply_to_user_id" : 112886536,
  "text" : "@maucha_ \u3055\u3063\u304D\u98DF\u3079\u305F\u30D2\u30E9\u30E1\u306E\u304A\u8336\u6F2C\u3051\uFF0C\u30D2\u30E9\u30E1\u304C\u3075\u308F\u3075\u308F\u3057\u3066\u3066\u3068\u3066\u3082\u7F8E\u5473\u3057\u304B\u3063\u305F\u3067\u3059",
  "id" : 441156197043806209,
  "in_reply_to_status_id" : 441155994966843392,
  "created_at" : "2014-03-05 10:20:08 +0000",
  "in_reply_to_screen_name" : "maucha_",
  "in_reply_to_user_id_str" : "112886536",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441155311693340672",
  "geo" : { },
  "id_str" : "441155449513984000",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3044\u3084\u307E\u3041\u304A\u3068\u306A\u3057\u3044\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u306F\u3042\u3063\u305F\u304C\u5144\u304C\u53CB\u4EBA\u591A\u3044\u611F\u3058\u3060\u3063\u305F\u304B\u3089\u3064\u3044\u305D\u3093\u306A\u611F\u3058\u306A\u306E\u304B\u3068",
  "id" : 441155449513984000,
  "in_reply_to_status_id" : 441155311693340672,
  "created_at" : "2014-03-05 10:17:10 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441154450686623744",
  "text" : "\u3046\u30FC\u3093\uFF0C\u77E5\u3089\u306A\u304F\u3066\u3044\u3044\u95C7\u306E\u7AEF\u3063\u3053\u306B\u89E6\u308C\u305F\u611F\u3058",
  "id" : 441154450686623744,
  "created_at" : "2014-03-05 10:13:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441154133014228992",
  "geo" : { },
  "id_str" : "441154291441487872",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u3048\uFF0C\u53CB\u9054\u3044\u306A\u304B\u3063\u305F\u306E\u307E\u3058\u304B",
  "id" : 441154291441487872,
  "in_reply_to_status_id" : 441154133014228992,
  "created_at" : "2014-03-05 10:12:33 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441153952252297216",
  "text" : "\u3042\u3042\uFF0C\uFF0C\uFF0C\u3042\u3042\uFF0C\uFF0C\uFF0C\uFF0C",
  "id" : 441153952252297216,
  "created_at" : "2014-03-05 10:11:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 3, 12 ],
      "id_str" : "112398542",
      "id" : 112398542
    }, {
      "name" : "end.K",
      "screen_name" : "end313124",
      "indices" : [ 14, 24 ],
      "id_str" : "155546700",
      "id" : 155546700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441153915849945088",
  "text" : "RT @akeopyaa: @end313124 \u3046\u3061\u306E\u59B9\u306F\u60AA\u304F\u306A\u3044\u3002\u52DD\u624B\u306B\u795E\u683C\u5316\u3055\u308C\u305F\u306E\u3060\u304B\u3089\u88AB\u5BB3\u8005\u3060\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jigtwi.jp\/?p=1\" rel=\"nofollow\"\u003Ejigtwi\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "end.K",
        "screen_name" : "end313124",
        "indices" : [ 0, 10 ],
        "id_str" : "155546700",
        "id" : 155546700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "441152727398092800",
    "geo" : { },
    "id_str" : "441153234787266560",
    "in_reply_to_user_id" : 155546700,
    "text" : "@end313124 \u3046\u3061\u306E\u59B9\u306F\u60AA\u304F\u306A\u3044\u3002\u52DD\u624B\u306B\u795E\u683C\u5316\u3055\u308C\u305F\u306E\u3060\u304B\u3089\u88AB\u5BB3\u8005\u3060\u3002",
    "id" : 441153234787266560,
    "in_reply_to_status_id" : 441152727398092800,
    "created_at" : "2014-03-05 10:08:22 +0000",
    "in_reply_to_screen_name" : "end313124",
    "in_reply_to_user_id_str" : "155546700",
    "user" : {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "protected" : false,
      "id_str" : "112398542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561391966932312067\/9EtgtRKB_normal.jpeg",
      "id" : 112398542,
      "verified" : false
    }
  },
  "id" : 441153915849945088,
  "created_at" : "2014-03-05 10:11:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441153234787266560",
  "geo" : { },
  "id_str" : "441153339938439169",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u78BA\u304B\u306B\u2026",
  "id" : 441153339938439169,
  "in_reply_to_status_id" : 441153234787266560,
  "created_at" : "2014-03-05 10:08:47 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 0, 9 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441152508979720192",
  "geo" : { },
  "id_str" : "441152727398092800",
  "in_reply_to_user_id" : 112398542,
  "text" : "@akeopyaa \u5F53\u6642\u304B\u3089\u601D\u3063\u3061\u3083\u3044\u305F\u304C\u3069\u3046\u8003\u3048\u3066\u3082\u6C17\u6301\u3061\u60AA\u3044",
  "id" : 441152727398092800,
  "in_reply_to_status_id" : 441152508979720192,
  "created_at" : "2014-03-05 10:06:21 +0000",
  "in_reply_to_screen_name" : "akeopyaa",
  "in_reply_to_user_id_str" : "112398542",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u8266\u5A18",
      "screen_name" : "akeopyaa",
      "indices" : [ 9, 18 ],
      "id_str" : "112398542",
      "id" : 112398542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441151952819216385",
  "text" : "\u4ECA\u601D\u3048\u3070\u9AD8\u6821\u6642\u4EE3\uFF0C@akeopyaa \u306E\u59B9\u306E\u7ACB\u3061\u4F4D\u7F6E\uFF0C\u3069\u3046\u8003\u3048\u3066\u3082\u30AA\u30BF\u30B5\u30FC\u306E\u59EB\u3081\u3044\u3066\u305F\uFF0C",
  "id" : 441151952819216385,
  "created_at" : "2014-03-05 10:03:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441150751218212864",
  "text" : "\u307E\u3041\u3067\u3082\u96FB\u5B50\u9320\u6642\u4EE3\u3060\u3057\u9375\u5C4B\u3055\u3093\u3068\u304B\u5927\u5909\u305D\u3046(\u5C0F\u4E26)",
  "id" : 441150751218212864,
  "created_at" : "2014-03-05 09:58:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441150550361374720",
  "text" : "\u9006\u306B\u8003\u3048\u308B\u3093\u3060\uFF0C\u958B\u3051\u3061\u3083\u3063\u3066\u3082\u3044\u3044\u3055\uFF0C\u3068",
  "id" : 441150550361374720,
  "created_at" : "2014-03-05 09:57:42 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441150493549539328",
  "text" : "\u3060\u304B\u3089\u958B\u304D\u306B\u304F\u3044\u9375\u3092\u3064\u3051\u3088\u3046\u306D\uFF0C\u3068\u3044\u3046\u8A71\u3060\u3063\u305F\u306E\u3060\u304C\uFF0C\u3048\u3093\u3069\u3055\u3093\u306F\u9006\u306B\u300C\u6642\u9593\u3092\u304B\u3051\u308C\u3070\u958B\u304F\u3093\u3060\u306A\u3041\u300D\u3068\u601D\u3063\u305F\uFF0E",
  "id" : 441150493549539328,
  "created_at" : "2014-03-05 09:57:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441150316499582976",
  "text" : "\u9632\u72AF\u95A2\u4FC2\u306E\u7279\u96C6\u3067\u9375\u5C4B\u3055\u3093\u304C\u300C\u6642\u9593\u3092\u639B\u3051\u3066\u958B\u304B\u306A\u3044(\u7269\u7406\u7684\u306A)\u9375\u306F\u306A\u3044\u300D\u3063\u3066\u8A00\u3063\u3066\u305F",
  "id" : 441150316499582976,
  "created_at" : "2014-03-05 09:56:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441149747672276992",
  "text" : "\u3054\u308A\u62BC\u3057\u5358\u8ABF\u4F5C\u696D\u5927\u81E3\u3067\u3059",
  "id" : 441149747672276992,
  "created_at" : "2014-03-05 09:54:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441149335263145984",
  "text" : "\u3053\u306E\u524D\u62FE\u3063\u305F3\u30B1\u30BF\u30CA\u30F3\u30D0\u30FC\u30ED\u30C3\u30AF\u306E\u9375",
  "id" : 441149335263145984,
  "created_at" : "2014-03-05 09:52:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/441149192807792640\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/jqLDYw874n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh9G2nRCEAA91kL.jpg",
      "id_str" : "441149192572899328",
      "id" : 441149192572899328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh9G2nRCEAA91kL.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/jqLDYw874n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441149192807792640",
  "text" : "\u5168\u63A2\u7D22\u304A\u3058\u3055\u3093\u3001364\u3067\u306E\u89E3\u9320\u3092\u78BA\u8A8D http:\/\/t.co\/jqLDYw874n",
  "id" : 441149192807792640,
  "created_at" : "2014-03-05 09:52:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441143868801568768",
  "text" : "\u51B7\u8535\u5EAB\u306B\u201D\u201D\u305F\u307E\u305F\u307E\u201D\u201D\u6B8B\u3063\u3066\u3044\u305F\u76AE\u4ED8\u304D\u306E\u30D2\u30E9\u30E1\u306E\u5207\u308A\u8EAB",
  "id" : 441143868801568768,
  "created_at" : "2014-03-05 09:31:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441142377726504961",
  "text" : "\u30D2\u30E9\u30E1\u306E\u304A\u8336\u6F2C\u3051\u3081\u3044\u305F\u3082\u306E\u3092\u98DF\u3079\u307E\u3057\u3087\u3046",
  "id" : 441142377726504961,
  "created_at" : "2014-03-05 09:25:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441142325339627520",
  "text" : "\u6C17\u304C\u3064\u3044\u305F\u3089\u4ECA\u65E5\u307E\u3068\u3082\u306B\u30E2\u30CE\u98DF\u3079\u3066\u306A\u3044",
  "id" : 441142325339627520,
  "created_at" : "2014-03-05 09:25:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441140893613953025",
  "text" : "\u3053\u306E\u611F\u3058\u4E45\u3005\u3060\u306A",
  "id" : 441140893613953025,
  "created_at" : "2014-03-05 09:19:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441140685534539776",
  "text" : "\u8DDD\u96E2\u611F\u3092\u5B66\u3073\u307E\u3057\u3087\u3046",
  "id" : 441140685534539776,
  "created_at" : "2014-03-05 09:18:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441137724657893376",
  "text" : "\u3086\u3044\u304B\u304A\u308A\u306E\u826F\u3044\u4ED5\u69D8\u66F8\u3068\u60AA\u3044\u4ED5\u69D8\u66F8\u3068\u305D\u3046\u3067\u306A\u3044\u6587\u7AE0\u306E\u898B\u5206\u3051\u304C\u3064\u304B\u306A\u3044\u307B\u3046",
  "id" : 441137724657893376,
  "created_at" : "2014-03-05 09:06:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u305F\u3044\u3077\u304B\u306E\u3093\/\u30B9\u30FC\u305F\u3093",
      "screen_name" : "typekanon",
      "indices" : [ 0, 10 ],
      "id_str" : "157989076",
      "id" : 157989076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441137535712890880",
  "geo" : { },
  "id_str" : "441137630193782784",
  "in_reply_to_user_id" : 157989076,
  "text" : "@typekanon \u8CE2\u3044\u3067\u3059\u306D",
  "id" : 441137630193782784,
  "in_reply_to_status_id" : 441137535712890880,
  "created_at" : "2014-03-05 09:06:21 +0000",
  "in_reply_to_screen_name" : "typekanon",
  "in_reply_to_user_id_str" : "157989076",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441137480759119874",
  "text" : "\u81EA\u5206\u3067\u4ED5\u69D8\u66F8\u3092\u66F8\u3044\u3066\u958B\u767A\u3059\u308B\u3063\u3066\u3069\u3046\u306A\u3093\u3060",
  "id" : 441137480759119874,
  "created_at" : "2014-03-05 09:05:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441137379860959232",
  "text" : "\u3086\u308B\u307C \u4ED5\u69D8\u66F8\u306E\u66F8\u304D\u65B9",
  "id" : 441137379860959232,
  "created_at" : "2014-03-05 09:05:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441136609480552448",
  "text" : "\u6D77\u5916\u306E\u5E97\u8217\u3092\u9664\u3051\u3070\u30D5\u30A1\u30DF\u30EA\u30FC\u30DE\u30FC\u30C8\u306F10,327\u5E97\u8217\u3057\u304B\u306A\u3044\u306E\u304B",
  "id" : 441136609480552448,
  "created_at" : "2014-03-05 09:02:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441119791428812800",
  "text" : "\u8AB0\u304B\u5BB6\u306B\u4F7F\u3063\u3066\u306A\u3044\u5168\u56FD\u9053\u8DEF\u5730\u56F3\u307F\u305F\u3044\u306A\u306E\u3042\u308B\u4EBA\u3044\u305F\u3089\u304F\u3060\u3055\u3044(\u5F37\u6B32)",
  "id" : 441119791428812800,
  "created_at" : "2014-03-05 07:55:28 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441118491886628865",
  "text" : "\u3053\u308C\u3067\u30E1\u30ED\u30F3\u30BD\u30FC\u30C0\u98F2\u3081\u308B\u3057\u7121\u6575",
  "id" : 441118491886628865,
  "created_at" : "2014-03-05 07:50:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon.co.jp (\u30A2\u30DE\u30BE\u30F3)",
      "screen_name" : "AmazonJP",
      "indices" : [ 46, 55 ],
      "id_str" : "161616614",
      "id" : 161616614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/9pPNGfmqkF",
      "expanded_url" : "http:\/\/www.amazon.co.jp\/dp\/B0033VGLHY\/ref=cm_sw_r_tw_asp_GQh3H.08X9FDC",
      "display_url" : "amazon.co.jp\/dp\/B0033VGLHY\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441118413310541824",
  "text" : "\u6B21\u306E\u5546\u54C1\u3092\u8CFC\u5165\u3057\u307E\u3057\u305F\uFF1A\u30E1\u30ED\u30F3\u30B7\u30ED\u30C3\u30D7 \u300E\u30B5\u30F3\u30C8\u30EA\u30FC \u30E1\u30ED\u30F3\u30B7\u30ED\u30C3\u30D7 780ml\u300F via @amazonJP http:\/\/t.co\/9pPNGfmqkF",
  "id" : 441118413310541824,
  "created_at" : "2014-03-05 07:49:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441115796597506051",
  "text" : "\u4F55\u304B\u306E\u5F62\u3067\u9023\u7D61\u304F\u3060\u3055\u3044\uFF0E\u3063\u3066\u66F8\u3053\u3046\u3068\u3057\u3066\u4F55\u304B\u306E\u5F62\u3067\u30EA\u30D7\u30E9\u30A4\u304F\u3060\u3055\u3044\uFF0C\u3063\u3066\u8A00\u3063\u3066\u3057\u307E\u3063\u305F\u304C\u305D\u308C\u3059\u3054\u3044\u52E2\u3044\u3067\u30C4\u30A4\u30C3\u30C6\u30FC\u306B\u9650\u5B9A\u3057\u3066\u3044\u308B",
  "id" : 441115796597506051,
  "created_at" : "2014-03-05 07:39:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u3063\u3061\u3093\u3071",
      "screen_name" : "kuttinpa",
      "indices" : [ 0, 9 ],
      "id_str" : "102399578",
      "id" : 102399578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441114633970008065",
  "in_reply_to_user_id" : 102399578,
  "text" : "@kuttinpa \u5B9F\u5BB6\u304B\u3089\u5E30\u3063\u305F\u3089\u4F55\u304B\u306E\u5F62\u3067\u30EA\u30D7\u30E9\u30A4\u304F\u3060\u3055\u3044\u306A",
  "id" : 441114633970008065,
  "created_at" : "2014-03-05 07:34:58 +0000",
  "in_reply_to_screen_name" : "kuttinpa",
  "in_reply_to_user_id_str" : "102399578",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441112424393875457",
  "text" : "\u3046\u30FC\u3093\uFF0C\u30AB\u30FC\u30C9\u5165\u308C\u308B\u7BB1\u9069\u5F53\u306B\u898B\u7E55\u308F\u306A\u3044\u3068\u304B\u306A\uFF1F",
  "id" : 441112424393875457,
  "created_at" : "2014-03-05 07:26:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u3064\u308A\u3046\u3080@0817-4100-1332",
      "screen_name" : "otsuotsu",
      "indices" : [ 0, 9 ],
      "id_str" : "53934373",
      "id" : 53934373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441110451019976704",
  "geo" : { },
  "id_str" : "441110667227983872",
  "in_reply_to_user_id" : 53934373,
  "text" : "@otsuotsu \u3067\u306F\u305D\u306E\u611F\u3058\u3067\u3088\u308D\u3057\u304F\u304A\u306D\u304C\u3044\u3057\u307E\u3059\uFF0E\u7D9A\u304D\u306FDM\u3067\uFF0E",
  "id" : 441110667227983872,
  "in_reply_to_status_id" : 441110451019976704,
  "created_at" : "2014-03-05 07:19:13 +0000",
  "in_reply_to_screen_name" : "otsuotsu",
  "in_reply_to_user_id_str" : "53934373",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441110029702139904",
  "text" : "\u5B9F\u5BB6\u306B\u9670\u8B00\u3068\u6D77\u8FBA\u304C\u3042\u308B\u306E\u3082\u601D\u3044\u51FA\u3057\u305F\u304C",
  "id" : 441110029702139904,
  "created_at" : "2014-03-05 07:16:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441109764219490304",
  "text" : "\u4E2D\u53E4\u306E\u76F8\u5834\u3055\u3063\u3071\u308A\u308F\u304B\u3089\u3093\u307D\u3093",
  "id" : 441109764219490304,
  "created_at" : "2014-03-05 07:15:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u3064\u308A\u3046\u3080@0817-4100-1332",
      "screen_name" : "otsuotsu",
      "indices" : [ 0, 9 ],
      "id_str" : "53934373",
      "id" : 53934373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441109204409937920",
  "geo" : { },
  "id_str" : "441109710356238337",
  "in_reply_to_user_id" : 53934373,
  "text" : "@otsuotsu \u7121\u5370\uFF0C\u9670\u8B00\uFF0C\u53CE\u7A6B\u796D\u306F\u624B\u5143\u306B\u3042\u308B\u306E\u3067\u30A4\u30DE\u30A4\u30C1\u30A2\u30EC\u3067\u3059\u304C\u305D\u308C\u4EE5\u5916\u306A\u3089\u4E00\u30641500\u5186\u304F\u3089\u3044\u3067\u3059\u304B\u306D\uFF1F",
  "id" : 441109710356238337,
  "in_reply_to_status_id" : 441109204409937920,
  "created_at" : "2014-03-05 07:15:25 +0000",
  "in_reply_to_screen_name" : "otsuotsu",
  "in_reply_to_user_id_str" : "53934373",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u3064\u308A\u3046\u3080@0817-4100-1332",
      "screen_name" : "otsuotsu",
      "indices" : [ 0, 9 ],
      "id_str" : "53934373",
      "id" : 53934373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441108870745047040",
  "geo" : { },
  "id_str" : "441109038630064128",
  "in_reply_to_user_id" : 53934373,
  "text" : "@otsuotsu \u5272\u3068\u6B32\u3057\u3044\u3067\u3059[\u5024\u6BB5\u306B\u3082\u4F9D\u308A\u307E\u3059\u304C]",
  "id" : 441109038630064128,
  "in_reply_to_status_id" : 441108870745047040,
  "created_at" : "2014-03-05 07:12:44 +0000",
  "in_reply_to_screen_name" : "otsuotsu",
  "in_reply_to_user_id_str" : "53934373",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441108722446635009",
  "text" : "\u57FA\u672C\u304B",
  "id" : 441108722446635009,
  "created_at" : "2014-03-05 07:11:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304A\u3064\u308A\u3046\u3080@0817-4100-1332",
      "screen_name" : "otsuotsu",
      "indices" : [ 0, 9 ],
      "id_str" : "53934373",
      "id" : 53934373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441108535548465152",
  "geo" : { },
  "id_str" : "441108602267242496",
  "in_reply_to_user_id" : 53934373,
  "text" : "@otsuotsu \u7121\u5370\u3067\u3059\uFF1F",
  "id" : 441108602267242496,
  "in_reply_to_status_id" : 441108535548465152,
  "created_at" : "2014-03-05 07:11:00 +0000",
  "in_reply_to_screen_name" : "otsuotsu",
  "in_reply_to_user_id_str" : "53934373",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441108476916273153",
  "text" : "\u7518\u3044\u306E\u3057\u3087\u3063\u3071\u3044\u306E\u7518\u3044\u306E\u3057\u3087\u3063\u3071\u3044\u306E",
  "id" : 441108476916273153,
  "created_at" : "2014-03-05 07:10:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441105953526517760",
  "text" : "\u3059\u3054\u304F\u3042\u307E\u3044",
  "id" : 441105953526517760,
  "created_at" : "2014-03-05 07:00:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441105907334664193",
  "text" : "\u4E94\u5104\u5E74\u3076\u308A\u306B\u5348\u5F8C\u306E\u7D05\u8336\uFF08\u30B9\u30C8\u30EC\u30FC\u30C8\uFF09\u98F2\u3093\u3067\u308B",
  "id" : 441105907334664193,
  "created_at" : "2014-03-05 07:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441091784920158208",
  "text" : "21\u6642\u307E\u3067\u3059\u3054\u3044H\u3057\u3066\u305D\u308C\u304B\u3089\u6E80\u3092\u6301\u3057\u3066\u5F15\u8D8A\u3057\u306E\u6E96\u5099\u3092\u59CB\u3081\u3088\u3046",
  "id" : 441091784920158208,
  "created_at" : "2014-03-05 06:04:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441091181091360769",
  "text" : "\u3082\u3082\u306E\u30BC\u30EA\u30FC\uFF4D\uFF47\uFF4D\uFF47",
  "id" : 441091181091360769,
  "created_at" : "2014-03-05 06:01:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441083036226973696",
  "text" : "\u305D\u308C\u306B\u3057\u3066\u3082\u304A\u306A\u304B\u306E\u3044\u305F\u307F\u3088",
  "id" : 441083036226973696,
  "created_at" : "2014-03-05 05:29:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441071924068622338",
  "text" : "\u65AD\u7D9A\u7684\u306A\u8179\u75DB\u306A\u3093\u3058\u3083",
  "id" : 441071924068622338,
  "created_at" : "2014-03-05 04:45:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441069611992109056",
  "text" : "\u98DF\u6B32\u3042\u3093\u307E\u308A\u306A\u3044\u3051\u3069\u30D0\u30FC\u30E0\u30AF\u30FC\u30D8\u30F3\u306F\u3061\u3083\u3093\u3068\u304A\u3044\u3057\u3044",
  "id" : 441069611992109056,
  "created_at" : "2014-03-05 04:36:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441068864399347712",
  "text" : "\u306A\u3093\u306B\u3082\u3057\u3089\u306A\u3044",
  "id" : 441068864399347712,
  "created_at" : "2014-03-05 04:33:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440890795701182464",
  "text" : "\u6628\u65E5\u306E\u70AC\u71F5\u3067\u306E\u7761\u7720\u306F\u5931\u6557\u3060\u3063\u305F",
  "id" : 440890795701182464,
  "created_at" : "2014-03-04 16:45:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440819018090311680",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 440819018090311680,
  "created_at" : "2014-03-04 12:00:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440723266907279360",
  "geo" : { },
  "id_str" : "440749695581687809",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u304F\u308B\u6642\u306B\u4F55\u304B\u304A\u304B\u305A\u6301\u3063\u3066\u304D\u3066\u304F\u308C\u305F\u3089\u3054\u98EF\u708A\u3044\u3066\u304A\u304D\u307E\u3059[\u3046\u3061\u306B\u826F\u3044\u611F\u3058\u306E\u98DF\u6750\u304C\u3061\u3087\u3053\u3061\u3087\u3053\u3042\u308A\u307E\u3059]",
  "id" : 440749695581687809,
  "in_reply_to_status_id" : 440723266907279360,
  "created_at" : "2014-03-04 07:24:50 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440699602405044226",
  "text" : "\u30DF\u30CB\u30D0\u30C3\u30D5\u30A1\u3068\u30B9\u30AF\u30E9\u30C3\u30C1\u306E\u4E0A\u624B\u306A\u4F7F\u3044\u65B9\u304C\u4ECA\u4E00\u3064\u826F\u304F\u308F\u304B\u3089\u306A\u3044\u306A\u30FC",
  "id" : 440699602405044226,
  "created_at" : "2014-03-04 04:05:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440567729028747264",
  "text" : "\u30BB\u30DF\u30B3\u30ED\u30F3\u306E\u30DC\u30BF\u30F3\u62BC\u3057\u305F\u3089-\u304C\u51FA\u3066,\u30B9\u30E9\u30C3\u30B7\u30E5\u306E\u30DC\u30BF\u30F3\u62BC\u3057\u305F\u3089+\u3067\u3066\u304F\u308B\u306E",
  "id" : 440567729028747264,
  "created_at" : "2014-03-03 19:21:46 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/440566874716123136\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/9wqj3fGuFZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh01PQOCMAAIAMD.jpg",
      "id_str" : "440566874720317440",
      "id" : 440566874720317440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh01PQOCMAAIAMD.jpg",
      "sizes" : [ {
        "h" : 97,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 923
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 923
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9wqj3fGuFZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440566874716123136",
  "text" : "\u9ED2\u677F\u3081\u3044\u3066\u30A2\u30EC http:\/\/t.co\/9wqj3fGuFZ",
  "id" : 440566874716123136,
  "created_at" : "2014-03-03 19:18:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440557551269052417",
  "text" : "\u9ED2\u3067\u306A\u304F\u9752\u3068\u304B\u7DD1\u306E\u307B\u3046\u304C\u3044\u3044\u306E\u304B\u3093",
  "id" : 440557551269052417,
  "created_at" : "2014-03-03 18:41:20 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440557467546566656",
  "text" : "\u3046\u30FC\u3093\uFF0C\u80CC\u666F\u8272\u3092\u6697\u304F\u3057\u3066\u307F\u305F\u3051\u308C\u3069\u9055\u548C\u611F\u3070\u304B\u308A\u304C\u306C\u306C\u306C\u306C\u306C",
  "id" : 440557467546566656,
  "created_at" : "2014-03-03 18:41:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440551084038189056",
  "text" : "p.277 memomemo",
  "id" : 440551084038189056,
  "created_at" : "2014-03-03 18:15:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440550749085265920",
  "text" : "(?)",
  "id" : 440550749085265920,
  "created_at" : "2014-03-03 18:14:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440550732182585345",
  "text" : "\u4E00\u6642\u306B\u5E30\u308B\u3068\u304B\u8A00\u3063\u3066\u305F\u79C1\u3081\u3056\u307E\u3041\u307F\u308D",
  "id" : 440550732182585345,
  "created_at" : "2014-03-03 18:14:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440550126239490048",
  "text" : "\u305A\u3082\u3082\u3082\u3082\u3082\u3082\u3082\u3082\u3082\u3082\u3082\u3082\u3082",
  "id" : 440550126239490048,
  "created_at" : "2014-03-03 18:11:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440549794239369216",
  "text" : "\u5E30\u308A\u305F\u3044\u3051\u308C\u3069\u5916\u306B\u51FA\u305F\u304F\u306A\u3044\u3053\u308C\u304C\u30B8\u30EC\u30F3\u30DE",
  "id" : 440549794239369216,
  "created_at" : "2014-03-03 18:10:30 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440549254231109632",
  "text" : "\u4E45\u3005\u306B\u3084\u3063\u305F\u3089\u697D\u3057\u304B\u3063\u305F\u3067\u3059\uFF08\u3053\u306A\u307F\u304B\u3093\uFF09",
  "id" : 440549254231109632,
  "created_at" : "2014-03-03 18:08:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440549196840456192",
  "text" : "\u6607\u306E\u6587\u5B57\u3092TL\u3067\u89B3\u6E2C\u3057\u3066\u304B\u3089\u6607\u7ADC\u3092\u60F3\u8D77\u3057\u3066\u300C\u305D\u3046\u3044\u3048\u3070\u3046\u3060\u3055\u3093\u975E\u60F3\u5929\u5247\u51FA\u6765\u308B\u3093\u3067\u3057\u305F\u3063\u3051\u300D\u304B\u3089\u306E2\u6642\u9593\u304F\u3089\u3044\u975E\u60F3\u5929\u5247\u3060\u3063\u305F",
  "id" : 440549196840456192,
  "created_at" : "2014-03-03 18:08:08 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440519004617072641",
  "geo" : { },
  "id_str" : "440541372911607808",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u304B\u308B\u304B\u305D\u3093\u306C\uFF1F",
  "id" : 440541372911607808,
  "in_reply_to_status_id" : 440519004617072641,
  "created_at" : "2014-03-03 17:37:02 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440514237115269120",
  "text" : "\u4E00\u5E74\u524D\u306B\u4FE1\u3058\u306A\u3044\uFF0C\u306F\u4ECA\u306A\u3089\u4FE1\u3058\u308B\u3092\u542B\u610F\u3057\u306A\u3044",
  "id" : 440514237115269120,
  "created_at" : "2014-03-03 15:49:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1\u5E74\u524D\u306E\u81EA\u5206\u306B\u8A00\u3063\u3066\u3082\u4FE1\u3058\u3066\u3082\u3089\u3048\u306A\u3044\u3053\u3068",
      "indices" : [ 18, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440514064813268993",
  "text" : "\u656C\u8654\u306A\u30D2\u30F3\u30C9\u30A5\u30FC\u6559\u5F92\u306F\uFF0C\u606F\u3092\u3057\u306A\u3044 #1\u5E74\u524D\u306E\u81EA\u5206\u306B\u8A00\u3063\u3066\u3082\u4FE1\u3058\u3066\u3082\u3089\u3048\u306A\u3044\u3053\u3068",
  "id" : 440514064813268993,
  "created_at" : "2014-03-03 15:48:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440513648495042560",
  "text" : "\u304A\u301C\u3044\uFF0C\u304A\u6E6F (Iced)",
  "id" : 440513648495042560,
  "created_at" : "2014-03-03 15:46:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440513557650624512",
  "text" : "\u304A\u301C\u3044\uFF0C\u304A\u6E6F",
  "id" : 440513557650624512,
  "created_at" : "2014-03-03 15:46:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440513312191545344",
  "text" : "\u98F2\u3080\u305C\u304A\u6E6F",
  "id" : 440513312191545344,
  "created_at" : "2014-03-03 15:45:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440511671899934720",
  "text" : "\u30D1\u30B9\u30BF\u5165\u308C\u3066\u3082\u3044\u3044\u304B\u3082\u3057\u308C\u306A\u3044\uFF0E\u3061\u3087\u3046\u3061\u3087\u306E\u304B\u305F\u3061\u306E\u3084\u3064\uFF0E",
  "id" : 440511671899934720,
  "created_at" : "2014-03-03 15:39:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440511538248445952",
  "text" : "\u30AB\u30EA\u30AB\u30EA\u306B\u713C\u3044\u305F\u30D0\u30BF\u30FC\u30EB\u3068\uFF0C\u71B1\u3005\u306E\u30AF\u30E9\u30E0\u30C1\u30E3\u30A6\u30C0\u30FC\uFF0E",
  "id" : 440511538248445952,
  "created_at" : "2014-03-03 15:38:29 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440511418291347457",
  "text" : "\u6587\u5B57\u5217\u306B\u4F9D\u308B\u30E1\u30B7\u30C6\u30ED\u306E\u6642\u9593\u304B\u2026",
  "id" : 440511418291347457,
  "created_at" : "2014-03-03 15:38:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440511189575954433",
  "text" : "\u4ECA\u5DE6\u4EAC\u533A\u3067\u4E00\u756A\u30AF\u30E9\u30E0\u30C1\u30E3\u30A6\u30C0\u30FC\u98F2\u307F\u305F\u3044\u81EA\u4FE1\u3042\u308A\u307E\u3059",
  "id" : 440511189575954433,
  "created_at" : "2014-03-03 15:37:06 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440510397578084352",
  "text" : "monoid",
  "id" : 440510397578084352,
  "created_at" : "2014-03-03 15:33:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440509506905067521",
  "text" : "\u201D\u65E5\u672C\u304C\u751F\u307F\u51FA\u3057\u305F\u4EBA\u9593\u306E\u904E\u3061\u201D\u3063\u307D\u3044",
  "id" : 440509506905067521,
  "created_at" : "2014-03-03 15:30:25 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440509405700714496",
  "text" : "\u30DF\u30B9\u3063\u3066\u3042\u306E\u30DF\u30B9\u30B3\u30F3\u306E\u30DF\u30B9\u3068\u304B\u3067\u306F\u306A\u3044\u306E\u3067\uFF0C\u30DF\u30B9\u30B8\u30E3\u30D1\u30F3\u3092\u30D2\u30E5\u30FC\u30DE\u30F3\u30A8\u30E9\u30FC\u30B8\u30E3\u30D1\u30F3\u3068\u8868\u73FE\u3059\u308B\u306E\u306F\u3059\u3054\u3044\u52E2\u3044\u3067\u304A\u3059\u3059\u3081\u3057\u307E\u305B\u3093",
  "id" : 440509405700714496,
  "created_at" : "2014-03-03 15:30:01 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440509148061368320",
  "text" : "\u305F\u3060\u306E\u30DF\u30B9\u3092\u30D2\u30E5\u30FC\u30DE\u30F3\u30A8\u30E9\u30FC\u3063\u3066\u8868\u73FE\u3059\u308B\u3068\u3057\u304B\u305F\u306A\u304F\u8D77\u304D\u305F\u30DF\u30B9\u611F\u304C\u51FA\u308B\u306E\u3067\u304A\u52E7\u3081\u3067\u3059\uFF0E",
  "id" : 440509148061368320,
  "created_at" : "2014-03-03 15:28:59 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440508942884413440",
  "text" : "\u5BD2\u3044\u51AC\u306B\u6E29\u304B\u3044\u98F2\u307F\u7269\u653E\u7F6E\u3059\u308B\u3068\u51B7\u305F\u304F\u306A\u3063\u3066\u6691\u3044\u590F\u306B\u51B7\u305F\u3044\u98F2\u307F\u7269\u653E\u7F6E\u3059\u308B\u3068\u6E29\u304F\u306A\u308B\u306E\uFF0E\u9006\u3060\u3063\u305F\u3089\u3088\u304B\u3063\u305F\u306E\u306B\u306D\uFF0E\u8A2D\u8A08\u30DF\u30B9\u3060\u306D\uFF0E",
  "id" : 440508942884413440,
  "created_at" : "2014-03-03 15:28:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440508309112504320",
  "text" : "\u4E3B\u300C\u305D\u3093\u306A\u4E8B\u8A00\u308F\u308C\u3066\u3082\u3059\u3054\u304F\u56F0\u308B\u300D",
  "id" : 440508309112504320,
  "created_at" : "2014-03-03 15:25:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "indices" : [ 3, 11 ],
      "id_str" : "5965172",
      "id" : 5965172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440508224798617600",
  "text" : "RT @mr_konn: \u4E3B\u3001\u305D\u3093\u306A\u3053\u3068\u3044\u308F\u308C\u3066\u3082\u3053\u307E\u308A\u305D\u3046",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440508182096384000",
    "text" : "\u4E3B\u3001\u305D\u3093\u306A\u3053\u3068\u3044\u308F\u308C\u3066\u3082\u3053\u307E\u308A\u305D\u3046",
    "id" : 440508182096384000,
    "created_at" : "2014-03-03 15:25:09 +0000",
    "user" : {
      "name" : "induction hypothesis",
      "screen_name" : "mr_konn",
      "protected" : false,
      "id_str" : "5965172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566615944194060288\/nh8McKGS_normal.jpeg",
      "id" : 5965172,
      "verified" : false
    }
  },
  "id" : 440508224798617600,
  "created_at" : "2014-03-03 15:25:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440508116988203008",
  "text" : "\u4E3B\u3088\uFF0C\u4EBA\u306E\u65E5\u9803\u306E\u884C\u3044\u3088",
  "id" : 440508116988203008,
  "created_at" : "2014-03-03 15:24:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440508058033090561",
  "text" : "\u3042\u3041\u65E5\u9803\u306E\u884C\u3044\u3088",
  "id" : 440508058033090561,
  "created_at" : "2014-03-03 15:24:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440507693485133824",
  "text" : "\u3077\u3088\u3077\u3088\u3082\u30C6\u30C8\u30EA\u30B9\u3082\u3042\u308B\u7A0B\u5EA6\u597D\u304D\u3060\u3051\u3069\u5225\u3005\u306B\u904A\u3073\u305F\u3044\u306A\u3041\u3063\u3066\u601D\u3046\u308F\u3051\u3088",
  "id" : 440507693485133824,
  "created_at" : "2014-03-03 15:23:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440506432123711489",
  "text" : "\u30D5\u30A3\u30FC\u30D0\u30FC\u306F\u50D5\u306F\u3088\u304F\u308F\u304B\u3093\u306A\u3044\u3067\u3057",
  "id" : 440506432123711489,
  "created_at" : "2014-03-03 15:18:12 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440506276544380929",
  "text" : "\u3077\u3088\u3066\u3068\u306F\u3046\u30FC\u3093",
  "id" : 440506276544380929,
  "created_at" : "2014-03-03 15:17:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440506188262686721",
  "text" : "\u666E\u901A\u306E\u3077\u3088\u3077\u3088\uFF08\u901A\uFF09\u304C\u3044\u3044",
  "id" : 440506188262686721,
  "created_at" : "2014-03-03 15:17:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440505143461556224",
  "text" : "\u30A4\u30E4\u30FC\u30C3\u306F\u307E\u3060\u898B\u3066\u306A\u3044",
  "id" : 440505143461556224,
  "created_at" : "2014-03-03 15:13:05 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440505076407230464",
  "text" : "\u201D\u30B0\u30EF\u30FC\u30C3!! \u4F8B\u5916\u3060!\u201D\u3068\u304B\u66F8\u3044\u3066\u3042\u308B\u3057\u82F1\u8A9E\u570F\u3067\u306F\u30B0\u30EF\u30FC\u30C3\u3063\u3066\u306A\u3093\u304B\u4E00\u822C\u7684\u306A\u30A2\u30EC\u306A\u3093\u304B",
  "id" : 440505076407230464,
  "created_at" : "2014-03-03 15:12:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440504660151906305",
  "text" : "\u3053\u308F\u3044H\u672C",
  "id" : 440504660151906305,
  "created_at" : "2014-03-03 15:11:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440504613624479744",
  "text" : "\u201DHaskell \u306B undefined \u3092\u8A55\u4FA1\u3057\u3088\u3046\u3068\u3059\u308B\u3068\u3001Haskell \u306F\u6012\u308A\u3092\u7206\u767A\u3055\u305B\u307E\u3059\u201D\n\n\u306A\u308B\u307B\u3069\u3049\u2026",
  "id" : 440504613624479744,
  "created_at" : "2014-03-03 15:10:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440504067534508032",
  "text" : "\u51B7\u305F\u3044\u307B\u3046\u3058\u8336\u306F\u51B7\u305F\u3044\u307B\u3046\u3058\u8336\u306E\u3088\u3046\u306A\u5473\u304C\u3057\u3066\u3069\u3053\u304B\u51B7\u305F\u304B\u3063\u305F",
  "id" : 440504067534508032,
  "created_at" : "2014-03-03 15:08:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440503959908655104",
  "text" : "\u5BD2\u3055!\u305D\u306E\u7121\u6148\u60B2\u306A\u74B0\u5883\u306F\u6E29\u304B\u3044\u307B\u3046\u3058\u8336\u3092\u51B7\u305F\u3044\u307B\u3046\u3058\u8336\u306B\u5909\u3048\u305F\uFF01",
  "id" : 440503959908655104,
  "created_at" : "2014-03-03 15:08:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440503436186886144",
  "text" : "\u306A\u308B\u307B\u3069\u3049",
  "id" : 440503436186886144,
  "created_at" : "2014-03-03 15:06:18 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440503326963032064",
  "text" : "\u306A\u308B\u307B\u3069\u3049\uFF01\u3063\u3066\u30EA\u30D7\u30E9\u30A4\u304C\u6765\u308B\u30C4\u30A4\u30FC\u30E8\u3060",
  "id" : 440503326963032064,
  "created_at" : "2014-03-03 15:05:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440503252983885825",
  "text" : "\u4EBA\u306E\u610F\u898B\u306B\u306F\u98DF\u3044\u6C17\u5473\u306B\u300C\u306A\u308B\u307B\u3069\u3049\uFF01\u300D\u3063\u3066\u8A00\u3046\u3068\u5ACC\u308F\u308C\u308B\u3093\u3058\u3083\u306A\u3044\u304B\u3068\u601D\u3044\u307E\u3059\uFF0E",
  "id" : 440503252983885825,
  "created_at" : "2014-03-03 15:05:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440502777253359616",
  "text" : "Capslock\u30B9\u30EC\u30A4\u30E4\u30FC",
  "id" : 440502777253359616,
  "created_at" : "2014-03-03 15:03:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440499496309387264",
  "text" : "\u5148\u6708\u306E\u30C6\u30FC\u30DE\u300C\u306A\u3093\u3067\u305D\u3093\u306A\u8A00\u3044\u65B9\u3092\u3059\u308B\u306E\u304B\u300D\u5148\u3005\u6708\u306E\u30C6\u30FC\u30DE\u300C\u9732\u9AA8\u300D\u306B\u6BD4\u3079\u308C\u3070\u3060\u3044\u3076\u307E\u3068\u3082\u306B\u306A\u3063\u305F\u5370\u8C61\u3042\u308B",
  "id" : 440499496309387264,
  "created_at" : "2014-03-03 14:50:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440499283066765313",
  "text" : "\u699B\u540D\u306F\u5927\u4E08\u592B\u3067\u3059",
  "id" : 440499283066765313,
  "created_at" : "2014-03-03 14:49:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440499246957989891",
  "text" : "\u4ECA\u6708\u306E\u30C6\u30FC\u30DE\u306F\u201D\u5927\u4E08\u592B\u201D\u3067\u3059\uFF0E\u5168\u7136\u5927\u4E08\u592B\u3058\u3083\u306A\u3044\u6642\u306B\u4F7F\u3063\u3066\u3082\u5927\u4E08\u592B\u3067\u3059\uFF0E",
  "id" : 440499246957989891,
  "created_at" : "2014-03-03 14:49:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440498460681183233",
  "text" : "\u3086\u3086\u5F0F",
  "id" : 440498460681183233,
  "created_at" : "2014-03-03 14:46:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440497139609636865",
  "geo" : { },
  "id_str" : "440497272854286336",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u305D\u3057\u305F\u3089\u96C0\u8358\u3053\u306A\u304F\u3066\u3082\u4E00\u5FDC\u4F1A\u3048\u308B[\u9EBB\u96C0\u304C\u51FA\u6765\u308B\u3068\u306F\u8A00\u3063\u3066\u3044\u306A\u3044]",
  "id" : 440497272854286336,
  "in_reply_to_status_id" : 440497139609636865,
  "created_at" : "2014-03-03 14:41:48 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440496924387315713",
  "geo" : { },
  "id_str" : "440497096903237632",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u9811\u5F35\u308C\u3070\u884C\u3051\u307E\u3059\u305F\u3076\u3093",
  "id" : 440497096903237632,
  "in_reply_to_status_id" : 440496924387315713,
  "created_at" : "2014-03-03 14:41:06 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440496844087377921",
  "geo" : { },
  "id_str" : "440496927738576896",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u3042\u308C\u3060\u308C\u304B\u3068\u4E92\u3044\u306B\u7D20\u3060\u3045\u305F\u3063\u305F\u3093\u304C\u306E\u306A\u3061\u3083\u3093\u3058\u3083\u306A\u304B\u3063\u305F\u304B",
  "id" : 440496927738576896,
  "in_reply_to_status_id" : 440496844087377921,
  "created_at" : "2014-03-03 14:40:26 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440496620828770304",
  "geo" : { },
  "id_str" : "440496773996351489",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 kmc\u306E",
  "id" : 440496773996351489,
  "in_reply_to_status_id" : 440496620828770304,
  "created_at" : "2014-03-03 14:39:49 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5316\u5B66\u9B54\u3060\u306D\u3053\u30FC",
      "screen_name" : "kagakuma",
      "indices" : [ 0, 9 ],
      "id_str" : "139989698",
      "id" : 139989698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440496575630938113",
  "geo" : { },
  "id_str" : "440496741570207744",
  "in_reply_to_user_id" : 139989698,
  "text" : "@kagakuma \u3042\u3063\u2026[\u5F15\u8D8A\u3057\u306E\u4F5C\u696D\u306E\u9032\u6357\u6B21\u7B2C\u3067\u756A\u5916\u7DE8\u306A\u3089\u30EF\u30F3\u30C1\u30E3\u30F3\u2026]",
  "id" : 440496741570207744,
  "in_reply_to_status_id" : 440496575630938113,
  "created_at" : "2014-03-03 14:39:41 +0000",
  "in_reply_to_screen_name" : "kagakuma",
  "in_reply_to_user_id_str" : "139989698",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440496392532799488",
  "geo" : { },
  "id_str" : "440496496304070658",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 \u6765\u3088\u3046[\u5408\u5BBF\u524D\u534A\u6765\u308C\u306A\u3044\u30DE\u30F3\u3060\u3063\u305F\u3088\u306D\uFF1F]",
  "id" : 440496496304070658,
  "in_reply_to_status_id" : 440496392532799488,
  "created_at" : "2014-03-03 14:38:43 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440496229571506176",
  "text" : "\u3042\u3063\u3068\u304B\u304F\u3044\u30E1\u30FC\u30EA\u30B9\u6D41\u3057\u307E\u3057\u305F\uFF0C\u3054\u304B\u304F\u306B\u3093\u304F\u3060\u3055\u3044\uFF0C",
  "id" : 440496229571506176,
  "created_at" : "2014-03-03 14:37:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440494385176662016",
  "geo" : { },
  "id_str" : "440494486070652929",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u5927\u4E08\u592B\u306A\u306F\u305A\u3002\u30E1\u30FC\u30EB\u56DE\u3057\u307E\u3059\u306D\u3002",
  "id" : 440494486070652929,
  "in_reply_to_status_id" : 440494385176662016,
  "created_at" : "2014-03-03 14:30:44 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440493339758960641",
  "geo" : { },
  "id_str" : "440493646933012480",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u4E57\u308A\u6C17\u3067\u306A\u3044\u8A33\u304C\u306A\u3044",
  "id" : 440493646933012480,
  "in_reply_to_status_id" : 440493339758960641,
  "created_at" : "2014-03-03 14:27:24 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440493110573813761",
  "text" : "\u958B\u3051\u3070\u958B\u304F",
  "id" : 440493110573813761,
  "created_at" : "2014-03-03 14:25:16 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440492981636722688",
  "text" : "\u9B3C\u8ECD\u66F9\u306B\u935B\u3048\u3089\u308C\u305F\u611F\u3058 is there",
  "id" : 440492981636722688,
  "created_at" : "2014-03-03 14:24:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5317\u767D\u5DDD\u306E\u306A\u6539\u307D\u3088",
      "screen_name" : "nonamea774",
      "indices" : [ 0, 11 ],
      "id_str" : "122305557",
      "id" : 122305557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440492820680294401",
  "geo" : { },
  "id_str" : "440492902926385152",
  "in_reply_to_user_id" : 122305557,
  "text" : "@nonamea774 c-i",
  "id" : 440492902926385152,
  "in_reply_to_status_id" : 440492820680294401,
  "created_at" : "2014-03-03 14:24:26 +0000",
  "in_reply_to_screen_name" : "nonamea774",
  "in_reply_to_user_id_str" : "122305557",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440492581948895233",
  "geo" : { },
  "id_str" : "440492754729046017",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u4ECA\u9031\u91D1\u66DC\uFF0C\u96C0\u8358\u3092\u5F37\u5236\u7684\u306B\u958B\u304F\u304B\uFF0C\u5BB6\u3067\u958B\u50AC\u3059\u308C\u3070\u89E3\u6C7A\u3059\u308B\u554F\u984C\u306A",
  "id" : 440492754729046017,
  "in_reply_to_status_id" : 440492581948895233,
  "created_at" : "2014-03-03 14:23:51 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440492628090441728",
  "text" : "C-c C-f,C-b,C-n or C-p \u3092\u4F7F\u3046\u30DE\u30F3\u306FC-c C-f,C-b,C-n or C-p\u3092\u4F7F\u3046",
  "id" : 440492628090441728,
  "created_at" : "2014-03-03 14:23:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440492272539287553",
  "text" : "\u307E\u3041\u4ECA\u9031\u672B\u3067\u3082\u672C\u6C17\u51FA\u305B\u3070\u958B\u3051\u308B\u306F\u305A\u3060\u3051\u3069\u306A",
  "id" : 440492272539287553,
  "created_at" : "2014-03-03 14:21:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440491969173663744",
  "geo" : { },
  "id_str" : "440492114544033792",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba KMC\u306E\u5408\u5BBF\u306B\u88AB\u308A\u305D\u3046\u306A\u306E\u3068\u5F15\u8D8A\u3057\u6E96\u5099\u304C\u5927\u8A70\u3081\u3066\u308B\u4E88\u5B9A\u306A\u306E\u3067\u53B3\u3057\u305D\u3046\u306A\u2026",
  "id" : 440492114544033792,
  "in_reply_to_status_id" : 440491969173663744,
  "created_at" : "2014-03-03 14:21:18 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440491608794877952",
  "geo" : { },
  "id_str" : "440491746233831424",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba \u306F\u3044(\u4ECA\u9031\u672B\u96C0\u8358\u958B\u3044\u3066\u307B\u3057\u3044\u4EBA\u751F\u3060\u3063\u305F)",
  "id" : 440491746233831424,
  "in_reply_to_status_id" : 440491608794877952,
  "created_at" : "2014-03-03 14:19:50 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440491484689600513",
  "text" : "hogehoge\u306Fhogehogehogehoge\u3057\u3066\u3044\u3066\u3068\u3066\u3082hogehoge(hugahuga) :\u30C6\u30F3\u30D7\u30EC",
  "id" : 440491484689600513,
  "created_at" : "2014-03-03 14:18:48 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4EAC\u90FD\u304C\u751F\u3093\u3060\u5947\u8DE1\u677E\u5CA1",
      "screen_name" : "otoriheba",
      "indices" : [ 0, 10 ],
      "id_str" : "997040574",
      "id" : 997040574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440491140165287936",
  "geo" : { },
  "id_str" : "440491263347798017",
  "in_reply_to_user_id" : 997040574,
  "text" : "@otoriheba 3\u670818\u65E5\u306B\u5F15\u8D8A\u3057\u4E88\u5B9A",
  "id" : 440491263347798017,
  "in_reply_to_status_id" : 440491140165287936,
  "created_at" : "2014-03-03 14:17:55 +0000",
  "in_reply_to_screen_name" : "otoriheba",
  "in_reply_to_user_id_str" : "997040574",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440491189876183040",
  "text" : "functor\u306F\u30D5\u30A1\u30F3\u30AF\u30BF\u30FC\u30D5\u30A1\u30F3\u30AF\u30BF\u30FC\u3057\u3066\u3044\u3066\u3068\u3066\u3082\u95A2\u624B",
  "id" : 440491189876183040,
  "created_at" : "2014-03-03 14:17:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440490796190400512",
  "text" : "\u30E1\u30AC\u30CD\u304C\u66C7\u308B",
  "id" : 440490796190400512,
  "created_at" : "2014-03-03 14:16:04 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440490516019298306",
  "text" : "\u306A\u3093\u3067\u3082\u306A\u3044\u3067\u3059",
  "id" : 440490516019298306,
  "created_at" : "2014-03-03 14:14:57 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440490499464392704",
  "text" : "\u5831\u3058\u3061\u3083\u3063\u305F",
  "id" : 440490499464392704,
  "created_at" : "2014-03-03 14:14:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440490474596352000",
  "text" : "\u307B\u3046\u3058\u8336\u3092\u98F2\u3093\u3067\u3044\u308B\u3053\u3068\u3092\u5831\u3058\u3066\u3044\u304F",
  "id" : 440490474596352000,
  "created_at" : "2014-03-03 14:14:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440474837861937152",
  "text" : "\u4E16\u754C\u306Bhogehoge\u304C\u6E80\u3061\u3066\u3044\u3066\uFF0Chogehoge\u304C\u6E80\u3061\u3066\u3044\u308B\u3082\u306E\u304C\u4E16\u754C\u3060",
  "id" : 440474837861937152,
  "created_at" : "2014-03-03 13:12:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3083\u3093\u3075",
      "screen_name" : "nyamph_pf",
      "indices" : [ 1, 11 ],
      "id_str" : "107723928",
      "id" : 107723928
    }, {
      "name" : "\u3042\u3063\u304D\u30FC@NaN",
      "screen_name" : "ac_k_y",
      "indices" : [ 12, 19 ],
      "id_str" : "106036912",
      "id" : 106036912
    }, {
      "name" : "\u5B97\u50CF",
      "screen_name" : "0_hoc",
      "indices" : [ 20, 26 ],
      "id_str" : "819165439",
      "id" : 819165439
    }, {
      "name" : " 10th\u3093\u3069",
      "screen_name" : "yoned85",
      "indices" : [ 27, 35 ],
      "id_str" : "395275426",
      "id" : 395275426
    }, {
      "name" : "\u30C6\u30A4\u30EB\u30BA\u30FB\u30AA\u30D6\u30FB\u6F22\u30AA\u30BB\u30C1\u30A2@\u3075\u3093\u3059\uFF01",
      "screen_name" : "osetia_kaguya",
      "indices" : [ 45, 59 ],
      "id_str" : "56097393",
      "id" : 56097393
    }, {
      "name" : "---------_pi",
      "screen_name" : "Makizushi_pi",
      "indices" : [ 60, 73 ],
      "id_str" : "844744578",
      "id" : 844744578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440454759078559744",
  "text" : ".@nyamph_pf @ac_k_y @0_hoc @yoned85 @gya_aaa @osetia_kaguya @Makizushi_pi \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 440454759078559744,
  "created_at" : "2014-03-03 11:52:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440385241350279168",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046",
  "id" : 440385241350279168,
  "created_at" : "2014-03-03 07:16:38 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440385164640661505",
  "text" : "\u3055\u30FC\u3066\u3055\u3066\u30FC",
  "id" : 440385164640661505,
  "created_at" : "2014-03-03 07:16:19 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/EyqCKhQhGp",
      "expanded_url" : "http:\/\/4sq.com\/1hEoK9r",
      "display_url" : "4sq.com\/1hEoK9r"
    } ]
  },
  "geo" : { },
  "id_str" : "440346313314820096",
  "text" : "\u3048\u3044\u304C\uFF01\u3048\u3044\u304C\uFF01 (@ MOVIX\u4EAC\u90FD) http:\/\/t.co\/EyqCKhQhGp",
  "id" : 440346313314820096,
  "created_at" : "2014-03-03 04:41:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Knights",
      "screen_name" : "hatsusato",
      "indices" : [ 0, 10 ],
      "id_str" : "515476338",
      "id" : 515476338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440343068898648065",
  "geo" : { },
  "id_str" : "440343222368608256",
  "in_reply_to_user_id" : 515476338,
  "text" : "@hatsusato \u304A\u3051\u30FC",
  "id" : 440343222368608256,
  "in_reply_to_status_id" : 440343068898648065,
  "created_at" : "2014-03-03 04:29:40 +0000",
  "in_reply_to_screen_name" : "hatsusato",
  "in_reply_to_user_id_str" : "515476338",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440343148040970240",
  "text" : "\u663C\u306E\u96C6\u5408\u304C\u8F9B\u3044\u5B66\u751F\u306E\u56F3",
  "id" : 440343148040970240,
  "created_at" : "2014-03-03 04:29:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Knights",
      "screen_name" : "hatsusato",
      "indices" : [ 0, 10 ],
      "id_str" : "515476338",
      "id" : 515476338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440342867035185152",
  "geo" : { },
  "id_str" : "440342945737089024",
  "in_reply_to_user_id" : 515476338,
  "text" : "@hatsusato \u3042\u3063\u2026",
  "id" : 440342945737089024,
  "in_reply_to_status_id" : 440342867035185152,
  "created_at" : "2014-03-03 04:28:34 +0000",
  "in_reply_to_screen_name" : "hatsusato",
  "in_reply_to_user_id_str" : "515476338",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Knights",
      "screen_name" : "hatsusato",
      "indices" : [ 0, 10 ],
      "id_str" : "515476338",
      "id" : 515476338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440342458476793856",
  "geo" : { },
  "id_str" : "440342648247705600",
  "in_reply_to_user_id" : 515476338,
  "text" : "@hatsusato 35\u5206\u306B\u306F\u73FE\u5730\u306B\u3044\u308B\u307E\u3059\u3001\u305F\u3076\u3093",
  "id" : 440342648247705600,
  "in_reply_to_status_id" : 440342458476793856,
  "created_at" : "2014-03-03 04:27:23 +0000",
  "in_reply_to_screen_name" : "hatsusato",
  "in_reply_to_user_id_str" : "515476338",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Knights",
      "screen_name" : "hatsusato",
      "indices" : [ 0, 10 ],
      "id_str" : "515476338",
      "id" : 515476338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440339277071675393",
  "geo" : { },
  "id_str" : "440339920029110272",
  "in_reply_to_user_id" : 515476338,
  "text" : "@hatsusato \u308F\u304B\u308B",
  "id" : 440339920029110272,
  "in_reply_to_status_id" : 440339277071675393,
  "created_at" : "2014-03-03 04:16:32 +0000",
  "in_reply_to_screen_name" : "hatsusato",
  "in_reply_to_user_id_str" : "515476338",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304D\u306C\u3044\u30C8\u30A5\u30FC\u30F3",
      "screen_name" : "0_u0",
      "indices" : [ 0, 5 ],
      "id_str" : "62833617",
      "id" : 62833617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440337939470352385",
  "geo" : { },
  "id_str" : "440338055707492352",
  "in_reply_to_user_id" : 62833617,
  "text" : "@0_u0 \u3044\u307E\u304A\u304D\u305F",
  "id" : 440338055707492352,
  "in_reply_to_status_id" : 440337939470352385,
  "created_at" : "2014-03-03 04:09:08 +0000",
  "in_reply_to_screen_name" : "0_u0",
  "in_reply_to_user_id_str" : "62833617",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440337915634122753",
  "text" : "\u60E8\u72B6\u2026",
  "id" : 440337915634122753,
  "created_at" : "2014-03-03 04:08:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440337868909596674",
  "text" : "\u3042\u3001\u8D77\u304D\u3066\u307E\u3059\u3001\u53C2\u4E0A\u306B\u4E09\u6761\u3057\u3066\u307E\u3059",
  "id" : 440337868909596674,
  "created_at" : "2014-03-03 04:08:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440260051836489729",
  "geo" : { },
  "id_str" : "440321829924659200",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning OK",
  "id" : 440321829924659200,
  "in_reply_to_status_id" : 440260051836489729,
  "created_at" : "2014-03-03 03:04:39 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440186945893695488",
  "text" : "yama",
  "id" : 440186945893695488,
  "created_at" : "2014-03-02 18:08:40 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440168885350715394",
  "text" : "\u4E00\u5EA6\u5D29\u308C\u305F\u751F\u6D3B\u30EA\u30BA\u30E0\u306F\uFF0C\u3082\u3046\u4E8C\u5EA6\u3068\u5143\u306B\u306F\u623B\u3089\u306A\u3044",
  "id" : 440168885350715394,
  "created_at" : "2014-03-02 16:56:54 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440094180275019777",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 440094180275019777,
  "created_at" : "2014-03-02 12:00:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440062152620007425",
  "geo" : { },
  "id_str" : "440062688102596608",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning \u4E86\u89E3\u3057\u305F\uFF0E\u5177\u4F53\u7684\u306A\u6642\u9593\u3082\u4EFB\u305B\u308B\u306E\u3067\u8A00\u3063\u3066\u304F\u308C\u308C\u3070\u5BFE\u5FDC\u3057\u3084\u3059\uFF0E",
  "id" : 440062688102596608,
  "in_reply_to_status_id" : 440062152620007425,
  "created_at" : "2014-03-02 09:54:55 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DF\u30EB\u30C1",
      "screen_name" : "mircea_morning",
      "indices" : [ 0, 15 ],
      "id_str" : "199550192",
      "id" : 199550192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438235512763985921",
  "geo" : { },
  "id_str" : "440059169178021889",
  "in_reply_to_user_id" : 199550192,
  "text" : "@mircea_morning 4\u65E5\u3068\u304B\u3044\u304B\u304C\u3067\u3057\u3087\uFF0E\u6642\u9593\u5E2F\u306F\u3044\u3064\u3067\u3082\u304A\u3063\u3051\u30FC\u3067\u3059\uFF0E",
  "id" : 440059169178021889,
  "in_reply_to_status_id" : 438235512763985921,
  "created_at" : "2014-03-02 09:40:56 +0000",
  "in_reply_to_screen_name" : "mircea_morning",
  "in_reply_to_user_id_str" : "199550192",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twmode.sf.net\/\" rel=\"nofollow\"\u003Etwmode\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440058067841859584",
  "text" : "\u53CB\u4EBA\u3089\u304C\u6B8B\u3057\u3066\u3044\u3063\u305F\u591A\u304F\u306E\u6B63\u306E\u907A\u7523\u3067\u3057\u3070\u3089\u304F\u98DF\u3079\u3066\u3044\u3051\u308B(\uFF1F)",
  "id" : 440058067841859584,
  "created_at" : "2014-03-02 09:36:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/SluGa4Hzbu",
      "expanded_url" : "https:\/\/twitter.com\/end313124\/status\/440054921098838016",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "440054953202040832",
  "geo" : { },
  "id_str" : "440055029341241344",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo https:\/\/t.co\/SluGa4Hzbu",
  "id" : 440055029341241344,
  "in_reply_to_status_id" : 440054953202040832,
  "created_at" : "2014-03-02 09:24:29 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440054921098838016",
  "text" : "10\u5104\u5186\u596A\u3063\u3066\u4ED6\u306E\u4EBA\u306B\u3042\u3052\u308B\u4EBA\u306F\u60AA\u304F\u3066\u304B\u3064\u826F\u3044\u4EBA",
  "id" : 440054921098838016,
  "created_at" : "2014-03-02 09:24:03 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440054749761527808",
  "text" : "\u60AA\u3044\u4EBA\u306E\u5341\u5206\u6761\u4EF6\u306F10\u5104\u5186\u596A\u3046\u4EBA",
  "id" : 440054749761527808,
  "created_at" : "2014-03-02 09:23:22 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440054175548723200",
  "geo" : { },
  "id_str" : "440054253646655489",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u4F7F\u7528\u3057\u306A\u3044\u77E5\u8B58\u306E\u65B9\u304C\u591A\u3044",
  "id" : 440054253646655489,
  "in_reply_to_status_id" : 440054175548723200,
  "created_at" : "2014-03-02 09:21:24 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440054135103053824",
  "text" : "\u3054\u98EF\u98DF\u3079\u305F\u3089\u90E8\u5BA4\u3044\u304F\u306E",
  "id" : 440054135103053824,
  "created_at" : "2014-03-02 09:20:56 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440053640816898049",
  "geo" : { },
  "id_str" : "440054009244577792",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u307E\u305F\u4E00\u3064\u8CE2\u304F\u306A\u308A\u307E\u3057\u305F\u306D",
  "id" : 440054009244577792,
  "in_reply_to_status_id" : 440053640816898049,
  "created_at" : "2014-03-02 09:20:26 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440053324285353985",
  "geo" : { },
  "id_str" : "440053429012938752",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u826F\u3044\u4EBA\u306E\u5B9A\u7FA9\u304C\u826F\u3044\u3068\u306F\u9650\u3089\u306A\u3044",
  "id" : 440053429012938752,
  "in_reply_to_status_id" : 440053324285353985,
  "created_at" : "2014-03-02 09:18:07 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440053274603835392",
  "text" : "\u4E0A\u6607\u5FD7\u5411",
  "id" : 440053274603835392,
  "created_at" : "2014-03-02 09:17:31 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440053153300357120",
  "geo" : { },
  "id_str" : "440053239598166016",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u4E0A\u3092\u76EE\u6307\u3057\u3066\u308B\u826F\u3044\u4EBA",
  "id" : 440053239598166016,
  "in_reply_to_status_id" : 440053153300357120,
  "created_at" : "2014-03-02 09:17:22 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440053083725254656",
  "text" : "\u8D08\u4E0E\u7A0E\u3068\u304B\u639B\u304B\u308B\u306A\u2026",
  "id" : 440053083725254656,
  "created_at" : "2014-03-02 09:16:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30A4\u30BE\u30AF(\u4EEE)",
      "screen_name" : "sio_puyo",
      "indices" : [ 0, 9 ],
      "id_str" : "205621330",
      "id" : 205621330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440052591297175552",
  "geo" : { },
  "id_str" : "440052852212248576",
  "in_reply_to_user_id" : 205621330,
  "text" : "@sio_puyo \u6BBA\u3055\u308C\u308B\u4EBA\u9593\u306B\u308F\u3056\u308F\u305610\u5104\u3082\u304F\u308C\u308B\u306E\u306F\u826F\u3044\u4EBA\u3067\u306F\u3002\u846C\u5F0F\u3068\u304B\u304A\u5893\u3068\u304B\u6B7B\u306C\u306E\u3082\u30BF\u30C0\u3058\u3083\u306A\u3044\u306E\u3067",
  "id" : 440052852212248576,
  "in_reply_to_status_id" : 440052591297175552,
  "created_at" : "2014-03-02 09:15:50 +0000",
  "in_reply_to_screen_name" : "sio_puyo",
  "in_reply_to_user_id_str" : "205621330",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440052436867108864",
  "text" : "\u81EA\u660E\u306A\u632F\u308B\u821E\u3044\u304C\u529F\u3092\u594F\u3057\u305F",
  "id" : 440052436867108864,
  "created_at" : "2014-03-02 09:14:11 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30DB\u30EA\u30A3\u30FB\u30BB\u30F3\uFF08\u30B5\u30FC\u30AF\u30E9\u4F1A\u9577\uFF09",
      "screen_name" : "holysen",
      "indices" : [ 3, 11 ],
      "id_str" : "119406614",
      "id" : 119406614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/F4kxLsQHL7",
      "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/440051781461360640",
      "display_url" : "twitter.com\/end313124\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440052302041214976",
  "text" : "RT @holysen: \u300C\uFF5E\uFF5E\u306E\u6761\u4EF6\u306F\uFF1F\u300D\u3063\u3066\u8CEA\u554F\u3001\u5FC5\u8981\u6761\u4EF6\u3092\u805E\u3044\u3066\u308B\u3093\u3060\u306A\u3068\u3088\u304F\u5206\u304B\u308B\u56DE\u7B54\u3060\u3053\u308C \uFF1ERT http:\/\/t.co\/F4kxLsQHL7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sites.google.com\/site\/tweentwitterclient\/\" rel=\"nofollow\"\u003ETween\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/F4kxLsQHL7",
        "expanded_url" : "http:\/\/twitter.com\/end313124\/status\/440051781461360640",
        "display_url" : "twitter.com\/end313124\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440052138924711936",
    "text" : "\u300C\uFF5E\uFF5E\u306E\u6761\u4EF6\u306F\uFF1F\u300D\u3063\u3066\u8CEA\u554F\u3001\u5FC5\u8981\u6761\u4EF6\u3092\u805E\u3044\u3066\u308B\u3093\u3060\u306A\u3068\u3088\u304F\u5206\u304B\u308B\u56DE\u7B54\u3060\u3053\u308C \uFF1ERT http:\/\/t.co\/F4kxLsQHL7",
    "id" : 440052138924711936,
    "created_at" : "2014-03-02 09:13:00 +0000",
    "user" : {
      "name" : "\u30DB\u30EA\u30A3\u30FB\u30BB\u30F3\uFF08\u30B5\u30FC\u30AF\u30E9\u4F1A\u9577\uFF09",
      "screen_name" : "holysen",
      "protected" : false,
      "id_str" : "119406614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563696739647885312\/xD22Cw3z_normal.png",
      "id" : 119406614,
      "verified" : false
    }
  },
  "id" : 440052302041214976,
  "created_at" : "2014-03-02 09:13:39 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ask.fm\/\" rel=\"nofollow\"\u003EAsk.fm\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/NwKffLaP6G",
      "expanded_url" : "http:\/\/ask.fm\/a\/ae86lcq2",
      "display_url" : "ask.fm\/a\/ae86lcq2"
    } ]
  },
  "geo" : { },
  "id_str" : "440051781461360640",
  "text" : "\u300C\u826F\u3044\u4EBA\u300D\u306E\u6761\u4EF6\u306F\uFF1F \u2014 \u5341\u5206\u6761\u4EF6\u3068\u3057\u3066\u300C10\u5104\u5186\u304F\u308C\u308B\u300D\u3068\u304B\u304C\u3042\u308B\u3068\u601D\u3044\u307E\u3059 http:\/\/t.co\/NwKffLaP6G",
  "id" : 440051781461360640,
  "created_at" : "2014-03-02 09:11:35 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ask.fm\/\" rel=\"nofollow\"\u003EAsk.fm\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/99x0NaxjwG",
      "expanded_url" : "http:\/\/ask.fm\/a\/ae86a9jb",
      "display_url" : "ask.fm\/a\/ae86a9jb"
    } ]
  },
  "geo" : { },
  "id_str" : "440051604986032129",
  "text" : "\u4EAC\u5927\u6587\u5B66\u90E8\u306F\u3069\u3093\u306A\u96F0\u56F2\u6C17\u304C\u6F02\u3063\u3066\u307E\u3059\u304B\u3002 \u2014 \u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2(\u306A\u305C\u304B\u5909\u63DB\u51FA\u6765\u306A\u3044)\n\u3046\u30FC\u3093\u3001\u53E4\u304D\u826F\u304D\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u306F\u3042\u308B\u3068\u601D\u3044\u307E\u3059\u3002\u304C\u4EBA\u6A29\u9762\u3067\u3042\u307E\u308A\u82B3\u3057\u304F\u306A\u304B\u3063\u305F\u5370\u8C61\u3067\u3059\u3002\u4F55\u306E\u305F\u3081\u306EMIAKO\u3058\u3083\u3002 http:\/\/t.co\/99x0NaxjwG",
  "id" : 440051604986032129,
  "created_at" : "2014-03-02 09:10:53 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ask.fm\/\" rel=\"nofollow\"\u003EAsk.fm\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ilTuN7tzX7",
      "expanded_url" : "http:\/\/ask.fm\/a\/ae869059",
      "display_url" : "ask.fm\/a\/ae869059"
    } ]
  },
  "geo" : { },
  "id_str" : "440051161547427840",
  "text" : "\u4EAC\u5927\u306E\u597D\u304D\u306A\u3068\u3053\u308D\u306F\u3069\u3053\u3067\u3059\u304B\uFF1F \u2014 \u5834\u6240\u306A\u3089\u30B7\u30A7\u30EB\u30D4\u30F3\u30B9\u30AD\u30FC\u306E\u68EE\u3068\u304B\u7406\u5B66\u90E86\u53F7\u9928\u30D4\u30ED\u30C6\u30A3\u3068\u304B\u304C\u597D\u304D\u3067\u3059\u3002\u5834\u6240\u3067\u7121\u3044\u306A\u3089\u3001\u4E0B\u5BBF\u751F\u304C\u591A\u3044\u4E8B\u3068\u304B\u7D42\u96FB\u306E\u6982\u5FF5\u304C\u5E0C\u8584\u306A\u4E8B\u3001\u4F55\u306B\u3057\u3066\u3082\u512A\u79C0\u306A\u4EBA\u9593\u304C\u591A\u3044(\u81EA\u5206\u304C\u512A\u79C0\u3068\u306F\u8A00\u3063\u3066\u3044\u306A\u3044)\u4E8B\u3067\u3059\u3002 http:\/\/t.co\/ilTuN7tzX7",
  "id" : 440051161547427840,
  "created_at" : "2014-03-02 09:09:07 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440048504350597121",
  "text" : "\u52D8\u9055\u3044\u30CB\u30F3\u30B2\u30F3",
  "id" : 440048504350597121,
  "created_at" : "2014-03-02 08:58:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440047338547998721",
  "text" : "\u30EA\u30A2\u30AF\u30C8\u65E9\u3044",
  "id" : 440047338547998721,
  "created_at" : "2014-03-02 08:53:55 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440047302212730880",
  "text" : "\u5BDD\u3059\u304E\u305F(\u663C\u5BDD)",
  "id" : 440047302212730880,
  "created_at" : "2014-03-02 08:53:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439829576236032000",
  "text" : "\u3080\u305A\u304C\u306F\u306A\u306F\u306A\u3057\u3066\u6765\u305F\u3057\u305D\u3046\u3044\u3046\u5B63\u7BC0\u304B",
  "id" : 439829576236032000,
  "created_at" : "2014-03-01 18:28:37 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439828219361890305",
  "text" : "\u3054\u307E\u3060\u308C\u30FC\u30FC\u30FC",
  "id" : 439828219361890305,
  "created_at" : "2014-03-01 18:23:13 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439771730827956224",
  "text" : "\u51FA\u3066\u6765\u305F\u4EFB\u610F\u306E\u725B\u8089\u304C\u795E\u6238\u725B\u3067\u3046\u3049\u30A9\u30F3\uFF01",
  "id" : 439771730827956224,
  "created_at" : "2014-03-01 14:38:45 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439771602821992448",
  "text" : "\u53CB\u4EBA\u306E\u6BCD\u89AA\u306E\u53CB\u4EBA\u306B\u3054\u98EF\u3092\u3054\u99B3\u8D70\u306B\u306A\u308B\u4E16\u754C\u7DDA",
  "id" : 439771602821992448,
  "created_at" : "2014-03-01 14:38:15 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u68EE\u7530\u7D18\u5E73",
      "screen_name" : "kouheimorita",
      "indices" : [ 0, 13 ],
      "id_str" : "160230093",
      "id" : 160230093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439755793710055425",
  "geo" : { },
  "id_str" : "439771520466829312",
  "in_reply_to_user_id" : 160230093,
  "text" : "@kouheimorita \u53CB\u4EBA\u306E\u6BCD\u89AA\u306E\u53CB\u4EBA\u306B\u3054\u98EF\u3092\u3054\u99B3\u8D70\u306B\u306A\u308A\u306B\u6765\u3066\u307E\u3057\u305F",
  "id" : 439771520466829312,
  "in_reply_to_status_id" : 439755793710055425,
  "created_at" : "2014-03-01 14:37:55 +0000",
  "in_reply_to_screen_name" : "kouheimorita",
  "in_reply_to_user_id_str" : "160230093",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twisuke.com\" rel=\"nofollow\"\u003E\u30C4\u30A4\u52A9\u3002\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "follow_me",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "math",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439731837934391296",
  "text" : "\u3010\u81EA\u52D5\u30FB\u5B9A\u671F\u30FB\u62E1\u6563\u5E0C\u671B\u3011\u6570\u5B66\u597D\u304D\u306A\u4EBAfollow me! \uFF08\u5F97\u610F\u306A\u4EBA\u3001\u4E0B\u624B\u306E\u6A2A\u597D\u304D\u306A\u4EBA\u3001\u6570\u5B66\u597D\u304D\u306E\u6587\u7CFB\u3001\u6559\u3048\u3066\u308B\u3001\u6559\u308F\u3063\u3066\u308B\u3001\u7406\u5B66\u90E8\u3001\u5DE5\u5B66\u90E8\u3001\u72EC\u5B66\u3001\u5927\u6570\u4FE1\u8005\u3001etc\uFF09 #follow_me #math",
  "id" : 439731837934391296,
  "created_at" : "2014-03-01 12:00:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/FQEbtZCnrz",
      "expanded_url" : "http:\/\/4sq.com\/1pIqIKl",
      "display_url" : "4sq.com\/1pIqIKl"
    } ]
  },
  "geo" : { },
  "id_str" : "439720650442539008",
  "text" : "\u3053\u3046\u3079\u306F\u3058\u3081\u3066\u304D\u305F (@ \u4E09\u5BAE\u99C5 (Sannomiya Sta.) w\/ 3 others) http:\/\/t.co\/FQEbtZCnrz",
  "id" : 439720650442539008,
  "created_at" : "2014-03-01 11:15:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ask.fm\/\" rel=\"nofollow\"\u003EAsk.fm\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/ks8N2rDdx2",
      "expanded_url" : "http:\/\/ask.fm\/a\/ae4q6phl",
      "display_url" : "ask.fm\/a\/ae4q6phl"
    } ]
  },
  "geo" : { },
  "id_str" : "439709730702110720",
  "text" : "\u4ECA\u73FE\u5728\u4ED8\u304D\u5408\u3063\u3066\u308B\u4EBA\u306F\u3044\u307E\u3059\u304B\uFF1F \u2014 \u3044\u3048\uFF1F\u3044\u307E\u305B\u3093\u306A\u304C\u3089\u6B8B\u5FF5 http:\/\/t.co\/ks8N2rDdx2",
  "id" : 439709730702110720,
  "created_at" : "2014-03-01 10:32:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439699488010014720",
  "text" : "\u79FB\u52D5\u4E2D\u307F\u3093\u306A\u30B9\u30DE\u30D2\u30E7\u5F04\u3063\u3066\u308B\u69D8\u6FC3\u539A\u306A\u73FE\u4EE3\u30A2\u30C8\u30E2\u30B9\u30D5\u30A3\u30A2\u3092\u91B8\u3059",
  "id" : 439699488010014720,
  "created_at" : "2014-03-01 09:51:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/ip1Pe7FPc9",
      "expanded_url" : "http:\/\/ask.fm\/end313124",
      "display_url" : "ask.fm\/end313124"
    } ]
  },
  "geo" : { },
  "id_str" : "439698776387629056",
  "text" : "[\u8CEA\u554F\u306B]\u79FB\u52D5\u4E2D\u6687[\u7B54\u3048\u308B\u3068\u306F] http:\/\/t.co\/ip1Pe7FPc9 [\u9650\u3089\u306A\u3044]",
  "id" : 439698776387629056,
  "created_at" : "2014-03-01 09:48:52 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439698595877355520",
  "text" : "3\u6642\u9593\u5BDD\u3066\u3054\u98EF\u3092\u3054\u99B3\u8D70\u306B\u306A\u308A\u306B\u51FA\u639B\u3051\u308B",
  "id" : 439698595877355520,
  "created_at" : "2014-03-01 09:48:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439619240362917888",
  "text" : "\u30D0\u30B8\u30EB\u30B7\u30FC\u30C9",
  "id" : 439619240362917888,
  "created_at" : "2014-03-01 04:32:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439619180090773504",
  "text" : "\u6210\u57CE\u77F3\u4E95\u3067\u30AB\u30A8\u30EB\u306E\u5375\u98F2\u307F\u7269\u8CB7\u3063\u305F\uFF01\uFF01\uFF01",
  "id" : 439619180090773504,
  "created_at" : "2014-03-01 04:32:34 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/xNi9K9JwON",
      "expanded_url" : "http:\/\/4sq.com\/1pGZALV",
      "display_url" : "4sq.com\/1pGZALV"
    } ]
  },
  "geo" : { },
  "id_str" : "439605849661931520",
  "text" : "\u3089\u30FC\u30FC\u30FC\u30FC\u30FC\u306C\u3093 (@ \u4EAC\u90FD\u62C9\u9EBA\u5C0F\u8DEF) http:\/\/t.co\/xNi9K9JwON",
  "id" : 439605849661931520,
  "created_at" : "2014-03-01 03:39:36 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439600618869489664",
  "text" : "\u3067\u3082\u5358\u4F4D\u306F\u304F\u308C\u305F\u306E\u3067\u826F\u3044\u4EBA\u3067\u3059!!",
  "id" : 439600618869489664,
  "created_at" : "2014-03-01 03:18:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439600511520485376",
  "text" : "\u30AA\u30AF\u30CE\u6C0F\u3001\u3061\u3087\u3063\u3068\u7406\u4E0D\u5C3D\u306A\u5370\u8C61\u3057\u304B\u306A\u3044(\u504F\u898B)",
  "id" : 439600511520485376,
  "created_at" : "2014-03-01 03:18:23 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439596679059103744",
  "text" : "\u8D77\u304D\u3066\u304B\u30893\u6642\u9593\u304F\u3089\u3044\u7D4C\u3064\u306E\u306B\u6697\u304F\u306A\u3089\u306A\u3044\u306E\u4E0D\u601D\u8B70",
  "id" : 439596679059103744,
  "created_at" : "2014-03-01 03:03:10 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/tWbcOckCqr",
      "expanded_url" : "http:\/\/4sq.com\/1kz6aQP",
      "display_url" : "4sq.com\/1kz6aQP"
    } ]
  },
  "geo" : { },
  "id_str" : "439596079060119552",
  "text" : "\u304A\u3046\u3061\u304B\u3048\u308B (@ \u962A\u6025 \u5927\u5C71\u5D0E\u99C5 (Oyamazaki Sta.) (HK-75)) http:\/\/t.co\/tWbcOckCqr",
  "id" : 439596079060119552,
  "created_at" : "2014-03-01 03:00:47 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439595048171089920",
  "text" : "\u30C1\u30A7\u30EA\u30AA\u306E\u81EA\u8CA9\u6A5F\u306E100\u5186\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306B\u4F55\u3092\u6C42\u3081\u3066\u3044\u308B\u306E\u304B",
  "id" : 439595048171089920,
  "created_at" : "2014-03-01 02:56:41 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439594914796412928",
  "text" : "\u8584\u3044\u30C7\u30AB\u30D3\u30BF\u3001\u6B63\u3057\u3044\u5F62\u5BB9\u3060",
  "id" : 439594914796412928,
  "created_at" : "2014-03-01 02:56:09 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439594829098385408",
  "text" : "\u30D0\u30A4\u30AA\u30CB\u30C3\u30AF\u30A8\u30FC\u30B9\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046",
  "id" : 439594829098385408,
  "created_at" : "2014-03-01 02:55:49 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/OQIcCRkAG5",
      "expanded_url" : "http:\/\/4sq.com\/1eyrLrZ",
      "display_url" : "4sq.com\/1eyrLrZ"
    } ]
  },
  "geo" : { },
  "id_str" : "439570144827031552",
  "text" : "I'm at \u30B5\u30F3\u30C8\u30EA\u30FC\u5C71\u5D0E\u84B8\u6E9C\u6240 (Suntory Yamazaki Distillery) (\u4E09\u5CF6\u90E1, \u5927\u962A\u5E9C) http:\/\/t.co\/OQIcCRkAG5",
  "id" : 439570144827031552,
  "created_at" : "2014-03-01 01:17:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439560532131987456",
  "text" : "\u3082\u3075\u3082\u3075",
  "id" : 439560532131987456,
  "created_at" : "2014-03-01 00:39:32 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/ask.fm\/\" rel=\"nofollow\"\u003EAsk.fm\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/AqkojXpNtt",
      "expanded_url" : "http:\/\/ask.fm\/a\/ae44a3pd",
      "display_url" : "ask.fm\/a\/ae44a3pd"
    } ]
  },
  "geo" : { },
  "id_str" : "439560506354180096",
  "text" : "\u597D\u304D\u306A\u72AC\u306E\u54C1\u7A2E\u306F\uFF1F \u2014 \u30DD\u30E1\u30E9\u30CB\u30A2\u30F3 http:\/\/t.co\/AqkojXpNtt",
  "id" : 439560506354180096,
  "created_at" : "2014-03-01 00:39:26 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A8\u30AF\u30EC\u30FC\u30EB",
      "screen_name" : "eclair_15",
      "indices" : [ 1, 11 ],
      "id_str" : "158645894",
      "id" : 158645894
    }, {
      "name" : "\u306E\u3063\u3061\uFF20\u95A2\u6771\u306E\u4EBA",
      "screen_name" : "Notchi_KT",
      "indices" : [ 12, 22 ],
      "id_str" : "121298858",
      "id" : 121298858
    }, {
      "name" : "\u3057\u3087\u30FC\u304B\u304D",
      "screen_name" : "fire_EXT",
      "indices" : [ 23, 32 ],
      "id_str" : "371220128",
      "id" : 371220128
    }, {
      "name" : "\u516C\u5171\u4EA4\u901A\u6A5F\u95A2\u3092\u4F7F\u304A\u3046",
      "screen_name" : "yasuand",
      "indices" : [ 33, 41 ],
      "id_str" : "351349087",
      "id" : 351349087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439557370515963904",
  "text" : ".@eclair_15 @Notchi_KT @fire_EXT @yasuand @setsuna030218 \u30CA\u30A4\u30B9\u30CA\u30A4\u30B9\u30ED\u30C3\u30AF\uFF01",
  "id" : 439557370515963904,
  "created_at" : "2014-03-01 00:26:58 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439550041909243904",
  "text" : "\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u30A8\u30CA\u30B8\u30FC\u30C9\u30EA\u30F3\u30AF\u306A\u3046\uFF01",
  "id" : 439550041909243904,
  "created_at" : "2014-02-28 23:57:51 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439549969754644480",
  "text" : "\u306F\u3041\u301C\u301C\u301C\u301C\u301C(\u7720\u3044\u7720\u3044\u7720\u3044\u7720\u3044\u7720\u3044\u7720\u3044\u7720\u3044)",
  "id" : 439549969754644480,
  "created_at" : "2014-02-28 23:57:33 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439511072286842880",
  "text" : "\u3084\u3044\u3070\u306E\u30D6\u30FC\u30E1\u30E9\u30F3\u3060\u3063\u305F",
  "id" : 439511072286842880,
  "created_at" : "2014-02-28 21:23:00 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439511031321468928",
  "text" : "\u3053\u306E\u6642\u9593\u306B\u8D77\u304D\u3066\u308B\u5974\u30CA\u30CB\u30E2\u30F3\u3060\u3088\u2026",
  "id" : 439511031321468928,
  "created_at" : "2014-02-28 21:22:50 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439507737039618048",
  "text" : "\u5B9F\u3092\u8A00\u3046\u3068\u7720\u308B\u4E8B\u306F\u3082\u3046\u3060\u3081\u3067\u3059\u3002\n\u7A81\u7136\u3053\u3093\u306A\u3053\u3068\u8A00\u3063\u3066\u3054\u3081\u3093\u306D\u3002\n\u3067\u3082\u672C\u5F53\u3067\u3059\u3002\n\n2\u6642\u9593\u5F8C\u306B\u3082\u306E\u3059\u3054\u304F\n\u3046\u308B\u3055\u3044\u76EE\u899A\u307E\u3057\u304C\u9CF4\u308A\u307E\u3059\u3002\n\n\u305D\u308C\u304C\u8D77\u5E8A\u306E\u5408\u56F3\u3067\u3059\u3002\n\u7A0B\u306A\u304F\u30ED\u30C3\u30AF\u30B9\u30BF\u30FC\u304C\u51B7\u8535\u5EAB\u306B\u3042\u308B\u306E\u3067\n\u6C17\u3092\u3064\u3051\u3066\u3002\n\u305D\u308C\u3092\u98F2\u3093\u3060\u3089\u3001\u5C11\u3057\u3060\u3051\u9593\u3092\u304A\u3044\u3066\n\u8179\u75DB\u304C\u304D\u307E\u3059\u3002",
  "id" : 439507737039618048,
  "created_at" : "2014-02-28 21:09:44 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439506633623080960",
  "text" : "\u30A2\u30A4\u30A8\u30A8\u30A8\u2026",
  "id" : 439506633623080960,
  "created_at" : "2014-02-28 21:05:21 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439506604359442432",
  "text" : "\u3053\u3053\u3067\u60B2\u3057\u3044\u304A\u77E5\u3089\u305B\u3067\u3059\u30028\uFF1A30\u306B\u76EE\u899A\u307E\u3057\u304C\u9CF4\u308A\u307E\u3059\u3002",
  "id" : 439506604359442432,
  "created_at" : "2014-02-28 21:05:14 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30CF\u30E0\u30C8",
      "screen_name" : "turkey2410",
      "indices" : [ 35, 46 ],
      "id_str" : "763557104",
      "id" : 763557104
    }, {
      "name" : "\u30E8\u30B7\u30F2",
      "screen_name" : "y_misasagi",
      "indices" : [ 69, 80 ],
      "id_str" : "221377214",
      "id" : 221377214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3053\u3046\u3044\u3046\u3068\u304D\u3069\u3046\u3084\u3063\u3066\u5BDD\u308C\u3070\u826F\u3044\u304B\u308F\u304B\u3089\u306A\u3044\u306E",
      "indices" : [ 89, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439476416829067264",
  "text" : "\u30AF\u30EC\u30A4\u30B8\u30FC\u306A\u53CB\u4EBA\u3092\u7D39\u4ECB\u3059\u308B\u305C\uFF01\uFF01\u3075\u305F\u7D44\u7528\u610F\u3057\u305F\u6577\u5E03\u56E3\u3092\u6795\u306B\u3057\u3066\u5BDD\u3066\u3044\u308B@turkey2410 \uFF01\uFF01\u50D5\u304C\u666E\u6BB5\u4F7F\u3063\u3066\u308B\u30D9\u30C3\u30C9\u3067\u3044\u3061\u65E9\u304F\u7720\u3063\u305F @y_misasagi \uFF01\uFF01\uFF01\u4EE5\u4E0A\u3060\uFF01\uFF01#\u3053\u3046\u3044\u3046\u3068\u304D\u3069\u3046\u3084\u3063\u3066\u5BDD\u308C\u3070\u826F\u3044\u304B\u308F\u304B\u3089\u306A\u3044\u306E",
  "id" : 439476416829067264,
  "created_at" : "2014-02-28 19:05:17 +0000",
  "user" : {
    "name" : "end.K",
    "screen_name" : "end313124",
    "protected" : false,
    "id_str" : "155546700",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450814638066638848\/nFvSGDlu_normal.jpeg",
    "id" : 155546700,
    "verified" : false
  }
} ]