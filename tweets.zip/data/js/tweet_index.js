var tweet_index =  [ {
  "file_name" : "data\/js\/tweets\/2015_06.js",
  "year" : 2015,
  "var_name" : "tweets_2015_06",
  "tweet_count" : 233,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2015_05.js",
  "year" : 2015,
  "var_name" : "tweets_2015_05",
  "tweet_count" : 788,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2015_04.js",
  "year" : 2015,
  "var_name" : "tweets_2015_04",
  "tweet_count" : 1788,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2015_03.js",
  "year" : 2015,
  "var_name" : "tweets_2015_03",
  "tweet_count" : 1510,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2015_02.js",
  "year" : 2015,
  "var_name" : "tweets_2015_02",
  "tweet_count" : 1259,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2015_01.js",
  "year" : 2015,
  "var_name" : "tweets_2015_01",
  "tweet_count" : 1553,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2014_12.js",
  "year" : 2014,
  "var_name" : "tweets_2014_12",
  "tweet_count" : 1299,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2014_11.js",
  "year" : 2014,
  "var_name" : "tweets_2014_11",
  "tweet_count" : 1022,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2014_10.js",
  "year" : 2014,
  "var_name" : "tweets_2014_10",
  "tweet_count" : 1332,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2014_09.js",
  "year" : 2014,
  "var_name" : "tweets_2014_09",
  "tweet_count" : 1224,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2014_08.js",
  "year" : 2014,
  "var_name" : "tweets_2014_08",
  "tweet_count" : 1370,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2014_07.js",
  "year" : 2014,
  "var_name" : "tweets_2014_07",
  "tweet_count" : 1727,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2014_06.js",
  "year" : 2014,
  "var_name" : "tweets_2014_06",
  "tweet_count" : 2091,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2014_05.js",
  "year" : 2014,
  "var_name" : "tweets_2014_05",
  "tweet_count" : 3243,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2014_04.js",
  "year" : 2014,
  "var_name" : "tweets_2014_04",
  "tweet_count" : 3031,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2014_03.js",
  "year" : 2014,
  "var_name" : "tweets_2014_03",
  "tweet_count" : 936,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2014_02.js",
  "year" : 2014,
  "var_name" : "tweets_2014_02",
  "tweet_count" : 1190,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2014_01.js",
  "year" : 2014,
  "var_name" : "tweets_2014_01",
  "tweet_count" : 2380,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2013_12.js",
  "year" : 2013,
  "var_name" : "tweets_2013_12",
  "tweet_count" : 1439,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2013_11.js",
  "year" : 2013,
  "var_name" : "tweets_2013_11",
  "tweet_count" : 2322,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2013_10.js",
  "year" : 2013,
  "var_name" : "tweets_2013_10",
  "tweet_count" : 1473,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2013_09.js",
  "year" : 2013,
  "var_name" : "tweets_2013_09",
  "tweet_count" : 1684,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2013_08.js",
  "year" : 2013,
  "var_name" : "tweets_2013_08",
  "tweet_count" : 931,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2013_07.js",
  "year" : 2013,
  "var_name" : "tweets_2013_07",
  "tweet_count" : 636,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2013_06.js",
  "year" : 2013,
  "var_name" : "tweets_2013_06",
  "tweet_count" : 618,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2013_05.js",
  "year" : 2013,
  "var_name" : "tweets_2013_05",
  "tweet_count" : 889,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2013_04.js",
  "year" : 2013,
  "var_name" : "tweets_2013_04",
  "tweet_count" : 487,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2013_03.js",
  "year" : 2013,
  "var_name" : "tweets_2013_03",
  "tweet_count" : 874,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2013_02.js",
  "year" : 2013,
  "var_name" : "tweets_2013_02",
  "tweet_count" : 1520,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2013_01.js",
  "year" : 2013,
  "var_name" : "tweets_2013_01",
  "tweet_count" : 1634,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2012_12.js",
  "year" : 2012,
  "var_name" : "tweets_2012_12",
  "tweet_count" : 1404,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2012_11.js",
  "year" : 2012,
  "var_name" : "tweets_2012_11",
  "tweet_count" : 1363,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2012_10.js",
  "year" : 2012,
  "var_name" : "tweets_2012_10",
  "tweet_count" : 1576,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2012_09.js",
  "year" : 2012,
  "var_name" : "tweets_2012_09",
  "tweet_count" : 1958,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2012_08.js",
  "year" : 2012,
  "var_name" : "tweets_2012_08",
  "tweet_count" : 780,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2012_07.js",
  "year" : 2012,
  "var_name" : "tweets_2012_07",
  "tweet_count" : 946,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2012_06.js",
  "year" : 2012,
  "var_name" : "tweets_2012_06",
  "tweet_count" : 1054,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2012_05.js",
  "year" : 2012,
  "var_name" : "tweets_2012_05",
  "tweet_count" : 945,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2012_04.js",
  "year" : 2012,
  "var_name" : "tweets_2012_04",
  "tweet_count" : 1394,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2012_03.js",
  "year" : 2012,
  "var_name" : "tweets_2012_03",
  "tweet_count" : 1804,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2012_02.js",
  "year" : 2012,
  "var_name" : "tweets_2012_02",
  "tweet_count" : 1112,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2012_01.js",
  "year" : 2012,
  "var_name" : "tweets_2012_01",
  "tweet_count" : 1500,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2011_12.js",
  "year" : 2011,
  "var_name" : "tweets_2011_12",
  "tweet_count" : 1471,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2011_11.js",
  "year" : 2011,
  "var_name" : "tweets_2011_11",
  "tweet_count" : 533,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2011_10.js",
  "year" : 2011,
  "var_name" : "tweets_2011_10",
  "tweet_count" : 690,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2011_09.js",
  "year" : 2011,
  "var_name" : "tweets_2011_09",
  "tweet_count" : 756,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2011_08.js",
  "year" : 2011,
  "var_name" : "tweets_2011_08",
  "tweet_count" : 221,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2011_07.js",
  "year" : 2011,
  "var_name" : "tweets_2011_07",
  "tweet_count" : 777,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2011_06.js",
  "year" : 2011,
  "var_name" : "tweets_2011_06",
  "tweet_count" : 451,
  "month" : 6
}, {
  "file_name" : "data\/js\/tweets\/2011_05.js",
  "year" : 2011,
  "var_name" : "tweets_2011_05",
  "tweet_count" : 829,
  "month" : 5
}, {
  "file_name" : "data\/js\/tweets\/2011_04.js",
  "year" : 2011,
  "var_name" : "tweets_2011_04",
  "tweet_count" : 565,
  "month" : 4
}, {
  "file_name" : "data\/js\/tweets\/2011_03.js",
  "year" : 2011,
  "var_name" : "tweets_2011_03",
  "tweet_count" : 199,
  "month" : 3
}, {
  "file_name" : "data\/js\/tweets\/2011_02.js",
  "year" : 2011,
  "var_name" : "tweets_2011_02",
  "tweet_count" : 84,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2011_01.js",
  "year" : 2011,
  "var_name" : "tweets_2011_01",
  "tweet_count" : 87,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2010_12.js",
  "year" : 2010,
  "var_name" : "tweets_2010_12",
  "tweet_count" : 75,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2010_11.js",
  "year" : 2010,
  "var_name" : "tweets_2010_11",
  "tweet_count" : 96,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2010_10.js",
  "year" : 2010,
  "var_name" : "tweets_2010_10",
  "tweet_count" : 50,
  "month" : 10
}, {
  "file_name" : "data\/js\/tweets\/2010_09.js",
  "year" : 2010,
  "var_name" : "tweets_2010_09",
  "tweet_count" : 39,
  "month" : 9
}, {
  "file_name" : "data\/js\/tweets\/2010_08.js",
  "year" : 2010,
  "var_name" : "tweets_2010_08",
  "tweet_count" : 37,
  "month" : 8
}, {
  "file_name" : "data\/js\/tweets\/2010_07.js",
  "year" : 2010,
  "var_name" : "tweets_2010_07",
  "tweet_count" : 93,
  "month" : 7
}, {
  "file_name" : "data\/js\/tweets\/2010_06.js",
  "year" : 2010,
  "var_name" : "tweets_2010_06",
  "tweet_count" : 49,
  "month" : 6
} ]