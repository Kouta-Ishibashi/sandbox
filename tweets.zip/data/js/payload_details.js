var payload_details =  {
  "tweets" : 65895,
  "created_at" : "2015-06-09 13:11:14 +0000",
  "lang" : "ja"
}